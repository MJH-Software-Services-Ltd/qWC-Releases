/**
 * @version 1.0.0.0
 * @author MJH Software Services Ltd
 * @copyright MJH @2017
 * @compiler Bridge.NET 17.9.0
 */
Bridge.assembly("QWC", function ($asm, globals) {
    "use strict";

    Bridge.define("\u01c0\u01c0Qwc\u01c0\u01c0Component\u01c0\u01c0App\u01c0\u01c0Xaml\u01c0\u01c0Factory", {
        statics: {
            methods: {
                Instantiate: function () {
                    var type = QWC.App;
                    return Bridge.global.CSHTML5.Internal.TypeInstantiationHelper.Instantiate(type);
                }
            }
        }
    });

    Bridge.define("\u01c0\u01c0Qwc\u01c0\u01c0Component\u01c0\u01c0Mainpage\u01c0\u01c0Xaml\u01c0\u01c0Factory", {
        statics: {
            methods: {
                Instantiate: function () {
                    var type = QWC.MainPage;
                    return Bridge.global.CSHTML5.Internal.TypeInstantiationHelper.Instantiate(type);
                }
            }
        }
    });

    Bridge.define("QWC.App", {
        inherits: [Windows.UI.Xaml.Application],
        main: function Main () {
            new QWC.App();
        },
        fields: {
            d: null,
            _contentLoaded: false
        },
        ctors: {
            ctor: function () {
                this.$initialize();
                Windows.UI.Xaml.Application.ctor.call(this);
                this.InitializeComponent();
                try {
                    var a = new DataBinding.SenderClass();
                    Windows.UI.Xaml.Application.Current.Resources.setItem("SenderClass", a);
                    Windows.UI.Xaml.Application.Current.Resources.setItem("QWC", this);
                } catch ($e1) {
                    $e1 = System.Exception.create($e1);
                }
                var mainPage = new QWC.MainPage();
                if (mjh_filesloaded) mjh_filesloaded['page'] = mainPage;
                Windows.UI.Xaml.Window.Current.Content = mainPage;
            }
        },
        methods: {
            RunClickMin: function (s, args) {
                var dc = Bridge.cast(Bridge.cast(s, Windows.UI.Xaml.Controls.Button).DataContext, DataBinding.qwcForm_Data);
                dc.SendMargin = false;
                dc.State = 1;
                var root = Bridge.as(APLExtension.APL.GetInstance$3("DataBinding", "qwc_Root", "qwc_Root", this), DataBinding.qwc_Root);
                root.FullScreenId = "";
            },
            RunClickMax: function (s, args) {
                var dc = Bridge.cast(Bridge.cast(s, Windows.UI.Xaml.Controls.Button).DataContext, DataBinding.qwcForm_Data);
                dc.SendMargin = false;
                if (2 === dc.State) {
                    dc.State = 0;
                } else {
                    dc.State = 2;
                }
                var root = Bridge.as(APLExtension.APL.GetInstance$3("DataBinding", "qwc_Root", "qwc_Root", this), DataBinding.qwc_Root);
                root.FullScreenId = "";
            },
            RunClickFullScreen: function (s, args) {
                var dc = Bridge.cast(Bridge.cast(s, Windows.UI.Xaml.Controls.Button).DataContext, DataBinding.qwcForm_Data);
                var obj = Bridge.as(dc.MJH_Self, APLControls.APLForm);
                dc.SendMargin = false;
                var elem = CSHTML5.Interop.GetDiv(obj);
                openFullscreen(elem);
                dc.State = 4;
                var root = Bridge.as(APLExtension.APL.GetInstance$3("DataBinding", "qwc_Root", "qwc_Root", this), DataBinding.qwc_Root);
                root.FullScreenId = dc.Name;
            },
            RunClickClose: function (s, args) {
                var dc = Bridge.cast(Bridge.cast(s, Windows.UI.Xaml.Controls.Button).DataContext, DataBinding.qwcForm_Data);
                dc.SendMargin = false;
                var eventname = "ClickClose";
                var obj = Bridge.as(dc.MJH_Self, APLControls.APLForm);
                obj.Close$1();
            },
            InitializeComponent: function () {
                var $t;
                if (this._contentLoaded) {
                    return;
                }
                this._contentLoaded = true;


                if (Bridge.is(this, Windows.UI.Xaml.UIElement)) {
                    Bridge.cast(this, Windows.UI.Xaml.UIElement).XamlSourcePath = "QWC\\App.xaml";
                }


                Bridge.global.CSHTML5.Internal.StartupAssemblyInfo.OutputRootPath = "Output\\";
                Bridge.global.CSHTML5.Internal.StartupAssemblyInfo.OutputAppFilesPath = "app-cshtml5\\app\\";
                Bridge.global.CSHTML5.Internal.StartupAssemblyInfo.OutputLibrariesPath = "app-cshtml5\\libs\\";
                Bridge.global.CSHTML5.Internal.StartupAssemblyInfo.OutputResourcesPath = "app-cshtml5\\res\\";


                var ResourceDictionary_e2952fbb6abd42b1b96fd7a9f9e0086d = new Bridge.global.Windows.UI.Xaml.ResourceDictionary();
                this.Resources = ResourceDictionary_e2952fbb6abd42b1b96fd7a9f9e0086d;
                var IntConverter_4f0fc029082642609e91ec4dc241a474 = new Bridge.global.APLExtension.IntConverter();

                var DecConverter_6db006cb544a4003876d389f14bdfae6 = new Bridge.global.APLExtension.DecConverter();

                var ToPolyLineConverter_c14b95c2579c4e5299cfaf0c7edcea19 = new Bridge.global.APLExtension.ToPolyLineConverter();

                var ToPointsConverter_ce6d938e10464443a40b6096cee0786c = new Bridge.global.APLExtension.ToPointsConverter();

                var ToLinesConverter_31a8341ee1254e968bdb1a86ad332bc9 = new Bridge.global.APLExtension.ToLinesConverter();

                var APLColorConverter_e6b5633b5c4244a49daba81b098a31f7 = new Bridge.global.APLExtension.APLColorConverter();

                var APLColorCSSConverter_30b973812cf24833a0a97d26f07de23f = new Bridge.global.APLExtension.APLColorCSSConverter();

                var APLMultiColorConverter_1af9045d90a1418788b2b4941be6fff0 = new Bridge.global.APLExtension.APLMultiColorConverter();

                var APLMultiColorCSSConverter_1c77884d08fd40ff83eaea70642020c5 = new Bridge.global.APLExtension.APLMultiColorCSSConverter();

                var IndexInt32Converter_8933781ef9744154a0f0e12c38cc14e9 = new Bridge.global.APLExtension.IndexInt32Converter();

                var IndexDoubleConverter_6575379ad39d4a16ad09c42dd3761fe3 = new Bridge.global.APLExtension.IndexDoubleConverter();

                var IndexStringConverter_5e2c536c49d34fcc9b01f1044165d56c = new Bridge.global.APLExtension.IndexStringConverter();

                var IndexAPLColorConverter_c976d2edaf5b4a12bafa7adfc57371b4 = new Bridge.global.APLExtension.IndexAPLColorConverter();

                var IndexAPLColourConverter_f6ad351210ce41ed9a212203d86cef16 = new Bridge.global.APLExtension.IndexAPLColourConverter();

                var MathsIConverter_027ba51a91d844669f2b6dd4fe1ca9a9 = new Bridge.global.APLExtension.MathsIConverter();

                var MathsDConverter_dbb664daa16346479bd0a94c4f1bb58e = new Bridge.global.APLExtension.MathsDConverter();

                var MathIConverter_613539876bb14e13982b526a7a4b1c6d = new Bridge.global.APLExtension.MathIConverter();

                var MathDConverter_09043c9183924a1d8cb9bb2ffdac5adc = new Bridge.global.APLExtension.MathDConverter();

                var String_c1ae34d60a43493d8b929fd6930da12a = "\u2395WC Cross Platform";

                var String_3830f76b4f3c4b9aae768d2ee6e8ab69 = "MJH Software Services Ltd";

                var String_fba55e27b0904e2bb4fe1814dc76e5ec = "MJH Software Services Ltd";

                var String_d70cd1ac903045f6951867e4631c489d = "QWC";

                var String_83dd6b32c41c45a48bf7aebfd5700270 = "\u2395WC Cross Platform";

                var String_a984194d3e514a09bb81ca8a00ee75bd = "mjh.ico";

                var String_7cd16769227a480cbd8b4b5d26c736eb = "12345";

                var String_e45dc52e8e1c48e8a2723c3478abf7bc = "MainPage";

                var String_20a0908420a8408c9bf3e2ce0841f179 = "MainPage:Page";

                var String_67a6067df1e64503895bba5ebe3c32a4 = "Direct";

                var String_ab831429303d40fc823bba4101186242 = "QWC";

                var Style_b78a3de1e1c84ea5863dc5b463b71ad3 = new Bridge.global.Windows.UI.Xaml.Style.ctor();
                Style_b78a3de1e1c84ea5863dc5b463b71ad3.TargetType = Bridge.global.Windows.UI.Xaml.Controls.ChildWindow;
                var Setter_7443520a67414fcaaf5669cead6fd981 = new Bridge.global.Windows.UI.Xaml.Setter.ctor();
                Setter_7443520a67414fcaaf5669cead6fd981.Property = Bridge.global.Windows.UI.Xaml.Controls.ChildWindow.OverlayBrushProperty;
                Setter_7443520a67414fcaaf5669cead6fd981.Value = new Bridge.global.Windows.UI.Xaml.Media.SolidColorBrush.$ctor1(($t = new Bridge.global.Windows.UI.Color(), $t.A = 0, $t.R = 255, $t.G = 255, $t.B = 255, $t));

                var Setter_3770da51862e4a79a0e3c38351dcf6e1 = new Bridge.global.Windows.UI.Xaml.Setter.ctor();
                Setter_3770da51862e4a79a0e3c38351dcf6e1.Property = Bridge.global.Windows.UI.Xaml.Controls.ChildWindow.OverlayOpacityProperty;
                Setter_3770da51862e4a79a0e3c38351dcf6e1.Value = Bridge.box(1.0, System.Double, System.Double.format, System.Double.getHashCode);

                var Setter_042fdfd7bca94ac592cd6b2a4b89eaa8 = new Bridge.global.Windows.UI.Xaml.Setter.ctor();
                Setter_042fdfd7bca94ac592cd6b2a4b89eaa8.Property = Bridge.global.Windows.UI.Xaml.FrameworkElement.HorizontalAlignmentProperty;
                Setter_042fdfd7bca94ac592cd6b2a4b89eaa8.Value = Bridge.box(Bridge.global.Windows.UI.Xaml.HorizontalAlignment.Left, Windows.UI.Xaml.HorizontalAlignment, System.Enum.toStringFn(Windows.UI.Xaml.HorizontalAlignment));

                var Setter_93bad502aa5e4418b945bc05ed2107b2 = new Bridge.global.Windows.UI.Xaml.Setter.ctor();
                Setter_93bad502aa5e4418b945bc05ed2107b2.Property = Bridge.global.Windows.UI.Xaml.FrameworkElement.VerticalAlignmentProperty;
                Setter_93bad502aa5e4418b945bc05ed2107b2.Value = Bridge.box(Bridge.global.Windows.UI.Xaml.VerticalAlignment.Top, Windows.UI.Xaml.VerticalAlignment, System.Enum.toStringFn(Windows.UI.Xaml.VerticalAlignment));

                var Setter_4cf7840ded984147b4b366aed4e4c046 = new Bridge.global.Windows.UI.Xaml.Setter.ctor();
                Setter_4cf7840ded984147b4b366aed4e4c046.Property = Bridge.global.Windows.UI.Xaml.Controls.Control.TemplateProperty;
                var ControlTemplate_4102399d067a40699abe27750ada3504 = new Bridge.global.Windows.UI.Xaml.Controls.ControlTemplate();
                ControlTemplate_4102399d067a40699abe27750ada3504.TargetType = Bridge.global.Windows.UI.Xaml.Controls.ChildWindow;
                ControlTemplate_4102399d067a40699abe27750ada3504.SetMethodToInstantiateFrameworkTemplate(Bridge.fn.bind(this, function (templateOwner_ControlTemplate_4102399d067a40699abe27750ada3504) {
                    var $t1;
                    var templateInstance_796d386afaa44c97b4e7909d12e3483f = new Bridge.global.Windows.UI.Xaml.TemplateInstance();
                    templateInstance_796d386afaa44c97b4e7909d12e3483f.TemplateOwner = templateOwner_ControlTemplate_4102399d067a40699abe27750ada3504;
                    var VisualState_2860d34e171f4787b1fa67bf185e4737 = new Bridge.global.Windows.UI.Xaml.VisualState();
                    var VisualState_56a36b87c42846e9af0161d765687209 = new Bridge.global.Windows.UI.Xaml.VisualState();
                    var VisualStateGroup_3e36b1296b5c445897eac3de675fc923 = new Bridge.global.Windows.UI.Xaml.VisualStateGroup();
                    var Grid_ee4c7cb4306346f99f7485536d37553a = new Bridge.global.Windows.UI.Xaml.Controls.Grid();
                    var Button_60fae2047df74d78abf5f0946465d63e = new Bridge.global.Windows.UI.Xaml.Controls.Button();
                    var ContentControl_bc7a1dc64dd0482f9f7e43f75189a414 = new Bridge.global.Windows.UI.Xaml.Controls.ContentControl();
                    var Button_30b2d1de8c794a4590e34356a7e0c55f = new Bridge.global.Windows.UI.Xaml.Controls.Button();
                    var Button_161b3c9ca91548eea031e1094354b87d = new Bridge.global.Windows.UI.Xaml.Controls.Button();
                    var Button_d4c864165c9844c285428efa158e8d9f = new Bridge.global.Windows.UI.Xaml.Controls.Button();
                    var Button_46f2dd50b28c4f29ab75a35171c155c5 = new Bridge.global.Windows.UI.Xaml.Controls.Button();
                    var Button_442ce5b6caa44345a8c4b404d9e2c162 = new Bridge.global.Windows.UI.Xaml.Controls.Button();
                    var Border_d4641268f41b477fb6a64d40f2cf29f3 = new Bridge.global.Windows.UI.Xaml.Controls.Border();
                    var ContentPresenter_fbed8a1a428842fd816fabf9d8e11164 = new Bridge.global.Windows.UI.Xaml.Controls.ContentPresenter();
                    var Border_c1fcadb4f6d9499bb0f25f9b8c8f0224 = new Bridge.global.Windows.UI.Xaml.Controls.Border();
                    var Border_f36fff7ba6a642efaa49d8dde7277059 = new Bridge.global.Windows.UI.Xaml.Controls.Border();
                    var Grid_af86404858f64812b85b608ed289ad84 = new Bridge.global.Windows.UI.Xaml.Controls.Grid();
                    templateOwner_ControlTemplate_4102399d067a40699abe27750ada3504.RegisterName("Root", Grid_af86404858f64812b85b608ed289ad84);
                    Grid_af86404858f64812b85b608ed289ad84.Name = "Root";
                    Grid_af86404858f64812b85b608ed289ad84.RenderTransformOrigin = new Bridge.global.Windows.Foundation.Point.$ctor1(0, 0);
                    templateOwner_ControlTemplate_4102399d067a40699abe27750ada3504.RegisterName("ModalStates", VisualStateGroup_3e36b1296b5c445897eac3de675fc923);
                    VisualStateGroup_3e36b1296b5c445897eac3de675fc923.Name = "ModalStates";
                    templateOwner_ControlTemplate_4102399d067a40699abe27750ada3504.RegisterName("NotModal", VisualState_2860d34e171f4787b1fa67bf185e4737);
                    VisualState_2860d34e171f4787b1fa67bf185e4737.Name = "NotModal";
                    var Storyboard_e679a45aadc24a5588ae128b3e9cb09a = new Bridge.global.Windows.UI.Xaml.Media.Animation.Storyboard();
                    var ObjectAnimationUsingKeyFrames_035e80d0ab9946a188982d6086aa5a24 = new Bridge.global.Windows.UI.Xaml.Media.Animation.ObjectAnimationUsingKeyFrames();
                    Bridge.global.Windows.UI.Xaml.Media.Animation.Storyboard.SetTargetName(ObjectAnimationUsingKeyFrames_035e80d0ab9946a188982d6086aa5a24, "Overlay");
                    var DiscreteObjectKeyFrame_bc79ac18b9334c02a23ee8b4b8a2b14d = new Bridge.global.Windows.UI.Xaml.Media.Animation.DiscreteObjectKeyFrame();
                    var NullExtension_83cdb317ef094e3fbc35a91d9538834b = new Bridge.global.System.Windows.Markup.NullExtension();

                    DiscreteObjectKeyFrame_bc79ac18b9334c02a23ee8b4b8a2b14d.Value = null;


                    ObjectAnimationUsingKeyFrames_035e80d0ab9946a188982d6086aa5a24.KeyFrames.add(DiscreteObjectKeyFrame_bc79ac18b9334c02a23ee8b4b8a2b14d);


                    var ObjectAnimationUsingKeyFrames_e6ed720101c84195829c69efe354de06 = new Bridge.global.Windows.UI.Xaml.Media.Animation.ObjectAnimationUsingKeyFrames();
                    Bridge.global.Windows.UI.Xaml.Media.Animation.Storyboard.SetTargetName(ObjectAnimationUsingKeyFrames_e6ed720101c84195829c69efe354de06, "Overlay");
                    var DiscreteObjectKeyFrame_ffec2471640541fd8139747291c18d79 = new Bridge.global.Windows.UI.Xaml.Media.Animation.DiscreteObjectKeyFrame();
                    DiscreteObjectKeyFrame_ffec2471640541fd8139747291c18d79.Value = "False";

                    ObjectAnimationUsingKeyFrames_e6ed720101c84195829c69efe354de06.KeyFrames.add(DiscreteObjectKeyFrame_ffec2471640541fd8139747291c18d79);


                    Storyboard_e679a45aadc24a5588ae128b3e9cb09a.Children.add(ObjectAnimationUsingKeyFrames_035e80d0ab9946a188982d6086aa5a24);
                    Storyboard_e679a45aadc24a5588ae128b3e9cb09a.Children.add(ObjectAnimationUsingKeyFrames_e6ed720101c84195829c69efe354de06);


                    VisualState_2860d34e171f4787b1fa67bf185e4737.Storyboard = Storyboard_e679a45aadc24a5588ae128b3e9cb09a;


                    templateOwner_ControlTemplate_4102399d067a40699abe27750ada3504.RegisterName("Modal", VisualState_56a36b87c42846e9af0161d765687209);
                    VisualState_56a36b87c42846e9af0161d765687209.Name = "Modal";

                    System.Array.add(VisualStateGroup_3e36b1296b5c445897eac3de675fc923.States, VisualState_2860d34e171f4787b1fa67bf185e4737, Object);
                    System.Array.add(VisualStateGroup_3e36b1296b5c445897eac3de675fc923.States, VisualState_56a36b87c42846e9af0161d765687209, Object);


                    templateOwner_ControlTemplate_4102399d067a40699abe27750ada3504.INTERNAL_GetVisualStateGroups().add(VisualStateGroup_3e36b1296b5c445897eac3de675fc923);

                    templateOwner_ControlTemplate_4102399d067a40699abe27750ada3504.RegisterName("Overlay", Grid_ee4c7cb4306346f99f7485536d37553a);
                    Grid_ee4c7cb4306346f99f7485536d37553a.Name = "Overlay";
                    Grid_ee4c7cb4306346f99f7485536d37553a.HorizontalAlignment = Bridge.global.Windows.UI.Xaml.HorizontalAlignment.Stretch;
                    Grid_ee4c7cb4306346f99f7485536d37553a.VerticalAlignment = Bridge.global.Windows.UI.Xaml.VerticalAlignment.Stretch;
                    Grid_ee4c7cb4306346f99f7485536d37553a.Margin = new Bridge.global.Windows.UI.Xaml.Thickness.$ctor1(0);
                    var Binding_86cd32a323f446f183f4b385ed80003a = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_86cd32a323f446f183f4b385ed80003a.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("OverlayBrush");
                    var RelativeSource_4a2043618cda490696d79b076dd294c2 = new Bridge.global.Windows.UI.Xaml.Data.RelativeSource.ctor();
                    RelativeSource_4a2043618cda490696d79b076dd294c2.Mode = Bridge.global.Windows.UI.Xaml.Data.RelativeSourceMode.TemplatedParent;

                    Binding_86cd32a323f446f183f4b385ed80003a.RelativeSource = RelativeSource_4a2043618cda490696d79b076dd294c2;


                    Binding_86cd32a323f446f183f4b385ed80003a.TemplateOwner = templateInstance_796d386afaa44c97b4e7909d12e3483f;

                    var Binding_69414187e0e54d7c98801a04abf48ef3 = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_69414187e0e54d7c98801a04abf48ef3.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("OverlayOpacity");
                    var RelativeSource_cfa76d79d7d84da58ac02ff0fcbce1b1 = new Bridge.global.Windows.UI.Xaml.Data.RelativeSource.ctor();
                    RelativeSource_cfa76d79d7d84da58ac02ff0fcbce1b1.Mode = Bridge.global.Windows.UI.Xaml.Data.RelativeSourceMode.TemplatedParent;

                    Binding_69414187e0e54d7c98801a04abf48ef3.RelativeSource = RelativeSource_cfa76d79d7d84da58ac02ff0fcbce1b1;


                    Binding_69414187e0e54d7c98801a04abf48ef3.TemplateOwner = templateInstance_796d386afaa44c97b4e7909d12e3483f;


                    templateOwner_ControlTemplate_4102399d067a40699abe27750ada3504.RegisterName("ContentRoot", Border_f36fff7ba6a642efaa49d8dde7277059);
                    Border_f36fff7ba6a642efaa49d8dde7277059.Name = "ContentRoot";
                    templateOwner_ControlTemplate_4102399d067a40699abe27750ada3504.RegisterName("ContentContainer", Border_c1fcadb4f6d9499bb0f25f9b8c8f0224);
                    Border_c1fcadb4f6d9499bb0f25f9b8c8f0224.Name = "ContentContainer";
                    Border_c1fcadb4f6d9499bb0f25f9b8c8f0224.Background = new Bridge.global.Windows.UI.Xaml.Media.SolidColorBrush.$ctor1(($t1 = new Bridge.global.Windows.UI.Color(), $t1.A = 255, $t1.R = 246, $t1.G = 246, $t1.B = 246, $t1));
                    Border_c1fcadb4f6d9499bb0f25f9b8c8f0224.CornerRadius = new Bridge.global.Windows.UI.Xaml.CornerRadius.$ctor1(2);
                    var Grid_47bfab44efe5409e8700a1604e66c1e6 = new Bridge.global.Windows.UI.Xaml.Controls.Grid();
                    var RowDefinition_9e13a2d8b21045199b272a9a4332b93b = new Bridge.global.Windows.UI.Xaml.Controls.RowDefinition();
                    RowDefinition_9e13a2d8b21045199b272a9a4332b93b.Height = new Bridge.global.Windows.UI.Xaml.GridLength.$ctor2(1.0, Bridge.global.Windows.UI.Xaml.GridUnitType.Auto);

                    var RowDefinition_df22764b80ac4936b920778810ba06bb = new Bridge.global.Windows.UI.Xaml.Controls.RowDefinition();
                    RowDefinition_df22764b80ac4936b920778810ba06bb.Height = new Bridge.global.Windows.UI.Xaml.GridLength.$ctor2(1.0, Bridge.global.Windows.UI.Xaml.GridUnitType.Star);

                    Grid_47bfab44efe5409e8700a1604e66c1e6.RowDefinitions.add(RowDefinition_9e13a2d8b21045199b272a9a4332b93b);
                    Grid_47bfab44efe5409e8700a1604e66c1e6.RowDefinitions.add(RowDefinition_df22764b80ac4936b920778810ba06bb);

                    templateOwner_ControlTemplate_4102399d067a40699abe27750ada3504.RegisterName("Chrome", Border_d4641268f41b477fb6a64d40f2cf29f3);
                    Border_d4641268f41b477fb6a64d40f2cf29f3.Name = "Chrome";
                    Border_d4641268f41b477fb6a64d40f2cf29f3.Width = Number.NaN;
                    Border_d4641268f41b477fb6a64d40f2cf29f3.BorderBrush = new Bridge.global.Windows.UI.Xaml.Media.SolidColorBrush.$ctor1(($t1 = new Bridge.global.Windows.UI.Color(), $t1.A = 255, $t1.R = 255, $t1.G = 255, $t1.B = 255, $t1));
                    Border_d4641268f41b477fb6a64d40f2cf29f3.BorderThickness = new Bridge.global.Windows.UI.Xaml.Thickness.$ctor2(0, 0, 0, 0);
                    Border_d4641268f41b477fb6a64d40f2cf29f3.Background = new Bridge.global.Windows.UI.Xaml.Media.SolidColorBrush.$ctor1(($t1 = new Bridge.global.Windows.UI.Color(), $t1.A = 255, $t1.R = 238, $t1.G = 238, $t1.B = 238, $t1));
                    var Grid_8f02fc35a51442eeb829bd1edc70838a = new Bridge.global.Windows.UI.Xaml.Controls.Grid();
                    var ColumnDefinition_c05bc26c700c44b58318f2670a680ae2 = new Bridge.global.Windows.UI.Xaml.Controls.ColumnDefinition();
                    ColumnDefinition_c05bc26c700c44b58318f2670a680ae2.Width = new Bridge.global.Windows.UI.Xaml.GridLength.$ctor2(1.0, Bridge.global.Windows.UI.Xaml.GridUnitType.Auto);

                    var ColumnDefinition_f700bcca2e0e47cb9063b05df67f03cb = new Bridge.global.Windows.UI.Xaml.Controls.ColumnDefinition();
                    ColumnDefinition_f700bcca2e0e47cb9063b05df67f03cb.Width = new Bridge.global.Windows.UI.Xaml.GridLength.$ctor2(1.0, Bridge.global.Windows.UI.Xaml.GridUnitType.Star);

                    var ColumnDefinition_db8ff82ebf82421196d7e71fd45c2cfa = new Bridge.global.Windows.UI.Xaml.Controls.ColumnDefinition();
                    ColumnDefinition_db8ff82ebf82421196d7e71fd45c2cfa.Width = new Bridge.global.Windows.UI.Xaml.GridLength.$ctor2(1.0, Bridge.global.Windows.UI.Xaml.GridUnitType.Auto);

                    var ColumnDefinition_154d6b252685402eb463d4689e180ee0 = new Bridge.global.Windows.UI.Xaml.Controls.ColumnDefinition();
                    ColumnDefinition_154d6b252685402eb463d4689e180ee0.Width = new Bridge.global.Windows.UI.Xaml.GridLength.$ctor2(1.0, Bridge.global.Windows.UI.Xaml.GridUnitType.Auto);

                    var ColumnDefinition_da9a9ede35ba429eab5a0e191e8bd987 = new Bridge.global.Windows.UI.Xaml.Controls.ColumnDefinition();
                    ColumnDefinition_da9a9ede35ba429eab5a0e191e8bd987.Width = new Bridge.global.Windows.UI.Xaml.GridLength.$ctor2(1.0, Bridge.global.Windows.UI.Xaml.GridUnitType.Auto);

                    var ColumnDefinition_ada5004ac5df4b7c83bb82902bb9844e = new Bridge.global.Windows.UI.Xaml.Controls.ColumnDefinition();
                    ColumnDefinition_ada5004ac5df4b7c83bb82902bb9844e.Width = new Bridge.global.Windows.UI.Xaml.GridLength.$ctor2(1.0, Bridge.global.Windows.UI.Xaml.GridUnitType.Auto);

                    var ColumnDefinition_4dd5380aa9eb46029e6be3c60d3a4c00 = new Bridge.global.Windows.UI.Xaml.Controls.ColumnDefinition();
                    ColumnDefinition_4dd5380aa9eb46029e6be3c60d3a4c00.Width = new Bridge.global.Windows.UI.Xaml.GridLength.$ctor2(1.0, Bridge.global.Windows.UI.Xaml.GridUnitType.Auto);

                    Grid_8f02fc35a51442eeb829bd1edc70838a.ColumnDefinitions.add(ColumnDefinition_c05bc26c700c44b58318f2670a680ae2);
                    Grid_8f02fc35a51442eeb829bd1edc70838a.ColumnDefinitions.add(ColumnDefinition_f700bcca2e0e47cb9063b05df67f03cb);
                    Grid_8f02fc35a51442eeb829bd1edc70838a.ColumnDefinitions.add(ColumnDefinition_db8ff82ebf82421196d7e71fd45c2cfa);
                    Grid_8f02fc35a51442eeb829bd1edc70838a.ColumnDefinitions.add(ColumnDefinition_154d6b252685402eb463d4689e180ee0);
                    Grid_8f02fc35a51442eeb829bd1edc70838a.ColumnDefinitions.add(ColumnDefinition_da9a9ede35ba429eab5a0e191e8bd987);
                    Grid_8f02fc35a51442eeb829bd1edc70838a.ColumnDefinitions.add(ColumnDefinition_ada5004ac5df4b7c83bb82902bb9844e);
                    Grid_8f02fc35a51442eeb829bd1edc70838a.ColumnDefinitions.add(ColumnDefinition_4dd5380aa9eb46029e6be3c60d3a4c00);

                    templateOwner_ControlTemplate_4102399d067a40699abe27750ada3504.RegisterName("IconButton", Button_60fae2047df74d78abf5f0946465d63e);
                    Button_60fae2047df74d78abf5f0946465d63e.Name = "IconButton";
                    Button_60fae2047df74d78abf5f0946465d63e.HorizontalAlignment = Bridge.global.Windows.UI.Xaml.HorizontalAlignment.Left;
                    Button_60fae2047df74d78abf5f0946465d63e.VerticalAlignment = Bridge.global.Windows.UI.Xaml.VerticalAlignment.Center;
                    Button_60fae2047df74d78abf5f0946465d63e.HorizontalContentAlignment = Bridge.global.Windows.UI.Xaml.HorizontalAlignment.Center;
                    Button_60fae2047df74d78abf5f0946465d63e.VerticalContentAlignment = Bridge.global.Windows.UI.Xaml.VerticalAlignment.Center;
                    Button_60fae2047df74d78abf5f0946465d63e.Width = 20.0;
                    Button_60fae2047df74d78abf5f0946465d63e.Padding = new Bridge.global.Windows.UI.Xaml.Thickness.$ctor1(0);
                    var Image_d6e2e42e91614a148e6910fd214d8fff = new Bridge.global.Windows.UI.Xaml.Controls.Image();
                    var Binding_69611c557b3d40a8b6d203eb230ff77e = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_69611c557b3d40a8b6d203eb230ff77e.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("Icon");



                    Button_60fae2047df74d78abf5f0946465d63e.Content = Image_d6e2e42e91614a148e6910fd214d8fff;

                    var Binding_aafcd2de5e8c4b9298f3baa708cce4a3 = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_aafcd2de5e8c4b9298f3baa708cce4a3.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("IconVisibility");



                    templateOwner_ControlTemplate_4102399d067a40699abe27750ada3504.RegisterName("Title", ContentControl_bc7a1dc64dd0482f9f7e43f75189a414);
                    ContentControl_bc7a1dc64dd0482f9f7e43f75189a414.Name = "Title";
                    Bridge.global.Windows.UI.Xaml.Controls.Grid.SetColumn(ContentControl_bc7a1dc64dd0482f9f7e43f75189a414, 1);
                    ContentControl_bc7a1dc64dd0482f9f7e43f75189a414.HorizontalAlignment = Bridge.global.Windows.UI.Xaml.HorizontalAlignment.Left;
                    ContentControl_bc7a1dc64dd0482f9f7e43f75189a414.VerticalAlignment = Bridge.global.Windows.UI.Xaml.VerticalAlignment.Center;
                    ContentControl_bc7a1dc64dd0482f9f7e43f75189a414.Margin = new Bridge.global.Windows.UI.Xaml.Thickness.$ctor2(6, 0, 6, 0);
                    var Binding_991bf82f47dc40528015cd2c10237adb = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_991bf82f47dc40528015cd2c10237adb.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("Title");
                    var RelativeSource_e524d656fbea4e6c926f6400238d75cc = new Bridge.global.Windows.UI.Xaml.Data.RelativeSource.ctor();
                    RelativeSource_e524d656fbea4e6c926f6400238d75cc.Mode = Bridge.global.Windows.UI.Xaml.Data.RelativeSourceMode.TemplatedParent;

                    Binding_991bf82f47dc40528015cd2c10237adb.RelativeSource = RelativeSource_e524d656fbea4e6c926f6400238d75cc;


                    Binding_991bf82f47dc40528015cd2c10237adb.TemplateOwner = templateInstance_796d386afaa44c97b4e7909d12e3483f;


                    templateOwner_ControlTemplate_4102399d067a40699abe27750ada3504.RegisterName("HelpButton", Button_30b2d1de8c794a4590e34356a7e0c55f);
                    Button_30b2d1de8c794a4590e34356a7e0c55f.Name = "HelpButton";
                    Button_30b2d1de8c794a4590e34356a7e0c55f.HorizontalAlignment = Bridge.global.Windows.UI.Xaml.HorizontalAlignment.Right;
                    Button_30b2d1de8c794a4590e34356a7e0c55f.VerticalAlignment = Bridge.global.Windows.UI.Xaml.VerticalAlignment.Center;
                    Bridge.global.Windows.UI.Xaml.Controls.Grid.SetColumn(Button_30b2d1de8c794a4590e34356a7e0c55f, 2);
                    Button_30b2d1de8c794a4590e34356a7e0c55f.HorizontalContentAlignment = Bridge.global.Windows.UI.Xaml.HorizontalAlignment.Center;
                    Button_30b2d1de8c794a4590e34356a7e0c55f.VerticalContentAlignment = Bridge.global.Windows.UI.Xaml.VerticalAlignment.Center;
                    Button_30b2d1de8c794a4590e34356a7e0c55f.Width = 20.0;
                    Button_30b2d1de8c794a4590e34356a7e0c55f.Padding = new Bridge.global.Windows.UI.Xaml.Thickness.$ctor1(0);
                    var Image_8070472e3dae4b08b1915ca5e82c3914 = new Bridge.global.Windows.UI.Xaml.Controls.Image();
                    var Binding_4af27fcd47e44a6bbd040c11aafb174a = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_4af27fcd47e44a6bbd040c11aafb174a.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("HelpIcon");



                    Button_30b2d1de8c794a4590e34356a7e0c55f.Content = Image_8070472e3dae4b08b1915ca5e82c3914;

                    var Binding_037e74bdb563460b9fdcd024e04bf4c2 = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_037e74bdb563460b9fdcd024e04bf4c2.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("HelpVisibility");



                    templateOwner_ControlTemplate_4102399d067a40699abe27750ada3504.RegisterName("MinButton", Button_161b3c9ca91548eea031e1094354b87d);
                    Button_161b3c9ca91548eea031e1094354b87d.Name = "MinButton";
                    Button_161b3c9ca91548eea031e1094354b87d.HorizontalAlignment = Bridge.global.Windows.UI.Xaml.HorizontalAlignment.Right;
                    Button_161b3c9ca91548eea031e1094354b87d.VerticalAlignment = Bridge.global.Windows.UI.Xaml.VerticalAlignment.Center;
                    Bridge.global.Windows.UI.Xaml.Controls.Grid.SetColumn(Button_161b3c9ca91548eea031e1094354b87d, 3);
                    Button_161b3c9ca91548eea031e1094354b87d.HorizontalContentAlignment = Bridge.global.Windows.UI.Xaml.HorizontalAlignment.Center;
                    Button_161b3c9ca91548eea031e1094354b87d.VerticalContentAlignment = Bridge.global.Windows.UI.Xaml.VerticalAlignment.Center;
                    Button_161b3c9ca91548eea031e1094354b87d.Width = 20.0;
                    Button_161b3c9ca91548eea031e1094354b87d.Padding = new Bridge.global.Windows.UI.Xaml.Thickness.$ctor1(0);
                    Button_161b3c9ca91548eea031e1094354b87d.addClick(Bridge.fn.cacheBind(this, this.RunClickMin));
                    var Image_7ae402d125c346dfa7e503c35742666e = new Bridge.global.Windows.UI.Xaml.Controls.Image();
                    var Binding_b06f7c30a5ca4826a902b2aab01e9734 = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_b06f7c30a5ca4826a902b2aab01e9734.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("MinResIcon");



                    Button_161b3c9ca91548eea031e1094354b87d.Content = Image_7ae402d125c346dfa7e503c35742666e;

                    var Binding_0f4f24d2950d425ea454bc064dd57f8d = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_0f4f24d2950d425ea454bc064dd57f8d.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("MinVisibility");



                    templateOwner_ControlTemplate_4102399d067a40699abe27750ada3504.RegisterName("MaxButton", Button_d4c864165c9844c285428efa158e8d9f);
                    Button_d4c864165c9844c285428efa158e8d9f.Name = "MaxButton";
                    Button_d4c864165c9844c285428efa158e8d9f.HorizontalAlignment = Bridge.global.Windows.UI.Xaml.HorizontalAlignment.Right;
                    Button_d4c864165c9844c285428efa158e8d9f.VerticalAlignment = Bridge.global.Windows.UI.Xaml.VerticalAlignment.Center;
                    Bridge.global.Windows.UI.Xaml.Controls.Grid.SetColumn(Button_d4c864165c9844c285428efa158e8d9f, 4);
                    Button_d4c864165c9844c285428efa158e8d9f.HorizontalContentAlignment = Bridge.global.Windows.UI.Xaml.HorizontalAlignment.Center;
                    Button_d4c864165c9844c285428efa158e8d9f.VerticalContentAlignment = Bridge.global.Windows.UI.Xaml.VerticalAlignment.Center;
                    Button_d4c864165c9844c285428efa158e8d9f.Width = 20.0;
                    Button_d4c864165c9844c285428efa158e8d9f.Padding = new Bridge.global.Windows.UI.Xaml.Thickness.$ctor1(0);
                    Button_d4c864165c9844c285428efa158e8d9f.addClick(Bridge.fn.cacheBind(this, this.RunClickMax));
                    var Image_d59bd3ab8e524514b8de0dadf2572742 = new Bridge.global.Windows.UI.Xaml.Controls.Image();
                    var Binding_5dcaf0d38a744b679c2e89a5874b7950 = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_5dcaf0d38a744b679c2e89a5874b7950.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("MaxResIcon");



                    Button_d4c864165c9844c285428efa158e8d9f.Content = Image_d59bd3ab8e524514b8de0dadf2572742;

                    var Binding_08f24589dfc5427fb8c326dcc3b21602 = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_08f24589dfc5427fb8c326dcc3b21602.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("MaxVisibility");



                    templateOwner_ControlTemplate_4102399d067a40699abe27750ada3504.RegisterName("FullScreenButton", Button_46f2dd50b28c4f29ab75a35171c155c5);
                    Button_46f2dd50b28c4f29ab75a35171c155c5.Name = "FullScreenButton";
                    Button_46f2dd50b28c4f29ab75a35171c155c5.HorizontalAlignment = Bridge.global.Windows.UI.Xaml.HorizontalAlignment.Right;
                    Button_46f2dd50b28c4f29ab75a35171c155c5.VerticalAlignment = Bridge.global.Windows.UI.Xaml.VerticalAlignment.Center;
                    Bridge.global.Windows.UI.Xaml.Controls.Grid.SetColumn(Button_46f2dd50b28c4f29ab75a35171c155c5, 5);
                    Button_46f2dd50b28c4f29ab75a35171c155c5.HorizontalContentAlignment = Bridge.global.Windows.UI.Xaml.HorizontalAlignment.Center;
                    Button_46f2dd50b28c4f29ab75a35171c155c5.VerticalContentAlignment = Bridge.global.Windows.UI.Xaml.VerticalAlignment.Center;
                    Button_46f2dd50b28c4f29ab75a35171c155c5.Width = 20.0;
                    Button_46f2dd50b28c4f29ab75a35171c155c5.Padding = new Bridge.global.Windows.UI.Xaml.Thickness.$ctor1(0);
                    Button_46f2dd50b28c4f29ab75a35171c155c5.addClick(Bridge.fn.cacheBind(this, this.RunClickFullScreen));
                    var Image_1f26cd4335814d73a390c84a7bbb5afe = new Bridge.global.Windows.UI.Xaml.Controls.Image();
                    var Binding_598ed236f9a94b1cb019a85c934fbe22 = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_598ed236f9a94b1cb019a85c934fbe22.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("FullScreenIcon");



                    Button_46f2dd50b28c4f29ab75a35171c155c5.Content = Image_1f26cd4335814d73a390c84a7bbb5afe;

                    var Binding_0f46f87b1660474e9b1c4fa7d7c44ed6 = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_0f46f87b1660474e9b1c4fa7d7c44ed6.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("FullScreenVisibility");



                    templateOwner_ControlTemplate_4102399d067a40699abe27750ada3504.RegisterName("CloseButton", Button_442ce5b6caa44345a8c4b404d9e2c162);
                    Button_442ce5b6caa44345a8c4b404d9e2c162.Name = "CloseButton";
                    Button_442ce5b6caa44345a8c4b404d9e2c162.HorizontalAlignment = Bridge.global.Windows.UI.Xaml.HorizontalAlignment.Right;
                    Button_442ce5b6caa44345a8c4b404d9e2c162.VerticalAlignment = Bridge.global.Windows.UI.Xaml.VerticalAlignment.Center;
                    Bridge.global.Windows.UI.Xaml.Controls.Grid.SetColumn(Button_442ce5b6caa44345a8c4b404d9e2c162, 6);
                    Button_442ce5b6caa44345a8c4b404d9e2c162.HorizontalContentAlignment = Bridge.global.Windows.UI.Xaml.HorizontalAlignment.Center;
                    Button_442ce5b6caa44345a8c4b404d9e2c162.VerticalContentAlignment = Bridge.global.Windows.UI.Xaml.VerticalAlignment.Center;
                    Button_442ce5b6caa44345a8c4b404d9e2c162.Width = 20.0;
                    Button_442ce5b6caa44345a8c4b404d9e2c162.Padding = new Bridge.global.Windows.UI.Xaml.Thickness.$ctor1(0);
                    Button_442ce5b6caa44345a8c4b404d9e2c162.addClick(Bridge.fn.cacheBind(this, this.RunClickClose));
                    var Image_e30080894e7246e09c40fec66e23d9a9 = new Bridge.global.Windows.UI.Xaml.Controls.Image();
                    var Binding_a28574d350764225a52ffa48a7282761 = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_a28574d350764225a52ffa48a7282761.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("CloseIcon");



                    Button_442ce5b6caa44345a8c4b404d9e2c162.Content = Image_e30080894e7246e09c40fec66e23d9a9;

                    var Binding_a4d2f93f98434c3db453d4db14f63379 = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_a4d2f93f98434c3db453d4db14f63379.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("CloseVisibility");



                    Grid_8f02fc35a51442eeb829bd1edc70838a.Children.add(Button_60fae2047df74d78abf5f0946465d63e);
                    Grid_8f02fc35a51442eeb829bd1edc70838a.Children.add(ContentControl_bc7a1dc64dd0482f9f7e43f75189a414);
                    Grid_8f02fc35a51442eeb829bd1edc70838a.Children.add(Button_30b2d1de8c794a4590e34356a7e0c55f);
                    Grid_8f02fc35a51442eeb829bd1edc70838a.Children.add(Button_161b3c9ca91548eea031e1094354b87d);
                    Grid_8f02fc35a51442eeb829bd1edc70838a.Children.add(Button_d4c864165c9844c285428efa158e8d9f);
                    Grid_8f02fc35a51442eeb829bd1edc70838a.Children.add(Button_46f2dd50b28c4f29ab75a35171c155c5);
                    Grid_8f02fc35a51442eeb829bd1edc70838a.Children.add(Button_442ce5b6caa44345a8c4b404d9e2c162);


                    Border_d4641268f41b477fb6a64d40f2cf29f3.Child = Grid_8f02fc35a51442eeb829bd1edc70838a;

                    var Binding_0a5793a35c8647909e39f2fdf1f8df4a = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_0a5793a35c8647909e39f2fdf1f8df4a.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("TitleVisibility");



                    var Border_0aa9ce5feabf46f5a7c45e53a2172fcc = new Bridge.global.Windows.UI.Xaml.Controls.Border();
                    Bridge.global.Windows.UI.Xaml.Controls.Grid.SetRow(Border_0aa9ce5feabf46f5a7c45e53a2172fcc, 1);
                    Border_0aa9ce5feabf46f5a7c45e53a2172fcc.BorderThickness = new Bridge.global.Windows.UI.Xaml.Thickness.$ctor2(0, 0, 0, 0);
                    templateOwner_ControlTemplate_4102399d067a40699abe27750ada3504.RegisterName("FormContentPresenter", ContentPresenter_fbed8a1a428842fd816fabf9d8e11164);
                    ContentPresenter_fbed8a1a428842fd816fabf9d8e11164.Name = "FormContentPresenter";
                    ContentPresenter_fbed8a1a428842fd816fabf9d8e11164.ClipToBounds = true;
                    var Binding_e3c0110bf588484f8152c4d9d6a73a62 = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_e3c0110bf588484f8152c4d9d6a73a62.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("Content");
                    var RelativeSource_4c137be614af451fabb737b4e5f73a9e = new Bridge.global.Windows.UI.Xaml.Data.RelativeSource.ctor();
                    RelativeSource_4c137be614af451fabb737b4e5f73a9e.Mode = Bridge.global.Windows.UI.Xaml.Data.RelativeSourceMode.TemplatedParent;

                    Binding_e3c0110bf588484f8152c4d9d6a73a62.RelativeSource = RelativeSource_4c137be614af451fabb737b4e5f73a9e;


                    Binding_e3c0110bf588484f8152c4d9d6a73a62.TemplateOwner = templateInstance_796d386afaa44c97b4e7909d12e3483f;

                    var Binding_71681778ec0f45a1847a305535c00f5f = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_71681778ec0f45a1847a305535c00f5f.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("ContentTemplate");
                    var RelativeSource_c3a81e25c73f46049aceeb4cbc230739 = new Bridge.global.Windows.UI.Xaml.Data.RelativeSource.ctor();
                    RelativeSource_c3a81e25c73f46049aceeb4cbc230739.Mode = Bridge.global.Windows.UI.Xaml.Data.RelativeSourceMode.TemplatedParent;

                    Binding_71681778ec0f45a1847a305535c00f5f.RelativeSource = RelativeSource_c3a81e25c73f46049aceeb4cbc230739;


                    Binding_71681778ec0f45a1847a305535c00f5f.TemplateOwner = templateInstance_796d386afaa44c97b4e7909d12e3483f;

                    var Binding_34c8f4422b14463cb71204836154c5dc = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_34c8f4422b14463cb71204836154c5dc.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("ClientWidth");


                    var Binding_fcf4f1db5bf34151a75e1f0027650bad = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_fcf4f1db5bf34151a75e1f0027650bad.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("ClientHeight");


                    var Binding_be6ea6fa1ab34d2fbc444e1a098bd95a = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_be6ea6fa1ab34d2fbc444e1a098bd95a.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("HorizontalAlignment");
                    var RelativeSource_40de737074384cebbd97856b64d62594 = new Bridge.global.Windows.UI.Xaml.Data.RelativeSource.ctor();
                    RelativeSource_40de737074384cebbd97856b64d62594.Mode = Bridge.global.Windows.UI.Xaml.Data.RelativeSourceMode.TemplatedParent;

                    Binding_be6ea6fa1ab34d2fbc444e1a098bd95a.RelativeSource = RelativeSource_40de737074384cebbd97856b64d62594;


                    Binding_be6ea6fa1ab34d2fbc444e1a098bd95a.TemplateOwner = templateInstance_796d386afaa44c97b4e7909d12e3483f;

                    var Binding_c83cb7d5e88e4a97a9bbbdcdc56dcc68 = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_c83cb7d5e88e4a97a9bbbdcdc56dcc68.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("VerticalAlignment");
                    var RelativeSource_d10af7d10b824efb992d56603fb0112d = new Bridge.global.Windows.UI.Xaml.Data.RelativeSource.ctor();
                    RelativeSource_d10af7d10b824efb992d56603fb0112d.Mode = Bridge.global.Windows.UI.Xaml.Data.RelativeSourceMode.TemplatedParent;

                    Binding_c83cb7d5e88e4a97a9bbbdcdc56dcc68.RelativeSource = RelativeSource_d10af7d10b824efb992d56603fb0112d;


                    Binding_c83cb7d5e88e4a97a9bbbdcdc56dcc68.TemplateOwner = templateInstance_796d386afaa44c97b4e7909d12e3483f;


                    Border_0aa9ce5feabf46f5a7c45e53a2172fcc.Child = ContentPresenter_fbed8a1a428842fd816fabf9d8e11164;

                    var Binding_ef0e44e9410c4b2681f497feea091147 = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_ef0e44e9410c4b2681f497feea091147.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("ClientHeight");


                    var Binding_b6b0d01c8a734f10a1ac52b67c83e354 = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_b6b0d01c8a734f10a1ac52b67c83e354.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("ClientWidth");


                    var Binding_b1aac4c0905c420c8965fef5e439bf51 = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_b1aac4c0905c420c8965fef5e439bf51.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("Background");
                    var RelativeSource_658510df9c4c4d74abba4aaaf0792525 = new Bridge.global.Windows.UI.Xaml.Data.RelativeSource.ctor();
                    RelativeSource_658510df9c4c4d74abba4aaaf0792525.Mode = Bridge.global.Windows.UI.Xaml.Data.RelativeSourceMode.TemplatedParent;

                    Binding_b1aac4c0905c420c8965fef5e439bf51.RelativeSource = RelativeSource_658510df9c4c4d74abba4aaaf0792525;


                    Binding_b1aac4c0905c420c8965fef5e439bf51.TemplateOwner = templateInstance_796d386afaa44c97b4e7909d12e3483f;

                    var Binding_5b8a2e8079ad4fc79cc9b1e6338540ab = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_5b8a2e8079ad4fc79cc9b1e6338540ab.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("Background");
                    var RelativeSource_fdbd2003243c414ab5297cdb043644a2 = new Bridge.global.Windows.UI.Xaml.Data.RelativeSource.ctor();
                    RelativeSource_fdbd2003243c414ab5297cdb043644a2.Mode = Bridge.global.Windows.UI.Xaml.Data.RelativeSourceMode.TemplatedParent;

                    Binding_5b8a2e8079ad4fc79cc9b1e6338540ab.RelativeSource = RelativeSource_fdbd2003243c414ab5297cdb043644a2;


                    Binding_5b8a2e8079ad4fc79cc9b1e6338540ab.TemplateOwner = templateInstance_796d386afaa44c97b4e7909d12e3483f;


                    Grid_47bfab44efe5409e8700a1604e66c1e6.Children.add(Border_d4641268f41b477fb6a64d40f2cf29f3);
                    Grid_47bfab44efe5409e8700a1604e66c1e6.Children.add(Border_0aa9ce5feabf46f5a7c45e53a2172fcc);


                    Border_c1fcadb4f6d9499bb0f25f9b8c8f0224.Child = Grid_47bfab44efe5409e8700a1604e66c1e6;

                    var Binding_c8cf490b85cf4b51a29554edde4c7529 = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_c8cf490b85cf4b51a29554edde4c7529.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("BorderThickness");
                    var RelativeSource_1ed6d57dc27d479593d5ccdc4475959e = new Bridge.global.Windows.UI.Xaml.Data.RelativeSource.ctor();
                    RelativeSource_1ed6d57dc27d479593d5ccdc4475959e.Mode = Bridge.global.Windows.UI.Xaml.Data.RelativeSourceMode.TemplatedParent;

                    Binding_c8cf490b85cf4b51a29554edde4c7529.RelativeSource = RelativeSource_1ed6d57dc27d479593d5ccdc4475959e;


                    Binding_c8cf490b85cf4b51a29554edde4c7529.TemplateOwner = templateInstance_796d386afaa44c97b4e7909d12e3483f;

                    var Binding_22d511359dcc4afd867a3b0c7262c37d = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_22d511359dcc4afd867a3b0c7262c37d.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("BorderBrush");
                    var RelativeSource_35aa2dc795af4ceaa3ec008324cccbfe = new Bridge.global.Windows.UI.Xaml.Data.RelativeSource.ctor();
                    RelativeSource_35aa2dc795af4ceaa3ec008324cccbfe.Mode = Bridge.global.Windows.UI.Xaml.Data.RelativeSourceMode.TemplatedParent;

                    Binding_22d511359dcc4afd867a3b0c7262c37d.RelativeSource = RelativeSource_35aa2dc795af4ceaa3ec008324cccbfe;


                    Binding_22d511359dcc4afd867a3b0c7262c37d.TemplateOwner = templateInstance_796d386afaa44c97b4e7909d12e3483f;


                    Border_f36fff7ba6a642efaa49d8dde7277059.Child = Border_c1fcadb4f6d9499bb0f25f9b8c8f0224;


                    Grid_af86404858f64812b85b608ed289ad84.Children.add(Grid_ee4c7cb4306346f99f7485536d37553a);
                    Grid_af86404858f64812b85b608ed289ad84.Children.add(Border_f36fff7ba6a642efaa49d8dde7277059);

                    var Binding_d5443166e3cb497c9599ba94758be6ef = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_d5443166e3cb497c9599ba94758be6ef.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("Height");
                    var RelativeSource_15d160a3892144fbb574e31a1960cfc8 = new Bridge.global.Windows.UI.Xaml.Data.RelativeSource.ctor();
                    RelativeSource_15d160a3892144fbb574e31a1960cfc8.Mode = Bridge.global.Windows.UI.Xaml.Data.RelativeSourceMode.TemplatedParent;

                    Binding_d5443166e3cb497c9599ba94758be6ef.RelativeSource = RelativeSource_15d160a3892144fbb574e31a1960cfc8;


                    Binding_d5443166e3cb497c9599ba94758be6ef.TemplateOwner = templateInstance_796d386afaa44c97b4e7909d12e3483f;

                    var Binding_c18495cb335141b69c9d50045a2f4582 = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_c18495cb335141b69c9d50045a2f4582.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("Width");
                    var RelativeSource_662ab443f4564dd4a5f34c2a43a56ebb = new Bridge.global.Windows.UI.Xaml.Data.RelativeSource.ctor();
                    RelativeSource_662ab443f4564dd4a5f34c2a43a56ebb.Mode = Bridge.global.Windows.UI.Xaml.Data.RelativeSourceMode.TemplatedParent;

                    Binding_c18495cb335141b69c9d50045a2f4582.RelativeSource = RelativeSource_662ab443f4564dd4a5f34c2a43a56ebb;


                    Binding_c18495cb335141b69c9d50045a2f4582.TemplateOwner = templateInstance_796d386afaa44c97b4e7909d12e3483f;

                    var Binding_74e84791d69a4a979db46152bb1224bd = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_74e84791d69a4a979db46152bb1224bd.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("HorizontalAlignment");
                    var RelativeSource_c8f11f171b174cbb93edb7964b8d4fbb = new Bridge.global.Windows.UI.Xaml.Data.RelativeSource.ctor();
                    RelativeSource_c8f11f171b174cbb93edb7964b8d4fbb.Mode = Bridge.global.Windows.UI.Xaml.Data.RelativeSourceMode.TemplatedParent;

                    Binding_74e84791d69a4a979db46152bb1224bd.RelativeSource = RelativeSource_c8f11f171b174cbb93edb7964b8d4fbb;


                    Binding_74e84791d69a4a979db46152bb1224bd.TemplateOwner = templateInstance_796d386afaa44c97b4e7909d12e3483f;

                    var Binding_706ca05c1cfc4dce89bef4149bbdcb7d = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_706ca05c1cfc4dce89bef4149bbdcb7d.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("VerticalAlignment");
                    var RelativeSource_d64616540af84ae985c50498a0366336 = new Bridge.global.Windows.UI.Xaml.Data.RelativeSource.ctor();
                    RelativeSource_d64616540af84ae985c50498a0366336.Mode = Bridge.global.Windows.UI.Xaml.Data.RelativeSourceMode.TemplatedParent;

                    Binding_706ca05c1cfc4dce89bef4149bbdcb7d.RelativeSource = RelativeSource_d64616540af84ae985c50498a0366336;


                    Binding_706ca05c1cfc4dce89bef4149bbdcb7d.TemplateOwner = templateInstance_796d386afaa44c97b4e7909d12e3483f;


                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(Grid_ee4c7cb4306346f99f7485536d37553a, Bridge.global.Windows.UI.Xaml.Controls.Panel.BackgroundProperty, Binding_86cd32a323f446f183f4b385ed80003a);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(Grid_ee4c7cb4306346f99f7485536d37553a, Bridge.global.Windows.UI.Xaml.UIElement.OpacityProperty, Binding_69414187e0e54d7c98801a04abf48ef3);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(Image_d6e2e42e91614a148e6910fd214d8fff, Bridge.global.Windows.UI.Xaml.Controls.Image.SourceProperty, Binding_69611c557b3d40a8b6d203eb230ff77e);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(Button_60fae2047df74d78abf5f0946465d63e, Bridge.global.Windows.UI.Xaml.UIElement.VisibilityProperty, Binding_aafcd2de5e8c4b9298f3baa708cce4a3);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(ContentControl_bc7a1dc64dd0482f9f7e43f75189a414, Bridge.global.Windows.UI.Xaml.Controls.ContentControl.ContentProperty, Binding_991bf82f47dc40528015cd2c10237adb);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(Image_8070472e3dae4b08b1915ca5e82c3914, Bridge.global.Windows.UI.Xaml.Controls.Image.SourceProperty, Binding_4af27fcd47e44a6bbd040c11aafb174a);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(Button_30b2d1de8c794a4590e34356a7e0c55f, Bridge.global.Windows.UI.Xaml.UIElement.VisibilityProperty, Binding_037e74bdb563460b9fdcd024e04bf4c2);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(Image_7ae402d125c346dfa7e503c35742666e, Bridge.global.Windows.UI.Xaml.Controls.Image.SourceProperty, Binding_b06f7c30a5ca4826a902b2aab01e9734);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(Button_161b3c9ca91548eea031e1094354b87d, Bridge.global.Windows.UI.Xaml.UIElement.VisibilityProperty, Binding_0f4f24d2950d425ea454bc064dd57f8d);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(Image_d59bd3ab8e524514b8de0dadf2572742, Bridge.global.Windows.UI.Xaml.Controls.Image.SourceProperty, Binding_5dcaf0d38a744b679c2e89a5874b7950);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(Button_d4c864165c9844c285428efa158e8d9f, Bridge.global.Windows.UI.Xaml.UIElement.VisibilityProperty, Binding_08f24589dfc5427fb8c326dcc3b21602);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(Image_1f26cd4335814d73a390c84a7bbb5afe, Bridge.global.Windows.UI.Xaml.Controls.Image.SourceProperty, Binding_598ed236f9a94b1cb019a85c934fbe22);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(Button_46f2dd50b28c4f29ab75a35171c155c5, Bridge.global.Windows.UI.Xaml.UIElement.VisibilityProperty, Binding_0f46f87b1660474e9b1c4fa7d7c44ed6);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(Image_e30080894e7246e09c40fec66e23d9a9, Bridge.global.Windows.UI.Xaml.Controls.Image.SourceProperty, Binding_a28574d350764225a52ffa48a7282761);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(Button_442ce5b6caa44345a8c4b404d9e2c162, Bridge.global.Windows.UI.Xaml.UIElement.VisibilityProperty, Binding_a4d2f93f98434c3db453d4db14f63379);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(Border_d4641268f41b477fb6a64d40f2cf29f3, Bridge.global.Windows.UI.Xaml.UIElement.VisibilityProperty, Binding_0a5793a35c8647909e39f2fdf1f8df4a);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(ContentPresenter_fbed8a1a428842fd816fabf9d8e11164, Bridge.global.Windows.UI.Xaml.Controls.ContentControl.ContentProperty, Binding_e3c0110bf588484f8152c4d9d6a73a62);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(ContentPresenter_fbed8a1a428842fd816fabf9d8e11164, Bridge.global.Windows.UI.Xaml.Controls.ContentControl.ContentTemplateProperty, Binding_71681778ec0f45a1847a305535c00f5f);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(ContentPresenter_fbed8a1a428842fd816fabf9d8e11164, Bridge.global.Windows.UI.Xaml.FrameworkElement.WidthProperty, Binding_34c8f4422b14463cb71204836154c5dc);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(ContentPresenter_fbed8a1a428842fd816fabf9d8e11164, Bridge.global.Windows.UI.Xaml.FrameworkElement.HeightProperty, Binding_fcf4f1db5bf34151a75e1f0027650bad);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(ContentPresenter_fbed8a1a428842fd816fabf9d8e11164, Bridge.global.Windows.UI.Xaml.FrameworkElement.HorizontalAlignmentProperty, Binding_be6ea6fa1ab34d2fbc444e1a098bd95a);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(ContentPresenter_fbed8a1a428842fd816fabf9d8e11164, Bridge.global.Windows.UI.Xaml.FrameworkElement.VerticalAlignmentProperty, Binding_c83cb7d5e88e4a97a9bbbdcdc56dcc68);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(Border_0aa9ce5feabf46f5a7c45e53a2172fcc, Bridge.global.Windows.UI.Xaml.FrameworkElement.HeightProperty, Binding_ef0e44e9410c4b2681f497feea091147);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(Border_0aa9ce5feabf46f5a7c45e53a2172fcc, Bridge.global.Windows.UI.Xaml.FrameworkElement.WidthProperty, Binding_b6b0d01c8a734f10a1ac52b67c83e354);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(Border_0aa9ce5feabf46f5a7c45e53a2172fcc, Bridge.global.Windows.UI.Xaml.Controls.Border.BackgroundProperty, Binding_b1aac4c0905c420c8965fef5e439bf51);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(Border_0aa9ce5feabf46f5a7c45e53a2172fcc, Bridge.global.Windows.UI.Xaml.Controls.Border.BorderBrushProperty, Binding_5b8a2e8079ad4fc79cc9b1e6338540ab);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(Border_c1fcadb4f6d9499bb0f25f9b8c8f0224, Bridge.global.Windows.UI.Xaml.Controls.Border.BorderThicknessProperty, Binding_c8cf490b85cf4b51a29554edde4c7529);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(Border_c1fcadb4f6d9499bb0f25f9b8c8f0224, Bridge.global.Windows.UI.Xaml.Controls.Border.BorderBrushProperty, Binding_22d511359dcc4afd867a3b0c7262c37d);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(Grid_af86404858f64812b85b608ed289ad84, Bridge.global.Windows.UI.Xaml.FrameworkElement.HeightProperty, Binding_d5443166e3cb497c9599ba94758be6ef);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(Grid_af86404858f64812b85b608ed289ad84, Bridge.global.Windows.UI.Xaml.FrameworkElement.WidthProperty, Binding_c18495cb335141b69c9d50045a2f4582);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(Grid_af86404858f64812b85b608ed289ad84, Bridge.global.Windows.UI.Xaml.FrameworkElement.HorizontalAlignmentProperty, Binding_74e84791d69a4a979db46152bb1224bd);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(Grid_af86404858f64812b85b608ed289ad84, Bridge.global.Windows.UI.Xaml.FrameworkElement.VerticalAlignmentProperty, Binding_706ca05c1cfc4dce89bef4149bbdcb7d);

                    Bridge.global.Windows.UI.Xaml.Media.Animation.Storyboard.SetTargetProperty(ObjectAnimationUsingKeyFrames_035e80d0ab9946a188982d6086aa5a24, new Bridge.global.Windows.UI.Xaml.PropertyPath.$ctor2("Background", "Background", Bridge.fn.cacheBind(this, this.accessVisualStateProperty_0efeb1ee91ba4e7fb4a607183778abe9), Bridge.fn.cacheBind(this, this.setVisualStateProperty_0efeb1ee91ba4e7fb4a607183778abe9), Bridge.fn.cacheBind(this, this.setAnimationVisualStateProperty_0efeb1ee91ba4e7fb4a607183778abe9), Bridge.fn.cacheBind(this, this.setLocalVisualStateProperty_0efeb1ee91ba4e7fb4a607183778abe9), Bridge.fn.cacheBind(this, this.getVisualStateProperty_0efeb1ee91ba4e7fb4a607183778abe9)));
                    Bridge.global.Windows.UI.Xaml.Media.Animation.Storyboard.SetTarget(ObjectAnimationUsingKeyFrames_035e80d0ab9946a188982d6086aa5a24, Grid_ee4c7cb4306346f99f7485536d37553a);


                    Bridge.global.Windows.UI.Xaml.Media.Animation.Storyboard.SetTargetProperty(ObjectAnimationUsingKeyFrames_e6ed720101c84195829c69efe354de06, new Bridge.global.Windows.UI.Xaml.PropertyPath.$ctor2("IsHitTestVisible", "IsHitTestVisible", Bridge.fn.cacheBind(this, this.accessVisualStateProperty_432128cd104b46ed8f7e8d441715639b), Bridge.fn.cacheBind(this, this.setVisualStateProperty_432128cd104b46ed8f7e8d441715639b), Bridge.fn.cacheBind(this, this.setAnimationVisualStateProperty_432128cd104b46ed8f7e8d441715639b), Bridge.fn.cacheBind(this, this.setLocalVisualStateProperty_432128cd104b46ed8f7e8d441715639b), Bridge.fn.cacheBind(this, this.getVisualStateProperty_432128cd104b46ed8f7e8d441715639b)));
                    Bridge.global.Windows.UI.Xaml.Media.Animation.Storyboard.SetTarget(ObjectAnimationUsingKeyFrames_e6ed720101c84195829c69efe354de06, Grid_ee4c7cb4306346f99f7485536d37553a);

                    templateInstance_796d386afaa44c97b4e7909d12e3483f.TemplateContent = Grid_af86404858f64812b85b608ed289ad84;
                    return templateInstance_796d386afaa44c97b4e7909d12e3483f;
                }));

                Setter_4cf7840ded984147b4b366aed4e4c046.Value = ControlTemplate_4102399d067a40699abe27750ada3504;


                Style_b78a3de1e1c84ea5863dc5b463b71ad3.Setters.add(Setter_7443520a67414fcaaf5669cead6fd981);
                Style_b78a3de1e1c84ea5863dc5b463b71ad3.Setters.add(Setter_3770da51862e4a79a0e3c38351dcf6e1);
                Style_b78a3de1e1c84ea5863dc5b463b71ad3.Setters.add(Setter_042fdfd7bca94ac592cd6b2a4b89eaa8);
                Style_b78a3de1e1c84ea5863dc5b463b71ad3.Setters.add(Setter_93bad502aa5e4418b945bc05ed2107b2);
                Style_b78a3de1e1c84ea5863dc5b463b71ad3.Setters.add(Setter_4cf7840ded984147b4b366aed4e4c046);


                var Style_6a1730c2b07846c9b6041cce22b4eafa = new Bridge.global.Windows.UI.Xaml.Style.ctor();
                Style_6a1730c2b07846c9b6041cce22b4eafa.TargetType = Bridge.global.Windows.UI.Xaml.Controls.Button;
                var Setter_d3cd7bc82ba74c2490e29328458dfefb = new Bridge.global.Windows.UI.Xaml.Setter.ctor();
                Setter_d3cd7bc82ba74c2490e29328458dfefb.Property = Bridge.global.Windows.UI.Xaml.Controls.Control.BackgroundProperty;
                Setter_d3cd7bc82ba74c2490e29328458dfefb.Value = new Bridge.global.Windows.UI.Xaml.Media.SolidColorBrush.$ctor1(($t = new Bridge.global.Windows.UI.Color(), $t.A = 255, $t.R = 226, $t.G = 226, $t.B = 226, $t));

                var Setter_ab288d468ea44df892ae06552443fbab = new Bridge.global.Windows.UI.Xaml.Setter.ctor();
                Setter_ab288d468ea44df892ae06552443fbab.Property = Bridge.global.Windows.UI.Xaml.Controls.Control.ForegroundProperty;
                Setter_ab288d468ea44df892ae06552443fbab.Value = new Bridge.global.Windows.UI.Xaml.Media.SolidColorBrush.$ctor1(($t = new Bridge.global.Windows.UI.Color(), $t.A = 255, $t.R = 0, $t.G = 0, $t.B = 0, $t));

                var Setter_2ec1b316c31e40259b4b5a1984769a47 = new Bridge.global.Windows.UI.Xaml.Setter.ctor();
                Setter_2ec1b316c31e40259b4b5a1984769a47.Property = Bridge.global.Windows.UI.Xaml.Controls.Control.BorderThicknessProperty;
                Setter_2ec1b316c31e40259b4b5a1984769a47.Value = new Bridge.global.Windows.UI.Xaml.Thickness.$ctor1(0).$clone();

                var Setter_c28692cd71994dc09ec6da2d363babf7 = new Bridge.global.Windows.UI.Xaml.Setter.ctor();
                Setter_c28692cd71994dc09ec6da2d363babf7.Property = Bridge.global.Windows.UI.Xaml.Controls.Control.PaddingProperty;
                Setter_c28692cd71994dc09ec6da2d363babf7.Value = new Bridge.global.Windows.UI.Xaml.Thickness.$ctor2(12, 4, 12, 4).$clone();

                var Setter_fb84d2e842d545648eab2f46275e55bb = new Bridge.global.Windows.UI.Xaml.Setter.ctor();
                Setter_fb84d2e842d545648eab2f46275e55bb.Property = Bridge.global.Windows.UI.Xaml.FrameworkElement.CursorProperty;
                Setter_fb84d2e842d545648eab2f46275e55bb.Value = Bridge.global.System.Windows.Input.Cursors.Hand;

                var Setter_9290ec738d09424b9f591078fa5a246c = new Bridge.global.Windows.UI.Xaml.Setter.ctor();
                Setter_9290ec738d09424b9f591078fa5a246c.Property = Bridge.global.Windows.UI.Xaml.Controls.Control.HorizontalContentAlignmentProperty;
                Setter_9290ec738d09424b9f591078fa5a246c.Value = Bridge.box(Bridge.global.Windows.UI.Xaml.HorizontalAlignment.Center, Windows.UI.Xaml.HorizontalAlignment, System.Enum.toStringFn(Windows.UI.Xaml.HorizontalAlignment));

                var Setter_ce33a3e7cc65419d89a8dbb42f688a29 = new Bridge.global.Windows.UI.Xaml.Setter.ctor();
                Setter_ce33a3e7cc65419d89a8dbb42f688a29.Property = Bridge.global.Windows.UI.Xaml.Controls.Control.VerticalContentAlignmentProperty;
                Setter_ce33a3e7cc65419d89a8dbb42f688a29.Value = Bridge.box(Bridge.global.Windows.UI.Xaml.VerticalAlignment.Center, Windows.UI.Xaml.VerticalAlignment, System.Enum.toStringFn(Windows.UI.Xaml.VerticalAlignment));

                var Setter_6e07fe7283da410bb65e0af156e52768 = new Bridge.global.Windows.UI.Xaml.Setter.ctor();
                Setter_6e07fe7283da410bb65e0af156e52768.Property = Bridge.global.Windows.UI.Xaml.Controls.Control.TemplateProperty;
                var ControlTemplate_8afc2814747b4677a26d45679c3d612c = new Bridge.global.Windows.UI.Xaml.Controls.ControlTemplate();
                ControlTemplate_8afc2814747b4677a26d45679c3d612c.TargetType = Bridge.global.Windows.UI.Xaml.Controls.Button;
                ControlTemplate_8afc2814747b4677a26d45679c3d612c.SetMethodToInstantiateFrameworkTemplate(Bridge.fn.bind(this, function (templateOwner_ControlTemplate_8afc2814747b4677a26d45679c3d612c) {
                    var templateInstance_e91b0aef99424442a38f6eb8419c8185 = new Bridge.global.Windows.UI.Xaml.TemplateInstance();
                    templateInstance_e91b0aef99424442a38f6eb8419c8185.TemplateOwner = templateOwner_ControlTemplate_8afc2814747b4677a26d45679c3d612c;
                    var VisualState_0767c9b5eac74569889aa1bda9aa5d68 = new Bridge.global.Windows.UI.Xaml.VisualState();
                    var VisualState_542ae96077e44b339d9f4cae513d94e7 = new Bridge.global.Windows.UI.Xaml.VisualState();
                    var VisualState_4545adb37cc446f6b391940016311665 = new Bridge.global.Windows.UI.Xaml.VisualState();
                    var VisualState_70ffa7a556b84deb81bbd4f99d98ccb9 = new Bridge.global.Windows.UI.Xaml.VisualState();
                    var VisualStateGroup_954728a580504c8b8cbb686b6975ed48 = new Bridge.global.Windows.UI.Xaml.VisualStateGroup();
                    var ContentPresenter_d18cd84aa993427d8287e4d6ab192fcb = new Bridge.global.Windows.UI.Xaml.Controls.ContentPresenter();
                    var Border_bb3bb633583a4cc3820e757de8e0d4d4 = new Bridge.global.Windows.UI.Xaml.Controls.Border();
                    var Border_cef48745920341fd9b1636f3053dbd81 = new Bridge.global.Windows.UI.Xaml.Controls.Border();
                    templateOwner_ControlTemplate_8afc2814747b4677a26d45679c3d612c.RegisterName("OuterBorder", Border_cef48745920341fd9b1636f3053dbd81);
                    Border_cef48745920341fd9b1636f3053dbd81.Name = "OuterBorder";
                    templateOwner_ControlTemplate_8afc2814747b4677a26d45679c3d612c.RegisterName("CommonStates", VisualStateGroup_954728a580504c8b8cbb686b6975ed48);
                    VisualStateGroup_954728a580504c8b8cbb686b6975ed48.Name = "CommonStates";
                    templateOwner_ControlTemplate_8afc2814747b4677a26d45679c3d612c.RegisterName("Normal", VisualState_0767c9b5eac74569889aa1bda9aa5d68);
                    VisualState_0767c9b5eac74569889aa1bda9aa5d68.Name = "Normal";

                    templateOwner_ControlTemplate_8afc2814747b4677a26d45679c3d612c.RegisterName("PointerOver", VisualState_542ae96077e44b339d9f4cae513d94e7);
                    VisualState_542ae96077e44b339d9f4cae513d94e7.Name = "PointerOver";
                    var Storyboard_fb7397d06b954e619f4ba2dc99afa949 = new Bridge.global.Windows.UI.Xaml.Media.Animation.Storyboard();
                    var ObjectAnimationUsingKeyFrames_b4bded6eaf7c45fc9103ebc1433b3bbc = new Bridge.global.Windows.UI.Xaml.Media.Animation.ObjectAnimationUsingKeyFrames();
                    Bridge.global.Windows.UI.Xaml.Media.Animation.Storyboard.SetTargetName(ObjectAnimationUsingKeyFrames_b4bded6eaf7c45fc9103ebc1433b3bbc, "InnerBorder");
                    var DiscreteObjectKeyFrame_593013d5e81747a9b0b1fb55ea9bb5ca = new Bridge.global.Windows.UI.Xaml.Media.Animation.DiscreteObjectKeyFrame();
                    DiscreteObjectKeyFrame_593013d5e81747a9b0b1fb55ea9bb5ca.KeyTime = Bridge.global.Windows.UI.Xaml.Media.Animation.KeyTime.FromTimeSpan(new Bridge.global.System.TimeSpan(System.Int64(0)));
                    DiscreteObjectKeyFrame_593013d5e81747a9b0b1fb55ea9bb5ca.Value = "#11000000";

                    ObjectAnimationUsingKeyFrames_b4bded6eaf7c45fc9103ebc1433b3bbc.KeyFrames.add(DiscreteObjectKeyFrame_593013d5e81747a9b0b1fb55ea9bb5ca);


                    Storyboard_fb7397d06b954e619f4ba2dc99afa949.Children.add(ObjectAnimationUsingKeyFrames_b4bded6eaf7c45fc9103ebc1433b3bbc);


                    VisualState_542ae96077e44b339d9f4cae513d94e7.Storyboard = Storyboard_fb7397d06b954e619f4ba2dc99afa949;


                    templateOwner_ControlTemplate_8afc2814747b4677a26d45679c3d612c.RegisterName("Pressed", VisualState_4545adb37cc446f6b391940016311665);
                    VisualState_4545adb37cc446f6b391940016311665.Name = "Pressed";
                    var Storyboard_acdf105c5ed546fb922e1ee30f691016 = new Bridge.global.Windows.UI.Xaml.Media.Animation.Storyboard();
                    var ObjectAnimationUsingKeyFrames_2c23f01b1c124a9191b9f5feaeac11d8 = new Bridge.global.Windows.UI.Xaml.Media.Animation.ObjectAnimationUsingKeyFrames();
                    Bridge.global.Windows.UI.Xaml.Media.Animation.Storyboard.SetTargetName(ObjectAnimationUsingKeyFrames_2c23f01b1c124a9191b9f5feaeac11d8, "InnerBorder");
                    var DiscreteObjectKeyFrame_60c5a6cec97b467ba4f03d32e74053d1 = new Bridge.global.Windows.UI.Xaml.Media.Animation.DiscreteObjectKeyFrame();
                    DiscreteObjectKeyFrame_60c5a6cec97b467ba4f03d32e74053d1.KeyTime = Bridge.global.Windows.UI.Xaml.Media.Animation.KeyTime.FromTimeSpan(new Bridge.global.System.TimeSpan(System.Int64(0)));
                    DiscreteObjectKeyFrame_60c5a6cec97b467ba4f03d32e74053d1.Value = "#22000000";

                    ObjectAnimationUsingKeyFrames_2c23f01b1c124a9191b9f5feaeac11d8.KeyFrames.add(DiscreteObjectKeyFrame_60c5a6cec97b467ba4f03d32e74053d1);


                    Storyboard_acdf105c5ed546fb922e1ee30f691016.Children.add(ObjectAnimationUsingKeyFrames_2c23f01b1c124a9191b9f5feaeac11d8);


                    VisualState_4545adb37cc446f6b391940016311665.Storyboard = Storyboard_acdf105c5ed546fb922e1ee30f691016;


                    templateOwner_ControlTemplate_8afc2814747b4677a26d45679c3d612c.RegisterName("Disabled", VisualState_70ffa7a556b84deb81bbd4f99d98ccb9);
                    VisualState_70ffa7a556b84deb81bbd4f99d98ccb9.Name = "Disabled";
                    var Storyboard_1968fccb19a347f3b90029e8b0e7ba52 = new Bridge.global.Windows.UI.Xaml.Media.Animation.Storyboard();
                    var ObjectAnimationUsingKeyFrames_40dba0b037974d62be1b5c2f6784e2a1 = new Bridge.global.Windows.UI.Xaml.Media.Animation.ObjectAnimationUsingKeyFrames();
                    Bridge.global.Windows.UI.Xaml.Media.Animation.Storyboard.SetTargetName(ObjectAnimationUsingKeyFrames_40dba0b037974d62be1b5c2f6784e2a1, "InnerBorder");
                    var DiscreteObjectKeyFrame_720c56632cbb40f2b151d766b6691e10 = new Bridge.global.Windows.UI.Xaml.Media.Animation.DiscreteObjectKeyFrame();
                    DiscreteObjectKeyFrame_720c56632cbb40f2b151d766b6691e10.KeyTime = Bridge.global.Windows.UI.Xaml.Media.Animation.KeyTime.FromTimeSpan(new Bridge.global.System.TimeSpan(System.Int64(0)));
                    DiscreteObjectKeyFrame_720c56632cbb40f2b151d766b6691e10.Value = "#33FFFFFF";

                    ObjectAnimationUsingKeyFrames_40dba0b037974d62be1b5c2f6784e2a1.KeyFrames.add(DiscreteObjectKeyFrame_720c56632cbb40f2b151d766b6691e10);


                    Storyboard_1968fccb19a347f3b90029e8b0e7ba52.Children.add(ObjectAnimationUsingKeyFrames_40dba0b037974d62be1b5c2f6784e2a1);


                    VisualState_70ffa7a556b84deb81bbd4f99d98ccb9.Storyboard = Storyboard_1968fccb19a347f3b90029e8b0e7ba52;


                    System.Array.add(VisualStateGroup_954728a580504c8b8cbb686b6975ed48.States, VisualState_0767c9b5eac74569889aa1bda9aa5d68, Object);
                    System.Array.add(VisualStateGroup_954728a580504c8b8cbb686b6975ed48.States, VisualState_542ae96077e44b339d9f4cae513d94e7, Object);
                    System.Array.add(VisualStateGroup_954728a580504c8b8cbb686b6975ed48.States, VisualState_4545adb37cc446f6b391940016311665, Object);
                    System.Array.add(VisualStateGroup_954728a580504c8b8cbb686b6975ed48.States, VisualState_70ffa7a556b84deb81bbd4f99d98ccb9, Object);


                    templateOwner_ControlTemplate_8afc2814747b4677a26d45679c3d612c.INTERNAL_GetVisualStateGroups().add(VisualStateGroup_954728a580504c8b8cbb686b6975ed48);

                    templateOwner_ControlTemplate_8afc2814747b4677a26d45679c3d612c.RegisterName("InnerBorder", Border_bb3bb633583a4cc3820e757de8e0d4d4);
                    Border_bb3bb633583a4cc3820e757de8e0d4d4.Name = "InnerBorder";
                    templateOwner_ControlTemplate_8afc2814747b4677a26d45679c3d612c.RegisterName("ContentPresenter", ContentPresenter_d18cd84aa993427d8287e4d6ab192fcb);
                    ContentPresenter_d18cd84aa993427d8287e4d6ab192fcb.Name = "ContentPresenter";
                    var Binding_cb48836e9a944e9c9a77e0a712c00fe6 = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_cb48836e9a944e9c9a77e0a712c00fe6.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("ContentTemplate");
                    var RelativeSource_cccdd57ba4e042b3bae88c892f2e5f9f = new Bridge.global.Windows.UI.Xaml.Data.RelativeSource.ctor();
                    RelativeSource_cccdd57ba4e042b3bae88c892f2e5f9f.Mode = Bridge.global.Windows.UI.Xaml.Data.RelativeSourceMode.TemplatedParent;

                    Binding_cb48836e9a944e9c9a77e0a712c00fe6.RelativeSource = RelativeSource_cccdd57ba4e042b3bae88c892f2e5f9f;


                    Binding_cb48836e9a944e9c9a77e0a712c00fe6.TemplateOwner = templateInstance_e91b0aef99424442a38f6eb8419c8185;

                    var Binding_f965cb164dda462bba62950f49c1a746 = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_f965cb164dda462bba62950f49c1a746.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("Content");
                    var RelativeSource_375d72f04b644099bdec8e28ceeeecc9 = new Bridge.global.Windows.UI.Xaml.Data.RelativeSource.ctor();
                    RelativeSource_375d72f04b644099bdec8e28ceeeecc9.Mode = Bridge.global.Windows.UI.Xaml.Data.RelativeSourceMode.TemplatedParent;

                    Binding_f965cb164dda462bba62950f49c1a746.RelativeSource = RelativeSource_375d72f04b644099bdec8e28ceeeecc9;


                    Binding_f965cb164dda462bba62950f49c1a746.TemplateOwner = templateInstance_e91b0aef99424442a38f6eb8419c8185;

                    var Binding_81401f04b70645a99b505901a58ec268 = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_81401f04b70645a99b505901a58ec268.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("Height");
                    var RelativeSource_02e19677613041c0ae3aced45b2b9950 = new Bridge.global.Windows.UI.Xaml.Data.RelativeSource.ctor();
                    RelativeSource_02e19677613041c0ae3aced45b2b9950.Mode = Bridge.global.Windows.UI.Xaml.Data.RelativeSourceMode.TemplatedParent;

                    Binding_81401f04b70645a99b505901a58ec268.RelativeSource = RelativeSource_02e19677613041c0ae3aced45b2b9950;


                    Binding_81401f04b70645a99b505901a58ec268.TemplateOwner = templateInstance_e91b0aef99424442a38f6eb8419c8185;

                    var Binding_32d7a355b4d641a4a4014e8a6d9bf5ed = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_32d7a355b4d641a4a4014e8a6d9bf5ed.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("Width");
                    var RelativeSource_af609a7b2e104faaa1efef6f10dc2cb0 = new Bridge.global.Windows.UI.Xaml.Data.RelativeSource.ctor();
                    RelativeSource_af609a7b2e104faaa1efef6f10dc2cb0.Mode = Bridge.global.Windows.UI.Xaml.Data.RelativeSourceMode.TemplatedParent;

                    Binding_32d7a355b4d641a4a4014e8a6d9bf5ed.RelativeSource = RelativeSource_af609a7b2e104faaa1efef6f10dc2cb0;


                    Binding_32d7a355b4d641a4a4014e8a6d9bf5ed.TemplateOwner = templateInstance_e91b0aef99424442a38f6eb8419c8185;

                    var Binding_c6cc01571ea84df58e55d46e6044d1ae = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_c6cc01571ea84df58e55d46e6044d1ae.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("Padding");
                    var RelativeSource_e0decfe7bfce429fb371b61a4a9b8ffb = new Bridge.global.Windows.UI.Xaml.Data.RelativeSource.ctor();
                    RelativeSource_e0decfe7bfce429fb371b61a4a9b8ffb.Mode = Bridge.global.Windows.UI.Xaml.Data.RelativeSourceMode.TemplatedParent;

                    Binding_c6cc01571ea84df58e55d46e6044d1ae.RelativeSource = RelativeSource_e0decfe7bfce429fb371b61a4a9b8ffb;


                    Binding_c6cc01571ea84df58e55d46e6044d1ae.TemplateOwner = templateInstance_e91b0aef99424442a38f6eb8419c8185;

                    var Binding_4455f2c39270462aa2993e2238dd40fd = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_4455f2c39270462aa2993e2238dd40fd.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("HorizontalContentAlignment");
                    var RelativeSource_62469ac9a73e4e0b9fa93e35ebffb817 = new Bridge.global.Windows.UI.Xaml.Data.RelativeSource.ctor();
                    RelativeSource_62469ac9a73e4e0b9fa93e35ebffb817.Mode = Bridge.global.Windows.UI.Xaml.Data.RelativeSourceMode.TemplatedParent;

                    Binding_4455f2c39270462aa2993e2238dd40fd.RelativeSource = RelativeSource_62469ac9a73e4e0b9fa93e35ebffb817;


                    Binding_4455f2c39270462aa2993e2238dd40fd.TemplateOwner = templateInstance_e91b0aef99424442a38f6eb8419c8185;

                    var Binding_2a0af287b68c47f69e9efeba8182d75a = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_2a0af287b68c47f69e9efeba8182d75a.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("VerticalContentAlignment");
                    var RelativeSource_e3c005d220944e1988b79dec50e71061 = new Bridge.global.Windows.UI.Xaml.Data.RelativeSource.ctor();
                    RelativeSource_e3c005d220944e1988b79dec50e71061.Mode = Bridge.global.Windows.UI.Xaml.Data.RelativeSourceMode.TemplatedParent;

                    Binding_2a0af287b68c47f69e9efeba8182d75a.RelativeSource = RelativeSource_e3c005d220944e1988b79dec50e71061;


                    Binding_2a0af287b68c47f69e9efeba8182d75a.TemplateOwner = templateInstance_e91b0aef99424442a38f6eb8419c8185;

                    var Binding_1cf6887002214ab38b8fdc5a450f3cd4 = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_1cf6887002214ab38b8fdc5a450f3cd4.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("Visibility");



                    Border_bb3bb633583a4cc3820e757de8e0d4d4.Child = ContentPresenter_d18cd84aa993427d8287e4d6ab192fcb;

                    var Binding_bc471710688841e28f6b6081a38d6148 = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_bc471710688841e28f6b6081a38d6148.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("Background");
                    var RelativeSource_617fb72a05b2449198cf95cb6ed4e10c = new Bridge.global.Windows.UI.Xaml.Data.RelativeSource.ctor();
                    RelativeSource_617fb72a05b2449198cf95cb6ed4e10c.Mode = Bridge.global.Windows.UI.Xaml.Data.RelativeSourceMode.TemplatedParent;

                    Binding_bc471710688841e28f6b6081a38d6148.RelativeSource = RelativeSource_617fb72a05b2449198cf95cb6ed4e10c;


                    Binding_bc471710688841e28f6b6081a38d6148.TemplateOwner = templateInstance_e91b0aef99424442a38f6eb8419c8185;


                    Border_cef48745920341fd9b1636f3053dbd81.Child = Border_bb3bb633583a4cc3820e757de8e0d4d4;

                    var Binding_933b803d367f46ab9580a4f7a8e755b2 = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_933b803d367f46ab9580a4f7a8e755b2.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("Background");
                    var RelativeSource_09b061dbd59e42a4a9d2d6bc50ceaf3a = new Bridge.global.Windows.UI.Xaml.Data.RelativeSource.ctor();
                    RelativeSource_09b061dbd59e42a4a9d2d6bc50ceaf3a.Mode = Bridge.global.Windows.UI.Xaml.Data.RelativeSourceMode.TemplatedParent;

                    Binding_933b803d367f46ab9580a4f7a8e755b2.RelativeSource = RelativeSource_09b061dbd59e42a4a9d2d6bc50ceaf3a;


                    Binding_933b803d367f46ab9580a4f7a8e755b2.TemplateOwner = templateInstance_e91b0aef99424442a38f6eb8419c8185;

                    var Binding_3502abe6475b43529d3b4533a6ac74af = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_3502abe6475b43529d3b4533a6ac74af.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("BorderBrush");
                    var RelativeSource_ae721e1f54d3411f951f8c22916f1a97 = new Bridge.global.Windows.UI.Xaml.Data.RelativeSource.ctor();
                    RelativeSource_ae721e1f54d3411f951f8c22916f1a97.Mode = Bridge.global.Windows.UI.Xaml.Data.RelativeSourceMode.TemplatedParent;

                    Binding_3502abe6475b43529d3b4533a6ac74af.RelativeSource = RelativeSource_ae721e1f54d3411f951f8c22916f1a97;


                    Binding_3502abe6475b43529d3b4533a6ac74af.TemplateOwner = templateInstance_e91b0aef99424442a38f6eb8419c8185;

                    var Binding_03655984c9da456d8462188313d254a9 = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_03655984c9da456d8462188313d254a9.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("BorderThickness");
                    var RelativeSource_389fec1a7bf94faab363d6b87875d02a = new Bridge.global.Windows.UI.Xaml.Data.RelativeSource.ctor();
                    RelativeSource_389fec1a7bf94faab363d6b87875d02a.Mode = Bridge.global.Windows.UI.Xaml.Data.RelativeSourceMode.TemplatedParent;

                    Binding_03655984c9da456d8462188313d254a9.RelativeSource = RelativeSource_389fec1a7bf94faab363d6b87875d02a;


                    Binding_03655984c9da456d8462188313d254a9.TemplateOwner = templateInstance_e91b0aef99424442a38f6eb8419c8185;

                    var Binding_7c4585d566e24ac9b4f74e5c205756d2 = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_7c4585d566e24ac9b4f74e5c205756d2.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("Margin");
                    var RelativeSource_fc8d200a502341b683b4108b64f7e897 = new Bridge.global.Windows.UI.Xaml.Data.RelativeSource.ctor();
                    RelativeSource_fc8d200a502341b683b4108b64f7e897.Mode = Bridge.global.Windows.UI.Xaml.Data.RelativeSourceMode.TemplatedParent;

                    Binding_7c4585d566e24ac9b4f74e5c205756d2.RelativeSource = RelativeSource_fc8d200a502341b683b4108b64f7e897;


                    Binding_7c4585d566e24ac9b4f74e5c205756d2.TemplateOwner = templateInstance_e91b0aef99424442a38f6eb8419c8185;

                    var Binding_6820f864ebc041f0bcddbccb24c0aab9 = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_6820f864ebc041f0bcddbccb24c0aab9.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("Visibility");



                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(ContentPresenter_d18cd84aa993427d8287e4d6ab192fcb, Bridge.global.Windows.UI.Xaml.Controls.ContentControl.ContentTemplateProperty, Binding_cb48836e9a944e9c9a77e0a712c00fe6);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(ContentPresenter_d18cd84aa993427d8287e4d6ab192fcb, Bridge.global.Windows.UI.Xaml.Controls.ContentControl.ContentProperty, Binding_f965cb164dda462bba62950f49c1a746);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(ContentPresenter_d18cd84aa993427d8287e4d6ab192fcb, Bridge.global.Windows.UI.Xaml.FrameworkElement.HeightProperty, Binding_81401f04b70645a99b505901a58ec268);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(ContentPresenter_d18cd84aa993427d8287e4d6ab192fcb, Bridge.global.Windows.UI.Xaml.FrameworkElement.WidthProperty, Binding_32d7a355b4d641a4a4014e8a6d9bf5ed);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(ContentPresenter_d18cd84aa993427d8287e4d6ab192fcb, Bridge.global.Windows.UI.Xaml.FrameworkElement.MarginProperty, Binding_c6cc01571ea84df58e55d46e6044d1ae);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(ContentPresenter_d18cd84aa993427d8287e4d6ab192fcb, Bridge.global.Windows.UI.Xaml.FrameworkElement.HorizontalAlignmentProperty, Binding_4455f2c39270462aa2993e2238dd40fd);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(ContentPresenter_d18cd84aa993427d8287e4d6ab192fcb, Bridge.global.Windows.UI.Xaml.FrameworkElement.VerticalAlignmentProperty, Binding_2a0af287b68c47f69e9efeba8182d75a);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(ContentPresenter_d18cd84aa993427d8287e4d6ab192fcb, Bridge.global.Windows.UI.Xaml.UIElement.VisibilityProperty, Binding_1cf6887002214ab38b8fdc5a450f3cd4);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(Border_bb3bb633583a4cc3820e757de8e0d4d4, Bridge.global.Windows.UI.Xaml.Controls.Border.BackgroundProperty, Binding_bc471710688841e28f6b6081a38d6148);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(Border_cef48745920341fd9b1636f3053dbd81, Bridge.global.Windows.UI.Xaml.Controls.Border.BackgroundProperty, Binding_933b803d367f46ab9580a4f7a8e755b2);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(Border_cef48745920341fd9b1636f3053dbd81, Bridge.global.Windows.UI.Xaml.Controls.Border.BorderBrushProperty, Binding_3502abe6475b43529d3b4533a6ac74af);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(Border_cef48745920341fd9b1636f3053dbd81, Bridge.global.Windows.UI.Xaml.Controls.Border.BorderThicknessProperty, Binding_03655984c9da456d8462188313d254a9);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(Border_cef48745920341fd9b1636f3053dbd81, Bridge.global.Windows.UI.Xaml.FrameworkElement.MarginProperty, Binding_7c4585d566e24ac9b4f74e5c205756d2);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(Border_cef48745920341fd9b1636f3053dbd81, Bridge.global.Windows.UI.Xaml.UIElement.VisibilityProperty, Binding_6820f864ebc041f0bcddbccb24c0aab9);

                    Bridge.global.Windows.UI.Xaml.Media.Animation.Storyboard.SetTargetProperty(ObjectAnimationUsingKeyFrames_b4bded6eaf7c45fc9103ebc1433b3bbc, new Bridge.global.Windows.UI.Xaml.PropertyPath.$ctor2("Background", "Background", Bridge.fn.cacheBind(this, this.accessVisualStateProperty_3a3e2022cc954baeb81d6f3ec01c449f), Bridge.fn.cacheBind(this, this.setVisualStateProperty_3a3e2022cc954baeb81d6f3ec01c449f), Bridge.fn.cacheBind(this, this.setAnimationVisualStateProperty_3a3e2022cc954baeb81d6f3ec01c449f), Bridge.fn.cacheBind(this, this.setLocalVisualStateProperty_3a3e2022cc954baeb81d6f3ec01c449f), Bridge.fn.cacheBind(this, this.getVisualStateProperty_3a3e2022cc954baeb81d6f3ec01c449f)));
                    Bridge.global.Windows.UI.Xaml.Media.Animation.Storyboard.SetTarget(ObjectAnimationUsingKeyFrames_b4bded6eaf7c45fc9103ebc1433b3bbc, Border_bb3bb633583a4cc3820e757de8e0d4d4);


                    Bridge.global.Windows.UI.Xaml.Media.Animation.Storyboard.SetTargetProperty(ObjectAnimationUsingKeyFrames_2c23f01b1c124a9191b9f5feaeac11d8, new Bridge.global.Windows.UI.Xaml.PropertyPath.$ctor2("Background", "Background", Bridge.fn.cacheBind(this, this.accessVisualStateProperty_0644eb09043444188059ca9517a15f22), Bridge.fn.cacheBind(this, this.setVisualStateProperty_0644eb09043444188059ca9517a15f22), Bridge.fn.cacheBind(this, this.setAnimationVisualStateProperty_0644eb09043444188059ca9517a15f22), Bridge.fn.cacheBind(this, this.setLocalVisualStateProperty_0644eb09043444188059ca9517a15f22), Bridge.fn.cacheBind(this, this.getVisualStateProperty_0644eb09043444188059ca9517a15f22)));
                    Bridge.global.Windows.UI.Xaml.Media.Animation.Storyboard.SetTarget(ObjectAnimationUsingKeyFrames_2c23f01b1c124a9191b9f5feaeac11d8, Border_bb3bb633583a4cc3820e757de8e0d4d4);


                    Bridge.global.Windows.UI.Xaml.Media.Animation.Storyboard.SetTargetProperty(ObjectAnimationUsingKeyFrames_40dba0b037974d62be1b5c2f6784e2a1, new Bridge.global.Windows.UI.Xaml.PropertyPath.$ctor2("Background", "Background", Bridge.fn.cacheBind(this, this.accessVisualStateProperty_0371403c000847ad8936836e5ce40cf3), Bridge.fn.cacheBind(this, this.setVisualStateProperty_0371403c000847ad8936836e5ce40cf3), Bridge.fn.cacheBind(this, this.setAnimationVisualStateProperty_0371403c000847ad8936836e5ce40cf3), Bridge.fn.cacheBind(this, this.setLocalVisualStateProperty_0371403c000847ad8936836e5ce40cf3), Bridge.fn.cacheBind(this, this.getVisualStateProperty_0371403c000847ad8936836e5ce40cf3)));
                    Bridge.global.Windows.UI.Xaml.Media.Animation.Storyboard.SetTarget(ObjectAnimationUsingKeyFrames_40dba0b037974d62be1b5c2f6784e2a1, Border_bb3bb633583a4cc3820e757de8e0d4d4);

                    templateInstance_e91b0aef99424442a38f6eb8419c8185.TemplateContent = Border_cef48745920341fd9b1636f3053dbd81;
                    return templateInstance_e91b0aef99424442a38f6eb8419c8185;
                }));

                Setter_6e07fe7283da410bb65e0af156e52768.Value = ControlTemplate_8afc2814747b4677a26d45679c3d612c;


                Style_6a1730c2b07846c9b6041cce22b4eafa.Setters.add(Setter_d3cd7bc82ba74c2490e29328458dfefb);
                Style_6a1730c2b07846c9b6041cce22b4eafa.Setters.add(Setter_ab288d468ea44df892ae06552443fbab);
                Style_6a1730c2b07846c9b6041cce22b4eafa.Setters.add(Setter_2ec1b316c31e40259b4b5a1984769a47);
                Style_6a1730c2b07846c9b6041cce22b4eafa.Setters.add(Setter_c28692cd71994dc09ec6da2d363babf7);
                Style_6a1730c2b07846c9b6041cce22b4eafa.Setters.add(Setter_fb84d2e842d545648eab2f46275e55bb);
                Style_6a1730c2b07846c9b6041cce22b4eafa.Setters.add(Setter_9290ec738d09424b9f591078fa5a246c);
                Style_6a1730c2b07846c9b6041cce22b4eafa.Setters.add(Setter_ce33a3e7cc65419d89a8dbb42f688a29);
                Style_6a1730c2b07846c9b6041cce22b4eafa.Setters.add(Setter_6e07fe7283da410bb65e0af156e52768);


                ResourceDictionary_e2952fbb6abd42b1b96fd7a9f9e0086d.setItem("IntConverter", IntConverter_4f0fc029082642609e91ec4dc241a474);
                ResourceDictionary_e2952fbb6abd42b1b96fd7a9f9e0086d.setItem("DecConverter", DecConverter_6db006cb544a4003876d389f14bdfae6);
                ResourceDictionary_e2952fbb6abd42b1b96fd7a9f9e0086d.setItem("ToPolyLineConverter", ToPolyLineConverter_c14b95c2579c4e5299cfaf0c7edcea19);
                ResourceDictionary_e2952fbb6abd42b1b96fd7a9f9e0086d.setItem("ToPointsConverter", ToPointsConverter_ce6d938e10464443a40b6096cee0786c);
                ResourceDictionary_e2952fbb6abd42b1b96fd7a9f9e0086d.setItem("ToLinesConverter", ToLinesConverter_31a8341ee1254e968bdb1a86ad332bc9);
                ResourceDictionary_e2952fbb6abd42b1b96fd7a9f9e0086d.setItem("APLColorConverter", APLColorConverter_e6b5633b5c4244a49daba81b098a31f7);
                ResourceDictionary_e2952fbb6abd42b1b96fd7a9f9e0086d.setItem("APLColorCSSConverter", APLColorCSSConverter_30b973812cf24833a0a97d26f07de23f);
                ResourceDictionary_e2952fbb6abd42b1b96fd7a9f9e0086d.setItem("APLMultiColorConverter", APLMultiColorConverter_1af9045d90a1418788b2b4941be6fff0);
                ResourceDictionary_e2952fbb6abd42b1b96fd7a9f9e0086d.setItem("APLMultiColorCSSConverter", APLMultiColorCSSConverter_1c77884d08fd40ff83eaea70642020c5);
                ResourceDictionary_e2952fbb6abd42b1b96fd7a9f9e0086d.setItem("IndexInt32Converter", IndexInt32Converter_8933781ef9744154a0f0e12c38cc14e9);
                ResourceDictionary_e2952fbb6abd42b1b96fd7a9f9e0086d.setItem("IndexDoubleConverter", IndexDoubleConverter_6575379ad39d4a16ad09c42dd3761fe3);
                ResourceDictionary_e2952fbb6abd42b1b96fd7a9f9e0086d.setItem("IndexStringConverter", IndexStringConverter_5e2c536c49d34fcc9b01f1044165d56c);
                ResourceDictionary_e2952fbb6abd42b1b96fd7a9f9e0086d.setItem("IndexAPLColorConverter", IndexAPLColorConverter_c976d2edaf5b4a12bafa7adfc57371b4);
                ResourceDictionary_e2952fbb6abd42b1b96fd7a9f9e0086d.setItem("IndexAPLColourConverter", IndexAPLColourConverter_f6ad351210ce41ed9a212203d86cef16);
                ResourceDictionary_e2952fbb6abd42b1b96fd7a9f9e0086d.setItem("MathsIConverter", MathsIConverter_027ba51a91d844669f2b6dd4fe1ca9a9);
                ResourceDictionary_e2952fbb6abd42b1b96fd7a9f9e0086d.setItem("MathsDConverter", MathsDConverter_dbb664daa16346479bd0a94c4f1bb58e);
                ResourceDictionary_e2952fbb6abd42b1b96fd7a9f9e0086d.setItem("MathIConverter", MathIConverter_613539876bb14e13982b526a7a4b1c6d);
                ResourceDictionary_e2952fbb6abd42b1b96fd7a9f9e0086d.setItem("MathDConverter", MathDConverter_09043c9183924a1d8cb9bb2ffdac5adc);
                ResourceDictionary_e2952fbb6abd42b1b96fd7a9f9e0086d.setItem("Application", String_c1ae34d60a43493d8b929fd6930da12a);
                ResourceDictionary_e2952fbb6abd42b1b96fd7a9f9e0086d.setItem("Owner", String_3830f76b4f3c4b9aae768d2ee6e8ab69);
                ResourceDictionary_e2952fbb6abd42b1b96fd7a9f9e0086d.setItem("Company", String_fba55e27b0904e2bb4fe1814dc76e5ec);
                ResourceDictionary_e2952fbb6abd42b1b96fd7a9f9e0086d.setItem("Name", String_d70cd1ac903045f6951867e4631c489d);
                ResourceDictionary_e2952fbb6abd42b1b96fd7a9f9e0086d.setItem("Title", String_83dd6b32c41c45a48bf7aebfd5700270);
                ResourceDictionary_e2952fbb6abd42b1b96fd7a9f9e0086d.setItem("FavIcon", String_a984194d3e514a09bb81ca8a00ee75bd);
                ResourceDictionary_e2952fbb6abd42b1b96fd7a9f9e0086d.setItem("Port", String_7cd16769227a480cbd8b4b5d26c736eb);
                ResourceDictionary_e2952fbb6abd42b1b96fd7a9f9e0086d.setItem("Main", String_e45dc52e8e1c48e8a2723c3478abf7bc);
                ResourceDictionary_e2952fbb6abd42b1b96fd7a9f9e0086d.setItem("Base", String_20a0908420a8408c9bf3e2ce0841f179);
                ResourceDictionary_e2952fbb6abd42b1b96fd7a9f9e0086d.setItem("ConnectionType", String_67a6067df1e64503895bba5ebe3c32a4);
                ResourceDictionary_e2952fbb6abd42b1b96fd7a9f9e0086d.setItem("Namespace", String_ab831429303d40fc823bba4101186242);
                ResourceDictionary_e2952fbb6abd42b1b96fd7a9f9e0086d.setItem("APLFormStyle", Style_b78a3de1e1c84ea5863dc5b463b71ad3);
                ResourceDictionary_e2952fbb6abd42b1b96fd7a9f9e0086d.setItem("ButtonStyle1", Style_6a1730c2b07846c9b6041cce22b4eafa);

                this.Resources = ResourceDictionary_e2952fbb6abd42b1b96fd7a9f9e0086d;







            },
            accessVisualStateProperty_0efeb1ee91ba4e7fb4a607183778abe9: function (rootTargetObjectInstance) {
                return new (Bridge.GeneratorEnumerable$1(System.Tuple$3(Windows.UI.Xaml.DependencyObject,Windows.UI.Xaml.DependencyProperty,System.Nullable$1(System.Int32))))(Bridge.fn.bind(this, function (rootTargetObjectInstance) {
                    var $step = 0,
                        $jumpFromFinally,
                        $returnValue,
                        $async_e;

                    var $enumerator = new (Bridge.GeneratorEnumerator$1(System.Tuple$3(Windows.UI.Xaml.DependencyObject,Windows.UI.Xaml.DependencyProperty,System.Nullable$1(System.Int32))))(Bridge.fn.bind(this, function () {
                        try {
                            for (;;) {
                                switch ($step) {
                                    case 0: {
                                        return false;
                                    }
                                    default: {
                                        return false;
                                    }
                                }
                            }
                        } catch($async_e1) {
                            $async_e = System.Exception.create($async_e1);
                            throw $async_e;
                        }
                    }));
                    return $enumerator;
                }, arguments));
            },
            setVisualStateProperty_0efeb1ee91ba4e7fb4a607183778abe9: function (finalTargetInstance, value) {

                var finalTargetInstanceType = Bridge.getType(finalTargetInstance);
                var propertyDeclaringType = Bridge.Reflection.getMembers(finalTargetInstanceType, 16, 284, "Background").td;
                var propertyField = Bridge.Reflection.getMembers(propertyDeclaringType, 4, 284, "BackgroundProperty");
                var property = Bridge.cast(Bridge.Reflection.fieldAccess(propertyField, null), Windows.UI.Xaml.DependencyProperty);

                (finalTargetInstance).SetVisualStateValue(property, value);
            },
            setAnimationVisualStateProperty_0efeb1ee91ba4e7fb4a607183778abe9: function (finalTargetInstance, value) {

                var finalTargetInstanceType = Bridge.getType(finalTargetInstance);
                var propertyDeclaringType = Bridge.Reflection.getMembers(finalTargetInstanceType, 16, 284, "Background").td;
                var propertyField = Bridge.Reflection.getMembers(propertyDeclaringType, 4, 284, "BackgroundProperty");
                var property = Bridge.cast(Bridge.Reflection.fieldAccess(propertyField, null), Windows.UI.Xaml.DependencyProperty);

                (finalTargetInstance).SetAnimationValue(property, value);
            },
            setLocalVisualStateProperty_0efeb1ee91ba4e7fb4a607183778abe9: function (finalTargetInstance, value) {

                var finalTargetInstanceType = Bridge.getType(finalTargetInstance);
                var propertyDeclaringType = Bridge.Reflection.getMembers(finalTargetInstanceType, 16, 284, "Background").td;
                var propertyField = Bridge.Reflection.getMembers(propertyDeclaringType, 4, 284, "BackgroundProperty");
                var property = Bridge.cast(Bridge.Reflection.fieldAccess(propertyField, null), Windows.UI.Xaml.DependencyProperty);

                (finalTargetInstance).SetCurrentValue(property, value);
            },
            getVisualStateProperty_0efeb1ee91ba4e7fb4a607183778abe9: function (finalTargetInstance) {

                var finalTargetInstanceType = Bridge.getType(finalTargetInstance);
                var propertyDeclaringType = Bridge.Reflection.getMembers(finalTargetInstanceType, 16, 284, "Background").td;
                var propertyField = Bridge.Reflection.getMembers(propertyDeclaringType, 4, 284, "BackgroundProperty");
                var property = Bridge.cast(Bridge.Reflection.fieldAccess(propertyField, null), Windows.UI.Xaml.DependencyProperty);

                return finalTargetInstance.GetVisualStateValue(property);
            },
            accessVisualStateProperty_432128cd104b46ed8f7e8d441715639b: function (rootTargetObjectInstance) {
                return new (Bridge.GeneratorEnumerable$1(System.Tuple$3(Windows.UI.Xaml.DependencyObject,Windows.UI.Xaml.DependencyProperty,System.Nullable$1(System.Int32))))(Bridge.fn.bind(this, function (rootTargetObjectInstance) {
                    var $step = 0,
                        $jumpFromFinally,
                        $returnValue,
                        $async_e;

                    var $enumerator = new (Bridge.GeneratorEnumerator$1(System.Tuple$3(Windows.UI.Xaml.DependencyObject,Windows.UI.Xaml.DependencyProperty,System.Nullable$1(System.Int32))))(Bridge.fn.bind(this, function () {
                        try {
                            for (;;) {
                                switch ($step) {
                                    case 0: {
                                        return false;
                                    }
                                    default: {
                                        return false;
                                    }
                                }
                            }
                        } catch($async_e1) {
                            $async_e = System.Exception.create($async_e1);
                            throw $async_e;
                        }
                    }));
                    return $enumerator;
                }, arguments));
            },
            setVisualStateProperty_432128cd104b46ed8f7e8d441715639b: function (finalTargetInstance, value) {

                var finalTargetInstanceType = Bridge.getType(finalTargetInstance);
                var propertyDeclaringType = Bridge.Reflection.getMembers(finalTargetInstanceType, 16, 284, "IsHitTestVisible").td;
                var propertyField = Bridge.Reflection.getMembers(propertyDeclaringType, 4, 284, "IsHitTestVisibleProperty");
                var property = Bridge.cast(Bridge.Reflection.fieldAccess(propertyField, null), Windows.UI.Xaml.DependencyProperty);

                (finalTargetInstance).SetVisualStateValue(property, value);
            },
            setAnimationVisualStateProperty_432128cd104b46ed8f7e8d441715639b: function (finalTargetInstance, value) {

                var finalTargetInstanceType = Bridge.getType(finalTargetInstance);
                var propertyDeclaringType = Bridge.Reflection.getMembers(finalTargetInstanceType, 16, 284, "IsHitTestVisible").td;
                var propertyField = Bridge.Reflection.getMembers(propertyDeclaringType, 4, 284, "IsHitTestVisibleProperty");
                var property = Bridge.cast(Bridge.Reflection.fieldAccess(propertyField, null), Windows.UI.Xaml.DependencyProperty);

                (finalTargetInstance).SetAnimationValue(property, value);
            },
            setLocalVisualStateProperty_432128cd104b46ed8f7e8d441715639b: function (finalTargetInstance, value) {

                var finalTargetInstanceType = Bridge.getType(finalTargetInstance);
                var propertyDeclaringType = Bridge.Reflection.getMembers(finalTargetInstanceType, 16, 284, "IsHitTestVisible").td;
                var propertyField = Bridge.Reflection.getMembers(propertyDeclaringType, 4, 284, "IsHitTestVisibleProperty");
                var property = Bridge.cast(Bridge.Reflection.fieldAccess(propertyField, null), Windows.UI.Xaml.DependencyProperty);

                (finalTargetInstance).SetCurrentValue(property, value);
            },
            getVisualStateProperty_432128cd104b46ed8f7e8d441715639b: function (finalTargetInstance) {

                var finalTargetInstanceType = Bridge.getType(finalTargetInstance);
                var propertyDeclaringType = Bridge.Reflection.getMembers(finalTargetInstanceType, 16, 284, "IsHitTestVisible").td;
                var propertyField = Bridge.Reflection.getMembers(propertyDeclaringType, 4, 284, "IsHitTestVisibleProperty");
                var property = Bridge.cast(Bridge.Reflection.fieldAccess(propertyField, null), Windows.UI.Xaml.DependencyProperty);

                return finalTargetInstance.GetVisualStateValue(property);
            },
            accessVisualStateProperty_3a3e2022cc954baeb81d6f3ec01c449f: function (rootTargetObjectInstance) {
                return new (Bridge.GeneratorEnumerable$1(System.Tuple$3(Windows.UI.Xaml.DependencyObject,Windows.UI.Xaml.DependencyProperty,System.Nullable$1(System.Int32))))(Bridge.fn.bind(this, function (rootTargetObjectInstance) {
                    var $step = 0,
                        $jumpFromFinally,
                        $returnValue,
                        $async_e;

                    var $enumerator = new (Bridge.GeneratorEnumerator$1(System.Tuple$3(Windows.UI.Xaml.DependencyObject,Windows.UI.Xaml.DependencyProperty,System.Nullable$1(System.Int32))))(Bridge.fn.bind(this, function () {
                        try {
                            for (;;) {
                                switch ($step) {
                                    case 0: {
                                        return false;
                                    }
                                    default: {
                                        return false;
                                    }
                                }
                            }
                        } catch($async_e1) {
                            $async_e = System.Exception.create($async_e1);
                            throw $async_e;
                        }
                    }));
                    return $enumerator;
                }, arguments));
            },
            setVisualStateProperty_3a3e2022cc954baeb81d6f3ec01c449f: function (finalTargetInstance, value) {

                var finalTargetInstanceType = Bridge.getType(finalTargetInstance);
                var propertyDeclaringType = Bridge.Reflection.getMembers(finalTargetInstanceType, 16, 284, "Background").td;
                var propertyField = Bridge.Reflection.getMembers(propertyDeclaringType, 4, 284, "BackgroundProperty");
                var property = Bridge.cast(Bridge.Reflection.fieldAccess(propertyField, null), Windows.UI.Xaml.DependencyProperty);

                (finalTargetInstance).SetVisualStateValue(property, value);
            },
            setAnimationVisualStateProperty_3a3e2022cc954baeb81d6f3ec01c449f: function (finalTargetInstance, value) {

                var finalTargetInstanceType = Bridge.getType(finalTargetInstance);
                var propertyDeclaringType = Bridge.Reflection.getMembers(finalTargetInstanceType, 16, 284, "Background").td;
                var propertyField = Bridge.Reflection.getMembers(propertyDeclaringType, 4, 284, "BackgroundProperty");
                var property = Bridge.cast(Bridge.Reflection.fieldAccess(propertyField, null), Windows.UI.Xaml.DependencyProperty);

                (finalTargetInstance).SetAnimationValue(property, value);
            },
            setLocalVisualStateProperty_3a3e2022cc954baeb81d6f3ec01c449f: function (finalTargetInstance, value) {

                var finalTargetInstanceType = Bridge.getType(finalTargetInstance);
                var propertyDeclaringType = Bridge.Reflection.getMembers(finalTargetInstanceType, 16, 284, "Background").td;
                var propertyField = Bridge.Reflection.getMembers(propertyDeclaringType, 4, 284, "BackgroundProperty");
                var property = Bridge.cast(Bridge.Reflection.fieldAccess(propertyField, null), Windows.UI.Xaml.DependencyProperty);

                (finalTargetInstance).SetCurrentValue(property, value);
            },
            getVisualStateProperty_3a3e2022cc954baeb81d6f3ec01c449f: function (finalTargetInstance) {

                var finalTargetInstanceType = Bridge.getType(finalTargetInstance);
                var propertyDeclaringType = Bridge.Reflection.getMembers(finalTargetInstanceType, 16, 284, "Background").td;
                var propertyField = Bridge.Reflection.getMembers(propertyDeclaringType, 4, 284, "BackgroundProperty");
                var property = Bridge.cast(Bridge.Reflection.fieldAccess(propertyField, null), Windows.UI.Xaml.DependencyProperty);

                return finalTargetInstance.GetVisualStateValue(property);
            },
            accessVisualStateProperty_0644eb09043444188059ca9517a15f22: function (rootTargetObjectInstance) {
                return new (Bridge.GeneratorEnumerable$1(System.Tuple$3(Windows.UI.Xaml.DependencyObject,Windows.UI.Xaml.DependencyProperty,System.Nullable$1(System.Int32))))(Bridge.fn.bind(this, function (rootTargetObjectInstance) {
                    var $step = 0,
                        $jumpFromFinally,
                        $returnValue,
                        $async_e;

                    var $enumerator = new (Bridge.GeneratorEnumerator$1(System.Tuple$3(Windows.UI.Xaml.DependencyObject,Windows.UI.Xaml.DependencyProperty,System.Nullable$1(System.Int32))))(Bridge.fn.bind(this, function () {
                        try {
                            for (;;) {
                                switch ($step) {
                                    case 0: {
                                        return false;
                                    }
                                    default: {
                                        return false;
                                    }
                                }
                            }
                        } catch($async_e1) {
                            $async_e = System.Exception.create($async_e1);
                            throw $async_e;
                        }
                    }));
                    return $enumerator;
                }, arguments));
            },
            setVisualStateProperty_0644eb09043444188059ca9517a15f22: function (finalTargetInstance, value) {

                var finalTargetInstanceType = Bridge.getType(finalTargetInstance);
                var propertyDeclaringType = Bridge.Reflection.getMembers(finalTargetInstanceType, 16, 284, "Background").td;
                var propertyField = Bridge.Reflection.getMembers(propertyDeclaringType, 4, 284, "BackgroundProperty");
                var property = Bridge.cast(Bridge.Reflection.fieldAccess(propertyField, null), Windows.UI.Xaml.DependencyProperty);

                (finalTargetInstance).SetVisualStateValue(property, value);
            },
            setAnimationVisualStateProperty_0644eb09043444188059ca9517a15f22: function (finalTargetInstance, value) {

                var finalTargetInstanceType = Bridge.getType(finalTargetInstance);
                var propertyDeclaringType = Bridge.Reflection.getMembers(finalTargetInstanceType, 16, 284, "Background").td;
                var propertyField = Bridge.Reflection.getMembers(propertyDeclaringType, 4, 284, "BackgroundProperty");
                var property = Bridge.cast(Bridge.Reflection.fieldAccess(propertyField, null), Windows.UI.Xaml.DependencyProperty);

                (finalTargetInstance).SetAnimationValue(property, value);
            },
            setLocalVisualStateProperty_0644eb09043444188059ca9517a15f22: function (finalTargetInstance, value) {

                var finalTargetInstanceType = Bridge.getType(finalTargetInstance);
                var propertyDeclaringType = Bridge.Reflection.getMembers(finalTargetInstanceType, 16, 284, "Background").td;
                var propertyField = Bridge.Reflection.getMembers(propertyDeclaringType, 4, 284, "BackgroundProperty");
                var property = Bridge.cast(Bridge.Reflection.fieldAccess(propertyField, null), Windows.UI.Xaml.DependencyProperty);

                (finalTargetInstance).SetCurrentValue(property, value);
            },
            getVisualStateProperty_0644eb09043444188059ca9517a15f22: function (finalTargetInstance) {

                var finalTargetInstanceType = Bridge.getType(finalTargetInstance);
                var propertyDeclaringType = Bridge.Reflection.getMembers(finalTargetInstanceType, 16, 284, "Background").td;
                var propertyField = Bridge.Reflection.getMembers(propertyDeclaringType, 4, 284, "BackgroundProperty");
                var property = Bridge.cast(Bridge.Reflection.fieldAccess(propertyField, null), Windows.UI.Xaml.DependencyProperty);

                return finalTargetInstance.GetVisualStateValue(property);
            },
            accessVisualStateProperty_0371403c000847ad8936836e5ce40cf3: function (rootTargetObjectInstance) {
                return new (Bridge.GeneratorEnumerable$1(System.Tuple$3(Windows.UI.Xaml.DependencyObject,Windows.UI.Xaml.DependencyProperty,System.Nullable$1(System.Int32))))(Bridge.fn.bind(this, function (rootTargetObjectInstance) {
                    var $step = 0,
                        $jumpFromFinally,
                        $returnValue,
                        $async_e;

                    var $enumerator = new (Bridge.GeneratorEnumerator$1(System.Tuple$3(Windows.UI.Xaml.DependencyObject,Windows.UI.Xaml.DependencyProperty,System.Nullable$1(System.Int32))))(Bridge.fn.bind(this, function () {
                        try {
                            for (;;) {
                                switch ($step) {
                                    case 0: {
                                        return false;
                                    }
                                    default: {
                                        return false;
                                    }
                                }
                            }
                        } catch($async_e1) {
                            $async_e = System.Exception.create($async_e1);
                            throw $async_e;
                        }
                    }));
                    return $enumerator;
                }, arguments));
            },
            setVisualStateProperty_0371403c000847ad8936836e5ce40cf3: function (finalTargetInstance, value) {

                var finalTargetInstanceType = Bridge.getType(finalTargetInstance);
                var propertyDeclaringType = Bridge.Reflection.getMembers(finalTargetInstanceType, 16, 284, "Background").td;
                var propertyField = Bridge.Reflection.getMembers(propertyDeclaringType, 4, 284, "BackgroundProperty");
                var property = Bridge.cast(Bridge.Reflection.fieldAccess(propertyField, null), Windows.UI.Xaml.DependencyProperty);

                (finalTargetInstance).SetVisualStateValue(property, value);
            },
            setAnimationVisualStateProperty_0371403c000847ad8936836e5ce40cf3: function (finalTargetInstance, value) {

                var finalTargetInstanceType = Bridge.getType(finalTargetInstance);
                var propertyDeclaringType = Bridge.Reflection.getMembers(finalTargetInstanceType, 16, 284, "Background").td;
                var propertyField = Bridge.Reflection.getMembers(propertyDeclaringType, 4, 284, "BackgroundProperty");
                var property = Bridge.cast(Bridge.Reflection.fieldAccess(propertyField, null), Windows.UI.Xaml.DependencyProperty);

                (finalTargetInstance).SetAnimationValue(property, value);
            },
            setLocalVisualStateProperty_0371403c000847ad8936836e5ce40cf3: function (finalTargetInstance, value) {

                var finalTargetInstanceType = Bridge.getType(finalTargetInstance);
                var propertyDeclaringType = Bridge.Reflection.getMembers(finalTargetInstanceType, 16, 284, "Background").td;
                var propertyField = Bridge.Reflection.getMembers(propertyDeclaringType, 4, 284, "BackgroundProperty");
                var property = Bridge.cast(Bridge.Reflection.fieldAccess(propertyField, null), Windows.UI.Xaml.DependencyProperty);

                (finalTargetInstance).SetCurrentValue(property, value);
            },
            getVisualStateProperty_0371403c000847ad8936836e5ce40cf3: function (finalTargetInstance) {

                var finalTargetInstanceType = Bridge.getType(finalTargetInstance);
                var propertyDeclaringType = Bridge.Reflection.getMembers(finalTargetInstanceType, 16, 284, "Background").td;
                var propertyField = Bridge.Reflection.getMembers(propertyDeclaringType, 4, 284, "BackgroundProperty");
                var property = Bridge.cast(Bridge.Reflection.fieldAccess(propertyField, null), Windows.UI.Xaml.DependencyProperty);

                return finalTargetInstance.GetVisualStateValue(property);
            }
        }
    });

    Bridge.define("QWC.MainPage", {
        inherits: [Windows.UI.Xaml.Controls.Page],
        fields: {
            filesReady: null,
            webSocketReady: null,
            webSocket: null,
            directwebSocket: null,
            connection: null,
            connectionport: null,
            AllReady: false,
            SetupCompleteRun: false,
            QWCGrid: null,
            QWCIcons: null,
            QWCHidden: null,
            QWCSideBars: null,
            Top: null,
            _contentLoaded: false
        },
        props: {
            FilesReady: {
                get: function () {
                    return this.filesReady.task;
                }
            },
            WebSocketReady: {
                get: function () {
                    return this.webSocketReady.task;
                }
            }
        },
        ctors: {
            init: function () {
                this.filesReady = new System.Threading.Tasks.TaskCompletionSource();
                this.webSocketReady = new System.Threading.Tasks.TaskCompletionSource();
                this.connection = "";
                this.connectionport = "";
                this.AllReady = false;
                this.SetupCompleteRun = false;
            },
            ctor: function () {
                this.$initialize();
                Windows.UI.Xaml.Controls.Page.ctor.call(this);
                this.RunRestMain();
            }
        },
        methods: {
            AddFileLoading: function () {
                mjh_filesloaded.value += 1;
                var FilesLoaded = System.Nullable.getValue(Bridge.cast(Bridge.unbox(mjh_filesloaded.value, System.Int32), System.Int32));
                var TotalFilesToBeLoaded = System.Nullable.getValue(Bridge.cast(Bridge.unbox(mjh_filesloaded.total, System.Int32), System.Int32));
                if (FilesLoaded === TotalFilesToBeLoaded) {
                    var x = this.filesReady.trySetResult(true);
                }
                ;
            },
            CheckFileLoading: function () {
                var FilesLoaded = System.Nullable.getValue(Bridge.cast(Bridge.unbox(mjh_filesloaded.value, System.Int32), System.Int32));
                var TotalFilesToBeLoaded = System.Nullable.getValue(Bridge.cast(Bridge.unbox(mjh_filesloaded.total, System.Int32), System.Int32));
                if (FilesLoaded === TotalFilesToBeLoaded) {
                    var x = this.filesReady.trySetResult(true);
                }
                ;
            },
            EndCustomCSS: function () {
                var runflg = System.Nullable.getValue(Bridge.cast(Bridge.unbox(('undefined' !=typeof ej &&  'undefined' != typeof ej.base), System.Boolean), System.Boolean));
                if (runflg) {
                    ej.base.enableRipple(false);
                }
            },
            RunRestMain: function () {
                window.addEventListener('beforeunload', Bridge.fn.cacheBind(this, this.OnBeforeUnload));
                Windows.UI.Xaml.Application.Current.Resources.setItem("MaxSerialNo", Bridge.box(0, System.Int32));
                Windows.UI.Xaml.Application.Current.Resources.setItem("FrameworkElement", this);
                Windows.UI.Xaml.Application.Current.Resources.setItem("AllReady", Bridge.box(this.AllReady, System.Boolean, System.Boolean.toString));
                var original = System.Windows.Browser.HtmlPage.Document.DocumentUri.getOriginalString();
                Windows.UI.Xaml.Application.Current.Resources.setItem("OriginalURL", original);
                var connection;
                var apps = APLExtension.Utils.GetAppsResource("QWC", "webdetails.html");
                connection = APLExtension.Utils.GetAppResource(apps, "Connection");
                if (0 === connection.length) {
                    connection = Bridge.cast(Windows.UI.Xaml.Application.Current.TryFindResource("Connection"), System.String);
                }
                var connectiontype = APLExtension.Utils.GetAppResource(apps, "ConnectionType");
                if (0 === connectiontype.length) {
                    connectiontype = Bridge.cast(Windows.UI.Xaml.Application.Current.TryFindResource("ConnectionType"), System.String);
                }
                var uploadhost = APLExtension.Utils.GetAppResource(apps, "UploadHost");
                if (null == uploadhost || 0 === uploadhost.length) {
                    uploadhost = Bridge.cast(Windows.UI.Xaml.Application.Current.TryFindResource("UploadHost"), System.String);
                    if (null == uploadhost || 0 === uploadhost.length) {
                        uploadhost = "localhost";
                    }
                }
                Windows.UI.Xaml.Application.Current.Resources.setItem("UploadHost", uploadhost);
                var uploadport = APLExtension.Utils.GetAppResource(apps, "UploadPort");
                if (null == uploadport || 0 === uploadport.length) {
                    uploadport = Bridge.cast(Windows.UI.Xaml.Application.Current.TryFindResource("UploadPort"), System.String);
                    if (null == uploadport || 0 === uploadport.length) {
                        uploadport = "1234";
                    }
                }
                Windows.UI.Xaml.Application.Current.Resources.setItem("UploadPort", uploadport);
                var uploadsecure = APLExtension.Utils.GetAppResource(apps, "UploadSecure");
                if (null == uploadsecure || 0 === uploadsecure.length) {
                    uploadsecure = Bridge.cast(Windows.UI.Xaml.Application.Current.TryFindResource("UploadSecure"), System.String);
                    if (null == uploadsecure || 0 === uploadsecure.length) {
                        uploadsecure = "0";
                    }
                }
                Windows.UI.Xaml.Application.Current.Resources.setItem("UploadSecure", uploadsecure);
                var name = APLExtension.Utils.GetAppResource(apps, "Name");
                if (0 === name.length) {
                    name = Bridge.cast(Windows.UI.Xaml.Application.Current.Resources.getItem("Name"), System.String);
                }
                var WSname = APLExtension.Utils.GetAppResource(apps, "WSName");
                if (0 === WSname.length) {
                    WSname = Bridge.cast(Windows.UI.Xaml.Application.Current.TryFindResource("WSName"), System.String);
                }
                var port = APLExtension.Utils.GetAppResource(apps, "Port");
                if (0 === port.length) {
                    port = Bridge.cast(Windows.UI.Xaml.Application.Current.TryFindResource("Port"), System.String);
                }
                if (null == WSname) {
                    WSname = "WS";
                }
                WSname = WSname.trim();
                if (Bridge.referenceEquals("", WSname)) {
                    WSname = "WS";
                }
                if (Bridge.referenceEquals(WSname.toUpperCase(), "NONE")) {
                    WSname = "";
                }
                if (null == connection) {
                    connection = "";
                }
                connection = connection.trim();
                if (null == connectiontype) {
                    connectiontype = "";
                }
                connectiontype = connectiontype.trim();
                if (Bridge.referenceEquals("", connectiontype)) {
                    connectiontype = "Direct";
                }
                if (Bridge.referenceEquals("", connection)) {
                    if (Bridge.referenceEquals("http", System.Windows.Browser.HtmlPage.Document.DocumentUri.getProtocol())) {
                        connection = System.Windows.Browser.HtmlPage.Document.DocumentUri.getHostName();
                    } else {
                        connection = "localhost";
                    }
                }
                var appname = APLExtension.Utils.GetAppResource(apps, "AppName");
                if (0 === appname.length) {
                    appname = Bridge.cast(Windows.UI.Xaml.Application.Current.TryFindResource("AppName"), System.String);
                }
                if (null == appname) {
                    appname = name;
                }
                if (Bridge.referenceEquals("", appname)) {
                    appname = name;
                }
                Windows.UI.Xaml.Application.Current.Resources.setItem("AppName", appname);
                if (Bridge.referenceEquals("Direct", connectiontype)) {
                    if (null == port) {
                        port = "";
                    }
                    var uri = Bridge.cast(document.location.search, System.String);
                    if (0 !== uri.length) {
                        var p = "";
                        for (var i = 0; i < uri.length; i = (i + 1) | 0) {
                            if (63 !== uri.charCodeAt(i)) {
                                if (48 === uri.charCodeAt(i) || 49 === uri.charCodeAt(i) || 50 === uri.charCodeAt(i) || 51 === uri.charCodeAt(i) || 52 === uri.charCodeAt(i) || 53 === uri.charCodeAt(i) || 54 === uri.charCodeAt(i) || 55 === uri.charCodeAt(i) || 56 === uri.charCodeAt(i) || 57 === uri.charCodeAt(i)) {
                                    p = (p || "") + String.fromCharCode(uri.charCodeAt(i));
                                } else {
                                    break;
                                }
                            }
                        }
                        if (0 !== p.length) {
                            port = p;
                        }
                    }
                    if (Bridge.referenceEquals("", port)) {
                        port = Bridge.toString(System.Windows.Browser.HtmlPage.Document.DocumentUri.getPort());
                    }
                    connection = (connection || "") + ((":" + (port || "") + "/" + (name || "") + "/") || "");
                } else {
                    if (0 !== connection.length) {
                        this.connectionport = APLExtension.Utils.GetAppResource(apps, "ConnectionPort");
                        if (this.connectionport == null || 0 === this.connectionport.length) {
                            this.connectionport = Bridge.cast(Windows.UI.Xaml.Application.Current.TryFindResource("ConnectionPort"), System.String);
                        }
                        if (this.connectionport != null && 0 !== this.connectionport.length) {
                            connection = (connection || "") + ((":" + (this.connectionport || "")) || "");
                        }
                    }
                    connection = (connection || "") + (("/" + (WSname || "")) || "");
                    if (0 !== WSname.length) {
                        connection = (connection || "") + "/";
                    }
                }
                var secureconnection = APLExtension.Utils.GetAppResource(apps, "SecureConnection");
                if (null == secureconnection || 0 === secureconnection.length) {
                    secureconnection = Bridge.cast(Windows.UI.Xaml.Application.Current.TryFindResource("SecureConnection"), System.String);
                    if (null == secureconnection || 0 === secureconnection.length) {
                        secureconnection = "0";
                    }
                }
                Windows.UI.Xaml.Application.Current.Resources.setItem("SecureConnection", secureconnection);
                if (Bridge.referenceEquals(secureconnection, "1")) {
                    connection = "wss://" + (connection || "");
                } else {
                    connection = "ws://" + (connection || "");
                }
                var _WSInternals = Bridge.as(APLExtension.APL.MakeInstance("DataBinding", "WSInternals", "WSInternals", this), DataBinding.WSInternals);
                var _qwc_Root = Bridge.as(APLExtension.APL.MakeInstance("DataBinding", "qwc_Root", "qwc_Root", this), DataBinding.qwc_Root);
                var rnd = new System.Random.ctor();
                var rnds = Bridge.toString(rnd.Next());
                this.webSocket = new CSHTML5.Extensions.WebSockets.WebSocket((connection || "") + "?hash=" + (rnds || ""));
                this.directwebSocket = new CSHTML5.Extensions.WebSockets.WebSocket((connection || "") + "?hash=" + (rnds || ""));
                Windows.UI.Xaml.Application.Current.Resources.setItem("WebSocket", this.webSocket);
                Windows.UI.Xaml.Application.Current.Resources.setItem("DirectWebSocket", this.directwebSocket);
                var xstring;
                var d = "";
                this.webSocket.addOnMessage(Bridge.fn.bind(this, function (s, e) {
                    var $step = 0,
                        $task1, 
                        $taskResult1, 
                        $jumpFromFinally, 
                        data, 
                        ds, 
                        trans, 
                        fullfont, 
                        f, 
                        elem, 
                        cl, 
                        o, 
                        assembly, 
                        type, 
                        ob, 
                        cl1, 
                        obj, 
                        assembly1, 
                        cl2, 
                        obj1, 
                        cla, 
                        method, 
                        $arguments, 
                        assembly2, 
                        cl3, 
                        obj2, 
                        cla1, 
                        method1, 
                        $arguments1, 
                        typecl, 
                        method11, 
                        $arguments2, 
                        NQresult, 
                        obj3, 
                        assembly3, 
                        type1, 
                        method2, 
                        $asyncBody = Bridge.fn.bind(this, function () {
                            for (;;) {
                                $step = System.Array.min([0,1,2,3], $step);
                                switch ($step) {
                                    case 0: {
                                        if (this.SetupCompleteRun) {
                                            $step = 1;
                                            continue;
                                        } 
                                        $step = 3;
                                        continue;
                                    }
                                    case 1: {
                                        this.SetupCompleteRun = false;
                                        this.CheckFileLoading();
                                        $task1 = this.FilesReady;
                                        $step = 2;
                                        if ($task1.isCompleted()) {
                                            continue;
                                        }
                                        $task1.continue($asyncBody);
                                        return;
                                    }
                                    case 2: {
                                        $taskResult1 = $task1.getAwaitedResult();
                                        this.EndCustomCSS();
                                        $step = 3;
                                        continue;
                                    }
                                    case 3: {
                                        data = APLExtension.TD.Split$1(e.Data, APLExtension.TD.delims5);
                                        for (var i1 = 0; i1 < data.length; i1 = (i1 + 1) | 0) {
                                            ds = APLExtension.TD.ToTransferString(data[System.Array.index(i1, data)]);
                                            trans = ds.Trans;
                                            if (Bridge.referenceEquals(ds.Action, "WaitForQueue")) {
                                                this.webSocket.Send(data[System.Array.index(i1, data)]);
                                            } else if (Bridge.referenceEquals(ds.Action, "MJH_CloseServer")) {
                                                this.webSocket.Send(data[System.Array.index(i1, data)]);
                                            } else if (Bridge.referenceEquals(ds.Action, "Ping")) {
                                                this.webSocket.Send(data[System.Array.index(i1, data)]);
                                            } else if (Bridge.referenceEquals(ds.Action, "Loaded")) {
                                                Windows.UI.Xaml.Application.Current.Resources.setItem("Index", ds.Data);
                                                this.webSocketReady.setResult(true);
                                                _WSInternals.Status = "WebSocket Opened ";
                                                this.AllReady = true;
                                                Windows.UI.Xaml.Application.Current.Resources.setItem("AllReady", Bridge.box(this.AllReady, System.Boolean, System.Boolean.toString));
                                                this.InitializeComponent();
                                                this.MakeWinSize(_qwc_Root, _WSInternals);
                                                _qwc_Root.NotifyPropertyChanged("FontList");
                                                _qwc_Root.NotifyPropertyChanged("FontFamily");
                                                _qwc_Root.NotifyPropertyChanged("Caption");
                                                _qwc_Root.NotifyPropertyChanged("URL");
                                                _qwc_Root.NotifyPropertyChanged("URLS");
                                                _qwc_Root.NotifyPropertyChanged("Captions");
                                                loadFont("APL385","app-cshtml5/res/QWC/fonts/apl385-webfont.woff");
                                                fullfont = function (_o1) {
                                                    _o1.add("APL385");
                                                    _o1.add("Andal\u00e9 Mono");
                                                    _o1.add("Arial");
                                                    _o1.add("Arial Black");
                                                    _o1.add("Arial Narrow");
                                                    _o1.add("Arial Rounded MT Bold");
                                                    _o1.add("Baskerville");
                                                    _o1.add("Bodoni 72");
                                                    _o1.add("Bodoni MT");
                                                    _o1.add("Bradley Hand");
                                                    _o1.add("Brush Script MT");
                                                    _o1.add("Calibri");
                                                    _o1.add("Calisto MT");
                                                    _o1.add("Cambria");
                                                    _o1.add("Candara");
                                                    _o1.add("Century Gothic");
                                                    _o1.add("Comic Sans MS");
                                                    _o1.add("Consolas");
                                                    _o1.add("Copperplate Gothic");
                                                    _o1.add("Courier");
                                                    _o1.add("Courier New");
                                                    _o1.add("Dejavu Sans");
                                                    _o1.add("Didot");
                                                    _o1.add("Franklin Gothic");
                                                    _o1.add("Garamond");
                                                    _o1.add("Georgia");
                                                    _o1.add("Gill Sans");
                                                    _o1.add("Goudy Old Style");
                                                    _o1.add("Helvetica");
                                                    _o1.add("Helvetica Neu");
                                                    _o1.add("Impact");
                                                    _o1.add("Lucida");
                                                    _o1.add("Lucida Bright");
                                                    _o1.add("Lucida Handwriting");
                                                    _o1.add("Lucida Sans");
                                                    _o1.add("Luminari");
                                                    _o1.add("Microsoft Sans Serif");
                                                    _o1.add("Monaco");
                                                    _o1.add("Optima");
                                                    _o1.add("Palatino");
                                                    _o1.add("Perpetua");
                                                    _o1.add("Rage");
                                                    _o1.add("Rockwell");
                                                    _o1.add("Script MT");
                                                    _o1.add("Segoe UI");
                                                    _o1.add("Segoe script");
                                                    _o1.add("Snell Roundhand");
                                                    _o1.add("Tahoma");
                                                    _o1.add("Times New Roman");
                                                    _o1.add("Trebuchet MS");
                                                    _o1.add("Verdana");
                                                    return _o1;
                                                }(new (System.Collections.Generic.List$1(System.String)).ctor());
                                                _qwc_Root.MJH_FontList_Shape[System.Array.index(0, _qwc_Root.MJH_FontList_Shape)] = 51;
                                                _qwc_Root.MJH_FontList_Shape[System.Array.index(1, _qwc_Root.MJH_FontList_Shape)] = 8;
                                                _qwc_Root.MJH_FontFamily_Shape = 51;
                                                f = new (System.Collections.Generic.List$1(System.Collections.Generic.List$1(APLExtension.APLItem))).ctor();
                                                for (var r = 0; r < 51; r = (r + 1) | 0) {
                                                    f.add(new (System.Collections.Generic.List$1(APLExtension.APLItem)).ctor());
                                                    f.getItem(r).add(new APLExtension.APLItem.$ctor9(fullfont.getItem(r)));
                                                    f.getItem(r).add(new APLExtension.APLItem.$ctor7(0));
                                                    f.getItem(r).add(new APLExtension.APLItem.$ctor7(0));
                                                    f.getItem(r).add(new APLExtension.APLItem.$ctor7(0));
                                                    f.getItem(r).add(new APLExtension.APLItem.$ctor7(0));
                                                    f.getItem(r).add(new APLExtension.APLItem.$ctor7(0));
                                                    f.getItem(r).add(new APLExtension.APLItem.$ctor7(0));
                                                    f.getItem(r).add(new APLExtension.APLItem.$ctor7(0));
                                                }
                                                _qwc_Root.FontList = f;
                                                _qwc_Root.FontFamily = function (_o2) {
                                                    _o2.add("APL385");
                                                    _o2.add("Andal\u00e9 Mono, monospace");
                                                    _o2.add("Arial, Helvetica Neue, Helvetica, sans-serif");
                                                    _o2.add("Arial Black, Arial Bold, Gadget, sans-serif");
                                                    _o2.add("Arial Narrow, Arial, sans-serif");
                                                    _o2.add("Arial Rounded MT Bold, Helvetica Rounded, Arial, sans-serif");
                                                    _o2.add("Baskerville, Baskerville Old Face, Garamond, Times New Roman, serif");
                                                    _o2.add("Bodoni 72, Bodoni MT, Didot, Didot LT STD, Hoefler Text, Garamond, Times New Roman, serif");
                                                    _o2.add("Bodoni MT, Bodoni 72, Didot, Didot LT STD, Hoefler Text, Garamond, Times New Roman, serif");
                                                    _o2.add("Bradley Hand, cursive");
                                                    _o2.add("Brush Script MT, cursive");
                                                    _o2.add("Calibri, Candara, Segoe, Segoe UI, Optima, Arial, sans-serif");
                                                    _o2.add("Calisto MT, Bookman Old Style, Bookman, Goudy Old Style, Garamond, Hoefler Text, Bitstream Charter, Georgia, serif");
                                                    _o2.add("Cambria, Georgia, serif");
                                                    _o2.add("Candara, Calibri, Segoe, Segoe UI, Optima, Arial, sans-serif");
                                                    _o2.add("Century Gothic, CenturyGothic, AppleGothic, sans-serif");
                                                    _o2.add("Comic Sans MS, cursive");
                                                    _o2.add("Consolas, monaco, monospace");
                                                    _o2.add("Copperplate Gothic, Copperplate Gothic Light, fantasy");
                                                    _o2.add("Courier, monospace");
                                                    _o2.add("Courier New, Courier, Lucida Sans Typewriter, Lucida Typewriter, monospace");
                                                    _o2.add("Dejavu Sans, Arial, Verdana, sans-serif");
                                                    _o2.add("Didot, Didot LT STD, Hoefler Text, Garamond, Calisto MT, Times New Roman, serif");
                                                    _o2.add("Franklin Gothic, Arial Bold, Arial, sans-serif");
                                                    _o2.add("Garamond, Baskerville, Baskerville Old Face, Hoefler Text, Times New Roman, serif");
                                                    _o2.add("Georgia, Times, Times New Roman, serif");
                                                    _o2.add("Gill Sans, Gill Sans MT, Calibri, sans-serif");
                                                    _o2.add("Goudy Old Style, Garamond, Big Caslon, Times New Roman, serif");
                                                    _o2.add("Helvetica, Helvetica Neu, Arial, sans-serif.");
                                                    _o2.add("Helvetica Neu, Helvetica, Arial, sans-serif.");
                                                    _o2.add("Impact, Charcoal, Helvetica Inserat, Bitstream Vera Sans Bold, Arial Black, sans-serif.");
                                                    _o2.add("Lucida, monospace");
                                                    _o2.add("Lucida Bright, Georgia, serif.");
                                                    _o2.add("Lucida Handwriting, cursive");
                                                    _o2.add("Lucida Sans, Helvetica, Arial, sans-serif.");
                                                    _o2.add("Luminari, fantasy");
                                                    _o2.add("Microsoft Sans Serif, sans-serif.");
                                                    _o2.add("Monaco, monospace");
                                                    _o2.add("Optima, Segoe, Segoe UI, Candara, Calibri, Arial, sans-serif.");
                                                    _o2.add("Palatino, Palatino Linotype, Palatino LT STD, Book Antiqua, Georgia, serif.");
                                                    _o2.add("Perpetua, Baskerville, Big Caslon, Palatino Linotype, Palatino, serif.");
                                                    _o2.add("Rage, cursive");
                                                    _o2.add("Rockwell, Courier Bold, Courier, Georgia, Times, Times New Roman, serif.");
                                                    _o2.add("Script MT, cursive");
                                                    _o2.add("Segoe UI, Frutiger, Dejavu Sans, Helvetica Neue, Arial, sans-serif.");
                                                    _o2.add("Segoe script, cursive");
                                                    _o2.add("Snell Roundhand, cursive");
                                                    _o2.add("Tahoma, Verdana, Segoe, sans-serif.");
                                                    _o2.add("Times New Roman, Georgia, serif;");
                                                    _o2.add("Trebuchet MS, Lucida Grande, Lucida Sans Unicode, Lucida Sans, sans-serif.");
                                                    _o2.add("Verdana, Geneva, sans-serif.");
                                                    return _o2;
                                                }(new (System.Collections.Generic.List$1(System.String)).ctor());
                                                _qwc_Root.NotifyPropertyChanged("FontList");
                                                _qwc_Root.NotifyPropertyChanged("FontFamily");
                                                xstring = new APLExtension.TransferString();
                                                xstring.Type = "SetupComplete";
                                                this.SetupCompleteRun = true;
                                                d = APLExtension.TD.FromTransferString(xstring);
                                                this.webSocket.Send(d);
                                                elem = document.getElementById("mjhsplashscreen");
                                                elem.style = "display: none;";
                                            } else if (Bridge.referenceEquals(ds.Action, "Create")) {
                                                this.EndCustomCSS();
                                                ds.Name = "Type";
                                                ds.Data = ds.Class.substr(3);
                                                if (Bridge.referenceEquals(ds.Class, "qwcButton") || Bridge.referenceEquals(ds.Class, "qwcCombo") || Bridge.referenceEquals(ds.Class, "qwcDateTimePicker") || Bridge.referenceEquals(ds.Class, "qwcMsgBox") || Bridge.referenceEquals(ds.Class, "qwcEdit") || Bridge.referenceEquals(ds.Class, "qwcList") || Bridge.referenceEquals(ds.Class, "qwcListViewSingle") || Bridge.referenceEquals(ds.Class, "qwcListViewMulti") || Bridge.referenceEquals(ds.Class, "qwcMenuItem") || Bridge.referenceEquals(ds.Class, "qwcTabControl")) {
                                                    ds.Class = (ds.Class || "") + (ds.Extras || "");
                                                }
                                                cl = (ds.Class || "") + "_Data";
                                                o = APLExtension.APL.MakeInstance("DataBinding", cl, ds.Instance, this);
                                                xstring = new APLExtension.TransferString();
                                                xstring.Trans = trans;
                                                d = APLExtension.TD.FromTransferString(xstring);
                                                this.webSocket.Send(d);
                                            } else if (Bridge.referenceEquals(ds.Action, "EndRunLoaded")) {
                                                this.CreateControl(ds);
                                            } else if (Bridge.referenceEquals(ds.Action, "OldCreate")) {
                                                ds.Name = "Type";
                                                ds.Data = ds.Class.substr(3);
                                                if (Bridge.referenceEquals(ds.Class, "qwcButton") || Bridge.referenceEquals(ds.Class, "qwcCombo") || Bridge.referenceEquals(ds.Class, "qwcDateTimePicker") || Bridge.referenceEquals(ds.Class, "qwcMsgBox") || Bridge.referenceEquals(ds.Class, "qwcEdit") || Bridge.referenceEquals(ds.Class, "qwcList") || Bridge.referenceEquals(ds.Class, "qwcListViewSingle") || Bridge.referenceEquals(ds.Class, "qwcListViewMulti") || Bridge.referenceEquals(ds.Class, "qwcMenuItem") || Bridge.referenceEquals(ds.Class, "qwcTabControl")) {
                                                    ds.Class = (ds.Class || "") + (ds.Extras || "");
                                                }
                                                assembly = APLExtension.APL.GetAssembly("DataBinding", this);
                                                type = Bridge.Reflection.getType("DataBinding." + (ds.Class || ""), assembly);
                                                ob = Bridge.createInstance(type, [ds]);
                                                cl1 = APLExtension.APL.GetClassByName(ds.Instance);
                                                obj = APLExtension.APL.GetInstance$3("DataBinding", cl1, ds.Instance, ob);
                                                xstring = new APLExtension.TransferString();
                                                xstring.Trans = trans;
                                                d = APLExtension.TD.FromTransferString(xstring);
                                                this.webSocket.Send(d);
                                                this.directwebSocket.Send(d);
                                            } else if (Bridge.referenceEquals(ds.Action, "CreateContinue1")) {
                                                if (Bridge.referenceEquals(ds.Class, "qwcButton") || Bridge.referenceEquals(ds.Class, "qwcCombo") || Bridge.referenceEquals(ds.Class, "qwcDateTimePicker") || Bridge.referenceEquals(ds.Class, "qwcMsgBox") || Bridge.referenceEquals(ds.Class, "qwcEdit") || Bridge.referenceEquals(ds.Class, "qwcList") || Bridge.referenceEquals(ds.Class, "qwcListViewSingle") || Bridge.referenceEquals(ds.Class, "qwcListViewMulti") || Bridge.referenceEquals(ds.Class, "qwcMenuItem") || Bridge.referenceEquals(ds.Class, "qwcTabControl")) {
                                                    ds.Class = (ds.Class || "") + (ds.Extras || "");
                                                }
                                                assembly1 = APLExtension.APL.GetAssembly("DataBinding", this);
                                                cl2 = APLExtension.APL.GetClassByName(ds.Instance);
                                                obj1 = APLExtension.APL.GetInstance$3("DataBinding", cl2, ds.Instance, null);
                                                cla = Bridge.Reflection.getType("DataBinding." + (ds.Class || ""), assembly1);
                                                method = Bridge.Reflection.getMembers(cla, 8, 284, "CreateContinue1");
                                                if (method != null) {
                                                    $arguments = System.Array.init([ds], System.Object);
                                                    Bridge.Reflection.midel(method, Bridge.unbox(Bridge.cast(obj1, APLExtension.MJH_CommonData).MJH_Class)).apply(null, Bridge.unbox($arguments));
                                                }
                                                xstring = new APLExtension.TransferString();
                                                xstring.Trans = trans;
                                                d = APLExtension.TD.FromTransferString(xstring);
                                                this.webSocket.Send(d);
                                                this.directwebSocket.Send(d);
                                            } else if (Bridge.referenceEquals(ds.Action, "CreateContinue2")) {
                                                if (Bridge.referenceEquals(ds.Class, "qwcButton") || Bridge.referenceEquals(ds.Class, "qwcCombo") || Bridge.referenceEquals(ds.Class, "qwcDateTimePicker") || Bridge.referenceEquals(ds.Class, "qwcMsgBox") || Bridge.referenceEquals(ds.Class, "qwcEdit") || Bridge.referenceEquals(ds.Class, "qwcList") || Bridge.referenceEquals(ds.Class, "qwcListViewSingle") || Bridge.referenceEquals(ds.Class, "qwcListViewMulti") || Bridge.referenceEquals(ds.Class, "qwcMenuItem") || Bridge.referenceEquals(ds.Class, "qwcTabControl")) {
                                                    ds.Class = (ds.Class || "") + (ds.Extras || "");
                                                }
                                                assembly2 = APLExtension.APL.GetAssembly("DataBinding", this);
                                                cl3 = APLExtension.APL.GetClassByName(ds.Instance);
                                                obj2 = APLExtension.APL.GetInstance$3("DataBinding", cl3, ds.Instance, null);
                                                cla1 = Bridge.Reflection.getType("DataBinding." + (ds.Class || ""), assembly2);
                                                method1 = Bridge.Reflection.getMembers(cla1, 8, 284, "CreateContinue2");
                                                if (method1 != null) {
                                                    $arguments1 = System.Array.init([ds], System.Object);
                                                    Bridge.Reflection.midel(method1, Bridge.unbox(Bridge.cast(obj2, APLExtension.MJH_CommonData).MJH_Class)).apply(null, Bridge.unbox($arguments1));
                                                }
                                                if (0 !== ds.Extras.length) {
                                                    ds.Name = "Style";
                                                    ds.Data = ds.Extras;
                                                    typecl = Bridge.Reflection.getType("DataBinding." + (cl3 || ""), assembly2);
                                                    method11 = Bridge.Reflection.getMembers(typecl, 8, 284, "RunPropertyChangedIn");
                                                    $arguments2 = System.Array.init([ds, Bridge.box(false, System.Boolean, System.Boolean.toString)], System.Object);
                                                    Bridge.Reflection.midel(method11, Bridge.unbox(obj2)).apply(null, Bridge.unbox($arguments2));
                                                }
                                                xstring = new APLExtension.TransferString();
                                                xstring.Trans = trans;
                                                d = APLExtension.TD.FromTransferString(xstring);
                                                this.webSocket.Send(d);
                                                this.directwebSocket.Send(d);
                                            } else if (Bridge.referenceEquals(ds.Action, "EnQueue")) {
                                        ds.Class = APLExtension.APL.GetClassByName(ds.Instance);
                                                if (null != ds.Class) {
                                                    obj3 = APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this);
                                                    $arguments1 = System.Array.init([ds, this], System.Object);
                                                    assembly3 = APLExtension.APL.GetAssembly("QWC", this);
                                                    type1 = Bridge.Reflection.getType("QWC.NQ", assembly3);
                                                    method2 = Bridge.Reflection.getMembers(type1, 8, 284, "Do" + (ds.Name || ""));
                                                    if (APLExtension.Utils.IsStatic(method2)) {
                                                        NQresult = Bridge.cast(Bridge.Reflection.midel(method2, null).apply(null, Bridge.unbox($arguments1)), System.String);
                                                    } else {
                                                        NQresult = Bridge.cast(Bridge.Reflection.midel(method2, Bridge.unbox(obj3)).apply(null, Bridge.unbox($arguments1)), System.String);
                                                    }
                                                } else {
                                                    NQresult = "False";
                                                }
                                                xstring = new APLExtension.TransferString();
                                                xstring.Type = "EnQueue";
                                                xstring.Data = NQresult;
                                                xstring.Trans = trans;
                                                d = APLExtension.TD.FromTransferString(xstring);
                                                this.directwebSocket.Send(d);
                                            } else {
                                                this.RunDataBinding(ds);
                                            }
                                        }
                                        return;
                                    }
                                    default: {
                                        return;
                                    }
                                }
                            }
                        }, arguments);

                    $asyncBody();
                }));
                this.webSocket.addOnError(function (s, e) {
                    _WSInternals.Status = "ERROR : " + (e.Data || "");
                });
                this.webSocket.addOnClose(function (s, e) {
                    _WSInternals.Status = "WebSocket Closed ";
                });
                this.webSocket.addOnOpen(Bridge.fn.bind(this, function (s, e) {
                    xstring = new APLExtension.TransferString();
                    xstring.Type = "SessionStart";
                    xstring.Data = Bridge.cast(Windows.UI.Xaml.Application.Current.Resources.getItem("OriginalURL"), System.String);
                    d = APLExtension.TD.FromTransferString(xstring);
                    this.webSocket.Send(d);
                }));
                this.directwebSocket.addOnOpen(Bridge.fn.bind(this, function (s, e) {
                    var $step = 0,
                        $task1, 
                        $taskResult1, 
                        $jumpFromFinally, 
                        dx, 
                        $asyncBody = Bridge.fn.bind(this, function () {
                            for (;;) {
                                $step = System.Array.min([0,1], $step);
                                switch ($step) {
                                    case 0: {
                                        xstring = new APLExtension.TransferString();
                                        $task1 = this.WebSocketReady;
                                        $step = 1;
                                        if ($task1.isCompleted()) {
                                            continue;
                                        }
                                        $task1.continue($asyncBody);
                                        return;
                                    }
                                    case 1: {
                                        $taskResult1 = $task1.getAwaitedResult();
                                        xstring.Data = Bridge.cast(Windows.UI.Xaml.Application.Current.Resources.getItem("Index"), System.String);
                                        xstring.Type = "Index";
                                        dx = APLExtension.TD.FromTransferString(xstring);
                                        this.directwebSocket.Send(dx);
                                        return;
                                    }
                                    default: {
                                        return;
                                    }
                                }
                            }
                        }, arguments);

                    $asyncBody();
                }));
                this.directwebSocket.addOnMessage(Bridge.fn.bind(this, function (s, e) {
                    var ds = APLExtension.TD.ToTransferString(e.Data);
                    var trans = ds.Trans;
                    if (Bridge.referenceEquals(ds.Action, "MJH_CloseServer")) {
                        this.directwebSocket.Send(e.Data);
                    } else if (Bridge.referenceEquals(ds.Action, "EnQueue")) {
                        var NQresult;
                        ds.Class = APLExtension.APL.GetClassByName(ds.Instance);
                        if (null != ds.Class) {
                            var obj = APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this);
                            var $arguments = System.Array.init([ds, this], System.Object);
                            var assembly = APLExtension.APL.GetAssembly("QWC", this);
                            var type = Bridge.Reflection.getType("QWC.NQ", assembly);
                            var method = Bridge.Reflection.getMembers(type, 8, 284, "Do" + (ds.Name || ""));
                            if (APLExtension.Utils.IsStatic(method)) {
                                NQresult = Bridge.cast(Bridge.Reflection.midel(method, null).apply(null, Bridge.unbox($arguments)), System.String);
                            } else {
                                NQresult = Bridge.cast(Bridge.Reflection.midel(method, Bridge.unbox(obj)).apply(null, Bridge.unbox($arguments)), System.String);
                            }
                        } else {
                            NQresult = "False";
                        }
                        xstring = new APLExtension.TransferString();
                        xstring.Type = "EnQueue";
                        xstring.Data = NQresult;
                        xstring.Trans = trans;
                        d = APLExtension.TD.FromTransferString(xstring);
                        this.directwebSocket.Send(d);
                    } else if (Bridge.referenceEquals(ds.Action, "ReturnEvent")) {
                        APLExtension.APL.RaiseEventReturned(e.Data);
                    }
                }));
            },
            IsEJ1: function (inp) {
                return false;
            },
            IsEJ2: function (inp) {
                if (Bridge.referenceEquals(inp, "qwcAppBar_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcAvatar_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcBadge_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcBarCode_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcBreadCrumb_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcCalendar_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcCard_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcCarousel_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcChart_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcChips_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcCircularGauge_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcColourPicker_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcColorPicker_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcComboDrop_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcComboDropEdit_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcComboSimple_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcContextMenu_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcDashBoard_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcDataGrid_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcDataManager_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcDateTimePickerCombo_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcDiagram_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcMsgBoxMsg_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcMsgBoxInfo_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcMsgBoxQuery_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcMsgBoxWarn_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcMsgBoxError_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcDocumentEditor_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcFileManager_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcGantt_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcGrid_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcImageEditor_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcLinearGauge_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcImage_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcKanban_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcListSingle_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcListMulti_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcListViewSingle_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcListViewMulti_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcMaps_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcMention_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcMenuBar_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcMessage_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcPager_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcPDFViewer_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcPivotTable_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcProgressBar_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcProgressButton_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcQueryBuilder_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcQRCode_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcRating_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcRibbon_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcRichTextEditor_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcSchedule_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcSideBar_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcSignature_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcSkeleton_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcSplitter_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcTabControl_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcText_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcTreeView_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcUploader_Data")) {
                    return true;
                }
                return false;
            },
            CreateControl: function (ds) {
                var assembly = APLExtension.APL.GetAssembly("DataBinding", this);
                var type = Bridge.Reflection.getType("DataBinding." + (ds.Class || ""), assembly);
                var cl = (ds.Class || "") + "_Data";
                var isEJ1 = this.IsEJ1(cl);
                var isEJ2 = this.IsEJ2(cl);
                var ob = Bridge.createInstance(type, [ds]);
                var method = Bridge.Reflection.getMembers(type, 8, 284, "CreateContinue1");
                var obj = APLExtension.APL.GetInstance$3("DataBinding", cl, ds.Instance, null);
                if (method != null) {
                    var $arguments = System.Array.init([ds], System.Object);
                    Bridge.Reflection.midel(method, Bridge.unbox(Bridge.cast(obj, APLExtension.MJH_CommonData).MJH_Class)).apply(null, Bridge.unbox($arguments));
                }
                method = Bridge.Reflection.getMembers(type, 8, 284, "CreateContinue2");
                if (method != null) {
                    var $arguments1 = System.Array.init([ds], System.Object);
                    Bridge.Reflection.midel(method, Bridge.unbox(Bridge.cast(obj, APLExtension.MJH_CommonData).MJH_Class)).apply(null, Bridge.unbox($arguments1));
                }
                if (0 !== ds.Extras.length) {
                    ds.Name = "Style";
                    ds.Data = ds.Extras;
                    var typecl = Bridge.Reflection.getType("DataBinding." + (cl || ""), assembly);
                    method = Bridge.Reflection.getMembers(typecl, 8, 284, "RunPropertyChangedIn");
                    var $arguments2 = System.Array.init([ds, Bridge.box(false, System.Boolean, System.Boolean.toString)], System.Object);
                    Bridge.Reflection.midel(method, Bridge.unbox(obj)).apply(null, Bridge.unbox($arguments2));
                }
            },
            RunDataBinding: function (ds) {
                if (Bridge.referenceEquals(ds.Class, "qwc_Root")) {
                    var dbobj1 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwc_Root);
                    if (null != dbobj1) {
                        dbobj1.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "MJH_DQ_Data")) {
                    var dbobj2 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.MJH_DQ_Data);
                    if (null != dbobj2) {
                        dbobj2.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "MJH_MinForm_Data")) {
                    var dbobj3 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.MJH_MinForm_Data);
                    if (null != dbobj3) {
                        dbobj3.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcAppBar_Data")) {
                    var dbobj4 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcAppBar_Data);
                    if (null != dbobj4) {
                        dbobj4.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcAvatar_Data")) {
                    var dbobj5 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcAvatar_Data);
                    if (null != dbobj5) {
                        dbobj5.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcBadge_Data")) {
                    var dbobj6 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcBadge_Data);
                    if (null != dbobj6) {
                        dbobj6.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcBarCode_Data")) {
                    var dbobj7 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcBarCode_Data);
                    if (null != dbobj7) {
                        dbobj7.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcBreadCrumb_Data")) {
                    var dbobj8 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcBreadCrumb_Data);
                    if (null != dbobj8) {
                        dbobj8.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcBridgeScore_Data")) {
                    var dbobj9 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcBridgeScore_Data);
                    if (null != dbobj9) {
                        dbobj9.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcButtonCheck_Data")) {
                    var dbobj10 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcButtonCheck_Data);
                    if (null != dbobj10) {
                        dbobj10.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcButtonCommandLink_Data")) {
                    var dbobj11 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcButtonCommandLink_Data);
                    if (null != dbobj11) {
                        dbobj11.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcButtonPush_Data")) {
                    var dbobj12 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcButtonPush_Data);
                    if (null != dbobj12) {
                        dbobj12.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcButtonRadio_Data")) {
                    var dbobj13 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcButtonRadio_Data);
                    if (null != dbobj13) {
                        dbobj13.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcButtonSplit_Data")) {
                    var dbobj14 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcButtonSplit_Data);
                    if (null != dbobj14) {
                        dbobj14.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcButtonToggle_Data")) {
                    var dbobj15 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcButtonToggle_Data);
                    if (null != dbobj15) {
                        dbobj15.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcCalendar_Data")) {
                    var dbobj16 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcCalendar_Data);
                    if (null != dbobj16) {
                        dbobj16.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcCard_Data")) {
                    var dbobj17 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcCard_Data);
                    if (null != dbobj17) {
                        dbobj17.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcCarousel_Data")) {
                    var dbobj18 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcCarousel_Data);
                    if (null != dbobj18) {
                        dbobj18.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcChart_Data")) {
                    var dbobj19 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcChart_Data);
                    if (null != dbobj19) {
                        dbobj19.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcChips_Data")) {
                    var dbobj20 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcChips_Data);
                    if (null != dbobj20) {
                        dbobj20.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcCircularGauge_Data")) {
                    var dbobj21 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcCircularGauge_Data);
                    if (null != dbobj21) {
                        dbobj21.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcColourPicker_Data")) {
                    var dbobj22 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcColourPicker_Data);
                    if (null != dbobj22) {
                        dbobj22.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcColorPicker_Data")) {
                    var dbobj23 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcColorPicker_Data);
                    if (null != dbobj23) {
                        dbobj23.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcComboDrop_Data")) {
                    var dbobj24 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcComboDrop_Data);
                    if (null != dbobj24) {
                        dbobj24.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcComboDropEdit_Data")) {
                    var dbobj25 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcComboDropEdit_Data);
                    if (null != dbobj25) {
                        dbobj25.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcComboSimple_Data")) {
                    var dbobj26 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcComboSimple_Data);
                    if (null != dbobj26) {
                        dbobj26.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcContextMenu_Data")) {
                    var dbobj27 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcContextMenu_Data);
                    if (null != dbobj27) {
                        dbobj27.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcDashBoard_Data")) {
                    var dbobj28 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcDashBoard_Data);
                    if (null != dbobj28) {
                        dbobj28.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcDataGrid_Data")) {
                    var dbobj29 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcDataGrid_Data);
                    if (null != dbobj29) {
                        dbobj29.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcDataManager_Data")) {
                    var dbobj30 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcDataManager_Data);
                    if (null != dbobj30) {
                        dbobj30.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcDatePicker_Data")) {
                    var dbobj31 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcDatePicker_Data);
                    if (null != dbobj31) {
                        dbobj31.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcDateTimePickerCombo_Data")) {
                    var dbobj32 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcDateTimePickerCombo_Data);
                    if (null != dbobj32) {
                        dbobj32.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcDiagram_Data")) {
                    var dbobj33 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcDiagram_Data);
                    if (null != dbobj33) {
                        dbobj33.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcMsgBoxMsg_Data")) {
                    var dbobj34 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcMsgBoxMsg_Data);
                    if (null != dbobj34) {
                        dbobj34.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcMsgBoxInfo_Data")) {
                    var dbobj35 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcMsgBoxInfo_Data);
                    if (null != dbobj35) {
                        dbobj35.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcMsgBoxQuery_Data")) {
                    var dbobj36 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcMsgBoxQuery_Data);
                    if (null != dbobj36) {
                        dbobj36.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcMsgBoxWarn_Data")) {
                    var dbobj37 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcMsgBoxWarn_Data);
                    if (null != dbobj37) {
                        dbobj37.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcMsgBoxError_Data")) {
                    var dbobj38 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcMsgBoxError_Data);
                    if (null != dbobj38) {
                        dbobj38.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcDocumentEditor_Data")) {
                    var dbobj39 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcDocumentEditor_Data);
                    if (null != dbobj39) {
                        dbobj39.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcEditSingle_Data")) {
                    var dbobj40 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcEditSingle_Data);
                    if (null != dbobj40) {
                        dbobj40.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcEditMulti_Data")) {
                    var dbobj41 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcEditMulti_Data);
                    if (null != dbobj41) {
                        dbobj41.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcExpander_Data")) {
                    var dbobj42 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcExpander_Data);
                    if (null != dbobj42) {
                        dbobj42.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcFileManager_Data")) {
                    var dbobj43 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcFileManager_Data);
                    if (null != dbobj43) {
                        dbobj43.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcFont_Data")) {
                    var dbobj44 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcFont_Data);
                    if (null != dbobj44) {
                        dbobj44.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcForm_Data")) {
                    var dbobj45 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcForm_Data);
                    if (null != dbobj45) {
                        dbobj45.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcGantt_Data")) {
                    var dbobj46 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcGantt_Data);
                    if (null != dbobj46) {
                        dbobj46.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcGrid_Data")) {
                    var dbobj47 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcGrid_Data);
                    if (null != dbobj47) {
                        dbobj47.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcGroup_Data")) {
                    var dbobj48 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcGroup_Data);
                    if (null != dbobj48) {
                        dbobj48.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcImageEditor_Data")) {
                    var dbobj49 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcImageEditor_Data);
                    if (null != dbobj49) {
                        dbobj49.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcKanban_Data")) {
                    var dbobj50 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcKanban_Data);
                    if (null != dbobj50) {
                        dbobj50.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcLabel_Data")) {
                    var dbobj51 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcLabel_Data);
                    if (null != dbobj51) {
                        dbobj51.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcLinearGauge_Data")) {
                    var dbobj52 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcLinearGauge_Data);
                    if (null != dbobj52) {
                        dbobj52.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcImage_Data")) {
                    var dbobj53 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcImage_Data);
                    if (null != dbobj53) {
                        dbobj53.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcImageList_Data")) {
                    var dbobj54 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcImageList_Data);
                    if (null != dbobj54) {
                        dbobj54.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcKanban_Data")) {
                    var dbobj55 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcKanban_Data);
                    if (null != dbobj55) {
                        dbobj55.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcListSingle_Data")) {
                    var dbobj56 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcListSingle_Data);
                    if (null != dbobj56) {
                        dbobj56.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcListMulti_Data")) {
                    var dbobj57 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcListMulti_Data);
                    if (null != dbobj57) {
                        dbobj57.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcListViewSingle_Data")) {
                    var dbobj58 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcListViewSingle_Data);
                    if (null != dbobj58) {
                        dbobj58.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcListViewMulti_Data")) {
                    var dbobj59 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcListViewMulti_Data);
                    if (null != dbobj59) {
                        dbobj59.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcMaps_Data")) {
                    var dbobj60 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcMaps_Data);
                    if (null != dbobj60) {
                        dbobj60.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcMention_Data")) {
                    var dbobj61 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcMention_Data);
                    if (null != dbobj61) {
                        dbobj61.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcMenu_Data")) {
                    var dbobj62 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcMenu_Data);
                    if (null != dbobj62) {
                        dbobj62.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcMenuBar_Data")) {
                    var dbobj63 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcMenuBar_Data);
                    if (null != dbobj63) {
                        dbobj63.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcMenuItemCheck_Data")) {
                    var dbobj64 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcMenuItemCheck_Data);
                    if (null != dbobj64) {
                        dbobj64.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcMenuItemRadio_Data")) {
                    var dbobj65 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcMenuItemRadio_Data);
                    if (null != dbobj65) {
                        dbobj65.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcMessage_Data")) {
                    var dbobj66 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcMessage_Data);
                    if (null != dbobj66) {
                        dbobj66.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcPager_Data")) {
                    var dbobj67 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcPager_Data);
                    if (null != dbobj67) {
                        dbobj67.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcPDFViewer_Data")) {
                    var dbobj68 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcPDFViewer_Data);
                    if (null != dbobj68) {
                        dbobj68.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcPivotTable_Data")) {
                    var dbobj69 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcPivotTable_Data);
                    if (null != dbobj69) {
                        dbobj69.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcProgressBar_Data")) {
                    var dbobj70 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcProgressBar_Data);
                    if (null != dbobj70) {
                        dbobj70.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcProgressButton_Data")) {
                    var dbobj71 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcProgressButton_Data);
                    if (null != dbobj71) {
                        dbobj71.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcQueryBuilder_Data")) {
                    var dbobj72 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcQueryBuilder_Data);
                    if (null != dbobj72) {
                        dbobj72.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcQRCode_Data")) {
                    var dbobj73 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcQRCode_Data);
                    if (null != dbobj73) {
                        dbobj73.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcRating_Data")) {
                    var dbobj74 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcRating_Data);
                    if (null != dbobj74) {
                        dbobj74.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcRibbon_Data")) {
                    var dbobj75 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcRibbon_Data);
                    if (null != dbobj75) {
                        dbobj75.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcRichTextEditor_Data")) {
                    var dbobj76 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcRichTextEditor_Data);
                    if (null != dbobj76) {
                        dbobj76.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcSchedule_Data")) {
                    var dbobj77 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcSchedule_Data);
                    if (null != dbobj77) {
                        dbobj77.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcSeparator_Data")) {
                    var dbobj78 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcSeparator_Data);
                    if (null != dbobj78) {
                        dbobj78.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcSideBar_Data")) {
                    var dbobj79 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcSideBar_Data);
                    if (null != dbobj79) {
                        dbobj79.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcSignature_Data")) {
                    var dbobj80 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcSignature_Data);
                    if (null != dbobj80) {
                        dbobj80.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcSkeleton_Data")) {
                    var dbobj81 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcSkeleton_Data);
                    if (null != dbobj81) {
                        dbobj81.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcSplitter_Data")) {
                    var dbobj82 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcSplitter_Data);
                    if (null != dbobj82) {
                        dbobj82.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcSubForm_Data")) {
                    var dbobj83 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcSubForm_Data);
                    if (null != dbobj83) {
                        dbobj83.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcTabButton_Data")) {
                    var dbobj84 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcTabButton_Data);
                    if (null != dbobj84) {
                        dbobj84.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcTabButton1_Data")) {
                    var dbobj85 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcTabButton1_Data);
                    if (null != dbobj85) {
                        dbobj85.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcTabControl_Data")) {
                    var dbobj86 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcTabControl_Data);
                    if (null != dbobj86) {
                        dbobj86.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcTabControlButtons_Data")) {
                    var dbobj87 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcTabControlButtons_Data);
                    if (null != dbobj87) {
                        dbobj87.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcTabControlFlatButtons_Data")) {
                    var dbobj88 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcTabControlFlatButtons_Data);
                    if (null != dbobj88) {
                        dbobj88.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcTabControlTabs_Data")) {
                    var dbobj89 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcTabControlTabs_Data);
                    if (null != dbobj89) {
                        dbobj89.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcText_Data")) {
                    var dbobj90 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcText_Data);
                    if (null != dbobj90) {
                        dbobj90.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcTreeView_Data")) {
                    var dbobj91 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcTreeView_Data);
                    if (null != dbobj91) {
                        dbobj91.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcUploader_Data")) {
                    var dbobj92 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcUploader_Data);
                    if (null != dbobj92) {
                        dbobj92.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "WSInternals")) {
                    var dbobj93 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.WSInternals);
                    if (null != dbobj93) {
                        dbobj93.RunPropertyChangedIn(ds, false);
                    }
                }

            },
            OnBeforeUnload: function (e) {
                var msg = "Do you want to leave QWC?";
                e.preventDefault();
                e.returnValue = msg;
                return msg;
            },
            MakeWinSize: function (rt, wi) {
                wi.SetValue("Status", "WebSocket Opened");
                var fsz = new Windows.Foundation.Size.ctor();
                fsz.Width = System.Nullable.getValue(Bridge.cast(Bridge.unbox(screen.width, System.Double), System.Double));
                fsz.Height = System.Nullable.getValue(Bridge.cast(Bridge.unbox(screen.height, System.Double), System.Double));
                Windows.UI.Xaml.Application.Current.Resources.setItem("FullScreenHeight", Bridge.box(fsz.Height, System.Double, System.Double.format, System.Double.getHashCode));
                Windows.UI.Xaml.Application.Current.Resources.setItem("FullScreenWidth", Bridge.box(fsz.Width, System.Double, System.Double.format, System.Double.getHashCode));
                rt.SetValue("FullScreenSize", fsz.$clone());
                var win = Windows.UI.Xaml.Window.Current;
                Windows.UI.Xaml.Application.Current.Resources.setItem("Screen", win);
                var rect = win.Bounds.$clone();
                Windows.UI.Xaml.Application.Current.Resources.setItem("ScreenHeight", Bridge.box(rect.Height, System.Double, System.Double.format, System.Double.getHashCode));
                Windows.UI.Xaml.Application.Current.Resources.setItem("ScreenWidth", Bridge.box(rect.Width, System.Double, System.Double.format, System.Double.getHashCode));
                rt.SetValue("ScreenSize", rect.Size.$clone());
                rt.SetValue("BrowserScreenSize", rect.Size.$clone());
                var ratio = System.Nullable.getValue(Bridge.cast(Bridge.unbox(window.devicePixelRatio, System.Double), System.Double));
                if (ratio < 1) {
                    ratio = 1 / ratio;
                }
                var fSize = new Windows.Foundation.Size.$ctor1(Bridge.Int.clip32(fsz.Width) * ratio, Bridge.Int.clip32(fsz.Height) * ratio);
                Windows.UI.Xaml.Application.Current.Resources.setItem("FullScreenHeight", Bridge.box(fSize.Height, System.Double, System.Double.format, System.Double.getHashCode));
                Windows.UI.Xaml.Application.Current.Resources.setItem("FullScreenWidth", Bridge.box(fSize.Width, System.Double, System.Double.format, System.Double.getHashCode));
                rt.SetValue("FullScreenSize", fSize.$clone());
                win.addSizeChanged$1(Bridge.fn.bind(this, function (s1, e1) {
                    var newsz = e1.Size.$clone();
                    var root = Bridge.as(APLExtension.APL.GetInstance$3("DataBinding", "qwc_Root", "qwc_Root", this), DataBinding.qwc_Root);
                    root.SetValue("ScreenSize", newsz.$clone());
                    root.SetValue("BrowserScreenSize", newsz.$clone());
                    var ratio1 = System.Nullable.getValue(Bridge.cast(Bridge.unbox(window.devicePixelRatio, System.Double), System.Double));
                    if (ratio1 < 1) {
                        ratio1 = 1 / ratio1 + 0.5;
                    }
                    var fSize1 = new Windows.Foundation.Size.$ctor1(Bridge.Int.clip32(fsz.Width) * ratio1, Bridge.Int.clip32(fsz.Height) * ratio1);
                    Windows.UI.Xaml.Application.Current.Resources.setItem("FullScreenHeight", Bridge.box(fSize1.Height, System.Double, System.Double.format, System.Double.getHashCode));
                    Windows.UI.Xaml.Application.Current.Resources.setItem("FullScreenWidth", Bridge.box(fSize1.Width, System.Double, System.Double.format, System.Double.getHashCode));
                    root.SetValue("FullScreenSize", fSize1.$clone());
                    Windows.UI.Xaml.Application.Current.Resources.setItem("ScreenHeight", Bridge.box(newsz.Height, System.Double, System.Double.format, System.Double.getHashCode));
                    Windows.UI.Xaml.Application.Current.Resources.setItem("ScreenWidth", Bridge.box(newsz.Width, System.Double, System.Double.format, System.Double.getHashCode));
                    Windows.UI.Xaml.Application.Current.Resources.setItem("BrowserScreenHeight", Bridge.box(newsz.Height, System.Double, System.Double.format, System.Double.getHashCode));
                    Windows.UI.Xaml.Application.Current.Resources.setItem("BrowserScreenWidth", Bridge.box(newsz.Width, System.Double, System.Double.format, System.Double.getHashCode));
                    var fm = Bridge.cast(root.GetValue("FullScreenId"), System.String);
                    if (0 !== fm.length) {
                        var ds = Bridge.as(APLExtension.APL.GetInstance$3("DataBinding", "qwcForm_Data", fm, this), DataBinding.qwcForm_Data);
                        if (fm != null && 4 === System.Nullable.getValue(Bridge.cast(Bridge.unbox(ds.GetValue("State"), System.Int32), System.Int32))) {
                            ds.NotifyPropertyChanged("Size");
                        }
                    }
                }));
            },
            UpdateBindingLostFocus: function (sender, e) {
                var tx = Bridge.cast(sender, Windows.UI.Xaml.Controls.TextBox);
                if (0 !== tx.Text.length) {
                    var exp = tx.GetBindingExpression(Windows.UI.Xaml.Controls.TextBox.TextProperty);
                    var dobj = Bridge.as(exp.DataItem, APLExtension.MJH_CommonData);
                    var instance = dobj.MJH_Instance;
                    var ds = APLExtension.TD.ToTransferString("");
                    ds.Name = exp.ParentBinding.Path.Path;
                    ds.Data = tx.Text;
                    ds.Instance = instance;
                    ds.Class = APLExtension.APL.GetClassByName(ds.Instance);
                    var obj = APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this);
                    var $arguments = System.Array.init([ds, Bridge.box(true, System.Boolean, System.Boolean.toString)], System.Object);
                    var assembly = APLExtension.APL.GetAssembly("DataBinding", this);
                    var type = Bridge.Reflection.getType("DataBinding." + (ds.Class || ""), assembly);
                    var method = Bridge.Reflection.getMembers(type, 8, 284, "RunPropertyChangedIn");
                    Bridge.Reflection.midel(method, Bridge.unbox(obj)).apply(null, Bridge.unbox($arguments));
                }
            },
            UpdateBindingKeyDown: function (sender, e) {
                if (e.Key === Windows.System.VirtualKey.Enter) {
                    var tx = Bridge.cast(sender, Windows.UI.Xaml.Controls.TextBox);
                    if (0 !== tx.Text.length) {
                        var exp = tx.GetBindingExpression(Windows.UI.Xaml.Controls.TextBox.TextProperty);
                        var dobj = Bridge.as(exp.DataItem, APLExtension.MJH_CommonData);
                        var instance = dobj.MJH_Instance;
                        var ds = APLExtension.TD.ToTransferString("");
                        ds.Name = exp.ParentBinding.Path.Path;
                        ds.Data = tx.Text;
                        ds.Instance = instance;
                        ds.Class = APLExtension.APL.GetClassByName(ds.Instance);
                        var obj = APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this);
                        var $arguments = System.Array.init([ds, Bridge.box(true, System.Boolean, System.Boolean.toString)], System.Object);
                        var assembly = APLExtension.APL.GetAssembly("DataBinding", this);
                        var type = Bridge.Reflection.getType("DataBinding." + (ds.Class || ""), assembly);
                        var method = Bridge.Reflection.getMembers(type, 8, 284, "RunPropertyChangedIn");
                        Bridge.Reflection.midel(method, Bridge.unbox(obj)).apply(null, Bridge.unbox($arguments));
                    }
                }
            },
            InitializeComponent: function () {
                if (this._contentLoaded) {
                    return;
                }
                this._contentLoaded = true;


                if (Bridge.is(this, Windows.UI.Xaml.UIElement)) {
                    Bridge.cast(this, Windows.UI.Xaml.UIElement).XamlSourcePath = "QWC\\MainPage.xaml";
                }

                var Grid_53950a6ecd6243d181da2940f006e5aa = new Bridge.global.Windows.UI.Xaml.Controls.Grid();
                var WrapPanel_8f6d90c5b84940a384cadcb071f4005e = new Bridge.global.Windows.UI.Xaml.Controls.WrapPanel();
                var Grid_ea417361752c4065ab1cfb876d5ea823 = new Bridge.global.Windows.UI.Xaml.Controls.Grid();
                var Grid_16f0b6813c034068981ae6b671ab14b6 = new Bridge.global.Windows.UI.Xaml.Controls.Grid();

                this.RegisterName$1("Top", this);
                this.Name = "Top";
                var IntConverter_a260ce79c7c14c9cabf45df0e838443c = new Bridge.global.APLExtension.IntConverter();

                var DecConverter_7dfffd0469554b91bea17421a7918064 = new Bridge.global.APLExtension.DecConverter();

                this.Resources.setItem("IntConverter", IntConverter_a260ce79c7c14c9cabf45df0e838443c);
                this.Resources.setItem("DecConverter", DecConverter_7dfffd0469554b91bea17421a7918064);

                var Grid_b500d5b20d014ae69dd3a523a2294d1a = new Bridge.global.Windows.UI.Xaml.Controls.Grid();
                var RowDefinition_d5d836fc4de341199895bafb2ea44c15 = new Bridge.global.Windows.UI.Xaml.Controls.RowDefinition();
                RowDefinition_d5d836fc4de341199895bafb2ea44c15.Height = new Bridge.global.Windows.UI.Xaml.GridLength.$ctor2(1.0, Bridge.global.Windows.UI.Xaml.GridUnitType.Star);

                var RowDefinition_65a4a5f4f8d44e1da00100714c64ad85 = new Bridge.global.Windows.UI.Xaml.Controls.RowDefinition();
                RowDefinition_65a4a5f4f8d44e1da00100714c64ad85.Height = new Bridge.global.Windows.UI.Xaml.GridLength.$ctor2(1.0, Bridge.global.Windows.UI.Xaml.GridUnitType.Auto);

                Grid_b500d5b20d014ae69dd3a523a2294d1a.RowDefinitions.add(RowDefinition_d5d836fc4de341199895bafb2ea44c15);
                Grid_b500d5b20d014ae69dd3a523a2294d1a.RowDefinitions.add(RowDefinition_65a4a5f4f8d44e1da00100714c64ad85);

                this.RegisterName$1("QWCGrid", Grid_53950a6ecd6243d181da2940f006e5aa);
                Grid_53950a6ecd6243d181da2940f006e5aa.Name = "QWCGrid";

                this.RegisterName$1("QWCIcons", WrapPanel_8f6d90c5b84940a384cadcb071f4005e);
                WrapPanel_8f6d90c5b84940a384cadcb071f4005e.Name = "QWCIcons";
                Bridge.global.Windows.UI.Xaml.Controls.Grid.SetRow(WrapPanel_8f6d90c5b84940a384cadcb071f4005e, 1);

                this.RegisterName$1("QWCHidden", Grid_ea417361752c4065ab1cfb876d5ea823);
                Grid_ea417361752c4065ab1cfb876d5ea823.Name = "QWCHidden";
                Bridge.global.Windows.UI.Xaml.Controls.Grid.SetRow(Grid_ea417361752c4065ab1cfb876d5ea823, 1);
                Grid_ea417361752c4065ab1cfb876d5ea823.Visibility = Bridge.global.Windows.UI.Xaml.Visibility.Collapsed;

                this.RegisterName$1("QWCSideBars", Grid_16f0b6813c034068981ae6b671ab14b6);
                Grid_16f0b6813c034068981ae6b671ab14b6.Name = "QWCSideBars";
                Bridge.global.Windows.UI.Xaml.Controls.Grid.SetRow(Grid_16f0b6813c034068981ae6b671ab14b6, 1);
                Grid_16f0b6813c034068981ae6b671ab14b6.Visibility = Bridge.global.Windows.UI.Xaml.Visibility.Collapsed;

                Grid_b500d5b20d014ae69dd3a523a2294d1a.Children.add(Grid_53950a6ecd6243d181da2940f006e5aa);
                Grid_b500d5b20d014ae69dd3a523a2294d1a.Children.add(WrapPanel_8f6d90c5b84940a384cadcb071f4005e);
                Grid_b500d5b20d014ae69dd3a523a2294d1a.Children.add(Grid_ea417361752c4065ab1cfb876d5ea823);
                Grid_b500d5b20d014ae69dd3a523a2294d1a.Children.add(Grid_16f0b6813c034068981ae6b671ab14b6);


                this.Content = Grid_b500d5b20d014ae69dd3a523a2294d1a;

                var DataContextExtension_8454268f73a046e48055a31e7e20df6c = new Bridge.global.APLExtension.DataContextExtension.ctor();
                DataContextExtension_8454268f73a046e48055a31e7e20df6c.Instance = "qwc_Root";
                DataContextExtension_8454268f73a046e48055a31e7e20df6c.Class = "qwc_Root";
                DataContextExtension_8454268f73a046e48055a31e7e20df6c.NS = "DataBinding";




                this.QWCGrid = Grid_53950a6ecd6243d181da2940f006e5aa;
                this.QWCIcons = WrapPanel_8f6d90c5b84940a384cadcb071f4005e;
                this.QWCHidden = Grid_ea417361752c4065ab1cfb876d5ea823;
                this.QWCSideBars = Grid_16f0b6813c034068981ae6b671ab14b6;
                this.Top = this;

                var customMarkupValue_1097948483294c72a2b30485289dba68 = DataContextExtension_8454268f73a046e48055a31e7e20df6c.ProvideValue(new Bridge.global.System.ServiceProvider.ctor(this, Bridge.global.Windows.UI.Xaml.FrameworkElement.DataContextProperty));
                if (Bridge.is(customMarkupValue_1097948483294c72a2b30485289dba68, Windows.UI.Xaml.Data.Binding)) {
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(this, Bridge.global.Windows.UI.Xaml.FrameworkElement.DataContextProperty, Bridge.cast(customMarkupValue_1097948483294c72a2b30485289dba68, Windows.UI.Xaml.Data.Binding));
                } else {
                    this.DataContext = customMarkupValue_1097948483294c72a2b30485289dba68;
                }

            }
        }
    });

    Bridge.define("QWC.NQ", {
        statics: {
            fields: {
                LockInstances: null
            },
            ctors: {
                init: function () {
                    this.LockInstances = { };
                }
            },
            methods: {
                DoAddVisual: function (ds, actthis) {
                    var obj = APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, actthis);
                    var $arguments = System.Array.init([ds], System.Object);
                    var assembly = APLExtension.APL.GetAssembly("DataBinding", actthis);

                    var cl = APLExtension.APL.GetClassByName(ds.Instance);
                    if (System.String.contains(cl,"_Data")) {
                        cl = cl.substr(0, ((cl.length - 5) | 0));
                    }
                    var type = Bridge.Reflection.getType("DataBinding." + (cl || ""), assembly);

                    var method = Bridge.Reflection.getMembers(type, 8, 284, "DoAddVisual");

                    if (APLExtension.Utils.IsStatic(method)) {
                        return Bridge.cast(Bridge.Reflection.midel(method, null).apply(null, Bridge.unbox($arguments)), System.String);
                    } else {
                        return Bridge.cast(Bridge.Reflection.midel(method, Bridge.unbox(Bridge.cast(obj, APLExtension.MJH_CommonData).MJH_Class)).apply(null, Bridge.unbox($arguments)), System.String);
                    }
                },
                DoRunEvent: function (ds, actthis) {
                    var obj = APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, actthis);
                    var $arguments = System.Array.init([ds], System.Object);
                    var assembly = APLExtension.APL.GetAssembly("DataBinding", actthis);

                    var cl = APLExtension.APL.GetClassByName(ds.Instance);
                    if (System.String.contains(cl,"_Data")) {
                        cl = cl.substr(0, ((cl.length - 5) | 0));
                    }
                    var type = Bridge.Reflection.getType("DataBinding." + (cl || ""), assembly);

                    var method = Bridge.Reflection.getMembers(type, 8, 284, "DoRunEvent");

                    var result = "";
                    if (method != null) {
                        if (APLExtension.Utils.IsStatic(method)) {
                            result = Bridge.cast(Bridge.Reflection.midel(method, null).apply(null, Bridge.unbox($arguments)), System.String);
                        } else {
                            result = Bridge.cast(Bridge.Reflection.midel(method, Bridge.unbox(Bridge.cast(obj, APLExtension.MJH_CommonData).MJH_Class)).apply(null, Bridge.unbox($arguments)), System.String);
                        }
                    }
                    return result;
                },
                DoRunMethod: function (ds, actthis) {
                    var result = "";
                    var obj = APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, actthis);
                    var $arguments = System.Array.init([ds], System.Object);
                    var assembly = APLExtension.APL.GetAssembly("DataBinding", actthis);
                    var cl = APLExtension.APL.GetClassByName(ds.Instance);

                    if (System.String.contains(cl,"_Data")) {
                        cl = cl.substr(0, ((cl.length - 5) | 0));
                    }
                    var type = Bridge.Reflection.getType("DataBinding." + (cl || ""), assembly);
                    var method = Bridge.Reflection.getMembers(type, 8, 284, "Do" + (ds.Data || ""));

                    if (method != null) {
                        if (APLExtension.Utils.IsStatic(method)) {
                            result = Bridge.cast(Bridge.Reflection.midel(method, null).apply(null, Bridge.unbox($arguments)), System.String);
                        } else {
                            result = Bridge.cast(Bridge.Reflection.midel(method, Bridge.unbox(Bridge.cast(obj, APLExtension.MJH_CommonData).MJH_Class)).apply(null, Bridge.unbox($arguments)), System.String);
                        }
                    }
                    return result;
                },
                DoGetSerialNo: function (ds, actthis) {
                    var obj = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, actthis), APLExtension.MJH_CommonData);
                    var result = obj.MJH_SerialNo;
                    return result;
                },
                DoDelete: function (ds, actthis) {
                    if (Bridge.referenceEquals(ds.Class, "qwc_Root")) {
                        return ("");
                    }
                    var result = "";

                    var obj = APLExtension.APL.GetInstance(ds.SerialNo);
                    var $arguments = System.Array.init([ds], System.Object);
                    var assembly = APLExtension.APL.GetAssembly("DataBinding", actthis);
                    if (0 !== ds.SerialNo.length) {
                        var cl = APLExtension.APL.GetClassBySerialNo(ds.SerialNo);
                        if (0 !== cl.length) {
                            if (System.String.contains(cl,"_Data")) {
                                cl = cl.substr(0, ((cl.length - 5) | 0));
                            }
                            var type = Bridge.Reflection.getType("DataBinding." + (cl || ""), assembly);

                            var method = Bridge.Reflection.getMembers(type, 8, 284, "DoDelete");

                            if (method != null) {
                                if (APLExtension.Utils.IsStatic(method)) {
                                    result = Bridge.cast(Bridge.Reflection.midel(method, null).apply(null, Bridge.unbox($arguments)), System.String);
                                } else {
                                    var self = Bridge.cast(obj, APLExtension.MJH_CommonData);
                                    result = Bridge.cast(Bridge.Reflection.midel(method, Bridge.unbox(self.MJH_Class)).apply(null, Bridge.unbox($arguments)), System.String);
                                }
                            }
                        }
                        return result;
                    } else {
                        return "";
                    }
                },
                DoSetAccelerator: function (ds, actthis) {
                    var key = System.Convert.toInt32(ds.Args);
                    if (key !== 0) {
                        APLExtension.Accelerator.Add(key, ds.Instance);
                    } else {
                        APLExtension.Accelerator.Remove(key, ds.Instance);

                    }
                    return "";
                }
            }
        }
    });
});

//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAiZmlsZSI6ICJRV0MuanMiLAogICJzb3VyY2VSb290IjogIiIsCiAgInNvdXJjZXMiOiBbIm9iai9EZWJ1Zy9BcHAueGFtbC5nLmNzIiwib2JqL0RlYnVnL01haW5QYWdlLnhhbWwuZy5jcyIsIkFwcC54YW1sLmNzIiwiTWFpblBhZ2UueGFtbC5jcyIsIk1KSF9FbnF1ZXVlLmNzIl0sCiAgIm5hbWVzIjogWyIiXSwKICAibWFwcGluZ3MiOiAiOzs7Ozs7Ozs7Ozs7O29CQVFRQSxXQUEyQkEsQUFBT0E7b0JBQ2xDQSxPQUFPQSxtRUFBNkRBOzs7Ozs7Ozs7O29CQ0RwRUEsV0FBMkJBLEFBQU9BO29CQUNsQ0EsT0FBT0EsbUVBQTZEQTs7Ozs7Ozs7O1lEaXlDeEVBLElBQUlBOzs7Ozs7Ozs7O2dCRXZ4Q0lBO2dCQUVBQTtvQkFFSUEsUUFBNEJBLElBQUlBO29CQUNoQ0EscUVBQStDQTtvQkFDL0NBLDZEQUF1Q0E7Ozs7Z0JBRTNDQSxlQUFlQSxJQUFJQTtnQkFDNUJBLCtDQUErRUE7Z0JBQ3RFQSx5Q0FBeUJBOzs7O21DQUVwQkEsR0FBVUE7Z0JBQzNCQSxTQUFrQkEsWUFBZUEsQUFBQ0EsWUFBU0E7Z0JBQzNDQTtnQkFDQUE7Z0JBQ0FBLFdBQWdCQSxnRkFBdURBO2dCQUN2RUE7O21DQUVpQkEsR0FBVUE7Z0JBQzNCQSxTQUFrQkEsWUFBY0EsQUFBQ0EsWUFBUUE7Z0JBQ3pDQTtnQkFDQUEsSUFBSUEsTUFBS0E7b0JBQVVBOztvQkFDZEE7O2dCQUNMQSxXQUFnQkEsZ0ZBQXVEQTtnQkFDdkVBOzswQ0FFd0JBLEdBQVVBO2dCQUNsQ0EsU0FBa0JBLFlBQWNBLEFBQUNBLFlBQVFBO2dCQUN6Q0EsVUFBY0E7Z0JBQ2RBO2dCQUNBQSxXQUEyQ0EsdUJBQWVBO2dCQUMxREE7Z0JBQ0FBO2dCQUNBQSxXQUFnQkEsZ0ZBQXVEQTtnQkFDdkVBLG9CQUFvQkE7O3FDQUVEQSxHQUFVQTtnQkFDN0JBLFNBQWtCQSxZQUFjQSxBQUFDQSxZQUFRQTtnQkFDekNBO2dCQUNBQTtnQkFDQUEsVUFBY0E7Z0JBQ2RBOzs7O2dCRnBCWUEsSUFBSUE7b0JBQ0FBOztnQkFDSkE7OztnQkFHQUEsSUFBSUE7b0JBRUFBLEFBQUNBLFlBQW1DQSxBQUFRQTs7OztnQkFLNURBO2dCQUNBQTtnQkFDQUE7Z0JBQ0FBOzs7Z0JBR0FBLDBEQUEwREEsSUFBSUE7Z0JBQzlEQSxpQkFBaUJBO2dCQUNqQkEsb0RBQW9EQSxJQUFJQTs7Z0JBRXhEQSxvREFBb0RBLElBQUlBOztnQkFFeERBLDJEQUEyREEsSUFBSUE7O2dCQUUvREEseURBQXlEQSxJQUFJQTs7Z0JBRTdEQSx3REFBd0RBLElBQUlBOztnQkFFNURBLHlEQUF5REEsSUFBSUE7O2dCQUU3REEsNERBQTREQSxJQUFJQTs7Z0JBRWhFQSw4REFBOERBLElBQUlBOztnQkFFbEVBLGlFQUFpRUEsSUFBSUE7O2dCQUVyRUEsMkRBQTJEQSxJQUFJQTs7Z0JBRS9EQSw0REFBNERBLElBQUlBOztnQkFFaEVBLDREQUE0REEsSUFBSUE7O2dCQUVoRUEsOERBQThEQSxJQUFJQTs7Z0JBRWxFQSwrREFBK0RBLElBQUlBOztnQkFFbkVBLHVEQUF1REEsSUFBSUE7O2dCQUUzREEsdURBQXVEQSxJQUFJQTs7Z0JBRTNEQSxzREFBc0RBLElBQUlBOztnQkFFMURBLHNEQUFzREEsSUFBSUE7O2dCQUUxREE7O2dCQUVBQTs7Z0JBRUFBOztnQkFFQUE7O2dCQUVBQTs7Z0JBRUFBOztnQkFFQUE7O2dCQUVBQTs7Z0JBRUFBOztnQkFFQUE7O2dCQUVBQTs7Z0JBRUFBLDZDQUE2Q0EsSUFBSUE7Z0JBQ2pEQSxvREFBb0RBLEFBQU9BO2dCQUMzREEsOENBQThDQSxJQUFJQTtnQkFDbERBLG1EQUFtREE7Z0JBQ25EQSxnREFBZ0RBLElBQUlBLDJEQUE4Q0EsVUFBSUEseUNBQWlDQSxVQUFhQSxZQUFlQSxZQUFlQTs7Z0JBRWxMQSw4Q0FBOENBLElBQUlBO2dCQUNsREEsbURBQW1EQTtnQkFDbkRBOztnQkFFQUEsOENBQThDQSxJQUFJQTtnQkFDbERBLG1EQUFtREE7Z0JBQ25EQSxnREFBZ0RBOztnQkFFaERBLDhDQUE4Q0EsSUFBSUE7Z0JBQ2xEQSxtREFBbURBO2dCQUNuREEsZ0RBQWdEQTs7Z0JBRWhEQSw4Q0FBOENBLElBQUlBO2dCQUNsREEsbURBQW1EQTtnQkFDbkRBLHVEQUF1REEsSUFBSUE7Z0JBQzNEQSw4REFBOERBLEFBQU9BO2dCQUNyRUEseUZBQXlGQSxBQUFpRkE7O29CQUUxS0Esd0RBQXdEQSxJQUFJQTtvQkFDNURBLGtFQUFrRUE7b0JBQ2xFQSxtREFBbURBLElBQUlBO29CQUN2REEsbURBQW1EQSxJQUFJQTtvQkFDdkRBLHdEQUF3REEsSUFBSUE7b0JBQzVEQSw0Q0FBNENBLElBQUlBO29CQUNoREEsOENBQThDQSxJQUFJQTtvQkFDbERBLHNEQUFzREEsSUFBSUE7b0JBQzFEQSw4Q0FBOENBLElBQUlBO29CQUNsREEsOENBQThDQSxJQUFJQTtvQkFDbERBLDhDQUE4Q0EsSUFBSUE7b0JBQ2xEQSw4Q0FBOENBLElBQUlBO29CQUNsREEsOENBQThDQSxJQUFJQTtvQkFDbERBLDhDQUE4Q0EsSUFBSUE7b0JBQ2xEQSx3REFBd0RBLElBQUlBO29CQUM1REEsOENBQThDQSxJQUFJQTtvQkFDbERBLDhDQUE4Q0EsSUFBSUE7b0JBQ2xEQSw0Q0FBNENBLElBQUlBO29CQUNoREEsb0ZBQW9GQTtvQkFDcEZBO29CQUNBQSw4REFBOERBLElBQUlBO29CQUNsRUEsMkZBQTJGQTtvQkFDM0ZBO29CQUNBQSx3RkFBd0ZBO29CQUN4RkE7b0JBQ0FBLGtEQUFrREEsSUFBSUE7b0JBQ3REQSxxRUFBcUVBLElBQUlBO29CQUN6RUEsdUVBQWlFQTtvQkFDakVBLDhEQUE4REEsSUFBSUE7b0JBQ2xFQSxxREFBcURBLElBQUlBOztvQkFFekRBLGdFQUFnRUE7OztvQkFHaEVBLDZFQUE2RUE7OztvQkFHN0VBLHFFQUFxRUEsSUFBSUE7b0JBQ3pFQSx1RUFBaUVBO29CQUNqRUEsOERBQThEQSxJQUFJQTtvQkFDbEVBOztvQkFFQUEsNkVBQTZFQTs7O29CQUc3RUEseURBQXlEQTtvQkFDekRBLHlEQUF5REE7OztvQkFHekRBLDBEQUEwREE7OztvQkFHMURBLHFGQUFxRkE7b0JBQ3JGQTs7b0JBRUFBLDJFQUE2REE7b0JBQzdEQSwyRUFBNkRBOzs7b0JBRzdEQSxtR0FBbUdBOztvQkFFbkdBLHVGQUF1RkE7b0JBQ3ZGQTtvQkFDQUEsNERBQTREQTtvQkFDNURBLDBEQUEwREE7b0JBQzFEQSwrQ0FBK0NBLElBQUlBO29CQUNuREEsK0NBQStDQSxJQUFJQTtvQkFDbkRBLGdEQUFnREEsSUFBSUE7b0JBQ3BEQSxzREFBc0RBLElBQUlBO29CQUMxREEsdURBQXVEQTs7b0JBRXZEQSwwREFBMERBOzs7b0JBRzFEQSx5REFBeURBOztvQkFFekRBLCtDQUErQ0EsSUFBSUE7b0JBQ25EQSxnREFBZ0RBLElBQUlBO29CQUNwREEsc0RBQXNEQSxJQUFJQTtvQkFDMURBLHVEQUF1REE7O29CQUV2REEsMERBQTBEQTs7O29CQUcxREEseURBQXlEQTs7O29CQUd6REEsMkZBQTJGQTtvQkFDM0ZBO29CQUNBQSxnR0FBZ0dBO29CQUNoR0E7b0JBQ0FBLHFEQUFxREEsSUFBSUEsMkRBQThDQSxXQUFJQSwwQ0FBaUNBLGFBQWVBLGFBQWVBLGFBQWVBO29CQUN6TEEsdURBQXVEQSxJQUFJQTtvQkFDM0RBLDRDQUE0Q0EsSUFBSUE7b0JBQ2hEQSxxREFBcURBLElBQUlBO29CQUN6REEsd0RBQXdEQSxJQUFJQSxxREFBd0NBOztvQkFFcEdBLHFEQUFxREEsSUFBSUE7b0JBQ3pEQSx3REFBd0RBLElBQUlBLHFEQUF3Q0E7O29CQUVwR0EseURBQXlEQTtvQkFDekRBLHlEQUF5REE7O29CQUV6REEsc0ZBQXNGQTtvQkFDdEZBO29CQUNBQSxnREFBZ0RBO29CQUNoREEsc0RBQXNEQSxJQUFJQSwyREFBOENBLFdBQUlBLDBDQUFpQ0EsYUFBZUEsYUFBZUEsYUFBZUE7b0JBQzFMQSwwREFBMERBLElBQUlBO29CQUM5REEscURBQXFEQSxJQUFJQSwyREFBOENBLFdBQUlBLDBDQUFpQ0EsYUFBZUEsYUFBZUEsYUFBZUE7b0JBQ3pMQSw0Q0FBNENBLElBQUlBO29CQUNoREEsd0RBQXdEQSxJQUFJQTtvQkFDNURBLDBEQUEwREEsSUFBSUEscURBQXdDQTs7b0JBRXRHQSx3REFBd0RBLElBQUlBO29CQUM1REEsMERBQTBEQSxJQUFJQSxxREFBd0NBOztvQkFFdEdBLHdEQUF3REEsSUFBSUE7b0JBQzVEQSwwREFBMERBLElBQUlBLHFEQUF3Q0E7O29CQUV0R0Esd0RBQXdEQSxJQUFJQTtvQkFDNURBLDBEQUEwREEsSUFBSUEscURBQXdDQTs7b0JBRXRHQSx3REFBd0RBLElBQUlBO29CQUM1REEsMERBQTBEQSxJQUFJQSxxREFBd0NBOztvQkFFdEdBLHdEQUF3REEsSUFBSUE7b0JBQzVEQSwwREFBMERBLElBQUlBLHFEQUF3Q0E7O29CQUV0R0Esd0RBQXdEQSxJQUFJQTtvQkFDNURBLDBEQUEwREEsSUFBSUEscURBQXdDQTs7b0JBRXRHQSw0REFBNERBO29CQUM1REEsNERBQTREQTtvQkFDNURBLDREQUE0REE7b0JBQzVEQSw0REFBNERBO29CQUM1REEsNERBQTREQTtvQkFDNURBLDREQUE0REE7b0JBQzVEQSw0REFBNERBOztvQkFFNURBLDBGQUEwRkE7b0JBQzFGQTtvQkFDQUEsOERBQThEQTtvQkFDOURBLDREQUE0REE7b0JBQzVEQSxxRUFBcUVBO29CQUNyRUEsbUVBQW1FQTtvQkFDbkVBO29CQUNBQSxrREFBa0RBLElBQUlBO29CQUN0REEsNkNBQTZDQSxJQUFJQTtvQkFDakRBLCtDQUErQ0EsSUFBSUE7b0JBQ25EQSxnREFBZ0RBLElBQUlBOzs7O29CQUlwREEsa0RBQWtEQTs7b0JBRWxEQSwrQ0FBK0NBLElBQUlBO29CQUNuREEsZ0RBQWdEQSxJQUFJQTs7OztvQkFJcERBLHFGQUFxRkE7b0JBQ3JGQTtvQkFDQUEsc0RBQWdEQTtvQkFDaERBLHNFQUFzRUE7b0JBQ3RFQSxvRUFBb0VBO29CQUNwRUEseURBQXlEQSxJQUFJQTtvQkFDN0RBLCtDQUErQ0EsSUFBSUE7b0JBQ25EQSxnREFBZ0RBLElBQUlBO29CQUNwREEsc0RBQXNEQSxJQUFJQTtvQkFDMURBLHVEQUF1REE7O29CQUV2REEsMERBQTBEQTs7O29CQUcxREEseURBQXlEQTs7O29CQUd6REEsMEZBQTBGQTtvQkFDMUZBO29CQUNBQSw4REFBOERBO29CQUM5REEsNERBQTREQTtvQkFDNURBLHNEQUFnREE7b0JBQ2hEQSxxRUFBcUVBO29CQUNyRUEsbUVBQW1FQTtvQkFDbkVBO29CQUNBQSxrREFBa0RBLElBQUlBO29CQUN0REEsNkNBQTZDQSxJQUFJQTtvQkFDakRBLCtDQUErQ0EsSUFBSUE7b0JBQ25EQSxnREFBZ0RBLElBQUlBOzs7O29CQUlwREEsa0RBQWtEQTs7b0JBRWxEQSwrQ0FBK0NBLElBQUlBO29CQUNuREEsZ0RBQWdEQSxJQUFJQTs7OztvQkFJcERBLHlGQUF5RkE7b0JBQ3pGQTtvQkFDQUEsOERBQThEQTtvQkFDOURBLDREQUE0REE7b0JBQzVEQSxzREFBZ0RBO29CQUNoREEscUVBQXFFQTtvQkFDckVBLG1FQUFtRUE7b0JBQ25FQTtvQkFDQUEsa0RBQWtEQSxJQUFJQTtvQkFDdERBLGlEQUFpREE7b0JBQ2pEQSw2Q0FBNkNBLElBQUlBO29CQUNqREEsK0NBQStDQSxJQUFJQTtvQkFDbkRBLGdEQUFnREEsSUFBSUE7Ozs7b0JBSXBEQSxrREFBa0RBOztvQkFFbERBLCtDQUErQ0EsSUFBSUE7b0JBQ25EQSxnREFBZ0RBLElBQUlBOzs7O29CQUlwREEseUZBQXlGQTtvQkFDekZBO29CQUNBQSw4REFBOERBO29CQUM5REEsNERBQTREQTtvQkFDNURBLHNEQUFnREE7b0JBQ2hEQSxxRUFBcUVBO29CQUNyRUEsbUVBQW1FQTtvQkFDbkVBO29CQUNBQSxrREFBa0RBLElBQUlBO29CQUN0REEsaURBQWlEQTtvQkFDakRBLDZDQUE2Q0EsSUFBSUE7b0JBQ2pEQSwrQ0FBK0NBLElBQUlBO29CQUNuREEsZ0RBQWdEQSxJQUFJQTs7OztvQkFJcERBLGtEQUFrREE7O29CQUVsREEsK0NBQStDQSxJQUFJQTtvQkFDbkRBLGdEQUFnREEsSUFBSUE7Ozs7b0JBSXBEQSxnR0FBZ0dBO29CQUNoR0E7b0JBQ0FBLDhEQUE4REE7b0JBQzlEQSw0REFBNERBO29CQUM1REEsc0RBQWdEQTtvQkFDaERBLHFFQUFxRUE7b0JBQ3JFQSxtRUFBbUVBO29CQUNuRUE7b0JBQ0FBLGtEQUFrREEsSUFBSUE7b0JBQ3REQSxpREFBaURBO29CQUNqREEsNkNBQTZDQSxJQUFJQTtvQkFDakRBLCtDQUErQ0EsSUFBSUE7b0JBQ25EQSxnREFBZ0RBLElBQUlBOzs7O29CQUlwREEsa0RBQWtEQTs7b0JBRWxEQSwrQ0FBK0NBLElBQUlBO29CQUNuREEsZ0RBQWdEQSxJQUFJQTs7OztvQkFJcERBLDJGQUEyRkE7b0JBQzNGQTtvQkFDQUEsOERBQThEQTtvQkFDOURBLDREQUE0REE7b0JBQzVEQSxzREFBZ0RBO29CQUNoREEscUVBQXFFQTtvQkFDckVBLG1FQUFtRUE7b0JBQ25FQTtvQkFDQUEsa0RBQWtEQSxJQUFJQTtvQkFDdERBLGlEQUFpREE7b0JBQ2pEQSw2Q0FBNkNBLElBQUlBO29CQUNqREEsK0NBQStDQSxJQUFJQTtvQkFDbkRBLGdEQUFnREEsSUFBSUE7Ozs7b0JBSXBEQSxrREFBa0RBOztvQkFFbERBLCtDQUErQ0EsSUFBSUE7b0JBQ25EQSxnREFBZ0RBLElBQUlBOzs7O29CQUlwREEsbURBQW1EQTtvQkFDbkRBLG1EQUFtREE7b0JBQ25EQSxtREFBbURBO29CQUNuREEsbURBQW1EQTtvQkFDbkRBLG1EQUFtREE7b0JBQ25EQSxtREFBbURBO29CQUNuREEsbURBQW1EQTs7O29CQUduREEsZ0RBQWdEQTs7b0JBRWhEQSwrQ0FBK0NBLElBQUlBO29CQUNuREEsZ0RBQWdEQSxJQUFJQTs7OztvQkFJcERBLDhDQUE4Q0EsSUFBSUE7b0JBQ2xEQSxtREFBNkNBO29CQUM3Q0EsMERBQTBEQSxJQUFJQTtvQkFDOURBLG9HQUFvR0E7b0JBQ3BHQTtvQkFDQUE7b0JBQ0FBLCtDQUErQ0EsSUFBSUE7b0JBQ25EQSxnREFBZ0RBLElBQUlBO29CQUNwREEsc0RBQXNEQSxJQUFJQTtvQkFDMURBLHVEQUF1REE7O29CQUV2REEsMERBQTBEQTs7O29CQUcxREEseURBQXlEQTs7b0JBRXpEQSwrQ0FBK0NBLElBQUlBO29CQUNuREEsZ0RBQWdEQSxJQUFJQTtvQkFDcERBLHNEQUFzREEsSUFBSUE7b0JBQzFEQSx1REFBdURBOztvQkFFdkRBLDBEQUEwREE7OztvQkFHMURBLHlEQUF5REE7O29CQUV6REEsK0NBQStDQSxJQUFJQTtvQkFDbkRBLGdEQUFnREEsSUFBSUE7OztvQkFHcERBLCtDQUErQ0EsSUFBSUE7b0JBQ25EQSxnREFBZ0RBLElBQUlBOzs7b0JBR3BEQSwrQ0FBK0NBLElBQUlBO29CQUNuREEsZ0RBQWdEQSxJQUFJQTtvQkFDcERBLHNEQUFzREEsSUFBSUE7b0JBQzFEQSx1REFBdURBOztvQkFFdkRBLDBEQUEwREE7OztvQkFHMURBLHlEQUF5REE7O29CQUV6REEsK0NBQStDQSxJQUFJQTtvQkFDbkRBLGdEQUFnREEsSUFBSUE7b0JBQ3BEQSxzREFBc0RBLElBQUlBO29CQUMxREEsdURBQXVEQTs7b0JBRXZEQSwwREFBMERBOzs7b0JBRzFEQSx5REFBeURBOzs7b0JBR3pEQSxnREFBZ0RBOztvQkFFaERBLCtDQUErQ0EsSUFBSUE7b0JBQ25EQSxnREFBZ0RBLElBQUlBOzs7b0JBR3BEQSwrQ0FBK0NBLElBQUlBO29CQUNuREEsZ0RBQWdEQSxJQUFJQTs7O29CQUdwREEsK0NBQStDQSxJQUFJQTtvQkFDbkRBLGdEQUFnREEsSUFBSUE7b0JBQ3BEQSxzREFBc0RBLElBQUlBO29CQUMxREEsdURBQXVEQTs7b0JBRXZEQSwwREFBMERBOzs7b0JBRzFEQSx5REFBeURBOztvQkFFekRBLCtDQUErQ0EsSUFBSUE7b0JBQ25EQSxnREFBZ0RBLElBQUlBO29CQUNwREEsc0RBQXNEQSxJQUFJQTtvQkFDMURBLHVEQUF1REE7O29CQUV2REEsMERBQTBEQTs7O29CQUcxREEseURBQXlEQTs7O29CQUd6REEsbURBQW1EQTtvQkFDbkRBLG1EQUFtREE7OztvQkFHbkRBLGdEQUFnREE7O29CQUVoREEsK0NBQStDQSxJQUFJQTtvQkFDbkRBLGdEQUFnREEsSUFBSUE7b0JBQ3BEQSxzREFBc0RBLElBQUlBO29CQUMxREEsdURBQXVEQTs7b0JBRXZEQSwwREFBMERBOzs7b0JBRzFEQSx5REFBeURBOztvQkFFekRBLCtDQUErQ0EsSUFBSUE7b0JBQ25EQSxnREFBZ0RBLElBQUlBO29CQUNwREEsc0RBQXNEQSxJQUFJQTtvQkFDMURBLHVEQUF1REE7O29CQUV2REEsMERBQTBEQTs7O29CQUcxREEseURBQXlEQTs7O29CQUd6REEsZ0RBQWdEQTs7O29CQUdoREEsbURBQW1EQTtvQkFDbkRBLG1EQUFtREE7O29CQUVuREEsK0NBQStDQSxJQUFJQTtvQkFDbkRBLGdEQUFnREEsSUFBSUE7b0JBQ3BEQSxzREFBc0RBLElBQUlBO29CQUMxREEsdURBQXVEQTs7b0JBRXZEQSwwREFBMERBOzs7b0JBRzFEQSx5REFBeURBOztvQkFFekRBLCtDQUErQ0EsSUFBSUE7b0JBQ25EQSxnREFBZ0RBLElBQUlBO29CQUNwREEsc0RBQXNEQSxJQUFJQTtvQkFDMURBLHVEQUF1REE7O29CQUV2REEsMERBQTBEQTs7O29CQUcxREEseURBQXlEQTs7b0JBRXpEQSwrQ0FBK0NBLElBQUlBO29CQUNuREEsZ0RBQWdEQSxJQUFJQTtvQkFDcERBLHNEQUFzREEsSUFBSUE7b0JBQzFEQSx1REFBdURBOztvQkFFdkRBLDBEQUEwREE7OztvQkFHMURBLHlEQUF5REE7O29CQUV6REEsK0NBQStDQSxJQUFJQTtvQkFDbkRBLGdEQUFnREEsSUFBSUE7b0JBQ3BEQSxzREFBc0RBLElBQUlBO29CQUMxREEsdURBQXVEQTs7b0JBRXZEQSwwREFBMERBOzs7b0JBRzFEQSx5REFBeURBOzs7b0JBR3pEQSxnRUFBMERBLHVDQUF1Q0EsaUVBQTJEQTtvQkFDNUpBLGdFQUEwREEsdUNBQXVDQSx5REFBbURBO29CQUNwSkEsZ0VBQTBEQSx3Q0FBd0NBLDZEQUF1REE7b0JBQ3pKQSxnRUFBMERBLHlDQUF5Q0EsNERBQXNEQTtvQkFDekpBLGdFQUEwREEsaURBQWlEQSx1RUFBaUVBO29CQUM1S0EsZ0VBQTBEQSx3Q0FBd0NBLDZEQUF1REE7b0JBQ3pKQSxnRUFBMERBLHlDQUF5Q0EsNERBQXNEQTtvQkFDekpBLGdFQUEwREEsd0NBQXdDQSw2REFBdURBO29CQUN6SkEsZ0VBQTBEQSx5Q0FBeUNBLDREQUFzREE7b0JBQ3pKQSxnRUFBMERBLHdDQUF3Q0EsNkRBQXVEQTtvQkFDekpBLGdFQUEwREEseUNBQXlDQSw0REFBc0RBO29CQUN6SkEsZ0VBQTBEQSx3Q0FBd0NBLDZEQUF1REE7b0JBQ3pKQSxnRUFBMERBLHlDQUF5Q0EsNERBQXNEQTtvQkFDekpBLGdFQUEwREEsd0NBQXdDQSw2REFBdURBO29CQUN6SkEsZ0VBQTBEQSx5Q0FBeUNBLDREQUFzREE7b0JBQ3pKQSxnRUFBMERBLHlDQUF5Q0EsNERBQXNEQTtvQkFDekpBLGdFQUEwREEsbURBQW1EQSx1RUFBaUVBO29CQUM5S0EsZ0VBQTBEQSxtREFBbURBLCtFQUF5RUE7b0JBQ3RMQSxnRUFBMERBLG1EQUFtREEsOERBQXdEQTtvQkFDcktBLGdFQUEwREEsbURBQW1EQSwrREFBeURBO29CQUN0S0EsZ0VBQTBEQSxtREFBbURBLDRFQUFzRUE7b0JBQ25MQSxnRUFBMERBLG1EQUFtREEsMEVBQW9FQTtvQkFDakxBLGdFQUEwREEseUNBQXlDQSwrREFBeURBO29CQUM1SkEsZ0VBQTBEQSx5Q0FBeUNBLDhEQUF3REE7b0JBQzNKQSxnRUFBMERBLHlDQUF5Q0Esa0VBQTREQTtvQkFDL0pBLGdFQUEwREEseUNBQXlDQSxtRUFBNkRBO29CQUNoS0EsZ0VBQTBEQSx5Q0FBeUNBLHVFQUFpRUE7b0JBQ3BLQSxnRUFBMERBLHlDQUF5Q0EsbUVBQTZEQTtvQkFDaEtBLGdFQUEwREEsdUNBQXVDQSwrREFBeURBO29CQUMxSkEsZ0VBQTBEQSx1Q0FBdUNBLDhEQUF3REE7b0JBQ3pKQSxnRUFBMERBLHVDQUF1Q0EsNEVBQXNFQTtvQkFDdktBLGdFQUEwREEsdUNBQXVDQSwwRUFBb0VBOztvQkFFcktBLDJFQUFxRUEsZ0VBQ2pFQSxJQUFJQSw4RUFHQUEsNEZBQ0FBLHlGQUNBQSxrR0FDQUEsOEZBQ0FBO29CQUNSQSxtRUFBNkRBLGdFQUFnRUE7OztvQkFHN0hBLDJFQUFxRUEsZ0VBQ2pFQSxJQUFJQSwwRkFHQUEsNEZBQ0FBLHlGQUNBQSxrR0FDQUEsOEZBQ0FBO29CQUNSQSxtRUFBNkRBLGdFQUFnRUE7O29CQUU3SEEsb0VBQW9FQTtvQkFDcEVBLE9BQU9BOzs7Z0JBR1BBLGdEQUFnREE7OztnQkFHaERBLG1EQUFtREE7Z0JBQ25EQSxtREFBbURBO2dCQUNuREEsbURBQW1EQTtnQkFDbkRBLG1EQUFtREE7Z0JBQ25EQSxtREFBbURBOzs7Z0JBR25EQSw2Q0FBNkNBLElBQUlBO2dCQUNqREEsb0RBQW9EQSxBQUFPQTtnQkFDM0RBLDhDQUE4Q0EsSUFBSUE7Z0JBQ2xEQSxtREFBbURBO2dCQUNuREEsZ0RBQWdEQSxJQUFJQSwyREFBOENBLFVBQUlBLHlDQUFpQ0EsWUFBZUEsWUFBZUEsWUFBZUE7O2dCQUVwTEEsOENBQThDQSxJQUFJQTtnQkFDbERBLG1EQUFtREE7Z0JBQ25EQSxnREFBZ0RBLElBQUlBLDJEQUE4Q0EsVUFBSUEseUNBQWlDQSxZQUFlQSxVQUFhQSxVQUFhQTs7Z0JBRWhMQSw4Q0FBOENBLElBQUlBO2dCQUNsREEsbURBQW1EQTtnQkFDbkRBLGdEQUFnREEsSUFBSUE7O2dCQUVwREEsOENBQThDQSxJQUFJQTtnQkFDbERBLG1EQUFtREE7Z0JBQ25EQSxnREFBZ0RBLElBQUlBOztnQkFFcERBLDhDQUE4Q0EsSUFBSUE7Z0JBQ2xEQSxtREFBbURBO2dCQUNuREEsZ0RBQWdEQTs7Z0JBRWhEQSw4Q0FBOENBLElBQUlBO2dCQUNsREEsbURBQW1EQTtnQkFDbkRBLGdEQUFnREE7O2dCQUVoREEsOENBQThDQSxJQUFJQTtnQkFDbERBLG1EQUFtREE7Z0JBQ25EQSxnREFBZ0RBOztnQkFFaERBLDhDQUE4Q0EsSUFBSUE7Z0JBQ2xEQSxtREFBbURBO2dCQUNuREEsdURBQXVEQSxJQUFJQTtnQkFDM0RBLDhEQUE4REEsQUFBT0E7Z0JBQ3JFQSx5RkFBeUZBLEFBQWlGQTtvQkFFMUtBLHdEQUF3REEsSUFBSUE7b0JBQzVEQSxrRUFBa0VBO29CQUNsRUEsbURBQW1EQSxJQUFJQTtvQkFDdkRBLG1EQUFtREEsSUFBSUE7b0JBQ3ZEQSxtREFBbURBLElBQUlBO29CQUN2REEsbURBQW1EQSxJQUFJQTtvQkFDdkRBLHdEQUF3REEsSUFBSUE7b0JBQzVEQSx3REFBd0RBLElBQUlBO29CQUM1REEsOENBQThDQSxJQUFJQTtvQkFDbERBLDhDQUE4Q0EsSUFBSUE7b0JBQ2xEQSwyRkFBMkZBO29CQUMzRkE7b0JBQ0FBLDRGQUE0RkE7b0JBQzVGQTtvQkFDQUEsc0ZBQXNGQTtvQkFDdEZBOztvQkFFQUEsMkZBQTJGQTtvQkFDM0ZBO29CQUNBQSxrREFBa0RBLElBQUlBO29CQUN0REEscUVBQXFFQSxJQUFJQTtvQkFDekVBLHVFQUFpRUE7b0JBQ2pFQSw4REFBOERBLElBQUlBO29CQUNsRUEsa0VBQWtFQSxtRUFBNkRBLElBQUlBO29CQUNuSUE7O29CQUVBQSw2RUFBNkVBOzs7b0JBRzdFQSx5REFBeURBOzs7b0JBR3pEQSwwREFBMERBOzs7b0JBRzFEQSx1RkFBdUZBO29CQUN2RkE7b0JBQ0FBLGtEQUFrREEsSUFBSUE7b0JBQ3REQSxxRUFBcUVBLElBQUlBO29CQUN6RUEsdUVBQWlFQTtvQkFDakVBLDhEQUE4REEsSUFBSUE7b0JBQ2xFQSxrRUFBa0VBLG1FQUE2REEsSUFBSUE7b0JBQ25JQTs7b0JBRUFBLDZFQUE2RUE7OztvQkFHN0VBLHlEQUF5REE7OztvQkFHekRBLDBEQUEwREE7OztvQkFHMURBLHdGQUF3RkE7b0JBQ3hGQTtvQkFDQUEsa0RBQWtEQSxJQUFJQTtvQkFDdERBLHFFQUFxRUEsSUFBSUE7b0JBQ3pFQSx1RUFBaUVBO29CQUNqRUEsOERBQThEQSxJQUFJQTtvQkFDbEVBLGtFQUFrRUEsbUVBQTZEQSxJQUFJQTtvQkFDbklBOztvQkFFQUEsNkVBQTZFQTs7O29CQUc3RUEseURBQXlEQTs7O29CQUd6REEsMERBQTBEQTs7O29CQUcxREEsMkVBQTZEQTtvQkFDN0RBLDJFQUE2REE7b0JBQzdEQSwyRUFBNkRBO29CQUM3REEsMkVBQTZEQTs7O29CQUc3REEsbUdBQW1HQTs7b0JBRW5HQSwyRkFBMkZBO29CQUMzRkE7b0JBQ0FBLGdHQUFnR0E7b0JBQ2hHQTtvQkFDQUEsK0NBQStDQSxJQUFJQTtvQkFDbkRBLGdEQUFnREEsSUFBSUE7b0JBQ3BEQSxzREFBc0RBLElBQUlBO29CQUMxREEsdURBQXVEQTs7b0JBRXZEQSwwREFBMERBOzs7b0JBRzFEQSx5REFBeURBOztvQkFFekRBLCtDQUErQ0EsSUFBSUE7b0JBQ25EQSxnREFBZ0RBLElBQUlBO29CQUNwREEsc0RBQXNEQSxJQUFJQTtvQkFDMURBLHVEQUF1REE7O29CQUV2REEsMERBQTBEQTs7O29CQUcxREEseURBQXlEQTs7b0JBRXpEQSwrQ0FBK0NBLElBQUlBO29CQUNuREEsZ0RBQWdEQSxJQUFJQTtvQkFDcERBLHNEQUFzREEsSUFBSUE7b0JBQzFEQSx1REFBdURBOztvQkFFdkRBLDBEQUEwREE7OztvQkFHMURBLHlEQUF5REE7O29CQUV6REEsK0NBQStDQSxJQUFJQTtvQkFDbkRBLGdEQUFnREEsSUFBSUE7b0JBQ3BEQSxzREFBc0RBLElBQUlBO29CQUMxREEsdURBQXVEQTs7b0JBRXZEQSwwREFBMERBOzs7b0JBRzFEQSx5REFBeURBOztvQkFFekRBLCtDQUErQ0EsSUFBSUE7b0JBQ25EQSxnREFBZ0RBLElBQUlBO29CQUNwREEsc0RBQXNEQSxJQUFJQTtvQkFDMURBLHVEQUF1REE7O29CQUV2REEsMERBQTBEQTs7O29CQUcxREEseURBQXlEQTs7b0JBRXpEQSwrQ0FBK0NBLElBQUlBO29CQUNuREEsZ0RBQWdEQSxJQUFJQTtvQkFDcERBLHNEQUFzREEsSUFBSUE7b0JBQzFEQSx1REFBdURBOztvQkFFdkRBLDBEQUEwREE7OztvQkFHMURBLHlEQUF5REE7O29CQUV6REEsK0NBQStDQSxJQUFJQTtvQkFDbkRBLGdEQUFnREEsSUFBSUE7b0JBQ3BEQSxzREFBc0RBLElBQUlBO29CQUMxREEsdURBQXVEQTs7b0JBRXZEQSwwREFBMERBOzs7b0JBRzFEQSx5REFBeURBOztvQkFFekRBLCtDQUErQ0EsSUFBSUE7b0JBQ25EQSxnREFBZ0RBLElBQUlBOzs7O29CQUlwREEsZ0RBQWdEQTs7b0JBRWhEQSwrQ0FBK0NBLElBQUlBO29CQUNuREEsZ0RBQWdEQSxJQUFJQTtvQkFDcERBLHNEQUFzREEsSUFBSUE7b0JBQzFEQSx1REFBdURBOztvQkFFdkRBLDBEQUEwREE7OztvQkFHMURBLHlEQUF5REE7OztvQkFHekRBLGdEQUFnREE7O29CQUVoREEsK0NBQStDQSxJQUFJQTtvQkFDbkRBLGdEQUFnREEsSUFBSUE7b0JBQ3BEQSxzREFBc0RBLElBQUlBO29CQUMxREEsdURBQXVEQTs7b0JBRXZEQSwwREFBMERBOzs7b0JBRzFEQSx5REFBeURBOztvQkFFekRBLCtDQUErQ0EsSUFBSUE7b0JBQ25EQSxnREFBZ0RBLElBQUlBO29CQUNwREEsc0RBQXNEQSxJQUFJQTtvQkFDMURBLHVEQUF1REE7O29CQUV2REEsMERBQTBEQTs7O29CQUcxREEseURBQXlEQTs7b0JBRXpEQSwrQ0FBK0NBLElBQUlBO29CQUNuREEsZ0RBQWdEQSxJQUFJQTtvQkFDcERBLHNEQUFzREEsSUFBSUE7b0JBQzFEQSx1REFBdURBOztvQkFFdkRBLDBEQUEwREE7OztvQkFHMURBLHlEQUF5REE7O29CQUV6REEsK0NBQStDQSxJQUFJQTtvQkFDbkRBLGdEQUFnREEsSUFBSUE7b0JBQ3BEQSxzREFBc0RBLElBQUlBO29CQUMxREEsdURBQXVEQTs7b0JBRXZEQSwwREFBMERBOzs7b0JBRzFEQSx5REFBeURBOztvQkFFekRBLCtDQUErQ0EsSUFBSUE7b0JBQ25EQSxnREFBZ0RBLElBQUlBOzs7O29CQUlwREEsZ0VBQTBEQSxtREFBbURBLCtFQUF5RUE7b0JBQ3RMQSxnRUFBMERBLG1EQUFtREEsdUVBQWlFQTtvQkFDOUtBLGdFQUEwREEsbURBQW1EQSwrREFBeURBO29CQUN0S0EsZ0VBQTBEQSxtREFBbURBLDhEQUF3REE7b0JBQ3JLQSxnRUFBMERBLG1EQUFtREEsK0RBQXlEQTtvQkFDdEtBLGdFQUEwREEsbURBQW1EQSw0RUFBc0VBO29CQUNuTEEsZ0VBQTBEQSxtREFBbURBLDBFQUFvRUE7b0JBQ2pMQSxnRUFBMERBLG1EQUFtREEsNERBQXNEQTtvQkFDbktBLGdFQUEwREEseUNBQXlDQSxrRUFBNERBO29CQUMvSkEsZ0VBQTBEQSx5Q0FBeUNBLGtFQUE0REE7b0JBQy9KQSxnRUFBMERBLHlDQUF5Q0EsbUVBQTZEQTtvQkFDaEtBLGdFQUEwREEseUNBQXlDQSx1RUFBaUVBO29CQUNwS0EsZ0VBQTBEQSx5Q0FBeUNBLCtEQUF5REE7b0JBQzVKQSxnRUFBMERBLHlDQUF5Q0EsNERBQXNEQTs7b0JBRXpKQSwyRUFBcUVBLGdFQUNqRUEsSUFBSUEsOEVBR0FBLDRGQUNBQSx5RkFDQUEsa0dBQ0FBLDhGQUNBQTtvQkFDUkEsbUVBQTZEQSxnRUFBZ0VBOzs7b0JBRzdIQSwyRUFBcUVBLGdFQUNqRUEsSUFBSUEsOEVBR0FBLDRGQUNBQSx5RkFDQUEsa0dBQ0FBLDhGQUNBQTtvQkFDUkEsbUVBQTZEQSxnRUFBZ0VBOzs7b0JBRzdIQSwyRUFBcUVBLGdFQUNqRUEsSUFBSUEsOEVBR0FBLDRGQUNBQSx5RkFDQUEsa0dBQ0FBLDhGQUNBQTtvQkFDUkEsbUVBQTZEQSxnRUFBZ0VBOztvQkFFN0hBLG9FQUFvRUE7b0JBQ3BFQSxPQUFPQTs7O2dCQUdQQSxnREFBZ0RBOzs7Z0JBR2hEQSxtREFBbURBO2dCQUNuREEsbURBQW1EQTtnQkFDbkRBLG1EQUFtREE7Z0JBQ25EQSxtREFBbURBO2dCQUNuREEsbURBQW1EQTtnQkFDbkRBLG1EQUFtREE7Z0JBQ25EQSxtREFBbURBO2dCQUNuREEsbURBQW1EQTs7O2dCQUduREEsNEVBQXNFQTtnQkFDdEVBLDRFQUFzRUE7Z0JBQ3RFQSxtRkFBNkVBO2dCQUM3RUEsaUZBQTJFQTtnQkFDM0VBLGdGQUEwRUE7Z0JBQzFFQSxpRkFBMkVBO2dCQUMzRUEsb0ZBQThFQTtnQkFDOUVBLHNGQUFnRkE7Z0JBQ2hGQSx5RkFBbUZBO2dCQUNuRkEsbUZBQTZFQTtnQkFDN0VBLG9GQUE4RUE7Z0JBQzlFQSxvRkFBOEVBO2dCQUM5RUEsc0ZBQWdGQTtnQkFDaEZBLHVGQUFpRkE7Z0JBQ2pGQSwrRUFBeUVBO2dCQUN6RUEsK0VBQXlFQTtnQkFDekVBLDhFQUF3RUE7Z0JBQ3hFQSw4RUFBd0VBO2dCQUN4RUEsMkVBQXFFQTtnQkFDckVBLHFFQUErREE7Z0JBQy9EQSx1RUFBaUVBO2dCQUNqRUEsb0VBQThEQTtnQkFDOURBLHFFQUErREE7Z0JBQy9EQSx1RUFBaUVBO2dCQUNqRUEsb0VBQThEQTtnQkFDOURBLG9FQUE4REE7Z0JBQzlEQSxvRUFBOERBO2dCQUM5REEsOEVBQXdFQTtnQkFDeEVBLHlFQUFtRUE7Z0JBQ25FQSw0RUFBc0VBO2dCQUN0RUEsNEVBQXNFQTs7Z0JBRXRFQSxpQkFBaUJBOzs7Ozs7Ozs7a0ZBWW1OQTs7Ozs7Ozs7Ozs7O3dDQUdwT0E7Ozs7Ozs7Ozs7Ozs7OzsrRUFJcUVBLHFCQUE4REE7O2dCQUduSUEsOEJBQThDQTtnQkFDOUNBLDRCQUE0Q0E7Z0JBQzVDQSxvQkFBb0RBO2dCQUNwREEsZUFBc0RBLFlBQTRDQSw2Q0FBdUJBOztnQkFFdkhBLENBQUNBLHlDQUF5Q0EsVUFBVUE7O3dGQUl3QkEscUJBQThEQTs7Z0JBRzVJQSw4QkFBOENBO2dCQUM5Q0EsNEJBQTRDQTtnQkFDNUNBLG9CQUFvREE7Z0JBQ3BEQSxlQUFzREEsWUFBNENBLDZDQUF1QkE7O2dCQUV2SEEsQ0FBQ0EsdUNBQXVDQSxVQUFVQTs7b0ZBSXNCQSxxQkFBOERBOztnQkFHeElBLDhCQUE4Q0E7Z0JBQzlDQSw0QkFBNENBO2dCQUM1Q0Esb0JBQW9EQTtnQkFDcERBLGVBQXNEQSxZQUE0Q0EsNkNBQXVCQTs7Z0JBRXZIQSxDQUFDQSxxQ0FBcUNBLFVBQVVBOzsrRUFJb0NBOztnQkFHdEZBLDhCQUE4Q0E7Z0JBQzlDQSw0QkFBNENBO2dCQUM1Q0Esb0JBQW9EQTtnQkFDcERBLGVBQXNEQSxZQUE0Q0EsNkNBQXVCQTs7Z0JBRXZIQSxPQUFPQSx3Q0FBd0NBOztrRkFJbUxBOzs7Ozs7Ozs7Ozs7d0NBR3BPQTs7Ozs7Ozs7Ozs7Ozs7OytFQUlxRUEscUJBQThEQTs7Z0JBR25JQSw4QkFBOENBO2dCQUM5Q0EsNEJBQTRDQTtnQkFDNUNBLG9CQUFvREE7Z0JBQ3BEQSxlQUFzREEsWUFBNENBLDZDQUF1QkE7O2dCQUV2SEEsQ0FBQ0EseUNBQXlDQSxVQUFVQTs7d0ZBSXdCQSxxQkFBOERBOztnQkFHNUlBLDhCQUE4Q0E7Z0JBQzlDQSw0QkFBNENBO2dCQUM1Q0Esb0JBQW9EQTtnQkFDcERBLGVBQXNEQSxZQUE0Q0EsNkNBQXVCQTs7Z0JBRXZIQSxDQUFDQSx1Q0FBdUNBLFVBQVVBOztvRkFJc0JBLHFCQUE4REE7O2dCQUd4SUEsOEJBQThDQTtnQkFDOUNBLDRCQUE0Q0E7Z0JBQzVDQSxvQkFBb0RBO2dCQUNwREEsZUFBc0RBLFlBQTRDQSw2Q0FBdUJBOztnQkFFdkhBLENBQUNBLHFDQUFxQ0EsVUFBVUE7OytFQUlvQ0E7O2dCQUd0RkEsOEJBQThDQTtnQkFDOUNBLDRCQUE0Q0E7Z0JBQzVDQSxvQkFBb0RBO2dCQUNwREEsZUFBc0RBLFlBQTRDQSw2Q0FBdUJBOztnQkFFdkhBLE9BQU9BLHdDQUF3Q0E7O2tGQUltTEE7Ozs7Ozs7Ozs7Ozt3Q0FHcE9BOzs7Ozs7Ozs7Ozs7Ozs7K0VBSXFFQSxxQkFBOERBOztnQkFHbklBLDhCQUE4Q0E7Z0JBQzlDQSw0QkFBNENBO2dCQUM1Q0Esb0JBQW9EQTtnQkFDcERBLGVBQXNEQSxZQUE0Q0EsNkNBQXVCQTs7Z0JBRXZIQSxDQUFDQSx5Q0FBeUNBLFVBQVVBOzt3RkFJd0JBLHFCQUE4REE7O2dCQUc1SUEsOEJBQThDQTtnQkFDOUNBLDRCQUE0Q0E7Z0JBQzVDQSxvQkFBb0RBO2dCQUNwREEsZUFBc0RBLFlBQTRDQSw2Q0FBdUJBOztnQkFFdkhBLENBQUNBLHVDQUF1Q0EsVUFBVUE7O29GQUlzQkEscUJBQThEQTs7Z0JBR3hJQSw4QkFBOENBO2dCQUM5Q0EsNEJBQTRDQTtnQkFDNUNBLG9CQUFvREE7Z0JBQ3BEQSxlQUFzREEsWUFBNENBLDZDQUF1QkE7O2dCQUV2SEEsQ0FBQ0EscUNBQXFDQSxVQUFVQTs7K0VBSW9DQTs7Z0JBR3RGQSw4QkFBOENBO2dCQUM5Q0EsNEJBQTRDQTtnQkFDNUNBLG9CQUFvREE7Z0JBQ3BEQSxlQUFzREEsWUFBNENBLDZDQUF1QkE7O2dCQUV2SEEsT0FBT0Esd0NBQXdDQTs7a0ZBSW1MQTs7Ozs7Ozs7Ozs7O3dDQUdwT0E7Ozs7Ozs7Ozs7Ozs7OzsrRUFJcUVBLHFCQUE4REE7O2dCQUduSUEsOEJBQThDQTtnQkFDOUNBLDRCQUE0Q0E7Z0JBQzVDQSxvQkFBb0RBO2dCQUNwREEsZUFBc0RBLFlBQTRDQSw2Q0FBdUJBOztnQkFFdkhBLENBQUNBLHlDQUF5Q0EsVUFBVUE7O3dGQUl3QkEscUJBQThEQTs7Z0JBRzVJQSw4QkFBOENBO2dCQUM5Q0EsNEJBQTRDQTtnQkFDNUNBLG9CQUFvREE7Z0JBQ3BEQSxlQUFzREEsWUFBNENBLDZDQUF1QkE7O2dCQUV2SEEsQ0FBQ0EsdUNBQXVDQSxVQUFVQTs7b0ZBSXNCQSxxQkFBOERBOztnQkFHeElBLDhCQUE4Q0E7Z0JBQzlDQSw0QkFBNENBO2dCQUM1Q0Esb0JBQW9EQTtnQkFDcERBLGVBQXNEQSxZQUE0Q0EsNkNBQXVCQTs7Z0JBRXZIQSxDQUFDQSxxQ0FBcUNBLFVBQVVBOzsrRUFJb0NBOztnQkFHdEZBLDhCQUE4Q0E7Z0JBQzlDQSw0QkFBNENBO2dCQUM1Q0Esb0JBQW9EQTtnQkFDcERBLGVBQXNEQSxZQUE0Q0EsNkNBQXVCQTs7Z0JBRXZIQSxPQUFPQSx3Q0FBd0NBOztrRkFJbUxBOzs7Ozs7Ozs7Ozs7d0NBR3BPQTs7Ozs7Ozs7Ozs7Ozs7OytFQUlxRUEscUJBQThEQTs7Z0JBR25JQSw4QkFBOENBO2dCQUM5Q0EsNEJBQTRDQTtnQkFDNUNBLG9CQUFvREE7Z0JBQ3BEQSxlQUFzREEsWUFBNENBLDZDQUF1QkE7O2dCQUV2SEEsQ0FBQ0EseUNBQXlDQSxVQUFVQTs7d0ZBSXdCQSxxQkFBOERBOztnQkFHNUlBLDhCQUE4Q0E7Z0JBQzlDQSw0QkFBNENBO2dCQUM1Q0Esb0JBQW9EQTtnQkFDcERBLGVBQXNEQSxZQUE0Q0EsNkNBQXVCQTs7Z0JBRXZIQSxDQUFDQSx1Q0FBdUNBLFVBQVVBOztvRkFJc0JBLHFCQUE4REE7O2dCQUd4SUEsOEJBQThDQTtnQkFDOUNBLDRCQUE0Q0E7Z0JBQzVDQSxvQkFBb0RBO2dCQUNwREEsZUFBc0RBLFlBQTRDQSw2Q0FBdUJBOztnQkFFdkhBLENBQUNBLHFDQUFxQ0EsVUFBVUE7OytFQUlvQ0E7O2dCQUd0RkEsOEJBQThDQTtnQkFDOUNBLDRCQUE0Q0E7Z0JBQzVDQSxvQkFBb0RBO2dCQUNwREEsZUFBc0RBLFlBQTRDQSw2Q0FBdUJBOztnQkFFdkhBLE9BQU9BLHdDQUF3Q0E7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O29CRzF3Q1pBLE9BQU9BOzs7OztvQkFFSEEsT0FBT0E7Ozs7OztrQ0FIUUEsSUFBSUE7c0NBRVBBLElBQUlBOzs7Ozs7Ozs7Z0JBU3pEQTs7Ozs7Z0JBR0FBO2dCQUNBQSxrQkFBa0JBLHFDQUFNQTtnQkFDeEJBLDJCQUEyQkEscUNBQU1BO2dCQUNqQ0EsSUFBSUEsZ0JBQWVBO29CQUF1QkEsUUFBU0E7O2dCQUErQkE7OztnQkFHbEZBLGtCQUFrQkEscUNBQU1BO2dCQUN4QkEsMkJBQTJCQSxxQ0FBTUE7Z0JBQ2pDQSxJQUFJQSxnQkFBZUE7b0JBQXVCQSxRQUFTQTs7Z0JBQStCQTs7O2dCQUdsRkEsYUFBY0EscUNBQU9BO2dCQUNyQkEsSUFBSUE7b0JBQ0pBOzs7O2dCQUlBQSx3Q0FBeUVBLEFBQXFCQTtnQkFDOUZBO2dCQUNBQSwwRUFBb0RBO2dCQUNwREEsa0VBQTRDQTtnQkFDNUNBLGVBQWtCQTtnQkFDbEJBLHFFQUErQ0E7Z0JBQy9DQTtnQkFDQUEsV0FBaUNBO2dCQUNqQ0EsYUFBYUEsa0NBQXFCQTtnQkFDbENBLElBQUlBLE1BQUtBO29CQUNUQSxhQUFhQSxZQUFRQTs7Z0JBRXJCQSxxQkFBd0JBLGtDQUFxQkE7Z0JBQzdDQSxJQUFJQSxNQUFLQTtvQkFDVEEsaUJBQWlCQSxZQUFRQTs7Z0JBRXpCQSxpQkFBb0JBLGtDQUFxQkE7Z0JBQ3pDQSxJQUFJQSxRQUFRQSxjQUFjQSxNQUFLQTtvQkFDL0JBLGFBQWFBLFlBQVFBO29CQUNyQkEsSUFBSUEsUUFBUUEsY0FBY0EsTUFBS0E7d0JBQW1CQTs7O2dCQUVsREEsb0VBQThDQTtnQkFDOUNBLGlCQUFvQkEsa0NBQXFCQTtnQkFDekNBLElBQUlBLFFBQVFBLGNBQWNBLE1BQUtBO29CQUMvQkEsYUFBYUEsWUFBUUE7b0JBQ3JCQSxJQUFJQSxRQUFRQSxjQUFjQSxNQUFLQTt3QkFBbUJBOzs7Z0JBRWxEQSxvRUFBOENBO2dCQUM5Q0EsbUJBQXNCQSxrQ0FBcUJBO2dCQUMzQ0EsSUFBSUEsUUFBUUEsZ0JBQWdCQSxNQUFLQTtvQkFDakNBLGVBQWVBLFlBQVFBO29CQUN2QkEsSUFBSUEsUUFBUUEsZ0JBQWdCQSxNQUFLQTt3QkFBcUJBOzs7Z0JBRXREQSxzRUFBZ0RBO2dCQUNoREEsV0FBY0Esa0NBQXFCQTtnQkFDbkNBLElBQUlBLE1BQUtBO29CQUNUQSxPQUFPQSxZQUFRQTs7Z0JBRWZBLGFBQWdCQSxrQ0FBcUJBO2dCQUNyQ0EsSUFBSUEsTUFBS0E7b0JBQ1RBLFNBQVNBLFlBQVFBOztnQkFFakJBLFdBQWNBLGtDQUFxQkE7Z0JBQ25DQSxJQUFJQSxNQUFLQTtvQkFDVEEsT0FBT0EsWUFBUUE7O2dCQUVmQSxJQUFJQSxRQUFRQTtvQkFBV0E7O2dCQUN2QkEsU0FBU0E7Z0JBQ1RBLElBQUlBLDJCQUFNQTtvQkFBVUE7O2dCQUNwQkEsSUFBSUE7b0JBQTRCQTs7Z0JBQ2hDQSxJQUFJQSxRQUFRQTtvQkFBY0E7O2dCQUMxQkEsYUFBYUE7Z0JBQ2JBLElBQUlBLFFBQVFBO29CQUFrQkE7O2dCQUM5QkEsaUJBQWlCQTtnQkFDakJBLElBQUlBLDJCQUFNQTtvQkFBa0JBOztnQkFDNUJBLElBQUlBLDJCQUFNQTtvQkFDVkEsSUFBSUEsK0JBQVVBO3dCQUFzQ0EsYUFBYUE7O3dCQUM1REE7OztnQkFFTEEsY0FBaUJBLGtDQUFxQkE7Z0JBQ3RDQSxJQUFJQSxNQUFLQTtvQkFBZ0JBLFVBQVVBLFlBQVFBOztnQkFDM0NBLElBQUlBLFFBQVFBO29CQUFTQSxVQUFVQTs7Z0JBQy9CQSxJQUFJQSwyQkFBTUE7b0JBQVNBLFVBQVVBOztnQkFDN0JBLGlFQUEyQ0E7Z0JBQzNDQSxJQUFJQSxpQ0FBWUE7b0JBQ2hCQSxJQUFJQSxRQUFRQTt3QkFBUUE7O29CQUNwQkEsVUFBYUEsWUFBU0E7b0JBQ3RCQSxJQUFJQSxNQUFLQTt3QkFDVEE7d0JBQ0FBLEtBQUlBLFdBQVNBLElBQUlBLFlBQVlBOzRCQUM3QkEsSUFBSUEsT0FBT0EsZUFBSUE7Z0NBQ2ZBLElBQUlBLE9BQU9BLGVBQUlBLE1BQU1BLE9BQU9BLGVBQUlBLE1BQU1BLE9BQU9BLGVBQUlBLE1BQU1BLE9BQU9BLGVBQUlBLE1BQU1BLE9BQU9BLGVBQUlBLE1BQU1BLE9BQU9BLGVBQUlBLE1BQU1BLE9BQU9BLGVBQUlBLE1BQU1BLE9BQU9BLGVBQUlBLE1BQU1BLE9BQU9BLGVBQUlBLE1BQU1BLE9BQU9BLGVBQUlBO29DQUN4S0Esb0NBQUtBLGVBQUlBOztvQ0FFSkE7Ozs7d0JBR0xBLElBQUlBLE1BQUtBOzRCQUFVQSxPQUFPQTs7O29CQUUxQkEsSUFBSUEsMkJBQU1BO3dCQUFRQSxPQUFPQTs7b0JBQ3pCQSxtQ0FBY0EsUUFBTUEscUJBQWFBOztvQkFFakNBLElBQUlBLE1BQUtBO3dCQUNUQSxzQkFBaUJBLGtDQUFxQkE7d0JBQ3RDQSxJQUFJQSx1QkFBa0JBLFFBQVFBLE1BQUtBOzRCQUF1QkEsc0JBQWlCQSxZQUFRQTs7d0JBQ25GQSxJQUFJQSx1QkFBa0JBLFFBQVFBLE1BQUtBOzRCQUF1QkEsbUNBQWNBLFFBQU1BOzs7b0JBRTlFQSxtQ0FBY0EsUUFBTUE7b0JBQ3BCQSxJQUFJQSxNQUFLQTt3QkFBZUE7OztnQkFFeEJBLHVCQUEwQkEsa0NBQXFCQTtnQkFDL0NBLElBQUlBLFFBQVFBLG9CQUFvQkEsTUFBS0E7b0JBQ3JDQSxtQkFBbUJBLFlBQVFBO29CQUMzQkEsSUFBSUEsUUFBUUEsb0JBQW9CQSxNQUFLQTt3QkFBeUJBOzs7Z0JBRTlEQSwwRUFBb0RBO2dCQUNwREEsSUFBSUE7b0JBQXlCQSxhQUFhQSxZQUFXQTs7b0JBQ2hEQSxhQUFhQSxXQUFVQTs7Z0JBQzVCQSxtQkFBMkJBLHFGQUEyREE7Z0JBQ3RGQSxnQkFBcUJBLCtFQUFxREE7Z0JBRTFFQSxVQUFhQSxJQUFJQTtnQkFDakJBLFdBQWNBO2dCQUNkQSxpQkFBWUEsSUFBSUEsd0NBQXdDQSxpQ0FBd0JBO2dCQUNoRkEsdUJBQWtCQSxJQUFJQSx3Q0FBd0NBLGlDQUF3QkE7Z0JBQ3RGQSxtRUFBNkNBO2dCQUM3Q0EseUVBQW1EQTtnQkFDbkRBO2dCQUNBQTtnQkFDQUEsNEJBQXNCQSwrQkFBT0EsR0FBR0E7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7d0NBQ2hDQSxJQUFJQTs7Ozs7Ozs7d0NBQ0pBO3dDQUNBQTt3Q0FDQUEsU0FBTUE7Ozs7Ozs7Ozs7d0NBQ05BOzs7Ozt3Q0FFQUEsT0FBZ0JBLEFBQVVBLHdCQUFTQSxRQUFRQTt3Q0FDM0NBLEtBQUtBLFlBQVdBLEtBQUlBLGFBQWFBOzRDQUNqQ0EsS0FBa0JBLGlDQUFvQkEsd0JBQUtBLElBQUxBOzRDQUN0Q0EsUUFBZUE7NENBQ2ZBLElBQUlBO2dEQUNKQSxvQkFBZUEsd0JBQUtBLElBQUxBO21EQUNSQSxJQUFJQTtnREFDWEEsb0JBQWVBLHdCQUFLQSxJQUFMQTttREFDUkEsSUFBSUE7Z0RBQ1hBLG9CQUFlQSx3QkFBS0EsSUFBTEE7bURBQ1JBLElBQUlBO2dEQUNYQSwrREFBeUNBO2dEQUN6Q0E7Z0RBQ0FBO2dEQUNBQTtnREFDQUEsa0VBQTRDQTtnREFDNUNBO2dEQUNBQSxpQkFBWUEsV0FBVUE7Z0RBQ3RCQTtnREFDQUE7Z0RBQ0FBO2dEQUNBQTtnREFDQUE7Z0RBQ0FBO2dEQUNBQTtnREFDQUEsV0FBd0JBLEFBQWlEQSxVQUFDQTtvREFBT0E7b0RBQWtCQTtvREFBdUJBO29EQUFpQkE7b0RBQXVCQTtvREFBd0JBO29EQUFpQ0E7b0RBQXVCQTtvREFBcUJBO29EQUFxQkE7b0RBQXdCQTtvREFBMkJBO29EQUFtQkE7b0RBQXNCQTtvREFBbUJBO29EQUFtQkE7b0RBQTBCQTtvREFBeUJBO29EQUFvQkE7b0RBQThCQTtvREFBbUJBO29EQUF1QkE7b0RBQXVCQTtvREFBaUJBO29EQUEyQkE7b0RBQW9CQTtvREFBbUJBO29EQUFxQkE7b0RBQTJCQTtvREFBcUJBO29EQUF5QkE7b0RBQWtCQTtvREFBa0JBO29EQUF5QkE7b0RBQThCQTtvREFBdUJBO29EQUFvQkE7b0RBQWdDQTtvREFBa0JBO29EQUFrQkE7b0RBQW9CQTtvREFBb0JBO29EQUFnQkE7b0RBQW9CQTtvREFBcUJBO29EQUFvQkE7b0RBQXdCQTtvREFBMkJBO29EQUFrQkE7b0RBQTJCQTtvREFBd0JBO29EQUFtQkEsT0FBT0E7a0RBQWhwQ0EsS0FBSUE7Z0RBQzFEQTtnREFDQUE7Z0RBQ0FBO2dEQUNBQSxJQUF3QkEsS0FBSUE7Z0RBQzVCQSxLQUFLQSxXQUFVQSxRQUFNQTtvREFDckJBLE1BQU1BLEtBQUlBO29EQUNWQSxVQUFFQSxPQUFPQSxJQUFJQSw0QkFBUUEsaUJBQVNBO29EQUM5QkEsVUFBRUEsT0FBT0EsSUFBSUE7b0RBQ2JBLFVBQUVBLE9BQU9BLElBQUlBO29EQUNiQSxVQUFFQSxPQUFPQSxJQUFJQTtvREFDYkEsVUFBRUEsT0FBT0EsSUFBSUE7b0RBQ2JBLFVBQUVBLE9BQU9BLElBQUlBO29EQUNiQSxVQUFFQSxPQUFPQSxJQUFJQTtvREFDYkEsVUFBRUEsT0FBT0EsSUFBSUE7O2dEQUViQSxxQkFBcUJBO2dEQUNyQkEsdUJBQXdCQSxBQUFpREEsVUFBQ0E7b0RBQU9BO29EQUFrQkE7b0RBQWtDQTtvREFBd0RBO29EQUF1REE7b0RBQTJDQTtvREFBdUVBO29EQUErRUE7b0RBQXFHQTtvREFBcUdBO29EQUFpQ0E7b0RBQW9DQTtvREFBd0VBO29EQUE4SEE7b0RBQW1DQTtvREFBd0VBO29EQUFrRUE7b0RBQWtDQTtvREFBdUNBO29EQUFpRUE7b0RBQThCQTtvREFBc0ZBO29EQUFtREE7b0RBQTJGQTtvREFBMERBO29EQUE2RkE7b0RBQWtEQTtvREFBd0RBO29EQUF5RUE7b0RBQXdEQTtvREFBd0RBO29EQUFtR0E7b0RBQTZCQTtvREFBMENBO29EQUF1Q0E7b0RBQXNEQTtvREFBNkJBO29EQUE2Q0E7b0RBQTZCQTtvREFBeUVBO29EQUF1RkE7b0RBQWtGQTtvREFBeUJBO29EQUFvRkE7b0RBQThCQTtvREFBK0VBO29EQUFpQ0E7b0RBQW9DQTtvREFBK0NBO29EQUE0Q0E7b0RBQXNGQTtvREFBd0NBLE9BQU9BO2tEQUF0NkZBLEtBQUlBO2dEQUMxREE7Z0RBQ0FBO2dEQUNBQSxVQUFVQSxJQUFJQTtnREFDZEE7Z0RBQ0FBO2dEQUNBQSxJQUFJQSxtQ0FBc0JBO2dEQUMxQkEsb0JBQWVBO2dEQUNmQSxPQUFXQTtnREFDWEEsQUFBNENBO21EQUNyQ0EsSUFBSUE7Z0RBQ1hBO2dEQUNBQTtnREFDQUEsVUFBVUE7Z0RBQ1ZBLElBQUlBLGlEQUEwQkEsZ0RBQXlCQSx5REFBa0NBLGlEQUEwQkEsK0NBQXdCQSwrQ0FBd0JBLHlEQUFrQ0Esd0RBQWlDQSxtREFBNEJBO29EQUNsUUEsK0JBQVlBOztnREFFWkEsS0FBWUE7Z0RBQ1pBLElBQVdBLDZDQUFnQ0EsSUFBSUEsYUFBYUE7Z0RBQzVEQSxVQUFVQSxJQUFJQTtnREFDZEEsZ0JBQWdCQTtnREFDaEJBLElBQUlBLG1DQUFzQkE7Z0RBQzFCQSxvQkFBZUE7bURBQ1JBLElBQUlBO2dEQUNYQSxtQkFBY0E7bURBQ1BBLElBQUlBO2dEQUNYQTtnREFDQUEsVUFBVUE7Z0RBQ1ZBLElBQUlBLGlEQUEwQkEsZ0RBQXlCQSx5REFBa0NBLGlEQUEwQkEsK0NBQXdCQSwrQ0FBd0JBLHlEQUFrQ0Esd0RBQWlDQSxtREFBNEJBO29EQUNsUUEsK0JBQVlBOztnREFFWkEsV0FBb0JBLDRDQUErQkE7Z0RBQ25EQSxPQUFZQSwwQkFBaUJBLGtCQUFzQkE7Z0RBQ25EQSxLQUFTQSxzQkFBeUJBLE9BQUtBO2dEQUN2Q0EsTUFBWUEsZ0NBQW1CQTtnREFDL0JBLE1BQVVBLDhDQUErQkEsS0FBSUEsYUFBY0E7Z0RBQzNEQSxVQUFVQSxJQUFJQTtnREFDZEEsZ0JBQWdCQTtnREFDaEJBLElBQUVBLG1DQUFzQkE7Z0RBQ3hCQSxvQkFBZUE7Z0RBQ2ZBLDBCQUFxQkE7bURBQ2RBLElBQUlBO2dEQUNYQSxJQUFJQSxpREFBMEJBLGdEQUF5QkEseURBQWtDQSxpREFBMEJBLCtDQUF3QkEsK0NBQXdCQSx5REFBa0NBLHdEQUFpQ0EsbURBQTRCQTtvREFDbFFBLCtCQUFZQTs7Z0RBQ1pBLFlBQW9CQSw0Q0FBK0JBO2dEQUNuREEsTUFBWUEsZ0NBQW1CQTtnREFDL0JBLE9BQVVBLDhDQUErQkEsS0FBSUEsYUFBYUE7Z0RBQzFEQSxNQUFXQSwwQkFBaUJBLGtCQUFzQkE7Z0RBQ2xEQSxTQUFvQkE7Z0RBQ3BCQSxJQUFJQSxVQUFVQTtvREFDZEEsYUFBZ0JBLG1CQUFlQTtvREFDL0JBLGdDQUFjQSxhQUFDQSxZQUFnQkEsMkRBQWdCQTs7Z0RBQy9DQSxVQUFVQSxJQUFJQTtnREFDZEEsZ0JBQWdCQTtnREFDaEJBLElBQUlBLG1DQUFzQkE7Z0RBQzFCQSxvQkFBZUE7Z0RBQ2ZBLDBCQUFxQkE7bURBQ2RBLElBQUlBO2dEQUNYQSxJQUFJQSxpREFBMEJBLGdEQUF5QkEseURBQWtDQSxpREFBMEJBLCtDQUF3QkEsK0NBQXdCQSx5REFBa0NBLHdEQUFpQ0EsbURBQTRCQTtvREFDbFFBLCtCQUFZQTs7Z0RBRVpBLFlBQW9CQSw0Q0FBOEJBO2dEQUNsREEsTUFBWUEsZ0NBQW1CQTtnREFDL0JBLE9BQVVBLDhDQUErQkEsS0FBSUEsYUFBWUE7Z0RBQ3pEQSxPQUFXQSwwQkFBaUJBLGtCQUFzQkE7Z0RBQ2xEQSxVQUFvQkE7Z0RBQ3BCQSxJQUFJQSxXQUFVQTtvREFDZEEsY0FBZ0JBLG1CQUFlQTtvREFDL0JBLGlDQUFjQSxhQUFDQSxZQUFpQkEsMkRBQWdCQTs7Z0RBRWhEQSxJQUFJQSxNQUFHQTtvREFDUEE7b0RBQ0FBLFVBQVVBO29EQUNWQSxTQUFjQSwwQkFBaUJBLGtCQUFzQkE7b0RBQ3JEQSxXQUFxQkE7b0RBQ3JCQSxjQUFnQkEsbUJBQWVBO29EQUMvQkEsa0NBQWVBLGdDQUFLQTs7Z0RBRXBCQSxVQUFVQSxJQUFJQTtnREFDZEEsZ0JBQWdCQTtnREFDaEJBLElBQUVBLG1DQUFzQkE7Z0RBQ3hCQSxvQkFBZUE7Z0RBQ2ZBLDBCQUFxQkE7bURBQ2RBLElBQUlBO3dDQUVYQSxXQUFXQSxnQ0FBbUJBO2dEQUM5QkEsSUFBSUEsUUFBUUE7b0RBQ1pBLE9BQWFBLDhDQUErQkEsVUFBVUEsYUFBYUE7b0RBQ25FQSxjQUFnQkEsbUJBQWVBLElBQUlBO29EQUNuQ0EsWUFBb0JBLG9DQUF1QkE7b0RBQzNDQSxRQUFZQSwwQkFBaUJBO29EQUM3QkEsVUFBb0JBLDRDQUFlQSxRQUFPQTtvREFDMUNBLElBQUlBLDRCQUFlQTt3REFDbkJBLFdBQVdBLFlBQVFBLGlDQUFjQSxrQkFBTUE7O3dEQUV2Q0EsV0FBV0EsWUFBUUEsaUNBQWNBLGdDQUFLQTs7O29EQUd0Q0E7O2dEQUVBQSxVQUFVQSxJQUFJQTtnREFDZEE7Z0RBQ0FBLGVBQWVBO2dEQUNmQSxnQkFBZ0JBO2dEQUNoQkEsSUFBSUEsbUNBQXNCQTtnREFDMUJBLDBCQUFxQkE7O2dEQUNkQSxvQkFBZUE7Ozs7Ozs7Ozs7Ozs7O2dCQUV0QkEsMEJBQW1CQSxVQUFDQSxHQUFFQTtvQkFBSUEsc0JBQW9CQSxjQUFhQTs7Z0JBQzNEQSwwQkFBbUJBLFVBQUNBLEdBQUVBO29CQUFJQTs7Z0JBQzFCQSx5QkFBa0JBLCtCQUFDQSxHQUFFQTtvQkFDckJBLFVBQVVBLElBQUlBO29CQUNkQTtvQkFDQUEsZUFBZUEsWUFBU0E7b0JBQ3hCQSxJQUFJQSxtQ0FBc0JBO29CQUMxQkEsb0JBQWVBOztnQkFFZkEsK0JBQTBCQSwrQkFBT0EsR0FBR0E7Ozs7Ozs7Ozs7O3dDQUVwQ0EsVUFBVUEsSUFBSUE7d0NBQ2RBLFNBQU1BOzs7Ozs7Ozs7O3dDQUNOQSxlQUFlQSxZQUFTQTt3Q0FDeEJBO3dDQUNBQSxLQUFZQSxtQ0FBc0JBO3dDQUNsQ0EsMEJBQXFCQTs7Ozs7Ozs7Ozs7O2dCQUVyQkEsa0NBQTZCQSwrQkFBQ0EsR0FBR0E7b0JBQ2pDQSxTQUFvQkEsaUNBQW9CQTtvQkFDeENBLFlBQWVBO29CQUNmQSxJQUFJQTt3QkFDSkEsMEJBQXFCQTsyQkFDZEEsSUFBSUE7d0JBQ1hBO3dCQUNBQSxXQUFXQSxnQ0FBbUJBO3dCQUM5QkEsSUFBSUEsUUFBUUE7NEJBQ1pBLFVBQWFBLDhDQUErQkEsVUFBVUEsYUFBYUE7NEJBQ25FQSxpQkFBZ0JBLG1CQUFlQSxJQUFJQTs0QkFDbkNBLGVBQW9CQSxvQ0FBdUJBOzRCQUMzQ0EsV0FBWUEsMEJBQWlCQTs0QkFDN0JBLGFBQW9CQSwyQ0FBZUEsUUFBT0E7NEJBQzFDQSxJQUFJQSw0QkFBZUE7Z0NBQ25CQSxXQUFXQSxZQUFRQSxnQ0FBY0Esa0JBQU1BOztnQ0FFdkNBLFdBQVdBLFlBQVFBLGdDQUFjQSwrQkFBS0E7Ozs0QkFHdENBOzt3QkFFQUEsVUFBVUEsSUFBSUE7d0JBQ2RBO3dCQUNBQSxlQUFlQTt3QkFDZkEsZ0JBQWdCQTt3QkFDaEJBLElBQUlBLG1DQUFzQkE7d0JBQzFCQSwwQkFBcUJBOzJCQUNkQSxJQUFJQTt3QkFDWEEsb0NBQXVCQTs7Ozs2QkFJWkE7Z0JBQ1hBOzs2QkFFV0E7Z0JBQ1hBLElBQUlBO29CQUF5QkE7O2dCQUM3QkEsSUFBSUE7b0JBQXlCQTs7Z0JBQzdCQSxJQUFJQTtvQkFBd0JBOztnQkFDNUJBLElBQUlBO29CQUEwQkE7O2dCQUM5QkEsSUFBSUE7b0JBQTZCQTs7Z0JBQ2pDQSxJQUFJQTtvQkFBMkJBOztnQkFDL0JBLElBQUlBO29CQUF1QkE7O2dCQUMzQkEsSUFBSUE7b0JBQTJCQTs7Z0JBQy9CQSxJQUFJQTtvQkFBd0JBOztnQkFDNUJBLElBQUlBO29CQUF3QkE7O2dCQUM1QkEsSUFBSUE7b0JBQWdDQTs7Z0JBQ3BDQSxJQUFJQTtvQkFBK0JBOztnQkFDbkNBLElBQUlBO29CQUE4QkE7O2dCQUNsQ0EsSUFBSUE7b0JBQTRCQTs7Z0JBQ2hDQSxJQUFJQTtvQkFBZ0NBOztnQkFDcENBLElBQUlBO29CQUE4QkE7O2dCQUNsQ0EsSUFBSUE7b0JBQThCQTs7Z0JBQ2xDQSxJQUFJQTtvQkFBNEJBOztnQkFDaENBLElBQUlBO29CQUEyQkE7O2dCQUMvQkEsSUFBSUE7b0JBQThCQTs7Z0JBQ2xDQSxJQUFJQTtvQkFBc0NBOztnQkFDMUNBLElBQUlBO29CQUEwQkE7O2dCQUM5QkEsSUFBSUE7b0JBQTRCQTs7Z0JBQ2hDQSxJQUFJQTtvQkFBNkJBOztnQkFDakNBLElBQUlBO29CQUE4QkE7O2dCQUNsQ0EsSUFBSUE7b0JBQTZCQTs7Z0JBQ2pDQSxJQUFJQTtvQkFBOEJBOztnQkFDbENBLElBQUlBO29CQUFpQ0E7O2dCQUNyQ0EsSUFBSUE7b0JBQThCQTs7Z0JBQ2xDQSxJQUFJQTtvQkFBd0JBOztnQkFDNUJBLElBQUlBO29CQUF1QkE7O2dCQUMzQkEsSUFBSUE7b0JBQThCQTs7Z0JBQ2xDQSxJQUFJQTtvQkFBOEJBOztnQkFDbENBLElBQUlBO29CQUF3QkE7O2dCQUM1QkEsSUFBSUE7b0JBQXlCQTs7Z0JBQzdCQSxJQUFJQTtvQkFBNkJBOztnQkFDakNBLElBQUlBO29CQUE0QkE7O2dCQUNoQ0EsSUFBSUE7b0JBQWlDQTs7Z0JBQ3JDQSxJQUFJQTtvQkFBZ0NBOztnQkFDcENBLElBQUlBO29CQUF1QkE7O2dCQUMzQkEsSUFBSUE7b0JBQTBCQTs7Z0JBQzlCQSxJQUFJQTtvQkFBMEJBOztnQkFDOUJBLElBQUlBO29CQUEwQkE7O2dCQUM5QkEsSUFBSUE7b0JBQXdCQTs7Z0JBQzVCQSxJQUFJQTtvQkFBNEJBOztnQkFDaENBLElBQUlBO29CQUE2QkE7O2dCQUNqQ0EsSUFBSUE7b0JBQThCQTs7Z0JBQ2xDQSxJQUFJQTtvQkFBaUNBOztnQkFDckNBLElBQUlBO29CQUErQkE7O2dCQUNuQ0EsSUFBSUE7b0JBQXlCQTs7Z0JBQzdCQSxJQUFJQTtvQkFBeUJBOztnQkFDN0JBLElBQUlBO29CQUF5QkE7O2dCQUM3QkEsSUFBSUE7b0JBQWlDQTs7Z0JBQ3JDQSxJQUFJQTtvQkFBMkJBOztnQkFDL0JBLElBQUlBO29CQUEwQkE7O2dCQUM5QkEsSUFBSUE7b0JBQTRCQTs7Z0JBQ2hDQSxJQUFJQTtvQkFBMkJBOztnQkFDL0JBLElBQUlBO29CQUEyQkE7O2dCQUMvQkEsSUFBSUE7b0JBQTZCQTs7Z0JBQ2pDQSxJQUFJQTtvQkFBdUJBOztnQkFDM0JBLElBQUlBO29CQUEyQkE7O2dCQUMvQkEsSUFBSUE7b0JBQTJCQTs7Z0JBQy9CQTs7cUNBRTJCQTtnQkFDM0JBLGVBQW9CQSw0Q0FBK0JBO2dCQUNuREEsV0FBWUEsMEJBQWlCQSxrQkFBc0JBO2dCQUNuREEsU0FBWUE7Z0JBQ1pBLFlBQWFBLFdBQU1BO2dCQUNuQkEsWUFBYUEsV0FBTUE7Z0JBQ25CQSxTQUFTQSxzQkFBeUJBLE9BQU1BO2dCQUN4Q0EsYUFBb0JBO2dCQUNwQkEsVUFBVUEsOENBQStCQSxJQUFJQSxhQUFhQTtnQkFDMURBLElBQUlBLFVBQVVBO29CQUNkQSxpQkFBZ0JBLG1CQUFlQTtvQkFDL0JBLGdDQUFjQSxhQUFDQSxZQUFnQkEsMERBQWdCQTs7Z0JBRS9DQSxTQUFTQTtnQkFDVEEsSUFBSUEsVUFBVUE7b0JBQ2RBLGtCQUFnQkEsbUJBQWVBO29CQUMvQkEsZ0NBQWNBLGFBQUNBLFlBQWdCQSwwREFBZ0JBOztnQkFFL0NBLElBQUlBLE1BQUtBO29CQUNUQTtvQkFDQUEsVUFBVUE7b0JBQ1ZBLGFBQWNBLDBCQUFpQkEsa0JBQXNCQTtvQkFDckRBLFNBQVNBO29CQUNUQSxrQkFBZ0JBLG1CQUFlQTtvQkFDL0JBLGdDQUFjQSwrQkFBS0E7OztzQ0FFU0E7Z0JBQzVCQSxJQUFHQTtvQkFDSEEsYUFBa0JBLFlBQVdBLDhDQUErQkEsVUFBVUEsYUFBYUE7b0JBQ25GQSxJQUFJQSxRQUFRQTt3QkFBUUEsNEJBQTRCQTs7dUJBRzNDQSxJQUFHQTtvQkFDUkEsYUFBcUJBLFlBQWNBLDhDQUErQkEsVUFBVUEsYUFBYUE7b0JBQ3pGQSxJQUFJQSxRQUFRQTt3QkFBUUEsNEJBQTRCQTs7dUJBRzNDQSxJQUFHQTtvQkFDUkEsYUFBMEJBLFlBQW1CQSw4Q0FBK0JBLFVBQVVBLGFBQWFBO29CQUNuR0EsSUFBSUEsUUFBUUE7d0JBQVFBLDRCQUE0QkE7O3VCQUczQ0EsSUFBR0E7b0JBQ1JBLGFBQXdCQSxZQUFpQkEsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDL0ZBLElBQUlBLFFBQVFBO3dCQUFRQSw0QkFBNEJBOzt1QkFHM0NBLElBQUdBO29CQUNSQSxhQUF3QkEsWUFBaUJBLDhDQUErQkEsVUFBVUEsYUFBYUE7b0JBQy9GQSxJQUFJQSxRQUFRQTt3QkFBUUEsNEJBQTRCQTs7dUJBRzNDQSxJQUFHQTtvQkFDUkEsYUFBdUJBLFlBQWdCQSw4Q0FBK0JBLFVBQVVBLGFBQWFBO29CQUM3RkEsSUFBSUEsUUFBUUE7d0JBQVFBLDRCQUE0QkE7O3VCQUczQ0EsSUFBR0E7b0JBQ1JBLGFBQXlCQSxZQUFrQkEsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDakdBLElBQUlBLFFBQVFBO3dCQUFRQSw0QkFBNEJBOzt1QkFHM0NBLElBQUdBO29CQUNSQSxhQUE0QkEsWUFBcUJBLDhDQUErQkEsVUFBVUEsYUFBYUE7b0JBQ3ZHQSxJQUFJQSxRQUFRQTt3QkFBUUEsNEJBQTRCQTs7dUJBRzNDQSxJQUFHQTtvQkFDUkEsYUFBNkJBLFlBQXNCQSw4Q0FBK0JBLFVBQVVBLGFBQWFBO29CQUN6R0EsSUFBSUEsUUFBUUE7d0JBQVFBLDRCQUE0QkE7O3VCQUczQ0EsSUFBR0E7b0JBQ1JBLGNBQThCQSxZQUFzQkEsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDMUdBLElBQUlBLFFBQVFBO3dCQUFTQSw2QkFBNkJBOzt1QkFHN0NBLElBQUdBO29CQUNSQSxjQUFvQ0EsWUFBNEJBLDhDQUErQkEsVUFBVUEsYUFBYUE7b0JBQ3RIQSxJQUFJQSxRQUFRQTt3QkFBU0EsNkJBQTZCQTs7dUJBRzdDQSxJQUFHQTtvQkFDUkEsY0FBNkJBLFlBQXFCQSw4Q0FBK0JBLFVBQVVBLGFBQWFBO29CQUN4R0EsSUFBSUEsUUFBUUE7d0JBQVNBLDZCQUE2QkE7O3VCQUc3Q0EsSUFBR0E7b0JBQ1JBLGNBQThCQSxZQUFzQkEsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDMUdBLElBQUlBLFFBQVFBO3dCQUFTQSw2QkFBNkJBOzt1QkFHN0NBLElBQUdBO29CQUNSQSxjQUE4QkEsWUFBc0JBLDhDQUErQkEsVUFBVUEsYUFBYUE7b0JBQzFHQSxJQUFJQSxRQUFRQTt3QkFBU0EsNkJBQTZCQTs7dUJBRzdDQSxJQUFHQTtvQkFDUkEsY0FBK0JBLFlBQXVCQSw4Q0FBK0JBLFVBQVVBLGFBQWFBO29CQUM1R0EsSUFBSUEsUUFBUUE7d0JBQVNBLDZCQUE2QkE7O3VCQUc3Q0EsSUFBR0E7b0JBQ1JBLGNBQTJCQSxZQUFtQkEsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDcEdBLElBQUlBLFFBQVFBO3dCQUFTQSw2QkFBNkJBOzt1QkFHN0NBLElBQUdBO29CQUNSQSxjQUF1QkEsWUFBZUEsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDNUZBLElBQUlBLFFBQVFBO3dCQUFTQSw2QkFBNkJBOzt1QkFHN0NBLElBQUdBO29CQUNSQSxjQUEyQkEsWUFBbUJBLDhDQUErQkEsVUFBVUEsYUFBYUE7b0JBQ3BHQSxJQUFJQSxRQUFRQTt3QkFBU0EsNkJBQTZCQTs7dUJBRzdDQSxJQUFHQTtvQkFDUkEsY0FBd0JBLFlBQWdCQSw4Q0FBK0JBLFVBQVVBLGFBQWFBO29CQUM5RkEsSUFBSUEsUUFBUUE7d0JBQVNBLDZCQUE2QkE7O3VCQUc3Q0EsSUFBR0E7b0JBQ1JBLGNBQXdCQSxZQUFnQkEsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDOUZBLElBQUlBLFFBQVFBO3dCQUFTQSw2QkFBNkJBOzt1QkFHN0NBLElBQUdBO29CQUNSQSxjQUFnQ0EsWUFBd0JBLDhDQUErQkEsVUFBVUEsYUFBYUE7b0JBQzlHQSxJQUFJQSxRQUFRQTt3QkFBU0EsNkJBQTZCQTs7dUJBRzdDQSxJQUFHQTtvQkFDUkEsY0FBK0JBLFlBQXVCQSw4Q0FBK0JBLFVBQVVBLGFBQWFBO29CQUM1R0EsSUFBSUEsUUFBUUE7d0JBQVNBLDZCQUE2QkE7O3VCQUc3Q0EsSUFBR0E7b0JBQ1JBLGNBQThCQSxZQUFzQkEsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDMUdBLElBQUlBLFFBQVFBO3dCQUFTQSw2QkFBNkJBOzt1QkFHN0NBLElBQUdBO29CQUNSQSxjQUE0QkEsWUFBb0JBLDhDQUErQkEsVUFBVUEsYUFBYUE7b0JBQ3RHQSxJQUFJQSxRQUFRQTt3QkFBU0EsNkJBQTZCQTs7dUJBRzdDQSxJQUFHQTtvQkFDUkEsY0FBZ0NBLFlBQXdCQSw4Q0FBK0JBLFVBQVVBLGFBQWFBO29CQUM5R0EsSUFBSUEsUUFBUUE7d0JBQVNBLDZCQUE2QkE7O3VCQUc3Q0EsSUFBR0E7b0JBQ1JBLGNBQThCQSxZQUFzQkEsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDMUdBLElBQUlBLFFBQVFBO3dCQUFTQSw2QkFBNkJBOzt1QkFHN0NBLElBQUdBO29CQUNSQSxjQUE4QkEsWUFBc0JBLDhDQUErQkEsVUFBVUEsYUFBYUE7b0JBQzFHQSxJQUFJQSxRQUFRQTt3QkFBU0EsNkJBQTZCQTs7dUJBRzdDQSxJQUFHQTtvQkFDUkEsY0FBNEJBLFlBQW9CQSw4Q0FBK0JBLFVBQVVBLGFBQWFBO29CQUN0R0EsSUFBSUEsUUFBUUE7d0JBQVNBLDZCQUE2QkE7O3VCQUc3Q0EsSUFBR0E7b0JBQ1JBLGNBQTJCQSxZQUFtQkEsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDcEdBLElBQUlBLFFBQVFBO3dCQUFTQSw2QkFBNkJBOzt1QkFHN0NBLElBQUdBO29CQUNSQSxjQUE4QkEsWUFBc0JBLDhDQUErQkEsVUFBVUEsYUFBYUE7b0JBQzFHQSxJQUFJQSxRQUFRQTt3QkFBU0EsNkJBQTZCQTs7dUJBRzdDQSxJQUFHQTtvQkFDUkEsY0FBNkJBLFlBQXFCQSw4Q0FBK0JBLFVBQVVBLGFBQWFBO29CQUN4R0EsSUFBSUEsUUFBUUE7d0JBQVNBLDZCQUE2QkE7O3VCQUc3Q0EsSUFBR0E7b0JBQ1JBLGNBQXNDQSxZQUE4QkEsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDMUhBLElBQUlBLFFBQVFBO3dCQUFTQSw2QkFBNkJBOzt1QkFHN0NBLElBQUdBO29CQUNSQSxjQUEwQkEsWUFBa0JBLDhDQUErQkEsVUFBVUEsYUFBYUE7b0JBQ2xHQSxJQUFJQSxRQUFRQTt3QkFBU0EsNkJBQTZCQTs7dUJBRzdDQSxJQUFHQTtvQkFDUkEsY0FBNEJBLFlBQW9CQSw4Q0FBK0JBLFVBQVVBLGFBQWFBO29CQUN0R0EsSUFBSUEsUUFBUUE7d0JBQVNBLDZCQUE2QkE7O3VCQUc3Q0EsSUFBR0E7b0JBQ1JBLGNBQTZCQSxZQUFxQkEsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDeEdBLElBQUlBLFFBQVFBO3dCQUFTQSw2QkFBNkJBOzt1QkFHN0NBLElBQUdBO29CQUNSQSxjQUE4QkEsWUFBc0JBLDhDQUErQkEsVUFBVUEsYUFBYUE7b0JBQzFHQSxJQUFJQSxRQUFRQTt3QkFBU0EsNkJBQTZCQTs7dUJBRzdDQSxJQUFHQTtvQkFDUkEsY0FBNkJBLFlBQXFCQSw4Q0FBK0JBLFVBQVVBLGFBQWFBO29CQUN4R0EsSUFBSUEsUUFBUUE7d0JBQVNBLDZCQUE2QkE7O3VCQUc3Q0EsSUFBR0E7b0JBQ1JBLGNBQThCQSxZQUFzQkEsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDMUdBLElBQUlBLFFBQVFBO3dCQUFTQSw2QkFBNkJBOzt1QkFHN0NBLElBQUdBO29CQUNSQSxjQUFpQ0EsWUFBeUJBLDhDQUErQkEsVUFBVUEsYUFBYUE7b0JBQ2hIQSxJQUFJQSxRQUFRQTt3QkFBU0EsNkJBQTZCQTs7dUJBRzdDQSxJQUFHQTtvQkFDUkEsY0FBNkJBLFlBQXFCQSw4Q0FBK0JBLFVBQVVBLGFBQWFBO29CQUN4R0EsSUFBSUEsUUFBUUE7d0JBQVNBLDZCQUE2QkE7O3VCQUc3Q0EsSUFBR0E7b0JBQ1JBLGNBQTRCQSxZQUFvQkEsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDdEdBLElBQUlBLFFBQVFBO3dCQUFTQSw2QkFBNkJBOzt1QkFHN0NBLElBQUdBO29CQUNSQSxjQUEyQkEsWUFBbUJBLDhDQUErQkEsVUFBVUEsYUFBYUE7b0JBQ3BHQSxJQUFJQSxRQUFRQTt3QkFBU0EsNkJBQTZCQTs7dUJBRzdDQSxJQUFHQTtvQkFDUkEsY0FBOEJBLFlBQXNCQSw4Q0FBK0JBLFVBQVVBLGFBQWFBO29CQUMxR0EsSUFBSUEsUUFBUUE7d0JBQVNBLDZCQUE2QkE7O3VCQUc3Q0EsSUFBR0E7b0JBQ1JBLGNBQXVCQSxZQUFlQSw4Q0FBK0JBLFVBQVVBLGFBQWFBO29CQUM1RkEsSUFBSUEsUUFBUUE7d0JBQVNBLDZCQUE2QkE7O3VCQUc3Q0EsSUFBR0E7b0JBQ1JBLGNBQXVCQSxZQUFlQSw4Q0FBK0JBLFVBQVVBLGFBQWFBO29CQUM1RkEsSUFBSUEsUUFBUUE7d0JBQVNBLDZCQUE2QkE7O3VCQUc3Q0EsSUFBR0E7b0JBQ1JBLGNBQXdCQSxZQUFnQkEsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDOUZBLElBQUlBLFFBQVFBO3dCQUFTQSw2QkFBNkJBOzt1QkFHN0NBLElBQUdBO29CQUNSQSxjQUF1QkEsWUFBZUEsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDNUZBLElBQUlBLFFBQVFBO3dCQUFTQSw2QkFBNkJBOzt1QkFHN0NBLElBQUdBO29CQUNSQSxjQUF3QkEsWUFBZ0JBLDhDQUErQkEsVUFBVUEsYUFBYUE7b0JBQzlGQSxJQUFJQSxRQUFRQTt3QkFBU0EsNkJBQTZCQTs7dUJBRzdDQSxJQUFHQTtvQkFDUkEsY0FBOEJBLFlBQXNCQSw4Q0FBK0JBLFVBQVVBLGFBQWFBO29CQUMxR0EsSUFBSUEsUUFBUUE7d0JBQVNBLDZCQUE2QkE7O3VCQUc3Q0EsSUFBR0E7b0JBQ1JBLGNBQXlCQSxZQUFpQkEsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDaEdBLElBQUlBLFFBQVFBO3dCQUFTQSw2QkFBNkJBOzt1QkFHN0NBLElBQUdBO29CQUNSQSxjQUF3QkEsWUFBZ0JBLDhDQUErQkEsVUFBVUEsYUFBYUE7b0JBQzlGQSxJQUFJQSxRQUFRQTt3QkFBU0EsNkJBQTZCQTs7dUJBRzdDQSxJQUFHQTtvQkFDUkEsY0FBOEJBLFlBQXNCQSw4Q0FBK0JBLFVBQVVBLGFBQWFBO29CQUMxR0EsSUFBSUEsUUFBUUE7d0JBQVNBLDZCQUE2QkE7O3VCQUc3Q0EsSUFBR0E7b0JBQ1JBLGNBQXdCQSxZQUFnQkEsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDOUZBLElBQUlBLFFBQVFBO3dCQUFTQSw2QkFBNkJBOzt1QkFHN0NBLElBQUdBO29CQUNSQSxjQUE0QkEsWUFBb0JBLDhDQUErQkEsVUFBVUEsYUFBYUE7b0JBQ3RHQSxJQUFJQSxRQUFRQTt3QkFBU0EsNkJBQTZCQTs7dUJBRzdDQSxJQUFHQTtvQkFDUkEsY0FBeUJBLFlBQWlCQSw4Q0FBK0JBLFVBQVVBLGFBQWFBO29CQUNoR0EsSUFBSUEsUUFBUUE7d0JBQVNBLDZCQUE2QkE7O3VCQUc3Q0EsSUFBR0E7b0JBQ1JBLGNBQTZCQSxZQUFxQkEsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDeEdBLElBQUlBLFFBQVFBO3dCQUFTQSw2QkFBNkJBOzt1QkFHN0NBLElBQUdBO29CQUNSQSxjQUE0QkEsWUFBb0JBLDhDQUErQkEsVUFBVUEsYUFBYUE7b0JBQ3RHQSxJQUFJQSxRQUFRQTt3QkFBU0EsNkJBQTZCQTs7dUJBRzdDQSxJQUFHQTtvQkFDUkEsY0FBaUNBLFlBQXlCQSw4Q0FBK0JBLFVBQVVBLGFBQWFBO29CQUNoSEEsSUFBSUEsUUFBUUE7d0JBQVNBLDZCQUE2QkE7O3VCQUc3Q0EsSUFBR0E7b0JBQ1JBLGNBQWdDQSxZQUF3QkEsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDOUdBLElBQUlBLFFBQVFBO3dCQUFTQSw2QkFBNkJBOzt1QkFHN0NBLElBQUdBO29CQUNSQSxjQUF1QkEsWUFBZUEsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDNUZBLElBQUlBLFFBQVFBO3dCQUFTQSw2QkFBNkJBOzt1QkFHN0NBLElBQUdBO29CQUNSQSxjQUEwQkEsWUFBa0JBLDhDQUErQkEsVUFBVUEsYUFBYUE7b0JBQ2xHQSxJQUFJQSxRQUFRQTt3QkFBU0EsNkJBQTZCQTs7dUJBRzdDQSxJQUFHQTtvQkFDUkEsY0FBdUJBLFlBQWVBLDhDQUErQkEsVUFBVUEsYUFBYUE7b0JBQzVGQSxJQUFJQSxRQUFRQTt3QkFBU0EsNkJBQTZCQTs7dUJBRzdDQSxJQUFHQTtvQkFDUkEsY0FBMEJBLFlBQWtCQSw4Q0FBK0JBLFVBQVVBLGFBQWFBO29CQUNsR0EsSUFBSUEsUUFBUUE7d0JBQVNBLDZCQUE2QkE7O3VCQUc3Q0EsSUFBR0E7b0JBQ1JBLGNBQWdDQSxZQUF3QkEsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDOUdBLElBQUlBLFFBQVFBO3dCQUFTQSw2QkFBNkJBOzt1QkFHN0NBLElBQUdBO29CQUNSQSxjQUFnQ0EsWUFBd0JBLDhDQUErQkEsVUFBVUEsYUFBYUE7b0JBQzlHQSxJQUFJQSxRQUFRQTt3QkFBU0EsNkJBQTZCQTs7dUJBRzdDQSxJQUFHQTtvQkFDUkEsY0FBMEJBLFlBQWtCQSw4Q0FBK0JBLFVBQVVBLGFBQWFBO29CQUNsR0EsSUFBSUEsUUFBUUE7d0JBQVNBLDZCQUE2QkE7O3VCQUc3Q0EsSUFBR0E7b0JBQ1JBLGNBQXdCQSxZQUFnQkEsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDOUZBLElBQUlBLFFBQVFBO3dCQUFTQSw2QkFBNkJBOzt1QkFHN0NBLElBQUdBO29CQUNSQSxjQUE0QkEsWUFBb0JBLDhDQUErQkEsVUFBVUEsYUFBYUE7b0JBQ3RHQSxJQUFJQSxRQUFRQTt3QkFBU0EsNkJBQTZCQTs7dUJBRzdDQSxJQUFHQTtvQkFDUkEsY0FBNkJBLFlBQXFCQSw4Q0FBK0JBLFVBQVVBLGFBQWFBO29CQUN4R0EsSUFBSUEsUUFBUUE7d0JBQVNBLDZCQUE2QkE7O3VCQUc3Q0EsSUFBR0E7b0JBQ1JBLGNBQThCQSxZQUFzQkEsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDMUdBLElBQUlBLFFBQVFBO3dCQUFTQSw2QkFBNkJBOzt1QkFHN0NBLElBQUdBO29CQUNSQSxjQUFpQ0EsWUFBeUJBLDhDQUErQkEsVUFBVUEsYUFBYUE7b0JBQ2hIQSxJQUFJQSxRQUFRQTt3QkFBU0EsNkJBQTZCQTs7dUJBRzdDQSxJQUFHQTtvQkFDUkEsY0FBK0JBLFlBQXVCQSw4Q0FBK0JBLFVBQVVBLGFBQWFBO29CQUM1R0EsSUFBSUEsUUFBUUE7d0JBQVNBLDZCQUE2QkE7O3VCQUc3Q0EsSUFBR0E7b0JBQ1JBLGNBQXlCQSxZQUFpQkEsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDaEdBLElBQUlBLFFBQVFBO3dCQUFTQSw2QkFBNkJBOzt1QkFHN0NBLElBQUdBO29CQUNSQSxjQUF5QkEsWUFBaUJBLDhDQUErQkEsVUFBVUEsYUFBYUE7b0JBQ2hHQSxJQUFJQSxRQUFRQTt3QkFBU0EsNkJBQTZCQTs7dUJBRzdDQSxJQUFHQTtvQkFDUkEsY0FBeUJBLFlBQWlCQSw4Q0FBK0JBLFVBQVVBLGFBQWFBO29CQUNoR0EsSUFBSUEsUUFBUUE7d0JBQVNBLDZCQUE2QkE7O3VCQUc3Q0EsSUFBR0E7b0JBQ1JBLGNBQWlDQSxZQUF5QkEsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDaEhBLElBQUlBLFFBQVFBO3dCQUFTQSw2QkFBNkJBOzt1QkFHN0NBLElBQUdBO29CQUNSQSxjQUEyQkEsWUFBbUJBLDhDQUErQkEsVUFBVUEsYUFBYUE7b0JBQ3BHQSxJQUFJQSxRQUFRQTt3QkFBU0EsNkJBQTZCQTs7dUJBRzdDQSxJQUFHQTtvQkFDUkEsY0FBNEJBLFlBQW9CQSw4Q0FBK0JBLFVBQVVBLGFBQWFBO29CQUN0R0EsSUFBSUEsUUFBUUE7d0JBQVNBLDZCQUE2QkE7O3VCQUc3Q0EsSUFBR0E7b0JBQ1JBLGNBQTBCQSxZQUFrQkEsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDbEdBLElBQUlBLFFBQVFBO3dCQUFTQSw2QkFBNkJBOzt1QkFHN0NBLElBQUdBO29CQUNSQSxjQUE0QkEsWUFBb0JBLDhDQUErQkEsVUFBVUEsYUFBYUE7b0JBQ3RHQSxJQUFJQSxRQUFRQTt3QkFBU0EsNkJBQTZCQTs7dUJBRzdDQSxJQUFHQTtvQkFDUkEsY0FBMkJBLFlBQW1CQSw4Q0FBK0JBLFVBQVVBLGFBQWFBO29CQUNwR0EsSUFBSUEsUUFBUUE7d0JBQVNBLDZCQUE2QkE7O3VCQUc3Q0EsSUFBR0E7b0JBQ1JBLGNBQTJCQSxZQUFtQkEsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDcEdBLElBQUlBLFFBQVFBO3dCQUFTQSw2QkFBNkJBOzt1QkFHN0NBLElBQUdBO29CQUNSQSxjQUEwQkEsWUFBa0JBLDhDQUErQkEsVUFBVUEsYUFBYUE7b0JBQ2xHQSxJQUFJQSxRQUFRQTt3QkFBU0EsNkJBQTZCQTs7dUJBRzdDQSxJQUFHQTtvQkFDUkEsY0FBNEJBLFlBQW9CQSw4Q0FBK0JBLFVBQVVBLGFBQWFBO29CQUN0R0EsSUFBSUEsUUFBUUE7d0JBQVNBLDZCQUE2QkE7O3VCQUc3Q0EsSUFBR0E7b0JBQ1JBLGNBQTZCQSxZQUFxQkEsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDeEdBLElBQUlBLFFBQVFBO3dCQUFTQSw2QkFBNkJBOzt1QkFHN0NBLElBQUdBO29CQUNSQSxjQUE2QkEsWUFBcUJBLDhDQUErQkEsVUFBVUEsYUFBYUE7b0JBQ3hHQSxJQUFJQSxRQUFRQTt3QkFBU0EsNkJBQTZCQTs7dUJBRzdDQSxJQUFHQTtvQkFDUkEsY0FBb0NBLFlBQTRCQSw4Q0FBK0JBLFVBQVVBLGFBQWFBO29CQUN0SEEsSUFBSUEsUUFBUUE7d0JBQVNBLDZCQUE2QkE7O3VCQUc3Q0EsSUFBR0E7b0JBQ1JBLGNBQXdDQSxZQUFnQ0EsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDOUhBLElBQUlBLFFBQVFBO3dCQUFTQSw2QkFBNkJBOzt1QkFHN0NBLElBQUdBO29CQUNSQSxjQUFpQ0EsWUFBeUJBLDhDQUErQkEsVUFBVUEsYUFBYUE7b0JBQ2hIQSxJQUFJQSxRQUFRQTt3QkFBU0EsNkJBQTZCQTs7dUJBRzdDQSxJQUFHQTtvQkFDUkEsY0FBdUJBLFlBQWVBLDhDQUErQkEsVUFBVUEsYUFBYUE7b0JBQzVGQSxJQUFJQSxRQUFRQTt3QkFBU0EsNkJBQTZCQTs7dUJBRzdDQSxJQUFHQTtvQkFDUkEsY0FBMkJBLFlBQW1CQSw4Q0FBK0JBLFVBQVVBLGFBQWFBO29CQUNwR0EsSUFBSUEsUUFBUUE7d0JBQVNBLDZCQUE2QkE7O3VCQUc3Q0EsSUFBR0E7b0JBQ1JBLGNBQTJCQSxZQUFtQkEsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDcEdBLElBQUlBLFFBQVFBO3dCQUFTQSw2QkFBNkJBOzt1QkFHN0NBLElBQUdBO29CQUNSQSxjQUFzQkEsWUFBY0EsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDMUZBLElBQUlBLFFBQVFBO3dCQUFTQSw2QkFBNkJBOzs7OztzQ0FJNUJBO2dCQUN0QkE7Z0JBQ0FBLEFBQWlEQTtnQkFDakRBLEFBQWdEQSxnQkFBRUE7Z0JBQ2xEQSxPQUFPQTs7bUNBRWtCQSxJQUFhQTtnQkFDdENBO2dCQUNBQSxVQUFXQSxJQUFJQTtnQkFDZkEsWUFBWUEscUNBQVNBO2dCQUNyQkEsYUFBYUEscUNBQVNBO2dCQUN0QkEsMEVBQW9EQTtnQkFDcERBLHlFQUFtREE7Z0JBQ25EQSw4QkFBNkJBO2dCQUM3QkEsVUFBYUE7Z0JBQ2JBLGdFQUEwQ0E7Z0JBQzFDQSxXQUFZQTtnQkFDWkEsc0VBQWdEQTtnQkFDaERBLHFFQUErQ0E7Z0JBQy9DQSwwQkFBeUJBO2dCQUN6QkEsaUNBQWdDQTtnQkFDaENBLFlBQWFBLHFDQUFTQTtnQkFDdEJBLElBQUlBO29CQUFTQSxRQUFNQSxJQUFFQTs7Z0JBQ3JCQSxZQUFXQSxJQUFJQSwrQkFBS0Esa0JBQU1BLGFBQVVBLE9BQU9BLGtCQUFNQSxjQUFXQTtnQkFDNURBLDBFQUFvREE7Z0JBQ3BEQSx5RUFBbURBO2dCQUNuREEsOEJBQTZCQTtnQkFDN0JBLHFCQUFtQkEsK0JBQUNBLElBQUlBO29CQUN4QkEsWUFBYUE7b0JBQ2JBLFdBQWdCQSxnRkFBdURBO29CQUN2RUEsNEJBQTRCQTtvQkFDNUJBLG1DQUFtQ0E7b0JBQ25DQSxhQUFjQSxxQ0FBU0E7b0JBQ3ZCQSxJQUFJQTt3QkFBVUEsU0FBT0EsSUFBRUE7O29CQUN2QkEsYUFBWUEsSUFBSUEsK0JBQUtBLGtCQUFNQSxhQUFVQSxRQUFRQSxrQkFBTUEsY0FBV0E7b0JBQzlEQSwwRUFBb0RBO29CQUNwREEseUVBQW1EQTtvQkFDbkRBLGdDQUErQkE7b0JBQy9CQSxzRUFBZ0RBO29CQUNoREEscUVBQStDQTtvQkFDL0NBLDZFQUF1REE7b0JBQ3ZEQSw0RUFBc0RBO29CQUN0REEsU0FBWUEsWUFBUUE7b0JBQ3BCQSxJQUFJQSxNQUFLQTt3QkFDVEEsU0FBa0JBLHdFQUErQ0EsSUFBSUE7d0JBQ3JFQSxJQUFJQSxNQUFNQSxRQUFRQSxNQUFLQSxxQ0FBS0E7NEJBQzVCQTs7Ozs7OENBR29DQSxRQUFlQTtnQkFFbkRBLFNBQWFBLFlBQVNBO2dCQUN0QkEsSUFBSUEsTUFBS0E7b0JBQ1RBLFVBQXdCQSx3QkFBd0JBO29CQUNoREEsV0FBc0JBO29CQUN0QkEsZUFBa0JBO29CQUNsQkEsU0FBb0JBO29CQUNwQkEsVUFBVUE7b0JBQ1ZBLFVBQVVBO29CQUNWQSxjQUFjQTtvQkFDZEEsV0FBV0EsZ0NBQW1CQTtvQkFDOUJBLFVBQWFBLDhDQUErQkEsVUFBVUEsYUFBYUE7b0JBQ25FQSxpQkFBZ0JBLG1CQUFjQTtvQkFDOUJBLGVBQW9CQSw0Q0FBK0JBO29CQUNuREEsV0FBWUEsMEJBQWlCQSxrQkFBc0JBO29CQUNuREEsYUFBb0JBO29CQUNwQkEsZ0NBQWNBLCtCQUFLQTs7OzRDQUVlQSxRQUFlQTtnQkFFakRBLElBQUlBLFVBQVNBO29CQUViQSxTQUFhQSxZQUFTQTtvQkFDdEJBLElBQUdBLE1BQUdBO3dCQUNOQSxVQUF3QkEsd0JBQXdCQTt3QkFDaERBLFdBQXNCQTt3QkFDdEJBLGVBQWtCQTt3QkFDbEJBLFNBQW9CQTt3QkFDcEJBLFVBQVVBO3dCQUNWQSxVQUFVQTt3QkFDVkEsY0FBY0E7d0JBQ2RBLFdBQVdBLGdDQUFtQkE7d0JBQzlCQSxVQUFhQSw4Q0FBK0JBLFVBQVVBLGFBQWFBO3dCQUNuRUEsaUJBQWdCQSxtQkFBY0E7d0JBQzlCQSxlQUFvQkEsNENBQStCQTt3QkFDbkRBLFdBQVlBLDBCQUFpQkEsa0JBQXNCQTt3QkFDbkRBLGFBQW9CQTt3QkFDcEJBLGdDQUFjQSwrQkFBS0E7Ozs7O2dCRmg5QlBBLElBQUlBO29CQUNBQTs7Z0JBQ0pBOzs7Z0JBR0FBLElBQUlBO29CQUVBQSxBQUFDQSxZQUFtQ0EsQUFBUUE7OztnQkFJNURBLDRDQUE0Q0EsSUFBSUE7Z0JBQ2hEQSxpREFBaURBLElBQUlBO2dCQUNyREEsNENBQTRDQSxJQUFJQTtnQkFDaERBLDRDQUE0Q0EsSUFBSUE7O2dCQUVoREEsMkJBQXlCQTtnQkFDekJBO2dCQUNBQSxvREFBb0RBLElBQUlBOztnQkFFeERBLG9EQUFvREEsSUFBSUE7O2dCQUV4REEsdUNBQWlDQTtnQkFDakNBLHVDQUFpQ0E7O2dCQUVqQ0EsNENBQTRDQSxJQUFJQTtnQkFDaERBLHFEQUFxREEsSUFBSUE7Z0JBQ3pEQSx3REFBd0RBLElBQUlBLHFEQUF3Q0E7O2dCQUVwR0EscURBQXFEQSxJQUFJQTtnQkFDekRBLHdEQUF3REEsSUFBSUEscURBQXdDQTs7Z0JBRXBHQSx5REFBeURBO2dCQUN6REEseURBQXlEQTs7Z0JBRXpEQSwrQkFBNkJBO2dCQUM3QkE7O2dCQUVBQSxnQ0FBOEJBO2dCQUM5QkE7Z0JBQ0FBLG1EQUE2Q0E7O2dCQUU3Q0EsaUNBQStCQTtnQkFDL0JBO2dCQUNBQSxtREFBNkNBO2dCQUM3Q0EsbURBQW1EQTs7Z0JBRW5EQSxtQ0FBaUNBO2dCQUNqQ0E7Z0JBQ0FBLG1EQUE2Q0E7Z0JBQzdDQSxtREFBbURBOztnQkFFbkRBLG1EQUFtREE7Z0JBQ25EQSxtREFBbURBO2dCQUNuREEsbURBQW1EQTtnQkFDbkRBLG1EQUFtREE7OztnQkFHbkRBLGVBQWVBOztnQkFFZkEsNERBQTREQSxJQUFJQTtnQkFDaEVBO2dCQUNBQTtnQkFDQUE7Ozs7O2dCQUtBQSxlQUFVQTtnQkFDVkEsZ0JBQVdBO2dCQUNYQSxpQkFBWUE7Z0JBQ1pBLG1CQUFjQTtnQkFDZEEsV0FBTUE7O2dCQUVOQSx5REFBeURBLG1FQUFtRUEsSUFBSUEsMENBQStCQSxNQUFNQTtnQkFDcktBLElBQUdBO29CQUVDQSxnRUFBMERBLE1BQU1BLG9FQUE4REEsWUFBOEJBOztvQkFJNUpBLG1CQUFtQkEsQUFBdUJBOzs7Ozs7Ozs7Ozs7Ozt5Q0c3Q0FBOzs7O3VDQXBFTEEsSUFBbUJBO29CQUVoREEsVUFBYUEsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDbkVBLGlCQUFnQkEsbUJBQWVBO29CQUMvQkEsZUFBb0JBLDRDQUErQkE7O29CQUVuREEsU0FBWUEsZ0NBQW1CQTtvQkFDL0JBLElBQUlBO3dCQUFzQkEsS0FBS0EsYUFBZ0JBOztvQkFDL0NBLFdBQVlBLDBCQUFpQkEsa0JBQXNCQTs7b0JBRW5EQSxhQUFvQkE7O29CQUVwQkEsSUFBSUEsNEJBQWVBO3dCQUNmQSxPQUFPQSxZQUFRQSxnQ0FBY0Esa0JBQU1BOzt3QkFFbkNBLE9BQU9BLFlBQVFBLGdDQUFjQSxhQUFDQSxZQUFnQkEsMERBQWdCQTs7O3NDQUd0Q0EsSUFBbUJBO29CQUUvQ0EsVUFBYUEsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDbkVBLGlCQUFnQkEsbUJBQWVBO29CQUMvQkEsZUFBb0JBLDRDQUErQkE7O29CQUVuREEsU0FBWUEsZ0NBQW1CQTtvQkFDL0JBLElBQUlBO3dCQUFzQkEsS0FBS0EsYUFBZ0JBOztvQkFDL0NBLFdBQVlBLDBCQUFpQkEsa0JBQXNCQTs7b0JBRW5EQSxhQUFvQkE7O29CQUVwQkE7b0JBQ0FBLElBQUlBLFVBQVVBO3dCQUVWQSxJQUFJQSw0QkFBZUE7NEJBQ2ZBLFNBQVNBLFlBQVFBLGdDQUFjQSxrQkFBTUE7OzRCQUVyQ0EsU0FBU0EsWUFBUUEsZ0NBQWNBLGFBQUNBLFlBQWdCQSwwREFBZ0JBOzs7b0JBRXhFQSxPQUFPQTs7dUNBR3NCQSxJQUFtQkE7b0JBRWhEQTtvQkFDQUEsVUFBYUEsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDbkVBLGlCQUFnQkEsbUJBQWVBO29CQUMvQkEsZUFBb0JBLDRDQUErQkE7b0JBQ25EQSxTQUFZQSxnQ0FBbUJBOztvQkFFL0JBLElBQUlBO3dCQUFzQkEsS0FBS0EsYUFBZ0JBOztvQkFDL0NBLFdBQVlBLDBCQUFpQkEsa0JBQXNCQTtvQkFDbkRBLGFBQW9CQSwyQ0FBZUEsUUFBT0E7O29CQUUxQ0EsSUFBSUEsVUFBVUE7d0JBRVZBLElBQUlBLDRCQUFlQTs0QkFBU0EsU0FBU0EsWUFBUUEsZ0NBQWNBLGtCQUFNQTs7NEJBQzVEQSxTQUFTQSxZQUFRQSxnQ0FBY0EsYUFBQ0EsWUFBZ0JBLDBEQUFnQkE7OztvQkFFekVBLE9BQU9BOzt5Q0FHd0JBLElBQW1CQTtvQkFFbERBLFVBQXFCQSxZQUFnQkEsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDM0ZBLGFBQWdCQTtvQkFDaEJBLE9BQU9BOztvQ0FLbUJBLElBQW1CQTtvQkFFN0NBLElBQUlBO3dCQUF3QkEsT0FBT0E7O29CQUNuQ0E7O29CQUVBQSxVQUFhQSw2QkFBZ0JBO29CQUM3QkEsaUJBQWdCQSxtQkFBZUE7b0JBQy9CQSxlQUFvQkEsNENBQStCQTtvQkFDbkRBLElBQUlBLE1BQUtBO3dCQUVMQSxTQUFZQSxvQ0FBdUJBO3dCQUMvQ0EsSUFBSUEsTUFBS0E7NEJBQ1JBLElBQUlBO2dDQUFzQkEsS0FBS0EsYUFBZ0JBOzs0QkFDL0NBLFdBQVlBLDBCQUFpQkEsa0JBQXNCQTs7NEJBRW5EQSxhQUFvQkE7OzRCQUVwQkEsSUFBSUEsVUFBVUE7Z0NBRWJBLElBQUlBLDRCQUFlQTtvQ0FDbEJBLFNBQVNBLFlBQVFBLGdDQUFjQSxrQkFBTUE7O29DQUdyQ0EsV0FBc0JBLFlBQWdCQTtvQ0FDdENBLFNBQVNBLFlBQVFBLGdDQUFjQSwwQ0FBZ0JBOzs7O3dCQUl0Q0EsT0FBT0E7O3dCQUVOQTs7OzRDQUV1QkEsSUFBbUJBO29CQUUvQ0EsVUFBVUEsdUJBQWdCQTtvQkFDMUJBLElBQUlBO3dCQUVBQSw2QkFBZ0JBLEtBQUtBOzt3QkFHckJBLGdDQUFtQkEsS0FBS0E7OztvQkFHNUJBIiwKICAic291cmNlc0NvbnRlbnQiOiBbIi8vIDxDU0hUTUw1PjxYYW1sSGFzaD45MDNEMjFBN0I4RTVGOThGMDRFNTgzNjNFOTIxQjhFRDwvWGFtbEhhc2g+PFBhc3NOdW1iZXI+MjwvUGFzc051bWJlcj48Q29tcGlsYXRpb25EYXRlPjE2LzA5LzIwMjQgMDA6NTU6NDQ8L0NvbXBpbGF0aW9uRGF0ZT48L0NTSFRNTDU+XHJcblxyXG5cclxuXHJcbnB1YmxpYyBzdGF0aWMgY2xhc3Mgx4DHgFF3Y8eAx4BDb21wb25lbnTHgMeAQXBwx4DHgFhhbWzHgMeARmFjdG9yeVxyXG57XHJcbiAgICBwdWJsaWMgc3RhdGljIG9iamVjdCBJbnN0YW50aWF0ZSgpXHJcbiAgICB7XHJcbiAgICAgICAgZ2xvYmFsOjpTeXN0ZW0uVHlwZSB0eXBlID0gdHlwZW9mKFFXQy5BcHApO1xyXG4gICAgICAgIHJldHVybiBnbG9iYWw6OkNTSFRNTDUuSW50ZXJuYWwuVHlwZUluc3RhbnRpYXRpb25IZWxwZXIuSW5zdGFudGlhdGUodHlwZSk7XHJcbiAgICB9XHJcbn1cclxuXHJcbm5hbWVzcGFjZSBRV0Ncclxue1xyXG5cclxuXHJcbi8vLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcbi8vIDxhdXRvLWdlbmVyYXRlZD5cclxuLy8gICAgIFRoaXMgY29kZSB3YXMgYXV0by1nZW5lcmF0ZWQgYnkgXCJDIy9YQU1MIGZvciBIVE1MNVwiXHJcbi8vXHJcbi8vICAgICBDaGFuZ2VzIHRvIHRoaXMgZmlsZSBtYXkgY2F1c2UgaW5jb3JyZWN0IGJlaGF2aW9yIGFuZCB3aWxsIGJlIGxvc3QgaWZcclxuLy8gICAgIHRoZSBjb2RlIGlzIHJlZ2VuZXJhdGVkLlxyXG4vLyA8L2F1dG8tZ2VuZXJhdGVkPlxyXG4vLy0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG5cclxuXHJcblxyXG5wYXJ0aWFsIGNsYXNzIEFwcCA6IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkFwcGxpY2F0aW9uXHJcbntcclxuXHJcbiNwcmFnbWEgd2FybmluZyBkaXNhYmxlIDE2OSwgNjQ5LCAwNjI4IC8vIFByZXZlbnRzIHdhcm5pbmcgQ1MwMTY5ICgnZmllbGQgLi4uIGlzIG5ldmVyIHVzZWQnKSwgQ1MwNjQ5ICgnZmllbGQgLi4uIGlzIG5ldmVyIGFzc2lnbmVkIHRvLCBhbmQgd2lsbCBhbHdheXMgaGF2ZSBpdHMgZGVmYXVsdCB2YWx1ZSBudWxsJyksIGFuZCBDUzA2MjggKCdtZW1iZXIgOiBuZXcgcHJvdGVjdGVkIG1lbWJlciBkZWNsYXJlZCBpbiBzZWFsZWQgY2xhc3MnKVxyXG5cclxuXHJcblxyXG4jcHJhZ21hIHdhcm5pbmcgcmVzdG9yZSAxNjksIDY0OSwgMDYyOFxyXG5cclxuXHJcbiAgICAgICAgcHJpdmF0ZSBib29sIF9jb250ZW50TG9hZGVkO1xyXG4gICAgICAgIHB1YmxpYyB2b2lkIEluaXRpYWxpemVDb21wb25lbnQoKVxyXG4gICAgICAgIHtcclxuICAgICAgICAgICAgaWYgKF9jb250ZW50TG9hZGVkKVxyXG4gICAgICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgICAgICBfY29udGVudExvYWRlZCA9IHRydWU7XHJcblxyXG4jcHJhZ21hIHdhcm5pbmcgZGlzYWJsZSAwMTg0IC8vIFByZXZlbnRzIHdhcm5pbmcgQ1MwMTg0ICgnVGhlIGdpdmVuIGV4cHJlc3Npb24gaXMgbmV2ZXIgb2YgdGhlIHByb3ZpZGVkICgndHlwZScpIHR5cGUnKVxyXG4gICAgICAgICAgICBpZiAodGhpcyBpcyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5VSUVsZW1lbnQpXHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICgoZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuVUlFbGVtZW50KShvYmplY3QpdGhpcykuWGFtbFNvdXJjZVBhdGggPSBAXCJRV0NcXEFwcC54YW1sXCI7XHJcbiAgICAgICAgICAgIH1cclxuI3ByYWdtYSB3YXJuaW5nIHJlc3RvcmUgMDE4NFxyXG5cclxuXHJcbmdsb2JhbDo6Q1NIVE1MNS5JbnRlcm5hbC5TdGFydHVwQXNzZW1ibHlJbmZvLk91dHB1dFJvb3RQYXRoID0gQFwiT3V0cHV0XFxcIjtcclxuZ2xvYmFsOjpDU0hUTUw1LkludGVybmFsLlN0YXJ0dXBBc3NlbWJseUluZm8uT3V0cHV0QXBwRmlsZXNQYXRoID0gQFwiYXBwLWNzaHRtbDVcXGFwcFxcXCI7XHJcbmdsb2JhbDo6Q1NIVE1MNS5JbnRlcm5hbC5TdGFydHVwQXNzZW1ibHlJbmZvLk91dHB1dExpYnJhcmllc1BhdGggPSBAXCJhcHAtY3NodG1sNVxcbGlic1xcXCI7XHJcbmdsb2JhbDo6Q1NIVE1MNS5JbnRlcm5hbC5TdGFydHVwQXNzZW1ibHlJbmZvLk91dHB1dFJlc291cmNlc1BhdGggPSBAXCJhcHAtY3NodG1sNVxccmVzXFxcIjtcclxuXHJcblxyXG52YXIgUmVzb3VyY2VEaWN0aW9uYXJ5X2UyOTUyZmJiNmFiZDQyYjFiOTZmZDdhOWY5ZTAwODZkID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlJlc291cmNlRGljdGlvbmFyeSgpO1xyXG50aGlzLlJlc291cmNlcyA9IFJlc291cmNlRGljdGlvbmFyeV9lMjk1MmZiYjZhYmQ0MmIxYjk2ZmQ3YTlmOWUwMDg2ZDtcclxudmFyIEludENvbnZlcnRlcl80ZjBmYzAyOTA4MjY0MjYwOWU5MWVjNGRjMjQxYTQ3NCA9IG5ldyBnbG9iYWw6OkFQTEV4dGVuc2lvbi5JbnRDb252ZXJ0ZXIoKTtcclxuXHJcbnZhciBEZWNDb252ZXJ0ZXJfNmRiMDA2Y2I1NDRhNDAwMzg3NmQzODlmMTRiZGZhZTYgPSBuZXcgZ2xvYmFsOjpBUExFeHRlbnNpb24uRGVjQ29udmVydGVyKCk7XHJcblxyXG52YXIgVG9Qb2x5TGluZUNvbnZlcnRlcl9jMTRiOTVjMjU3OWM0ZTUyOTljZmFmMGM3ZWRjZWExOSA9IG5ldyBnbG9iYWw6OkFQTEV4dGVuc2lvbi5Ub1BvbHlMaW5lQ29udmVydGVyKCk7XHJcblxyXG52YXIgVG9Qb2ludHNDb252ZXJ0ZXJfY2U2ZDkzOGUxMDQ2NDQ0M2E0MGI2MDk2Y2VlMDc4NmMgPSBuZXcgZ2xvYmFsOjpBUExFeHRlbnNpb24uVG9Qb2ludHNDb252ZXJ0ZXIoKTtcclxuXHJcbnZhciBUb0xpbmVzQ29udmVydGVyXzMxYTgzNDFlZTEyNTRlOTY4YmRiMWE4NmFkMzMyYmM5ID0gbmV3IGdsb2JhbDo6QVBMRXh0ZW5zaW9uLlRvTGluZXNDb252ZXJ0ZXIoKTtcclxuXHJcbnZhciBBUExDb2xvckNvbnZlcnRlcl9lNmI1NjMzYjVjNDI0NGE0OWRhYmE4MWIwOThhMzFmNyA9IG5ldyBnbG9iYWw6OkFQTEV4dGVuc2lvbi5BUExDb2xvckNvbnZlcnRlcigpO1xyXG5cclxudmFyIEFQTENvbG9yQ1NTQ29udmVydGVyXzMwYjk3MzgxMmNmMjQ4MzNhMGE5N2QyNmYwN2RlMjNmID0gbmV3IGdsb2JhbDo6QVBMRXh0ZW5zaW9uLkFQTENvbG9yQ1NTQ29udmVydGVyKCk7XHJcblxyXG52YXIgQVBMTXVsdGlDb2xvckNvbnZlcnRlcl8xYWY5MDQ1ZDkwYTE0MTg3ODhiMmI0OTQxYmU2ZmZmMCA9IG5ldyBnbG9iYWw6OkFQTEV4dGVuc2lvbi5BUExNdWx0aUNvbG9yQ29udmVydGVyKCk7XHJcblxyXG52YXIgQVBMTXVsdGlDb2xvckNTU0NvbnZlcnRlcl8xYzc3ODg0ZDA4ZmQ0MGZmODNlYWVhNzA2NDIwMjBjNSA9IG5ldyBnbG9iYWw6OkFQTEV4dGVuc2lvbi5BUExNdWx0aUNvbG9yQ1NTQ29udmVydGVyKCk7XHJcblxyXG52YXIgSW5kZXhJbnQzMkNvbnZlcnRlcl84OTMzNzgxZWY5NzQ0MTU0YTBmMGUxMmMzOGNjMTRlOSA9IG5ldyBnbG9iYWw6OkFQTEV4dGVuc2lvbi5JbmRleEludDMyQ29udmVydGVyKCk7XHJcblxyXG52YXIgSW5kZXhEb3VibGVDb252ZXJ0ZXJfNjU3NTM3OWFkMzlkNGExNmFkMDljNDJkZDM3NjFmZTMgPSBuZXcgZ2xvYmFsOjpBUExFeHRlbnNpb24uSW5kZXhEb3VibGVDb252ZXJ0ZXIoKTtcclxuXHJcbnZhciBJbmRleFN0cmluZ0NvbnZlcnRlcl81ZTJjNTM2YzQ5ZDM0ZmNjOWIwMWYxMDQ0MTY1ZDU2YyA9IG5ldyBnbG9iYWw6OkFQTEV4dGVuc2lvbi5JbmRleFN0cmluZ0NvbnZlcnRlcigpO1xyXG5cclxudmFyIEluZGV4QVBMQ29sb3JDb252ZXJ0ZXJfYzk3NmQyZWRhZjViNGExMmJhZmE3YWRmYzU3MzcxYjQgPSBuZXcgZ2xvYmFsOjpBUExFeHRlbnNpb24uSW5kZXhBUExDb2xvckNvbnZlcnRlcigpO1xyXG5cclxudmFyIEluZGV4QVBMQ29sb3VyQ29udmVydGVyX2Y2YWQzNTEyMTBjZTQxZWQ5YTIxMjIwM2Q4NmNlZjE2ID0gbmV3IGdsb2JhbDo6QVBMRXh0ZW5zaW9uLkluZGV4QVBMQ29sb3VyQ29udmVydGVyKCk7XHJcblxyXG52YXIgTWF0aHNJQ29udmVydGVyXzAyN2JhNTFhOTFkODQ0NjY5ZjJiNmRkNGZlMWNhOWE5ID0gbmV3IGdsb2JhbDo6QVBMRXh0ZW5zaW9uLk1hdGhzSUNvbnZlcnRlcigpO1xyXG5cclxudmFyIE1hdGhzRENvbnZlcnRlcl9kYmI2NjRkYWExNjM0NjQ3OWJkMGE5NGM0ZjFiYjU4ZSA9IG5ldyBnbG9iYWw6OkFQTEV4dGVuc2lvbi5NYXRoc0RDb252ZXJ0ZXIoKTtcclxuXHJcbnZhciBNYXRoSUNvbnZlcnRlcl82MTM1Mzk4NzZiYjE0ZTEzOTgyYjUyNmE3YTRiMWM2ZCA9IG5ldyBnbG9iYWw6OkFQTEV4dGVuc2lvbi5NYXRoSUNvbnZlcnRlcigpO1xyXG5cclxudmFyIE1hdGhEQ29udmVydGVyXzA5MDQzYzkxODM5MjRhMWQ4Y2I5YmIyZmZkYWM1YWRjID0gbmV3IGdsb2JhbDo6QVBMRXh0ZW5zaW9uLk1hdGhEQ29udmVydGVyKCk7XHJcblxyXG5nbG9iYWw6OlN5c3RlbS5TdHJpbmcgU3RyaW5nX2MxYWUzNGQ2MGE0MzQ5M2Q4YjkyOWZkNjkzMGRhMTJhID0gQFwi4o6VV0MgQ3Jvc3MgUGxhdGZvcm1cIjtcclxuXHJcbmdsb2JhbDo6U3lzdGVtLlN0cmluZyBTdHJpbmdfMzgzMGY3NmI0ZjNjNGI5YWFlNzY4ZDJlZTZlOGFiNjkgPSBAXCJNSkggU29mdHdhcmUgU2VydmljZXMgTHRkXCI7XHJcblxyXG5nbG9iYWw6OlN5c3RlbS5TdHJpbmcgU3RyaW5nX2ZiYTU1ZTI3YjA5MDRlMmJiNGZlMTgxNGRjNzZlNWVjID0gQFwiTUpIIFNvZnR3YXJlIFNlcnZpY2VzIEx0ZFwiO1xyXG5cclxuZ2xvYmFsOjpTeXN0ZW0uU3RyaW5nIFN0cmluZ19kNzBjZDFhYzkwMzA0NWY2OTUxODY3ZTQ2MzFjNDg5ZCA9IEBcIlFXQ1wiO1xyXG5cclxuZ2xvYmFsOjpTeXN0ZW0uU3RyaW5nIFN0cmluZ184M2RkNmIzMmM0MWM0NWE0OGJmN2FlYmZkNTcwMDI3MCA9IEBcIuKOlVdDIENyb3NzIFBsYXRmb3JtXCI7XHJcblxyXG5nbG9iYWw6OlN5c3RlbS5TdHJpbmcgU3RyaW5nX2E5ODQxOTRkM2U1MTRhMDliYjgxY2E4YTAwZWU3NWJkID0gQFwibWpoLmljb1wiO1xyXG5cclxuZ2xvYmFsOjpTeXN0ZW0uU3RyaW5nIFN0cmluZ183Y2QxNjc2OTIyN2E0ODBjYmQ4YjRiNWQyNmM3MzZlYiA9IEBcIjEyMzQ1XCI7XHJcblxyXG5nbG9iYWw6OlN5c3RlbS5TdHJpbmcgU3RyaW5nX2U0NWRjNTJlOGUxYzQ4ZThhMjcyM2MzNDc4YWJmN2JjID0gQFwiTWFpblBhZ2VcIjtcclxuXHJcbmdsb2JhbDo6U3lzdGVtLlN0cmluZyBTdHJpbmdfMjBhMDkwODQyMGE4NDA4YzliZjNlMmNlMDg0MWYxNzkgPSBAXCJNYWluUGFnZTpQYWdlXCI7XHJcblxyXG5nbG9iYWw6OlN5c3RlbS5TdHJpbmcgU3RyaW5nXzY3YTYwNjdkZjFlNjQ1MDM4OTViYmE1ZWJlM2MzMmE0ID0gQFwiRGlyZWN0XCI7XHJcblxyXG5nbG9iYWw6OlN5c3RlbS5TdHJpbmcgU3RyaW5nX2FiODMxNDI5MzAzZDQwZmM4MjNiYmE0MTAxMTg2MjQyID0gQFwiUVdDXCI7XHJcblxyXG52YXIgU3R5bGVfYjc4YTNkZTFlMWM4NGVhNTg2M2RjNWI0NjNiNzFhZDMgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuU3R5bGUoKTtcclxuU3R5bGVfYjc4YTNkZTFlMWM4NGVhNTg2M2RjNWI0NjNiNzFhZDMuVGFyZ2V0VHlwZSA9IHR5cGVvZihnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Db250cm9scy5DaGlsZFdpbmRvdyk7XHJcbnZhciBTZXR0ZXJfNzQ0MzUyMGE2NzQxNGZjYWFmNTY2OWNlYWQ2ZmQ5ODEgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuU2V0dGVyKCk7XHJcblNldHRlcl83NDQzNTIwYTY3NDE0ZmNhYWY1NjY5Y2VhZDZmZDk4MS5Qcm9wZXJ0eSA9IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkNvbnRyb2xzLkNoaWxkV2luZG93Lk92ZXJsYXlCcnVzaFByb3BlcnR5O1xyXG5TZXR0ZXJfNzQ0MzUyMGE2NzQxNGZjYWFmNTY2OWNlYWQ2ZmQ5ODEuVmFsdWUgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuTWVkaWEuU29saWRDb2xvckJydXNoKG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuQ29sb3IoKSB7IEEgPSAoYnl0ZSkwLCBSID0gKGJ5dGUpMjU1LCBHID0gKGJ5dGUpMjU1LCBCID0gKGJ5dGUpMjU1IH0pO1xyXG5cclxudmFyIFNldHRlcl8zNzcwZGE1MTg2MmU0YTc5YTBlM2MzODM1MWRjZjZlMSA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5TZXR0ZXIoKTtcclxuU2V0dGVyXzM3NzBkYTUxODYyZTRhNzlhMGUzYzM4MzUxZGNmNmUxLlByb3BlcnR5ID0gZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuQ29udHJvbHMuQ2hpbGRXaW5kb3cuT3ZlcmxheU9wYWNpdHlQcm9wZXJ0eTtcclxuU2V0dGVyXzM3NzBkYTUxODYyZTRhNzlhMGUzYzM4MzUxZGNmNmUxLlZhbHVlID0gMUQ7XHJcblxyXG52YXIgU2V0dGVyXzA0MmZkZmQ3YmNhOTRhYzU5MmNkNmIyYTRiODllYWE4ID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlNldHRlcigpO1xyXG5TZXR0ZXJfMDQyZmRmZDdiY2E5NGFjNTkyY2Q2YjJhNGI4OWVhYTguUHJvcGVydHkgPSBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Db250cm9scy5DaGlsZFdpbmRvdy5Ib3Jpem9udGFsQWxpZ25tZW50UHJvcGVydHk7XHJcblNldHRlcl8wNDJmZGZkN2JjYTk0YWM1OTJjZDZiMmE0Yjg5ZWFhOC5WYWx1ZSA9IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkhvcml6b250YWxBbGlnbm1lbnQuTGVmdDtcclxuXHJcbnZhciBTZXR0ZXJfOTNiYWQ1MDJhYTVlNDQxOGI5NDViYzA1ZWQyMTA3YjIgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuU2V0dGVyKCk7XHJcblNldHRlcl85M2JhZDUwMmFhNWU0NDE4Yjk0NWJjMDVlZDIxMDdiMi5Qcm9wZXJ0eSA9IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkNvbnRyb2xzLkNoaWxkV2luZG93LlZlcnRpY2FsQWxpZ25tZW50UHJvcGVydHk7XHJcblNldHRlcl85M2JhZDUwMmFhNWU0NDE4Yjk0NWJjMDVlZDIxMDdiMi5WYWx1ZSA9IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlZlcnRpY2FsQWxpZ25tZW50LlRvcDtcclxuXHJcbnZhciBTZXR0ZXJfNGNmNzg0MGRlZDk4NDE0N2I0YjM2NmFlZDRlNGMwNDYgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuU2V0dGVyKCk7XHJcblNldHRlcl80Y2Y3ODQwZGVkOTg0MTQ3YjRiMzY2YWVkNGU0YzA0Ni5Qcm9wZXJ0eSA9IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkNvbnRyb2xzLkNoaWxkV2luZG93LlRlbXBsYXRlUHJvcGVydHk7XHJcbnZhciBDb250cm9sVGVtcGxhdGVfNDEwMjM5OWQwNjdhNDA2OTlhYmUyNzc1MGFkYTM1MDQgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuQ29udHJvbHMuQ29udHJvbFRlbXBsYXRlKCk7XHJcbkNvbnRyb2xUZW1wbGF0ZV80MTAyMzk5ZDA2N2E0MDY5OWFiZTI3NzUwYWRhMzUwNC5UYXJnZXRUeXBlID0gdHlwZW9mKGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkNvbnRyb2xzLkNoaWxkV2luZG93KTtcclxuQ29udHJvbFRlbXBsYXRlXzQxMDIzOTlkMDY3YTQwNjk5YWJlMjc3NTBhZGEzNTA0LlNldE1ldGhvZFRvSW5zdGFudGlhdGVGcmFtZXdvcmtUZW1wbGF0ZSgoU3lzdGVtLkZ1bmM8V2luZG93cy5VSS5YYW1sLkNvbnRyb2xzLkNvbnRyb2wsV2luZG93cy5VSS5YYW1sLlRlbXBsYXRlSW5zdGFuY2U+KSh0ZW1wbGF0ZU93bmVyX0NvbnRyb2xUZW1wbGF0ZV80MTAyMzk5ZDA2N2E0MDY5OWFiZTI3NzUwYWRhMzUwNCA9PiBcclxue1xyXG52YXIgdGVtcGxhdGVJbnN0YW5jZV83OTZkMzg2YWZhYTQ0Yzk3YjRlNzkwOWQxMmUzNDgzZiA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5UZW1wbGF0ZUluc3RhbmNlKCk7XHJcbnRlbXBsYXRlSW5zdGFuY2VfNzk2ZDM4NmFmYWE0NGM5N2I0ZTc5MDlkMTJlMzQ4M2YuVGVtcGxhdGVPd25lciA9IHRlbXBsYXRlT3duZXJfQ29udHJvbFRlbXBsYXRlXzQxMDIzOTlkMDY3YTQwNjk5YWJlMjc3NTBhZGEzNTA0O1xyXG52YXIgVmlzdWFsU3RhdGVfMjg2MGQzNGUxNzFmNDc4N2IxZmE2N2JmMTg1ZTQ3MzcgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuVmlzdWFsU3RhdGUoKTtcclxudmFyIFZpc3VhbFN0YXRlXzU2YTM2Yjg3YzQyODQ2ZTlhZjAxNjFkNzY1Njg3MjA5ID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlZpc3VhbFN0YXRlKCk7XHJcbnZhciBWaXN1YWxTdGF0ZUdyb3VwXzNlMzZiMTI5NmI1YzQ0NTg5N2VhYzNkZTY3NWZjOTIzID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlZpc3VhbFN0YXRlR3JvdXAoKTtcclxudmFyIEdyaWRfZWU0YzdjYjQzMDYzNDZmOTlmNzQ4NTUzNmQzNzU1M2EgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuQ29udHJvbHMuR3JpZCgpO1xyXG52YXIgQnV0dG9uXzYwZmFlMjA0N2RmNzRkNzhhYmY1ZjA5NDY0NjVkNjNlID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkNvbnRyb2xzLkJ1dHRvbigpO1xyXG52YXIgQ29udGVudENvbnRyb2xfYmM3YTFkYzY0ZGQwNDgyZjlmN2U0M2Y3NTE4OWE0MTQgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuQ29udHJvbHMuQ29udGVudENvbnRyb2woKTtcclxudmFyIEJ1dHRvbl8zMGIyZDFkZThjNzk0YTQ1OTBlMzQzNTZhN2UwYzU1ZiA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Db250cm9scy5CdXR0b24oKTtcclxudmFyIEJ1dHRvbl8xNjFiM2M5Y2E5MTU0OGVlYTAzMWUxMDk0MzU0Yjg3ZCA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Db250cm9scy5CdXR0b24oKTtcclxudmFyIEJ1dHRvbl9kNGM4NjQxNjVjOTg0NGMyODU0MjhlZmExNThlOGQ5ZiA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Db250cm9scy5CdXR0b24oKTtcclxudmFyIEJ1dHRvbl80NmYyZGQ1MGIyOGM0ZjI5YWI3NWEzNTE3MWMxNTVjNSA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Db250cm9scy5CdXR0b24oKTtcclxudmFyIEJ1dHRvbl80NDJjZTViNmNhYTQ0MzQ1YThjNGI0MDRkOWUyYzE2MiA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Db250cm9scy5CdXR0b24oKTtcclxudmFyIEJvcmRlcl9kNDY0MTI2OGY0MWI0NzdmYjZhNjRkNDBmMmNmMjlmMyA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Db250cm9scy5Cb3JkZXIoKTtcclxudmFyIENvbnRlbnRQcmVzZW50ZXJfZmJlZDhhMWE0Mjg4NDJmZDgxNmZhYmY5ZDhlMTExNjQgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuQ29udHJvbHMuQ29udGVudFByZXNlbnRlcigpO1xyXG52YXIgQm9yZGVyX2MxZmNhZGI0ZjZkOTQ5OWJiMGYyNWY5YjhjOGYwMjI0ID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkNvbnRyb2xzLkJvcmRlcigpO1xyXG52YXIgQm9yZGVyX2YzNmZmZjdiYTZhNjQyZWZhYTQ5ZDhkZGU3Mjc3MDU5ID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkNvbnRyb2xzLkJvcmRlcigpO1xyXG52YXIgR3JpZF9hZjg2NDA0ODU4ZjY0ODEyYjg1YjYwOGVkMjg5YWQ4NCA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Db250cm9scy5HcmlkKCk7XHJcbnRlbXBsYXRlT3duZXJfQ29udHJvbFRlbXBsYXRlXzQxMDIzOTlkMDY3YTQwNjk5YWJlMjc3NTBhZGEzNTA0LlJlZ2lzdGVyTmFtZShcIlJvb3RcIiwgR3JpZF9hZjg2NDA0ODU4ZjY0ODEyYjg1YjYwOGVkMjg5YWQ4NCk7XHJcbkdyaWRfYWY4NjQwNDg1OGY2NDgxMmI4NWI2MDhlZDI4OWFkODQuTmFtZSA9IFwiUm9vdFwiO1xyXG5HcmlkX2FmODY0MDQ4NThmNjQ4MTJiODViNjA4ZWQyODlhZDg0LlJlbmRlclRyYW5zZm9ybU9yaWdpbiA9IG5ldyBnbG9iYWw6OldpbmRvd3MuRm91bmRhdGlvbi5Qb2ludCgwLCAwKTtcclxudGVtcGxhdGVPd25lcl9Db250cm9sVGVtcGxhdGVfNDEwMjM5OWQwNjdhNDA2OTlhYmUyNzc1MGFkYTM1MDQuUmVnaXN0ZXJOYW1lKFwiTW9kYWxTdGF0ZXNcIiwgVmlzdWFsU3RhdGVHcm91cF8zZTM2YjEyOTZiNWM0NDU4OTdlYWMzZGU2NzVmYzkyMyk7XHJcblZpc3VhbFN0YXRlR3JvdXBfM2UzNmIxMjk2YjVjNDQ1ODk3ZWFjM2RlNjc1ZmM5MjMuTmFtZSA9IFwiTW9kYWxTdGF0ZXNcIjtcclxudGVtcGxhdGVPd25lcl9Db250cm9sVGVtcGxhdGVfNDEwMjM5OWQwNjdhNDA2OTlhYmUyNzc1MGFkYTM1MDQuUmVnaXN0ZXJOYW1lKFwiTm90TW9kYWxcIiwgVmlzdWFsU3RhdGVfMjg2MGQzNGUxNzFmNDc4N2IxZmE2N2JmMTg1ZTQ3MzcpO1xyXG5WaXN1YWxTdGF0ZV8yODYwZDM0ZTE3MWY0Nzg3YjFmYTY3YmYxODVlNDczNy5OYW1lID0gXCJOb3RNb2RhbFwiO1xyXG52YXIgU3Rvcnlib2FyZF9lNjc5YTQ1YWFkYzI0YTU1ODhhZTEyOGIzZTljYjA5YSA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5NZWRpYS5BbmltYXRpb24uU3Rvcnlib2FyZCgpO1xyXG52YXIgT2JqZWN0QW5pbWF0aW9uVXNpbmdLZXlGcmFtZXNfMDM1ZTgwZDBhYjk5NDZhMTg4OTgyZDYwODZhYTVhMjQgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuTWVkaWEuQW5pbWF0aW9uLk9iamVjdEFuaW1hdGlvblVzaW5nS2V5RnJhbWVzKCk7XHJcbmdsb2JhbDo6V2luZG93cy5VSS5YYW1sLk1lZGlhLkFuaW1hdGlvbi5TdG9yeWJvYXJkLlNldFRhcmdldE5hbWUoT2JqZWN0QW5pbWF0aW9uVXNpbmdLZXlGcmFtZXNfMDM1ZTgwZDBhYjk5NDZhMTg4OTgyZDYwODZhYTVhMjQsQFwiT3ZlcmxheVwiKTtcclxudmFyIERpc2NyZXRlT2JqZWN0S2V5RnJhbWVfYmM3OWFjMThiOTMzNGMwMmEyM2VlOGI0YjhhMmIxNGQgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuTWVkaWEuQW5pbWF0aW9uLkRpc2NyZXRlT2JqZWN0S2V5RnJhbWUoKTtcclxudmFyIE51bGxFeHRlbnNpb25fODNjZGIzMTdlZjA5NGUzZmJjMzVhOTFkOTUzODgzNGIgPSBuZXcgZ2xvYmFsOjpTeXN0ZW0uV2luZG93cy5NYXJrdXAuTnVsbEV4dGVuc2lvbigpO1xyXG5cclxuRGlzY3JldGVPYmplY3RLZXlGcmFtZV9iYzc5YWMxOGI5MzM0YzAyYTIzZWU4YjRiOGEyYjE0ZC5WYWx1ZSA9IG51bGw7XHJcblxyXG5cclxuT2JqZWN0QW5pbWF0aW9uVXNpbmdLZXlGcmFtZXNfMDM1ZTgwZDBhYjk5NDZhMTg4OTgyZDYwODZhYTVhMjQuS2V5RnJhbWVzLkFkZChEaXNjcmV0ZU9iamVjdEtleUZyYW1lX2JjNzlhYzE4YjkzMzRjMDJhMjNlZThiNGI4YTJiMTRkKTtcclxuXHJcblxyXG52YXIgT2JqZWN0QW5pbWF0aW9uVXNpbmdLZXlGcmFtZXNfZTZlZDcyMDEwMWM4NDE5NTgyOWM2OWVmZTM1NGRlMDYgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuTWVkaWEuQW5pbWF0aW9uLk9iamVjdEFuaW1hdGlvblVzaW5nS2V5RnJhbWVzKCk7XHJcbmdsb2JhbDo6V2luZG93cy5VSS5YYW1sLk1lZGlhLkFuaW1hdGlvbi5TdG9yeWJvYXJkLlNldFRhcmdldE5hbWUoT2JqZWN0QW5pbWF0aW9uVXNpbmdLZXlGcmFtZXNfZTZlZDcyMDEwMWM4NDE5NTgyOWM2OWVmZTM1NGRlMDYsQFwiT3ZlcmxheVwiKTtcclxudmFyIERpc2NyZXRlT2JqZWN0S2V5RnJhbWVfZmZlYzI0NzE2NDA1NDFmZDgxMzk3NDcyOTFjMThkNzkgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuTWVkaWEuQW5pbWF0aW9uLkRpc2NyZXRlT2JqZWN0S2V5RnJhbWUoKTtcclxuRGlzY3JldGVPYmplY3RLZXlGcmFtZV9mZmVjMjQ3MTY0MDU0MWZkODEzOTc0NzI5MWMxOGQ3OS5WYWx1ZSA9IEBcIkZhbHNlXCI7XHJcblxyXG5PYmplY3RBbmltYXRpb25Vc2luZ0tleUZyYW1lc19lNmVkNzIwMTAxYzg0MTk1ODI5YzY5ZWZlMzU0ZGUwNi5LZXlGcmFtZXMuQWRkKERpc2NyZXRlT2JqZWN0S2V5RnJhbWVfZmZlYzI0NzE2NDA1NDFmZDgxMzk3NDcyOTFjMThkNzkpO1xyXG5cclxuXHJcblN0b3J5Ym9hcmRfZTY3OWE0NWFhZGMyNGE1NTg4YWUxMjhiM2U5Y2IwOWEuQ2hpbGRyZW4uQWRkKE9iamVjdEFuaW1hdGlvblVzaW5nS2V5RnJhbWVzXzAzNWU4MGQwYWI5OTQ2YTE4ODk4MmQ2MDg2YWE1YTI0KTtcclxuU3Rvcnlib2FyZF9lNjc5YTQ1YWFkYzI0YTU1ODhhZTEyOGIzZTljYjA5YS5DaGlsZHJlbi5BZGQoT2JqZWN0QW5pbWF0aW9uVXNpbmdLZXlGcmFtZXNfZTZlZDcyMDEwMWM4NDE5NTgyOWM2OWVmZTM1NGRlMDYpO1xyXG5cclxuXHJcblZpc3VhbFN0YXRlXzI4NjBkMzRlMTcxZjQ3ODdiMWZhNjdiZjE4NWU0NzM3LlN0b3J5Ym9hcmQgPSBTdG9yeWJvYXJkX2U2NzlhNDVhYWRjMjRhNTU4OGFlMTI4YjNlOWNiMDlhO1xyXG5cclxuXHJcbnRlbXBsYXRlT3duZXJfQ29udHJvbFRlbXBsYXRlXzQxMDIzOTlkMDY3YTQwNjk5YWJlMjc3NTBhZGEzNTA0LlJlZ2lzdGVyTmFtZShcIk1vZGFsXCIsIFZpc3VhbFN0YXRlXzU2YTM2Yjg3YzQyODQ2ZTlhZjAxNjFkNzY1Njg3MjA5KTtcclxuVmlzdWFsU3RhdGVfNTZhMzZiODdjNDI4NDZlOWFmMDE2MWQ3NjU2ODcyMDkuTmFtZSA9IFwiTW9kYWxcIjtcclxuXHJcblZpc3VhbFN0YXRlR3JvdXBfM2UzNmIxMjk2YjVjNDQ1ODk3ZWFjM2RlNjc1ZmM5MjMuU3RhdGVzLkFkZChWaXN1YWxTdGF0ZV8yODYwZDM0ZTE3MWY0Nzg3YjFmYTY3YmYxODVlNDczNyk7XHJcblZpc3VhbFN0YXRlR3JvdXBfM2UzNmIxMjk2YjVjNDQ1ODk3ZWFjM2RlNjc1ZmM5MjMuU3RhdGVzLkFkZChWaXN1YWxTdGF0ZV81NmEzNmI4N2M0Mjg0NmU5YWYwMTYxZDc2NTY4NzIwOSk7XHJcblxyXG5cclxudGVtcGxhdGVPd25lcl9Db250cm9sVGVtcGxhdGVfNDEwMjM5OWQwNjdhNDA2OTlhYmUyNzc1MGFkYTM1MDQuSU5URVJOQUxfR2V0VmlzdWFsU3RhdGVHcm91cHMoKS5BZGQoVmlzdWFsU3RhdGVHcm91cF8zZTM2YjEyOTZiNWM0NDU4OTdlYWMzZGU2NzVmYzkyMyk7XHJcblxyXG50ZW1wbGF0ZU93bmVyX0NvbnRyb2xUZW1wbGF0ZV80MTAyMzk5ZDA2N2E0MDY5OWFiZTI3NzUwYWRhMzUwNC5SZWdpc3Rlck5hbWUoXCJPdmVybGF5XCIsIEdyaWRfZWU0YzdjYjQzMDYzNDZmOTlmNzQ4NTUzNmQzNzU1M2EpO1xyXG5HcmlkX2VlNGM3Y2I0MzA2MzQ2Zjk5Zjc0ODU1MzZkMzc1NTNhLk5hbWUgPSBcIk92ZXJsYXlcIjtcclxuR3JpZF9lZTRjN2NiNDMwNjM0NmY5OWY3NDg1NTM2ZDM3NTUzYS5Ib3Jpem9udGFsQWxpZ25tZW50ID0gZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuSG9yaXpvbnRhbEFsaWdubWVudC5TdHJldGNoO1xyXG5HcmlkX2VlNGM3Y2I0MzA2MzQ2Zjk5Zjc0ODU1MzZkMzc1NTNhLlZlcnRpY2FsQWxpZ25tZW50ID0gZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuVmVydGljYWxBbGlnbm1lbnQuU3RyZXRjaDtcclxuR3JpZF9lZTRjN2NiNDMwNjM0NmY5OWY3NDg1NTM2ZDM3NTUzYS5NYXJnaW4gPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuVGhpY2tuZXNzKDApO1xyXG52YXIgQmluZGluZ184NmNkMzJhMzIzZjQ0NmYxODNmNGIzODVlZDgwMDAzYSA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmcoKTtcclxuQmluZGluZ184NmNkMzJhMzIzZjQ0NmYxODNmNGIzODVlZDgwMDAzYS5QYXRoID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlByb3BlcnR5UGF0aChAXCJPdmVybGF5QnJ1c2hcIik7XHJcbnZhciBSZWxhdGl2ZVNvdXJjZV80YTIwNDM2MThjZGE0OTA2OTZkNzliMDc2ZGQyOTRjMiA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLlJlbGF0aXZlU291cmNlKCk7XHJcblJlbGF0aXZlU291cmNlXzRhMjA0MzYxOGNkYTQ5MDY5NmQ3OWIwNzZkZDI5NGMyLk1vZGUgPSBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLlJlbGF0aXZlU291cmNlTW9kZS5UZW1wbGF0ZWRQYXJlbnQ7XHJcblxyXG5CaW5kaW5nXzg2Y2QzMmEzMjNmNDQ2ZjE4M2Y0YjM4NWVkODAwMDNhLlJlbGF0aXZlU291cmNlID0gUmVsYXRpdmVTb3VyY2VfNGEyMDQzNjE4Y2RhNDkwNjk2ZDc5YjA3NmRkMjk0YzI7XHJcblxyXG5cclxuQmluZGluZ184NmNkMzJhMzIzZjQ0NmYxODNmNGIzODVlZDgwMDAzYS5UZW1wbGF0ZU93bmVyID0gdGVtcGxhdGVJbnN0YW5jZV83OTZkMzg2YWZhYTQ0Yzk3YjRlNzkwOWQxMmUzNDgzZjtcclxuXHJcbnZhciBCaW5kaW5nXzY5NDE0MTg3ZTBlNTRkN2M5ODgwMWEwNGFiZjQ4ZWYzID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuQmluZGluZygpO1xyXG5CaW5kaW5nXzY5NDE0MTg3ZTBlNTRkN2M5ODgwMWEwNGFiZjQ4ZWYzLlBhdGggPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuUHJvcGVydHlQYXRoKEBcIk92ZXJsYXlPcGFjaXR5XCIpO1xyXG52YXIgUmVsYXRpdmVTb3VyY2VfY2ZhNzZkNzlkN2Q4NGRhNThhYzAyZmYwZmNiY2UxYjEgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5SZWxhdGl2ZVNvdXJjZSgpO1xyXG5SZWxhdGl2ZVNvdXJjZV9jZmE3NmQ3OWQ3ZDg0ZGE1OGFjMDJmZjBmY2JjZTFiMS5Nb2RlID0gZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5SZWxhdGl2ZVNvdXJjZU1vZGUuVGVtcGxhdGVkUGFyZW50O1xyXG5cclxuQmluZGluZ182OTQxNDE4N2UwZTU0ZDdjOTg4MDFhMDRhYmY0OGVmMy5SZWxhdGl2ZVNvdXJjZSA9IFJlbGF0aXZlU291cmNlX2NmYTc2ZDc5ZDdkODRkYTU4YWMwMmZmMGZjYmNlMWIxO1xyXG5cclxuXHJcbkJpbmRpbmdfNjk0MTQxODdlMGU1NGQ3Yzk4ODAxYTA0YWJmNDhlZjMuVGVtcGxhdGVPd25lciA9IHRlbXBsYXRlSW5zdGFuY2VfNzk2ZDM4NmFmYWE0NGM5N2I0ZTc5MDlkMTJlMzQ4M2Y7XHJcblxyXG5cclxudGVtcGxhdGVPd25lcl9Db250cm9sVGVtcGxhdGVfNDEwMjM5OWQwNjdhNDA2OTlhYmUyNzc1MGFkYTM1MDQuUmVnaXN0ZXJOYW1lKFwiQ29udGVudFJvb3RcIiwgQm9yZGVyX2YzNmZmZjdiYTZhNjQyZWZhYTQ5ZDhkZGU3Mjc3MDU5KTtcclxuQm9yZGVyX2YzNmZmZjdiYTZhNjQyZWZhYTQ5ZDhkZGU3Mjc3MDU5Lk5hbWUgPSBcIkNvbnRlbnRSb290XCI7XHJcbnRlbXBsYXRlT3duZXJfQ29udHJvbFRlbXBsYXRlXzQxMDIzOTlkMDY3YTQwNjk5YWJlMjc3NTBhZGEzNTA0LlJlZ2lzdGVyTmFtZShcIkNvbnRlbnRDb250YWluZXJcIiwgQm9yZGVyX2MxZmNhZGI0ZjZkOTQ5OWJiMGYyNWY5YjhjOGYwMjI0KTtcclxuQm9yZGVyX2MxZmNhZGI0ZjZkOTQ5OWJiMGYyNWY5YjhjOGYwMjI0Lk5hbWUgPSBcIkNvbnRlbnRDb250YWluZXJcIjtcclxuQm9yZGVyX2MxZmNhZGI0ZjZkOTQ5OWJiMGYyNWY5YjhjOGYwMjI0LkJhY2tncm91bmQgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuTWVkaWEuU29saWRDb2xvckJydXNoKG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuQ29sb3IoKSB7IEEgPSAoYnl0ZSkyNTUsIFIgPSAoYnl0ZSkyNDYsIEcgPSAoYnl0ZSkyNDYsIEIgPSAoYnl0ZSkyNDYgfSk7XHJcbkJvcmRlcl9jMWZjYWRiNGY2ZDk0OTliYjBmMjVmOWI4YzhmMDIyNC5Db3JuZXJSYWRpdXMgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuQ29ybmVyUmFkaXVzKDIpO1xyXG52YXIgR3JpZF80N2JmYWI0NGVmZTU0MDllODcwMGExNjA0ZTY2YzFlNiA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Db250cm9scy5HcmlkKCk7XHJcbnZhciBSb3dEZWZpbml0aW9uXzllMTNhMmQ4YjIxMDQ1MTk5YjI3MmE5YTQzMzJiOTNiID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkNvbnRyb2xzLlJvd0RlZmluaXRpb24oKTtcclxuUm93RGVmaW5pdGlvbl85ZTEzYTJkOGIyMTA0NTE5OWIyNzJhOWE0MzMyYjkzYi5IZWlnaHQgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuR3JpZExlbmd0aCgxLjAsIGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkdyaWRVbml0VHlwZS5BdXRvKTtcclxuXHJcbnZhciBSb3dEZWZpbml0aW9uX2RmMjI3NjRiODBhYzQ5MzZiOTIwNzc4ODEwYmEwNmJiID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkNvbnRyb2xzLlJvd0RlZmluaXRpb24oKTtcclxuUm93RGVmaW5pdGlvbl9kZjIyNzY0YjgwYWM0OTM2YjkyMDc3ODgxMGJhMDZiYi5IZWlnaHQgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuR3JpZExlbmd0aCgxLjAsIGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkdyaWRVbml0VHlwZS5TdGFyKTtcclxuXHJcbkdyaWRfNDdiZmFiNDRlZmU1NDA5ZTg3MDBhMTYwNGU2NmMxZTYuUm93RGVmaW5pdGlvbnMuQWRkKFJvd0RlZmluaXRpb25fOWUxM2EyZDhiMjEwNDUxOTliMjcyYTlhNDMzMmI5M2IpO1xyXG5HcmlkXzQ3YmZhYjQ0ZWZlNTQwOWU4NzAwYTE2MDRlNjZjMWU2LlJvd0RlZmluaXRpb25zLkFkZChSb3dEZWZpbml0aW9uX2RmMjI3NjRiODBhYzQ5MzZiOTIwNzc4ODEwYmEwNmJiKTtcclxuXHJcbnRlbXBsYXRlT3duZXJfQ29udHJvbFRlbXBsYXRlXzQxMDIzOTlkMDY3YTQwNjk5YWJlMjc3NTBhZGEzNTA0LlJlZ2lzdGVyTmFtZShcIkNocm9tZVwiLCBCb3JkZXJfZDQ2NDEyNjhmNDFiNDc3ZmI2YTY0ZDQwZjJjZjI5ZjMpO1xyXG5Cb3JkZXJfZDQ2NDEyNjhmNDFiNDc3ZmI2YTY0ZDQwZjJjZjI5ZjMuTmFtZSA9IFwiQ2hyb21lXCI7XHJcbkJvcmRlcl9kNDY0MTI2OGY0MWI0NzdmYjZhNjRkNDBmMmNmMjlmMy5XaWR0aCA9IGdsb2JhbDo6U3lzdGVtLkRvdWJsZS5OYU47XHJcbkJvcmRlcl9kNDY0MTI2OGY0MWI0NzdmYjZhNjRkNDBmMmNmMjlmMy5Cb3JkZXJCcnVzaCA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5NZWRpYS5Tb2xpZENvbG9yQnJ1c2gobmV3IGdsb2JhbDo6V2luZG93cy5VSS5Db2xvcigpIHsgQSA9IChieXRlKTI1NSwgUiA9IChieXRlKTI1NSwgRyA9IChieXRlKTI1NSwgQiA9IChieXRlKTI1NSB9KTtcclxuQm9yZGVyX2Q0NjQxMjY4ZjQxYjQ3N2ZiNmE2NGQ0MGYyY2YyOWYzLkJvcmRlclRoaWNrbmVzcyA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5UaGlja25lc3MoMCwgMCwgMCwgMCk7XHJcbkJvcmRlcl9kNDY0MTI2OGY0MWI0NzdmYjZhNjRkNDBmMmNmMjlmMy5CYWNrZ3JvdW5kID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLk1lZGlhLlNvbGlkQ29sb3JCcnVzaChuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLkNvbG9yKCkgeyBBID0gKGJ5dGUpMjU1LCBSID0gKGJ5dGUpMjM4LCBHID0gKGJ5dGUpMjM4LCBCID0gKGJ5dGUpMjM4IH0pO1xyXG52YXIgR3JpZF84ZjAyZmMzNWE1MTQ0MmVlYjgyOWJkMWVkYzcwODM4YSA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Db250cm9scy5HcmlkKCk7XHJcbnZhciBDb2x1bW5EZWZpbml0aW9uX2MwNWJjMjZjNzAwYzQ0YjU4MzE4ZjI2NzBhNjgwYWUyID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkNvbnRyb2xzLkNvbHVtbkRlZmluaXRpb24oKTtcclxuQ29sdW1uRGVmaW5pdGlvbl9jMDViYzI2YzcwMGM0NGI1ODMxOGYyNjcwYTY4MGFlMi5XaWR0aCA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5HcmlkTGVuZ3RoKDEuMCwgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuR3JpZFVuaXRUeXBlLkF1dG8pO1xyXG5cclxudmFyIENvbHVtbkRlZmluaXRpb25fZjcwMGJjY2EyZTBlNDdjYjkwNjNiMDVkZjY3ZjAzY2IgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuQ29udHJvbHMuQ29sdW1uRGVmaW5pdGlvbigpO1xyXG5Db2x1bW5EZWZpbml0aW9uX2Y3MDBiY2NhMmUwZTQ3Y2I5MDYzYjA1ZGY2N2YwM2NiLldpZHRoID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkdyaWRMZW5ndGgoMS4wLCBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5HcmlkVW5pdFR5cGUuU3Rhcik7XHJcblxyXG52YXIgQ29sdW1uRGVmaW5pdGlvbl9kYjhmZjgyZWJmODI0MjExOTZkN2U3MWZkNDVjMmNmYSA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Db250cm9scy5Db2x1bW5EZWZpbml0aW9uKCk7XHJcbkNvbHVtbkRlZmluaXRpb25fZGI4ZmY4MmViZjgyNDIxMTk2ZDdlNzFmZDQ1YzJjZmEuV2lkdGggPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuR3JpZExlbmd0aCgxLjAsIGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkdyaWRVbml0VHlwZS5BdXRvKTtcclxuXHJcbnZhciBDb2x1bW5EZWZpbml0aW9uXzE1NGQ2YjI1MjY4NTQwMmViNDYzZDQ2ODllMTgwZWUwID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkNvbnRyb2xzLkNvbHVtbkRlZmluaXRpb24oKTtcclxuQ29sdW1uRGVmaW5pdGlvbl8xNTRkNmIyNTI2ODU0MDJlYjQ2M2Q0Njg5ZTE4MGVlMC5XaWR0aCA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5HcmlkTGVuZ3RoKDEuMCwgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuR3JpZFVuaXRUeXBlLkF1dG8pO1xyXG5cclxudmFyIENvbHVtbkRlZmluaXRpb25fZGE5YTllZGUzNWJhNDI5ZWFiNWEwZTE5MWU4YmQ5ODcgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuQ29udHJvbHMuQ29sdW1uRGVmaW5pdGlvbigpO1xyXG5Db2x1bW5EZWZpbml0aW9uX2RhOWE5ZWRlMzViYTQyOWVhYjVhMGUxOTFlOGJkOTg3LldpZHRoID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkdyaWRMZW5ndGgoMS4wLCBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5HcmlkVW5pdFR5cGUuQXV0byk7XHJcblxyXG52YXIgQ29sdW1uRGVmaW5pdGlvbl9hZGE1MDA0YWM1ZGY0YjdjODNiYjgyOTAyYmI5ODQ0ZSA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Db250cm9scy5Db2x1bW5EZWZpbml0aW9uKCk7XHJcbkNvbHVtbkRlZmluaXRpb25fYWRhNTAwNGFjNWRmNGI3YzgzYmI4MjkwMmJiOTg0NGUuV2lkdGggPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuR3JpZExlbmd0aCgxLjAsIGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkdyaWRVbml0VHlwZS5BdXRvKTtcclxuXHJcbnZhciBDb2x1bW5EZWZpbml0aW9uXzRkZDUzODBhYTllYjQ2MDI5ZTZiZTNjNjBkM2E0YzAwID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkNvbnRyb2xzLkNvbHVtbkRlZmluaXRpb24oKTtcclxuQ29sdW1uRGVmaW5pdGlvbl80ZGQ1MzgwYWE5ZWI0NjAyOWU2YmUzYzYwZDNhNGMwMC5XaWR0aCA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5HcmlkTGVuZ3RoKDEuMCwgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuR3JpZFVuaXRUeXBlLkF1dG8pO1xyXG5cclxuR3JpZF84ZjAyZmMzNWE1MTQ0MmVlYjgyOWJkMWVkYzcwODM4YS5Db2x1bW5EZWZpbml0aW9ucy5BZGQoQ29sdW1uRGVmaW5pdGlvbl9jMDViYzI2YzcwMGM0NGI1ODMxOGYyNjcwYTY4MGFlMik7XHJcbkdyaWRfOGYwMmZjMzVhNTE0NDJlZWI4MjliZDFlZGM3MDgzOGEuQ29sdW1uRGVmaW5pdGlvbnMuQWRkKENvbHVtbkRlZmluaXRpb25fZjcwMGJjY2EyZTBlNDdjYjkwNjNiMDVkZjY3ZjAzY2IpO1xyXG5HcmlkXzhmMDJmYzM1YTUxNDQyZWViODI5YmQxZWRjNzA4MzhhLkNvbHVtbkRlZmluaXRpb25zLkFkZChDb2x1bW5EZWZpbml0aW9uX2RiOGZmODJlYmY4MjQyMTE5NmQ3ZTcxZmQ0NWMyY2ZhKTtcclxuR3JpZF84ZjAyZmMzNWE1MTQ0MmVlYjgyOWJkMWVkYzcwODM4YS5Db2x1bW5EZWZpbml0aW9ucy5BZGQoQ29sdW1uRGVmaW5pdGlvbl8xNTRkNmIyNTI2ODU0MDJlYjQ2M2Q0Njg5ZTE4MGVlMCk7XHJcbkdyaWRfOGYwMmZjMzVhNTE0NDJlZWI4MjliZDFlZGM3MDgzOGEuQ29sdW1uRGVmaW5pdGlvbnMuQWRkKENvbHVtbkRlZmluaXRpb25fZGE5YTllZGUzNWJhNDI5ZWFiNWEwZTE5MWU4YmQ5ODcpO1xyXG5HcmlkXzhmMDJmYzM1YTUxNDQyZWViODI5YmQxZWRjNzA4MzhhLkNvbHVtbkRlZmluaXRpb25zLkFkZChDb2x1bW5EZWZpbml0aW9uX2FkYTUwMDRhYzVkZjRiN2M4M2JiODI5MDJiYjk4NDRlKTtcclxuR3JpZF84ZjAyZmMzNWE1MTQ0MmVlYjgyOWJkMWVkYzcwODM4YS5Db2x1bW5EZWZpbml0aW9ucy5BZGQoQ29sdW1uRGVmaW5pdGlvbl80ZGQ1MzgwYWE5ZWI0NjAyOWU2YmUzYzYwZDNhNGMwMCk7XHJcblxyXG50ZW1wbGF0ZU93bmVyX0NvbnRyb2xUZW1wbGF0ZV80MTAyMzk5ZDA2N2E0MDY5OWFiZTI3NzUwYWRhMzUwNC5SZWdpc3Rlck5hbWUoXCJJY29uQnV0dG9uXCIsIEJ1dHRvbl82MGZhZTIwNDdkZjc0ZDc4YWJmNWYwOTQ2NDY1ZDYzZSk7XHJcbkJ1dHRvbl82MGZhZTIwNDdkZjc0ZDc4YWJmNWYwOTQ2NDY1ZDYzZS5OYW1lID0gXCJJY29uQnV0dG9uXCI7XHJcbkJ1dHRvbl82MGZhZTIwNDdkZjc0ZDc4YWJmNWYwOTQ2NDY1ZDYzZS5Ib3Jpem9udGFsQWxpZ25tZW50ID0gZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuSG9yaXpvbnRhbEFsaWdubWVudC5MZWZ0O1xyXG5CdXR0b25fNjBmYWUyMDQ3ZGY3NGQ3OGFiZjVmMDk0NjQ2NWQ2M2UuVmVydGljYWxBbGlnbm1lbnQgPSBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5WZXJ0aWNhbEFsaWdubWVudC5DZW50ZXI7XHJcbkJ1dHRvbl82MGZhZTIwNDdkZjc0ZDc4YWJmNWYwOTQ2NDY1ZDYzZS5Ib3Jpem9udGFsQ29udGVudEFsaWdubWVudCA9IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkhvcml6b250YWxBbGlnbm1lbnQuQ2VudGVyO1xyXG5CdXR0b25fNjBmYWUyMDQ3ZGY3NGQ3OGFiZjVmMDk0NjQ2NWQ2M2UuVmVydGljYWxDb250ZW50QWxpZ25tZW50ID0gZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuVmVydGljYWxBbGlnbm1lbnQuQ2VudGVyO1xyXG5CdXR0b25fNjBmYWUyMDQ3ZGY3NGQ3OGFiZjVmMDk0NjQ2NWQ2M2UuV2lkdGggPSAyMEQ7XHJcbkJ1dHRvbl82MGZhZTIwNDdkZjc0ZDc4YWJmNWYwOTQ2NDY1ZDYzZS5QYWRkaW5nID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlRoaWNrbmVzcygwKTtcclxudmFyIEltYWdlX2Q2ZTJlNDJlOTE2MTRhMTQ4ZTY5MTBmZDIxNGQ4ZmZmID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkNvbnRyb2xzLkltYWdlKCk7XHJcbnZhciBCaW5kaW5nXzY5NjExYzU1N2IzZDQwYThiNmQyMDNlYjIzMGZmNzdlID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuQmluZGluZygpO1xyXG5CaW5kaW5nXzY5NjExYzU1N2IzZDQwYThiNmQyMDNlYjIzMGZmNzdlLlBhdGggPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuUHJvcGVydHlQYXRoKEBcIkljb25cIik7XHJcblxyXG5cclxuXHJcbkJ1dHRvbl82MGZhZTIwNDdkZjc0ZDc4YWJmNWYwOTQ2NDY1ZDYzZS5Db250ZW50ID0gSW1hZ2VfZDZlMmU0MmU5MTYxNGExNDhlNjkxMGZkMjE0ZDhmZmY7XHJcblxyXG52YXIgQmluZGluZ19hYWZjZDJkZTVlOGM0YjkyOThmM2JhYTcwOGNjZTRhMyA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmcoKTtcclxuQmluZGluZ19hYWZjZDJkZTVlOGM0YjkyOThmM2JhYTcwOGNjZTRhMy5QYXRoID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlByb3BlcnR5UGF0aChAXCJJY29uVmlzaWJpbGl0eVwiKTtcclxuXHJcblxyXG5cclxudGVtcGxhdGVPd25lcl9Db250cm9sVGVtcGxhdGVfNDEwMjM5OWQwNjdhNDA2OTlhYmUyNzc1MGFkYTM1MDQuUmVnaXN0ZXJOYW1lKFwiVGl0bGVcIiwgQ29udGVudENvbnRyb2xfYmM3YTFkYzY0ZGQwNDgyZjlmN2U0M2Y3NTE4OWE0MTQpO1xyXG5Db250ZW50Q29udHJvbF9iYzdhMWRjNjRkZDA0ODJmOWY3ZTQzZjc1MTg5YTQxNC5OYW1lID0gXCJUaXRsZVwiO1xyXG5nbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Db250cm9scy5HcmlkLlNldENvbHVtbihDb250ZW50Q29udHJvbF9iYzdhMWRjNjRkZDA0ODJmOWY3ZTQzZjc1MTg5YTQxNCwxKTtcclxuQ29udGVudENvbnRyb2xfYmM3YTFkYzY0ZGQwNDgyZjlmN2U0M2Y3NTE4OWE0MTQuSG9yaXpvbnRhbEFsaWdubWVudCA9IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkhvcml6b250YWxBbGlnbm1lbnQuTGVmdDtcclxuQ29udGVudENvbnRyb2xfYmM3YTFkYzY0ZGQwNDgyZjlmN2U0M2Y3NTE4OWE0MTQuVmVydGljYWxBbGlnbm1lbnQgPSBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5WZXJ0aWNhbEFsaWdubWVudC5DZW50ZXI7XHJcbkNvbnRlbnRDb250cm9sX2JjN2ExZGM2NGRkMDQ4MmY5ZjdlNDNmNzUxODlhNDE0Lk1hcmdpbiA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5UaGlja25lc3MoNiwgMCwgNiwgMCk7XHJcbnZhciBCaW5kaW5nXzk5MWJmODJmNDdkYzQwNTI4MDE1Y2QyYzEwMjM3YWRiID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuQmluZGluZygpO1xyXG5CaW5kaW5nXzk5MWJmODJmNDdkYzQwNTI4MDE1Y2QyYzEwMjM3YWRiLlBhdGggPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuUHJvcGVydHlQYXRoKEBcIlRpdGxlXCIpO1xyXG52YXIgUmVsYXRpdmVTb3VyY2VfZTUyNGQ2NTZmYmVhNGU2YzkyNmY2NDAwMjM4ZDc1Y2MgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5SZWxhdGl2ZVNvdXJjZSgpO1xyXG5SZWxhdGl2ZVNvdXJjZV9lNTI0ZDY1NmZiZWE0ZTZjOTI2ZjY0MDAyMzhkNzVjYy5Nb2RlID0gZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5SZWxhdGl2ZVNvdXJjZU1vZGUuVGVtcGxhdGVkUGFyZW50O1xyXG5cclxuQmluZGluZ185OTFiZjgyZjQ3ZGM0MDUyODAxNWNkMmMxMDIzN2FkYi5SZWxhdGl2ZVNvdXJjZSA9IFJlbGF0aXZlU291cmNlX2U1MjRkNjU2ZmJlYTRlNmM5MjZmNjQwMDIzOGQ3NWNjO1xyXG5cclxuXHJcbkJpbmRpbmdfOTkxYmY4MmY0N2RjNDA1MjgwMTVjZDJjMTAyMzdhZGIuVGVtcGxhdGVPd25lciA9IHRlbXBsYXRlSW5zdGFuY2VfNzk2ZDM4NmFmYWE0NGM5N2I0ZTc5MDlkMTJlMzQ4M2Y7XHJcblxyXG5cclxudGVtcGxhdGVPd25lcl9Db250cm9sVGVtcGxhdGVfNDEwMjM5OWQwNjdhNDA2OTlhYmUyNzc1MGFkYTM1MDQuUmVnaXN0ZXJOYW1lKFwiSGVscEJ1dHRvblwiLCBCdXR0b25fMzBiMmQxZGU4Yzc5NGE0NTkwZTM0MzU2YTdlMGM1NWYpO1xyXG5CdXR0b25fMzBiMmQxZGU4Yzc5NGE0NTkwZTM0MzU2YTdlMGM1NWYuTmFtZSA9IFwiSGVscEJ1dHRvblwiO1xyXG5CdXR0b25fMzBiMmQxZGU4Yzc5NGE0NTkwZTM0MzU2YTdlMGM1NWYuSG9yaXpvbnRhbEFsaWdubWVudCA9IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkhvcml6b250YWxBbGlnbm1lbnQuUmlnaHQ7XHJcbkJ1dHRvbl8zMGIyZDFkZThjNzk0YTQ1OTBlMzQzNTZhN2UwYzU1Zi5WZXJ0aWNhbEFsaWdubWVudCA9IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlZlcnRpY2FsQWxpZ25tZW50LkNlbnRlcjtcclxuZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuQ29udHJvbHMuR3JpZC5TZXRDb2x1bW4oQnV0dG9uXzMwYjJkMWRlOGM3OTRhNDU5MGUzNDM1NmE3ZTBjNTVmLDIpO1xyXG5CdXR0b25fMzBiMmQxZGU4Yzc5NGE0NTkwZTM0MzU2YTdlMGM1NWYuSG9yaXpvbnRhbENvbnRlbnRBbGlnbm1lbnQgPSBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Ib3Jpem9udGFsQWxpZ25tZW50LkNlbnRlcjtcclxuQnV0dG9uXzMwYjJkMWRlOGM3OTRhNDU5MGUzNDM1NmE3ZTBjNTVmLlZlcnRpY2FsQ29udGVudEFsaWdubWVudCA9IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlZlcnRpY2FsQWxpZ25tZW50LkNlbnRlcjtcclxuQnV0dG9uXzMwYjJkMWRlOGM3OTRhNDU5MGUzNDM1NmE3ZTBjNTVmLldpZHRoID0gMjBEO1xyXG5CdXR0b25fMzBiMmQxZGU4Yzc5NGE0NTkwZTM0MzU2YTdlMGM1NWYuUGFkZGluZyA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5UaGlja25lc3MoMCk7XHJcbnZhciBJbWFnZV84MDcwNDcyZTNkYWU0YjA4YjE5MTVjYTVlODJjMzkxNCA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Db250cm9scy5JbWFnZSgpO1xyXG52YXIgQmluZGluZ180YWYyN2ZjZDQ3ZTQ0YTZiYmQwNDBjMTFhYWZiMTc0YSA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmcoKTtcclxuQmluZGluZ180YWYyN2ZjZDQ3ZTQ0YTZiYmQwNDBjMTFhYWZiMTc0YS5QYXRoID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlByb3BlcnR5UGF0aChAXCJIZWxwSWNvblwiKTtcclxuXHJcblxyXG5cclxuQnV0dG9uXzMwYjJkMWRlOGM3OTRhNDU5MGUzNDM1NmE3ZTBjNTVmLkNvbnRlbnQgPSBJbWFnZV84MDcwNDcyZTNkYWU0YjA4YjE5MTVjYTVlODJjMzkxNDtcclxuXHJcbnZhciBCaW5kaW5nXzAzN2U3NGJkYjU2MzQ2MGI5ZmRjZDAyNGUwNGJmNGMyID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuQmluZGluZygpO1xyXG5CaW5kaW5nXzAzN2U3NGJkYjU2MzQ2MGI5ZmRjZDAyNGUwNGJmNGMyLlBhdGggPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuUHJvcGVydHlQYXRoKEBcIkhlbHBWaXNpYmlsaXR5XCIpO1xyXG5cclxuXHJcblxyXG50ZW1wbGF0ZU93bmVyX0NvbnRyb2xUZW1wbGF0ZV80MTAyMzk5ZDA2N2E0MDY5OWFiZTI3NzUwYWRhMzUwNC5SZWdpc3Rlck5hbWUoXCJNaW5CdXR0b25cIiwgQnV0dG9uXzE2MWIzYzljYTkxNTQ4ZWVhMDMxZTEwOTQzNTRiODdkKTtcclxuQnV0dG9uXzE2MWIzYzljYTkxNTQ4ZWVhMDMxZTEwOTQzNTRiODdkLk5hbWUgPSBcIk1pbkJ1dHRvblwiO1xyXG5CdXR0b25fMTYxYjNjOWNhOTE1NDhlZWEwMzFlMTA5NDM1NGI4N2QuSG9yaXpvbnRhbEFsaWdubWVudCA9IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkhvcml6b250YWxBbGlnbm1lbnQuUmlnaHQ7XHJcbkJ1dHRvbl8xNjFiM2M5Y2E5MTU0OGVlYTAzMWUxMDk0MzU0Yjg3ZC5WZXJ0aWNhbEFsaWdubWVudCA9IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlZlcnRpY2FsQWxpZ25tZW50LkNlbnRlcjtcclxuZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuQ29udHJvbHMuR3JpZC5TZXRDb2x1bW4oQnV0dG9uXzE2MWIzYzljYTkxNTQ4ZWVhMDMxZTEwOTQzNTRiODdkLDMpO1xyXG5CdXR0b25fMTYxYjNjOWNhOTE1NDhlZWEwMzFlMTA5NDM1NGI4N2QuSG9yaXpvbnRhbENvbnRlbnRBbGlnbm1lbnQgPSBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Ib3Jpem9udGFsQWxpZ25tZW50LkNlbnRlcjtcclxuQnV0dG9uXzE2MWIzYzljYTkxNTQ4ZWVhMDMxZTEwOTQzNTRiODdkLlZlcnRpY2FsQ29udGVudEFsaWdubWVudCA9IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlZlcnRpY2FsQWxpZ25tZW50LkNlbnRlcjtcclxuQnV0dG9uXzE2MWIzYzljYTkxNTQ4ZWVhMDMxZTEwOTQzNTRiODdkLldpZHRoID0gMjBEO1xyXG5CdXR0b25fMTYxYjNjOWNhOTE1NDhlZWEwMzFlMTA5NDM1NGI4N2QuUGFkZGluZyA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5UaGlja25lc3MoMCk7XHJcbkJ1dHRvbl8xNjFiM2M5Y2E5MTU0OGVlYTAzMWUxMDk0MzU0Yjg3ZC5DbGljayArPSBSdW5DbGlja01pbjtcclxudmFyIEltYWdlXzdhZTQwMmQxMjVjMzQ2ZGZhN2U1MDNjMzU3NDI2NjZlID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkNvbnRyb2xzLkltYWdlKCk7XHJcbnZhciBCaW5kaW5nX2IwNmY3YzMwYTVjYTQ4MjZhOTAyYjJhYWIwMWU5NzM0ID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuQmluZGluZygpO1xyXG5CaW5kaW5nX2IwNmY3YzMwYTVjYTQ4MjZhOTAyYjJhYWIwMWU5NzM0LlBhdGggPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuUHJvcGVydHlQYXRoKEBcIk1pblJlc0ljb25cIik7XHJcblxyXG5cclxuXHJcbkJ1dHRvbl8xNjFiM2M5Y2E5MTU0OGVlYTAzMWUxMDk0MzU0Yjg3ZC5Db250ZW50ID0gSW1hZ2VfN2FlNDAyZDEyNWMzNDZkZmE3ZTUwM2MzNTc0MjY2NmU7XHJcblxyXG52YXIgQmluZGluZ18wZjRmMjRkMjk1MGQ0MjVlYTQ1NGJjMDY0ZGQ1N2Y4ZCA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmcoKTtcclxuQmluZGluZ18wZjRmMjRkMjk1MGQ0MjVlYTQ1NGJjMDY0ZGQ1N2Y4ZC5QYXRoID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlByb3BlcnR5UGF0aChAXCJNaW5WaXNpYmlsaXR5XCIpO1xyXG5cclxuXHJcblxyXG50ZW1wbGF0ZU93bmVyX0NvbnRyb2xUZW1wbGF0ZV80MTAyMzk5ZDA2N2E0MDY5OWFiZTI3NzUwYWRhMzUwNC5SZWdpc3Rlck5hbWUoXCJNYXhCdXR0b25cIiwgQnV0dG9uX2Q0Yzg2NDE2NWM5ODQ0YzI4NTQyOGVmYTE1OGU4ZDlmKTtcclxuQnV0dG9uX2Q0Yzg2NDE2NWM5ODQ0YzI4NTQyOGVmYTE1OGU4ZDlmLk5hbWUgPSBcIk1heEJ1dHRvblwiO1xyXG5CdXR0b25fZDRjODY0MTY1Yzk4NDRjMjg1NDI4ZWZhMTU4ZThkOWYuSG9yaXpvbnRhbEFsaWdubWVudCA9IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkhvcml6b250YWxBbGlnbm1lbnQuUmlnaHQ7XHJcbkJ1dHRvbl9kNGM4NjQxNjVjOTg0NGMyODU0MjhlZmExNThlOGQ5Zi5WZXJ0aWNhbEFsaWdubWVudCA9IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlZlcnRpY2FsQWxpZ25tZW50LkNlbnRlcjtcclxuZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuQ29udHJvbHMuR3JpZC5TZXRDb2x1bW4oQnV0dG9uX2Q0Yzg2NDE2NWM5ODQ0YzI4NTQyOGVmYTE1OGU4ZDlmLDQpO1xyXG5CdXR0b25fZDRjODY0MTY1Yzk4NDRjMjg1NDI4ZWZhMTU4ZThkOWYuSG9yaXpvbnRhbENvbnRlbnRBbGlnbm1lbnQgPSBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Ib3Jpem9udGFsQWxpZ25tZW50LkNlbnRlcjtcclxuQnV0dG9uX2Q0Yzg2NDE2NWM5ODQ0YzI4NTQyOGVmYTE1OGU4ZDlmLlZlcnRpY2FsQ29udGVudEFsaWdubWVudCA9IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlZlcnRpY2FsQWxpZ25tZW50LkNlbnRlcjtcclxuQnV0dG9uX2Q0Yzg2NDE2NWM5ODQ0YzI4NTQyOGVmYTE1OGU4ZDlmLldpZHRoID0gMjBEO1xyXG5CdXR0b25fZDRjODY0MTY1Yzk4NDRjMjg1NDI4ZWZhMTU4ZThkOWYuUGFkZGluZyA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5UaGlja25lc3MoMCk7XHJcbkJ1dHRvbl9kNGM4NjQxNjVjOTg0NGMyODU0MjhlZmExNThlOGQ5Zi5DbGljayArPSBSdW5DbGlja01heDtcclxudmFyIEltYWdlX2Q1OWJkM2FiOGU1MjQ1MTRiOGRlMGRhZGYyNTcyNzQyID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkNvbnRyb2xzLkltYWdlKCk7XHJcbnZhciBCaW5kaW5nXzVkY2FmMGQzOGE3NDRiNjc5YzJlODlhNTg3NGI3OTUwID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuQmluZGluZygpO1xyXG5CaW5kaW5nXzVkY2FmMGQzOGE3NDRiNjc5YzJlODlhNTg3NGI3OTUwLlBhdGggPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuUHJvcGVydHlQYXRoKEBcIk1heFJlc0ljb25cIik7XHJcblxyXG5cclxuXHJcbkJ1dHRvbl9kNGM4NjQxNjVjOTg0NGMyODU0MjhlZmExNThlOGQ5Zi5Db250ZW50ID0gSW1hZ2VfZDU5YmQzYWI4ZTUyNDUxNGI4ZGUwZGFkZjI1NzI3NDI7XHJcblxyXG52YXIgQmluZGluZ18wOGYyNDU4OWRmYzU0MjdmYjhjMzI2ZGNjM2IyMTYwMiA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmcoKTtcclxuQmluZGluZ18wOGYyNDU4OWRmYzU0MjdmYjhjMzI2ZGNjM2IyMTYwMi5QYXRoID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlByb3BlcnR5UGF0aChAXCJNYXhWaXNpYmlsaXR5XCIpO1xyXG5cclxuXHJcblxyXG50ZW1wbGF0ZU93bmVyX0NvbnRyb2xUZW1wbGF0ZV80MTAyMzk5ZDA2N2E0MDY5OWFiZTI3NzUwYWRhMzUwNC5SZWdpc3Rlck5hbWUoXCJGdWxsU2NyZWVuQnV0dG9uXCIsIEJ1dHRvbl80NmYyZGQ1MGIyOGM0ZjI5YWI3NWEzNTE3MWMxNTVjNSk7XHJcbkJ1dHRvbl80NmYyZGQ1MGIyOGM0ZjI5YWI3NWEzNTE3MWMxNTVjNS5OYW1lID0gXCJGdWxsU2NyZWVuQnV0dG9uXCI7XHJcbkJ1dHRvbl80NmYyZGQ1MGIyOGM0ZjI5YWI3NWEzNTE3MWMxNTVjNS5Ib3Jpem9udGFsQWxpZ25tZW50ID0gZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuSG9yaXpvbnRhbEFsaWdubWVudC5SaWdodDtcclxuQnV0dG9uXzQ2ZjJkZDUwYjI4YzRmMjlhYjc1YTM1MTcxYzE1NWM1LlZlcnRpY2FsQWxpZ25tZW50ID0gZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuVmVydGljYWxBbGlnbm1lbnQuQ2VudGVyO1xyXG5nbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Db250cm9scy5HcmlkLlNldENvbHVtbihCdXR0b25fNDZmMmRkNTBiMjhjNGYyOWFiNzVhMzUxNzFjMTU1YzUsNSk7XHJcbkJ1dHRvbl80NmYyZGQ1MGIyOGM0ZjI5YWI3NWEzNTE3MWMxNTVjNS5Ib3Jpem9udGFsQ29udGVudEFsaWdubWVudCA9IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkhvcml6b250YWxBbGlnbm1lbnQuQ2VudGVyO1xyXG5CdXR0b25fNDZmMmRkNTBiMjhjNGYyOWFiNzVhMzUxNzFjMTU1YzUuVmVydGljYWxDb250ZW50QWxpZ25tZW50ID0gZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuVmVydGljYWxBbGlnbm1lbnQuQ2VudGVyO1xyXG5CdXR0b25fNDZmMmRkNTBiMjhjNGYyOWFiNzVhMzUxNzFjMTU1YzUuV2lkdGggPSAyMEQ7XHJcbkJ1dHRvbl80NmYyZGQ1MGIyOGM0ZjI5YWI3NWEzNTE3MWMxNTVjNS5QYWRkaW5nID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlRoaWNrbmVzcygwKTtcclxuQnV0dG9uXzQ2ZjJkZDUwYjI4YzRmMjlhYjc1YTM1MTcxYzE1NWM1LkNsaWNrICs9IFJ1bkNsaWNrRnVsbFNjcmVlbjtcclxudmFyIEltYWdlXzFmMjZjZDQzMzU4MTRkNzNhMzkwYzg0YTdiYmI1YWZlID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkNvbnRyb2xzLkltYWdlKCk7XHJcbnZhciBCaW5kaW5nXzU5OGVkMjM2ZjlhOTRiMWNiMDE5YTg1YzkzNGZiZTIyID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuQmluZGluZygpO1xyXG5CaW5kaW5nXzU5OGVkMjM2ZjlhOTRiMWNiMDE5YTg1YzkzNGZiZTIyLlBhdGggPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuUHJvcGVydHlQYXRoKEBcIkZ1bGxTY3JlZW5JY29uXCIpO1xyXG5cclxuXHJcblxyXG5CdXR0b25fNDZmMmRkNTBiMjhjNGYyOWFiNzVhMzUxNzFjMTU1YzUuQ29udGVudCA9IEltYWdlXzFmMjZjZDQzMzU4MTRkNzNhMzkwYzg0YTdiYmI1YWZlO1xyXG5cclxudmFyIEJpbmRpbmdfMGY0NmY4N2IxNjYwNDc0ZTliMWM0ZmE3ZDdjNDRlZDYgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5CaW5kaW5nKCk7XHJcbkJpbmRpbmdfMGY0NmY4N2IxNjYwNDc0ZTliMWM0ZmE3ZDdjNDRlZDYuUGF0aCA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Qcm9wZXJ0eVBhdGgoQFwiRnVsbFNjcmVlblZpc2liaWxpdHlcIik7XHJcblxyXG5cclxuXHJcbnRlbXBsYXRlT3duZXJfQ29udHJvbFRlbXBsYXRlXzQxMDIzOTlkMDY3YTQwNjk5YWJlMjc3NTBhZGEzNTA0LlJlZ2lzdGVyTmFtZShcIkNsb3NlQnV0dG9uXCIsIEJ1dHRvbl80NDJjZTViNmNhYTQ0MzQ1YThjNGI0MDRkOWUyYzE2Mik7XHJcbkJ1dHRvbl80NDJjZTViNmNhYTQ0MzQ1YThjNGI0MDRkOWUyYzE2Mi5OYW1lID0gXCJDbG9zZUJ1dHRvblwiO1xyXG5CdXR0b25fNDQyY2U1YjZjYWE0NDM0NWE4YzRiNDA0ZDllMmMxNjIuSG9yaXpvbnRhbEFsaWdubWVudCA9IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkhvcml6b250YWxBbGlnbm1lbnQuUmlnaHQ7XHJcbkJ1dHRvbl80NDJjZTViNmNhYTQ0MzQ1YThjNGI0MDRkOWUyYzE2Mi5WZXJ0aWNhbEFsaWdubWVudCA9IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlZlcnRpY2FsQWxpZ25tZW50LkNlbnRlcjtcclxuZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuQ29udHJvbHMuR3JpZC5TZXRDb2x1bW4oQnV0dG9uXzQ0MmNlNWI2Y2FhNDQzNDVhOGM0YjQwNGQ5ZTJjMTYyLDYpO1xyXG5CdXR0b25fNDQyY2U1YjZjYWE0NDM0NWE4YzRiNDA0ZDllMmMxNjIuSG9yaXpvbnRhbENvbnRlbnRBbGlnbm1lbnQgPSBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Ib3Jpem9udGFsQWxpZ25tZW50LkNlbnRlcjtcclxuQnV0dG9uXzQ0MmNlNWI2Y2FhNDQzNDVhOGM0YjQwNGQ5ZTJjMTYyLlZlcnRpY2FsQ29udGVudEFsaWdubWVudCA9IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlZlcnRpY2FsQWxpZ25tZW50LkNlbnRlcjtcclxuQnV0dG9uXzQ0MmNlNWI2Y2FhNDQzNDVhOGM0YjQwNGQ5ZTJjMTYyLldpZHRoID0gMjBEO1xyXG5CdXR0b25fNDQyY2U1YjZjYWE0NDM0NWE4YzRiNDA0ZDllMmMxNjIuUGFkZGluZyA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5UaGlja25lc3MoMCk7XHJcbkJ1dHRvbl80NDJjZTViNmNhYTQ0MzQ1YThjNGI0MDRkOWUyYzE2Mi5DbGljayArPSBSdW5DbGlja0Nsb3NlO1xyXG52YXIgSW1hZ2VfZTMwMDgwODk0ZTcyNDZlMDljNDBmZWM2NmUyM2Q5YTkgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuQ29udHJvbHMuSW1hZ2UoKTtcclxudmFyIEJpbmRpbmdfYTI4NTc0ZDM1MDc2NDIyNWE1MmZmYTQ4YTcyODI3NjEgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5CaW5kaW5nKCk7XHJcbkJpbmRpbmdfYTI4NTc0ZDM1MDc2NDIyNWE1MmZmYTQ4YTcyODI3NjEuUGF0aCA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Qcm9wZXJ0eVBhdGgoQFwiQ2xvc2VJY29uXCIpO1xyXG5cclxuXHJcblxyXG5CdXR0b25fNDQyY2U1YjZjYWE0NDM0NWE4YzRiNDA0ZDllMmMxNjIuQ29udGVudCA9IEltYWdlX2UzMDA4MDg5NGU3MjQ2ZTA5YzQwZmVjNjZlMjNkOWE5O1xyXG5cclxudmFyIEJpbmRpbmdfYTRkMmY5M2Y5ODQzNGMzZGI0NTNkNGRiMTRmNjMzNzkgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5CaW5kaW5nKCk7XHJcbkJpbmRpbmdfYTRkMmY5M2Y5ODQzNGMzZGI0NTNkNGRiMTRmNjMzNzkuUGF0aCA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Qcm9wZXJ0eVBhdGgoQFwiQ2xvc2VWaXNpYmlsaXR5XCIpO1xyXG5cclxuXHJcblxyXG5HcmlkXzhmMDJmYzM1YTUxNDQyZWViODI5YmQxZWRjNzA4MzhhLkNoaWxkcmVuLkFkZChCdXR0b25fNjBmYWUyMDQ3ZGY3NGQ3OGFiZjVmMDk0NjQ2NWQ2M2UpO1xyXG5HcmlkXzhmMDJmYzM1YTUxNDQyZWViODI5YmQxZWRjNzA4MzhhLkNoaWxkcmVuLkFkZChDb250ZW50Q29udHJvbF9iYzdhMWRjNjRkZDA0ODJmOWY3ZTQzZjc1MTg5YTQxNCk7XHJcbkdyaWRfOGYwMmZjMzVhNTE0NDJlZWI4MjliZDFlZGM3MDgzOGEuQ2hpbGRyZW4uQWRkKEJ1dHRvbl8zMGIyZDFkZThjNzk0YTQ1OTBlMzQzNTZhN2UwYzU1Zik7XHJcbkdyaWRfOGYwMmZjMzVhNTE0NDJlZWI4MjliZDFlZGM3MDgzOGEuQ2hpbGRyZW4uQWRkKEJ1dHRvbl8xNjFiM2M5Y2E5MTU0OGVlYTAzMWUxMDk0MzU0Yjg3ZCk7XHJcbkdyaWRfOGYwMmZjMzVhNTE0NDJlZWI4MjliZDFlZGM3MDgzOGEuQ2hpbGRyZW4uQWRkKEJ1dHRvbl9kNGM4NjQxNjVjOTg0NGMyODU0MjhlZmExNThlOGQ5Zik7XHJcbkdyaWRfOGYwMmZjMzVhNTE0NDJlZWI4MjliZDFlZGM3MDgzOGEuQ2hpbGRyZW4uQWRkKEJ1dHRvbl80NmYyZGQ1MGIyOGM0ZjI5YWI3NWEzNTE3MWMxNTVjNSk7XHJcbkdyaWRfOGYwMmZjMzVhNTE0NDJlZWI4MjliZDFlZGM3MDgzOGEuQ2hpbGRyZW4uQWRkKEJ1dHRvbl80NDJjZTViNmNhYTQ0MzQ1YThjNGI0MDRkOWUyYzE2Mik7XHJcblxyXG5cclxuQm9yZGVyX2Q0NjQxMjY4ZjQxYjQ3N2ZiNmE2NGQ0MGYyY2YyOWYzLkNoaWxkID0gR3JpZF84ZjAyZmMzNWE1MTQ0MmVlYjgyOWJkMWVkYzcwODM4YTtcclxuXHJcbnZhciBCaW5kaW5nXzBhNTc5M2EzNWM4NjQ3OTA5ZTM5ZjJmZGYxZjhkZjRhID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuQmluZGluZygpO1xyXG5CaW5kaW5nXzBhNTc5M2EzNWM4NjQ3OTA5ZTM5ZjJmZGYxZjhkZjRhLlBhdGggPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuUHJvcGVydHlQYXRoKEBcIlRpdGxlVmlzaWJpbGl0eVwiKTtcclxuXHJcblxyXG5cclxudmFyIEJvcmRlcl8wYWE5Y2U1ZmVhYmY0NmY1YTdjNDVlNTNhMjE3MmZjYyA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Db250cm9scy5Cb3JkZXIoKTtcclxuZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuQ29udHJvbHMuR3JpZC5TZXRSb3coQm9yZGVyXzBhYTljZTVmZWFiZjQ2ZjVhN2M0NWU1M2EyMTcyZmNjLDEpO1xyXG5Cb3JkZXJfMGFhOWNlNWZlYWJmNDZmNWE3YzQ1ZTUzYTIxNzJmY2MuQm9yZGVyVGhpY2tuZXNzID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlRoaWNrbmVzcygwLCAwLCAwLCAwKTtcclxudGVtcGxhdGVPd25lcl9Db250cm9sVGVtcGxhdGVfNDEwMjM5OWQwNjdhNDA2OTlhYmUyNzc1MGFkYTM1MDQuUmVnaXN0ZXJOYW1lKFwiRm9ybUNvbnRlbnRQcmVzZW50ZXJcIiwgQ29udGVudFByZXNlbnRlcl9mYmVkOGExYTQyODg0MmZkODE2ZmFiZjlkOGUxMTE2NCk7XHJcbkNvbnRlbnRQcmVzZW50ZXJfZmJlZDhhMWE0Mjg4NDJmZDgxNmZhYmY5ZDhlMTExNjQuTmFtZSA9IFwiRm9ybUNvbnRlbnRQcmVzZW50ZXJcIjtcclxuQ29udGVudFByZXNlbnRlcl9mYmVkOGExYTQyODg0MmZkODE2ZmFiZjlkOGUxMTE2NC5DbGlwVG9Cb3VuZHMgPSB0cnVlO1xyXG52YXIgQmluZGluZ19lM2MwMTEwYmY1ODg0ODRmODE1MmM0ZDlkNmE3M2E2MiA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmcoKTtcclxuQmluZGluZ19lM2MwMTEwYmY1ODg0ODRmODE1MmM0ZDlkNmE3M2E2Mi5QYXRoID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlByb3BlcnR5UGF0aChAXCJDb250ZW50XCIpO1xyXG52YXIgUmVsYXRpdmVTb3VyY2VfNGMxMzdiZTYxNGFmNDUxZmFiYjczN2I0ZTVmNzNhOWUgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5SZWxhdGl2ZVNvdXJjZSgpO1xyXG5SZWxhdGl2ZVNvdXJjZV80YzEzN2JlNjE0YWY0NTFmYWJiNzM3YjRlNWY3M2E5ZS5Nb2RlID0gZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5SZWxhdGl2ZVNvdXJjZU1vZGUuVGVtcGxhdGVkUGFyZW50O1xyXG5cclxuQmluZGluZ19lM2MwMTEwYmY1ODg0ODRmODE1MmM0ZDlkNmE3M2E2Mi5SZWxhdGl2ZVNvdXJjZSA9IFJlbGF0aXZlU291cmNlXzRjMTM3YmU2MTRhZjQ1MWZhYmI3MzdiNGU1ZjczYTllO1xyXG5cclxuXHJcbkJpbmRpbmdfZTNjMDExMGJmNTg4NDg0ZjgxNTJjNGQ5ZDZhNzNhNjIuVGVtcGxhdGVPd25lciA9IHRlbXBsYXRlSW5zdGFuY2VfNzk2ZDM4NmFmYWE0NGM5N2I0ZTc5MDlkMTJlMzQ4M2Y7XHJcblxyXG52YXIgQmluZGluZ183MTY4MTc3OGVjMGY0NWExODQ3YTMwNTUzNWMwMGY1ZiA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmcoKTtcclxuQmluZGluZ183MTY4MTc3OGVjMGY0NWExODQ3YTMwNTUzNWMwMGY1Zi5QYXRoID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlByb3BlcnR5UGF0aChAXCJDb250ZW50VGVtcGxhdGVcIik7XHJcbnZhciBSZWxhdGl2ZVNvdXJjZV9jM2E4MWUyNWM3M2Y0NjA0OWFjZWViNGNiYzIzMDczOSA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLlJlbGF0aXZlU291cmNlKCk7XHJcblJlbGF0aXZlU291cmNlX2MzYTgxZTI1YzczZjQ2MDQ5YWNlZWI0Y2JjMjMwNzM5Lk1vZGUgPSBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLlJlbGF0aXZlU291cmNlTW9kZS5UZW1wbGF0ZWRQYXJlbnQ7XHJcblxyXG5CaW5kaW5nXzcxNjgxNzc4ZWMwZjQ1YTE4NDdhMzA1NTM1YzAwZjVmLlJlbGF0aXZlU291cmNlID0gUmVsYXRpdmVTb3VyY2VfYzNhODFlMjVjNzNmNDYwNDlhY2VlYjRjYmMyMzA3Mzk7XHJcblxyXG5cclxuQmluZGluZ183MTY4MTc3OGVjMGY0NWExODQ3YTMwNTUzNWMwMGY1Zi5UZW1wbGF0ZU93bmVyID0gdGVtcGxhdGVJbnN0YW5jZV83OTZkMzg2YWZhYTQ0Yzk3YjRlNzkwOWQxMmUzNDgzZjtcclxuXHJcbnZhciBCaW5kaW5nXzM0YzhmNDQyMmIxNDQ2M2NiNzEyMDQ4MzYxNTRjNWRjID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuQmluZGluZygpO1xyXG5CaW5kaW5nXzM0YzhmNDQyMmIxNDQ2M2NiNzEyMDQ4MzYxNTRjNWRjLlBhdGggPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuUHJvcGVydHlQYXRoKEBcIkNsaWVudFdpZHRoXCIpO1xyXG5cclxuXHJcbnZhciBCaW5kaW5nX2ZjZjRmMWRiNWJmMzQxNTFhNzVlMWYwMDI3NjUwYmFkID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuQmluZGluZygpO1xyXG5CaW5kaW5nX2ZjZjRmMWRiNWJmMzQxNTFhNzVlMWYwMDI3NjUwYmFkLlBhdGggPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuUHJvcGVydHlQYXRoKEBcIkNsaWVudEhlaWdodFwiKTtcclxuXHJcblxyXG52YXIgQmluZGluZ19iZTZlYTZmYTFhYjM0ZDJmYmM0NDRlMWEwOThiZDk1YSA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmcoKTtcclxuQmluZGluZ19iZTZlYTZmYTFhYjM0ZDJmYmM0NDRlMWEwOThiZDk1YS5QYXRoID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlByb3BlcnR5UGF0aChAXCJIb3Jpem9udGFsQWxpZ25tZW50XCIpO1xyXG52YXIgUmVsYXRpdmVTb3VyY2VfNDBkZTczNzA3NDM4NGNlYmJkOTc4NTZiNjRkNjI1OTQgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5SZWxhdGl2ZVNvdXJjZSgpO1xyXG5SZWxhdGl2ZVNvdXJjZV80MGRlNzM3MDc0Mzg0Y2ViYmQ5Nzg1NmI2NGQ2MjU5NC5Nb2RlID0gZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5SZWxhdGl2ZVNvdXJjZU1vZGUuVGVtcGxhdGVkUGFyZW50O1xyXG5cclxuQmluZGluZ19iZTZlYTZmYTFhYjM0ZDJmYmM0NDRlMWEwOThiZDk1YS5SZWxhdGl2ZVNvdXJjZSA9IFJlbGF0aXZlU291cmNlXzQwZGU3MzcwNzQzODRjZWJiZDk3ODU2YjY0ZDYyNTk0O1xyXG5cclxuXHJcbkJpbmRpbmdfYmU2ZWE2ZmExYWIzNGQyZmJjNDQ0ZTFhMDk4YmQ5NWEuVGVtcGxhdGVPd25lciA9IHRlbXBsYXRlSW5zdGFuY2VfNzk2ZDM4NmFmYWE0NGM5N2I0ZTc5MDlkMTJlMzQ4M2Y7XHJcblxyXG52YXIgQmluZGluZ19jODNjYjdkNWU4OGU0YTk3YTliYmJkY2RjNTZkY2M2OCA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmcoKTtcclxuQmluZGluZ19jODNjYjdkNWU4OGU0YTk3YTliYmJkY2RjNTZkY2M2OC5QYXRoID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlByb3BlcnR5UGF0aChAXCJWZXJ0aWNhbEFsaWdubWVudFwiKTtcclxudmFyIFJlbGF0aXZlU291cmNlX2QxMGFmN2QxMGI4MjRlZmI5OTJkNTY2MDNmYjAxMTJkID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuUmVsYXRpdmVTb3VyY2UoKTtcclxuUmVsYXRpdmVTb3VyY2VfZDEwYWY3ZDEwYjgyNGVmYjk5MmQ1NjYwM2ZiMDExMmQuTW9kZSA9IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuUmVsYXRpdmVTb3VyY2VNb2RlLlRlbXBsYXRlZFBhcmVudDtcclxuXHJcbkJpbmRpbmdfYzgzY2I3ZDVlODhlNGE5N2E5YmJiZGNkYzU2ZGNjNjguUmVsYXRpdmVTb3VyY2UgPSBSZWxhdGl2ZVNvdXJjZV9kMTBhZjdkMTBiODI0ZWZiOTkyZDU2NjAzZmIwMTEyZDtcclxuXHJcblxyXG5CaW5kaW5nX2M4M2NiN2Q1ZTg4ZTRhOTdhOWJiYmRjZGM1NmRjYzY4LlRlbXBsYXRlT3duZXIgPSB0ZW1wbGF0ZUluc3RhbmNlXzc5NmQzODZhZmFhNDRjOTdiNGU3OTA5ZDEyZTM0ODNmO1xyXG5cclxuXHJcbkJvcmRlcl8wYWE5Y2U1ZmVhYmY0NmY1YTdjNDVlNTNhMjE3MmZjYy5DaGlsZCA9IENvbnRlbnRQcmVzZW50ZXJfZmJlZDhhMWE0Mjg4NDJmZDgxNmZhYmY5ZDhlMTExNjQ7XHJcblxyXG52YXIgQmluZGluZ19lZjBlNDRlOTQxMGM0YjI2ODFmNDk3ZmVlYTA5MTE0NyA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmcoKTtcclxuQmluZGluZ19lZjBlNDRlOTQxMGM0YjI2ODFmNDk3ZmVlYTA5MTE0Ny5QYXRoID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlByb3BlcnR5UGF0aChAXCJDbGllbnRIZWlnaHRcIik7XHJcblxyXG5cclxudmFyIEJpbmRpbmdfYjZiMGQwMWM4YTczNGYxMGExYWM1MmI2N2M4M2UzNTQgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5CaW5kaW5nKCk7XHJcbkJpbmRpbmdfYjZiMGQwMWM4YTczNGYxMGExYWM1MmI2N2M4M2UzNTQuUGF0aCA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Qcm9wZXJ0eVBhdGgoQFwiQ2xpZW50V2lkdGhcIik7XHJcblxyXG5cclxudmFyIEJpbmRpbmdfYjFhYWM0YzA5MDVjNDIwYzg5NjVmZWY1ZTQzOWJmNTEgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5CaW5kaW5nKCk7XHJcbkJpbmRpbmdfYjFhYWM0YzA5MDVjNDIwYzg5NjVmZWY1ZTQzOWJmNTEuUGF0aCA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Qcm9wZXJ0eVBhdGgoQFwiQmFja2dyb3VuZFwiKTtcclxudmFyIFJlbGF0aXZlU291cmNlXzY1ODUxMGRmOWM0YzRkNzRhYmJhNGFhYWYwNzkyNTI1ID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuUmVsYXRpdmVTb3VyY2UoKTtcclxuUmVsYXRpdmVTb3VyY2VfNjU4NTEwZGY5YzRjNGQ3NGFiYmE0YWFhZjA3OTI1MjUuTW9kZSA9IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuUmVsYXRpdmVTb3VyY2VNb2RlLlRlbXBsYXRlZFBhcmVudDtcclxuXHJcbkJpbmRpbmdfYjFhYWM0YzA5MDVjNDIwYzg5NjVmZWY1ZTQzOWJmNTEuUmVsYXRpdmVTb3VyY2UgPSBSZWxhdGl2ZVNvdXJjZV82NTg1MTBkZjljNGM0ZDc0YWJiYTRhYWFmMDc5MjUyNTtcclxuXHJcblxyXG5CaW5kaW5nX2IxYWFjNGMwOTA1YzQyMGM4OTY1ZmVmNWU0MzliZjUxLlRlbXBsYXRlT3duZXIgPSB0ZW1wbGF0ZUluc3RhbmNlXzc5NmQzODZhZmFhNDRjOTdiNGU3OTA5ZDEyZTM0ODNmO1xyXG5cclxudmFyIEJpbmRpbmdfNWI4YTJlODA3OWFkNGZjNzljYzliMWU2MzM4NTQwYWIgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5CaW5kaW5nKCk7XHJcbkJpbmRpbmdfNWI4YTJlODA3OWFkNGZjNzljYzliMWU2MzM4NTQwYWIuUGF0aCA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Qcm9wZXJ0eVBhdGgoQFwiQmFja2dyb3VuZFwiKTtcclxudmFyIFJlbGF0aXZlU291cmNlX2ZkYmQyMDAzMjQzYzQxNGFiNTI5N2NkYjA0MzY0NGEyID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuUmVsYXRpdmVTb3VyY2UoKTtcclxuUmVsYXRpdmVTb3VyY2VfZmRiZDIwMDMyNDNjNDE0YWI1Mjk3Y2RiMDQzNjQ0YTIuTW9kZSA9IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuUmVsYXRpdmVTb3VyY2VNb2RlLlRlbXBsYXRlZFBhcmVudDtcclxuXHJcbkJpbmRpbmdfNWI4YTJlODA3OWFkNGZjNzljYzliMWU2MzM4NTQwYWIuUmVsYXRpdmVTb3VyY2UgPSBSZWxhdGl2ZVNvdXJjZV9mZGJkMjAwMzI0M2M0MTRhYjUyOTdjZGIwNDM2NDRhMjtcclxuXHJcblxyXG5CaW5kaW5nXzViOGEyZTgwNzlhZDRmYzc5Y2M5YjFlNjMzODU0MGFiLlRlbXBsYXRlT3duZXIgPSB0ZW1wbGF0ZUluc3RhbmNlXzc5NmQzODZhZmFhNDRjOTdiNGU3OTA5ZDEyZTM0ODNmO1xyXG5cclxuXHJcbkdyaWRfNDdiZmFiNDRlZmU1NDA5ZTg3MDBhMTYwNGU2NmMxZTYuQ2hpbGRyZW4uQWRkKEJvcmRlcl9kNDY0MTI2OGY0MWI0NzdmYjZhNjRkNDBmMmNmMjlmMyk7XHJcbkdyaWRfNDdiZmFiNDRlZmU1NDA5ZTg3MDBhMTYwNGU2NmMxZTYuQ2hpbGRyZW4uQWRkKEJvcmRlcl8wYWE5Y2U1ZmVhYmY0NmY1YTdjNDVlNTNhMjE3MmZjYyk7XHJcblxyXG5cclxuQm9yZGVyX2MxZmNhZGI0ZjZkOTQ5OWJiMGYyNWY5YjhjOGYwMjI0LkNoaWxkID0gR3JpZF80N2JmYWI0NGVmZTU0MDllODcwMGExNjA0ZTY2YzFlNjtcclxuXHJcbnZhciBCaW5kaW5nX2M4Y2Y0OTBiODVjZjRiNTFhMjk1NTRlZGRlNGM3NTI5ID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuQmluZGluZygpO1xyXG5CaW5kaW5nX2M4Y2Y0OTBiODVjZjRiNTFhMjk1NTRlZGRlNGM3NTI5LlBhdGggPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuUHJvcGVydHlQYXRoKEBcIkJvcmRlclRoaWNrbmVzc1wiKTtcclxudmFyIFJlbGF0aXZlU291cmNlXzFlZDZkNTdkYzI3ZDQ3OTU5M2Q1Y2NkYzQ0NzU5NTllID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuUmVsYXRpdmVTb3VyY2UoKTtcclxuUmVsYXRpdmVTb3VyY2VfMWVkNmQ1N2RjMjdkNDc5NTkzZDVjY2RjNDQ3NTk1OWUuTW9kZSA9IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuUmVsYXRpdmVTb3VyY2VNb2RlLlRlbXBsYXRlZFBhcmVudDtcclxuXHJcbkJpbmRpbmdfYzhjZjQ5MGI4NWNmNGI1MWEyOTU1NGVkZGU0Yzc1MjkuUmVsYXRpdmVTb3VyY2UgPSBSZWxhdGl2ZVNvdXJjZV8xZWQ2ZDU3ZGMyN2Q0Nzk1OTNkNWNjZGM0NDc1OTU5ZTtcclxuXHJcblxyXG5CaW5kaW5nX2M4Y2Y0OTBiODVjZjRiNTFhMjk1NTRlZGRlNGM3NTI5LlRlbXBsYXRlT3duZXIgPSB0ZW1wbGF0ZUluc3RhbmNlXzc5NmQzODZhZmFhNDRjOTdiNGU3OTA5ZDEyZTM0ODNmO1xyXG5cclxudmFyIEJpbmRpbmdfMjJkNTExMzU5ZGNjNGFmZDg2N2EzYjBjNzI2MmMzN2QgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5CaW5kaW5nKCk7XHJcbkJpbmRpbmdfMjJkNTExMzU5ZGNjNGFmZDg2N2EzYjBjNzI2MmMzN2QuUGF0aCA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Qcm9wZXJ0eVBhdGgoQFwiQm9yZGVyQnJ1c2hcIik7XHJcbnZhciBSZWxhdGl2ZVNvdXJjZV8zNWFhMmRjNzk1YWY0Y2VhYTNlYzAwODMyNGNjY2JmZSA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLlJlbGF0aXZlU291cmNlKCk7XHJcblJlbGF0aXZlU291cmNlXzM1YWEyZGM3OTVhZjRjZWFhM2VjMDA4MzI0Y2NjYmZlLk1vZGUgPSBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLlJlbGF0aXZlU291cmNlTW9kZS5UZW1wbGF0ZWRQYXJlbnQ7XHJcblxyXG5CaW5kaW5nXzIyZDUxMTM1OWRjYzRhZmQ4NjdhM2IwYzcyNjJjMzdkLlJlbGF0aXZlU291cmNlID0gUmVsYXRpdmVTb3VyY2VfMzVhYTJkYzc5NWFmNGNlYWEzZWMwMDgzMjRjY2NiZmU7XHJcblxyXG5cclxuQmluZGluZ18yMmQ1MTEzNTlkY2M0YWZkODY3YTNiMGM3MjYyYzM3ZC5UZW1wbGF0ZU93bmVyID0gdGVtcGxhdGVJbnN0YW5jZV83OTZkMzg2YWZhYTQ0Yzk3YjRlNzkwOWQxMmUzNDgzZjtcclxuXHJcblxyXG5Cb3JkZXJfZjM2ZmZmN2JhNmE2NDJlZmFhNDlkOGRkZTcyNzcwNTkuQ2hpbGQgPSBCb3JkZXJfYzFmY2FkYjRmNmQ5NDk5YmIwZjI1ZjliOGM4ZjAyMjQ7XHJcblxyXG5cclxuR3JpZF9hZjg2NDA0ODU4ZjY0ODEyYjg1YjYwOGVkMjg5YWQ4NC5DaGlsZHJlbi5BZGQoR3JpZF9lZTRjN2NiNDMwNjM0NmY5OWY3NDg1NTM2ZDM3NTUzYSk7XHJcbkdyaWRfYWY4NjQwNDg1OGY2NDgxMmI4NWI2MDhlZDI4OWFkODQuQ2hpbGRyZW4uQWRkKEJvcmRlcl9mMzZmZmY3YmE2YTY0MmVmYWE0OWQ4ZGRlNzI3NzA1OSk7XHJcblxyXG52YXIgQmluZGluZ19kNTQ0MzE2NmUzY2I0OTdjOTU5OWJhOTQ3NThiZTZlZiA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmcoKTtcclxuQmluZGluZ19kNTQ0MzE2NmUzY2I0OTdjOTU5OWJhOTQ3NThiZTZlZi5QYXRoID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlByb3BlcnR5UGF0aChAXCJIZWlnaHRcIik7XHJcbnZhciBSZWxhdGl2ZVNvdXJjZV8xNWQxNjBhMzg5MjE0NGZiYjU3NGUzMWExOTYwY2ZjOCA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLlJlbGF0aXZlU291cmNlKCk7XHJcblJlbGF0aXZlU291cmNlXzE1ZDE2MGEzODkyMTQ0ZmJiNTc0ZTMxYTE5NjBjZmM4Lk1vZGUgPSBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLlJlbGF0aXZlU291cmNlTW9kZS5UZW1wbGF0ZWRQYXJlbnQ7XHJcblxyXG5CaW5kaW5nX2Q1NDQzMTY2ZTNjYjQ5N2M5NTk5YmE5NDc1OGJlNmVmLlJlbGF0aXZlU291cmNlID0gUmVsYXRpdmVTb3VyY2VfMTVkMTYwYTM4OTIxNDRmYmI1NzRlMzFhMTk2MGNmYzg7XHJcblxyXG5cclxuQmluZGluZ19kNTQ0MzE2NmUzY2I0OTdjOTU5OWJhOTQ3NThiZTZlZi5UZW1wbGF0ZU93bmVyID0gdGVtcGxhdGVJbnN0YW5jZV83OTZkMzg2YWZhYTQ0Yzk3YjRlNzkwOWQxMmUzNDgzZjtcclxuXHJcbnZhciBCaW5kaW5nX2MxODQ5NWNiMzM1MTQxYjY5YzlkNTAwNDVhMmY0NTgyID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuQmluZGluZygpO1xyXG5CaW5kaW5nX2MxODQ5NWNiMzM1MTQxYjY5YzlkNTAwNDVhMmY0NTgyLlBhdGggPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuUHJvcGVydHlQYXRoKEBcIldpZHRoXCIpO1xyXG52YXIgUmVsYXRpdmVTb3VyY2VfNjYyYWI0NDNmNDU2NGRkNGE1ZjM0YzJhNDNhNTZlYmIgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5SZWxhdGl2ZVNvdXJjZSgpO1xyXG5SZWxhdGl2ZVNvdXJjZV82NjJhYjQ0M2Y0NTY0ZGQ0YTVmMzRjMmE0M2E1NmViYi5Nb2RlID0gZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5SZWxhdGl2ZVNvdXJjZU1vZGUuVGVtcGxhdGVkUGFyZW50O1xyXG5cclxuQmluZGluZ19jMTg0OTVjYjMzNTE0MWI2OWM5ZDUwMDQ1YTJmNDU4Mi5SZWxhdGl2ZVNvdXJjZSA9IFJlbGF0aXZlU291cmNlXzY2MmFiNDQzZjQ1NjRkZDRhNWYzNGMyYTQzYTU2ZWJiO1xyXG5cclxuXHJcbkJpbmRpbmdfYzE4NDk1Y2IzMzUxNDFiNjljOWQ1MDA0NWEyZjQ1ODIuVGVtcGxhdGVPd25lciA9IHRlbXBsYXRlSW5zdGFuY2VfNzk2ZDM4NmFmYWE0NGM5N2I0ZTc5MDlkMTJlMzQ4M2Y7XHJcblxyXG52YXIgQmluZGluZ183NGU4NDc5MWQ2OWE0YTk3OWRiNDYxNTJiYjEyMjRiZCA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmcoKTtcclxuQmluZGluZ183NGU4NDc5MWQ2OWE0YTk3OWRiNDYxNTJiYjEyMjRiZC5QYXRoID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlByb3BlcnR5UGF0aChAXCJIb3Jpem9udGFsQWxpZ25tZW50XCIpO1xyXG52YXIgUmVsYXRpdmVTb3VyY2VfYzhmMTFmMTcxYjE3NGNiYjkzZWRiNzk2NGI4ZDRmYmIgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5SZWxhdGl2ZVNvdXJjZSgpO1xyXG5SZWxhdGl2ZVNvdXJjZV9jOGYxMWYxNzFiMTc0Y2JiOTNlZGI3OTY0YjhkNGZiYi5Nb2RlID0gZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5SZWxhdGl2ZVNvdXJjZU1vZGUuVGVtcGxhdGVkUGFyZW50O1xyXG5cclxuQmluZGluZ183NGU4NDc5MWQ2OWE0YTk3OWRiNDYxNTJiYjEyMjRiZC5SZWxhdGl2ZVNvdXJjZSA9IFJlbGF0aXZlU291cmNlX2M4ZjExZjE3MWIxNzRjYmI5M2VkYjc5NjRiOGQ0ZmJiO1xyXG5cclxuXHJcbkJpbmRpbmdfNzRlODQ3OTFkNjlhNGE5NzlkYjQ2MTUyYmIxMjI0YmQuVGVtcGxhdGVPd25lciA9IHRlbXBsYXRlSW5zdGFuY2VfNzk2ZDM4NmFmYWE0NGM5N2I0ZTc5MDlkMTJlMzQ4M2Y7XHJcblxyXG52YXIgQmluZGluZ183MDZjYTA1YzFjZmM0ZGNlODliZWY0MTQ5YmJkY2I3ZCA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmcoKTtcclxuQmluZGluZ183MDZjYTA1YzFjZmM0ZGNlODliZWY0MTQ5YmJkY2I3ZC5QYXRoID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlByb3BlcnR5UGF0aChAXCJWZXJ0aWNhbEFsaWdubWVudFwiKTtcclxudmFyIFJlbGF0aXZlU291cmNlX2Q2NDYxNjU0MGFmODRhZTk4NWM1MDQ5OGEwMzY2MzM2ID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuUmVsYXRpdmVTb3VyY2UoKTtcclxuUmVsYXRpdmVTb3VyY2VfZDY0NjE2NTQwYWY4NGFlOTg1YzUwNDk4YTAzNjYzMzYuTW9kZSA9IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuUmVsYXRpdmVTb3VyY2VNb2RlLlRlbXBsYXRlZFBhcmVudDtcclxuXHJcbkJpbmRpbmdfNzA2Y2EwNWMxY2ZjNGRjZTg5YmVmNDE0OWJiZGNiN2QuUmVsYXRpdmVTb3VyY2UgPSBSZWxhdGl2ZVNvdXJjZV9kNjQ2MTY1NDBhZjg0YWU5ODVjNTA0OThhMDM2NjMzNjtcclxuXHJcblxyXG5CaW5kaW5nXzcwNmNhMDVjMWNmYzRkY2U4OWJlZjQxNDliYmRjYjdkLlRlbXBsYXRlT3duZXIgPSB0ZW1wbGF0ZUluc3RhbmNlXzc5NmQzODZhZmFhNDRjOTdiNGU3OTA5ZDEyZTM0ODNmO1xyXG5cclxuXHJcbmdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuQmluZGluZ09wZXJhdGlvbnMuU2V0QmluZGluZyhHcmlkX2VlNGM3Y2I0MzA2MzQ2Zjk5Zjc0ODU1MzZkMzc1NTNhLCBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Db250cm9scy5QYW5lbC5CYWNrZ3JvdW5kUHJvcGVydHksIEJpbmRpbmdfODZjZDMyYTMyM2Y0NDZmMTgzZjRiMzg1ZWQ4MDAwM2EpO1xyXG5nbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmdPcGVyYXRpb25zLlNldEJpbmRpbmcoR3JpZF9lZTRjN2NiNDMwNjM0NmY5OWY3NDg1NTM2ZDM3NTUzYSwgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuVUlFbGVtZW50Lk9wYWNpdHlQcm9wZXJ0eSwgQmluZGluZ182OTQxNDE4N2UwZTU0ZDdjOTg4MDFhMDRhYmY0OGVmMyk7XHJcbmdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuQmluZGluZ09wZXJhdGlvbnMuU2V0QmluZGluZyhJbWFnZV9kNmUyZTQyZTkxNjE0YTE0OGU2OTEwZmQyMTRkOGZmZiwgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuQ29udHJvbHMuSW1hZ2UuU291cmNlUHJvcGVydHksIEJpbmRpbmdfNjk2MTFjNTU3YjNkNDBhOGI2ZDIwM2ViMjMwZmY3N2UpO1xyXG5nbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmdPcGVyYXRpb25zLlNldEJpbmRpbmcoQnV0dG9uXzYwZmFlMjA0N2RmNzRkNzhhYmY1ZjA5NDY0NjVkNjNlLCBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5VSUVsZW1lbnQuVmlzaWJpbGl0eVByb3BlcnR5LCBCaW5kaW5nX2FhZmNkMmRlNWU4YzRiOTI5OGYzYmFhNzA4Y2NlNGEzKTtcclxuZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5CaW5kaW5nT3BlcmF0aW9ucy5TZXRCaW5kaW5nKENvbnRlbnRDb250cm9sX2JjN2ExZGM2NGRkMDQ4MmY5ZjdlNDNmNzUxODlhNDE0LCBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Db250cm9scy5Db250ZW50Q29udHJvbC5Db250ZW50UHJvcGVydHksIEJpbmRpbmdfOTkxYmY4MmY0N2RjNDA1MjgwMTVjZDJjMTAyMzdhZGIpO1xyXG5nbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmdPcGVyYXRpb25zLlNldEJpbmRpbmcoSW1hZ2VfODA3MDQ3MmUzZGFlNGIwOGIxOTE1Y2E1ZTgyYzM5MTQsIGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkNvbnRyb2xzLkltYWdlLlNvdXJjZVByb3BlcnR5LCBCaW5kaW5nXzRhZjI3ZmNkNDdlNDRhNmJiZDA0MGMxMWFhZmIxNzRhKTtcclxuZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5CaW5kaW5nT3BlcmF0aW9ucy5TZXRCaW5kaW5nKEJ1dHRvbl8zMGIyZDFkZThjNzk0YTQ1OTBlMzQzNTZhN2UwYzU1ZiwgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuVUlFbGVtZW50LlZpc2liaWxpdHlQcm9wZXJ0eSwgQmluZGluZ18wMzdlNzRiZGI1NjM0NjBiOWZkY2QwMjRlMDRiZjRjMik7XHJcbmdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuQmluZGluZ09wZXJhdGlvbnMuU2V0QmluZGluZyhJbWFnZV83YWU0MDJkMTI1YzM0NmRmYTdlNTAzYzM1NzQyNjY2ZSwgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuQ29udHJvbHMuSW1hZ2UuU291cmNlUHJvcGVydHksIEJpbmRpbmdfYjA2ZjdjMzBhNWNhNDgyNmE5MDJiMmFhYjAxZTk3MzQpO1xyXG5nbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmdPcGVyYXRpb25zLlNldEJpbmRpbmcoQnV0dG9uXzE2MWIzYzljYTkxNTQ4ZWVhMDMxZTEwOTQzNTRiODdkLCBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5VSUVsZW1lbnQuVmlzaWJpbGl0eVByb3BlcnR5LCBCaW5kaW5nXzBmNGYyNGQyOTUwZDQyNWVhNDU0YmMwNjRkZDU3ZjhkKTtcclxuZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5CaW5kaW5nT3BlcmF0aW9ucy5TZXRCaW5kaW5nKEltYWdlX2Q1OWJkM2FiOGU1MjQ1MTRiOGRlMGRhZGYyNTcyNzQyLCBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Db250cm9scy5JbWFnZS5Tb3VyY2VQcm9wZXJ0eSwgQmluZGluZ181ZGNhZjBkMzhhNzQ0YjY3OWMyZTg5YTU4NzRiNzk1MCk7XHJcbmdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuQmluZGluZ09wZXJhdGlvbnMuU2V0QmluZGluZyhCdXR0b25fZDRjODY0MTY1Yzk4NDRjMjg1NDI4ZWZhMTU4ZThkOWYsIGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlVJRWxlbWVudC5WaXNpYmlsaXR5UHJvcGVydHksIEJpbmRpbmdfMDhmMjQ1ODlkZmM1NDI3ZmI4YzMyNmRjYzNiMjE2MDIpO1xyXG5nbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmdPcGVyYXRpb25zLlNldEJpbmRpbmcoSW1hZ2VfMWYyNmNkNDMzNTgxNGQ3M2EzOTBjODRhN2JiYjVhZmUsIGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkNvbnRyb2xzLkltYWdlLlNvdXJjZVByb3BlcnR5LCBCaW5kaW5nXzU5OGVkMjM2ZjlhOTRiMWNiMDE5YTg1YzkzNGZiZTIyKTtcclxuZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5CaW5kaW5nT3BlcmF0aW9ucy5TZXRCaW5kaW5nKEJ1dHRvbl80NmYyZGQ1MGIyOGM0ZjI5YWI3NWEzNTE3MWMxNTVjNSwgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuVUlFbGVtZW50LlZpc2liaWxpdHlQcm9wZXJ0eSwgQmluZGluZ18wZjQ2Zjg3YjE2NjA0NzRlOWIxYzRmYTdkN2M0NGVkNik7XHJcbmdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuQmluZGluZ09wZXJhdGlvbnMuU2V0QmluZGluZyhJbWFnZV9lMzAwODA4OTRlNzI0NmUwOWM0MGZlYzY2ZTIzZDlhOSwgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuQ29udHJvbHMuSW1hZ2UuU291cmNlUHJvcGVydHksIEJpbmRpbmdfYTI4NTc0ZDM1MDc2NDIyNWE1MmZmYTQ4YTcyODI3NjEpO1xyXG5nbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmdPcGVyYXRpb25zLlNldEJpbmRpbmcoQnV0dG9uXzQ0MmNlNWI2Y2FhNDQzNDVhOGM0YjQwNGQ5ZTJjMTYyLCBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5VSUVsZW1lbnQuVmlzaWJpbGl0eVByb3BlcnR5LCBCaW5kaW5nX2E0ZDJmOTNmOTg0MzRjM2RiNDUzZDRkYjE0ZjYzMzc5KTtcclxuZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5CaW5kaW5nT3BlcmF0aW9ucy5TZXRCaW5kaW5nKEJvcmRlcl9kNDY0MTI2OGY0MWI0NzdmYjZhNjRkNDBmMmNmMjlmMywgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuVUlFbGVtZW50LlZpc2liaWxpdHlQcm9wZXJ0eSwgQmluZGluZ18wYTU3OTNhMzVjODY0NzkwOWUzOWYyZmRmMWY4ZGY0YSk7XHJcbmdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuQmluZGluZ09wZXJhdGlvbnMuU2V0QmluZGluZyhDb250ZW50UHJlc2VudGVyX2ZiZWQ4YTFhNDI4ODQyZmQ4MTZmYWJmOWQ4ZTExMTY0LCBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Db250cm9scy5Db250ZW50Q29udHJvbC5Db250ZW50UHJvcGVydHksIEJpbmRpbmdfZTNjMDExMGJmNTg4NDg0ZjgxNTJjNGQ5ZDZhNzNhNjIpO1xyXG5nbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmdPcGVyYXRpb25zLlNldEJpbmRpbmcoQ29udGVudFByZXNlbnRlcl9mYmVkOGExYTQyODg0MmZkODE2ZmFiZjlkOGUxMTE2NCwgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuQ29udHJvbHMuQ29udGVudENvbnRyb2wuQ29udGVudFRlbXBsYXRlUHJvcGVydHksIEJpbmRpbmdfNzE2ODE3NzhlYzBmNDVhMTg0N2EzMDU1MzVjMDBmNWYpO1xyXG5nbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmdPcGVyYXRpb25zLlNldEJpbmRpbmcoQ29udGVudFByZXNlbnRlcl9mYmVkOGExYTQyODg0MmZkODE2ZmFiZjlkOGUxMTE2NCwgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRnJhbWV3b3JrRWxlbWVudC5XaWR0aFByb3BlcnR5LCBCaW5kaW5nXzM0YzhmNDQyMmIxNDQ2M2NiNzEyMDQ4MzYxNTRjNWRjKTtcclxuZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5CaW5kaW5nT3BlcmF0aW9ucy5TZXRCaW5kaW5nKENvbnRlbnRQcmVzZW50ZXJfZmJlZDhhMWE0Mjg4NDJmZDgxNmZhYmY5ZDhlMTExNjQsIGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkZyYW1ld29ya0VsZW1lbnQuSGVpZ2h0UHJvcGVydHksIEJpbmRpbmdfZmNmNGYxZGI1YmYzNDE1MWE3NWUxZjAwMjc2NTBiYWQpO1xyXG5nbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmdPcGVyYXRpb25zLlNldEJpbmRpbmcoQ29udGVudFByZXNlbnRlcl9mYmVkOGExYTQyODg0MmZkODE2ZmFiZjlkOGUxMTE2NCwgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRnJhbWV3b3JrRWxlbWVudC5Ib3Jpem9udGFsQWxpZ25tZW50UHJvcGVydHksIEJpbmRpbmdfYmU2ZWE2ZmExYWIzNGQyZmJjNDQ0ZTFhMDk4YmQ5NWEpO1xyXG5nbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmdPcGVyYXRpb25zLlNldEJpbmRpbmcoQ29udGVudFByZXNlbnRlcl9mYmVkOGExYTQyODg0MmZkODE2ZmFiZjlkOGUxMTE2NCwgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRnJhbWV3b3JrRWxlbWVudC5WZXJ0aWNhbEFsaWdubWVudFByb3BlcnR5LCBCaW5kaW5nX2M4M2NiN2Q1ZTg4ZTRhOTdhOWJiYmRjZGM1NmRjYzY4KTtcclxuZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5CaW5kaW5nT3BlcmF0aW9ucy5TZXRCaW5kaW5nKEJvcmRlcl8wYWE5Y2U1ZmVhYmY0NmY1YTdjNDVlNTNhMjE3MmZjYywgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRnJhbWV3b3JrRWxlbWVudC5IZWlnaHRQcm9wZXJ0eSwgQmluZGluZ19lZjBlNDRlOTQxMGM0YjI2ODFmNDk3ZmVlYTA5MTE0Nyk7XHJcbmdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuQmluZGluZ09wZXJhdGlvbnMuU2V0QmluZGluZyhCb3JkZXJfMGFhOWNlNWZlYWJmNDZmNWE3YzQ1ZTUzYTIxNzJmY2MsIGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkZyYW1ld29ya0VsZW1lbnQuV2lkdGhQcm9wZXJ0eSwgQmluZGluZ19iNmIwZDAxYzhhNzM0ZjEwYTFhYzUyYjY3YzgzZTM1NCk7XHJcbmdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuQmluZGluZ09wZXJhdGlvbnMuU2V0QmluZGluZyhCb3JkZXJfMGFhOWNlNWZlYWJmNDZmNWE3YzQ1ZTUzYTIxNzJmY2MsIGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkNvbnRyb2xzLkJvcmRlci5CYWNrZ3JvdW5kUHJvcGVydHksIEJpbmRpbmdfYjFhYWM0YzA5MDVjNDIwYzg5NjVmZWY1ZTQzOWJmNTEpO1xyXG5nbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmdPcGVyYXRpb25zLlNldEJpbmRpbmcoQm9yZGVyXzBhYTljZTVmZWFiZjQ2ZjVhN2M0NWU1M2EyMTcyZmNjLCBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Db250cm9scy5Cb3JkZXIuQm9yZGVyQnJ1c2hQcm9wZXJ0eSwgQmluZGluZ181YjhhMmU4MDc5YWQ0ZmM3OWNjOWIxZTYzMzg1NDBhYik7XHJcbmdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuQmluZGluZ09wZXJhdGlvbnMuU2V0QmluZGluZyhCb3JkZXJfYzFmY2FkYjRmNmQ5NDk5YmIwZjI1ZjliOGM4ZjAyMjQsIGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkNvbnRyb2xzLkJvcmRlci5Cb3JkZXJUaGlja25lc3NQcm9wZXJ0eSwgQmluZGluZ19jOGNmNDkwYjg1Y2Y0YjUxYTI5NTU0ZWRkZTRjNzUyOSk7XHJcbmdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuQmluZGluZ09wZXJhdGlvbnMuU2V0QmluZGluZyhCb3JkZXJfYzFmY2FkYjRmNmQ5NDk5YmIwZjI1ZjliOGM4ZjAyMjQsIGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkNvbnRyb2xzLkJvcmRlci5Cb3JkZXJCcnVzaFByb3BlcnR5LCBCaW5kaW5nXzIyZDUxMTM1OWRjYzRhZmQ4NjdhM2IwYzcyNjJjMzdkKTtcclxuZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5CaW5kaW5nT3BlcmF0aW9ucy5TZXRCaW5kaW5nKEdyaWRfYWY4NjQwNDg1OGY2NDgxMmI4NWI2MDhlZDI4OWFkODQsIGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkZyYW1ld29ya0VsZW1lbnQuSGVpZ2h0UHJvcGVydHksIEJpbmRpbmdfZDU0NDMxNjZlM2NiNDk3Yzk1OTliYTk0NzU4YmU2ZWYpO1xyXG5nbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmdPcGVyYXRpb25zLlNldEJpbmRpbmcoR3JpZF9hZjg2NDA0ODU4ZjY0ODEyYjg1YjYwOGVkMjg5YWQ4NCwgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRnJhbWV3b3JrRWxlbWVudC5XaWR0aFByb3BlcnR5LCBCaW5kaW5nX2MxODQ5NWNiMzM1MTQxYjY5YzlkNTAwNDVhMmY0NTgyKTtcclxuZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5CaW5kaW5nT3BlcmF0aW9ucy5TZXRCaW5kaW5nKEdyaWRfYWY4NjQwNDg1OGY2NDgxMmI4NWI2MDhlZDI4OWFkODQsIGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkZyYW1ld29ya0VsZW1lbnQuSG9yaXpvbnRhbEFsaWdubWVudFByb3BlcnR5LCBCaW5kaW5nXzc0ZTg0NzkxZDY5YTRhOTc5ZGI0NjE1MmJiMTIyNGJkKTtcclxuZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5CaW5kaW5nT3BlcmF0aW9ucy5TZXRCaW5kaW5nKEdyaWRfYWY4NjQwNDg1OGY2NDgxMmI4NWI2MDhlZDI4OWFkODQsIGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkZyYW1ld29ya0VsZW1lbnQuVmVydGljYWxBbGlnbm1lbnRQcm9wZXJ0eSwgQmluZGluZ183MDZjYTA1YzFjZmM0ZGNlODliZWY0MTQ5YmJkY2I3ZCk7XHJcblxyXG5nbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5NZWRpYS5BbmltYXRpb24uU3Rvcnlib2FyZC5TZXRUYXJnZXRQcm9wZXJ0eShPYmplY3RBbmltYXRpb25Vc2luZ0tleUZyYW1lc18wMzVlODBkMGFiOTk0NmExODg5ODJkNjA4NmFhNWEyNCxcclxuICAgIG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Qcm9wZXJ0eVBhdGgoXHJcbiAgICAgICAgXCJCYWNrZ3JvdW5kXCIsXHJcbiAgICAgICAgXCJCYWNrZ3JvdW5kXCIsXHJcbiAgICAgICAgYWNjZXNzVmlzdWFsU3RhdGVQcm9wZXJ0eV8wZWZlYjFlZTkxYmE0ZTdmYjRhNjA3MTgzNzc4YWJlOSxcclxuICAgICAgICBzZXRWaXN1YWxTdGF0ZVByb3BlcnR5XzBlZmViMWVlOTFiYTRlN2ZiNGE2MDcxODM3NzhhYmU5LFxyXG4gICAgICAgIHNldEFuaW1hdGlvblZpc3VhbFN0YXRlUHJvcGVydHlfMGVmZWIxZWU5MWJhNGU3ZmI0YTYwNzE4Mzc3OGFiZTksICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgIHNldExvY2FsVmlzdWFsU3RhdGVQcm9wZXJ0eV8wZWZlYjFlZTkxYmE0ZTdmYjRhNjA3MTgzNzc4YWJlOSxcclxuICAgICAgICBnZXRWaXN1YWxTdGF0ZVByb3BlcnR5XzBlZmViMWVlOTFiYTRlN2ZiNGE2MDcxODM3NzhhYmU5KSk7XHJcbmdsb2JhbDo6V2luZG93cy5VSS5YYW1sLk1lZGlhLkFuaW1hdGlvbi5TdG9yeWJvYXJkLlNldFRhcmdldChPYmplY3RBbmltYXRpb25Vc2luZ0tleUZyYW1lc18wMzVlODBkMGFiOTk0NmExODg5ODJkNjA4NmFhNWEyNCwgR3JpZF9lZTRjN2NiNDMwNjM0NmY5OWY3NDg1NTM2ZDM3NTUzYSk7XHJcblxyXG5cclxuZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuTWVkaWEuQW5pbWF0aW9uLlN0b3J5Ym9hcmQuU2V0VGFyZ2V0UHJvcGVydHkoT2JqZWN0QW5pbWF0aW9uVXNpbmdLZXlGcmFtZXNfZTZlZDcyMDEwMWM4NDE5NTgyOWM2OWVmZTM1NGRlMDYsXHJcbiAgICBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuUHJvcGVydHlQYXRoKFxyXG4gICAgICAgIFwiSXNIaXRUZXN0VmlzaWJsZVwiLFxyXG4gICAgICAgIFwiSXNIaXRUZXN0VmlzaWJsZVwiLFxyXG4gICAgICAgIGFjY2Vzc1Zpc3VhbFN0YXRlUHJvcGVydHlfNDMyMTI4Y2QxMDRiNDZlZDhmN2U4ZDQ0MTcxNTYzOWIsXHJcbiAgICAgICAgc2V0VmlzdWFsU3RhdGVQcm9wZXJ0eV80MzIxMjhjZDEwNGI0NmVkOGY3ZThkNDQxNzE1NjM5YixcclxuICAgICAgICBzZXRBbmltYXRpb25WaXN1YWxTdGF0ZVByb3BlcnR5XzQzMjEyOGNkMTA0YjQ2ZWQ4ZjdlOGQ0NDE3MTU2MzliLCAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICBzZXRMb2NhbFZpc3VhbFN0YXRlUHJvcGVydHlfNDMyMTI4Y2QxMDRiNDZlZDhmN2U4ZDQ0MTcxNTYzOWIsXHJcbiAgICAgICAgZ2V0VmlzdWFsU3RhdGVQcm9wZXJ0eV80MzIxMjhjZDEwNGI0NmVkOGY3ZThkNDQxNzE1NjM5YikpO1xyXG5nbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5NZWRpYS5BbmltYXRpb24uU3Rvcnlib2FyZC5TZXRUYXJnZXQoT2JqZWN0QW5pbWF0aW9uVXNpbmdLZXlGcmFtZXNfZTZlZDcyMDEwMWM4NDE5NTgyOWM2OWVmZTM1NGRlMDYsIEdyaWRfZWU0YzdjYjQzMDYzNDZmOTlmNzQ4NTUzNmQzNzU1M2EpO1xyXG5cclxudGVtcGxhdGVJbnN0YW5jZV83OTZkMzg2YWZhYTQ0Yzk3YjRlNzkwOWQxMmUzNDgzZi5UZW1wbGF0ZUNvbnRlbnQgPSBHcmlkX2FmODY0MDQ4NThmNjQ4MTJiODViNjA4ZWQyODlhZDg0O1xyXG5yZXR1cm4gdGVtcGxhdGVJbnN0YW5jZV83OTZkMzg2YWZhYTQ0Yzk3YjRlNzkwOWQxMmUzNDgzZjtcclxufSkpO1xyXG5cclxuU2V0dGVyXzRjZjc4NDBkZWQ5ODQxNDdiNGIzNjZhZWQ0ZTRjMDQ2LlZhbHVlID0gQ29udHJvbFRlbXBsYXRlXzQxMDIzOTlkMDY3YTQwNjk5YWJlMjc3NTBhZGEzNTA0O1xyXG5cclxuXHJcblN0eWxlX2I3OGEzZGUxZTFjODRlYTU4NjNkYzViNDYzYjcxYWQzLlNldHRlcnMuQWRkKFNldHRlcl83NDQzNTIwYTY3NDE0ZmNhYWY1NjY5Y2VhZDZmZDk4MSk7XHJcblN0eWxlX2I3OGEzZGUxZTFjODRlYTU4NjNkYzViNDYzYjcxYWQzLlNldHRlcnMuQWRkKFNldHRlcl8zNzcwZGE1MTg2MmU0YTc5YTBlM2MzODM1MWRjZjZlMSk7XHJcblN0eWxlX2I3OGEzZGUxZTFjODRlYTU4NjNkYzViNDYzYjcxYWQzLlNldHRlcnMuQWRkKFNldHRlcl8wNDJmZGZkN2JjYTk0YWM1OTJjZDZiMmE0Yjg5ZWFhOCk7XHJcblN0eWxlX2I3OGEzZGUxZTFjODRlYTU4NjNkYzViNDYzYjcxYWQzLlNldHRlcnMuQWRkKFNldHRlcl85M2JhZDUwMmFhNWU0NDE4Yjk0NWJjMDVlZDIxMDdiMik7XHJcblN0eWxlX2I3OGEzZGUxZTFjODRlYTU4NjNkYzViNDYzYjcxYWQzLlNldHRlcnMuQWRkKFNldHRlcl80Y2Y3ODQwZGVkOTg0MTQ3YjRiMzY2YWVkNGU0YzA0Nik7XHJcblxyXG5cclxudmFyIFN0eWxlXzZhMTczMGMyYjA3ODQ2YzliNjA0MWNjZTIyYjRlYWZhID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlN0eWxlKCk7XHJcblN0eWxlXzZhMTczMGMyYjA3ODQ2YzliNjA0MWNjZTIyYjRlYWZhLlRhcmdldFR5cGUgPSB0eXBlb2YoZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuQ29udHJvbHMuQnV0dG9uKTtcclxudmFyIFNldHRlcl9kM2NkN2JjODJiYTc0YzI0OTBlMjkzMjg0NThkZmVmYiA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5TZXR0ZXIoKTtcclxuU2V0dGVyX2QzY2Q3YmM4MmJhNzRjMjQ5MGUyOTMyODQ1OGRmZWZiLlByb3BlcnR5ID0gZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuQ29udHJvbHMuQnV0dG9uLkJhY2tncm91bmRQcm9wZXJ0eTtcclxuU2V0dGVyX2QzY2Q3YmM4MmJhNzRjMjQ5MGUyOTMyODQ1OGRmZWZiLlZhbHVlID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLk1lZGlhLlNvbGlkQ29sb3JCcnVzaChuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLkNvbG9yKCkgeyBBID0gKGJ5dGUpMjU1LCBSID0gKGJ5dGUpMjI2LCBHID0gKGJ5dGUpMjI2LCBCID0gKGJ5dGUpMjI2IH0pO1xyXG5cclxudmFyIFNldHRlcl9hYjI4OGQ0NjhlYTQ0ZGY4OTJhZTA2NTUyNDQzZmJhYiA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5TZXR0ZXIoKTtcclxuU2V0dGVyX2FiMjg4ZDQ2OGVhNDRkZjg5MmFlMDY1NTI0NDNmYmFiLlByb3BlcnR5ID0gZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuQ29udHJvbHMuQnV0dG9uLkZvcmVncm91bmRQcm9wZXJ0eTtcclxuU2V0dGVyX2FiMjg4ZDQ2OGVhNDRkZjg5MmFlMDY1NTI0NDNmYmFiLlZhbHVlID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLk1lZGlhLlNvbGlkQ29sb3JCcnVzaChuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLkNvbG9yKCkgeyBBID0gKGJ5dGUpMjU1LCBSID0gKGJ5dGUpMCwgRyA9IChieXRlKTAsIEIgPSAoYnl0ZSkwIH0pO1xyXG5cclxudmFyIFNldHRlcl8yZWMxYjMxNmMzMWU0MDI1OWI0YjVhMTk4NDc2OWE0NyA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5TZXR0ZXIoKTtcclxuU2V0dGVyXzJlYzFiMzE2YzMxZTQwMjU5YjRiNWExOTg0NzY5YTQ3LlByb3BlcnR5ID0gZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuQ29udHJvbHMuQnV0dG9uLkJvcmRlclRoaWNrbmVzc1Byb3BlcnR5O1xyXG5TZXR0ZXJfMmVjMWIzMTZjMzFlNDAyNTliNGI1YTE5ODQ3NjlhNDcuVmFsdWUgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuVGhpY2tuZXNzKDApO1xyXG5cclxudmFyIFNldHRlcl9jMjg2OTJjZDcxOTk0ZGMwOWVjNmRhMmQzNjNiYWJmNyA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5TZXR0ZXIoKTtcclxuU2V0dGVyX2MyODY5MmNkNzE5OTRkYzA5ZWM2ZGEyZDM2M2JhYmY3LlByb3BlcnR5ID0gZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuQ29udHJvbHMuQnV0dG9uLlBhZGRpbmdQcm9wZXJ0eTtcclxuU2V0dGVyX2MyODY5MmNkNzE5OTRkYzA5ZWM2ZGEyZDM2M2JhYmY3LlZhbHVlID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlRoaWNrbmVzcygxMiwgNCwgMTIsIDQpO1xyXG5cclxudmFyIFNldHRlcl9mYjg0ZDJlODQyZDU0NTY0OGVhYjJmNDYyNzVlNTViYiA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5TZXR0ZXIoKTtcclxuU2V0dGVyX2ZiODRkMmU4NDJkNTQ1NjQ4ZWFiMmY0NjI3NWU1NWJiLlByb3BlcnR5ID0gZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuQ29udHJvbHMuQnV0dG9uLkN1cnNvclByb3BlcnR5O1xyXG5TZXR0ZXJfZmI4NGQyZTg0MmQ1NDU2NDhlYWIyZjQ2Mjc1ZTU1YmIuVmFsdWUgPSBnbG9iYWw6OlN5c3RlbS5XaW5kb3dzLklucHV0LkN1cnNvcnMuSGFuZDtcclxuXHJcbnZhciBTZXR0ZXJfOTI5MGVjNzM4ZDA5NDI0YjlmNTkxMDc4ZmE1YTI0NmMgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuU2V0dGVyKCk7XHJcblNldHRlcl85MjkwZWM3MzhkMDk0MjRiOWY1OTEwNzhmYTVhMjQ2Yy5Qcm9wZXJ0eSA9IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkNvbnRyb2xzLkJ1dHRvbi5Ib3Jpem9udGFsQ29udGVudEFsaWdubWVudFByb3BlcnR5O1xyXG5TZXR0ZXJfOTI5MGVjNzM4ZDA5NDI0YjlmNTkxMDc4ZmE1YTI0NmMuVmFsdWUgPSBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Ib3Jpem9udGFsQWxpZ25tZW50LkNlbnRlcjtcclxuXHJcbnZhciBTZXR0ZXJfY2UzM2EzZTdjYzY1NDE5ZDg5YThkYmI0MmY2ODhhMjkgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuU2V0dGVyKCk7XHJcblNldHRlcl9jZTMzYTNlN2NjNjU0MTlkODlhOGRiYjQyZjY4OGEyOS5Qcm9wZXJ0eSA9IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkNvbnRyb2xzLkJ1dHRvbi5WZXJ0aWNhbENvbnRlbnRBbGlnbm1lbnRQcm9wZXJ0eTtcclxuU2V0dGVyX2NlMzNhM2U3Y2M2NTQxOWQ4OWE4ZGJiNDJmNjg4YTI5LlZhbHVlID0gZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuVmVydGljYWxBbGlnbm1lbnQuQ2VudGVyO1xyXG5cclxudmFyIFNldHRlcl82ZTA3ZmU3MjgzZGE0MTBiYjY1ZTBhZjE1NmU1Mjc2OCA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5TZXR0ZXIoKTtcclxuU2V0dGVyXzZlMDdmZTcyODNkYTQxMGJiNjVlMGFmMTU2ZTUyNzY4LlByb3BlcnR5ID0gZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuQ29udHJvbHMuQnV0dG9uLlRlbXBsYXRlUHJvcGVydHk7XHJcbnZhciBDb250cm9sVGVtcGxhdGVfOGFmYzI4MTQ3NDdiNDY3N2EyNmQ0NTY3OWMzZDYxMmMgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuQ29udHJvbHMuQ29udHJvbFRlbXBsYXRlKCk7XHJcbkNvbnRyb2xUZW1wbGF0ZV84YWZjMjgxNDc0N2I0Njc3YTI2ZDQ1Njc5YzNkNjEyYy5UYXJnZXRUeXBlID0gdHlwZW9mKGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkNvbnRyb2xzLkJ1dHRvbik7XHJcbkNvbnRyb2xUZW1wbGF0ZV84YWZjMjgxNDc0N2I0Njc3YTI2ZDQ1Njc5YzNkNjEyYy5TZXRNZXRob2RUb0luc3RhbnRpYXRlRnJhbWV3b3JrVGVtcGxhdGUoKFN5c3RlbS5GdW5jPFdpbmRvd3MuVUkuWGFtbC5Db250cm9scy5Db250cm9sLFdpbmRvd3MuVUkuWGFtbC5UZW1wbGF0ZUluc3RhbmNlPikodGVtcGxhdGVPd25lcl9Db250cm9sVGVtcGxhdGVfOGFmYzI4MTQ3NDdiNDY3N2EyNmQ0NTY3OWMzZDYxMmMgPT4gXHJcbntcclxudmFyIHRlbXBsYXRlSW5zdGFuY2VfZTkxYjBhZWY5OTQyNDQ0MmEzOGY2ZWI4NDE5YzgxODUgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuVGVtcGxhdGVJbnN0YW5jZSgpO1xyXG50ZW1wbGF0ZUluc3RhbmNlX2U5MWIwYWVmOTk0MjQ0NDJhMzhmNmViODQxOWM4MTg1LlRlbXBsYXRlT3duZXIgPSB0ZW1wbGF0ZU93bmVyX0NvbnRyb2xUZW1wbGF0ZV84YWZjMjgxNDc0N2I0Njc3YTI2ZDQ1Njc5YzNkNjEyYztcclxudmFyIFZpc3VhbFN0YXRlXzA3NjdjOWI1ZWFjNzQ1Njk4ODlhYTFiZGE5YWE1ZDY4ID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlZpc3VhbFN0YXRlKCk7XHJcbnZhciBWaXN1YWxTdGF0ZV81NDJhZTk2MDc3ZTQ0YjMzOWQ5ZjRjYWU1MTNkOTRlNyA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5WaXN1YWxTdGF0ZSgpO1xyXG52YXIgVmlzdWFsU3RhdGVfNDU0NWFkYjM3Y2M0NDZmNmIzOTE5NDAwMTYzMTE2NjUgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuVmlzdWFsU3RhdGUoKTtcclxudmFyIFZpc3VhbFN0YXRlXzcwZmZhN2E1NTZiODRkZWI4MWJiZDRmOTlkOThjY2I5ID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlZpc3VhbFN0YXRlKCk7XHJcbnZhciBWaXN1YWxTdGF0ZUdyb3VwXzk1NDcyOGE1ODA1MDRjOGI4Y2JiNjg2YjY5NzVlZDQ4ID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlZpc3VhbFN0YXRlR3JvdXAoKTtcclxudmFyIENvbnRlbnRQcmVzZW50ZXJfZDE4Y2Q4NGFhOTkzNDI3ZDgyODdlNGQ2YWIxOTJmY2IgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuQ29udHJvbHMuQ29udGVudFByZXNlbnRlcigpO1xyXG52YXIgQm9yZGVyX2JiM2JiNjMzNTgzYTRjYzM4MjBlNzU3ZGU4ZTBkNGQ0ID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkNvbnRyb2xzLkJvcmRlcigpO1xyXG52YXIgQm9yZGVyX2NlZjQ4NzQ1OTIwMzQxZmQ5YjE2MzZmMzA1M2RiZDgxID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkNvbnRyb2xzLkJvcmRlcigpO1xyXG50ZW1wbGF0ZU93bmVyX0NvbnRyb2xUZW1wbGF0ZV84YWZjMjgxNDc0N2I0Njc3YTI2ZDQ1Njc5YzNkNjEyYy5SZWdpc3Rlck5hbWUoXCJPdXRlckJvcmRlclwiLCBCb3JkZXJfY2VmNDg3NDU5MjAzNDFmZDliMTYzNmYzMDUzZGJkODEpO1xyXG5Cb3JkZXJfY2VmNDg3NDU5MjAzNDFmZDliMTYzNmYzMDUzZGJkODEuTmFtZSA9IFwiT3V0ZXJCb3JkZXJcIjtcclxudGVtcGxhdGVPd25lcl9Db250cm9sVGVtcGxhdGVfOGFmYzI4MTQ3NDdiNDY3N2EyNmQ0NTY3OWMzZDYxMmMuUmVnaXN0ZXJOYW1lKFwiQ29tbW9uU3RhdGVzXCIsIFZpc3VhbFN0YXRlR3JvdXBfOTU0NzI4YTU4MDUwNGM4YjhjYmI2ODZiNjk3NWVkNDgpO1xyXG5WaXN1YWxTdGF0ZUdyb3VwXzk1NDcyOGE1ODA1MDRjOGI4Y2JiNjg2YjY5NzVlZDQ4Lk5hbWUgPSBcIkNvbW1vblN0YXRlc1wiO1xyXG50ZW1wbGF0ZU93bmVyX0NvbnRyb2xUZW1wbGF0ZV84YWZjMjgxNDc0N2I0Njc3YTI2ZDQ1Njc5YzNkNjEyYy5SZWdpc3Rlck5hbWUoXCJOb3JtYWxcIiwgVmlzdWFsU3RhdGVfMDc2N2M5YjVlYWM3NDU2OTg4OWFhMWJkYTlhYTVkNjgpO1xyXG5WaXN1YWxTdGF0ZV8wNzY3YzliNWVhYzc0NTY5ODg5YWExYmRhOWFhNWQ2OC5OYW1lID0gXCJOb3JtYWxcIjtcclxuXHJcbnRlbXBsYXRlT3duZXJfQ29udHJvbFRlbXBsYXRlXzhhZmMyODE0NzQ3YjQ2NzdhMjZkNDU2NzljM2Q2MTJjLlJlZ2lzdGVyTmFtZShcIlBvaW50ZXJPdmVyXCIsIFZpc3VhbFN0YXRlXzU0MmFlOTYwNzdlNDRiMzM5ZDlmNGNhZTUxM2Q5NGU3KTtcclxuVmlzdWFsU3RhdGVfNTQyYWU5NjA3N2U0NGIzMzlkOWY0Y2FlNTEzZDk0ZTcuTmFtZSA9IFwiUG9pbnRlck92ZXJcIjtcclxudmFyIFN0b3J5Ym9hcmRfZmI3Mzk3ZDA2Yjk1NGU2MTlmNGJhMmRjOTlhZmE5NDkgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuTWVkaWEuQW5pbWF0aW9uLlN0b3J5Ym9hcmQoKTtcclxudmFyIE9iamVjdEFuaW1hdGlvblVzaW5nS2V5RnJhbWVzX2I0YmRlZDZlYWY3YzQ1ZmM5MTAzZWJjMTQzM2IzYmJjID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLk1lZGlhLkFuaW1hdGlvbi5PYmplY3RBbmltYXRpb25Vc2luZ0tleUZyYW1lcygpO1xyXG5nbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5NZWRpYS5BbmltYXRpb24uU3Rvcnlib2FyZC5TZXRUYXJnZXROYW1lKE9iamVjdEFuaW1hdGlvblVzaW5nS2V5RnJhbWVzX2I0YmRlZDZlYWY3YzQ1ZmM5MTAzZWJjMTQzM2IzYmJjLEBcIklubmVyQm9yZGVyXCIpO1xyXG52YXIgRGlzY3JldGVPYmplY3RLZXlGcmFtZV81OTMwMTNkNWU4MTc0N2E5YjBiMWZiNTVlYTliYjVjYSA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5NZWRpYS5BbmltYXRpb24uRGlzY3JldGVPYmplY3RLZXlGcmFtZSgpO1xyXG5EaXNjcmV0ZU9iamVjdEtleUZyYW1lXzU5MzAxM2Q1ZTgxNzQ3YTliMGIxZmI1NWVhOWJiNWNhLktleVRpbWUgPSBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5NZWRpYS5BbmltYXRpb24uS2V5VGltZS5Gcm9tVGltZVNwYW4obmV3IGdsb2JhbDo6U3lzdGVtLlRpbWVTcGFuKDBMKSk7XHJcbkRpc2NyZXRlT2JqZWN0S2V5RnJhbWVfNTkzMDEzZDVlODE3NDdhOWIwYjFmYjU1ZWE5YmI1Y2EuVmFsdWUgPSBAXCIjMTEwMDAwMDBcIjtcclxuXHJcbk9iamVjdEFuaW1hdGlvblVzaW5nS2V5RnJhbWVzX2I0YmRlZDZlYWY3YzQ1ZmM5MTAzZWJjMTQzM2IzYmJjLktleUZyYW1lcy5BZGQoRGlzY3JldGVPYmplY3RLZXlGcmFtZV81OTMwMTNkNWU4MTc0N2E5YjBiMWZiNTVlYTliYjVjYSk7XHJcblxyXG5cclxuU3Rvcnlib2FyZF9mYjczOTdkMDZiOTU0ZTYxOWY0YmEyZGM5OWFmYTk0OS5DaGlsZHJlbi5BZGQoT2JqZWN0QW5pbWF0aW9uVXNpbmdLZXlGcmFtZXNfYjRiZGVkNmVhZjdjNDVmYzkxMDNlYmMxNDMzYjNiYmMpO1xyXG5cclxuXHJcblZpc3VhbFN0YXRlXzU0MmFlOTYwNzdlNDRiMzM5ZDlmNGNhZTUxM2Q5NGU3LlN0b3J5Ym9hcmQgPSBTdG9yeWJvYXJkX2ZiNzM5N2QwNmI5NTRlNjE5ZjRiYTJkYzk5YWZhOTQ5O1xyXG5cclxuXHJcbnRlbXBsYXRlT3duZXJfQ29udHJvbFRlbXBsYXRlXzhhZmMyODE0NzQ3YjQ2NzdhMjZkNDU2NzljM2Q2MTJjLlJlZ2lzdGVyTmFtZShcIlByZXNzZWRcIiwgVmlzdWFsU3RhdGVfNDU0NWFkYjM3Y2M0NDZmNmIzOTE5NDAwMTYzMTE2NjUpO1xyXG5WaXN1YWxTdGF0ZV80NTQ1YWRiMzdjYzQ0NmY2YjM5MTk0MDAxNjMxMTY2NS5OYW1lID0gXCJQcmVzc2VkXCI7XHJcbnZhciBTdG9yeWJvYXJkX2FjZGYxMDVjNWVkNTQ2ZmI5MjJlMWVlMzBmNjkxMDE2ID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLk1lZGlhLkFuaW1hdGlvbi5TdG9yeWJvYXJkKCk7XHJcbnZhciBPYmplY3RBbmltYXRpb25Vc2luZ0tleUZyYW1lc18yYzIzZjAxYjFjMTI0YTkxOTFiOWY1ZmVhZWFjMTFkOCA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5NZWRpYS5BbmltYXRpb24uT2JqZWN0QW5pbWF0aW9uVXNpbmdLZXlGcmFtZXMoKTtcclxuZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuTWVkaWEuQW5pbWF0aW9uLlN0b3J5Ym9hcmQuU2V0VGFyZ2V0TmFtZShPYmplY3RBbmltYXRpb25Vc2luZ0tleUZyYW1lc18yYzIzZjAxYjFjMTI0YTkxOTFiOWY1ZmVhZWFjMTFkOCxAXCJJbm5lckJvcmRlclwiKTtcclxudmFyIERpc2NyZXRlT2JqZWN0S2V5RnJhbWVfNjBjNWE2Y2VjOTdiNDY3YmE0ZjAzZDMyZTc0MDUzZDEgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuTWVkaWEuQW5pbWF0aW9uLkRpc2NyZXRlT2JqZWN0S2V5RnJhbWUoKTtcclxuRGlzY3JldGVPYmplY3RLZXlGcmFtZV82MGM1YTZjZWM5N2I0NjdiYTRmMDNkMzJlNzQwNTNkMS5LZXlUaW1lID0gZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuTWVkaWEuQW5pbWF0aW9uLktleVRpbWUuRnJvbVRpbWVTcGFuKG5ldyBnbG9iYWw6OlN5c3RlbS5UaW1lU3BhbigwTCkpO1xyXG5EaXNjcmV0ZU9iamVjdEtleUZyYW1lXzYwYzVhNmNlYzk3YjQ2N2JhNGYwM2QzMmU3NDA1M2QxLlZhbHVlID0gQFwiIzIyMDAwMDAwXCI7XHJcblxyXG5PYmplY3RBbmltYXRpb25Vc2luZ0tleUZyYW1lc18yYzIzZjAxYjFjMTI0YTkxOTFiOWY1ZmVhZWFjMTFkOC5LZXlGcmFtZXMuQWRkKERpc2NyZXRlT2JqZWN0S2V5RnJhbWVfNjBjNWE2Y2VjOTdiNDY3YmE0ZjAzZDMyZTc0MDUzZDEpO1xyXG5cclxuXHJcblN0b3J5Ym9hcmRfYWNkZjEwNWM1ZWQ1NDZmYjkyMmUxZWUzMGY2OTEwMTYuQ2hpbGRyZW4uQWRkKE9iamVjdEFuaW1hdGlvblVzaW5nS2V5RnJhbWVzXzJjMjNmMDFiMWMxMjRhOTE5MWI5ZjVmZWFlYWMxMWQ4KTtcclxuXHJcblxyXG5WaXN1YWxTdGF0ZV80NTQ1YWRiMzdjYzQ0NmY2YjM5MTk0MDAxNjMxMTY2NS5TdG9yeWJvYXJkID0gU3Rvcnlib2FyZF9hY2RmMTA1YzVlZDU0NmZiOTIyZTFlZTMwZjY5MTAxNjtcclxuXHJcblxyXG50ZW1wbGF0ZU93bmVyX0NvbnRyb2xUZW1wbGF0ZV84YWZjMjgxNDc0N2I0Njc3YTI2ZDQ1Njc5YzNkNjEyYy5SZWdpc3Rlck5hbWUoXCJEaXNhYmxlZFwiLCBWaXN1YWxTdGF0ZV83MGZmYTdhNTU2Yjg0ZGViODFiYmQ0Zjk5ZDk4Y2NiOSk7XHJcblZpc3VhbFN0YXRlXzcwZmZhN2E1NTZiODRkZWI4MWJiZDRmOTlkOThjY2I5Lk5hbWUgPSBcIkRpc2FibGVkXCI7XHJcbnZhciBTdG9yeWJvYXJkXzE5NjhmY2NiMTlhMzQ3ZjNiOTAwMjllOGIwZTdiYTUyID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLk1lZGlhLkFuaW1hdGlvbi5TdG9yeWJvYXJkKCk7XHJcbnZhciBPYmplY3RBbmltYXRpb25Vc2luZ0tleUZyYW1lc180MGRiYTBiMDM3OTc0ZDYyYmUxYjVjMmY2Nzg0ZTJhMSA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5NZWRpYS5BbmltYXRpb24uT2JqZWN0QW5pbWF0aW9uVXNpbmdLZXlGcmFtZXMoKTtcclxuZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuTWVkaWEuQW5pbWF0aW9uLlN0b3J5Ym9hcmQuU2V0VGFyZ2V0TmFtZShPYmplY3RBbmltYXRpb25Vc2luZ0tleUZyYW1lc180MGRiYTBiMDM3OTc0ZDYyYmUxYjVjMmY2Nzg0ZTJhMSxAXCJJbm5lckJvcmRlclwiKTtcclxudmFyIERpc2NyZXRlT2JqZWN0S2V5RnJhbWVfNzIwYzU2NjMyY2JiNDBmMmIxNTFkNzY2YjY2OTFlMTAgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuTWVkaWEuQW5pbWF0aW9uLkRpc2NyZXRlT2JqZWN0S2V5RnJhbWUoKTtcclxuRGlzY3JldGVPYmplY3RLZXlGcmFtZV83MjBjNTY2MzJjYmI0MGYyYjE1MWQ3NjZiNjY5MWUxMC5LZXlUaW1lID0gZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuTWVkaWEuQW5pbWF0aW9uLktleVRpbWUuRnJvbVRpbWVTcGFuKG5ldyBnbG9iYWw6OlN5c3RlbS5UaW1lU3BhbigwTCkpO1xyXG5EaXNjcmV0ZU9iamVjdEtleUZyYW1lXzcyMGM1NjYzMmNiYjQwZjJiMTUxZDc2NmI2NjkxZTEwLlZhbHVlID0gQFwiIzMzRkZGRkZGXCI7XHJcblxyXG5PYmplY3RBbmltYXRpb25Vc2luZ0tleUZyYW1lc180MGRiYTBiMDM3OTc0ZDYyYmUxYjVjMmY2Nzg0ZTJhMS5LZXlGcmFtZXMuQWRkKERpc2NyZXRlT2JqZWN0S2V5RnJhbWVfNzIwYzU2NjMyY2JiNDBmMmIxNTFkNzY2YjY2OTFlMTApO1xyXG5cclxuXHJcblN0b3J5Ym9hcmRfMTk2OGZjY2IxOWEzNDdmM2I5MDAyOWU4YjBlN2JhNTIuQ2hpbGRyZW4uQWRkKE9iamVjdEFuaW1hdGlvblVzaW5nS2V5RnJhbWVzXzQwZGJhMGIwMzc5NzRkNjJiZTFiNWMyZjY3ODRlMmExKTtcclxuXHJcblxyXG5WaXN1YWxTdGF0ZV83MGZmYTdhNTU2Yjg0ZGViODFiYmQ0Zjk5ZDk4Y2NiOS5TdG9yeWJvYXJkID0gU3Rvcnlib2FyZF8xOTY4ZmNjYjE5YTM0N2YzYjkwMDI5ZThiMGU3YmE1MjtcclxuXHJcblxyXG5WaXN1YWxTdGF0ZUdyb3VwXzk1NDcyOGE1ODA1MDRjOGI4Y2JiNjg2YjY5NzVlZDQ4LlN0YXRlcy5BZGQoVmlzdWFsU3RhdGVfMDc2N2M5YjVlYWM3NDU2OTg4OWFhMWJkYTlhYTVkNjgpO1xyXG5WaXN1YWxTdGF0ZUdyb3VwXzk1NDcyOGE1ODA1MDRjOGI4Y2JiNjg2YjY5NzVlZDQ4LlN0YXRlcy5BZGQoVmlzdWFsU3RhdGVfNTQyYWU5NjA3N2U0NGIzMzlkOWY0Y2FlNTEzZDk0ZTcpO1xyXG5WaXN1YWxTdGF0ZUdyb3VwXzk1NDcyOGE1ODA1MDRjOGI4Y2JiNjg2YjY5NzVlZDQ4LlN0YXRlcy5BZGQoVmlzdWFsU3RhdGVfNDU0NWFkYjM3Y2M0NDZmNmIzOTE5NDAwMTYzMTE2NjUpO1xyXG5WaXN1YWxTdGF0ZUdyb3VwXzk1NDcyOGE1ODA1MDRjOGI4Y2JiNjg2YjY5NzVlZDQ4LlN0YXRlcy5BZGQoVmlzdWFsU3RhdGVfNzBmZmE3YTU1NmI4NGRlYjgxYmJkNGY5OWQ5OGNjYjkpO1xyXG5cclxuXHJcbnRlbXBsYXRlT3duZXJfQ29udHJvbFRlbXBsYXRlXzhhZmMyODE0NzQ3YjQ2NzdhMjZkNDU2NzljM2Q2MTJjLklOVEVSTkFMX0dldFZpc3VhbFN0YXRlR3JvdXBzKCkuQWRkKFZpc3VhbFN0YXRlR3JvdXBfOTU0NzI4YTU4MDUwNGM4YjhjYmI2ODZiNjk3NWVkNDgpO1xyXG5cclxudGVtcGxhdGVPd25lcl9Db250cm9sVGVtcGxhdGVfOGFmYzI4MTQ3NDdiNDY3N2EyNmQ0NTY3OWMzZDYxMmMuUmVnaXN0ZXJOYW1lKFwiSW5uZXJCb3JkZXJcIiwgQm9yZGVyX2JiM2JiNjMzNTgzYTRjYzM4MjBlNzU3ZGU4ZTBkNGQ0KTtcclxuQm9yZGVyX2JiM2JiNjMzNTgzYTRjYzM4MjBlNzU3ZGU4ZTBkNGQ0Lk5hbWUgPSBcIklubmVyQm9yZGVyXCI7XHJcbnRlbXBsYXRlT3duZXJfQ29udHJvbFRlbXBsYXRlXzhhZmMyODE0NzQ3YjQ2NzdhMjZkNDU2NzljM2Q2MTJjLlJlZ2lzdGVyTmFtZShcIkNvbnRlbnRQcmVzZW50ZXJcIiwgQ29udGVudFByZXNlbnRlcl9kMThjZDg0YWE5OTM0MjdkODI4N2U0ZDZhYjE5MmZjYik7XHJcbkNvbnRlbnRQcmVzZW50ZXJfZDE4Y2Q4NGFhOTkzNDI3ZDgyODdlNGQ2YWIxOTJmY2IuTmFtZSA9IFwiQ29udGVudFByZXNlbnRlclwiO1xyXG52YXIgQmluZGluZ19jYjQ4ODM2ZTlhOTQ0ZTljOWE3N2UwYTcxMmMwMGZlNiA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmcoKTtcclxuQmluZGluZ19jYjQ4ODM2ZTlhOTQ0ZTljOWE3N2UwYTcxMmMwMGZlNi5QYXRoID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlByb3BlcnR5UGF0aChAXCJDb250ZW50VGVtcGxhdGVcIik7XHJcbnZhciBSZWxhdGl2ZVNvdXJjZV9jY2NkZDU3YmE0ZTA0MmIzYmFlODhjODkyZjJlNWY5ZiA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLlJlbGF0aXZlU291cmNlKCk7XHJcblJlbGF0aXZlU291cmNlX2NjY2RkNTdiYTRlMDQyYjNiYWU4OGM4OTJmMmU1ZjlmLk1vZGUgPSBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLlJlbGF0aXZlU291cmNlTW9kZS5UZW1wbGF0ZWRQYXJlbnQ7XHJcblxyXG5CaW5kaW5nX2NiNDg4MzZlOWE5NDRlOWM5YTc3ZTBhNzEyYzAwZmU2LlJlbGF0aXZlU291cmNlID0gUmVsYXRpdmVTb3VyY2VfY2NjZGQ1N2JhNGUwNDJiM2JhZTg4Yzg5MmYyZTVmOWY7XHJcblxyXG5cclxuQmluZGluZ19jYjQ4ODM2ZTlhOTQ0ZTljOWE3N2UwYTcxMmMwMGZlNi5UZW1wbGF0ZU93bmVyID0gdGVtcGxhdGVJbnN0YW5jZV9lOTFiMGFlZjk5NDI0NDQyYTM4ZjZlYjg0MTljODE4NTtcclxuXHJcbnZhciBCaW5kaW5nX2Y5NjVjYjE2NGRkYTQ2MmJiYTYyOTUwZjQ5YzFhNzQ2ID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuQmluZGluZygpO1xyXG5CaW5kaW5nX2Y5NjVjYjE2NGRkYTQ2MmJiYTYyOTUwZjQ5YzFhNzQ2LlBhdGggPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuUHJvcGVydHlQYXRoKEBcIkNvbnRlbnRcIik7XHJcbnZhciBSZWxhdGl2ZVNvdXJjZV8zNzVkNzJmMDRiNjQ0MDk5YmRlYzhlMjhjZWVlZWNjOSA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLlJlbGF0aXZlU291cmNlKCk7XHJcblJlbGF0aXZlU291cmNlXzM3NWQ3MmYwNGI2NDQwOTliZGVjOGUyOGNlZWVlY2M5Lk1vZGUgPSBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLlJlbGF0aXZlU291cmNlTW9kZS5UZW1wbGF0ZWRQYXJlbnQ7XHJcblxyXG5CaW5kaW5nX2Y5NjVjYjE2NGRkYTQ2MmJiYTYyOTUwZjQ5YzFhNzQ2LlJlbGF0aXZlU291cmNlID0gUmVsYXRpdmVTb3VyY2VfMzc1ZDcyZjA0YjY0NDA5OWJkZWM4ZTI4Y2VlZWVjYzk7XHJcblxyXG5cclxuQmluZGluZ19mOTY1Y2IxNjRkZGE0NjJiYmE2Mjk1MGY0OWMxYTc0Ni5UZW1wbGF0ZU93bmVyID0gdGVtcGxhdGVJbnN0YW5jZV9lOTFiMGFlZjk5NDI0NDQyYTM4ZjZlYjg0MTljODE4NTtcclxuXHJcbnZhciBCaW5kaW5nXzgxNDAxZjA0YjcwNjQ1YTk5YjUwNTkwMWE1OGVjMjY4ID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuQmluZGluZygpO1xyXG5CaW5kaW5nXzgxNDAxZjA0YjcwNjQ1YTk5YjUwNTkwMWE1OGVjMjY4LlBhdGggPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuUHJvcGVydHlQYXRoKEBcIkhlaWdodFwiKTtcclxudmFyIFJlbGF0aXZlU291cmNlXzAyZTE5Njc3NjEzMDQxYzBhZTNhY2VkNDViMmI5OTUwID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuUmVsYXRpdmVTb3VyY2UoKTtcclxuUmVsYXRpdmVTb3VyY2VfMDJlMTk2Nzc2MTMwNDFjMGFlM2FjZWQ0NWIyYjk5NTAuTW9kZSA9IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuUmVsYXRpdmVTb3VyY2VNb2RlLlRlbXBsYXRlZFBhcmVudDtcclxuXHJcbkJpbmRpbmdfODE0MDFmMDRiNzA2NDVhOTliNTA1OTAxYTU4ZWMyNjguUmVsYXRpdmVTb3VyY2UgPSBSZWxhdGl2ZVNvdXJjZV8wMmUxOTY3NzYxMzA0MWMwYWUzYWNlZDQ1YjJiOTk1MDtcclxuXHJcblxyXG5CaW5kaW5nXzgxNDAxZjA0YjcwNjQ1YTk5YjUwNTkwMWE1OGVjMjY4LlRlbXBsYXRlT3duZXIgPSB0ZW1wbGF0ZUluc3RhbmNlX2U5MWIwYWVmOTk0MjQ0NDJhMzhmNmViODQxOWM4MTg1O1xyXG5cclxudmFyIEJpbmRpbmdfMzJkN2EzNTViNGQ2NDFhNGE0MDE0ZThhNmQ5YmY1ZWQgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5CaW5kaW5nKCk7XHJcbkJpbmRpbmdfMzJkN2EzNTViNGQ2NDFhNGE0MDE0ZThhNmQ5YmY1ZWQuUGF0aCA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Qcm9wZXJ0eVBhdGgoQFwiV2lkdGhcIik7XHJcbnZhciBSZWxhdGl2ZVNvdXJjZV9hZjYwOWE3YjJlMTA0ZmFhYTFlZmVmNmYxMGRjMmNiMCA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLlJlbGF0aXZlU291cmNlKCk7XHJcblJlbGF0aXZlU291cmNlX2FmNjA5YTdiMmUxMDRmYWFhMWVmZWY2ZjEwZGMyY2IwLk1vZGUgPSBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLlJlbGF0aXZlU291cmNlTW9kZS5UZW1wbGF0ZWRQYXJlbnQ7XHJcblxyXG5CaW5kaW5nXzMyZDdhMzU1YjRkNjQxYTRhNDAxNGU4YTZkOWJmNWVkLlJlbGF0aXZlU291cmNlID0gUmVsYXRpdmVTb3VyY2VfYWY2MDlhN2IyZTEwNGZhYWExZWZlZjZmMTBkYzJjYjA7XHJcblxyXG5cclxuQmluZGluZ18zMmQ3YTM1NWI0ZDY0MWE0YTQwMTRlOGE2ZDliZjVlZC5UZW1wbGF0ZU93bmVyID0gdGVtcGxhdGVJbnN0YW5jZV9lOTFiMGFlZjk5NDI0NDQyYTM4ZjZlYjg0MTljODE4NTtcclxuXHJcbnZhciBCaW5kaW5nX2M2Y2MwMTU3MWVhODRkZjU4ZTU1ZDQ2ZTYwNDRkMWFlID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuQmluZGluZygpO1xyXG5CaW5kaW5nX2M2Y2MwMTU3MWVhODRkZjU4ZTU1ZDQ2ZTYwNDRkMWFlLlBhdGggPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuUHJvcGVydHlQYXRoKEBcIlBhZGRpbmdcIik7XHJcbnZhciBSZWxhdGl2ZVNvdXJjZV9lMGRlY2ZlN2JmY2U0MjlmYjM3MWI2MWE0YTliOGZmYiA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLlJlbGF0aXZlU291cmNlKCk7XHJcblJlbGF0aXZlU291cmNlX2UwZGVjZmU3YmZjZTQyOWZiMzcxYjYxYTRhOWI4ZmZiLk1vZGUgPSBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLlJlbGF0aXZlU291cmNlTW9kZS5UZW1wbGF0ZWRQYXJlbnQ7XHJcblxyXG5CaW5kaW5nX2M2Y2MwMTU3MWVhODRkZjU4ZTU1ZDQ2ZTYwNDRkMWFlLlJlbGF0aXZlU291cmNlID0gUmVsYXRpdmVTb3VyY2VfZTBkZWNmZTdiZmNlNDI5ZmIzNzFiNjFhNGE5YjhmZmI7XHJcblxyXG5cclxuQmluZGluZ19jNmNjMDE1NzFlYTg0ZGY1OGU1NWQ0NmU2MDQ0ZDFhZS5UZW1wbGF0ZU93bmVyID0gdGVtcGxhdGVJbnN0YW5jZV9lOTFiMGFlZjk5NDI0NDQyYTM4ZjZlYjg0MTljODE4NTtcclxuXHJcbnZhciBCaW5kaW5nXzQ0NTVmMmMzOTI3MDQ2MmFhMjk5M2UyMjM4ZGQ0MGZkID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuQmluZGluZygpO1xyXG5CaW5kaW5nXzQ0NTVmMmMzOTI3MDQ2MmFhMjk5M2UyMjM4ZGQ0MGZkLlBhdGggPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuUHJvcGVydHlQYXRoKEBcIkhvcml6b250YWxDb250ZW50QWxpZ25tZW50XCIpO1xyXG52YXIgUmVsYXRpdmVTb3VyY2VfNjI0NjlhYzlhNzNlNGUwYjlmYTkzZTM1ZWJmZmI4MTcgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5SZWxhdGl2ZVNvdXJjZSgpO1xyXG5SZWxhdGl2ZVNvdXJjZV82MjQ2OWFjOWE3M2U0ZTBiOWZhOTNlMzVlYmZmYjgxNy5Nb2RlID0gZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5SZWxhdGl2ZVNvdXJjZU1vZGUuVGVtcGxhdGVkUGFyZW50O1xyXG5cclxuQmluZGluZ180NDU1ZjJjMzkyNzA0NjJhYTI5OTNlMjIzOGRkNDBmZC5SZWxhdGl2ZVNvdXJjZSA9IFJlbGF0aXZlU291cmNlXzYyNDY5YWM5YTczZTRlMGI5ZmE5M2UzNWViZmZiODE3O1xyXG5cclxuXHJcbkJpbmRpbmdfNDQ1NWYyYzM5MjcwNDYyYWEyOTkzZTIyMzhkZDQwZmQuVGVtcGxhdGVPd25lciA9IHRlbXBsYXRlSW5zdGFuY2VfZTkxYjBhZWY5OTQyNDQ0MmEzOGY2ZWI4NDE5YzgxODU7XHJcblxyXG52YXIgQmluZGluZ18yYTBhZjI4N2I2OGM0N2Y2OWU5ZWZlYmE4MTgyZDc1YSA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmcoKTtcclxuQmluZGluZ18yYTBhZjI4N2I2OGM0N2Y2OWU5ZWZlYmE4MTgyZDc1YS5QYXRoID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlByb3BlcnR5UGF0aChAXCJWZXJ0aWNhbENvbnRlbnRBbGlnbm1lbnRcIik7XHJcbnZhciBSZWxhdGl2ZVNvdXJjZV9lM2MwMDVkMjIwOTQ0ZTE5ODhiNzlkZWM1MGU3MTA2MSA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLlJlbGF0aXZlU291cmNlKCk7XHJcblJlbGF0aXZlU291cmNlX2UzYzAwNWQyMjA5NDRlMTk4OGI3OWRlYzUwZTcxMDYxLk1vZGUgPSBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLlJlbGF0aXZlU291cmNlTW9kZS5UZW1wbGF0ZWRQYXJlbnQ7XHJcblxyXG5CaW5kaW5nXzJhMGFmMjg3YjY4YzQ3ZjY5ZTllZmViYTgxODJkNzVhLlJlbGF0aXZlU291cmNlID0gUmVsYXRpdmVTb3VyY2VfZTNjMDA1ZDIyMDk0NGUxOTg4Yjc5ZGVjNTBlNzEwNjE7XHJcblxyXG5cclxuQmluZGluZ18yYTBhZjI4N2I2OGM0N2Y2OWU5ZWZlYmE4MTgyZDc1YS5UZW1wbGF0ZU93bmVyID0gdGVtcGxhdGVJbnN0YW5jZV9lOTFiMGFlZjk5NDI0NDQyYTM4ZjZlYjg0MTljODE4NTtcclxuXHJcbnZhciBCaW5kaW5nXzFjZjY4ODcwMDIyMTRhYjM4YjhmZGM1YTQ1MGYzY2Q0ID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuQmluZGluZygpO1xyXG5CaW5kaW5nXzFjZjY4ODcwMDIyMTRhYjM4YjhmZGM1YTQ1MGYzY2Q0LlBhdGggPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuUHJvcGVydHlQYXRoKEBcIlZpc2liaWxpdHlcIik7XHJcblxyXG5cclxuXHJcbkJvcmRlcl9iYjNiYjYzMzU4M2E0Y2MzODIwZTc1N2RlOGUwZDRkNC5DaGlsZCA9IENvbnRlbnRQcmVzZW50ZXJfZDE4Y2Q4NGFhOTkzNDI3ZDgyODdlNGQ2YWIxOTJmY2I7XHJcblxyXG52YXIgQmluZGluZ19iYzQ3MTcxMDY4ODg0MWUyOGY2YjYwODFhMzhkNjE0OCA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmcoKTtcclxuQmluZGluZ19iYzQ3MTcxMDY4ODg0MWUyOGY2YjYwODFhMzhkNjE0OC5QYXRoID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlByb3BlcnR5UGF0aChAXCJCYWNrZ3JvdW5kXCIpO1xyXG52YXIgUmVsYXRpdmVTb3VyY2VfNjE3ZmI3MmEwNWIyNDQ5MTk4Y2Y5NWNiNmVkNGUxMGMgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5SZWxhdGl2ZVNvdXJjZSgpO1xyXG5SZWxhdGl2ZVNvdXJjZV82MTdmYjcyYTA1YjI0NDkxOThjZjk1Y2I2ZWQ0ZTEwYy5Nb2RlID0gZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5SZWxhdGl2ZVNvdXJjZU1vZGUuVGVtcGxhdGVkUGFyZW50O1xyXG5cclxuQmluZGluZ19iYzQ3MTcxMDY4ODg0MWUyOGY2YjYwODFhMzhkNjE0OC5SZWxhdGl2ZVNvdXJjZSA9IFJlbGF0aXZlU291cmNlXzYxN2ZiNzJhMDViMjQ0OTE5OGNmOTVjYjZlZDRlMTBjO1xyXG5cclxuXHJcbkJpbmRpbmdfYmM0NzE3MTA2ODg4NDFlMjhmNmI2MDgxYTM4ZDYxNDguVGVtcGxhdGVPd25lciA9IHRlbXBsYXRlSW5zdGFuY2VfZTkxYjBhZWY5OTQyNDQ0MmEzOGY2ZWI4NDE5YzgxODU7XHJcblxyXG5cclxuQm9yZGVyX2NlZjQ4NzQ1OTIwMzQxZmQ5YjE2MzZmMzA1M2RiZDgxLkNoaWxkID0gQm9yZGVyX2JiM2JiNjMzNTgzYTRjYzM4MjBlNzU3ZGU4ZTBkNGQ0O1xyXG5cclxudmFyIEJpbmRpbmdfOTMzYjgwM2QzNjdmNDZhYjk1ODBhNGY3YThlNzU1YjIgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5CaW5kaW5nKCk7XHJcbkJpbmRpbmdfOTMzYjgwM2QzNjdmNDZhYjk1ODBhNGY3YThlNzU1YjIuUGF0aCA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Qcm9wZXJ0eVBhdGgoQFwiQmFja2dyb3VuZFwiKTtcclxudmFyIFJlbGF0aXZlU291cmNlXzA5YjA2MWRiZDU5ZTQyYTRhOWQyZDZiYzUwY2VhZjNhID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuUmVsYXRpdmVTb3VyY2UoKTtcclxuUmVsYXRpdmVTb3VyY2VfMDliMDYxZGJkNTllNDJhNGE5ZDJkNmJjNTBjZWFmM2EuTW9kZSA9IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuUmVsYXRpdmVTb3VyY2VNb2RlLlRlbXBsYXRlZFBhcmVudDtcclxuXHJcbkJpbmRpbmdfOTMzYjgwM2QzNjdmNDZhYjk1ODBhNGY3YThlNzU1YjIuUmVsYXRpdmVTb3VyY2UgPSBSZWxhdGl2ZVNvdXJjZV8wOWIwNjFkYmQ1OWU0MmE0YTlkMmQ2YmM1MGNlYWYzYTtcclxuXHJcblxyXG5CaW5kaW5nXzkzM2I4MDNkMzY3ZjQ2YWI5NTgwYTRmN2E4ZTc1NWIyLlRlbXBsYXRlT3duZXIgPSB0ZW1wbGF0ZUluc3RhbmNlX2U5MWIwYWVmOTk0MjQ0NDJhMzhmNmViODQxOWM4MTg1O1xyXG5cclxudmFyIEJpbmRpbmdfMzUwMmFiZTY0NzViNDM1MjlkM2I0NTMzYTZhYzc0YWYgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5CaW5kaW5nKCk7XHJcbkJpbmRpbmdfMzUwMmFiZTY0NzViNDM1MjlkM2I0NTMzYTZhYzc0YWYuUGF0aCA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Qcm9wZXJ0eVBhdGgoQFwiQm9yZGVyQnJ1c2hcIik7XHJcbnZhciBSZWxhdGl2ZVNvdXJjZV9hZTcyMWUxZjU0ZDM0MTFmOTUxZjhjMjI5MTZmMWE5NyA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLlJlbGF0aXZlU291cmNlKCk7XHJcblJlbGF0aXZlU291cmNlX2FlNzIxZTFmNTRkMzQxMWY5NTFmOGMyMjkxNmYxYTk3Lk1vZGUgPSBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLlJlbGF0aXZlU291cmNlTW9kZS5UZW1wbGF0ZWRQYXJlbnQ7XHJcblxyXG5CaW5kaW5nXzM1MDJhYmU2NDc1YjQzNTI5ZDNiNDUzM2E2YWM3NGFmLlJlbGF0aXZlU291cmNlID0gUmVsYXRpdmVTb3VyY2VfYWU3MjFlMWY1NGQzNDExZjk1MWY4YzIyOTE2ZjFhOTc7XHJcblxyXG5cclxuQmluZGluZ18zNTAyYWJlNjQ3NWI0MzUyOWQzYjQ1MzNhNmFjNzRhZi5UZW1wbGF0ZU93bmVyID0gdGVtcGxhdGVJbnN0YW5jZV9lOTFiMGFlZjk5NDI0NDQyYTM4ZjZlYjg0MTljODE4NTtcclxuXHJcbnZhciBCaW5kaW5nXzAzNjU1OTg0YzlkYTQ1NmQ4NDYyMTg4MzEzZDI1NGE5ID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuQmluZGluZygpO1xyXG5CaW5kaW5nXzAzNjU1OTg0YzlkYTQ1NmQ4NDYyMTg4MzEzZDI1NGE5LlBhdGggPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuUHJvcGVydHlQYXRoKEBcIkJvcmRlclRoaWNrbmVzc1wiKTtcclxudmFyIFJlbGF0aXZlU291cmNlXzM4OWZlYzFhN2JmOTRmYWFiMzYzZDZiODc4NzVkMDJhID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuUmVsYXRpdmVTb3VyY2UoKTtcclxuUmVsYXRpdmVTb3VyY2VfMzg5ZmVjMWE3YmY5NGZhYWIzNjNkNmI4Nzg3NWQwMmEuTW9kZSA9IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuUmVsYXRpdmVTb3VyY2VNb2RlLlRlbXBsYXRlZFBhcmVudDtcclxuXHJcbkJpbmRpbmdfMDM2NTU5ODRjOWRhNDU2ZDg0NjIxODgzMTNkMjU0YTkuUmVsYXRpdmVTb3VyY2UgPSBSZWxhdGl2ZVNvdXJjZV8zODlmZWMxYTdiZjk0ZmFhYjM2M2Q2Yjg3ODc1ZDAyYTtcclxuXHJcblxyXG5CaW5kaW5nXzAzNjU1OTg0YzlkYTQ1NmQ4NDYyMTg4MzEzZDI1NGE5LlRlbXBsYXRlT3duZXIgPSB0ZW1wbGF0ZUluc3RhbmNlX2U5MWIwYWVmOTk0MjQ0NDJhMzhmNmViODQxOWM4MTg1O1xyXG5cclxudmFyIEJpbmRpbmdfN2M0NTg1ZDU2NmUyNGFjOWI0Zjc0ZTVjMjA1NzU2ZDIgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5CaW5kaW5nKCk7XHJcbkJpbmRpbmdfN2M0NTg1ZDU2NmUyNGFjOWI0Zjc0ZTVjMjA1NzU2ZDIuUGF0aCA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Qcm9wZXJ0eVBhdGgoQFwiTWFyZ2luXCIpO1xyXG52YXIgUmVsYXRpdmVTb3VyY2VfZmM4ZDIwMGE1MDIzNDFiNjgzYjQxMDhiNjRmN2U4OTcgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5SZWxhdGl2ZVNvdXJjZSgpO1xyXG5SZWxhdGl2ZVNvdXJjZV9mYzhkMjAwYTUwMjM0MWI2ODNiNDEwOGI2NGY3ZTg5Ny5Nb2RlID0gZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5SZWxhdGl2ZVNvdXJjZU1vZGUuVGVtcGxhdGVkUGFyZW50O1xyXG5cclxuQmluZGluZ183YzQ1ODVkNTY2ZTI0YWM5YjRmNzRlNWMyMDU3NTZkMi5SZWxhdGl2ZVNvdXJjZSA9IFJlbGF0aXZlU291cmNlX2ZjOGQyMDBhNTAyMzQxYjY4M2I0MTA4YjY0ZjdlODk3O1xyXG5cclxuXHJcbkJpbmRpbmdfN2M0NTg1ZDU2NmUyNGFjOWI0Zjc0ZTVjMjA1NzU2ZDIuVGVtcGxhdGVPd25lciA9IHRlbXBsYXRlSW5zdGFuY2VfZTkxYjBhZWY5OTQyNDQ0MmEzOGY2ZWI4NDE5YzgxODU7XHJcblxyXG52YXIgQmluZGluZ182ODIwZjg2NGViYzA0MWYwYmNkZGJjY2IyNGMwYWFiOSA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmcoKTtcclxuQmluZGluZ182ODIwZjg2NGViYzA0MWYwYmNkZGJjY2IyNGMwYWFiOS5QYXRoID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlByb3BlcnR5UGF0aChAXCJWaXNpYmlsaXR5XCIpO1xyXG5cclxuXHJcblxyXG5nbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmdPcGVyYXRpb25zLlNldEJpbmRpbmcoQ29udGVudFByZXNlbnRlcl9kMThjZDg0YWE5OTM0MjdkODI4N2U0ZDZhYjE5MmZjYiwgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuQ29udHJvbHMuQ29udGVudENvbnRyb2wuQ29udGVudFRlbXBsYXRlUHJvcGVydHksIEJpbmRpbmdfY2I0ODgzNmU5YTk0NGU5YzlhNzdlMGE3MTJjMDBmZTYpO1xyXG5nbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmdPcGVyYXRpb25zLlNldEJpbmRpbmcoQ29udGVudFByZXNlbnRlcl9kMThjZDg0YWE5OTM0MjdkODI4N2U0ZDZhYjE5MmZjYiwgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuQ29udHJvbHMuQ29udGVudENvbnRyb2wuQ29udGVudFByb3BlcnR5LCBCaW5kaW5nX2Y5NjVjYjE2NGRkYTQ2MmJiYTYyOTUwZjQ5YzFhNzQ2KTtcclxuZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5CaW5kaW5nT3BlcmF0aW9ucy5TZXRCaW5kaW5nKENvbnRlbnRQcmVzZW50ZXJfZDE4Y2Q4NGFhOTkzNDI3ZDgyODdlNGQ2YWIxOTJmY2IsIGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkZyYW1ld29ya0VsZW1lbnQuSGVpZ2h0UHJvcGVydHksIEJpbmRpbmdfODE0MDFmMDRiNzA2NDVhOTliNTA1OTAxYTU4ZWMyNjgpO1xyXG5nbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmdPcGVyYXRpb25zLlNldEJpbmRpbmcoQ29udGVudFByZXNlbnRlcl9kMThjZDg0YWE5OTM0MjdkODI4N2U0ZDZhYjE5MmZjYiwgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRnJhbWV3b3JrRWxlbWVudC5XaWR0aFByb3BlcnR5LCBCaW5kaW5nXzMyZDdhMzU1YjRkNjQxYTRhNDAxNGU4YTZkOWJmNWVkKTtcclxuZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5CaW5kaW5nT3BlcmF0aW9ucy5TZXRCaW5kaW5nKENvbnRlbnRQcmVzZW50ZXJfZDE4Y2Q4NGFhOTkzNDI3ZDgyODdlNGQ2YWIxOTJmY2IsIGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkZyYW1ld29ya0VsZW1lbnQuTWFyZ2luUHJvcGVydHksIEJpbmRpbmdfYzZjYzAxNTcxZWE4NGRmNThlNTVkNDZlNjA0NGQxYWUpO1xyXG5nbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmdPcGVyYXRpb25zLlNldEJpbmRpbmcoQ29udGVudFByZXNlbnRlcl9kMThjZDg0YWE5OTM0MjdkODI4N2U0ZDZhYjE5MmZjYiwgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRnJhbWV3b3JrRWxlbWVudC5Ib3Jpem9udGFsQWxpZ25tZW50UHJvcGVydHksIEJpbmRpbmdfNDQ1NWYyYzM5MjcwNDYyYWEyOTkzZTIyMzhkZDQwZmQpO1xyXG5nbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmdPcGVyYXRpb25zLlNldEJpbmRpbmcoQ29udGVudFByZXNlbnRlcl9kMThjZDg0YWE5OTM0MjdkODI4N2U0ZDZhYjE5MmZjYiwgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRnJhbWV3b3JrRWxlbWVudC5WZXJ0aWNhbEFsaWdubWVudFByb3BlcnR5LCBCaW5kaW5nXzJhMGFmMjg3YjY4YzQ3ZjY5ZTllZmViYTgxODJkNzVhKTtcclxuZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5CaW5kaW5nT3BlcmF0aW9ucy5TZXRCaW5kaW5nKENvbnRlbnRQcmVzZW50ZXJfZDE4Y2Q4NGFhOTkzNDI3ZDgyODdlNGQ2YWIxOTJmY2IsIGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlVJRWxlbWVudC5WaXNpYmlsaXR5UHJvcGVydHksIEJpbmRpbmdfMWNmNjg4NzAwMjIxNGFiMzhiOGZkYzVhNDUwZjNjZDQpO1xyXG5nbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmdPcGVyYXRpb25zLlNldEJpbmRpbmcoQm9yZGVyX2JiM2JiNjMzNTgzYTRjYzM4MjBlNzU3ZGU4ZTBkNGQ0LCBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Db250cm9scy5Cb3JkZXIuQmFja2dyb3VuZFByb3BlcnR5LCBCaW5kaW5nX2JjNDcxNzEwNjg4ODQxZTI4ZjZiNjA4MWEzOGQ2MTQ4KTtcclxuZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5CaW5kaW5nT3BlcmF0aW9ucy5TZXRCaW5kaW5nKEJvcmRlcl9jZWY0ODc0NTkyMDM0MWZkOWIxNjM2ZjMwNTNkYmQ4MSwgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuQ29udHJvbHMuQm9yZGVyLkJhY2tncm91bmRQcm9wZXJ0eSwgQmluZGluZ185MzNiODAzZDM2N2Y0NmFiOTU4MGE0ZjdhOGU3NTViMik7XHJcbmdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuQmluZGluZ09wZXJhdGlvbnMuU2V0QmluZGluZyhCb3JkZXJfY2VmNDg3NDU5MjAzNDFmZDliMTYzNmYzMDUzZGJkODEsIGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkNvbnRyb2xzLkJvcmRlci5Cb3JkZXJCcnVzaFByb3BlcnR5LCBCaW5kaW5nXzM1MDJhYmU2NDc1YjQzNTI5ZDNiNDUzM2E2YWM3NGFmKTtcclxuZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5CaW5kaW5nT3BlcmF0aW9ucy5TZXRCaW5kaW5nKEJvcmRlcl9jZWY0ODc0NTkyMDM0MWZkOWIxNjM2ZjMwNTNkYmQ4MSwgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuQ29udHJvbHMuQm9yZGVyLkJvcmRlclRoaWNrbmVzc1Byb3BlcnR5LCBCaW5kaW5nXzAzNjU1OTg0YzlkYTQ1NmQ4NDYyMTg4MzEzZDI1NGE5KTtcclxuZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5CaW5kaW5nT3BlcmF0aW9ucy5TZXRCaW5kaW5nKEJvcmRlcl9jZWY0ODc0NTkyMDM0MWZkOWIxNjM2ZjMwNTNkYmQ4MSwgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRnJhbWV3b3JrRWxlbWVudC5NYXJnaW5Qcm9wZXJ0eSwgQmluZGluZ183YzQ1ODVkNTY2ZTI0YWM5YjRmNzRlNWMyMDU3NTZkMik7XHJcbmdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuQmluZGluZ09wZXJhdGlvbnMuU2V0QmluZGluZyhCb3JkZXJfY2VmNDg3NDU5MjAzNDFmZDliMTYzNmYzMDUzZGJkODEsIGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlVJRWxlbWVudC5WaXNpYmlsaXR5UHJvcGVydHksIEJpbmRpbmdfNjgyMGY4NjRlYmMwNDFmMGJjZGRiY2NiMjRjMGFhYjkpO1xyXG5cclxuZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuTWVkaWEuQW5pbWF0aW9uLlN0b3J5Ym9hcmQuU2V0VGFyZ2V0UHJvcGVydHkoT2JqZWN0QW5pbWF0aW9uVXNpbmdLZXlGcmFtZXNfYjRiZGVkNmVhZjdjNDVmYzkxMDNlYmMxNDMzYjNiYmMsXHJcbiAgICBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuUHJvcGVydHlQYXRoKFxyXG4gICAgICAgIFwiQmFja2dyb3VuZFwiLFxyXG4gICAgICAgIFwiQmFja2dyb3VuZFwiLFxyXG4gICAgICAgIGFjY2Vzc1Zpc3VhbFN0YXRlUHJvcGVydHlfM2EzZTIwMjJjYzk1NGJhZWI4MWQ2ZjNlYzAxYzQ0OWYsXHJcbiAgICAgICAgc2V0VmlzdWFsU3RhdGVQcm9wZXJ0eV8zYTNlMjAyMmNjOTU0YmFlYjgxZDZmM2VjMDFjNDQ5ZixcclxuICAgICAgICBzZXRBbmltYXRpb25WaXN1YWxTdGF0ZVByb3BlcnR5XzNhM2UyMDIyY2M5NTRiYWViODFkNmYzZWMwMWM0NDlmLCAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICBzZXRMb2NhbFZpc3VhbFN0YXRlUHJvcGVydHlfM2EzZTIwMjJjYzk1NGJhZWI4MWQ2ZjNlYzAxYzQ0OWYsXHJcbiAgICAgICAgZ2V0VmlzdWFsU3RhdGVQcm9wZXJ0eV8zYTNlMjAyMmNjOTU0YmFlYjgxZDZmM2VjMDFjNDQ5ZikpO1xyXG5nbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5NZWRpYS5BbmltYXRpb24uU3Rvcnlib2FyZC5TZXRUYXJnZXQoT2JqZWN0QW5pbWF0aW9uVXNpbmdLZXlGcmFtZXNfYjRiZGVkNmVhZjdjNDVmYzkxMDNlYmMxNDMzYjNiYmMsIEJvcmRlcl9iYjNiYjYzMzU4M2E0Y2MzODIwZTc1N2RlOGUwZDRkNCk7XHJcblxyXG5cclxuZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuTWVkaWEuQW5pbWF0aW9uLlN0b3J5Ym9hcmQuU2V0VGFyZ2V0UHJvcGVydHkoT2JqZWN0QW5pbWF0aW9uVXNpbmdLZXlGcmFtZXNfMmMyM2YwMWIxYzEyNGE5MTkxYjlmNWZlYWVhYzExZDgsXHJcbiAgICBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuUHJvcGVydHlQYXRoKFxyXG4gICAgICAgIFwiQmFja2dyb3VuZFwiLFxyXG4gICAgICAgIFwiQmFja2dyb3VuZFwiLFxyXG4gICAgICAgIGFjY2Vzc1Zpc3VhbFN0YXRlUHJvcGVydHlfMDY0NGViMDkwNDM0NDQxODgwNTljYTk1MTdhMTVmMjIsXHJcbiAgICAgICAgc2V0VmlzdWFsU3RhdGVQcm9wZXJ0eV8wNjQ0ZWIwOTA0MzQ0NDE4ODA1OWNhOTUxN2ExNWYyMixcclxuICAgICAgICBzZXRBbmltYXRpb25WaXN1YWxTdGF0ZVByb3BlcnR5XzA2NDRlYjA5MDQzNDQ0MTg4MDU5Y2E5NTE3YTE1ZjIyLCAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICBzZXRMb2NhbFZpc3VhbFN0YXRlUHJvcGVydHlfMDY0NGViMDkwNDM0NDQxODgwNTljYTk1MTdhMTVmMjIsXHJcbiAgICAgICAgZ2V0VmlzdWFsU3RhdGVQcm9wZXJ0eV8wNjQ0ZWIwOTA0MzQ0NDE4ODA1OWNhOTUxN2ExNWYyMikpO1xyXG5nbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5NZWRpYS5BbmltYXRpb24uU3Rvcnlib2FyZC5TZXRUYXJnZXQoT2JqZWN0QW5pbWF0aW9uVXNpbmdLZXlGcmFtZXNfMmMyM2YwMWIxYzEyNGE5MTkxYjlmNWZlYWVhYzExZDgsIEJvcmRlcl9iYjNiYjYzMzU4M2E0Y2MzODIwZTc1N2RlOGUwZDRkNCk7XHJcblxyXG5cclxuZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuTWVkaWEuQW5pbWF0aW9uLlN0b3J5Ym9hcmQuU2V0VGFyZ2V0UHJvcGVydHkoT2JqZWN0QW5pbWF0aW9uVXNpbmdLZXlGcmFtZXNfNDBkYmEwYjAzNzk3NGQ2MmJlMWI1YzJmNjc4NGUyYTEsXHJcbiAgICBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuUHJvcGVydHlQYXRoKFxyXG4gICAgICAgIFwiQmFja2dyb3VuZFwiLFxyXG4gICAgICAgIFwiQmFja2dyb3VuZFwiLFxyXG4gICAgICAgIGFjY2Vzc1Zpc3VhbFN0YXRlUHJvcGVydHlfMDM3MTQwM2MwMDA4NDdhZDg5MzY4MzZlNWNlNDBjZjMsXHJcbiAgICAgICAgc2V0VmlzdWFsU3RhdGVQcm9wZXJ0eV8wMzcxNDAzYzAwMDg0N2FkODkzNjgzNmU1Y2U0MGNmMyxcclxuICAgICAgICBzZXRBbmltYXRpb25WaXN1YWxTdGF0ZVByb3BlcnR5XzAzNzE0MDNjMDAwODQ3YWQ4OTM2ODM2ZTVjZTQwY2YzLCAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICBzZXRMb2NhbFZpc3VhbFN0YXRlUHJvcGVydHlfMDM3MTQwM2MwMDA4NDdhZDg5MzY4MzZlNWNlNDBjZjMsXHJcbiAgICAgICAgZ2V0VmlzdWFsU3RhdGVQcm9wZXJ0eV8wMzcxNDAzYzAwMDg0N2FkODkzNjgzNmU1Y2U0MGNmMykpO1xyXG5nbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5NZWRpYS5BbmltYXRpb24uU3Rvcnlib2FyZC5TZXRUYXJnZXQoT2JqZWN0QW5pbWF0aW9uVXNpbmdLZXlGcmFtZXNfNDBkYmEwYjAzNzk3NGQ2MmJlMWI1YzJmNjc4NGUyYTEsIEJvcmRlcl9iYjNiYjYzMzU4M2E0Y2MzODIwZTc1N2RlOGUwZDRkNCk7XHJcblxyXG50ZW1wbGF0ZUluc3RhbmNlX2U5MWIwYWVmOTk0MjQ0NDJhMzhmNmViODQxOWM4MTg1LlRlbXBsYXRlQ29udGVudCA9IEJvcmRlcl9jZWY0ODc0NTkyMDM0MWZkOWIxNjM2ZjMwNTNkYmQ4MTtcclxucmV0dXJuIHRlbXBsYXRlSW5zdGFuY2VfZTkxYjBhZWY5OTQyNDQ0MmEzOGY2ZWI4NDE5YzgxODU7XHJcbn0pKTtcclxuXHJcblNldHRlcl82ZTA3ZmU3MjgzZGE0MTBiYjY1ZTBhZjE1NmU1Mjc2OC5WYWx1ZSA9IENvbnRyb2xUZW1wbGF0ZV84YWZjMjgxNDc0N2I0Njc3YTI2ZDQ1Njc5YzNkNjEyYztcclxuXHJcblxyXG5TdHlsZV82YTE3MzBjMmIwNzg0NmM5YjYwNDFjY2UyMmI0ZWFmYS5TZXR0ZXJzLkFkZChTZXR0ZXJfZDNjZDdiYzgyYmE3NGMyNDkwZTI5MzI4NDU4ZGZlZmIpO1xyXG5TdHlsZV82YTE3MzBjMmIwNzg0NmM5YjYwNDFjY2UyMmI0ZWFmYS5TZXR0ZXJzLkFkZChTZXR0ZXJfYWIyODhkNDY4ZWE0NGRmODkyYWUwNjU1MjQ0M2ZiYWIpO1xyXG5TdHlsZV82YTE3MzBjMmIwNzg0NmM5YjYwNDFjY2UyMmI0ZWFmYS5TZXR0ZXJzLkFkZChTZXR0ZXJfMmVjMWIzMTZjMzFlNDAyNTliNGI1YTE5ODQ3NjlhNDcpO1xyXG5TdHlsZV82YTE3MzBjMmIwNzg0NmM5YjYwNDFjY2UyMmI0ZWFmYS5TZXR0ZXJzLkFkZChTZXR0ZXJfYzI4NjkyY2Q3MTk5NGRjMDllYzZkYTJkMzYzYmFiZjcpO1xyXG5TdHlsZV82YTE3MzBjMmIwNzg0NmM5YjYwNDFjY2UyMmI0ZWFmYS5TZXR0ZXJzLkFkZChTZXR0ZXJfZmI4NGQyZTg0MmQ1NDU2NDhlYWIyZjQ2Mjc1ZTU1YmIpO1xyXG5TdHlsZV82YTE3MzBjMmIwNzg0NmM5YjYwNDFjY2UyMmI0ZWFmYS5TZXR0ZXJzLkFkZChTZXR0ZXJfOTI5MGVjNzM4ZDA5NDI0YjlmNTkxMDc4ZmE1YTI0NmMpO1xyXG5TdHlsZV82YTE3MzBjMmIwNzg0NmM5YjYwNDFjY2UyMmI0ZWFmYS5TZXR0ZXJzLkFkZChTZXR0ZXJfY2UzM2EzZTdjYzY1NDE5ZDg5YThkYmI0MmY2ODhhMjkpO1xyXG5TdHlsZV82YTE3MzBjMmIwNzg0NmM5YjYwNDFjY2UyMmI0ZWFmYS5TZXR0ZXJzLkFkZChTZXR0ZXJfNmUwN2ZlNzI4M2RhNDEwYmI2NWUwYWYxNTZlNTI3NjgpO1xyXG5cclxuXHJcblJlc291cmNlRGljdGlvbmFyeV9lMjk1MmZiYjZhYmQ0MmIxYjk2ZmQ3YTlmOWUwMDg2ZFtcIkludENvbnZlcnRlclwiXSA9IEludENvbnZlcnRlcl80ZjBmYzAyOTA4MjY0MjYwOWU5MWVjNGRjMjQxYTQ3NDtcclxuUmVzb3VyY2VEaWN0aW9uYXJ5X2UyOTUyZmJiNmFiZDQyYjFiOTZmZDdhOWY5ZTAwODZkW1wiRGVjQ29udmVydGVyXCJdID0gRGVjQ29udmVydGVyXzZkYjAwNmNiNTQ0YTQwMDM4NzZkMzg5ZjE0YmRmYWU2O1xyXG5SZXNvdXJjZURpY3Rpb25hcnlfZTI5NTJmYmI2YWJkNDJiMWI5NmZkN2E5ZjllMDA4NmRbXCJUb1BvbHlMaW5lQ29udmVydGVyXCJdID0gVG9Qb2x5TGluZUNvbnZlcnRlcl9jMTRiOTVjMjU3OWM0ZTUyOTljZmFmMGM3ZWRjZWExOTtcclxuUmVzb3VyY2VEaWN0aW9uYXJ5X2UyOTUyZmJiNmFiZDQyYjFiOTZmZDdhOWY5ZTAwODZkW1wiVG9Qb2ludHNDb252ZXJ0ZXJcIl0gPSBUb1BvaW50c0NvbnZlcnRlcl9jZTZkOTM4ZTEwNDY0NDQzYTQwYjYwOTZjZWUwNzg2YztcclxuUmVzb3VyY2VEaWN0aW9uYXJ5X2UyOTUyZmJiNmFiZDQyYjFiOTZmZDdhOWY5ZTAwODZkW1wiVG9MaW5lc0NvbnZlcnRlclwiXSA9IFRvTGluZXNDb252ZXJ0ZXJfMzFhODM0MWVlMTI1NGU5NjhiZGIxYTg2YWQzMzJiYzk7XHJcblJlc291cmNlRGljdGlvbmFyeV9lMjk1MmZiYjZhYmQ0MmIxYjk2ZmQ3YTlmOWUwMDg2ZFtcIkFQTENvbG9yQ29udmVydGVyXCJdID0gQVBMQ29sb3JDb252ZXJ0ZXJfZTZiNTYzM2I1YzQyNDRhNDlkYWJhODFiMDk4YTMxZjc7XHJcblJlc291cmNlRGljdGlvbmFyeV9lMjk1MmZiYjZhYmQ0MmIxYjk2ZmQ3YTlmOWUwMDg2ZFtcIkFQTENvbG9yQ1NTQ29udmVydGVyXCJdID0gQVBMQ29sb3JDU1NDb252ZXJ0ZXJfMzBiOTczODEyY2YyNDgzM2EwYTk3ZDI2ZjA3ZGUyM2Y7XHJcblJlc291cmNlRGljdGlvbmFyeV9lMjk1MmZiYjZhYmQ0MmIxYjk2ZmQ3YTlmOWUwMDg2ZFtcIkFQTE11bHRpQ29sb3JDb252ZXJ0ZXJcIl0gPSBBUExNdWx0aUNvbG9yQ29udmVydGVyXzFhZjkwNDVkOTBhMTQxODc4OGIyYjQ5NDFiZTZmZmYwO1xyXG5SZXNvdXJjZURpY3Rpb25hcnlfZTI5NTJmYmI2YWJkNDJiMWI5NmZkN2E5ZjllMDA4NmRbXCJBUExNdWx0aUNvbG9yQ1NTQ29udmVydGVyXCJdID0gQVBMTXVsdGlDb2xvckNTU0NvbnZlcnRlcl8xYzc3ODg0ZDA4ZmQ0MGZmODNlYWVhNzA2NDIwMjBjNTtcclxuUmVzb3VyY2VEaWN0aW9uYXJ5X2UyOTUyZmJiNmFiZDQyYjFiOTZmZDdhOWY5ZTAwODZkW1wiSW5kZXhJbnQzMkNvbnZlcnRlclwiXSA9IEluZGV4SW50MzJDb252ZXJ0ZXJfODkzMzc4MWVmOTc0NDE1NGEwZjBlMTJjMzhjYzE0ZTk7XHJcblJlc291cmNlRGljdGlvbmFyeV9lMjk1MmZiYjZhYmQ0MmIxYjk2ZmQ3YTlmOWUwMDg2ZFtcIkluZGV4RG91YmxlQ29udmVydGVyXCJdID0gSW5kZXhEb3VibGVDb252ZXJ0ZXJfNjU3NTM3OWFkMzlkNGExNmFkMDljNDJkZDM3NjFmZTM7XHJcblJlc291cmNlRGljdGlvbmFyeV9lMjk1MmZiYjZhYmQ0MmIxYjk2ZmQ3YTlmOWUwMDg2ZFtcIkluZGV4U3RyaW5nQ29udmVydGVyXCJdID0gSW5kZXhTdHJpbmdDb252ZXJ0ZXJfNWUyYzUzNmM0OWQzNGZjYzliMDFmMTA0NDE2NWQ1NmM7XHJcblJlc291cmNlRGljdGlvbmFyeV9lMjk1MmZiYjZhYmQ0MmIxYjk2ZmQ3YTlmOWUwMDg2ZFtcIkluZGV4QVBMQ29sb3JDb252ZXJ0ZXJcIl0gPSBJbmRleEFQTENvbG9yQ29udmVydGVyX2M5NzZkMmVkYWY1YjRhMTJiYWZhN2FkZmM1NzM3MWI0O1xyXG5SZXNvdXJjZURpY3Rpb25hcnlfZTI5NTJmYmI2YWJkNDJiMWI5NmZkN2E5ZjllMDA4NmRbXCJJbmRleEFQTENvbG91ckNvbnZlcnRlclwiXSA9IEluZGV4QVBMQ29sb3VyQ29udmVydGVyX2Y2YWQzNTEyMTBjZTQxZWQ5YTIxMjIwM2Q4NmNlZjE2O1xyXG5SZXNvdXJjZURpY3Rpb25hcnlfZTI5NTJmYmI2YWJkNDJiMWI5NmZkN2E5ZjllMDA4NmRbXCJNYXRoc0lDb252ZXJ0ZXJcIl0gPSBNYXRoc0lDb252ZXJ0ZXJfMDI3YmE1MWE5MWQ4NDQ2NjlmMmI2ZGQ0ZmUxY2E5YTk7XHJcblJlc291cmNlRGljdGlvbmFyeV9lMjk1MmZiYjZhYmQ0MmIxYjk2ZmQ3YTlmOWUwMDg2ZFtcIk1hdGhzRENvbnZlcnRlclwiXSA9IE1hdGhzRENvbnZlcnRlcl9kYmI2NjRkYWExNjM0NjQ3OWJkMGE5NGM0ZjFiYjU4ZTtcclxuUmVzb3VyY2VEaWN0aW9uYXJ5X2UyOTUyZmJiNmFiZDQyYjFiOTZmZDdhOWY5ZTAwODZkW1wiTWF0aElDb252ZXJ0ZXJcIl0gPSBNYXRoSUNvbnZlcnRlcl82MTM1Mzk4NzZiYjE0ZTEzOTgyYjUyNmE3YTRiMWM2ZDtcclxuUmVzb3VyY2VEaWN0aW9uYXJ5X2UyOTUyZmJiNmFiZDQyYjFiOTZmZDdhOWY5ZTAwODZkW1wiTWF0aERDb252ZXJ0ZXJcIl0gPSBNYXRoRENvbnZlcnRlcl8wOTA0M2M5MTgzOTI0YTFkOGNiOWJiMmZmZGFjNWFkYztcclxuUmVzb3VyY2VEaWN0aW9uYXJ5X2UyOTUyZmJiNmFiZDQyYjFiOTZmZDdhOWY5ZTAwODZkW1wiQXBwbGljYXRpb25cIl0gPSBTdHJpbmdfYzFhZTM0ZDYwYTQzNDkzZDhiOTI5ZmQ2OTMwZGExMmE7XHJcblJlc291cmNlRGljdGlvbmFyeV9lMjk1MmZiYjZhYmQ0MmIxYjk2ZmQ3YTlmOWUwMDg2ZFtcIk93bmVyXCJdID0gU3RyaW5nXzM4MzBmNzZiNGYzYzRiOWFhZTc2OGQyZWU2ZThhYjY5O1xyXG5SZXNvdXJjZURpY3Rpb25hcnlfZTI5NTJmYmI2YWJkNDJiMWI5NmZkN2E5ZjllMDA4NmRbXCJDb21wYW55XCJdID0gU3RyaW5nX2ZiYTU1ZTI3YjA5MDRlMmJiNGZlMTgxNGRjNzZlNWVjO1xyXG5SZXNvdXJjZURpY3Rpb25hcnlfZTI5NTJmYmI2YWJkNDJiMWI5NmZkN2E5ZjllMDA4NmRbXCJOYW1lXCJdID0gU3RyaW5nX2Q3MGNkMWFjOTAzMDQ1ZjY5NTE4NjdlNDYzMWM0ODlkO1xyXG5SZXNvdXJjZURpY3Rpb25hcnlfZTI5NTJmYmI2YWJkNDJiMWI5NmZkN2E5ZjllMDA4NmRbXCJUaXRsZVwiXSA9IFN0cmluZ184M2RkNmIzMmM0MWM0NWE0OGJmN2FlYmZkNTcwMDI3MDtcclxuUmVzb3VyY2VEaWN0aW9uYXJ5X2UyOTUyZmJiNmFiZDQyYjFiOTZmZDdhOWY5ZTAwODZkW1wiRmF2SWNvblwiXSA9IFN0cmluZ19hOTg0MTk0ZDNlNTE0YTA5YmI4MWNhOGEwMGVlNzViZDtcclxuUmVzb3VyY2VEaWN0aW9uYXJ5X2UyOTUyZmJiNmFiZDQyYjFiOTZmZDdhOWY5ZTAwODZkW1wiUG9ydFwiXSA9IFN0cmluZ183Y2QxNjc2OTIyN2E0ODBjYmQ4YjRiNWQyNmM3MzZlYjtcclxuUmVzb3VyY2VEaWN0aW9uYXJ5X2UyOTUyZmJiNmFiZDQyYjFiOTZmZDdhOWY5ZTAwODZkW1wiTWFpblwiXSA9IFN0cmluZ19lNDVkYzUyZThlMWM0OGU4YTI3MjNjMzQ3OGFiZjdiYztcclxuUmVzb3VyY2VEaWN0aW9uYXJ5X2UyOTUyZmJiNmFiZDQyYjFiOTZmZDdhOWY5ZTAwODZkW1wiQmFzZVwiXSA9IFN0cmluZ18yMGEwOTA4NDIwYTg0MDhjOWJmM2UyY2UwODQxZjE3OTtcclxuUmVzb3VyY2VEaWN0aW9uYXJ5X2UyOTUyZmJiNmFiZDQyYjFiOTZmZDdhOWY5ZTAwODZkW1wiQ29ubmVjdGlvblR5cGVcIl0gPSBTdHJpbmdfNjdhNjA2N2RmMWU2NDUwMzg5NWJiYTVlYmUzYzMyYTQ7XHJcblJlc291cmNlRGljdGlvbmFyeV9lMjk1MmZiYjZhYmQ0MmIxYjk2ZmQ3YTlmOWUwMDg2ZFtcIk5hbWVzcGFjZVwiXSA9IFN0cmluZ19hYjgzMTQyOTMwM2Q0MGZjODIzYmJhNDEwMTE4NjI0MjtcclxuUmVzb3VyY2VEaWN0aW9uYXJ5X2UyOTUyZmJiNmFiZDQyYjFiOTZmZDdhOWY5ZTAwODZkW1wiQVBMRm9ybVN0eWxlXCJdID0gU3R5bGVfYjc4YTNkZTFlMWM4NGVhNTg2M2RjNWI0NjNiNzFhZDM7XHJcblJlc291cmNlRGljdGlvbmFyeV9lMjk1MmZiYjZhYmQ0MmIxYjk2ZmQ3YTlmOWUwMDg2ZFtcIkJ1dHRvblN0eWxlMVwiXSA9IFN0eWxlXzZhMTczMGMyYjA3ODQ2YzliNjA0MWNjZTIyYjRlYWZhO1xyXG5cclxudGhpcy5SZXNvdXJjZXMgPSBSZXNvdXJjZURpY3Rpb25hcnlfZTI5NTJmYmI2YWJkNDJiMWI5NmZkN2E5ZjllMDA4NmQ7XHJcblxyXG5cclxuXHJcblxyXG5cclxuXHJcbiAgICBcclxuICAgICAgICB9XHJcblxyXG5cclxuXHJcbnB1YmxpYyBnbG9iYWw6OlN5c3RlbS5Db2xsZWN0aW9ucy5HZW5lcmljLklFbnVtZXJhYmxlPGdsb2JhbDo6U3lzdGVtLlR1cGxlPGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRlcGVuZGVuY3lPYmplY3QsIGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRlcGVuZGVuY3lQcm9wZXJ0eSwgaW50Pz4+IGFjY2Vzc1Zpc3VhbFN0YXRlUHJvcGVydHlfMGVmZWIxZWU5MWJhNGU3ZmI0YTYwNzE4Mzc3OGFiZTkgKGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRlcGVuZGVuY3lPYmplY3Qgcm9vdFRhcmdldE9iamVjdEluc3RhbmNlKVxyXG57XHJcbiAgXHJcbnlpZWxkIGJyZWFrO1xyXG59XHJcblxyXG5cclxucHVibGljIHZvaWQgc2V0VmlzdWFsU3RhdGVQcm9wZXJ0eV8wZWZlYjFlZTkxYmE0ZTdmYjRhNjA3MTgzNzc4YWJlOSAoZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGVwZW5kZW5jeU9iamVjdCBmaW5hbFRhcmdldEluc3RhbmNlLCBvYmplY3QgdmFsdWUpXHJcbntcclxuICBcclxuZ2xvYmFsOjpTeXN0ZW0uVHlwZSBmaW5hbFRhcmdldEluc3RhbmNlVHlwZSA9IGZpbmFsVGFyZ2V0SW5zdGFuY2UuR2V0VHlwZSgpO1xyXG5nbG9iYWw6OlN5c3RlbS5UeXBlIHByb3BlcnR5RGVjbGFyaW5nVHlwZSA9IGZpbmFsVGFyZ2V0SW5zdGFuY2VUeXBlLkdldFByb3BlcnR5KFwiQmFja2dyb3VuZFwiKS5EZWNsYXJpbmdUeXBlO1xyXG5nbG9iYWw6OlN5c3RlbS5SZWZsZWN0aW9uLkZpZWxkSW5mbyBwcm9wZXJ0eUZpZWxkID0gcHJvcGVydHlEZWNsYXJpbmdUeXBlLkdldEZpZWxkKFwiQmFja2dyb3VuZFByb3BlcnR5XCIpO1xyXG5nbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EZXBlbmRlbmN5UHJvcGVydHkgcHJvcGVydHkgPSAoZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGVwZW5kZW5jeVByb3BlcnR5KXByb3BlcnR5RmllbGQuR2V0VmFsdWUobnVsbCk7XHJcblxyXG4gIChmaW5hbFRhcmdldEluc3RhbmNlKS5TZXRWaXN1YWxTdGF0ZVZhbHVlKHByb3BlcnR5LCB2YWx1ZSk7XHJcbn1cclxuXHJcblxyXG5wdWJsaWMgdm9pZCBzZXRBbmltYXRpb25WaXN1YWxTdGF0ZVByb3BlcnR5XzBlZmViMWVlOTFiYTRlN2ZiNGE2MDcxODM3NzhhYmU5IChnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EZXBlbmRlbmN5T2JqZWN0IGZpbmFsVGFyZ2V0SW5zdGFuY2UsIG9iamVjdCB2YWx1ZSlcclxue1xyXG4gIFxyXG5nbG9iYWw6OlN5c3RlbS5UeXBlIGZpbmFsVGFyZ2V0SW5zdGFuY2VUeXBlID0gZmluYWxUYXJnZXRJbnN0YW5jZS5HZXRUeXBlKCk7XHJcbmdsb2JhbDo6U3lzdGVtLlR5cGUgcHJvcGVydHlEZWNsYXJpbmdUeXBlID0gZmluYWxUYXJnZXRJbnN0YW5jZVR5cGUuR2V0UHJvcGVydHkoXCJCYWNrZ3JvdW5kXCIpLkRlY2xhcmluZ1R5cGU7XHJcbmdsb2JhbDo6U3lzdGVtLlJlZmxlY3Rpb24uRmllbGRJbmZvIHByb3BlcnR5RmllbGQgPSBwcm9wZXJ0eURlY2xhcmluZ1R5cGUuR2V0RmllbGQoXCJCYWNrZ3JvdW5kUHJvcGVydHlcIik7XHJcbmdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRlcGVuZGVuY3lQcm9wZXJ0eSBwcm9wZXJ0eSA9IChnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EZXBlbmRlbmN5UHJvcGVydHkpcHJvcGVydHlGaWVsZC5HZXRWYWx1ZShudWxsKTtcclxuXHJcbiAgKGZpbmFsVGFyZ2V0SW5zdGFuY2UpLlNldEFuaW1hdGlvblZhbHVlKHByb3BlcnR5LCB2YWx1ZSk7XHJcbn1cclxuXHJcblxyXG5wdWJsaWMgdm9pZCBzZXRMb2NhbFZpc3VhbFN0YXRlUHJvcGVydHlfMGVmZWIxZWU5MWJhNGU3ZmI0YTYwNzE4Mzc3OGFiZTkgKGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRlcGVuZGVuY3lPYmplY3QgZmluYWxUYXJnZXRJbnN0YW5jZSwgb2JqZWN0IHZhbHVlKVxyXG57XHJcbiAgXHJcbmdsb2JhbDo6U3lzdGVtLlR5cGUgZmluYWxUYXJnZXRJbnN0YW5jZVR5cGUgPSBmaW5hbFRhcmdldEluc3RhbmNlLkdldFR5cGUoKTtcclxuZ2xvYmFsOjpTeXN0ZW0uVHlwZSBwcm9wZXJ0eURlY2xhcmluZ1R5cGUgPSBmaW5hbFRhcmdldEluc3RhbmNlVHlwZS5HZXRQcm9wZXJ0eShcIkJhY2tncm91bmRcIikuRGVjbGFyaW5nVHlwZTtcclxuZ2xvYmFsOjpTeXN0ZW0uUmVmbGVjdGlvbi5GaWVsZEluZm8gcHJvcGVydHlGaWVsZCA9IHByb3BlcnR5RGVjbGFyaW5nVHlwZS5HZXRGaWVsZChcIkJhY2tncm91bmRQcm9wZXJ0eVwiKTtcclxuZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGVwZW5kZW5jeVByb3BlcnR5IHByb3BlcnR5ID0gKGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRlcGVuZGVuY3lQcm9wZXJ0eSlwcm9wZXJ0eUZpZWxkLkdldFZhbHVlKG51bGwpO1xyXG5cclxuICAoZmluYWxUYXJnZXRJbnN0YW5jZSkuU2V0Q3VycmVudFZhbHVlKHByb3BlcnR5LCB2YWx1ZSk7XHJcbn1cclxuXHJcblxyXG5wdWJsaWMgZ2xvYmFsOjpTeXN0ZW0uT2JqZWN0IGdldFZpc3VhbFN0YXRlUHJvcGVydHlfMGVmZWIxZWU5MWJhNGU3ZmI0YTYwNzE4Mzc3OGFiZTkgKGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRlcGVuZGVuY3lPYmplY3QgZmluYWxUYXJnZXRJbnN0YW5jZSlcclxue1xyXG4gIFxyXG5nbG9iYWw6OlN5c3RlbS5UeXBlIGZpbmFsVGFyZ2V0SW5zdGFuY2VUeXBlID0gZmluYWxUYXJnZXRJbnN0YW5jZS5HZXRUeXBlKCk7XHJcbmdsb2JhbDo6U3lzdGVtLlR5cGUgcHJvcGVydHlEZWNsYXJpbmdUeXBlID0gZmluYWxUYXJnZXRJbnN0YW5jZVR5cGUuR2V0UHJvcGVydHkoXCJCYWNrZ3JvdW5kXCIpLkRlY2xhcmluZ1R5cGU7XHJcbmdsb2JhbDo6U3lzdGVtLlJlZmxlY3Rpb24uRmllbGRJbmZvIHByb3BlcnR5RmllbGQgPSBwcm9wZXJ0eURlY2xhcmluZ1R5cGUuR2V0RmllbGQoXCJCYWNrZ3JvdW5kUHJvcGVydHlcIik7XHJcbmdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRlcGVuZGVuY3lQcm9wZXJ0eSBwcm9wZXJ0eSA9IChnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EZXBlbmRlbmN5UHJvcGVydHkpcHJvcGVydHlGaWVsZC5HZXRWYWx1ZShudWxsKTtcclxuXHJcbiAgcmV0dXJuIGZpbmFsVGFyZ2V0SW5zdGFuY2UuR2V0VmlzdWFsU3RhdGVWYWx1ZShwcm9wZXJ0eSk7XHJcbn1cclxuXHJcblxyXG5wdWJsaWMgZ2xvYmFsOjpTeXN0ZW0uQ29sbGVjdGlvbnMuR2VuZXJpYy5JRW51bWVyYWJsZTxnbG9iYWw6OlN5c3RlbS5UdXBsZTxnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EZXBlbmRlbmN5T2JqZWN0LCBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EZXBlbmRlbmN5UHJvcGVydHksIGludD8+PiBhY2Nlc3NWaXN1YWxTdGF0ZVByb3BlcnR5XzQzMjEyOGNkMTA0YjQ2ZWQ4ZjdlOGQ0NDE3MTU2MzliIChnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EZXBlbmRlbmN5T2JqZWN0IHJvb3RUYXJnZXRPYmplY3RJbnN0YW5jZSlcclxue1xyXG4gIFxyXG55aWVsZCBicmVhaztcclxufVxyXG5cclxuXHJcbnB1YmxpYyB2b2lkIHNldFZpc3VhbFN0YXRlUHJvcGVydHlfNDMyMTI4Y2QxMDRiNDZlZDhmN2U4ZDQ0MTcxNTYzOWIgKGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRlcGVuZGVuY3lPYmplY3QgZmluYWxUYXJnZXRJbnN0YW5jZSwgb2JqZWN0IHZhbHVlKVxyXG57XHJcbiAgXHJcbmdsb2JhbDo6U3lzdGVtLlR5cGUgZmluYWxUYXJnZXRJbnN0YW5jZVR5cGUgPSBmaW5hbFRhcmdldEluc3RhbmNlLkdldFR5cGUoKTtcclxuZ2xvYmFsOjpTeXN0ZW0uVHlwZSBwcm9wZXJ0eURlY2xhcmluZ1R5cGUgPSBmaW5hbFRhcmdldEluc3RhbmNlVHlwZS5HZXRQcm9wZXJ0eShcIklzSGl0VGVzdFZpc2libGVcIikuRGVjbGFyaW5nVHlwZTtcclxuZ2xvYmFsOjpTeXN0ZW0uUmVmbGVjdGlvbi5GaWVsZEluZm8gcHJvcGVydHlGaWVsZCA9IHByb3BlcnR5RGVjbGFyaW5nVHlwZS5HZXRGaWVsZChcIklzSGl0VGVzdFZpc2libGVQcm9wZXJ0eVwiKTtcclxuZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGVwZW5kZW5jeVByb3BlcnR5IHByb3BlcnR5ID0gKGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRlcGVuZGVuY3lQcm9wZXJ0eSlwcm9wZXJ0eUZpZWxkLkdldFZhbHVlKG51bGwpO1xyXG5cclxuICAoZmluYWxUYXJnZXRJbnN0YW5jZSkuU2V0VmlzdWFsU3RhdGVWYWx1ZShwcm9wZXJ0eSwgdmFsdWUpO1xyXG59XHJcblxyXG5cclxucHVibGljIHZvaWQgc2V0QW5pbWF0aW9uVmlzdWFsU3RhdGVQcm9wZXJ0eV80MzIxMjhjZDEwNGI0NmVkOGY3ZThkNDQxNzE1NjM5YiAoZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGVwZW5kZW5jeU9iamVjdCBmaW5hbFRhcmdldEluc3RhbmNlLCBvYmplY3QgdmFsdWUpXHJcbntcclxuICBcclxuZ2xvYmFsOjpTeXN0ZW0uVHlwZSBmaW5hbFRhcmdldEluc3RhbmNlVHlwZSA9IGZpbmFsVGFyZ2V0SW5zdGFuY2UuR2V0VHlwZSgpO1xyXG5nbG9iYWw6OlN5c3RlbS5UeXBlIHByb3BlcnR5RGVjbGFyaW5nVHlwZSA9IGZpbmFsVGFyZ2V0SW5zdGFuY2VUeXBlLkdldFByb3BlcnR5KFwiSXNIaXRUZXN0VmlzaWJsZVwiKS5EZWNsYXJpbmdUeXBlO1xyXG5nbG9iYWw6OlN5c3RlbS5SZWZsZWN0aW9uLkZpZWxkSW5mbyBwcm9wZXJ0eUZpZWxkID0gcHJvcGVydHlEZWNsYXJpbmdUeXBlLkdldEZpZWxkKFwiSXNIaXRUZXN0VmlzaWJsZVByb3BlcnR5XCIpO1xyXG5nbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EZXBlbmRlbmN5UHJvcGVydHkgcHJvcGVydHkgPSAoZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGVwZW5kZW5jeVByb3BlcnR5KXByb3BlcnR5RmllbGQuR2V0VmFsdWUobnVsbCk7XHJcblxyXG4gIChmaW5hbFRhcmdldEluc3RhbmNlKS5TZXRBbmltYXRpb25WYWx1ZShwcm9wZXJ0eSwgdmFsdWUpO1xyXG59XHJcblxyXG5cclxucHVibGljIHZvaWQgc2V0TG9jYWxWaXN1YWxTdGF0ZVByb3BlcnR5XzQzMjEyOGNkMTA0YjQ2ZWQ4ZjdlOGQ0NDE3MTU2MzliIChnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EZXBlbmRlbmN5T2JqZWN0IGZpbmFsVGFyZ2V0SW5zdGFuY2UsIG9iamVjdCB2YWx1ZSlcclxue1xyXG4gIFxyXG5nbG9iYWw6OlN5c3RlbS5UeXBlIGZpbmFsVGFyZ2V0SW5zdGFuY2VUeXBlID0gZmluYWxUYXJnZXRJbnN0YW5jZS5HZXRUeXBlKCk7XHJcbmdsb2JhbDo6U3lzdGVtLlR5cGUgcHJvcGVydHlEZWNsYXJpbmdUeXBlID0gZmluYWxUYXJnZXRJbnN0YW5jZVR5cGUuR2V0UHJvcGVydHkoXCJJc0hpdFRlc3RWaXNpYmxlXCIpLkRlY2xhcmluZ1R5cGU7XHJcbmdsb2JhbDo6U3lzdGVtLlJlZmxlY3Rpb24uRmllbGRJbmZvIHByb3BlcnR5RmllbGQgPSBwcm9wZXJ0eURlY2xhcmluZ1R5cGUuR2V0RmllbGQoXCJJc0hpdFRlc3RWaXNpYmxlUHJvcGVydHlcIik7XHJcbmdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRlcGVuZGVuY3lQcm9wZXJ0eSBwcm9wZXJ0eSA9IChnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EZXBlbmRlbmN5UHJvcGVydHkpcHJvcGVydHlGaWVsZC5HZXRWYWx1ZShudWxsKTtcclxuXHJcbiAgKGZpbmFsVGFyZ2V0SW5zdGFuY2UpLlNldEN1cnJlbnRWYWx1ZShwcm9wZXJ0eSwgdmFsdWUpO1xyXG59XHJcblxyXG5cclxucHVibGljIGdsb2JhbDo6U3lzdGVtLk9iamVjdCBnZXRWaXN1YWxTdGF0ZVByb3BlcnR5XzQzMjEyOGNkMTA0YjQ2ZWQ4ZjdlOGQ0NDE3MTU2MzliIChnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EZXBlbmRlbmN5T2JqZWN0IGZpbmFsVGFyZ2V0SW5zdGFuY2UpXHJcbntcclxuICBcclxuZ2xvYmFsOjpTeXN0ZW0uVHlwZSBmaW5hbFRhcmdldEluc3RhbmNlVHlwZSA9IGZpbmFsVGFyZ2V0SW5zdGFuY2UuR2V0VHlwZSgpO1xyXG5nbG9iYWw6OlN5c3RlbS5UeXBlIHByb3BlcnR5RGVjbGFyaW5nVHlwZSA9IGZpbmFsVGFyZ2V0SW5zdGFuY2VUeXBlLkdldFByb3BlcnR5KFwiSXNIaXRUZXN0VmlzaWJsZVwiKS5EZWNsYXJpbmdUeXBlO1xyXG5nbG9iYWw6OlN5c3RlbS5SZWZsZWN0aW9uLkZpZWxkSW5mbyBwcm9wZXJ0eUZpZWxkID0gcHJvcGVydHlEZWNsYXJpbmdUeXBlLkdldEZpZWxkKFwiSXNIaXRUZXN0VmlzaWJsZVByb3BlcnR5XCIpO1xyXG5nbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EZXBlbmRlbmN5UHJvcGVydHkgcHJvcGVydHkgPSAoZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGVwZW5kZW5jeVByb3BlcnR5KXByb3BlcnR5RmllbGQuR2V0VmFsdWUobnVsbCk7XHJcblxyXG4gIHJldHVybiBmaW5hbFRhcmdldEluc3RhbmNlLkdldFZpc3VhbFN0YXRlVmFsdWUocHJvcGVydHkpO1xyXG59XHJcblxyXG5cclxucHVibGljIGdsb2JhbDo6U3lzdGVtLkNvbGxlY3Rpb25zLkdlbmVyaWMuSUVudW1lcmFibGU8Z2xvYmFsOjpTeXN0ZW0uVHVwbGU8Z2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGVwZW5kZW5jeU9iamVjdCwgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGVwZW5kZW5jeVByb3BlcnR5LCBpbnQ/Pj4gYWNjZXNzVmlzdWFsU3RhdGVQcm9wZXJ0eV8zYTNlMjAyMmNjOTU0YmFlYjgxZDZmM2VjMDFjNDQ5ZiAoZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGVwZW5kZW5jeU9iamVjdCByb290VGFyZ2V0T2JqZWN0SW5zdGFuY2UpXHJcbntcclxuICBcclxueWllbGQgYnJlYWs7XHJcbn1cclxuXHJcblxyXG5wdWJsaWMgdm9pZCBzZXRWaXN1YWxTdGF0ZVByb3BlcnR5XzNhM2UyMDIyY2M5NTRiYWViODFkNmYzZWMwMWM0NDlmIChnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EZXBlbmRlbmN5T2JqZWN0IGZpbmFsVGFyZ2V0SW5zdGFuY2UsIG9iamVjdCB2YWx1ZSlcclxue1xyXG4gIFxyXG5nbG9iYWw6OlN5c3RlbS5UeXBlIGZpbmFsVGFyZ2V0SW5zdGFuY2VUeXBlID0gZmluYWxUYXJnZXRJbnN0YW5jZS5HZXRUeXBlKCk7XHJcbmdsb2JhbDo6U3lzdGVtLlR5cGUgcHJvcGVydHlEZWNsYXJpbmdUeXBlID0gZmluYWxUYXJnZXRJbnN0YW5jZVR5cGUuR2V0UHJvcGVydHkoXCJCYWNrZ3JvdW5kXCIpLkRlY2xhcmluZ1R5cGU7XHJcbmdsb2JhbDo6U3lzdGVtLlJlZmxlY3Rpb24uRmllbGRJbmZvIHByb3BlcnR5RmllbGQgPSBwcm9wZXJ0eURlY2xhcmluZ1R5cGUuR2V0RmllbGQoXCJCYWNrZ3JvdW5kUHJvcGVydHlcIik7XHJcbmdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRlcGVuZGVuY3lQcm9wZXJ0eSBwcm9wZXJ0eSA9IChnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EZXBlbmRlbmN5UHJvcGVydHkpcHJvcGVydHlGaWVsZC5HZXRWYWx1ZShudWxsKTtcclxuXHJcbiAgKGZpbmFsVGFyZ2V0SW5zdGFuY2UpLlNldFZpc3VhbFN0YXRlVmFsdWUocHJvcGVydHksIHZhbHVlKTtcclxufVxyXG5cclxuXHJcbnB1YmxpYyB2b2lkIHNldEFuaW1hdGlvblZpc3VhbFN0YXRlUHJvcGVydHlfM2EzZTIwMjJjYzk1NGJhZWI4MWQ2ZjNlYzAxYzQ0OWYgKGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRlcGVuZGVuY3lPYmplY3QgZmluYWxUYXJnZXRJbnN0YW5jZSwgb2JqZWN0IHZhbHVlKVxyXG57XHJcbiAgXHJcbmdsb2JhbDo6U3lzdGVtLlR5cGUgZmluYWxUYXJnZXRJbnN0YW5jZVR5cGUgPSBmaW5hbFRhcmdldEluc3RhbmNlLkdldFR5cGUoKTtcclxuZ2xvYmFsOjpTeXN0ZW0uVHlwZSBwcm9wZXJ0eURlY2xhcmluZ1R5cGUgPSBmaW5hbFRhcmdldEluc3RhbmNlVHlwZS5HZXRQcm9wZXJ0eShcIkJhY2tncm91bmRcIikuRGVjbGFyaW5nVHlwZTtcclxuZ2xvYmFsOjpTeXN0ZW0uUmVmbGVjdGlvbi5GaWVsZEluZm8gcHJvcGVydHlGaWVsZCA9IHByb3BlcnR5RGVjbGFyaW5nVHlwZS5HZXRGaWVsZChcIkJhY2tncm91bmRQcm9wZXJ0eVwiKTtcclxuZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGVwZW5kZW5jeVByb3BlcnR5IHByb3BlcnR5ID0gKGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRlcGVuZGVuY3lQcm9wZXJ0eSlwcm9wZXJ0eUZpZWxkLkdldFZhbHVlKG51bGwpO1xyXG5cclxuICAoZmluYWxUYXJnZXRJbnN0YW5jZSkuU2V0QW5pbWF0aW9uVmFsdWUocHJvcGVydHksIHZhbHVlKTtcclxufVxyXG5cclxuXHJcbnB1YmxpYyB2b2lkIHNldExvY2FsVmlzdWFsU3RhdGVQcm9wZXJ0eV8zYTNlMjAyMmNjOTU0YmFlYjgxZDZmM2VjMDFjNDQ5ZiAoZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGVwZW5kZW5jeU9iamVjdCBmaW5hbFRhcmdldEluc3RhbmNlLCBvYmplY3QgdmFsdWUpXHJcbntcclxuICBcclxuZ2xvYmFsOjpTeXN0ZW0uVHlwZSBmaW5hbFRhcmdldEluc3RhbmNlVHlwZSA9IGZpbmFsVGFyZ2V0SW5zdGFuY2UuR2V0VHlwZSgpO1xyXG5nbG9iYWw6OlN5c3RlbS5UeXBlIHByb3BlcnR5RGVjbGFyaW5nVHlwZSA9IGZpbmFsVGFyZ2V0SW5zdGFuY2VUeXBlLkdldFByb3BlcnR5KFwiQmFja2dyb3VuZFwiKS5EZWNsYXJpbmdUeXBlO1xyXG5nbG9iYWw6OlN5c3RlbS5SZWZsZWN0aW9uLkZpZWxkSW5mbyBwcm9wZXJ0eUZpZWxkID0gcHJvcGVydHlEZWNsYXJpbmdUeXBlLkdldEZpZWxkKFwiQmFja2dyb3VuZFByb3BlcnR5XCIpO1xyXG5nbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EZXBlbmRlbmN5UHJvcGVydHkgcHJvcGVydHkgPSAoZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGVwZW5kZW5jeVByb3BlcnR5KXByb3BlcnR5RmllbGQuR2V0VmFsdWUobnVsbCk7XHJcblxyXG4gIChmaW5hbFRhcmdldEluc3RhbmNlKS5TZXRDdXJyZW50VmFsdWUocHJvcGVydHksIHZhbHVlKTtcclxufVxyXG5cclxuXHJcbnB1YmxpYyBnbG9iYWw6OlN5c3RlbS5PYmplY3QgZ2V0VmlzdWFsU3RhdGVQcm9wZXJ0eV8zYTNlMjAyMmNjOTU0YmFlYjgxZDZmM2VjMDFjNDQ5ZiAoZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGVwZW5kZW5jeU9iamVjdCBmaW5hbFRhcmdldEluc3RhbmNlKVxyXG57XHJcbiAgXHJcbmdsb2JhbDo6U3lzdGVtLlR5cGUgZmluYWxUYXJnZXRJbnN0YW5jZVR5cGUgPSBmaW5hbFRhcmdldEluc3RhbmNlLkdldFR5cGUoKTtcclxuZ2xvYmFsOjpTeXN0ZW0uVHlwZSBwcm9wZXJ0eURlY2xhcmluZ1R5cGUgPSBmaW5hbFRhcmdldEluc3RhbmNlVHlwZS5HZXRQcm9wZXJ0eShcIkJhY2tncm91bmRcIikuRGVjbGFyaW5nVHlwZTtcclxuZ2xvYmFsOjpTeXN0ZW0uUmVmbGVjdGlvbi5GaWVsZEluZm8gcHJvcGVydHlGaWVsZCA9IHByb3BlcnR5RGVjbGFyaW5nVHlwZS5HZXRGaWVsZChcIkJhY2tncm91bmRQcm9wZXJ0eVwiKTtcclxuZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGVwZW5kZW5jeVByb3BlcnR5IHByb3BlcnR5ID0gKGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRlcGVuZGVuY3lQcm9wZXJ0eSlwcm9wZXJ0eUZpZWxkLkdldFZhbHVlKG51bGwpO1xyXG5cclxuICByZXR1cm4gZmluYWxUYXJnZXRJbnN0YW5jZS5HZXRWaXN1YWxTdGF0ZVZhbHVlKHByb3BlcnR5KTtcclxufVxyXG5cclxuXHJcbnB1YmxpYyBnbG9iYWw6OlN5c3RlbS5Db2xsZWN0aW9ucy5HZW5lcmljLklFbnVtZXJhYmxlPGdsb2JhbDo6U3lzdGVtLlR1cGxlPGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRlcGVuZGVuY3lPYmplY3QsIGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRlcGVuZGVuY3lQcm9wZXJ0eSwgaW50Pz4+IGFjY2Vzc1Zpc3VhbFN0YXRlUHJvcGVydHlfMDY0NGViMDkwNDM0NDQxODgwNTljYTk1MTdhMTVmMjIgKGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRlcGVuZGVuY3lPYmplY3Qgcm9vdFRhcmdldE9iamVjdEluc3RhbmNlKVxyXG57XHJcbiAgXHJcbnlpZWxkIGJyZWFrO1xyXG59XHJcblxyXG5cclxucHVibGljIHZvaWQgc2V0VmlzdWFsU3RhdGVQcm9wZXJ0eV8wNjQ0ZWIwOTA0MzQ0NDE4ODA1OWNhOTUxN2ExNWYyMiAoZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGVwZW5kZW5jeU9iamVjdCBmaW5hbFRhcmdldEluc3RhbmNlLCBvYmplY3QgdmFsdWUpXHJcbntcclxuICBcclxuZ2xvYmFsOjpTeXN0ZW0uVHlwZSBmaW5hbFRhcmdldEluc3RhbmNlVHlwZSA9IGZpbmFsVGFyZ2V0SW5zdGFuY2UuR2V0VHlwZSgpO1xyXG5nbG9iYWw6OlN5c3RlbS5UeXBlIHByb3BlcnR5RGVjbGFyaW5nVHlwZSA9IGZpbmFsVGFyZ2V0SW5zdGFuY2VUeXBlLkdldFByb3BlcnR5KFwiQmFja2dyb3VuZFwiKS5EZWNsYXJpbmdUeXBlO1xyXG5nbG9iYWw6OlN5c3RlbS5SZWZsZWN0aW9uLkZpZWxkSW5mbyBwcm9wZXJ0eUZpZWxkID0gcHJvcGVydHlEZWNsYXJpbmdUeXBlLkdldEZpZWxkKFwiQmFja2dyb3VuZFByb3BlcnR5XCIpO1xyXG5nbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EZXBlbmRlbmN5UHJvcGVydHkgcHJvcGVydHkgPSAoZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGVwZW5kZW5jeVByb3BlcnR5KXByb3BlcnR5RmllbGQuR2V0VmFsdWUobnVsbCk7XHJcblxyXG4gIChmaW5hbFRhcmdldEluc3RhbmNlKS5TZXRWaXN1YWxTdGF0ZVZhbHVlKHByb3BlcnR5LCB2YWx1ZSk7XHJcbn1cclxuXHJcblxyXG5wdWJsaWMgdm9pZCBzZXRBbmltYXRpb25WaXN1YWxTdGF0ZVByb3BlcnR5XzA2NDRlYjA5MDQzNDQ0MTg4MDU5Y2E5NTE3YTE1ZjIyIChnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EZXBlbmRlbmN5T2JqZWN0IGZpbmFsVGFyZ2V0SW5zdGFuY2UsIG9iamVjdCB2YWx1ZSlcclxue1xyXG4gIFxyXG5nbG9iYWw6OlN5c3RlbS5UeXBlIGZpbmFsVGFyZ2V0SW5zdGFuY2VUeXBlID0gZmluYWxUYXJnZXRJbnN0YW5jZS5HZXRUeXBlKCk7XHJcbmdsb2JhbDo6U3lzdGVtLlR5cGUgcHJvcGVydHlEZWNsYXJpbmdUeXBlID0gZmluYWxUYXJnZXRJbnN0YW5jZVR5cGUuR2V0UHJvcGVydHkoXCJCYWNrZ3JvdW5kXCIpLkRlY2xhcmluZ1R5cGU7XHJcbmdsb2JhbDo6U3lzdGVtLlJlZmxlY3Rpb24uRmllbGRJbmZvIHByb3BlcnR5RmllbGQgPSBwcm9wZXJ0eURlY2xhcmluZ1R5cGUuR2V0RmllbGQoXCJCYWNrZ3JvdW5kUHJvcGVydHlcIik7XHJcbmdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRlcGVuZGVuY3lQcm9wZXJ0eSBwcm9wZXJ0eSA9IChnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EZXBlbmRlbmN5UHJvcGVydHkpcHJvcGVydHlGaWVsZC5HZXRWYWx1ZShudWxsKTtcclxuXHJcbiAgKGZpbmFsVGFyZ2V0SW5zdGFuY2UpLlNldEFuaW1hdGlvblZhbHVlKHByb3BlcnR5LCB2YWx1ZSk7XHJcbn1cclxuXHJcblxyXG5wdWJsaWMgdm9pZCBzZXRMb2NhbFZpc3VhbFN0YXRlUHJvcGVydHlfMDY0NGViMDkwNDM0NDQxODgwNTljYTk1MTdhMTVmMjIgKGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRlcGVuZGVuY3lPYmplY3QgZmluYWxUYXJnZXRJbnN0YW5jZSwgb2JqZWN0IHZhbHVlKVxyXG57XHJcbiAgXHJcbmdsb2JhbDo6U3lzdGVtLlR5cGUgZmluYWxUYXJnZXRJbnN0YW5jZVR5cGUgPSBmaW5hbFRhcmdldEluc3RhbmNlLkdldFR5cGUoKTtcclxuZ2xvYmFsOjpTeXN0ZW0uVHlwZSBwcm9wZXJ0eURlY2xhcmluZ1R5cGUgPSBmaW5hbFRhcmdldEluc3RhbmNlVHlwZS5HZXRQcm9wZXJ0eShcIkJhY2tncm91bmRcIikuRGVjbGFyaW5nVHlwZTtcclxuZ2xvYmFsOjpTeXN0ZW0uUmVmbGVjdGlvbi5GaWVsZEluZm8gcHJvcGVydHlGaWVsZCA9IHByb3BlcnR5RGVjbGFyaW5nVHlwZS5HZXRGaWVsZChcIkJhY2tncm91bmRQcm9wZXJ0eVwiKTtcclxuZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGVwZW5kZW5jeVByb3BlcnR5IHByb3BlcnR5ID0gKGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRlcGVuZGVuY3lQcm9wZXJ0eSlwcm9wZXJ0eUZpZWxkLkdldFZhbHVlKG51bGwpO1xyXG5cclxuICAoZmluYWxUYXJnZXRJbnN0YW5jZSkuU2V0Q3VycmVudFZhbHVlKHByb3BlcnR5LCB2YWx1ZSk7XHJcbn1cclxuXHJcblxyXG5wdWJsaWMgZ2xvYmFsOjpTeXN0ZW0uT2JqZWN0IGdldFZpc3VhbFN0YXRlUHJvcGVydHlfMDY0NGViMDkwNDM0NDQxODgwNTljYTk1MTdhMTVmMjIgKGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRlcGVuZGVuY3lPYmplY3QgZmluYWxUYXJnZXRJbnN0YW5jZSlcclxue1xyXG4gIFxyXG5nbG9iYWw6OlN5c3RlbS5UeXBlIGZpbmFsVGFyZ2V0SW5zdGFuY2VUeXBlID0gZmluYWxUYXJnZXRJbnN0YW5jZS5HZXRUeXBlKCk7XHJcbmdsb2JhbDo6U3lzdGVtLlR5cGUgcHJvcGVydHlEZWNsYXJpbmdUeXBlID0gZmluYWxUYXJnZXRJbnN0YW5jZVR5cGUuR2V0UHJvcGVydHkoXCJCYWNrZ3JvdW5kXCIpLkRlY2xhcmluZ1R5cGU7XHJcbmdsb2JhbDo6U3lzdGVtLlJlZmxlY3Rpb24uRmllbGRJbmZvIHByb3BlcnR5RmllbGQgPSBwcm9wZXJ0eURlY2xhcmluZ1R5cGUuR2V0RmllbGQoXCJCYWNrZ3JvdW5kUHJvcGVydHlcIik7XHJcbmdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRlcGVuZGVuY3lQcm9wZXJ0eSBwcm9wZXJ0eSA9IChnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EZXBlbmRlbmN5UHJvcGVydHkpcHJvcGVydHlGaWVsZC5HZXRWYWx1ZShudWxsKTtcclxuXHJcbiAgcmV0dXJuIGZpbmFsVGFyZ2V0SW5zdGFuY2UuR2V0VmlzdWFsU3RhdGVWYWx1ZShwcm9wZXJ0eSk7XHJcbn1cclxuXHJcblxyXG5wdWJsaWMgZ2xvYmFsOjpTeXN0ZW0uQ29sbGVjdGlvbnMuR2VuZXJpYy5JRW51bWVyYWJsZTxnbG9iYWw6OlN5c3RlbS5UdXBsZTxnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EZXBlbmRlbmN5T2JqZWN0LCBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EZXBlbmRlbmN5UHJvcGVydHksIGludD8+PiBhY2Nlc3NWaXN1YWxTdGF0ZVByb3BlcnR5XzAzNzE0MDNjMDAwODQ3YWQ4OTM2ODM2ZTVjZTQwY2YzIChnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EZXBlbmRlbmN5T2JqZWN0IHJvb3RUYXJnZXRPYmplY3RJbnN0YW5jZSlcclxue1xyXG4gIFxyXG55aWVsZCBicmVhaztcclxufVxyXG5cclxuXHJcbnB1YmxpYyB2b2lkIHNldFZpc3VhbFN0YXRlUHJvcGVydHlfMDM3MTQwM2MwMDA4NDdhZDg5MzY4MzZlNWNlNDBjZjMgKGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRlcGVuZGVuY3lPYmplY3QgZmluYWxUYXJnZXRJbnN0YW5jZSwgb2JqZWN0IHZhbHVlKVxyXG57XHJcbiAgXHJcbmdsb2JhbDo6U3lzdGVtLlR5cGUgZmluYWxUYXJnZXRJbnN0YW5jZVR5cGUgPSBmaW5hbFRhcmdldEluc3RhbmNlLkdldFR5cGUoKTtcclxuZ2xvYmFsOjpTeXN0ZW0uVHlwZSBwcm9wZXJ0eURlY2xhcmluZ1R5cGUgPSBmaW5hbFRhcmdldEluc3RhbmNlVHlwZS5HZXRQcm9wZXJ0eShcIkJhY2tncm91bmRcIikuRGVjbGFyaW5nVHlwZTtcclxuZ2xvYmFsOjpTeXN0ZW0uUmVmbGVjdGlvbi5GaWVsZEluZm8gcHJvcGVydHlGaWVsZCA9IHByb3BlcnR5RGVjbGFyaW5nVHlwZS5HZXRGaWVsZChcIkJhY2tncm91bmRQcm9wZXJ0eVwiKTtcclxuZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGVwZW5kZW5jeVByb3BlcnR5IHByb3BlcnR5ID0gKGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRlcGVuZGVuY3lQcm9wZXJ0eSlwcm9wZXJ0eUZpZWxkLkdldFZhbHVlKG51bGwpO1xyXG5cclxuICAoZmluYWxUYXJnZXRJbnN0YW5jZSkuU2V0VmlzdWFsU3RhdGVWYWx1ZShwcm9wZXJ0eSwgdmFsdWUpO1xyXG59XHJcblxyXG5cclxucHVibGljIHZvaWQgc2V0QW5pbWF0aW9uVmlzdWFsU3RhdGVQcm9wZXJ0eV8wMzcxNDAzYzAwMDg0N2FkODkzNjgzNmU1Y2U0MGNmMyAoZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGVwZW5kZW5jeU9iamVjdCBmaW5hbFRhcmdldEluc3RhbmNlLCBvYmplY3QgdmFsdWUpXHJcbntcclxuICBcclxuZ2xvYmFsOjpTeXN0ZW0uVHlwZSBmaW5hbFRhcmdldEluc3RhbmNlVHlwZSA9IGZpbmFsVGFyZ2V0SW5zdGFuY2UuR2V0VHlwZSgpO1xyXG5nbG9iYWw6OlN5c3RlbS5UeXBlIHByb3BlcnR5RGVjbGFyaW5nVHlwZSA9IGZpbmFsVGFyZ2V0SW5zdGFuY2VUeXBlLkdldFByb3BlcnR5KFwiQmFja2dyb3VuZFwiKS5EZWNsYXJpbmdUeXBlO1xyXG5nbG9iYWw6OlN5c3RlbS5SZWZsZWN0aW9uLkZpZWxkSW5mbyBwcm9wZXJ0eUZpZWxkID0gcHJvcGVydHlEZWNsYXJpbmdUeXBlLkdldEZpZWxkKFwiQmFja2dyb3VuZFByb3BlcnR5XCIpO1xyXG5nbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EZXBlbmRlbmN5UHJvcGVydHkgcHJvcGVydHkgPSAoZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGVwZW5kZW5jeVByb3BlcnR5KXByb3BlcnR5RmllbGQuR2V0VmFsdWUobnVsbCk7XHJcblxyXG4gIChmaW5hbFRhcmdldEluc3RhbmNlKS5TZXRBbmltYXRpb25WYWx1ZShwcm9wZXJ0eSwgdmFsdWUpO1xyXG59XHJcblxyXG5cclxucHVibGljIHZvaWQgc2V0TG9jYWxWaXN1YWxTdGF0ZVByb3BlcnR5XzAzNzE0MDNjMDAwODQ3YWQ4OTM2ODM2ZTVjZTQwY2YzIChnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EZXBlbmRlbmN5T2JqZWN0IGZpbmFsVGFyZ2V0SW5zdGFuY2UsIG9iamVjdCB2YWx1ZSlcclxue1xyXG4gIFxyXG5nbG9iYWw6OlN5c3RlbS5UeXBlIGZpbmFsVGFyZ2V0SW5zdGFuY2VUeXBlID0gZmluYWxUYXJnZXRJbnN0YW5jZS5HZXRUeXBlKCk7XHJcbmdsb2JhbDo6U3lzdGVtLlR5cGUgcHJvcGVydHlEZWNsYXJpbmdUeXBlID0gZmluYWxUYXJnZXRJbnN0YW5jZVR5cGUuR2V0UHJvcGVydHkoXCJCYWNrZ3JvdW5kXCIpLkRlY2xhcmluZ1R5cGU7XHJcbmdsb2JhbDo6U3lzdGVtLlJlZmxlY3Rpb24uRmllbGRJbmZvIHByb3BlcnR5RmllbGQgPSBwcm9wZXJ0eURlY2xhcmluZ1R5cGUuR2V0RmllbGQoXCJCYWNrZ3JvdW5kUHJvcGVydHlcIik7XHJcbmdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRlcGVuZGVuY3lQcm9wZXJ0eSBwcm9wZXJ0eSA9IChnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EZXBlbmRlbmN5UHJvcGVydHkpcHJvcGVydHlGaWVsZC5HZXRWYWx1ZShudWxsKTtcclxuXHJcbiAgKGZpbmFsVGFyZ2V0SW5zdGFuY2UpLlNldEN1cnJlbnRWYWx1ZShwcm9wZXJ0eSwgdmFsdWUpO1xyXG59XHJcblxyXG5cclxucHVibGljIGdsb2JhbDo6U3lzdGVtLk9iamVjdCBnZXRWaXN1YWxTdGF0ZVByb3BlcnR5XzAzNzE0MDNjMDAwODQ3YWQ4OTM2ODM2ZTVjZTQwY2YzIChnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EZXBlbmRlbmN5T2JqZWN0IGZpbmFsVGFyZ2V0SW5zdGFuY2UpXHJcbntcclxuICBcclxuZ2xvYmFsOjpTeXN0ZW0uVHlwZSBmaW5hbFRhcmdldEluc3RhbmNlVHlwZSA9IGZpbmFsVGFyZ2V0SW5zdGFuY2UuR2V0VHlwZSgpO1xyXG5nbG9iYWw6OlN5c3RlbS5UeXBlIHByb3BlcnR5RGVjbGFyaW5nVHlwZSA9IGZpbmFsVGFyZ2V0SW5zdGFuY2VUeXBlLkdldFByb3BlcnR5KFwiQmFja2dyb3VuZFwiKS5EZWNsYXJpbmdUeXBlO1xyXG5nbG9iYWw6OlN5c3RlbS5SZWZsZWN0aW9uLkZpZWxkSW5mbyBwcm9wZXJ0eUZpZWxkID0gcHJvcGVydHlEZWNsYXJpbmdUeXBlLkdldEZpZWxkKFwiQmFja2dyb3VuZFByb3BlcnR5XCIpO1xyXG5nbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EZXBlbmRlbmN5UHJvcGVydHkgcHJvcGVydHkgPSAoZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGVwZW5kZW5jeVByb3BlcnR5KXByb3BlcnR5RmllbGQuR2V0VmFsdWUobnVsbCk7XHJcblxyXG4gIHJldHVybiBmaW5hbFRhcmdldEluc3RhbmNlLkdldFZpc3VhbFN0YXRlVmFsdWUocHJvcGVydHkpO1xyXG59XHJcblxyXG5cclxucHVibGljIHN0YXRpYyB2b2lkIE1haW4oKVxyXG57XHJcbiAgICBuZXcgQXBwKCk7XHJcbn1cclxuXHJcbn1cclxuXHJcblxyXG59XHJcbiIsIi8vIDxDU0hUTUw1PjxYYW1sSGFzaD4wNkE2NDE2NEY5NEIyNjg0MkI2RkY3MTUwMEJGQjY5RjwvWGFtbEhhc2g+PFBhc3NOdW1iZXI+MjwvUGFzc051bWJlcj48Q29tcGlsYXRpb25EYXRlPjE2LzA5LzIwMjQgMDA6NTU6NDQ8L0NvbXBpbGF0aW9uRGF0ZT48L0NTSFRNTDU+XHJcblxyXG5cclxuXHJcbnB1YmxpYyBzdGF0aWMgY2xhc3Mgx4DHgFF3Y8eAx4BDb21wb25lbnTHgMeATWFpbnBhZ2XHgMeAWGFtbMeAx4BGYWN0b3J5XHJcbntcclxuICAgIHB1YmxpYyBzdGF0aWMgb2JqZWN0IEluc3RhbnRpYXRlKClcclxuICAgIHtcclxuICAgICAgICBnbG9iYWw6OlN5c3RlbS5UeXBlIHR5cGUgPSB0eXBlb2YoUVdDLk1haW5QYWdlKTtcclxuICAgICAgICByZXR1cm4gZ2xvYmFsOjpDU0hUTUw1LkludGVybmFsLlR5cGVJbnN0YW50aWF0aW9uSGVscGVyLkluc3RhbnRpYXRlKHR5cGUpO1xyXG4gICAgfVxyXG59XHJcblxyXG5uYW1lc3BhY2UgUVdDXHJcbntcclxuXHJcblxyXG4vLy0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG4vLyA8YXV0by1nZW5lcmF0ZWQ+XHJcbi8vICAgICBUaGlzIGNvZGUgd2FzIGF1dG8tZ2VuZXJhdGVkIGJ5IFwiQyMvWEFNTCBmb3IgSFRNTDVcIlxyXG4vL1xyXG4vLyAgICAgQ2hhbmdlcyB0byB0aGlzIGZpbGUgbWF5IGNhdXNlIGluY29ycmVjdCBiZWhhdmlvciBhbmQgd2lsbCBiZSBsb3N0IGlmXHJcbi8vICAgICB0aGUgY29kZSBpcyByZWdlbmVyYXRlZC5cclxuLy8gPC9hdXRvLWdlbmVyYXRlZD5cclxuLy8tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuXHJcblxyXG5cclxucGFydGlhbCBjbGFzcyBNYWluUGFnZSA6IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkNvbnRyb2xzLlBhZ2Vcclxue1xyXG5cclxuI3ByYWdtYSB3YXJuaW5nIGRpc2FibGUgMTY5LCA2NDksIDA2MjggLy8gUHJldmVudHMgd2FybmluZyBDUzAxNjkgKCdmaWVsZCAuLi4gaXMgbmV2ZXIgdXNlZCcpLCBDUzA2NDkgKCdmaWVsZCAuLi4gaXMgbmV2ZXIgYXNzaWduZWQgdG8sIGFuZCB3aWxsIGFsd2F5cyBoYXZlIGl0cyBkZWZhdWx0IHZhbHVlIG51bGwnKSwgYW5kIENTMDYyOCAoJ21lbWJlciA6IG5ldyBwcm90ZWN0ZWQgbWVtYmVyIGRlY2xhcmVkIGluIHNlYWxlZCBjbGFzcycpXHJcbnByb3RlY3RlZCBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Db250cm9scy5HcmlkIFFXQ0dyaWQ7XHJcbnByb3RlY3RlZCBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Db250cm9scy5XcmFwUGFuZWwgUVdDSWNvbnM7XHJcbnByb3RlY3RlZCBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Db250cm9scy5HcmlkIFFXQ0hpZGRlbjtcclxucHJvdGVjdGVkIGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkNvbnRyb2xzLkdyaWQgUVdDU2lkZUJhcnM7XHJcbnByb3RlY3RlZCBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Db250cm9scy5QYWdlIFRvcDtcclxuXHJcblxyXG4jcHJhZ21hIHdhcm5pbmcgcmVzdG9yZSAxNjksIDY0OSwgMDYyOFxyXG5cclxuXHJcbiAgICAgICAgcHJpdmF0ZSBib29sIF9jb250ZW50TG9hZGVkO1xyXG4gICAgICAgIHB1YmxpYyB2b2lkIEluaXRpYWxpemVDb21wb25lbnQoKVxyXG4gICAgICAgIHtcclxuICAgICAgICAgICAgaWYgKF9jb250ZW50TG9hZGVkKVxyXG4gICAgICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgICAgICBfY29udGVudExvYWRlZCA9IHRydWU7XHJcblxyXG4jcHJhZ21hIHdhcm5pbmcgZGlzYWJsZSAwMTg0IC8vIFByZXZlbnRzIHdhcm5pbmcgQ1MwMTg0ICgnVGhlIGdpdmVuIGV4cHJlc3Npb24gaXMgbmV2ZXIgb2YgdGhlIHByb3ZpZGVkICgndHlwZScpIHR5cGUnKVxyXG4gICAgICAgICAgICBpZiAodGhpcyBpcyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5VSUVsZW1lbnQpXHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICgoZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuVUlFbGVtZW50KShvYmplY3QpdGhpcykuWGFtbFNvdXJjZVBhdGggPSBAXCJRV0NcXE1haW5QYWdlLnhhbWxcIjtcclxuICAgICAgICAgICAgfVxyXG4jcHJhZ21hIHdhcm5pbmcgcmVzdG9yZSAwMTg0XHJcblxyXG52YXIgR3JpZF81Mzk1MGE2ZWNkNjI0M2QxODFkYTI5NDBmMDA2ZTVhYSA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Db250cm9scy5HcmlkKCk7XHJcbnZhciBXcmFwUGFuZWxfOGY2ZDkwYzViODQ5NDBhMzg0Y2FkY2IwNzFmNDAwNWUgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuQ29udHJvbHMuV3JhcFBhbmVsKCk7XHJcbnZhciBHcmlkX2VhNDE3MzYxNzUyYzQwNjVhYjFjZmI4NzZkNWVhODIzID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkNvbnRyb2xzLkdyaWQoKTtcclxudmFyIEdyaWRfMTZmMGI2ODEzYzAzNDA2ODk4MWFlNmI2NzFhYjE0YjYgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuQ29udHJvbHMuR3JpZCgpO1xyXG5cclxudGhpcy5SZWdpc3Rlck5hbWUoXCJUb3BcIiwgdGhpcyk7XHJcbnRoaXMuTmFtZSA9IFwiVG9wXCI7XHJcbnZhciBJbnRDb252ZXJ0ZXJfYTI2MGNlNzljN2MxNGM5Y2FiZjQ1ZGYwZTgzODQ0M2MgPSBuZXcgZ2xvYmFsOjpBUExFeHRlbnNpb24uSW50Q29udmVydGVyKCk7XHJcblxyXG52YXIgRGVjQ29udmVydGVyXzdkZmZmZDA0Njk1NTRiOTFiZWExNzQyMWE3OTE4MDY0ID0gbmV3IGdsb2JhbDo6QVBMRXh0ZW5zaW9uLkRlY0NvbnZlcnRlcigpO1xyXG5cclxudGhpcy5SZXNvdXJjZXNbXCJJbnRDb252ZXJ0ZXJcIl0gPSBJbnRDb252ZXJ0ZXJfYTI2MGNlNzljN2MxNGM5Y2FiZjQ1ZGYwZTgzODQ0M2M7XHJcbnRoaXMuUmVzb3VyY2VzW1wiRGVjQ29udmVydGVyXCJdID0gRGVjQ29udmVydGVyXzdkZmZmZDA0Njk1NTRiOTFiZWExNzQyMWE3OTE4MDY0O1xyXG5cclxudmFyIEdyaWRfYjUwMGQ1YjIwZDAxNGFlNjlkZDNhNTIzYTIyOTRkMWEgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuQ29udHJvbHMuR3JpZCgpO1xyXG52YXIgUm93RGVmaW5pdGlvbl9kNWQ4MzZmYzRkZTM0MTE5OTg5NWJhZmIyZWE0NGMxNSA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Db250cm9scy5Sb3dEZWZpbml0aW9uKCk7XHJcblJvd0RlZmluaXRpb25fZDVkODM2ZmM0ZGUzNDExOTk4OTViYWZiMmVhNDRjMTUuSGVpZ2h0ID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkdyaWRMZW5ndGgoMS4wLCBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5HcmlkVW5pdFR5cGUuU3Rhcik7XHJcblxyXG52YXIgUm93RGVmaW5pdGlvbl82NWE0YTVmNGY4ZDQ0ZTFkYTAwMTAwNzE0YzY0YWQ4NSA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Db250cm9scy5Sb3dEZWZpbml0aW9uKCk7XHJcblJvd0RlZmluaXRpb25fNjVhNGE1ZjRmOGQ0NGUxZGEwMDEwMDcxNGM2NGFkODUuSGVpZ2h0ID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkdyaWRMZW5ndGgoMS4wLCBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5HcmlkVW5pdFR5cGUuQXV0byk7XHJcblxyXG5HcmlkX2I1MDBkNWIyMGQwMTRhZTY5ZGQzYTUyM2EyMjk0ZDFhLlJvd0RlZmluaXRpb25zLkFkZChSb3dEZWZpbml0aW9uX2Q1ZDgzNmZjNGRlMzQxMTk5ODk1YmFmYjJlYTQ0YzE1KTtcclxuR3JpZF9iNTAwZDViMjBkMDE0YWU2OWRkM2E1MjNhMjI5NGQxYS5Sb3dEZWZpbml0aW9ucy5BZGQoUm93RGVmaW5pdGlvbl82NWE0YTVmNGY4ZDQ0ZTFkYTAwMTAwNzE0YzY0YWQ4NSk7XHJcblxyXG50aGlzLlJlZ2lzdGVyTmFtZShcIlFXQ0dyaWRcIiwgR3JpZF81Mzk1MGE2ZWNkNjI0M2QxODFkYTI5NDBmMDA2ZTVhYSk7XHJcbkdyaWRfNTM5NTBhNmVjZDYyNDNkMTgxZGEyOTQwZjAwNmU1YWEuTmFtZSA9IFwiUVdDR3JpZFwiO1xyXG5cclxudGhpcy5SZWdpc3Rlck5hbWUoXCJRV0NJY29uc1wiLCBXcmFwUGFuZWxfOGY2ZDkwYzViODQ5NDBhMzg0Y2FkY2IwNzFmNDAwNWUpO1xyXG5XcmFwUGFuZWxfOGY2ZDkwYzViODQ5NDBhMzg0Y2FkY2IwNzFmNDAwNWUuTmFtZSA9IFwiUVdDSWNvbnNcIjtcclxuZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuQ29udHJvbHMuR3JpZC5TZXRSb3coV3JhcFBhbmVsXzhmNmQ5MGM1Yjg0OTQwYTM4NGNhZGNiMDcxZjQwMDVlLDEpO1xyXG5cclxudGhpcy5SZWdpc3Rlck5hbWUoXCJRV0NIaWRkZW5cIiwgR3JpZF9lYTQxNzM2MTc1MmM0MDY1YWIxY2ZiODc2ZDVlYTgyMyk7XHJcbkdyaWRfZWE0MTczNjE3NTJjNDA2NWFiMWNmYjg3NmQ1ZWE4MjMuTmFtZSA9IFwiUVdDSGlkZGVuXCI7XHJcbmdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkNvbnRyb2xzLkdyaWQuU2V0Um93KEdyaWRfZWE0MTczNjE3NTJjNDA2NWFiMWNmYjg3NmQ1ZWE4MjMsMSk7XHJcbkdyaWRfZWE0MTczNjE3NTJjNDA2NWFiMWNmYjg3NmQ1ZWE4MjMuVmlzaWJpbGl0eSA9IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlZpc2liaWxpdHkuQ29sbGFwc2VkO1xyXG5cclxudGhpcy5SZWdpc3Rlck5hbWUoXCJRV0NTaWRlQmFyc1wiLCBHcmlkXzE2ZjBiNjgxM2MwMzQwNjg5ODFhZTZiNjcxYWIxNGI2KTtcclxuR3JpZF8xNmYwYjY4MTNjMDM0MDY4OTgxYWU2YjY3MWFiMTRiNi5OYW1lID0gXCJRV0NTaWRlQmFyc1wiO1xyXG5nbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Db250cm9scy5HcmlkLlNldFJvdyhHcmlkXzE2ZjBiNjgxM2MwMzQwNjg5ODFhZTZiNjcxYWIxNGI2LDEpO1xyXG5HcmlkXzE2ZjBiNjgxM2MwMzQwNjg5ODFhZTZiNjcxYWIxNGI2LlZpc2liaWxpdHkgPSBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5WaXNpYmlsaXR5LkNvbGxhcHNlZDtcclxuXHJcbkdyaWRfYjUwMGQ1YjIwZDAxNGFlNjlkZDNhNTIzYTIyOTRkMWEuQ2hpbGRyZW4uQWRkKEdyaWRfNTM5NTBhNmVjZDYyNDNkMTgxZGEyOTQwZjAwNmU1YWEpO1xyXG5HcmlkX2I1MDBkNWIyMGQwMTRhZTY5ZGQzYTUyM2EyMjk0ZDFhLkNoaWxkcmVuLkFkZChXcmFwUGFuZWxfOGY2ZDkwYzViODQ5NDBhMzg0Y2FkY2IwNzFmNDAwNWUpO1xyXG5HcmlkX2I1MDBkNWIyMGQwMTRhZTY5ZGQzYTUyM2EyMjk0ZDFhLkNoaWxkcmVuLkFkZChHcmlkX2VhNDE3MzYxNzUyYzQwNjVhYjFjZmI4NzZkNWVhODIzKTtcclxuR3JpZF9iNTAwZDViMjBkMDE0YWU2OWRkM2E1MjNhMjI5NGQxYS5DaGlsZHJlbi5BZGQoR3JpZF8xNmYwYjY4MTNjMDM0MDY4OTgxYWU2YjY3MWFiMTRiNik7XHJcblxyXG5cclxudGhpcy5Db250ZW50ID0gR3JpZF9iNTAwZDViMjBkMDE0YWU2OWRkM2E1MjNhMjI5NGQxYTtcclxuXHJcbnZhciBEYXRhQ29udGV4dEV4dGVuc2lvbl84NDU0MjY4ZjczYTA0NmU0ODA1NWEzMWU3ZTIwZGY2YyA9IG5ldyBnbG9iYWw6OkFQTEV4dGVuc2lvbi5EYXRhQ29udGV4dEV4dGVuc2lvbigpO1xyXG5EYXRhQ29udGV4dEV4dGVuc2lvbl84NDU0MjY4ZjczYTA0NmU0ODA1NWEzMWU3ZTIwZGY2Yy5JbnN0YW5jZSA9IEBcInF3Y19Sb290XCI7XHJcbkRhdGFDb250ZXh0RXh0ZW5zaW9uXzg0NTQyNjhmNzNhMDQ2ZTQ4MDU1YTMxZTdlMjBkZjZjLkNsYXNzID0gQFwicXdjX1Jvb3RcIjtcclxuRGF0YUNvbnRleHRFeHRlbnNpb25fODQ1NDI2OGY3M2EwNDZlNDgwNTVhMzFlN2UyMGRmNmMuTlMgPSBAXCJEYXRhQmluZGluZ1wiO1xyXG5cclxuXHJcblxyXG5cclxuUVdDR3JpZCA9IEdyaWRfNTM5NTBhNmVjZDYyNDNkMTgxZGEyOTQwZjAwNmU1YWE7XHJcblFXQ0ljb25zID0gV3JhcFBhbmVsXzhmNmQ5MGM1Yjg0OTQwYTM4NGNhZGNiMDcxZjQwMDVlO1xyXG5RV0NIaWRkZW4gPSBHcmlkX2VhNDE3MzYxNzUyYzQwNjVhYjFjZmI4NzZkNWVhODIzO1xyXG5RV0NTaWRlQmFycyA9IEdyaWRfMTZmMGI2ODEzYzAzNDA2ODk4MWFlNmI2NzFhYjE0YjY7XHJcblRvcCA9IHRoaXM7XHJcblxyXG52YXIgY3VzdG9tTWFya3VwVmFsdWVfMTA5Nzk0ODQ4MzI5NGM3MmEyYjMwNDg1Mjg5ZGJhNjggPSBEYXRhQ29udGV4dEV4dGVuc2lvbl84NDU0MjY4ZjczYTA0NmU0ODA1NWEzMWU3ZTIwZGY2Yy5Qcm92aWRlVmFsdWUobmV3IGdsb2JhbDo6U3lzdGVtLlNlcnZpY2VQcm92aWRlcih0aGlzLCBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5GcmFtZXdvcmtFbGVtZW50LkRhdGFDb250ZXh0UHJvcGVydHkpKTtcclxuaWYoY3VzdG9tTWFya3VwVmFsdWVfMTA5Nzk0ODQ4MzI5NGM3MmEyYjMwNDg1Mjg5ZGJhNjggaXMgV2luZG93cy5VSS5YYW1sLkRhdGEuQmluZGluZylcclxue1xyXG4gICAgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5CaW5kaW5nT3BlcmF0aW9ucy5TZXRCaW5kaW5nKHRoaXMsIGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkZyYW1ld29ya0VsZW1lbnQuRGF0YUNvbnRleHRQcm9wZXJ0eSwgKFdpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmcpY3VzdG9tTWFya3VwVmFsdWVfMTA5Nzk0ODQ4MzI5NGM3MmEyYjMwNDg1Mjg5ZGJhNjgpO1xyXG59XHJcbmVsc2Vcclxue1xyXG4gICAgdGhpcy5EYXRhQ29udGV4dCA9IChnbG9iYWw6OlN5c3RlbS5PYmplY3QpY3VzdG9tTWFya3VwVmFsdWVfMTA5Nzk0ODQ4MzI5NGM3MmEyYjMwNDg1Mjg5ZGJhNjg7XHJcbn1cclxuICAgIFxyXG4gICAgICAgIH1cclxuXHJcblxyXG5cclxuXHJcbn1cclxuXHJcblxyXG59XHJcbiIsInVzaW5nIEFQTENvbnRyb2xzO1xyXG51c2luZyBBUExDb250cm9scztcclxudXNpbmcgQVBMRXh0ZW5zaW9uO1xyXG51c2luZyBEYXRhQmluZGluZztcclxudXNpbmcgU3lzdGVtO1xyXG51c2luZyBDU0hUTUw1O1xyXG51c2luZyBTeXN0ZW0uQ29sbGVjdGlvbnMuR2VuZXJpYztcclxudXNpbmcgU3lzdGVtLklPO1xyXG51c2luZyBTeXN0ZW0uTGlucTtcclxudXNpbmcgV2luZG93cy5VSS5YYW1sO1xyXG51c2luZyBXaW5kb3dzLlVJLlhhbWwuQ29udHJvbHM7XHJcbnVzaW5nIFdpbmRvd3MuRm91bmRhdGlvbjtcclxubmFtZXNwYWNlIFFXQ1xyXG57XHJcbiAgICBwdWJsaWMgc2VhbGVkIHBhcnRpYWwgY2xhc3MgQXBwIDogQXBwbGljYXRpb25cclxuICAgIHtcclxuICAgICAgICBBUExFeHRlbnNpb24uRGF0YUNvbnRleHRFeHRlbnNpb24gZDtcclxuICAgICAgICBwdWJsaWMgQXBwKClcclxuICAgICAgICB7XHJcbiAgICAgICAgICAgIHRoaXMuSW5pdGlhbGl6ZUNvbXBvbmVudCgpO1xyXG4gICAgICAgICAgICAvLyBFbnRlciBjb25zdHJ1Y3Rpb24gbG9naWMgaGVyZS4uLlxyXG4gICAgICAgICAgICB0cnlcclxuICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgRGF0YUJpbmRpbmcuU2VuZGVyQ2xhc3MgYSA9IG5ldyBEYXRhQmluZGluZy5TZW5kZXJDbGFzcygpO1xyXG4gICAgICAgICAgICAgICAgQXBwbGljYXRpb24uQ3VycmVudC5SZXNvdXJjZXNbXCJTZW5kZXJDbGFzc1wiXSA9IGE7XHJcbiAgICAgICAgICAgICAgICBBcHBsaWNhdGlvbi5DdXJyZW50LlJlc291cmNlc1tcIlFXQ1wiXSA9IHRoaXM7XHJcbiAgICAgICAgICAgIH0gY2F0Y2ggeyB9XHJcbiAgICAgICAgICAgIHZhciBtYWluUGFnZSA9IG5ldyBNYWluUGFnZSgpO1xyXG4gICBJbnRlcm9wLkV4ZWN1dGVKYXZhU2NyaXB0KFwiaWYgKG1qaF9maWxlc2xvYWRlZCkgbWpoX2ZpbGVzbG9hZGVkWydwYWdlJ10gPSAkMFwiLCBtYWluUGFnZSk7XHJcbiAgICAgICAgICAgIFdpbmRvdy5DdXJyZW50LkNvbnRlbnQgPSBtYWluUGFnZTtcclxuICAgICAgICB9XHJcbnZvaWQgUnVuQ2xpY2tNaW4oT2JqZWN0IHMsIFJvdXRlZEV2ZW50QXJncyBhcmdzKSB7XHJcbnF3Y0Zvcm1fRGF0YSBkYyA9IChxd2NGb3JtX0RhdGEpICgoQnV0dG9uKSBzKS5EYXRhQ29udGV4dDtcclxuZGMuU2VuZE1hcmdpbiA9IGZhbHNlO1xyXG5kYy5TdGF0ZSA9IDE7XHJcbnF3Y19Sb290IHJvb3QgPSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBcInF3Y19Sb290XCIsIFwicXdjX1Jvb3RcIiwgdGhpcykgYXMgcXdjX1Jvb3Q7XHJcbnJvb3QuRnVsbFNjcmVlbklkID0gXCJcIjtcclxufSBcclxudm9pZCBSdW5DbGlja01heChPYmplY3QgcywgUm91dGVkRXZlbnRBcmdzIGFyZ3MpIHtcclxucXdjRm9ybV9EYXRhIGRjID0gKHF3Y0Zvcm1fRGF0YSkoKEJ1dHRvbilzKS5EYXRhQ29udGV4dDtcclxuZGMuU2VuZE1hcmdpbiA9IGZhbHNlO1xyXG5pZiAoMiA9PSBkYy5TdGF0ZSkgZGMuU3RhdGUgID0gMDtcclxuZWxzZSBkYy5TdGF0ZSA9IDI7XHJcbnF3Y19Sb290IHJvb3QgPSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBcInF3Y19Sb290XCIsIFwicXdjX1Jvb3RcIiwgdGhpcykgYXMgcXdjX1Jvb3Q7XHJcbnJvb3QuRnVsbFNjcmVlbklkID0gXCJcIjtcclxufSBcclxudm9pZCBSdW5DbGlja0Z1bGxTY3JlZW4oT2JqZWN0IHMsIFJvdXRlZEV2ZW50QXJncyBhcmdzKSB7XHJcbnF3Y0Zvcm1fRGF0YSBkYyA9IChxd2NGb3JtX0RhdGEpKChCdXR0b24pcykuRGF0YUNvbnRleHQ7XHJcbkFQTEZvcm0gb2JqID0gZGMuTUpIX1NlbGYgYXMgQVBMRm9ybTtcclxuZGMuU2VuZE1hcmdpbiA9IGZhbHNlO1xyXG5JbnRlcm9wLkV4ZWN1dGVKYXZhU2NyaXB0KFwidmFyIGVsZW0gPSAkMFwiLCBJbnRlcm9wLkdldERpdihvYmopKTtcclxuSW50ZXJvcC5FeGVjdXRlSmF2YVNjcmlwdChcIm9wZW5GdWxsc2NyZWVuKGVsZW0pXCIpO1xyXG5kYy5TdGF0ZSA9IDQ7XHJcbnF3Y19Sb290IHJvb3QgPSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBcInF3Y19Sb290XCIsIFwicXdjX1Jvb3RcIiwgdGhpcykgYXMgcXdjX1Jvb3Q7XHJcbnJvb3QuRnVsbFNjcmVlbklkID0gZGMuTmFtZTtcclxufSBcclxudm9pZCBSdW5DbGlja0Nsb3NlKE9iamVjdCBzLCBSb3V0ZWRFdmVudEFyZ3MgYXJncykge1xyXG5xd2NGb3JtX0RhdGEgZGMgPSAocXdjRm9ybV9EYXRhKSgoQnV0dG9uKXMpLkRhdGFDb250ZXh0O1xyXG5kYy5TZW5kTWFyZ2luID0gZmFsc2U7XHJcblN0cmluZyBldmVudG5hbWUgPSBcIkNsaWNrQ2xvc2VcIjtcclxuQVBMRm9ybSBvYmogPSBkYy5NSkhfU2VsZiBhcyBBUExGb3JtO1xyXG5vYmouQ2xvc2UoKTtcclxufSBcclxufX1cclxuIiwidXNpbmcgU3lzdGVtO1xyXG51c2luZyBTeXN0ZW0uQ29sbGVjdGlvbnMuR2VuZXJpYztcclxudXNpbmcgU3lzdGVtLklPO1xyXG51c2luZyBTeXN0ZW0uTGlucTtcclxudXNpbmcgV2luZG93cy5TeXN0ZW07XHJcbnVzaW5nIFdpbmRvd3MuVUkuWGFtbDtcclxudXNpbmcgV2luZG93cy5VSS5YYW1sLkNvbnRyb2xzO1xyXG51c2luZyBTeXN0ZW0uV2luZG93cy5JbnB1dDtcclxudXNpbmcgV2luZG93cy5VSS5YYW1sLklucHV0O1xyXG51c2luZyBXaW5kb3dzLlVJLlhhbWwuRGF0YTtcclxudXNpbmcgV2luZG93cy5Gb3VuZGF0aW9uO1xyXG51c2luZyBTeXN0ZW0uQ29sbGVjdGlvbnMuT2JqZWN0TW9kZWw7XHJcbnVzaW5nIFN5c3RlbS5XaW5kb3dzLkJyb3dzZXI7XHJcbnVzaW5nIFN5c3RlbS5SZWZsZWN0aW9uO1xyXG51c2luZyBBUExFeHRlbnNpb247XHJcbnVzaW5nIERhdGFCaW5kaW5nO1xyXG51c2luZyBDU0hUTUw1O1xyXG51c2luZyBTeXN0ZW0uVGhyZWFkaW5nLlRhc2tzO1xyXG51c2luZyBNSkhTb2Z0d2FyZS5Db21tb247XHJcbnVzaW5nIEFQTENvbnRyb2xzO1xyXG51c2luZyBTeXN0ZW0uVGhyZWFkaW5nO1xyXG5uYW1lc3BhY2UgUVdDXHJcbnsgXHJcbnB1YmxpYyBzZWFsZWQgcGFydGlhbCBjbGFzcyBNYWluUGFnZSA6IFBhZ2VcclxueyBcclxucHVibGljIHJlYWRvbmx5IFRhc2tDb21wbGV0aW9uU291cmNlPGJvb2w+IGZpbGVzUmVhZHkgPSBuZXcgVGFza0NvbXBsZXRpb25Tb3VyY2U8Ym9vbD4oKTtcclxucHVibGljIFRhc2s8Ym9vbD4gRmlsZXNSZWFkeSB7IGdldCB7IHJldHVybiBmaWxlc1JlYWR5LlRhc2s7IH0gfVxyXG5yZWFkb25seSBUYXNrQ29tcGxldGlvblNvdXJjZTxib29sPiB3ZWJTb2NrZXRSZWFkeSA9IG5ldyBUYXNrQ29tcGxldGlvblNvdXJjZTxib29sPigpO1xyXG5wdWJsaWMgVGFzazxib29sPiBXZWJTb2NrZXRSZWFkeSB7IGdldCB7IHJldHVybiB3ZWJTb2NrZXRSZWFkeS5UYXNrOyB9IH1cclxuQ1NIVE1MNS5FeHRlbnNpb25zLldlYlNvY2tldHMuV2ViU29ja2V0IHdlYlNvY2tldDtcclxuQ1NIVE1MNS5FeHRlbnNpb25zLldlYlNvY2tldHMuV2ViU29ja2V0IGRpcmVjdHdlYlNvY2tldDtcclxuU3RyaW5nIGNvbm5lY3Rpb24gPSBcIlwiO1xyXG5TdHJpbmcgY29ubmVjdGlvbnBvcnQgPSBcIlwiO1xyXG5Cb29sZWFuIEFsbFJlYWR5ID0gZmFsc2U7XHJcbkJvb2xlYW4gU2V0dXBDb21wbGV0ZVJ1biA9IGZhbHNlO1xyXG5wdWJsaWMgTWFpblBhZ2UoKSB7XHJcblJ1blJlc3RNYWluKCk7XHJcbn0gXHJcbnZvaWQgQWRkRmlsZUxvYWRpbmcoKSB7XHJcbkludGVyb3AuRXhlY3V0ZUphdmFTY3JpcHQoXCJtamhfZmlsZXNsb2FkZWQudmFsdWUgKz0gMVwiKTtcclxuaW50IEZpbGVzTG9hZGVkID0gKGludCkgSW50ZXJvcC5FeGVjdXRlSmF2YVNjcmlwdChcIm1qaF9maWxlc2xvYWRlZC52YWx1ZVwiKTtcclxuaW50IFRvdGFsRmlsZXNUb0JlTG9hZGVkID0gKGludCkgSW50ZXJvcC5FeGVjdXRlSmF2YVNjcmlwdChcIm1qaF9maWxlc2xvYWRlZC50b3RhbFwiKTtcclxuaWYgKEZpbGVzTG9hZGVkID09IFRvdGFsRmlsZXNUb0JlTG9hZGVkKSB7Ym9vbCB4ID0gZmlsZXNSZWFkeS5UcnlTZXRSZXN1bHQodHJ1ZSk7fTtcclxufSBcclxudm9pZCBDaGVja0ZpbGVMb2FkaW5nKCkge1xyXG5pbnQgRmlsZXNMb2FkZWQgPSAoaW50KSBJbnRlcm9wLkV4ZWN1dGVKYXZhU2NyaXB0KFwibWpoX2ZpbGVzbG9hZGVkLnZhbHVlXCIpO1xyXG5pbnQgVG90YWxGaWxlc1RvQmVMb2FkZWQgPSAoaW50KSBJbnRlcm9wLkV4ZWN1dGVKYXZhU2NyaXB0KFwibWpoX2ZpbGVzbG9hZGVkLnRvdGFsXCIpO1xyXG5pZiAoRmlsZXNMb2FkZWQgPT0gVG90YWxGaWxlc1RvQmVMb2FkZWQpIHtib29sIHggPSBmaWxlc1JlYWR5LlRyeVNldFJlc3VsdCh0cnVlKTt9O1xyXG59IFxyXG52b2lkIEVuZEN1c3RvbUNTUygpIHtcclxuYm9vbCBydW5mbGcgPSAoYm9vbCkgSW50ZXJvcC5FeGVjdXRlSmF2YVNjcmlwdChcIigndW5kZWZpbmVkJyAhPXR5cGVvZiBlaiAmJiAgJ3VuZGVmaW5lZCcgIT0gdHlwZW9mIGVqLmJhc2UpXCIpO1xyXG5pZiAocnVuZmxnKSB7XHJcbkludGVyb3AuRXhlY3V0ZUphdmFTY3JpcHQoXCJlai5iYXNlLmVuYWJsZVJpcHBsZShmYWxzZSlcIik7XHJcbn0gXHJcbn0gXHJcbnZvaWQgUnVuUmVzdE1haW4oKSB7XHJcbkludGVyb3AuRXhlY3V0ZUphdmFTY3JpcHQoXCJ3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcignYmVmb3JldW5sb2FkJywgJDApXCIsIChGdW5jPG9iamVjdCxzdHJpbmc+KU9uQmVmb3JlVW5sb2FkKTtcclxuQXBwbGljYXRpb24uQ3VycmVudC5SZXNvdXJjZXNbXCJNYXhTZXJpYWxOb1wiXSA9IDA7XHJcbkFwcGxpY2F0aW9uLkN1cnJlbnQuUmVzb3VyY2VzW1wiRnJhbWV3b3JrRWxlbWVudFwiXSA9IHRoaXM7XHJcbkFwcGxpY2F0aW9uLkN1cnJlbnQuUmVzb3VyY2VzW1wiQWxsUmVhZHlcIl0gPSBBbGxSZWFkeTtcclxuU3RyaW5nIG9yaWdpbmFsID0gSHRtbFBhZ2UuRG9jdW1lbnQuRG9jdW1lbnRVcmkuT3JpZ2luYWxTdHJpbmc7XHJcbkFwcGxpY2F0aW9uLkN1cnJlbnQuUmVzb3VyY2VzW1wiT3JpZ2luYWxVUkxcIl0gPSBvcmlnaW5hbDtcclxuU3RyaW5nIGNvbm5lY3Rpb247XHJcbkRpY3Rpb25hcnk8c3RyaW5nLHN0cmluZz4gYXBwcyA9IFV0aWxzLkdldEFwcHNSZXNvdXJjZShcIlFXQ1wiLFwid2ViZGV0YWlscy5odG1sXCIpO1xyXG5jb25uZWN0aW9uID0gVXRpbHMuR2V0QXBwUmVzb3VyY2UoYXBwcywgXCJDb25uZWN0aW9uXCIpO1xyXG5pZiAoMCA9PSBjb25uZWN0aW9uLkxlbmd0aCkge1xyXG5jb25uZWN0aW9uID0gKFN0cmluZylBcHBsaWNhdGlvbi5DdXJyZW50LlRyeUZpbmRSZXNvdXJjZShcIkNvbm5lY3Rpb25cIik7XHJcbn0gXHJcblN0cmluZyBjb25uZWN0aW9udHlwZSA9IFV0aWxzLkdldEFwcFJlc291cmNlKGFwcHMsIFwiQ29ubmVjdGlvblR5cGVcIik7XHJcbmlmICgwID09IGNvbm5lY3Rpb250eXBlLkxlbmd0aCkgeyBcclxuY29ubmVjdGlvbnR5cGUgPSAoU3RyaW5nKUFwcGxpY2F0aW9uLkN1cnJlbnQuVHJ5RmluZFJlc291cmNlKFwiQ29ubmVjdGlvblR5cGVcIik7XHJcbn0gXHJcbnN0cmluZyB1cGxvYWRob3N0ID0gVXRpbHMuR2V0QXBwUmVzb3VyY2UoYXBwcywgXCJVcGxvYWRIb3N0XCIpO1xyXG5pZiAobnVsbCA9PSB1cGxvYWRob3N0IHx8IDAgPT0gdXBsb2FkaG9zdC5MZW5ndGgpIHtcclxudXBsb2FkaG9zdCA9IChTdHJpbmcpQXBwbGljYXRpb24uQ3VycmVudC5UcnlGaW5kUmVzb3VyY2UoXCJVcGxvYWRIb3N0XCIpO1xyXG5pZiAobnVsbCA9PSB1cGxvYWRob3N0IHx8IDAgPT0gdXBsb2FkaG9zdC5MZW5ndGgpIHVwbG9hZGhvc3QgPSBcImxvY2FsaG9zdFwiO1xyXG59IFxyXG5BcHBsaWNhdGlvbi5DdXJyZW50LlJlc291cmNlc1tcIlVwbG9hZEhvc3RcIl0gPSB1cGxvYWRob3N0O1xyXG5zdHJpbmcgdXBsb2FkcG9ydCA9IFV0aWxzLkdldEFwcFJlc291cmNlKGFwcHMsIFwiVXBsb2FkUG9ydFwiKTtcclxuaWYgKG51bGwgPT0gdXBsb2FkcG9ydCB8fCAwID09IHVwbG9hZHBvcnQuTGVuZ3RoKSB7XHJcbnVwbG9hZHBvcnQgPSAoU3RyaW5nKUFwcGxpY2F0aW9uLkN1cnJlbnQuVHJ5RmluZFJlc291cmNlKFwiVXBsb2FkUG9ydFwiKTtcclxuaWYgKG51bGwgPT0gdXBsb2FkcG9ydCB8fCAwID09IHVwbG9hZHBvcnQuTGVuZ3RoKSB1cGxvYWRwb3J0ID0gXCIxMjM0XCI7XHJcbn0gXHJcbkFwcGxpY2F0aW9uLkN1cnJlbnQuUmVzb3VyY2VzW1wiVXBsb2FkUG9ydFwiXSA9IHVwbG9hZHBvcnQ7XHJcbnN0cmluZyB1cGxvYWRzZWN1cmUgPSBVdGlscy5HZXRBcHBSZXNvdXJjZShhcHBzLCBcIlVwbG9hZFNlY3VyZVwiKTtcclxuaWYgKG51bGwgPT0gdXBsb2Fkc2VjdXJlIHx8IDAgPT0gdXBsb2Fkc2VjdXJlLkxlbmd0aCkge1xyXG51cGxvYWRzZWN1cmUgPSAoU3RyaW5nKUFwcGxpY2F0aW9uLkN1cnJlbnQuVHJ5RmluZFJlc291cmNlKFwiVXBsb2FkU2VjdXJlXCIpO1xyXG5pZiAobnVsbCA9PSB1cGxvYWRzZWN1cmUgfHwgMCA9PSB1cGxvYWRzZWN1cmUuTGVuZ3RoKSB1cGxvYWRzZWN1cmUgPSBcIjBcIjtcclxufSBcclxuQXBwbGljYXRpb24uQ3VycmVudC5SZXNvdXJjZXNbXCJVcGxvYWRTZWN1cmVcIl0gPSB1cGxvYWRzZWN1cmU7XHJcbnN0cmluZyBuYW1lID0gVXRpbHMuR2V0QXBwUmVzb3VyY2UoYXBwcywgXCJOYW1lXCIpO1xyXG5pZiAoMCA9PSBuYW1lLkxlbmd0aCkge1xyXG5uYW1lID0gKFN0cmluZylBcHBsaWNhdGlvbi5DdXJyZW50LlJlc291cmNlc1tcIk5hbWVcIl07XHJcbn0gXHJcbnN0cmluZyBXU25hbWUgPSBVdGlscy5HZXRBcHBSZXNvdXJjZShhcHBzLCBcIldTTmFtZVwiKTtcclxuaWYgKDAgPT0gV1NuYW1lLkxlbmd0aCkge1xyXG5XU25hbWUgPSAoU3RyaW5nKUFwcGxpY2F0aW9uLkN1cnJlbnQuVHJ5RmluZFJlc291cmNlKFwiV1NOYW1lXCIpO1xyXG59IFxyXG5zdHJpbmcgcG9ydCA9IFV0aWxzLkdldEFwcFJlc291cmNlKGFwcHMsIFwiUG9ydFwiKTtcclxuaWYgKDAgPT0gcG9ydC5MZW5ndGgpIHtcclxucG9ydCA9IChTdHJpbmcpQXBwbGljYXRpb24uQ3VycmVudC5UcnlGaW5kUmVzb3VyY2UoXCJQb3J0XCIpO1xyXG59IFxyXG5pZiAobnVsbCA9PSBXU25hbWUgKSB7IFdTbmFtZSA9IFwiV1NcIjsgfVxyXG5XU25hbWUgPSBXU25hbWUuVHJpbSgpO1xyXG5pZiAoXCJcIiA9PSBXU25hbWUpIHsgV1NuYW1lID0gXCJXU1wiOyB9XHJcbmlmIChXU25hbWUuVG9VcHBlcigpID09IFwiTk9ORVwiKSBXU25hbWUgPSBcIlwiO1xyXG5pZiAobnVsbCA9PSBjb25uZWN0aW9uKSB7IGNvbm5lY3Rpb24gPSBcIlwiOyB9XHJcbmNvbm5lY3Rpb24gPSBjb25uZWN0aW9uLlRyaW0oKTtcclxuaWYgKG51bGwgPT0gY29ubmVjdGlvbnR5cGUpIHsgY29ubmVjdGlvbnR5cGUgPSBcIlwiOyB9XHJcbmNvbm5lY3Rpb250eXBlID0gY29ubmVjdGlvbnR5cGUuVHJpbSgpO1xyXG5pZiAoXCJcIiA9PSBjb25uZWN0aW9udHlwZSkgeyBjb25uZWN0aW9udHlwZSA9IFwiRGlyZWN0XCI7IH1cclxuaWYgKFwiXCIgPT0gY29ubmVjdGlvbikge1xyXG5pZiAoXCJodHRwXCIgPT0gSHRtbFBhZ2UuRG9jdW1lbnQuRG9jdW1lbnRVcmkuU2NoZW1lKSBjb25uZWN0aW9uID0gSHRtbFBhZ2UuRG9jdW1lbnQuRG9jdW1lbnRVcmkuSG9zdDtcclxuZWxzZSBjb25uZWN0aW9uID0gXCJsb2NhbGhvc3RcIjtcclxuIH1cclxuc3RyaW5nIGFwcG5hbWUgPSBVdGlscy5HZXRBcHBSZXNvdXJjZShhcHBzLCBcIkFwcE5hbWVcIik7XHJcbmlmICgwID09IGFwcG5hbWUuTGVuZ3RoKSBhcHBuYW1lID0gKFN0cmluZylBcHBsaWNhdGlvbi5DdXJyZW50LlRyeUZpbmRSZXNvdXJjZShcIkFwcE5hbWVcIik7XHJcbmlmIChudWxsID09IGFwcG5hbWUpIGFwcG5hbWUgPSBuYW1lO1xyXG5pZiAoXCJcIiA9PSBhcHBuYW1lKSBhcHBuYW1lID0gbmFtZTtcclxuQXBwbGljYXRpb24uQ3VycmVudC5SZXNvdXJjZXNbXCJBcHBOYW1lXCJdID0gYXBwbmFtZTtcclxuaWYgKFwiRGlyZWN0XCIgPT0gY29ubmVjdGlvbnR5cGUpIHtcclxuaWYgKG51bGwgPT0gcG9ydCkgeyBwb3J0ID0gXCJcIjsgfVxyXG5zdHJpbmcgdXJpID0gKHN0cmluZykgSW50ZXJvcC5FeGVjdXRlSmF2YVNjcmlwdChcImRvY3VtZW50LmxvY2F0aW9uLnNlYXJjaFwiKTtcclxuaWYgKDAgIT0gdXJpLkxlbmd0aCkge1xyXG5zdHJpbmcgcCA9IFwiXCI7XHJcbmZvcihpbnQgaT0wOyBpIDwgdXJpLkxlbmd0aDsgaSsrKSB7XHJcbmlmICgnPycgIT0gdXJpW2ldKSB7XHJcbmlmICgnMCcgPT0gdXJpW2ldIHx8ICcxJyA9PSB1cmlbaV0gfHwgJzInID09IHVyaVtpXSB8fCAnMycgPT0gdXJpW2ldIHx8ICc0JyA9PSB1cmlbaV0gfHwgJzUnID09IHVyaVtpXSB8fCAnNicgPT0gdXJpW2ldIHx8ICc3JyA9PSB1cmlbaV0gfHwgJzgnID09IHVyaVtpXSB8fCAnOScgPT0gdXJpW2ldKSB7XHJcbnAgKz0gdXJpW2ldO1xyXG59IFxyXG5lbHNlIGJyZWFrO1xyXG59IFxyXG59IFxyXG5pZiAoMCAhPSBwLkxlbmd0aCkgcG9ydCA9IHA7XHJcbn0gXHJcbmlmIChcIlwiID09IHBvcnQpIHsgcG9ydCA9IEh0bWxQYWdlLkRvY3VtZW50LkRvY3VtZW50VXJpLlBvcnQuVG9TdHJpbmcoKTsgfVxyXG5jb25uZWN0aW9uICs9IFwiOlwiICsgcG9ydCArIFwiL1wiICsgbmFtZSArXCIvXCI7XHJcbn0gZWxzZSB7XHJcbmlmICgwICE9IGNvbm5lY3Rpb24uTGVuZ3RoKSB7XHJcbmNvbm5lY3Rpb25wb3J0ID0gVXRpbHMuR2V0QXBwUmVzb3VyY2UoYXBwcywgXCJDb25uZWN0aW9uUG9ydFwiKTtcclxuaWYgKGNvbm5lY3Rpb25wb3J0ID09IG51bGwgfHwgMCA9PSBjb25uZWN0aW9ucG9ydC5MZW5ndGgpIGNvbm5lY3Rpb25wb3J0ID0gKFN0cmluZylBcHBsaWNhdGlvbi5DdXJyZW50LlRyeUZpbmRSZXNvdXJjZShcIkNvbm5lY3Rpb25Qb3J0XCIpO1xyXG5pZiAoY29ubmVjdGlvbnBvcnQgIT0gbnVsbCAmJiAwICE9IGNvbm5lY3Rpb25wb3J0Lkxlbmd0aCkgY29ubmVjdGlvbiArPSBcIjpcIiArIGNvbm5lY3Rpb25wb3J0O1xyXG59IFxyXG5jb25uZWN0aW9uICs9IFwiL1wiICsgV1NuYW1lO1xyXG5pZiAoMCAhPSBXU25hbWUuTGVuZ3RoKSBjb25uZWN0aW9uICs9IFwiL1wiO1xyXG59IFxyXG5zdHJpbmcgc2VjdXJlY29ubmVjdGlvbiA9IFV0aWxzLkdldEFwcFJlc291cmNlKGFwcHMsIFwiU2VjdXJlQ29ubmVjdGlvblwiKTtcclxuaWYgKG51bGwgPT0gc2VjdXJlY29ubmVjdGlvbiB8fCAwID09IHNlY3VyZWNvbm5lY3Rpb24uTGVuZ3RoKSB7XHJcbnNlY3VyZWNvbm5lY3Rpb24gPSAoU3RyaW5nKUFwcGxpY2F0aW9uLkN1cnJlbnQuVHJ5RmluZFJlc291cmNlKFwiU2VjdXJlQ29ubmVjdGlvblwiKTtcclxuaWYgKG51bGwgPT0gc2VjdXJlY29ubmVjdGlvbiB8fCAwID09IHNlY3VyZWNvbm5lY3Rpb24uTGVuZ3RoKSBzZWN1cmVjb25uZWN0aW9uID0gXCIwXCI7XHJcbn0gXHJcbkFwcGxpY2F0aW9uLkN1cnJlbnQuUmVzb3VyY2VzW1wiU2VjdXJlQ29ubmVjdGlvblwiXSA9IHNlY3VyZWNvbm5lY3Rpb247XHJcbmlmIChzZWN1cmVjb25uZWN0aW9uID09IFwiMVwiKSBjb25uZWN0aW9uID0gXCJ3c3M6Ly9cIiArIGNvbm5lY3Rpb247XHJcbmVsc2UgY29ubmVjdGlvbiA9IFwid3M6Ly9cIiArIGNvbm5lY3Rpb247XHJcbldTSW50ZXJuYWxzIF9XU0ludGVybmFscyA9IEFQTC5NYWtlSW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLFwiV1NJbnRlcm5hbHNcIixcIldTSW50ZXJuYWxzXCIsdGhpcykgYXMgV1NJbnRlcm5hbHM7XHJcbnF3Y19Sb290IF9xd2NfUm9vdCA9IEFQTC5NYWtlSW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLFwicXdjX1Jvb3RcIixcInF3Y19Sb290XCIsdGhpcykgYXMgcXdjX1Jvb3Q7XHJcbi8vIFJhbmRvbSBybmQgPSBuZXcgUmFuZG9tKEd1aWQuTmV3R3VpZCgpLkdldEhhc2hDb2RlKCkpO1xyXG5SYW5kb20gcm5kID0gbmV3IFJhbmRvbSgpO1xyXG5zdHJpbmcgcm5kcyA9IHJuZC5OZXh0KCkuVG9TdHJpbmcoKTtcclxud2ViU29ja2V0ID0gbmV3IENTSFRNTDUuRXh0ZW5zaW9ucy5XZWJTb2NrZXRzLldlYlNvY2tldChjb25uZWN0aW9uICsgXCI/aGFzaD1cIiArIHJuZHMpO1xyXG5kaXJlY3R3ZWJTb2NrZXQgPSBuZXcgQ1NIVE1MNS5FeHRlbnNpb25zLldlYlNvY2tldHMuV2ViU29ja2V0KGNvbm5lY3Rpb24gKyBcIj9oYXNoPVwiICsgcm5kcyk7XHJcbkFwcGxpY2F0aW9uLkN1cnJlbnQuUmVzb3VyY2VzW1wiV2ViU29ja2V0XCJdID0gd2ViU29ja2V0O1xyXG5BcHBsaWNhdGlvbi5DdXJyZW50LlJlc291cmNlc1tcIkRpcmVjdFdlYlNvY2tldFwiXSA9IGRpcmVjdHdlYlNvY2tldDtcclxuVHJhbnNmZXJTdHJpbmcgeHN0cmluZztcclxuc3RyaW5nIGQgPSBcIlwiO1xyXG53ZWJTb2NrZXQuT25NZXNzYWdlKz0gYXN5bmMgKHMsIGUpID0+e1xyXG5pZiAoU2V0dXBDb21wbGV0ZVJ1bikge1xyXG5TZXR1cENvbXBsZXRlUnVuID0gZmFsc2U7XHJcbkNoZWNrRmlsZUxvYWRpbmcoKTtcclxuYXdhaXQgRmlsZXNSZWFkeTtcclxuRW5kQ3VzdG9tQ1NTKCk7XHJcbn0gXHJcbnN0cmluZ1tdIGRhdGEgPSAoc3RyaW5nW10pVEQuU3BsaXQoZS5EYXRhLCBURC5kZWxpbXM1KTtcclxuZm9yIChpbnQgaSA9IDA7IGkgPCBkYXRhLkxlbmd0aDsgaSsrKSB7XHJcblRyYW5zZmVyU3RyaW5nIGRzPVRELlRvVHJhbnNmZXJTdHJpbmcoZGF0YVtpXSk7XHJcbnN0cmluZyB0cmFucyA9IGRzLlRyYW5zO1xyXG5pZiAoZHMuQWN0aW9uID09IFwiV2FpdEZvclF1ZXVlXCIpIHtcclxud2ViU29ja2V0LlNlbmQoZGF0YVtpXSk7XHJcbn0gZWxzZSBpZiAoZHMuQWN0aW9uID09IFwiTUpIX0Nsb3NlU2VydmVyXCIpIHtcclxud2ViU29ja2V0LlNlbmQoZGF0YVtpXSk7XHJcbn0gZWxzZSBpZiAoZHMuQWN0aW9uID09IFwiUGluZ1wiKSB7XHJcbndlYlNvY2tldC5TZW5kKGRhdGFbaV0pO1xyXG59IGVsc2UgaWYgKGRzLkFjdGlvbiA9PSBcIkxvYWRlZFwiKSB7XHJcbkFwcGxpY2F0aW9uLkN1cnJlbnQuUmVzb3VyY2VzW1wiSW5kZXhcIl0gPSBkcy5EYXRhO1xyXG53ZWJTb2NrZXRSZWFkeS5TZXRSZXN1bHQodHJ1ZSk7XHJcbl9XU0ludGVybmFscy5TdGF0dXMgPSBcIldlYlNvY2tldCBPcGVuZWQgXCI7XHJcbkFsbFJlYWR5ID0gdHJ1ZTtcclxuQXBwbGljYXRpb24uQ3VycmVudC5SZXNvdXJjZXNbXCJBbGxSZWFkeVwiXSA9IEFsbFJlYWR5O1xyXG50aGlzLkluaXRpYWxpemVDb21wb25lbnQoKTtcclxuTWFrZVdpblNpemUoX3F3Y19Sb290LF9XU0ludGVybmFscyk7XHJcbl9xd2NfUm9vdC5Ob3RpZnlQcm9wZXJ0eUNoYW5nZWQoXCJGb250TGlzdFwiKTtcclxuX3F3Y19Sb290Lk5vdGlmeVByb3BlcnR5Q2hhbmdlZChcIkZvbnRGYW1pbHlcIik7XHJcbl9xd2NfUm9vdC5Ob3RpZnlQcm9wZXJ0eUNoYW5nZWQoXCJDYXB0aW9uXCIpO1xyXG5fcXdjX1Jvb3QuTm90aWZ5UHJvcGVydHlDaGFuZ2VkKFwiVVJMXCIpO1xyXG5fcXdjX1Jvb3QuTm90aWZ5UHJvcGVydHlDaGFuZ2VkKFwiVVJMU1wiKTtcclxuX3F3Y19Sb290Lk5vdGlmeVByb3BlcnR5Q2hhbmdlZChcIkNhcHRpb25zXCIpO1xyXG5JbnRlcm9wLkV4ZWN1dGVKYXZhU2NyaXB0KFwibG9hZEZvbnQoJDAsJDEpXCIsXCJBUEwzODVcIixcImFwcC1jc2h0bWw1L3Jlcy9RV0MvZm9udHMvYXBsMzg1LXdlYmZvbnQud29mZlwiKTtcclxuTGlzdDxzdHJpbmc+IGZ1bGxmb250ID0gZ2xvYmFsOjpCcmlkZ2UuU2NyaXB0LkNhbGxGb3IobmV3IExpc3Q8c3RyaW5nPigpLChfbzEpPT57X28xLkFkZChcIkFQTDM4NVwiKTtfbzEuQWRkKFwiQW5kYWzDqSBNb25vXCIpO19vMS5BZGQoXCJBcmlhbFwiKTtfbzEuQWRkKFwiQXJpYWwgQmxhY2tcIik7X28xLkFkZChcIkFyaWFsIE5hcnJvd1wiKTtfbzEuQWRkKFwiQXJpYWwgUm91bmRlZCBNVCBCb2xkXCIpO19vMS5BZGQoXCJCYXNrZXJ2aWxsZVwiKTtfbzEuQWRkKFwiQm9kb25pIDcyXCIpO19vMS5BZGQoXCJCb2RvbmkgTVRcIik7X28xLkFkZChcIkJyYWRsZXkgSGFuZFwiKTtfbzEuQWRkKFwiQnJ1c2ggU2NyaXB0IE1UXCIpO19vMS5BZGQoXCJDYWxpYnJpXCIpO19vMS5BZGQoXCJDYWxpc3RvIE1UXCIpO19vMS5BZGQoXCJDYW1icmlhXCIpO19vMS5BZGQoXCJDYW5kYXJhXCIpO19vMS5BZGQoXCJDZW50dXJ5IEdvdGhpY1wiKTtfbzEuQWRkKFwiQ29taWMgU2FucyBNU1wiKTtfbzEuQWRkKFwiQ29uc29sYXNcIik7X28xLkFkZChcIkNvcHBlcnBsYXRlIEdvdGhpY1wiKTtfbzEuQWRkKFwiQ291cmllclwiKTtfbzEuQWRkKFwiQ291cmllciBOZXdcIik7X28xLkFkZChcIkRlamF2dSBTYW5zXCIpO19vMS5BZGQoXCJEaWRvdFwiKTtfbzEuQWRkKFwiRnJhbmtsaW4gR290aGljXCIpO19vMS5BZGQoXCJHYXJhbW9uZFwiKTtfbzEuQWRkKFwiR2VvcmdpYVwiKTtfbzEuQWRkKFwiR2lsbCBTYW5zXCIpO19vMS5BZGQoXCJHb3VkeSBPbGQgU3R5bGVcIik7X28xLkFkZChcIkhlbHZldGljYVwiKTtfbzEuQWRkKFwiSGVsdmV0aWNhIE5ldVwiKTtfbzEuQWRkKFwiSW1wYWN0XCIpO19vMS5BZGQoXCJMdWNpZGFcIik7X28xLkFkZChcIkx1Y2lkYSBCcmlnaHRcIik7X28xLkFkZChcIkx1Y2lkYSBIYW5kd3JpdGluZ1wiKTtfbzEuQWRkKFwiTHVjaWRhIFNhbnNcIik7X28xLkFkZChcIkx1bWluYXJpXCIpO19vMS5BZGQoXCJNaWNyb3NvZnQgU2FucyBTZXJpZlwiKTtfbzEuQWRkKFwiTW9uYWNvXCIpO19vMS5BZGQoXCJPcHRpbWFcIik7X28xLkFkZChcIlBhbGF0aW5vXCIpO19vMS5BZGQoXCJQZXJwZXR1YVwiKTtfbzEuQWRkKFwiUmFnZVwiKTtfbzEuQWRkKFwiUm9ja3dlbGxcIik7X28xLkFkZChcIlNjcmlwdCBNVFwiKTtfbzEuQWRkKFwiU2Vnb2UgVUlcIik7X28xLkFkZChcIlNlZ29lIHNjcmlwdFwiKTtfbzEuQWRkKFwiU25lbGwgUm91bmRoYW5kXCIpO19vMS5BZGQoXCJUYWhvbWFcIik7X28xLkFkZChcIlRpbWVzIE5ldyBSb21hblwiKTtfbzEuQWRkKFwiVHJlYnVjaGV0IE1TXCIpO19vMS5BZGQoXCJWZXJkYW5hXCIpO3JldHVybiBfbzE7fSk7XHJcbl9xd2NfUm9vdC5NSkhfRm9udExpc3RfU2hhcGVbMF0gPSA1MTtcclxuX3F3Y19Sb290Lk1KSF9Gb250TGlzdF9TaGFwZVsxXSA9IDg7XHJcbl9xd2NfUm9vdC5NSkhfRm9udEZhbWlseV9TaGFwZSA9IDUxO1xyXG5MaXN0PExpc3Q8QVBMSXRlbT4+IGYgPSBuZXcgTGlzdDxMaXN0PEFQTEl0ZW0+PigpO1xyXG5mb3IgKGludCByID0gMDtyPDUxOyByKyspIHtcclxuZi5BZGQobmV3IExpc3Q8QVBMSXRlbT4oKSk7XHJcbmZbcl0uQWRkKG5ldyBBUExJdGVtKGZ1bGxmb250W3JdKSk7XHJcbmZbcl0uQWRkKG5ldyBBUExJdGVtKDApKTtcclxuZltyXS5BZGQobmV3IEFQTEl0ZW0oMCkpO1xyXG5mW3JdLkFkZChuZXcgQVBMSXRlbSgwKSk7XHJcbmZbcl0uQWRkKG5ldyBBUExJdGVtKDApKTtcclxuZltyXS5BZGQobmV3IEFQTEl0ZW0oMCkpO1xyXG5mW3JdLkFkZChuZXcgQVBMSXRlbSgwKSk7XHJcbmZbcl0uQWRkKG5ldyBBUExJdGVtKDApKTtcclxufSBcclxuX3F3Y19Sb290LkZvbnRMaXN0ID0gZjtcclxuX3F3Y19Sb290LkZvbnRGYW1pbHkgPSAgZ2xvYmFsOjpCcmlkZ2UuU2NyaXB0LkNhbGxGb3IobmV3IExpc3Q8c3RyaW5nPigpLChfbzIpPT57X28yLkFkZChcIkFQTDM4NVwiKTtfbzIuQWRkKFwiQW5kYWzDqSBNb25vLCBtb25vc3BhY2VcIik7X28yLkFkZChcIkFyaWFsLCBIZWx2ZXRpY2EgTmV1ZSwgSGVsdmV0aWNhLCBzYW5zLXNlcmlmXCIpO19vMi5BZGQoXCJBcmlhbCBCbGFjaywgQXJpYWwgQm9sZCwgR2FkZ2V0LCBzYW5zLXNlcmlmXCIpO19vMi5BZGQoXCJBcmlhbCBOYXJyb3csIEFyaWFsLCBzYW5zLXNlcmlmXCIpO19vMi5BZGQoXCJBcmlhbCBSb3VuZGVkIE1UIEJvbGQsIEhlbHZldGljYSBSb3VuZGVkLCBBcmlhbCwgc2Fucy1zZXJpZlwiKTtfbzIuQWRkKFwiQmFza2VydmlsbGUsIEJhc2tlcnZpbGxlIE9sZCBGYWNlLCBHYXJhbW9uZCwgVGltZXMgTmV3IFJvbWFuLCBzZXJpZlwiKTtfbzIuQWRkKFwiQm9kb25pIDcyLCBCb2RvbmkgTVQsIERpZG90LCBEaWRvdCBMVCBTVEQsIEhvZWZsZXIgVGV4dCwgR2FyYW1vbmQsIFRpbWVzIE5ldyBSb21hbiwgc2VyaWZcIik7X28yLkFkZChcIkJvZG9uaSBNVCwgQm9kb25pIDcyLCBEaWRvdCwgRGlkb3QgTFQgU1RELCBIb2VmbGVyIFRleHQsIEdhcmFtb25kLCBUaW1lcyBOZXcgUm9tYW4sIHNlcmlmXCIpO19vMi5BZGQoXCJCcmFkbGV5IEhhbmQsIGN1cnNpdmVcIik7X28yLkFkZChcIkJydXNoIFNjcmlwdCBNVCwgY3Vyc2l2ZVwiKTtfbzIuQWRkKFwiQ2FsaWJyaSwgQ2FuZGFyYSwgU2Vnb2UsIFNlZ29lIFVJLCBPcHRpbWEsIEFyaWFsLCBzYW5zLXNlcmlmXCIpO19vMi5BZGQoXCJDYWxpc3RvIE1ULCBCb29rbWFuIE9sZCBTdHlsZSwgQm9va21hbiwgR291ZHkgT2xkIFN0eWxlLCBHYXJhbW9uZCwgSG9lZmxlciBUZXh0LCBCaXRzdHJlYW0gQ2hhcnRlciwgR2VvcmdpYSwgc2VyaWZcIik7X28yLkFkZChcIkNhbWJyaWEsIEdlb3JnaWEsIHNlcmlmXCIpO19vMi5BZGQoXCJDYW5kYXJhLCBDYWxpYnJpLCBTZWdvZSwgU2Vnb2UgVUksIE9wdGltYSwgQXJpYWwsIHNhbnMtc2VyaWZcIik7X28yLkFkZChcIkNlbnR1cnkgR290aGljLCBDZW50dXJ5R290aGljLCBBcHBsZUdvdGhpYywgc2Fucy1zZXJpZlwiKTtfbzIuQWRkKFwiQ29taWMgU2FucyBNUywgY3Vyc2l2ZVwiKTtfbzIuQWRkKFwiQ29uc29sYXMsIG1vbmFjbywgbW9ub3NwYWNlXCIpO19vMi5BZGQoXCJDb3BwZXJwbGF0ZSBHb3RoaWMsIENvcHBlcnBsYXRlIEdvdGhpYyBMaWdodCwgZmFudGFzeVwiKTtfbzIuQWRkKFwiQ291cmllciwgbW9ub3NwYWNlXCIpO19vMi5BZGQoXCJDb3VyaWVyIE5ldywgQ291cmllciwgTHVjaWRhIFNhbnMgVHlwZXdyaXRlciwgTHVjaWRhIFR5cGV3cml0ZXIsIG1vbm9zcGFjZVwiKTtfbzIuQWRkKFwiRGVqYXZ1IFNhbnMsIEFyaWFsLCBWZXJkYW5hLCBzYW5zLXNlcmlmXCIpO19vMi5BZGQoXCJEaWRvdCwgRGlkb3QgTFQgU1RELCBIb2VmbGVyIFRleHQsIEdhcmFtb25kLCBDYWxpc3RvIE1ULCBUaW1lcyBOZXcgUm9tYW4sIHNlcmlmXCIpO19vMi5BZGQoXCJGcmFua2xpbiBHb3RoaWMsIEFyaWFsIEJvbGQsIEFyaWFsLCBzYW5zLXNlcmlmXCIpO19vMi5BZGQoXCJHYXJhbW9uZCwgQmFza2VydmlsbGUsIEJhc2tlcnZpbGxlIE9sZCBGYWNlLCBIb2VmbGVyIFRleHQsIFRpbWVzIE5ldyBSb21hbiwgc2VyaWZcIik7X28yLkFkZChcIkdlb3JnaWEsIFRpbWVzLCBUaW1lcyBOZXcgUm9tYW4sIHNlcmlmXCIpO19vMi5BZGQoXCJHaWxsIFNhbnMsIEdpbGwgU2FucyBNVCwgQ2FsaWJyaSwgc2Fucy1zZXJpZlwiKTtfbzIuQWRkKFwiR291ZHkgT2xkIFN0eWxlLCBHYXJhbW9uZCwgQmlnIENhc2xvbiwgVGltZXMgTmV3IFJvbWFuLCBzZXJpZlwiKTtfbzIuQWRkKFwiSGVsdmV0aWNhLCBIZWx2ZXRpY2EgTmV1LCBBcmlhbCwgc2Fucy1zZXJpZi5cIik7X28yLkFkZChcIkhlbHZldGljYSBOZXUsIEhlbHZldGljYSwgQXJpYWwsIHNhbnMtc2VyaWYuXCIpO19vMi5BZGQoXCJJbXBhY3QsIENoYXJjb2FsLCBIZWx2ZXRpY2EgSW5zZXJhdCwgQml0c3RyZWFtIFZlcmEgU2FucyBCb2xkLCBBcmlhbCBCbGFjaywgc2Fucy1zZXJpZi5cIik7X28yLkFkZChcIkx1Y2lkYSwgbW9ub3NwYWNlXCIpO19vMi5BZGQoXCJMdWNpZGEgQnJpZ2h0LCBHZW9yZ2lhLCBzZXJpZi5cIik7X28yLkFkZChcIkx1Y2lkYSBIYW5kd3JpdGluZywgY3Vyc2l2ZVwiKTtfbzIuQWRkKFwiTHVjaWRhIFNhbnMsIEhlbHZldGljYSwgQXJpYWwsIHNhbnMtc2VyaWYuXCIpO19vMi5BZGQoXCJMdW1pbmFyaSwgZmFudGFzeVwiKTtfbzIuQWRkKFwiTWljcm9zb2Z0IFNhbnMgU2VyaWYsIHNhbnMtc2VyaWYuXCIpO19vMi5BZGQoXCJNb25hY28sIG1vbm9zcGFjZVwiKTtfbzIuQWRkKFwiT3B0aW1hLCBTZWdvZSwgU2Vnb2UgVUksIENhbmRhcmEsIENhbGlicmksIEFyaWFsLCBzYW5zLXNlcmlmLlwiKTtfbzIuQWRkKFwiUGFsYXRpbm8sIFBhbGF0aW5vIExpbm90eXBlLCBQYWxhdGlubyBMVCBTVEQsIEJvb2sgQW50aXF1YSwgR2VvcmdpYSwgc2VyaWYuXCIpO19vMi5BZGQoXCJQZXJwZXR1YSwgQmFza2VydmlsbGUsIEJpZyBDYXNsb24sIFBhbGF0aW5vIExpbm90eXBlLCBQYWxhdGlubywgc2VyaWYuXCIpO19vMi5BZGQoXCJSYWdlLCBjdXJzaXZlXCIpO19vMi5BZGQoXCJSb2Nrd2VsbCwgQ291cmllciBCb2xkLCBDb3VyaWVyLCBHZW9yZ2lhLCBUaW1lcywgVGltZXMgTmV3IFJvbWFuLCBzZXJpZi5cIik7X28yLkFkZChcIlNjcmlwdCBNVCwgY3Vyc2l2ZVwiKTtfbzIuQWRkKFwiU2Vnb2UgVUksIEZydXRpZ2VyLCBEZWphdnUgU2FucywgSGVsdmV0aWNhIE5ldWUsIEFyaWFsLCBzYW5zLXNlcmlmLlwiKTtfbzIuQWRkKFwiU2Vnb2Ugc2NyaXB0LCBjdXJzaXZlXCIpO19vMi5BZGQoXCJTbmVsbCBSb3VuZGhhbmQsIGN1cnNpdmVcIik7X28yLkFkZChcIlRhaG9tYSwgVmVyZGFuYSwgU2Vnb2UsIHNhbnMtc2VyaWYuXCIpO19vMi5BZGQoXCJUaW1lcyBOZXcgUm9tYW4sIEdlb3JnaWEsIHNlcmlmO1wiKTtfbzIuQWRkKFwiVHJlYnVjaGV0IE1TLCBMdWNpZGEgR3JhbmRlLCBMdWNpZGEgU2FucyBVbmljb2RlLCBMdWNpZGEgU2Fucywgc2Fucy1zZXJpZi5cIik7X28yLkFkZChcIlZlcmRhbmEsIEdlbmV2YSwgc2Fucy1zZXJpZi5cIik7cmV0dXJuIF9vMjt9KTtcclxuX3F3Y19Sb290Lk5vdGlmeVByb3BlcnR5Q2hhbmdlZChcIkZvbnRMaXN0XCIpO1xyXG5fcXdjX1Jvb3QuTm90aWZ5UHJvcGVydHlDaGFuZ2VkKFwiRm9udEZhbWlseVwiKTtcclxueHN0cmluZyA9IG5ldyBUcmFuc2ZlclN0cmluZygpO1xyXG54c3RyaW5nLlR5cGUgPSBcIlNldHVwQ29tcGxldGVcIjtcclxuU2V0dXBDb21wbGV0ZVJ1biA9IHRydWU7XHJcbmQgPSBURC5Gcm9tVHJhbnNmZXJTdHJpbmcoeHN0cmluZyk7XHJcbndlYlNvY2tldC5TZW5kKGQpO1xyXG52YXIgZWxlbSA9IEludGVyb3AuRXhlY3V0ZUphdmFTY3JpcHQoXCJkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgkMCk7XCIsXCJtamhzcGxhc2hzY3JlZW5cIik7XHJcbkludGVyb3AuRXhlY3V0ZUphdmFTY3JpcHQoXCIkMC5zdHlsZSA9ICQxO1wiLCBlbGVtLCBcImRpc3BsYXk6IG5vbmU7XCIpO1xyXG59IGVsc2UgaWYgKGRzLkFjdGlvbiA9PSBcIkNyZWF0ZVwiKSB7ICAvLyBxV0NcclxuRW5kQ3VzdG9tQ1NTKCk7XHJcbmRzLk5hbWUgPSBcIlR5cGVcIjtcclxuZHMuRGF0YSA9IGRzLkNsYXNzLlN1YnN0cmluZygzKTtcclxuaWYgKGRzLkNsYXNzID09IFwicXdjQnV0dG9uXCIgfHxkcy5DbGFzcyA9PSBcInF3Y0NvbWJvXCIgfHxkcy5DbGFzcyA9PSBcInF3Y0RhdGVUaW1lUGlja2VyXCIgfHxkcy5DbGFzcyA9PSBcInF3Y01zZ0JveFwiIHx8ZHMuQ2xhc3MgPT0gXCJxd2NFZGl0XCIgfHxkcy5DbGFzcyA9PSBcInF3Y0xpc3RcIiB8fGRzLkNsYXNzID09IFwicXdjTGlzdFZpZXdTaW5nbGVcIiB8fGRzLkNsYXNzID09IFwicXdjTGlzdFZpZXdNdWx0aVwiIHx8ZHMuQ2xhc3MgPT0gXCJxd2NNZW51SXRlbVwiIHx8ZHMuQ2xhc3MgPT0gXCJxd2NUYWJDb250cm9sXCIgKSB7XHJcbmRzLkNsYXNzICs9IGRzLkV4dHJhcztcclxufVxyXG5zdHJpbmcgY2wgPSBkcy5DbGFzcyArIFwiX0RhdGFcIjtcclxub2JqZWN0IG8gPSBBUEwuTWFrZUluc3RhbmNlKFwiRGF0YUJpbmRpbmdcIiwgY2wsIGRzLkluc3RhbmNlLCB0aGlzKTtcclxueHN0cmluZyA9IG5ldyBUcmFuc2ZlclN0cmluZygpO1xyXG54c3RyaW5nLlRyYW5zID0gdHJhbnM7XHJcbmQgPSBURC5Gcm9tVHJhbnNmZXJTdHJpbmcoeHN0cmluZyk7XHJcbndlYlNvY2tldC5TZW5kKGQpO1xyXG59IGVsc2UgaWYgKGRzLkFjdGlvbiA9PSBcIkVuZFJ1bkxvYWRlZFwiKSB7XHJcbkNyZWF0ZUNvbnRyb2woZHMpO1xyXG59IGVsc2UgaWYgKGRzLkFjdGlvbiA9PSBcIk9sZENyZWF0ZVwiKSB7ICAvLyBxV0NcclxuZHMuTmFtZSA9IFwiVHlwZVwiO1xyXG5kcy5EYXRhID0gZHMuQ2xhc3MuU3Vic3RyaW5nKDMpO1xyXG5pZiAoZHMuQ2xhc3MgPT0gXCJxd2NCdXR0b25cIiB8fGRzLkNsYXNzID09IFwicXdjQ29tYm9cIiB8fGRzLkNsYXNzID09IFwicXdjRGF0ZVRpbWVQaWNrZXJcIiB8fGRzLkNsYXNzID09IFwicXdjTXNnQm94XCIgfHxkcy5DbGFzcyA9PSBcInF3Y0VkaXRcIiB8fGRzLkNsYXNzID09IFwicXdjTGlzdFwiIHx8ZHMuQ2xhc3MgPT0gXCJxd2NMaXN0Vmlld1NpbmdsZVwiIHx8ZHMuQ2xhc3MgPT0gXCJxd2NMaXN0Vmlld011bHRpXCIgfHxkcy5DbGFzcyA9PSBcInF3Y01lbnVJdGVtXCIgfHxkcy5DbGFzcyA9PSBcInF3Y1RhYkNvbnRyb2xcIiApIHtcclxuZHMuQ2xhc3MgKz0gZHMuRXh0cmFzO1xyXG59XHJcbkFzc2VtYmx5IGFzc2VtYmx5ID0gQVBMLkdldEFzc2VtYmx5KFwiRGF0YUJpbmRpbmdcIiwgdGhpcyk7XHJcblR5cGUgdHlwZSA9IGFzc2VtYmx5LkdldFR5cGUoXCJEYXRhQmluZGluZ1wiICsgXCIuXCIgKyBkcy5DbGFzcyk7XHJcbnZhciBvYiA9IEFjdGl2YXRvci5DcmVhdGVJbnN0YW5jZSh0eXBlLGRzKTtcclxuU3RyaW5nIGNsID0gQVBMLkdldENsYXNzQnlOYW1lKGRzLkluc3RhbmNlKTtcclxudmFyIG9iaiA9IEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGNsLCBkcy5JbnN0YW5jZSwgIG9iKTtcclxueHN0cmluZyA9IG5ldyBUcmFuc2ZlclN0cmluZygpO1xyXG54c3RyaW5nLlRyYW5zID0gdHJhbnM7XHJcbmQ9VEQuRnJvbVRyYW5zZmVyU3RyaW5nKHhzdHJpbmcpO1xyXG53ZWJTb2NrZXQuU2VuZChkKTtcclxuZGlyZWN0d2ViU29ja2V0LlNlbmQoZCk7XHJcbn0gZWxzZSBpZiAoZHMuQWN0aW9uID09IFwiQ3JlYXRlQ29udGludWUxXCIpIHtcclxuaWYgKGRzLkNsYXNzID09IFwicXdjQnV0dG9uXCIgfHxkcy5DbGFzcyA9PSBcInF3Y0NvbWJvXCIgfHxkcy5DbGFzcyA9PSBcInF3Y0RhdGVUaW1lUGlja2VyXCIgfHxkcy5DbGFzcyA9PSBcInF3Y01zZ0JveFwiIHx8ZHMuQ2xhc3MgPT0gXCJxd2NFZGl0XCIgfHxkcy5DbGFzcyA9PSBcInF3Y0xpc3RcIiB8fGRzLkNsYXNzID09IFwicXdjTGlzdFZpZXdTaW5nbGVcIiB8fGRzLkNsYXNzID09IFwicXdjTGlzdFZpZXdNdWx0aVwiIHx8ZHMuQ2xhc3MgPT0gXCJxd2NNZW51SXRlbVwiIHx8ZHMuQ2xhc3MgPT0gXCJxd2NUYWJDb250cm9sXCIgKSB7XHJcbmRzLkNsYXNzICs9IGRzLkV4dHJhczsgfVxyXG5Bc3NlbWJseSBhc3NlbWJseSA9IEFQTC5HZXRBc3NlbWJseShcIkRhdGFCaW5kaW5nXCIsIHRoaXMpO1xyXG5TdHJpbmcgY2wgPSBBUEwuR2V0Q2xhc3NCeU5hbWUoZHMuSW5zdGFuY2UpO1xyXG52YXIgb2JqID0gQVBMLkdldEluc3RhbmNlKFwiRGF0YUJpbmRpbmdcIiwgY2wsIGRzLkluc3RhbmNlLCBudWxsKTtcclxuVHlwZSBjbGEgPSBhc3NlbWJseS5HZXRUeXBlKFwiRGF0YUJpbmRpbmdcIiArIFwiLlwiICsgZHMuQ2xhc3MpO1xyXG5NZXRob2RJbmZvIG1ldGhvZCA9IGNsYS5HZXRNZXRob2QoXCJDcmVhdGVDb250aW51ZTFcIik7XHJcbmlmIChtZXRob2QgIT0gbnVsbCkge1xyXG52YXIgYXJndW1lbnRzID0gbmV3IG9iamVjdFtdIHsgZHMgfTtcclxubWV0aG9kLkludm9rZSgoKE1KSF9Db21tb25EYXRhKW9iaikuTUpIX0NsYXNzLCBhcmd1bWVudHMpOyB9XHJcbnhzdHJpbmcgPSBuZXcgVHJhbnNmZXJTdHJpbmcoKTtcclxueHN0cmluZy5UcmFucyA9IHRyYW5zO1xyXG5kID0gVEQuRnJvbVRyYW5zZmVyU3RyaW5nKHhzdHJpbmcpO1xyXG53ZWJTb2NrZXQuU2VuZChkKTtcclxuZGlyZWN0d2ViU29ja2V0LlNlbmQoZCk7XHJcbn0gZWxzZSBpZiAoZHMuQWN0aW9uID09IFwiQ3JlYXRlQ29udGludWUyXCIpIHsgIC8vIFxyXG5pZiAoZHMuQ2xhc3MgPT0gXCJxd2NCdXR0b25cIiB8fGRzLkNsYXNzID09IFwicXdjQ29tYm9cIiB8fGRzLkNsYXNzID09IFwicXdjRGF0ZVRpbWVQaWNrZXJcIiB8fGRzLkNsYXNzID09IFwicXdjTXNnQm94XCIgfHxkcy5DbGFzcyA9PSBcInF3Y0VkaXRcIiB8fGRzLkNsYXNzID09IFwicXdjTGlzdFwiIHx8ZHMuQ2xhc3MgPT0gXCJxd2NMaXN0Vmlld1NpbmdsZVwiIHx8ZHMuQ2xhc3MgPT0gXCJxd2NMaXN0Vmlld011bHRpXCIgfHxkcy5DbGFzcyA9PSBcInF3Y01lbnVJdGVtXCIgfHxkcy5DbGFzcyA9PSBcInF3Y1RhYkNvbnRyb2xcIiApIHtcclxuZHMuQ2xhc3MgKz0gZHMuRXh0cmFzO1xyXG59XHJcbkFzc2VtYmx5IGFzc2VtYmx5ID0gQVBMLkdldEFzc2VtYmx5KFwiRGF0YUJpbmRpbmdcIix0aGlzKTtcclxuU3RyaW5nIGNsID0gQVBMLkdldENsYXNzQnlOYW1lKGRzLkluc3RhbmNlKTtcclxudmFyIG9iaiA9IEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGNsLCBkcy5JbnN0YW5jZSxudWxsKTtcclxuVHlwZSBjbGEgPSBhc3NlbWJseS5HZXRUeXBlKFwiRGF0YUJpbmRpbmdcIiArIFwiLlwiICsgZHMuQ2xhc3MpO1xyXG5NZXRob2RJbmZvIG1ldGhvZCA9IGNsYS5HZXRNZXRob2QoXCJDcmVhdGVDb250aW51ZTJcIik7XHJcbmlmIChtZXRob2QgIT0gbnVsbCkge1xyXG52YXIgYXJndW1lbnRzID0gbmV3IG9iamVjdFtdIHsgZHMgfTtcclxubWV0aG9kLkludm9rZSgoKE1KSF9Db21tb25EYXRhKSBvYmopLk1KSF9DbGFzcywgYXJndW1lbnRzKTtcclxufSBcclxuaWYgKDAhPWRzLkV4dHJhcy5MZW5ndGgpIHtcclxuZHMuTmFtZSA9IFwiU3R5bGVcIjtcclxuZHMuRGF0YSA9IGRzLkV4dHJhcztcclxuVHlwZSB0eXBlY2wgPSBhc3NlbWJseS5HZXRUeXBlKFwiRGF0YUJpbmRpbmdcIiArIFwiLlwiICsgY2wpO1xyXG5NZXRob2RJbmZvIG1ldGhvZDEgPSB0eXBlY2wuR2V0TWV0aG9kKFwiUnVuUHJvcGVydHlDaGFuZ2VkSW5cIik7XHJcbnZhciBhcmd1bWVudHMgPSBuZXcgb2JqZWN0W10geyBkcywgZmFsc2UgfTtcclxubWV0aG9kMS5JbnZva2Uob2JqLCBhcmd1bWVudHMpO1xyXG59IFxyXG54c3RyaW5nID0gbmV3IFRyYW5zZmVyU3RyaW5nKCk7XHJcbnhzdHJpbmcuVHJhbnMgPSB0cmFucztcclxuZD1URC5Gcm9tVHJhbnNmZXJTdHJpbmcoeHN0cmluZyk7XHJcbndlYlNvY2tldC5TZW5kKGQpO1xyXG5kaXJlY3R3ZWJTb2NrZXQuU2VuZChkKTtcclxufSBlbHNlIGlmIChkcy5BY3Rpb24gPT0gXCJFblF1ZXVlXCIpIHsgIC8vIHFOUVxyXG5TdHJpbmcgTlFyZXN1bHQ7XHJcbmRzLkNsYXNzID0gQVBMLkdldENsYXNzQnlOYW1lKGRzLkluc3RhbmNlKTtcclxuaWYgKG51bGwgIT0gZHMuQ2xhc3MpIHtcclxub2JqZWN0IG9iaiA9IEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgdGhpcyk7XHJcbnZhciBhcmd1bWVudHMgPSBuZXcgb2JqZWN0W10geyBkcywgdGhpcyB9O1xyXG5Bc3NlbWJseSBhc3NlbWJseSA9IEFQTC5HZXRBc3NlbWJseShcIlFXQ1wiLCB0aGlzKTtcclxuVHlwZSB0eXBlID0gYXNzZW1ibHkuR2V0VHlwZShcIlFXQ1wiICsgXCIuTlFcIik7XHJcbk1ldGhvZEluZm8gbWV0aG9kID0gdHlwZS5HZXRNZXRob2QoXCJEb1wiICsgZHMuTmFtZSk7XHJcbmlmIChVdGlscy5Jc1N0YXRpYyhtZXRob2QpKSB7XHJcbk5RcmVzdWx0ID0gKFN0cmluZyltZXRob2QuSW52b2tlKG51bGwsIGFyZ3VtZW50cyk7XHJcbn0gZWxzZSB7XHJcbk5RcmVzdWx0ID0gKFN0cmluZyltZXRob2QuSW52b2tlKG9iaiwgYXJndW1lbnRzKTtcclxufSBcclxufSBlbHNlIHtcclxuTlFyZXN1bHQ9XCJGYWxzZVwiO1xyXG59IFxyXG54c3RyaW5nID0gbmV3IFRyYW5zZmVyU3RyaW5nKCk7XHJcbnhzdHJpbmcuVHlwZSA9IFwiRW5RdWV1ZVwiO1xyXG54c3RyaW5nLkRhdGEgPSBOUXJlc3VsdDtcclxueHN0cmluZy5UcmFucyA9IHRyYW5zO1xyXG5kID0gVEQuRnJvbVRyYW5zZmVyU3RyaW5nKHhzdHJpbmcpO1xyXG5kaXJlY3R3ZWJTb2NrZXQuU2VuZChkKTsgICAvLyBQcm9jZXNzIHFOUSBcclxufSBlbHNlIFJ1bkRhdGFCaW5kaW5nKGRzKTtcclxufX07XHJcbndlYlNvY2tldC5PbkVycm9yKz0ocyxlKT0+X1dTSW50ZXJuYWxzLlN0YXR1cz1cIkVSUk9SIDogXCIgKyBlLkRhdGE7XHJcbndlYlNvY2tldC5PbkNsb3NlKz0ocyxlKT0+X1dTSW50ZXJuYWxzLlN0YXR1cz1cIldlYlNvY2tldCBDbG9zZWQgXCI7XHJcbndlYlNvY2tldC5Pbk9wZW4rPShzLGUpPT4ge1xyXG54c3RyaW5nID0gbmV3IFRyYW5zZmVyU3RyaW5nKCk7XHJcbnhzdHJpbmcuVHlwZSA9IFwiU2Vzc2lvblN0YXJ0XCI7XHJcbnhzdHJpbmcuRGF0YSA9IChzdHJpbmcpIEFwcGxpY2F0aW9uLkN1cnJlbnQuUmVzb3VyY2VzW1wiT3JpZ2luYWxVUkxcIl07XHJcbmQgPSBURC5Gcm9tVHJhbnNmZXJTdHJpbmcoeHN0cmluZyk7XHJcbndlYlNvY2tldC5TZW5kKGQpO1xyXG59O1xyXG5kaXJlY3R3ZWJTb2NrZXQuT25PcGVuICs9IGFzeW5jIChzLCBlKSA9PlxyXG57IFxyXG54c3RyaW5nID0gbmV3IFRyYW5zZmVyU3RyaW5nKCk7XHJcbmF3YWl0IFdlYlNvY2tldFJlYWR5O1xyXG54c3RyaW5nLkRhdGEgPSAoc3RyaW5nKSBBcHBsaWNhdGlvbi5DdXJyZW50LlJlc291cmNlc1tcIkluZGV4XCJdOyAgLy8gSW5kZXhcclxueHN0cmluZy5UeXBlID0gXCJJbmRleFwiO1xyXG5zdHJpbmcgZHggPSBURC5Gcm9tVHJhbnNmZXJTdHJpbmcoeHN0cmluZyk7XHJcbmRpcmVjdHdlYlNvY2tldC5TZW5kKGR4KTtcclxufTtcclxuZGlyZWN0d2ViU29ja2V0Lk9uTWVzc2FnZSArPSAocywgZSkgPT4ge1xyXG5UcmFuc2ZlclN0cmluZyBkcyA9IFRELlRvVHJhbnNmZXJTdHJpbmcoZS5EYXRhKTtcclxuc3RyaW5nIHRyYW5zID0gZHMuVHJhbnM7XHJcbmlmIChkcy5BY3Rpb24gPT0gXCJNSkhfQ2xvc2VTZXJ2ZXJcIikge1xyXG5kaXJlY3R3ZWJTb2NrZXQuU2VuZChlLkRhdGEpOyAgIC8vIFByb2Nlc3MgTUpIX0Nsb3NlU2VydmVyXHJcbn0gZWxzZSBpZiAoZHMuQWN0aW9uID09IFwiRW5RdWV1ZVwiKXsgIC8vIHFOUVxyXG5TdHJpbmcgTlFyZXN1bHQ7XHJcbmRzLkNsYXNzID0gQVBMLkdldENsYXNzQnlOYW1lKGRzLkluc3RhbmNlKTtcclxuaWYgKG51bGwgIT0gZHMuQ2xhc3MpIHtcclxub2JqZWN0IG9iaiA9IEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgdGhpcyk7XHJcbnZhciBhcmd1bWVudHMgPSBuZXcgb2JqZWN0W10geyBkcywgdGhpcyB9O1xyXG5Bc3NlbWJseSBhc3NlbWJseSA9IEFQTC5HZXRBc3NlbWJseShcIlFXQ1wiLCB0aGlzKTtcclxuVHlwZSB0eXBlID0gYXNzZW1ibHkuR2V0VHlwZShcIlFXQ1wiICsgXCIuTlFcIik7XHJcbk1ldGhvZEluZm8gbWV0aG9kID0gdHlwZS5HZXRNZXRob2QoXCJEb1wiICsgZHMuTmFtZSk7XHJcbmlmIChVdGlscy5Jc1N0YXRpYyhtZXRob2QpKSB7XHJcbk5RcmVzdWx0ID0gKFN0cmluZyltZXRob2QuSW52b2tlKG51bGwsIGFyZ3VtZW50cyk7XHJcbn0gZWxzZSB7XHJcbk5RcmVzdWx0ID0gKFN0cmluZyltZXRob2QuSW52b2tlKG9iaiwgYXJndW1lbnRzKTtcclxufSBcclxufSBlbHNlIHtcclxuTlFyZXN1bHQgPSBcIkZhbHNlXCI7XHJcbn0gXHJcbnhzdHJpbmcgPSBuZXcgVHJhbnNmZXJTdHJpbmcoKTtcclxueHN0cmluZy5UeXBlID0gXCJFblF1ZXVlXCI7XHJcbnhzdHJpbmcuRGF0YSA9IE5RcmVzdWx0O1xyXG54c3RyaW5nLlRyYW5zID0gdHJhbnM7XHJcbmQgPSBURC5Gcm9tVHJhbnNmZXJTdHJpbmcoeHN0cmluZyk7XHJcbmRpcmVjdHdlYlNvY2tldC5TZW5kKGQpOyAgIC8vIFByb2Nlc3MgcU5RXHJcbn0gZWxzZSBpZiAoZHMuQWN0aW9uID09IFwiUmV0dXJuRXZlbnRcIil7XHJcbkFQTC5SYWlzZUV2ZW50UmV0dXJuZWQoZS5EYXRhKTtcclxufSBcclxufTtcclxufSBcclxuYm9vbCBJc0VKMShzdHJpbmcgaW5wKSB7XHJcbnJldHVybiBmYWxzZTtcclxufSBcclxuYm9vbCBJc0VKMihzdHJpbmcgaW5wKSB7XHJcbmlmIChpbnAgPT0gXCJxd2NBcHBCYXJfRGF0YVwiKSByZXR1cm4gdHJ1ZTtcclxuaWYgKGlucCA9PSBcInF3Y0F2YXRhcl9EYXRhXCIpIHJldHVybiB0cnVlO1xyXG5pZiAoaW5wID09IFwicXdjQmFkZ2VfRGF0YVwiKSByZXR1cm4gdHJ1ZTtcclxuaWYgKGlucCA9PSBcInF3Y0JhckNvZGVfRGF0YVwiKSByZXR1cm4gdHJ1ZTtcclxuaWYgKGlucCA9PSBcInF3Y0JyZWFkQ3J1bWJfRGF0YVwiKSByZXR1cm4gdHJ1ZTtcclxuaWYgKGlucCA9PSBcInF3Y0NhbGVuZGFyX0RhdGFcIikgcmV0dXJuIHRydWU7XHJcbmlmIChpbnAgPT0gXCJxd2NDYXJkX0RhdGFcIikgcmV0dXJuIHRydWU7XHJcbmlmIChpbnAgPT0gXCJxd2NDYXJvdXNlbF9EYXRhXCIpIHJldHVybiB0cnVlO1xyXG5pZiAoaW5wID09IFwicXdjQ2hhcnRfRGF0YVwiKSByZXR1cm4gdHJ1ZTtcclxuaWYgKGlucCA9PSBcInF3Y0NoaXBzX0RhdGFcIikgcmV0dXJuIHRydWU7XHJcbmlmIChpbnAgPT0gXCJxd2NDaXJjdWxhckdhdWdlX0RhdGFcIikgcmV0dXJuIHRydWU7XHJcbmlmIChpbnAgPT0gXCJxd2NDb2xvdXJQaWNrZXJfRGF0YVwiKSByZXR1cm4gdHJ1ZTtcclxuaWYgKGlucCA9PSBcInF3Y0NvbG9yUGlja2VyX0RhdGFcIikgcmV0dXJuIHRydWU7XHJcbmlmIChpbnAgPT0gXCJxd2NDb21ib0Ryb3BfRGF0YVwiKSByZXR1cm4gdHJ1ZTtcclxuaWYgKGlucCA9PSBcInF3Y0NvbWJvRHJvcEVkaXRfRGF0YVwiKSByZXR1cm4gdHJ1ZTtcclxuaWYgKGlucCA9PSBcInF3Y0NvbWJvU2ltcGxlX0RhdGFcIikgcmV0dXJuIHRydWU7XHJcbmlmIChpbnAgPT0gXCJxd2NDb250ZXh0TWVudV9EYXRhXCIpIHJldHVybiB0cnVlO1xyXG5pZiAoaW5wID09IFwicXdjRGFzaEJvYXJkX0RhdGFcIikgcmV0dXJuIHRydWU7XHJcbmlmIChpbnAgPT0gXCJxd2NEYXRhR3JpZF9EYXRhXCIpIHJldHVybiB0cnVlO1xyXG5pZiAoaW5wID09IFwicXdjRGF0YU1hbmFnZXJfRGF0YVwiKSByZXR1cm4gdHJ1ZTtcclxuaWYgKGlucCA9PSBcInF3Y0RhdGVUaW1lUGlja2VyQ29tYm9fRGF0YVwiKSByZXR1cm4gdHJ1ZTtcclxuaWYgKGlucCA9PSBcInF3Y0RpYWdyYW1fRGF0YVwiKSByZXR1cm4gdHJ1ZTtcclxuaWYgKGlucCA9PSBcInF3Y01zZ0JveE1zZ19EYXRhXCIpIHJldHVybiB0cnVlO1xyXG5pZiAoaW5wID09IFwicXdjTXNnQm94SW5mb19EYXRhXCIpIHJldHVybiB0cnVlO1xyXG5pZiAoaW5wID09IFwicXdjTXNnQm94UXVlcnlfRGF0YVwiKSByZXR1cm4gdHJ1ZTtcclxuaWYgKGlucCA9PSBcInF3Y01zZ0JveFdhcm5fRGF0YVwiKSByZXR1cm4gdHJ1ZTtcclxuaWYgKGlucCA9PSBcInF3Y01zZ0JveEVycm9yX0RhdGFcIikgcmV0dXJuIHRydWU7XHJcbmlmIChpbnAgPT0gXCJxd2NEb2N1bWVudEVkaXRvcl9EYXRhXCIpIHJldHVybiB0cnVlO1xyXG5pZiAoaW5wID09IFwicXdjRmlsZU1hbmFnZXJfRGF0YVwiKSByZXR1cm4gdHJ1ZTtcclxuaWYgKGlucCA9PSBcInF3Y0dhbnR0X0RhdGFcIikgcmV0dXJuIHRydWU7XHJcbmlmIChpbnAgPT0gXCJxd2NHcmlkX0RhdGFcIikgcmV0dXJuIHRydWU7XHJcbmlmIChpbnAgPT0gXCJxd2NJbWFnZUVkaXRvcl9EYXRhXCIpIHJldHVybiB0cnVlO1xyXG5pZiAoaW5wID09IFwicXdjTGluZWFyR2F1Z2VfRGF0YVwiKSByZXR1cm4gdHJ1ZTtcclxuaWYgKGlucCA9PSBcInF3Y0ltYWdlX0RhdGFcIikgcmV0dXJuIHRydWU7XHJcbmlmIChpbnAgPT0gXCJxd2NLYW5iYW5fRGF0YVwiKSByZXR1cm4gdHJ1ZTtcclxuaWYgKGlucCA9PSBcInF3Y0xpc3RTaW5nbGVfRGF0YVwiKSByZXR1cm4gdHJ1ZTtcclxuaWYgKGlucCA9PSBcInF3Y0xpc3RNdWx0aV9EYXRhXCIpIHJldHVybiB0cnVlO1xyXG5pZiAoaW5wID09IFwicXdjTGlzdFZpZXdTaW5nbGVfRGF0YVwiKSByZXR1cm4gdHJ1ZTtcclxuaWYgKGlucCA9PSBcInF3Y0xpc3RWaWV3TXVsdGlfRGF0YVwiKSByZXR1cm4gdHJ1ZTtcclxuaWYgKGlucCA9PSBcInF3Y01hcHNfRGF0YVwiKSByZXR1cm4gdHJ1ZTtcclxuaWYgKGlucCA9PSBcInF3Y01lbnRpb25fRGF0YVwiKSByZXR1cm4gdHJ1ZTtcclxuaWYgKGlucCA9PSBcInF3Y01lbnVCYXJfRGF0YVwiKSByZXR1cm4gdHJ1ZTtcclxuaWYgKGlucCA9PSBcInF3Y01lc3NhZ2VfRGF0YVwiKSByZXR1cm4gdHJ1ZTtcclxuaWYgKGlucCA9PSBcInF3Y1BhZ2VyX0RhdGFcIikgcmV0dXJuIHRydWU7XHJcbmlmIChpbnAgPT0gXCJxd2NQREZWaWV3ZXJfRGF0YVwiKSByZXR1cm4gdHJ1ZTtcclxuaWYgKGlucCA9PSBcInF3Y1Bpdm90VGFibGVfRGF0YVwiKSByZXR1cm4gdHJ1ZTtcclxuaWYgKGlucCA9PSBcInF3Y1Byb2dyZXNzQmFyX0RhdGFcIikgcmV0dXJuIHRydWU7XHJcbmlmIChpbnAgPT0gXCJxd2NQcm9ncmVzc0J1dHRvbl9EYXRhXCIpIHJldHVybiB0cnVlO1xyXG5pZiAoaW5wID09IFwicXdjUXVlcnlCdWlsZGVyX0RhdGFcIikgcmV0dXJuIHRydWU7XHJcbmlmIChpbnAgPT0gXCJxd2NRUkNvZGVfRGF0YVwiKSByZXR1cm4gdHJ1ZTtcclxuaWYgKGlucCA9PSBcInF3Y1JhdGluZ19EYXRhXCIpIHJldHVybiB0cnVlO1xyXG5pZiAoaW5wID09IFwicXdjUmliYm9uX0RhdGFcIikgcmV0dXJuIHRydWU7XHJcbmlmIChpbnAgPT0gXCJxd2NSaWNoVGV4dEVkaXRvcl9EYXRhXCIpIHJldHVybiB0cnVlO1xyXG5pZiAoaW5wID09IFwicXdjU2NoZWR1bGVfRGF0YVwiKSByZXR1cm4gdHJ1ZTtcclxuaWYgKGlucCA9PSBcInF3Y1NpZGVCYXJfRGF0YVwiKSByZXR1cm4gdHJ1ZTtcclxuaWYgKGlucCA9PSBcInF3Y1NpZ25hdHVyZV9EYXRhXCIpIHJldHVybiB0cnVlO1xyXG5pZiAoaW5wID09IFwicXdjU2tlbGV0b25fRGF0YVwiKSByZXR1cm4gdHJ1ZTtcclxuaWYgKGlucCA9PSBcInF3Y1NwbGl0dGVyX0RhdGFcIikgcmV0dXJuIHRydWU7XHJcbmlmIChpbnAgPT0gXCJxd2NUYWJDb250cm9sX0RhdGFcIikgcmV0dXJuIHRydWU7XHJcbmlmIChpbnAgPT0gXCJxd2NUZXh0X0RhdGFcIikgcmV0dXJuIHRydWU7XHJcbmlmIChpbnAgPT0gXCJxd2NUcmVlVmlld19EYXRhXCIpIHJldHVybiB0cnVlO1xyXG5pZiAoaW5wID09IFwicXdjVXBsb2FkZXJfRGF0YVwiKSByZXR1cm4gdHJ1ZTtcclxucmV0dXJuIGZhbHNlO1xyXG59IFxyXG5wcml2YXRlIHZvaWQgQ3JlYXRlQ29udHJvbChUcmFuc2ZlclN0cmluZyBkcykge1xyXG5Bc3NlbWJseSBhc3NlbWJseSA9IEFQTC5HZXRBc3NlbWJseShcIkRhdGFCaW5kaW5nXCIsIHRoaXMpO1xyXG5UeXBlIHR5cGUgPSBhc3NlbWJseS5HZXRUeXBlKFwiRGF0YUJpbmRpbmdcIiArIFwiLlwiICsgZHMuQ2xhc3MpO1xyXG5zdHJpbmcgY2wgPSBkcy5DbGFzcyArIFwiX0RhdGFcIjtcclxuYm9vbCBpc0VKMSA9IElzRUoxKGNsKTtcclxuYm9vbCBpc0VKMiA9IElzRUoyKGNsKTtcclxudmFyIG9iID0gQWN0aXZhdG9yLkNyZWF0ZUluc3RhbmNlKHR5cGUsIGRzKTtcclxuTWV0aG9kSW5mbyBtZXRob2QgPSB0eXBlLkdldE1ldGhvZChcIkNyZWF0ZUNvbnRpbnVlMVwiKTtcclxudmFyIG9iaiA9IEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGNsLCBkcy5JbnN0YW5jZSwgbnVsbCk7XHJcbmlmIChtZXRob2QgIT0gbnVsbCkge1xyXG52YXIgYXJndW1lbnRzID0gbmV3IG9iamVjdFtdIHsgZHMgfTtcclxubWV0aG9kLkludm9rZSgoKE1KSF9Db21tb25EYXRhKW9iaikuTUpIX0NsYXNzLCBhcmd1bWVudHMpO1xyXG59IFxyXG5tZXRob2QgPSB0eXBlLkdldE1ldGhvZChcIkNyZWF0ZUNvbnRpbnVlMlwiKTtcclxuaWYgKG1ldGhvZCAhPSBudWxsKSB7XHJcbnZhciBhcmd1bWVudHMgPSBuZXcgb2JqZWN0W10geyBkcyB9O1xyXG5tZXRob2QuSW52b2tlKCgoTUpIX0NvbW1vbkRhdGEpb2JqKS5NSkhfQ2xhc3MsIGFyZ3VtZW50cyk7XHJcbn0gXHJcbmlmICgwICE9IGRzLkV4dHJhcy5MZW5ndGgpIHsgICAvLyBQcm9jZXNzIFN0eWxlIHByb3BlcnR5XHJcbmRzLk5hbWUgPSBcIlN0eWxlXCI7XHJcbmRzLkRhdGEgPSBkcy5FeHRyYXM7XHJcblR5cGUgdHlwZWNsID0gYXNzZW1ibHkuR2V0VHlwZShcIkRhdGFCaW5kaW5nXCIgKyBcIi5cIiArIGNsKTtcclxubWV0aG9kID0gdHlwZWNsLkdldE1ldGhvZChcIlJ1blByb3BlcnR5Q2hhbmdlZEluXCIpO1xyXG52YXIgYXJndW1lbnRzID0gbmV3IG9iamVjdFtdIHsgZHMsIGZhbHNlIH07XHJcbm1ldGhvZC5JbnZva2Uob2JqLCBhcmd1bWVudHMpO1xyXG59fVxyXG5wcml2YXRlIHZvaWQgUnVuRGF0YUJpbmRpbmcoVHJhbnNmZXJTdHJpbmcgZHMpIHtcclxuaWYoZHMuQ2xhc3MgPT0gXCJxd2NfUm9vdFwiKSB7XHJcbnF3Y19Sb290IGRib2JqMSA9IChxd2NfUm9vdCkgQVBMLkdldEluc3RhbmNlKFwiRGF0YUJpbmRpbmdcIiwgZHMuQ2xhc3MsIGRzLkluc3RhbmNlLCB0aGlzKTtcclxuaWYgKG51bGwgIT0gZGJvYmoxKSBkYm9iajEuUnVuUHJvcGVydHlDaGFuZ2VkSW4oZHMsZmFsc2UpO1xyXG59XHJcbiBcclxuZWxzZSBpZihkcy5DbGFzcyA9PSBcIk1KSF9EUV9EYXRhXCIpIHtcclxuTUpIX0RRX0RhdGEgZGJvYmoyID0gKE1KSF9EUV9EYXRhKSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBkcy5DbGFzcywgZHMuSW5zdGFuY2UsIHRoaXMpO1xyXG5pZiAobnVsbCAhPSBkYm9iajIpIGRib2JqMi5SdW5Qcm9wZXJ0eUNoYW5nZWRJbihkcyxmYWxzZSk7XHJcbn1cclxuIFxyXG5lbHNlIGlmKGRzLkNsYXNzID09IFwiTUpIX01pbkZvcm1fRGF0YVwiKSB7XHJcbk1KSF9NaW5Gb3JtX0RhdGEgZGJvYmozID0gKE1KSF9NaW5Gb3JtX0RhdGEpIEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgdGhpcyk7XHJcbmlmIChudWxsICE9IGRib2JqMykgZGJvYmozLlJ1blByb3BlcnR5Q2hhbmdlZEluKGRzLGZhbHNlKTtcclxufVxyXG4gXHJcbmVsc2UgaWYoZHMuQ2xhc3MgPT0gXCJxd2NBcHBCYXJfRGF0YVwiKSB7XHJcbnF3Y0FwcEJhcl9EYXRhIGRib2JqNCA9IChxd2NBcHBCYXJfRGF0YSkgQVBMLkdldEluc3RhbmNlKFwiRGF0YUJpbmRpbmdcIiwgZHMuQ2xhc3MsIGRzLkluc3RhbmNlLCB0aGlzKTtcclxuaWYgKG51bGwgIT0gZGJvYmo0KSBkYm9iajQuUnVuUHJvcGVydHlDaGFuZ2VkSW4oZHMsZmFsc2UpO1xyXG59XHJcbiBcclxuZWxzZSBpZihkcy5DbGFzcyA9PSBcInF3Y0F2YXRhcl9EYXRhXCIpIHtcclxucXdjQXZhdGFyX0RhdGEgZGJvYmo1ID0gKHF3Y0F2YXRhcl9EYXRhKSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBkcy5DbGFzcywgZHMuSW5zdGFuY2UsIHRoaXMpO1xyXG5pZiAobnVsbCAhPSBkYm9iajUpIGRib2JqNS5SdW5Qcm9wZXJ0eUNoYW5nZWRJbihkcyxmYWxzZSk7XHJcbn1cclxuIFxyXG5lbHNlIGlmKGRzLkNsYXNzID09IFwicXdjQmFkZ2VfRGF0YVwiKSB7XHJcbnF3Y0JhZGdlX0RhdGEgZGJvYmo2ID0gKHF3Y0JhZGdlX0RhdGEpIEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgdGhpcyk7XHJcbmlmIChudWxsICE9IGRib2JqNikgZGJvYmo2LlJ1blByb3BlcnR5Q2hhbmdlZEluKGRzLGZhbHNlKTtcclxufVxyXG4gXHJcbmVsc2UgaWYoZHMuQ2xhc3MgPT0gXCJxd2NCYXJDb2RlX0RhdGFcIikge1xyXG5xd2NCYXJDb2RlX0RhdGEgZGJvYmo3ID0gKHF3Y0JhckNvZGVfRGF0YSkgQVBMLkdldEluc3RhbmNlKFwiRGF0YUJpbmRpbmdcIiwgZHMuQ2xhc3MsIGRzLkluc3RhbmNlLCB0aGlzKTtcclxuaWYgKG51bGwgIT0gZGJvYmo3KSBkYm9iajcuUnVuUHJvcGVydHlDaGFuZ2VkSW4oZHMsZmFsc2UpO1xyXG59XHJcbiBcclxuZWxzZSBpZihkcy5DbGFzcyA9PSBcInF3Y0JyZWFkQ3J1bWJfRGF0YVwiKSB7XHJcbnF3Y0JyZWFkQ3J1bWJfRGF0YSBkYm9iajggPSAocXdjQnJlYWRDcnVtYl9EYXRhKSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBkcy5DbGFzcywgZHMuSW5zdGFuY2UsIHRoaXMpO1xyXG5pZiAobnVsbCAhPSBkYm9iajgpIGRib2JqOC5SdW5Qcm9wZXJ0eUNoYW5nZWRJbihkcyxmYWxzZSk7XHJcbn1cclxuIFxyXG5lbHNlIGlmKGRzLkNsYXNzID09IFwicXdjQnJpZGdlU2NvcmVfRGF0YVwiKSB7XHJcbnF3Y0JyaWRnZVNjb3JlX0RhdGEgZGJvYmo5ID0gKHF3Y0JyaWRnZVNjb3JlX0RhdGEpIEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgdGhpcyk7XHJcbmlmIChudWxsICE9IGRib2JqOSkgZGJvYmo5LlJ1blByb3BlcnR5Q2hhbmdlZEluKGRzLGZhbHNlKTtcclxufVxyXG4gXHJcbmVsc2UgaWYoZHMuQ2xhc3MgPT0gXCJxd2NCdXR0b25DaGVja19EYXRhXCIpIHtcclxucXdjQnV0dG9uQ2hlY2tfRGF0YSBkYm9iajEwID0gKHF3Y0J1dHRvbkNoZWNrX0RhdGEpIEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgdGhpcyk7XHJcbmlmIChudWxsICE9IGRib2JqMTApIGRib2JqMTAuUnVuUHJvcGVydHlDaGFuZ2VkSW4oZHMsZmFsc2UpO1xyXG59XHJcbiBcclxuZWxzZSBpZihkcy5DbGFzcyA9PSBcInF3Y0J1dHRvbkNvbW1hbmRMaW5rX0RhdGFcIikge1xyXG5xd2NCdXR0b25Db21tYW5kTGlua19EYXRhIGRib2JqMTEgPSAocXdjQnV0dG9uQ29tbWFuZExpbmtfRGF0YSkgQVBMLkdldEluc3RhbmNlKFwiRGF0YUJpbmRpbmdcIiwgZHMuQ2xhc3MsIGRzLkluc3RhbmNlLCB0aGlzKTtcclxuaWYgKG51bGwgIT0gZGJvYmoxMSkgZGJvYmoxMS5SdW5Qcm9wZXJ0eUNoYW5nZWRJbihkcyxmYWxzZSk7XHJcbn1cclxuIFxyXG5lbHNlIGlmKGRzLkNsYXNzID09IFwicXdjQnV0dG9uUHVzaF9EYXRhXCIpIHtcclxucXdjQnV0dG9uUHVzaF9EYXRhIGRib2JqMTIgPSAocXdjQnV0dG9uUHVzaF9EYXRhKSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBkcy5DbGFzcywgZHMuSW5zdGFuY2UsIHRoaXMpO1xyXG5pZiAobnVsbCAhPSBkYm9iajEyKSBkYm9iajEyLlJ1blByb3BlcnR5Q2hhbmdlZEluKGRzLGZhbHNlKTtcclxufVxyXG4gXHJcbmVsc2UgaWYoZHMuQ2xhc3MgPT0gXCJxd2NCdXR0b25SYWRpb19EYXRhXCIpIHtcclxucXdjQnV0dG9uUmFkaW9fRGF0YSBkYm9iajEzID0gKHF3Y0J1dHRvblJhZGlvX0RhdGEpIEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgdGhpcyk7XHJcbmlmIChudWxsICE9IGRib2JqMTMpIGRib2JqMTMuUnVuUHJvcGVydHlDaGFuZ2VkSW4oZHMsZmFsc2UpO1xyXG59XHJcbiBcclxuZWxzZSBpZihkcy5DbGFzcyA9PSBcInF3Y0J1dHRvblNwbGl0X0RhdGFcIikge1xyXG5xd2NCdXR0b25TcGxpdF9EYXRhIGRib2JqMTQgPSAocXdjQnV0dG9uU3BsaXRfRGF0YSkgQVBMLkdldEluc3RhbmNlKFwiRGF0YUJpbmRpbmdcIiwgZHMuQ2xhc3MsIGRzLkluc3RhbmNlLCB0aGlzKTtcclxuaWYgKG51bGwgIT0gZGJvYmoxNCkgZGJvYmoxNC5SdW5Qcm9wZXJ0eUNoYW5nZWRJbihkcyxmYWxzZSk7XHJcbn1cclxuIFxyXG5lbHNlIGlmKGRzLkNsYXNzID09IFwicXdjQnV0dG9uVG9nZ2xlX0RhdGFcIikge1xyXG5xd2NCdXR0b25Ub2dnbGVfRGF0YSBkYm9iajE1ID0gKHF3Y0J1dHRvblRvZ2dsZV9EYXRhKSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBkcy5DbGFzcywgZHMuSW5zdGFuY2UsIHRoaXMpO1xyXG5pZiAobnVsbCAhPSBkYm9iajE1KSBkYm9iajE1LlJ1blByb3BlcnR5Q2hhbmdlZEluKGRzLGZhbHNlKTtcclxufVxyXG4gXHJcbmVsc2UgaWYoZHMuQ2xhc3MgPT0gXCJxd2NDYWxlbmRhcl9EYXRhXCIpIHtcclxucXdjQ2FsZW5kYXJfRGF0YSBkYm9iajE2ID0gKHF3Y0NhbGVuZGFyX0RhdGEpIEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgdGhpcyk7XHJcbmlmIChudWxsICE9IGRib2JqMTYpIGRib2JqMTYuUnVuUHJvcGVydHlDaGFuZ2VkSW4oZHMsZmFsc2UpO1xyXG59XHJcbiBcclxuZWxzZSBpZihkcy5DbGFzcyA9PSBcInF3Y0NhcmRfRGF0YVwiKSB7XHJcbnF3Y0NhcmRfRGF0YSBkYm9iajE3ID0gKHF3Y0NhcmRfRGF0YSkgQVBMLkdldEluc3RhbmNlKFwiRGF0YUJpbmRpbmdcIiwgZHMuQ2xhc3MsIGRzLkluc3RhbmNlLCB0aGlzKTtcclxuaWYgKG51bGwgIT0gZGJvYmoxNykgZGJvYmoxNy5SdW5Qcm9wZXJ0eUNoYW5nZWRJbihkcyxmYWxzZSk7XHJcbn1cclxuIFxyXG5lbHNlIGlmKGRzLkNsYXNzID09IFwicXdjQ2Fyb3VzZWxfRGF0YVwiKSB7XHJcbnF3Y0Nhcm91c2VsX0RhdGEgZGJvYmoxOCA9IChxd2NDYXJvdXNlbF9EYXRhKSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBkcy5DbGFzcywgZHMuSW5zdGFuY2UsIHRoaXMpO1xyXG5pZiAobnVsbCAhPSBkYm9iajE4KSBkYm9iajE4LlJ1blByb3BlcnR5Q2hhbmdlZEluKGRzLGZhbHNlKTtcclxufVxyXG4gXHJcbmVsc2UgaWYoZHMuQ2xhc3MgPT0gXCJxd2NDaGFydF9EYXRhXCIpIHtcclxucXdjQ2hhcnRfRGF0YSBkYm9iajE5ID0gKHF3Y0NoYXJ0X0RhdGEpIEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgdGhpcyk7XHJcbmlmIChudWxsICE9IGRib2JqMTkpIGRib2JqMTkuUnVuUHJvcGVydHlDaGFuZ2VkSW4oZHMsZmFsc2UpO1xyXG59XHJcbiBcclxuZWxzZSBpZihkcy5DbGFzcyA9PSBcInF3Y0NoaXBzX0RhdGFcIikge1xyXG5xd2NDaGlwc19EYXRhIGRib2JqMjAgPSAocXdjQ2hpcHNfRGF0YSkgQVBMLkdldEluc3RhbmNlKFwiRGF0YUJpbmRpbmdcIiwgZHMuQ2xhc3MsIGRzLkluc3RhbmNlLCB0aGlzKTtcclxuaWYgKG51bGwgIT0gZGJvYmoyMCkgZGJvYmoyMC5SdW5Qcm9wZXJ0eUNoYW5nZWRJbihkcyxmYWxzZSk7XHJcbn1cclxuIFxyXG5lbHNlIGlmKGRzLkNsYXNzID09IFwicXdjQ2lyY3VsYXJHYXVnZV9EYXRhXCIpIHtcclxucXdjQ2lyY3VsYXJHYXVnZV9EYXRhIGRib2JqMjEgPSAocXdjQ2lyY3VsYXJHYXVnZV9EYXRhKSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBkcy5DbGFzcywgZHMuSW5zdGFuY2UsIHRoaXMpO1xyXG5pZiAobnVsbCAhPSBkYm9iajIxKSBkYm9iajIxLlJ1blByb3BlcnR5Q2hhbmdlZEluKGRzLGZhbHNlKTtcclxufVxyXG4gXHJcbmVsc2UgaWYoZHMuQ2xhc3MgPT0gXCJxd2NDb2xvdXJQaWNrZXJfRGF0YVwiKSB7XHJcbnF3Y0NvbG91clBpY2tlcl9EYXRhIGRib2JqMjIgPSAocXdjQ29sb3VyUGlja2VyX0RhdGEpIEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgdGhpcyk7XHJcbmlmIChudWxsICE9IGRib2JqMjIpIGRib2JqMjIuUnVuUHJvcGVydHlDaGFuZ2VkSW4oZHMsZmFsc2UpO1xyXG59XHJcbiBcclxuZWxzZSBpZihkcy5DbGFzcyA9PSBcInF3Y0NvbG9yUGlja2VyX0RhdGFcIikge1xyXG5xd2NDb2xvclBpY2tlcl9EYXRhIGRib2JqMjMgPSAocXdjQ29sb3JQaWNrZXJfRGF0YSkgQVBMLkdldEluc3RhbmNlKFwiRGF0YUJpbmRpbmdcIiwgZHMuQ2xhc3MsIGRzLkluc3RhbmNlLCB0aGlzKTtcclxuaWYgKG51bGwgIT0gZGJvYmoyMykgZGJvYmoyMy5SdW5Qcm9wZXJ0eUNoYW5nZWRJbihkcyxmYWxzZSk7XHJcbn1cclxuIFxyXG5lbHNlIGlmKGRzLkNsYXNzID09IFwicXdjQ29tYm9Ecm9wX0RhdGFcIikge1xyXG5xd2NDb21ib0Ryb3BfRGF0YSBkYm9iajI0ID0gKHF3Y0NvbWJvRHJvcF9EYXRhKSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBkcy5DbGFzcywgZHMuSW5zdGFuY2UsIHRoaXMpO1xyXG5pZiAobnVsbCAhPSBkYm9iajI0KSBkYm9iajI0LlJ1blByb3BlcnR5Q2hhbmdlZEluKGRzLGZhbHNlKTtcclxufVxyXG4gXHJcbmVsc2UgaWYoZHMuQ2xhc3MgPT0gXCJxd2NDb21ib0Ryb3BFZGl0X0RhdGFcIikge1xyXG5xd2NDb21ib0Ryb3BFZGl0X0RhdGEgZGJvYmoyNSA9IChxd2NDb21ib0Ryb3BFZGl0X0RhdGEpIEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgdGhpcyk7XHJcbmlmIChudWxsICE9IGRib2JqMjUpIGRib2JqMjUuUnVuUHJvcGVydHlDaGFuZ2VkSW4oZHMsZmFsc2UpO1xyXG59XHJcbiBcclxuZWxzZSBpZihkcy5DbGFzcyA9PSBcInF3Y0NvbWJvU2ltcGxlX0RhdGFcIikge1xyXG5xd2NDb21ib1NpbXBsZV9EYXRhIGRib2JqMjYgPSAocXdjQ29tYm9TaW1wbGVfRGF0YSkgQVBMLkdldEluc3RhbmNlKFwiRGF0YUJpbmRpbmdcIiwgZHMuQ2xhc3MsIGRzLkluc3RhbmNlLCB0aGlzKTtcclxuaWYgKG51bGwgIT0gZGJvYmoyNikgZGJvYmoyNi5SdW5Qcm9wZXJ0eUNoYW5nZWRJbihkcyxmYWxzZSk7XHJcbn1cclxuIFxyXG5lbHNlIGlmKGRzLkNsYXNzID09IFwicXdjQ29udGV4dE1lbnVfRGF0YVwiKSB7XHJcbnF3Y0NvbnRleHRNZW51X0RhdGEgZGJvYmoyNyA9IChxd2NDb250ZXh0TWVudV9EYXRhKSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBkcy5DbGFzcywgZHMuSW5zdGFuY2UsIHRoaXMpO1xyXG5pZiAobnVsbCAhPSBkYm9iajI3KSBkYm9iajI3LlJ1blByb3BlcnR5Q2hhbmdlZEluKGRzLGZhbHNlKTtcclxufVxyXG4gXHJcbmVsc2UgaWYoZHMuQ2xhc3MgPT0gXCJxd2NEYXNoQm9hcmRfRGF0YVwiKSB7XHJcbnF3Y0Rhc2hCb2FyZF9EYXRhIGRib2JqMjggPSAocXdjRGFzaEJvYXJkX0RhdGEpIEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgdGhpcyk7XHJcbmlmIChudWxsICE9IGRib2JqMjgpIGRib2JqMjguUnVuUHJvcGVydHlDaGFuZ2VkSW4oZHMsZmFsc2UpO1xyXG59XHJcbiBcclxuZWxzZSBpZihkcy5DbGFzcyA9PSBcInF3Y0RhdGFHcmlkX0RhdGFcIikge1xyXG5xd2NEYXRhR3JpZF9EYXRhIGRib2JqMjkgPSAocXdjRGF0YUdyaWRfRGF0YSkgQVBMLkdldEluc3RhbmNlKFwiRGF0YUJpbmRpbmdcIiwgZHMuQ2xhc3MsIGRzLkluc3RhbmNlLCB0aGlzKTtcclxuaWYgKG51bGwgIT0gZGJvYmoyOSkgZGJvYmoyOS5SdW5Qcm9wZXJ0eUNoYW5nZWRJbihkcyxmYWxzZSk7XHJcbn1cclxuIFxyXG5lbHNlIGlmKGRzLkNsYXNzID09IFwicXdjRGF0YU1hbmFnZXJfRGF0YVwiKSB7XHJcbnF3Y0RhdGFNYW5hZ2VyX0RhdGEgZGJvYmozMCA9IChxd2NEYXRhTWFuYWdlcl9EYXRhKSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBkcy5DbGFzcywgZHMuSW5zdGFuY2UsIHRoaXMpO1xyXG5pZiAobnVsbCAhPSBkYm9iajMwKSBkYm9iajMwLlJ1blByb3BlcnR5Q2hhbmdlZEluKGRzLGZhbHNlKTtcclxufVxyXG4gXHJcbmVsc2UgaWYoZHMuQ2xhc3MgPT0gXCJxd2NEYXRlUGlja2VyX0RhdGFcIikge1xyXG5xd2NEYXRlUGlja2VyX0RhdGEgZGJvYmozMSA9IChxd2NEYXRlUGlja2VyX0RhdGEpIEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgdGhpcyk7XHJcbmlmIChudWxsICE9IGRib2JqMzEpIGRib2JqMzEuUnVuUHJvcGVydHlDaGFuZ2VkSW4oZHMsZmFsc2UpO1xyXG59XHJcbiBcclxuZWxzZSBpZihkcy5DbGFzcyA9PSBcInF3Y0RhdGVUaW1lUGlja2VyQ29tYm9fRGF0YVwiKSB7XHJcbnF3Y0RhdGVUaW1lUGlja2VyQ29tYm9fRGF0YSBkYm9iajMyID0gKHF3Y0RhdGVUaW1lUGlja2VyQ29tYm9fRGF0YSkgQVBMLkdldEluc3RhbmNlKFwiRGF0YUJpbmRpbmdcIiwgZHMuQ2xhc3MsIGRzLkluc3RhbmNlLCB0aGlzKTtcclxuaWYgKG51bGwgIT0gZGJvYmozMikgZGJvYmozMi5SdW5Qcm9wZXJ0eUNoYW5nZWRJbihkcyxmYWxzZSk7XHJcbn1cclxuIFxyXG5lbHNlIGlmKGRzLkNsYXNzID09IFwicXdjRGlhZ3JhbV9EYXRhXCIpIHtcclxucXdjRGlhZ3JhbV9EYXRhIGRib2JqMzMgPSAocXdjRGlhZ3JhbV9EYXRhKSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBkcy5DbGFzcywgZHMuSW5zdGFuY2UsIHRoaXMpO1xyXG5pZiAobnVsbCAhPSBkYm9iajMzKSBkYm9iajMzLlJ1blByb3BlcnR5Q2hhbmdlZEluKGRzLGZhbHNlKTtcclxufVxyXG4gXHJcbmVsc2UgaWYoZHMuQ2xhc3MgPT0gXCJxd2NNc2dCb3hNc2dfRGF0YVwiKSB7XHJcbnF3Y01zZ0JveE1zZ19EYXRhIGRib2JqMzQgPSAocXdjTXNnQm94TXNnX0RhdGEpIEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgdGhpcyk7XHJcbmlmIChudWxsICE9IGRib2JqMzQpIGRib2JqMzQuUnVuUHJvcGVydHlDaGFuZ2VkSW4oZHMsZmFsc2UpO1xyXG59XHJcbiBcclxuZWxzZSBpZihkcy5DbGFzcyA9PSBcInF3Y01zZ0JveEluZm9fRGF0YVwiKSB7XHJcbnF3Y01zZ0JveEluZm9fRGF0YSBkYm9iajM1ID0gKHF3Y01zZ0JveEluZm9fRGF0YSkgQVBMLkdldEluc3RhbmNlKFwiRGF0YUJpbmRpbmdcIiwgZHMuQ2xhc3MsIGRzLkluc3RhbmNlLCB0aGlzKTtcclxuaWYgKG51bGwgIT0gZGJvYmozNSkgZGJvYmozNS5SdW5Qcm9wZXJ0eUNoYW5nZWRJbihkcyxmYWxzZSk7XHJcbn1cclxuIFxyXG5lbHNlIGlmKGRzLkNsYXNzID09IFwicXdjTXNnQm94UXVlcnlfRGF0YVwiKSB7XHJcbnF3Y01zZ0JveFF1ZXJ5X0RhdGEgZGJvYmozNiA9IChxd2NNc2dCb3hRdWVyeV9EYXRhKSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBkcy5DbGFzcywgZHMuSW5zdGFuY2UsIHRoaXMpO1xyXG5pZiAobnVsbCAhPSBkYm9iajM2KSBkYm9iajM2LlJ1blByb3BlcnR5Q2hhbmdlZEluKGRzLGZhbHNlKTtcclxufVxyXG4gXHJcbmVsc2UgaWYoZHMuQ2xhc3MgPT0gXCJxd2NNc2dCb3hXYXJuX0RhdGFcIikge1xyXG5xd2NNc2dCb3hXYXJuX0RhdGEgZGJvYmozNyA9IChxd2NNc2dCb3hXYXJuX0RhdGEpIEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgdGhpcyk7XHJcbmlmIChudWxsICE9IGRib2JqMzcpIGRib2JqMzcuUnVuUHJvcGVydHlDaGFuZ2VkSW4oZHMsZmFsc2UpO1xyXG59XHJcbiBcclxuZWxzZSBpZihkcy5DbGFzcyA9PSBcInF3Y01zZ0JveEVycm9yX0RhdGFcIikge1xyXG5xd2NNc2dCb3hFcnJvcl9EYXRhIGRib2JqMzggPSAocXdjTXNnQm94RXJyb3JfRGF0YSkgQVBMLkdldEluc3RhbmNlKFwiRGF0YUJpbmRpbmdcIiwgZHMuQ2xhc3MsIGRzLkluc3RhbmNlLCB0aGlzKTtcclxuaWYgKG51bGwgIT0gZGJvYmozOCkgZGJvYmozOC5SdW5Qcm9wZXJ0eUNoYW5nZWRJbihkcyxmYWxzZSk7XHJcbn1cclxuIFxyXG5lbHNlIGlmKGRzLkNsYXNzID09IFwicXdjRG9jdW1lbnRFZGl0b3JfRGF0YVwiKSB7XHJcbnF3Y0RvY3VtZW50RWRpdG9yX0RhdGEgZGJvYmozOSA9IChxd2NEb2N1bWVudEVkaXRvcl9EYXRhKSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBkcy5DbGFzcywgZHMuSW5zdGFuY2UsIHRoaXMpO1xyXG5pZiAobnVsbCAhPSBkYm9iajM5KSBkYm9iajM5LlJ1blByb3BlcnR5Q2hhbmdlZEluKGRzLGZhbHNlKTtcclxufVxyXG4gXHJcbmVsc2UgaWYoZHMuQ2xhc3MgPT0gXCJxd2NFZGl0U2luZ2xlX0RhdGFcIikge1xyXG5xd2NFZGl0U2luZ2xlX0RhdGEgZGJvYmo0MCA9IChxd2NFZGl0U2luZ2xlX0RhdGEpIEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgdGhpcyk7XHJcbmlmIChudWxsICE9IGRib2JqNDApIGRib2JqNDAuUnVuUHJvcGVydHlDaGFuZ2VkSW4oZHMsZmFsc2UpO1xyXG59XHJcbiBcclxuZWxzZSBpZihkcy5DbGFzcyA9PSBcInF3Y0VkaXRNdWx0aV9EYXRhXCIpIHtcclxucXdjRWRpdE11bHRpX0RhdGEgZGJvYmo0MSA9IChxd2NFZGl0TXVsdGlfRGF0YSkgQVBMLkdldEluc3RhbmNlKFwiRGF0YUJpbmRpbmdcIiwgZHMuQ2xhc3MsIGRzLkluc3RhbmNlLCB0aGlzKTtcclxuaWYgKG51bGwgIT0gZGJvYmo0MSkgZGJvYmo0MS5SdW5Qcm9wZXJ0eUNoYW5nZWRJbihkcyxmYWxzZSk7XHJcbn1cclxuIFxyXG5lbHNlIGlmKGRzLkNsYXNzID09IFwicXdjRXhwYW5kZXJfRGF0YVwiKSB7XHJcbnF3Y0V4cGFuZGVyX0RhdGEgZGJvYmo0MiA9IChxd2NFeHBhbmRlcl9EYXRhKSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBkcy5DbGFzcywgZHMuSW5zdGFuY2UsIHRoaXMpO1xyXG5pZiAobnVsbCAhPSBkYm9iajQyKSBkYm9iajQyLlJ1blByb3BlcnR5Q2hhbmdlZEluKGRzLGZhbHNlKTtcclxufVxyXG4gXHJcbmVsc2UgaWYoZHMuQ2xhc3MgPT0gXCJxd2NGaWxlTWFuYWdlcl9EYXRhXCIpIHtcclxucXdjRmlsZU1hbmFnZXJfRGF0YSBkYm9iajQzID0gKHF3Y0ZpbGVNYW5hZ2VyX0RhdGEpIEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgdGhpcyk7XHJcbmlmIChudWxsICE9IGRib2JqNDMpIGRib2JqNDMuUnVuUHJvcGVydHlDaGFuZ2VkSW4oZHMsZmFsc2UpO1xyXG59XHJcbiBcclxuZWxzZSBpZihkcy5DbGFzcyA9PSBcInF3Y0ZvbnRfRGF0YVwiKSB7XHJcbnF3Y0ZvbnRfRGF0YSBkYm9iajQ0ID0gKHF3Y0ZvbnRfRGF0YSkgQVBMLkdldEluc3RhbmNlKFwiRGF0YUJpbmRpbmdcIiwgZHMuQ2xhc3MsIGRzLkluc3RhbmNlLCB0aGlzKTtcclxuaWYgKG51bGwgIT0gZGJvYmo0NCkgZGJvYmo0NC5SdW5Qcm9wZXJ0eUNoYW5nZWRJbihkcyxmYWxzZSk7XHJcbn1cclxuIFxyXG5lbHNlIGlmKGRzLkNsYXNzID09IFwicXdjRm9ybV9EYXRhXCIpIHtcclxucXdjRm9ybV9EYXRhIGRib2JqNDUgPSAocXdjRm9ybV9EYXRhKSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBkcy5DbGFzcywgZHMuSW5zdGFuY2UsIHRoaXMpO1xyXG5pZiAobnVsbCAhPSBkYm9iajQ1KSBkYm9iajQ1LlJ1blByb3BlcnR5Q2hhbmdlZEluKGRzLGZhbHNlKTtcclxufVxyXG4gXHJcbmVsc2UgaWYoZHMuQ2xhc3MgPT0gXCJxd2NHYW50dF9EYXRhXCIpIHtcclxucXdjR2FudHRfRGF0YSBkYm9iajQ2ID0gKHF3Y0dhbnR0X0RhdGEpIEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgdGhpcyk7XHJcbmlmIChudWxsICE9IGRib2JqNDYpIGRib2JqNDYuUnVuUHJvcGVydHlDaGFuZ2VkSW4oZHMsZmFsc2UpO1xyXG59XHJcbiBcclxuZWxzZSBpZihkcy5DbGFzcyA9PSBcInF3Y0dyaWRfRGF0YVwiKSB7XHJcbnF3Y0dyaWRfRGF0YSBkYm9iajQ3ID0gKHF3Y0dyaWRfRGF0YSkgQVBMLkdldEluc3RhbmNlKFwiRGF0YUJpbmRpbmdcIiwgZHMuQ2xhc3MsIGRzLkluc3RhbmNlLCB0aGlzKTtcclxuaWYgKG51bGwgIT0gZGJvYmo0NykgZGJvYmo0Ny5SdW5Qcm9wZXJ0eUNoYW5nZWRJbihkcyxmYWxzZSk7XHJcbn1cclxuIFxyXG5lbHNlIGlmKGRzLkNsYXNzID09IFwicXdjR3JvdXBfRGF0YVwiKSB7XHJcbnF3Y0dyb3VwX0RhdGEgZGJvYmo0OCA9IChxd2NHcm91cF9EYXRhKSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBkcy5DbGFzcywgZHMuSW5zdGFuY2UsIHRoaXMpO1xyXG5pZiAobnVsbCAhPSBkYm9iajQ4KSBkYm9iajQ4LlJ1blByb3BlcnR5Q2hhbmdlZEluKGRzLGZhbHNlKTtcclxufVxyXG4gXHJcbmVsc2UgaWYoZHMuQ2xhc3MgPT0gXCJxd2NJbWFnZUVkaXRvcl9EYXRhXCIpIHtcclxucXdjSW1hZ2VFZGl0b3JfRGF0YSBkYm9iajQ5ID0gKHF3Y0ltYWdlRWRpdG9yX0RhdGEpIEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgdGhpcyk7XHJcbmlmIChudWxsICE9IGRib2JqNDkpIGRib2JqNDkuUnVuUHJvcGVydHlDaGFuZ2VkSW4oZHMsZmFsc2UpO1xyXG59XHJcbiBcclxuZWxzZSBpZihkcy5DbGFzcyA9PSBcInF3Y0thbmJhbl9EYXRhXCIpIHtcclxucXdjS2FuYmFuX0RhdGEgZGJvYmo1MCA9IChxd2NLYW5iYW5fRGF0YSkgQVBMLkdldEluc3RhbmNlKFwiRGF0YUJpbmRpbmdcIiwgZHMuQ2xhc3MsIGRzLkluc3RhbmNlLCB0aGlzKTtcclxuaWYgKG51bGwgIT0gZGJvYmo1MCkgZGJvYmo1MC5SdW5Qcm9wZXJ0eUNoYW5nZWRJbihkcyxmYWxzZSk7XHJcbn1cclxuIFxyXG5lbHNlIGlmKGRzLkNsYXNzID09IFwicXdjTGFiZWxfRGF0YVwiKSB7XHJcbnF3Y0xhYmVsX0RhdGEgZGJvYmo1MSA9IChxd2NMYWJlbF9EYXRhKSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBkcy5DbGFzcywgZHMuSW5zdGFuY2UsIHRoaXMpO1xyXG5pZiAobnVsbCAhPSBkYm9iajUxKSBkYm9iajUxLlJ1blByb3BlcnR5Q2hhbmdlZEluKGRzLGZhbHNlKTtcclxufVxyXG4gXHJcbmVsc2UgaWYoZHMuQ2xhc3MgPT0gXCJxd2NMaW5lYXJHYXVnZV9EYXRhXCIpIHtcclxucXdjTGluZWFyR2F1Z2VfRGF0YSBkYm9iajUyID0gKHF3Y0xpbmVhckdhdWdlX0RhdGEpIEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgdGhpcyk7XHJcbmlmIChudWxsICE9IGRib2JqNTIpIGRib2JqNTIuUnVuUHJvcGVydHlDaGFuZ2VkSW4oZHMsZmFsc2UpO1xyXG59XHJcbiBcclxuZWxzZSBpZihkcy5DbGFzcyA9PSBcInF3Y0ltYWdlX0RhdGFcIikge1xyXG5xd2NJbWFnZV9EYXRhIGRib2JqNTMgPSAocXdjSW1hZ2VfRGF0YSkgQVBMLkdldEluc3RhbmNlKFwiRGF0YUJpbmRpbmdcIiwgZHMuQ2xhc3MsIGRzLkluc3RhbmNlLCB0aGlzKTtcclxuaWYgKG51bGwgIT0gZGJvYmo1MykgZGJvYmo1My5SdW5Qcm9wZXJ0eUNoYW5nZWRJbihkcyxmYWxzZSk7XHJcbn1cclxuIFxyXG5lbHNlIGlmKGRzLkNsYXNzID09IFwicXdjSW1hZ2VMaXN0X0RhdGFcIikge1xyXG5xd2NJbWFnZUxpc3RfRGF0YSBkYm9iajU0ID0gKHF3Y0ltYWdlTGlzdF9EYXRhKSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBkcy5DbGFzcywgZHMuSW5zdGFuY2UsIHRoaXMpO1xyXG5pZiAobnVsbCAhPSBkYm9iajU0KSBkYm9iajU0LlJ1blByb3BlcnR5Q2hhbmdlZEluKGRzLGZhbHNlKTtcclxufVxyXG4gXHJcbmVsc2UgaWYoZHMuQ2xhc3MgPT0gXCJxd2NLYW5iYW5fRGF0YVwiKSB7XHJcbnF3Y0thbmJhbl9EYXRhIGRib2JqNTUgPSAocXdjS2FuYmFuX0RhdGEpIEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgdGhpcyk7XHJcbmlmIChudWxsICE9IGRib2JqNTUpIGRib2JqNTUuUnVuUHJvcGVydHlDaGFuZ2VkSW4oZHMsZmFsc2UpO1xyXG59XHJcbiBcclxuZWxzZSBpZihkcy5DbGFzcyA9PSBcInF3Y0xpc3RTaW5nbGVfRGF0YVwiKSB7XHJcbnF3Y0xpc3RTaW5nbGVfRGF0YSBkYm9iajU2ID0gKHF3Y0xpc3RTaW5nbGVfRGF0YSkgQVBMLkdldEluc3RhbmNlKFwiRGF0YUJpbmRpbmdcIiwgZHMuQ2xhc3MsIGRzLkluc3RhbmNlLCB0aGlzKTtcclxuaWYgKG51bGwgIT0gZGJvYmo1NikgZGJvYmo1Ni5SdW5Qcm9wZXJ0eUNoYW5nZWRJbihkcyxmYWxzZSk7XHJcbn1cclxuIFxyXG5lbHNlIGlmKGRzLkNsYXNzID09IFwicXdjTGlzdE11bHRpX0RhdGFcIikge1xyXG5xd2NMaXN0TXVsdGlfRGF0YSBkYm9iajU3ID0gKHF3Y0xpc3RNdWx0aV9EYXRhKSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBkcy5DbGFzcywgZHMuSW5zdGFuY2UsIHRoaXMpO1xyXG5pZiAobnVsbCAhPSBkYm9iajU3KSBkYm9iajU3LlJ1blByb3BlcnR5Q2hhbmdlZEluKGRzLGZhbHNlKTtcclxufVxyXG4gXHJcbmVsc2UgaWYoZHMuQ2xhc3MgPT0gXCJxd2NMaXN0Vmlld1NpbmdsZV9EYXRhXCIpIHtcclxucXdjTGlzdFZpZXdTaW5nbGVfRGF0YSBkYm9iajU4ID0gKHF3Y0xpc3RWaWV3U2luZ2xlX0RhdGEpIEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgdGhpcyk7XHJcbmlmIChudWxsICE9IGRib2JqNTgpIGRib2JqNTguUnVuUHJvcGVydHlDaGFuZ2VkSW4oZHMsZmFsc2UpO1xyXG59XHJcbiBcclxuZWxzZSBpZihkcy5DbGFzcyA9PSBcInF3Y0xpc3RWaWV3TXVsdGlfRGF0YVwiKSB7XHJcbnF3Y0xpc3RWaWV3TXVsdGlfRGF0YSBkYm9iajU5ID0gKHF3Y0xpc3RWaWV3TXVsdGlfRGF0YSkgQVBMLkdldEluc3RhbmNlKFwiRGF0YUJpbmRpbmdcIiwgZHMuQ2xhc3MsIGRzLkluc3RhbmNlLCB0aGlzKTtcclxuaWYgKG51bGwgIT0gZGJvYmo1OSkgZGJvYmo1OS5SdW5Qcm9wZXJ0eUNoYW5nZWRJbihkcyxmYWxzZSk7XHJcbn1cclxuIFxyXG5lbHNlIGlmKGRzLkNsYXNzID09IFwicXdjTWFwc19EYXRhXCIpIHtcclxucXdjTWFwc19EYXRhIGRib2JqNjAgPSAocXdjTWFwc19EYXRhKSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBkcy5DbGFzcywgZHMuSW5zdGFuY2UsIHRoaXMpO1xyXG5pZiAobnVsbCAhPSBkYm9iajYwKSBkYm9iajYwLlJ1blByb3BlcnR5Q2hhbmdlZEluKGRzLGZhbHNlKTtcclxufVxyXG4gXHJcbmVsc2UgaWYoZHMuQ2xhc3MgPT0gXCJxd2NNZW50aW9uX0RhdGFcIikge1xyXG5xd2NNZW50aW9uX0RhdGEgZGJvYmo2MSA9IChxd2NNZW50aW9uX0RhdGEpIEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgdGhpcyk7XHJcbmlmIChudWxsICE9IGRib2JqNjEpIGRib2JqNjEuUnVuUHJvcGVydHlDaGFuZ2VkSW4oZHMsZmFsc2UpO1xyXG59XHJcbiBcclxuZWxzZSBpZihkcy5DbGFzcyA9PSBcInF3Y01lbnVfRGF0YVwiKSB7XHJcbnF3Y01lbnVfRGF0YSBkYm9iajYyID0gKHF3Y01lbnVfRGF0YSkgQVBMLkdldEluc3RhbmNlKFwiRGF0YUJpbmRpbmdcIiwgZHMuQ2xhc3MsIGRzLkluc3RhbmNlLCB0aGlzKTtcclxuaWYgKG51bGwgIT0gZGJvYmo2MikgZGJvYmo2Mi5SdW5Qcm9wZXJ0eUNoYW5nZWRJbihkcyxmYWxzZSk7XHJcbn1cclxuIFxyXG5lbHNlIGlmKGRzLkNsYXNzID09IFwicXdjTWVudUJhcl9EYXRhXCIpIHtcclxucXdjTWVudUJhcl9EYXRhIGRib2JqNjMgPSAocXdjTWVudUJhcl9EYXRhKSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBkcy5DbGFzcywgZHMuSW5zdGFuY2UsIHRoaXMpO1xyXG5pZiAobnVsbCAhPSBkYm9iajYzKSBkYm9iajYzLlJ1blByb3BlcnR5Q2hhbmdlZEluKGRzLGZhbHNlKTtcclxufVxyXG4gXHJcbmVsc2UgaWYoZHMuQ2xhc3MgPT0gXCJxd2NNZW51SXRlbUNoZWNrX0RhdGFcIikge1xyXG5xd2NNZW51SXRlbUNoZWNrX0RhdGEgZGJvYmo2NCA9IChxd2NNZW51SXRlbUNoZWNrX0RhdGEpIEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgdGhpcyk7XHJcbmlmIChudWxsICE9IGRib2JqNjQpIGRib2JqNjQuUnVuUHJvcGVydHlDaGFuZ2VkSW4oZHMsZmFsc2UpO1xyXG59XHJcbiBcclxuZWxzZSBpZihkcy5DbGFzcyA9PSBcInF3Y01lbnVJdGVtUmFkaW9fRGF0YVwiKSB7XHJcbnF3Y01lbnVJdGVtUmFkaW9fRGF0YSBkYm9iajY1ID0gKHF3Y01lbnVJdGVtUmFkaW9fRGF0YSkgQVBMLkdldEluc3RhbmNlKFwiRGF0YUJpbmRpbmdcIiwgZHMuQ2xhc3MsIGRzLkluc3RhbmNlLCB0aGlzKTtcclxuaWYgKG51bGwgIT0gZGJvYmo2NSkgZGJvYmo2NS5SdW5Qcm9wZXJ0eUNoYW5nZWRJbihkcyxmYWxzZSk7XHJcbn1cclxuIFxyXG5lbHNlIGlmKGRzLkNsYXNzID09IFwicXdjTWVzc2FnZV9EYXRhXCIpIHtcclxucXdjTWVzc2FnZV9EYXRhIGRib2JqNjYgPSAocXdjTWVzc2FnZV9EYXRhKSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBkcy5DbGFzcywgZHMuSW5zdGFuY2UsIHRoaXMpO1xyXG5pZiAobnVsbCAhPSBkYm9iajY2KSBkYm9iajY2LlJ1blByb3BlcnR5Q2hhbmdlZEluKGRzLGZhbHNlKTtcclxufVxyXG4gXHJcbmVsc2UgaWYoZHMuQ2xhc3MgPT0gXCJxd2NQYWdlcl9EYXRhXCIpIHtcclxucXdjUGFnZXJfRGF0YSBkYm9iajY3ID0gKHF3Y1BhZ2VyX0RhdGEpIEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgdGhpcyk7XHJcbmlmIChudWxsICE9IGRib2JqNjcpIGRib2JqNjcuUnVuUHJvcGVydHlDaGFuZ2VkSW4oZHMsZmFsc2UpO1xyXG59XHJcbiBcclxuZWxzZSBpZihkcy5DbGFzcyA9PSBcInF3Y1BERlZpZXdlcl9EYXRhXCIpIHtcclxucXdjUERGVmlld2VyX0RhdGEgZGJvYmo2OCA9IChxd2NQREZWaWV3ZXJfRGF0YSkgQVBMLkdldEluc3RhbmNlKFwiRGF0YUJpbmRpbmdcIiwgZHMuQ2xhc3MsIGRzLkluc3RhbmNlLCB0aGlzKTtcclxuaWYgKG51bGwgIT0gZGJvYmo2OCkgZGJvYmo2OC5SdW5Qcm9wZXJ0eUNoYW5nZWRJbihkcyxmYWxzZSk7XHJcbn1cclxuIFxyXG5lbHNlIGlmKGRzLkNsYXNzID09IFwicXdjUGl2b3RUYWJsZV9EYXRhXCIpIHtcclxucXdjUGl2b3RUYWJsZV9EYXRhIGRib2JqNjkgPSAocXdjUGl2b3RUYWJsZV9EYXRhKSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBkcy5DbGFzcywgZHMuSW5zdGFuY2UsIHRoaXMpO1xyXG5pZiAobnVsbCAhPSBkYm9iajY5KSBkYm9iajY5LlJ1blByb3BlcnR5Q2hhbmdlZEluKGRzLGZhbHNlKTtcclxufVxyXG4gXHJcbmVsc2UgaWYoZHMuQ2xhc3MgPT0gXCJxd2NQcm9ncmVzc0Jhcl9EYXRhXCIpIHtcclxucXdjUHJvZ3Jlc3NCYXJfRGF0YSBkYm9iajcwID0gKHF3Y1Byb2dyZXNzQmFyX0RhdGEpIEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgdGhpcyk7XHJcbmlmIChudWxsICE9IGRib2JqNzApIGRib2JqNzAuUnVuUHJvcGVydHlDaGFuZ2VkSW4oZHMsZmFsc2UpO1xyXG59XHJcbiBcclxuZWxzZSBpZihkcy5DbGFzcyA9PSBcInF3Y1Byb2dyZXNzQnV0dG9uX0RhdGFcIikge1xyXG5xd2NQcm9ncmVzc0J1dHRvbl9EYXRhIGRib2JqNzEgPSAocXdjUHJvZ3Jlc3NCdXR0b25fRGF0YSkgQVBMLkdldEluc3RhbmNlKFwiRGF0YUJpbmRpbmdcIiwgZHMuQ2xhc3MsIGRzLkluc3RhbmNlLCB0aGlzKTtcclxuaWYgKG51bGwgIT0gZGJvYmo3MSkgZGJvYmo3MS5SdW5Qcm9wZXJ0eUNoYW5nZWRJbihkcyxmYWxzZSk7XHJcbn1cclxuIFxyXG5lbHNlIGlmKGRzLkNsYXNzID09IFwicXdjUXVlcnlCdWlsZGVyX0RhdGFcIikge1xyXG5xd2NRdWVyeUJ1aWxkZXJfRGF0YSBkYm9iajcyID0gKHF3Y1F1ZXJ5QnVpbGRlcl9EYXRhKSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBkcy5DbGFzcywgZHMuSW5zdGFuY2UsIHRoaXMpO1xyXG5pZiAobnVsbCAhPSBkYm9iajcyKSBkYm9iajcyLlJ1blByb3BlcnR5Q2hhbmdlZEluKGRzLGZhbHNlKTtcclxufVxyXG4gXHJcbmVsc2UgaWYoZHMuQ2xhc3MgPT0gXCJxd2NRUkNvZGVfRGF0YVwiKSB7XHJcbnF3Y1FSQ29kZV9EYXRhIGRib2JqNzMgPSAocXdjUVJDb2RlX0RhdGEpIEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgdGhpcyk7XHJcbmlmIChudWxsICE9IGRib2JqNzMpIGRib2JqNzMuUnVuUHJvcGVydHlDaGFuZ2VkSW4oZHMsZmFsc2UpO1xyXG59XHJcbiBcclxuZWxzZSBpZihkcy5DbGFzcyA9PSBcInF3Y1JhdGluZ19EYXRhXCIpIHtcclxucXdjUmF0aW5nX0RhdGEgZGJvYmo3NCA9IChxd2NSYXRpbmdfRGF0YSkgQVBMLkdldEluc3RhbmNlKFwiRGF0YUJpbmRpbmdcIiwgZHMuQ2xhc3MsIGRzLkluc3RhbmNlLCB0aGlzKTtcclxuaWYgKG51bGwgIT0gZGJvYmo3NCkgZGJvYmo3NC5SdW5Qcm9wZXJ0eUNoYW5nZWRJbihkcyxmYWxzZSk7XHJcbn1cclxuIFxyXG5lbHNlIGlmKGRzLkNsYXNzID09IFwicXdjUmliYm9uX0RhdGFcIikge1xyXG5xd2NSaWJib25fRGF0YSBkYm9iajc1ID0gKHF3Y1JpYmJvbl9EYXRhKSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBkcy5DbGFzcywgZHMuSW5zdGFuY2UsIHRoaXMpO1xyXG5pZiAobnVsbCAhPSBkYm9iajc1KSBkYm9iajc1LlJ1blByb3BlcnR5Q2hhbmdlZEluKGRzLGZhbHNlKTtcclxufVxyXG4gXHJcbmVsc2UgaWYoZHMuQ2xhc3MgPT0gXCJxd2NSaWNoVGV4dEVkaXRvcl9EYXRhXCIpIHtcclxucXdjUmljaFRleHRFZGl0b3JfRGF0YSBkYm9iajc2ID0gKHF3Y1JpY2hUZXh0RWRpdG9yX0RhdGEpIEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgdGhpcyk7XHJcbmlmIChudWxsICE9IGRib2JqNzYpIGRib2JqNzYuUnVuUHJvcGVydHlDaGFuZ2VkSW4oZHMsZmFsc2UpO1xyXG59XHJcbiBcclxuZWxzZSBpZihkcy5DbGFzcyA9PSBcInF3Y1NjaGVkdWxlX0RhdGFcIikge1xyXG5xd2NTY2hlZHVsZV9EYXRhIGRib2JqNzcgPSAocXdjU2NoZWR1bGVfRGF0YSkgQVBMLkdldEluc3RhbmNlKFwiRGF0YUJpbmRpbmdcIiwgZHMuQ2xhc3MsIGRzLkluc3RhbmNlLCB0aGlzKTtcclxuaWYgKG51bGwgIT0gZGJvYmo3NykgZGJvYmo3Ny5SdW5Qcm9wZXJ0eUNoYW5nZWRJbihkcyxmYWxzZSk7XHJcbn1cclxuIFxyXG5lbHNlIGlmKGRzLkNsYXNzID09IFwicXdjU2VwYXJhdG9yX0RhdGFcIikge1xyXG5xd2NTZXBhcmF0b3JfRGF0YSBkYm9iajc4ID0gKHF3Y1NlcGFyYXRvcl9EYXRhKSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBkcy5DbGFzcywgZHMuSW5zdGFuY2UsIHRoaXMpO1xyXG5pZiAobnVsbCAhPSBkYm9iajc4KSBkYm9iajc4LlJ1blByb3BlcnR5Q2hhbmdlZEluKGRzLGZhbHNlKTtcclxufVxyXG4gXHJcbmVsc2UgaWYoZHMuQ2xhc3MgPT0gXCJxd2NTaWRlQmFyX0RhdGFcIikge1xyXG5xd2NTaWRlQmFyX0RhdGEgZGJvYmo3OSA9IChxd2NTaWRlQmFyX0RhdGEpIEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgdGhpcyk7XHJcbmlmIChudWxsICE9IGRib2JqNzkpIGRib2JqNzkuUnVuUHJvcGVydHlDaGFuZ2VkSW4oZHMsZmFsc2UpO1xyXG59XHJcbiBcclxuZWxzZSBpZihkcy5DbGFzcyA9PSBcInF3Y1NpZ25hdHVyZV9EYXRhXCIpIHtcclxucXdjU2lnbmF0dXJlX0RhdGEgZGJvYmo4MCA9IChxd2NTaWduYXR1cmVfRGF0YSkgQVBMLkdldEluc3RhbmNlKFwiRGF0YUJpbmRpbmdcIiwgZHMuQ2xhc3MsIGRzLkluc3RhbmNlLCB0aGlzKTtcclxuaWYgKG51bGwgIT0gZGJvYmo4MCkgZGJvYmo4MC5SdW5Qcm9wZXJ0eUNoYW5nZWRJbihkcyxmYWxzZSk7XHJcbn1cclxuIFxyXG5lbHNlIGlmKGRzLkNsYXNzID09IFwicXdjU2tlbGV0b25fRGF0YVwiKSB7XHJcbnF3Y1NrZWxldG9uX0RhdGEgZGJvYmo4MSA9IChxd2NTa2VsZXRvbl9EYXRhKSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBkcy5DbGFzcywgZHMuSW5zdGFuY2UsIHRoaXMpO1xyXG5pZiAobnVsbCAhPSBkYm9iajgxKSBkYm9iajgxLlJ1blByb3BlcnR5Q2hhbmdlZEluKGRzLGZhbHNlKTtcclxufVxyXG4gXHJcbmVsc2UgaWYoZHMuQ2xhc3MgPT0gXCJxd2NTcGxpdHRlcl9EYXRhXCIpIHtcclxucXdjU3BsaXR0ZXJfRGF0YSBkYm9iajgyID0gKHF3Y1NwbGl0dGVyX0RhdGEpIEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgdGhpcyk7XHJcbmlmIChudWxsICE9IGRib2JqODIpIGRib2JqODIuUnVuUHJvcGVydHlDaGFuZ2VkSW4oZHMsZmFsc2UpO1xyXG59XHJcbiBcclxuZWxzZSBpZihkcy5DbGFzcyA9PSBcInF3Y1N1YkZvcm1fRGF0YVwiKSB7XHJcbnF3Y1N1YkZvcm1fRGF0YSBkYm9iajgzID0gKHF3Y1N1YkZvcm1fRGF0YSkgQVBMLkdldEluc3RhbmNlKFwiRGF0YUJpbmRpbmdcIiwgZHMuQ2xhc3MsIGRzLkluc3RhbmNlLCB0aGlzKTtcclxuaWYgKG51bGwgIT0gZGJvYmo4MykgZGJvYmo4My5SdW5Qcm9wZXJ0eUNoYW5nZWRJbihkcyxmYWxzZSk7XHJcbn1cclxuIFxyXG5lbHNlIGlmKGRzLkNsYXNzID09IFwicXdjVGFiQnV0dG9uX0RhdGFcIikge1xyXG5xd2NUYWJCdXR0b25fRGF0YSBkYm9iajg0ID0gKHF3Y1RhYkJ1dHRvbl9EYXRhKSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBkcy5DbGFzcywgZHMuSW5zdGFuY2UsIHRoaXMpO1xyXG5pZiAobnVsbCAhPSBkYm9iajg0KSBkYm9iajg0LlJ1blByb3BlcnR5Q2hhbmdlZEluKGRzLGZhbHNlKTtcclxufVxyXG4gXHJcbmVsc2UgaWYoZHMuQ2xhc3MgPT0gXCJxd2NUYWJCdXR0b24xX0RhdGFcIikge1xyXG5xd2NUYWJCdXR0b24xX0RhdGEgZGJvYmo4NSA9IChxd2NUYWJCdXR0b24xX0RhdGEpIEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgdGhpcyk7XHJcbmlmIChudWxsICE9IGRib2JqODUpIGRib2JqODUuUnVuUHJvcGVydHlDaGFuZ2VkSW4oZHMsZmFsc2UpO1xyXG59XHJcbiBcclxuZWxzZSBpZihkcy5DbGFzcyA9PSBcInF3Y1RhYkNvbnRyb2xfRGF0YVwiKSB7XHJcbnF3Y1RhYkNvbnRyb2xfRGF0YSBkYm9iajg2ID0gKHF3Y1RhYkNvbnRyb2xfRGF0YSkgQVBMLkdldEluc3RhbmNlKFwiRGF0YUJpbmRpbmdcIiwgZHMuQ2xhc3MsIGRzLkluc3RhbmNlLCB0aGlzKTtcclxuaWYgKG51bGwgIT0gZGJvYmo4NikgZGJvYmo4Ni5SdW5Qcm9wZXJ0eUNoYW5nZWRJbihkcyxmYWxzZSk7XHJcbn1cclxuIFxyXG5lbHNlIGlmKGRzLkNsYXNzID09IFwicXdjVGFiQ29udHJvbEJ1dHRvbnNfRGF0YVwiKSB7XHJcbnF3Y1RhYkNvbnRyb2xCdXR0b25zX0RhdGEgZGJvYmo4NyA9IChxd2NUYWJDb250cm9sQnV0dG9uc19EYXRhKSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBkcy5DbGFzcywgZHMuSW5zdGFuY2UsIHRoaXMpO1xyXG5pZiAobnVsbCAhPSBkYm9iajg3KSBkYm9iajg3LlJ1blByb3BlcnR5Q2hhbmdlZEluKGRzLGZhbHNlKTtcclxufVxyXG4gXHJcbmVsc2UgaWYoZHMuQ2xhc3MgPT0gXCJxd2NUYWJDb250cm9sRmxhdEJ1dHRvbnNfRGF0YVwiKSB7XHJcbnF3Y1RhYkNvbnRyb2xGbGF0QnV0dG9uc19EYXRhIGRib2JqODggPSAocXdjVGFiQ29udHJvbEZsYXRCdXR0b25zX0RhdGEpIEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgdGhpcyk7XHJcbmlmIChudWxsICE9IGRib2JqODgpIGRib2JqODguUnVuUHJvcGVydHlDaGFuZ2VkSW4oZHMsZmFsc2UpO1xyXG59XHJcbiBcclxuZWxzZSBpZihkcy5DbGFzcyA9PSBcInF3Y1RhYkNvbnRyb2xUYWJzX0RhdGFcIikge1xyXG5xd2NUYWJDb250cm9sVGFic19EYXRhIGRib2JqODkgPSAocXdjVGFiQ29udHJvbFRhYnNfRGF0YSkgQVBMLkdldEluc3RhbmNlKFwiRGF0YUJpbmRpbmdcIiwgZHMuQ2xhc3MsIGRzLkluc3RhbmNlLCB0aGlzKTtcclxuaWYgKG51bGwgIT0gZGJvYmo4OSkgZGJvYmo4OS5SdW5Qcm9wZXJ0eUNoYW5nZWRJbihkcyxmYWxzZSk7XHJcbn1cclxuIFxyXG5lbHNlIGlmKGRzLkNsYXNzID09IFwicXdjVGV4dF9EYXRhXCIpIHtcclxucXdjVGV4dF9EYXRhIGRib2JqOTAgPSAocXdjVGV4dF9EYXRhKSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBkcy5DbGFzcywgZHMuSW5zdGFuY2UsIHRoaXMpO1xyXG5pZiAobnVsbCAhPSBkYm9iajkwKSBkYm9iajkwLlJ1blByb3BlcnR5Q2hhbmdlZEluKGRzLGZhbHNlKTtcclxufVxyXG4gXHJcbmVsc2UgaWYoZHMuQ2xhc3MgPT0gXCJxd2NUcmVlVmlld19EYXRhXCIpIHtcclxucXdjVHJlZVZpZXdfRGF0YSBkYm9iajkxID0gKHF3Y1RyZWVWaWV3X0RhdGEpIEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgdGhpcyk7XHJcbmlmIChudWxsICE9IGRib2JqOTEpIGRib2JqOTEuUnVuUHJvcGVydHlDaGFuZ2VkSW4oZHMsZmFsc2UpO1xyXG59XHJcbiBcclxuZWxzZSBpZihkcy5DbGFzcyA9PSBcInF3Y1VwbG9hZGVyX0RhdGFcIikge1xyXG5xd2NVcGxvYWRlcl9EYXRhIGRib2JqOTIgPSAocXdjVXBsb2FkZXJfRGF0YSkgQVBMLkdldEluc3RhbmNlKFwiRGF0YUJpbmRpbmdcIiwgZHMuQ2xhc3MsIGRzLkluc3RhbmNlLCB0aGlzKTtcclxuaWYgKG51bGwgIT0gZGJvYmo5MikgZGJvYmo5Mi5SdW5Qcm9wZXJ0eUNoYW5nZWRJbihkcyxmYWxzZSk7XHJcbn1cclxuIFxyXG5lbHNlIGlmKGRzLkNsYXNzID09IFwiV1NJbnRlcm5hbHNcIikge1xyXG5XU0ludGVybmFscyBkYm9iajkzID0gKFdTSW50ZXJuYWxzKSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBkcy5DbGFzcywgZHMuSW5zdGFuY2UsIHRoaXMpO1xyXG5pZiAobnVsbCAhPSBkYm9iajkzKSBkYm9iajkzLlJ1blByb3BlcnR5Q2hhbmdlZEluKGRzLGZhbHNlKTtcclxufVxyXG4gXHJcbn1cclxuc3RyaW5nIE9uQmVmb3JlVW5sb2FkKG9iamVjdCBlKSB7XHJcbnN0cmluZyBtc2cgPSBcIkRvIHlvdSB3YW50IHRvIGxlYXZlIFFXQz9cIjtcclxuSW50ZXJvcC5FeGVjdXRlSmF2YVNjcmlwdChcIiQwLnByZXZlbnREZWZhdWx0KClcIiwgZSk7XHJcbkludGVyb3AuRXhlY3V0ZUphdmFTY3JpcHQoXCIkMC5yZXR1cm5WYWx1ZSA9ICQxXCIsZSxtc2cpO1xyXG5yZXR1cm4gbXNnO1xyXG59IFxyXG5wcml2YXRlIHZvaWQgTWFrZVdpblNpemUocXdjX1Jvb3QgcnQsIFdTSW50ZXJuYWxzIHdpKXtcclxud2kuU2V0VmFsdWUoXCJTdGF0dXNcIiwgXCJXZWJTb2NrZXQgT3BlbmVkXCIpO1xyXG5TaXplIGZzeiA9IG5ldyBTaXplKCk7XHJcbmZzei5XaWR0aCA9IChkb3VibGUpIEludGVyb3AuRXhlY3V0ZUphdmFTY3JpcHQoXCJzY3JlZW4ud2lkdGhcIik7XHJcbmZzei5IZWlnaHQgPSAoZG91YmxlKSBJbnRlcm9wLkV4ZWN1dGVKYXZhU2NyaXB0KFwic2NyZWVuLmhlaWdodFwiKTtcclxuQXBwbGljYXRpb24uQ3VycmVudC5SZXNvdXJjZXNbXCJGdWxsU2NyZWVuSGVpZ2h0XCJdID0gZnN6LkhlaWdodDtcclxuQXBwbGljYXRpb24uQ3VycmVudC5SZXNvdXJjZXNbXCJGdWxsU2NyZWVuV2lkdGhcIl0gPSBmc3ouV2lkdGg7XHJcbnJ0LlNldFZhbHVlKFwiRnVsbFNjcmVlblNpemVcIixmc3opO1xyXG5XaW5kb3cgd2luID0gV2luZG93LkN1cnJlbnQ7XHJcbkFwcGxpY2F0aW9uLkN1cnJlbnQuUmVzb3VyY2VzW1wiU2NyZWVuXCJdID0gd2luO1xyXG5SZWN0IHJlY3QgPSB3aW4uQm91bmRzO1xyXG5BcHBsaWNhdGlvbi5DdXJyZW50LlJlc291cmNlc1tcIlNjcmVlbkhlaWdodFwiXSA9IHJlY3QuSGVpZ2h0O1xyXG5BcHBsaWNhdGlvbi5DdXJyZW50LlJlc291cmNlc1tcIlNjcmVlbldpZHRoXCJdID0gcmVjdC5XaWR0aDtcclxucnQuU2V0VmFsdWUoXCJTY3JlZW5TaXplXCIscmVjdC5TaXplKTtcclxucnQuU2V0VmFsdWUoXCJCcm93c2VyU2NyZWVuU2l6ZVwiLHJlY3QuU2l6ZSk7XHJcbmRvdWJsZSByYXRpbz0oZG91YmxlKSBJbnRlcm9wLkV4ZWN1dGVKYXZhU2NyaXB0KFwid2luZG93LmRldmljZVBpeGVsUmF0aW9cIik7XHJcbmlmIChyYXRpbzwxKSByYXRpbz0xL3JhdGlvO1xyXG5TaXplIGZTaXplPW5ldyBTaXplKChpbnQpIGZzei5XaWR0aCpyYXRpbywgKGludCkgZnN6LkhlaWdodCpyYXRpbyk7XHJcbkFwcGxpY2F0aW9uLkN1cnJlbnQuUmVzb3VyY2VzW1wiRnVsbFNjcmVlbkhlaWdodFwiXSA9IGZTaXplLkhlaWdodDtcclxuQXBwbGljYXRpb24uQ3VycmVudC5SZXNvdXJjZXNbXCJGdWxsU2NyZWVuV2lkdGhcIl0gPSBmU2l6ZS5XaWR0aDtcclxucnQuU2V0VmFsdWUoXCJGdWxsU2NyZWVuU2l6ZVwiLGZTaXplKTtcclxud2luLlNpemVDaGFuZ2VkICs9IChzMSwgZTEpID0+IHtcclxuU2l6ZSBuZXdzeiA9IGUxLlNpemU7XHJcbnF3Y19Sb290IHJvb3QgPSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBcInF3Y19Sb290XCIsIFwicXdjX1Jvb3RcIiwgdGhpcykgYXMgcXdjX1Jvb3Q7XHJcbnJvb3QuU2V0VmFsdWUoXCJTY3JlZW5TaXplXCIsIG5ld3N6KTtcclxucm9vdC5TZXRWYWx1ZShcIkJyb3dzZXJTY3JlZW5TaXplXCIsIG5ld3N6KTtcclxuZG91YmxlIHJhdGlvMT0oZG91YmxlKSBJbnRlcm9wLkV4ZWN1dGVKYXZhU2NyaXB0KFwid2luZG93LmRldmljZVBpeGVsUmF0aW9cIik7XHJcbmlmIChyYXRpbzE8MSkgcmF0aW8xPTEvcmF0aW8xKzAuNTtcclxuU2l6ZSBmU2l6ZTE9bmV3IFNpemUoKGludCkgZnN6LldpZHRoKnJhdGlvMSwgKGludCkgZnN6LkhlaWdodCpyYXRpbzEpO1xyXG5BcHBsaWNhdGlvbi5DdXJyZW50LlJlc291cmNlc1tcIkZ1bGxTY3JlZW5IZWlnaHRcIl0gPSBmU2l6ZTEuSGVpZ2h0O1xyXG5BcHBsaWNhdGlvbi5DdXJyZW50LlJlc291cmNlc1tcIkZ1bGxTY3JlZW5XaWR0aFwiXSA9IGZTaXplMS5XaWR0aDtcclxucm9vdC5TZXRWYWx1ZShcIkZ1bGxTY3JlZW5TaXplXCIsZlNpemUxKTtcclxuQXBwbGljYXRpb24uQ3VycmVudC5SZXNvdXJjZXNbXCJTY3JlZW5IZWlnaHRcIl0gPSBuZXdzei5IZWlnaHQ7XHJcbkFwcGxpY2F0aW9uLkN1cnJlbnQuUmVzb3VyY2VzW1wiU2NyZWVuV2lkdGhcIl0gPSBuZXdzei5XaWR0aDtcclxuQXBwbGljYXRpb24uQ3VycmVudC5SZXNvdXJjZXNbXCJCcm93c2VyU2NyZWVuSGVpZ2h0XCJdID0gbmV3c3ouSGVpZ2h0O1xyXG5BcHBsaWNhdGlvbi5DdXJyZW50LlJlc291cmNlc1tcIkJyb3dzZXJTY3JlZW5XaWR0aFwiXSA9IG5ld3N6LldpZHRoO1xyXG5TdHJpbmcgZm0gPSAoU3RyaW5nKXJvb3QuR2V0VmFsdWUoXCJGdWxsU2NyZWVuSWRcIik7XHJcbmlmICgwICE9IGZtLkxlbmd0aCkge1xyXG5xd2NGb3JtX0RhdGEgZHMgPSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBcInF3Y0Zvcm1fRGF0YVwiLCBmbSwgdGhpcykgYXMgcXdjRm9ybV9EYXRhO1xyXG5pZiAoZm0gIT0gbnVsbCAmJiA0ID09IChpbnQpZHMuR2V0VmFsdWUoXCJTdGF0ZVwiKSkge1xyXG5kcy5Ob3RpZnlQcm9wZXJ0eUNoYW5nZWQoXCJTaXplXCIpO1xyXG59fVxyXG59O31cclxucHJpdmF0ZSB2b2lkIFVwZGF0ZUJpbmRpbmdMb3N0Rm9jdXMob2JqZWN0IHNlbmRlciwgUm91dGVkRXZlbnRBcmdzIGUpXHJcbnsgXHJcblRleHRCb3ggdHggPSAoVGV4dEJveClzZW5kZXI7XHJcbmlmICgwICE9IHR4LlRleHQuTGVuZ3RoKSB7XHJcbkJpbmRpbmdFeHByZXNzaW9uIGV4cCA9IHR4LkdldEJpbmRpbmdFeHByZXNzaW9uKFRleHRCb3guVGV4dFByb3BlcnR5KTtcclxuTUpIX0NvbW1vbkRhdGEgZG9iaiA9IGV4cC5EYXRhSXRlbSBhcyBNSkhfQ29tbW9uRGF0YTtcclxuc3RyaW5nIGluc3RhbmNlID0gZG9iai5NSkhfSW5zdGFuY2U7XHJcblRyYW5zZmVyU3RyaW5nIGRzID0gVEQuVG9UcmFuc2ZlclN0cmluZyhcIlwiKTtcclxuZHMuTmFtZSA9IGV4cC5QYXJlbnRCaW5kaW5nLlBhdGguUGF0aDtcclxuZHMuRGF0YSA9IHR4LlRleHQ7XHJcbmRzLkluc3RhbmNlID0gaW5zdGFuY2U7XHJcbmRzLkNsYXNzID0gQVBMLkdldENsYXNzQnlOYW1lKGRzLkluc3RhbmNlKTtcclxub2JqZWN0IG9iaiA9IEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgdGhpcyk7XHJcbnZhciBhcmd1bWVudHMgPSBuZXcgb2JqZWN0W10ge2RzLCB0cnVlfTsgIC8vIEFzIGlmIGVudGVyZWQgZnJvbSBzY3JlZW5cclxuQXNzZW1ibHkgYXNzZW1ibHkgPSBBUEwuR2V0QXNzZW1ibHkoXCJEYXRhQmluZGluZ1wiLCB0aGlzKTtcclxuVHlwZSB0eXBlID0gYXNzZW1ibHkuR2V0VHlwZShcIkRhdGFCaW5kaW5nXCIgKyBcIi5cIiArIGRzLkNsYXNzKTtcclxuTWV0aG9kSW5mbyBtZXRob2QgPSB0eXBlLkdldE1ldGhvZChcIlJ1blByb3BlcnR5Q2hhbmdlZEluXCIpO1xyXG5tZXRob2QuSW52b2tlKG9iaiwgYXJndW1lbnRzKTtcclxufX1cclxucHJpdmF0ZSB2b2lkIFVwZGF0ZUJpbmRpbmdLZXlEb3duKG9iamVjdCBzZW5kZXIsIEtleVJvdXRlZEV2ZW50QXJncyBlKVxyXG57IFxyXG5pZiAoZS5LZXkgPT0gVmlydHVhbEtleS5FbnRlcilcclxueyBcclxuVGV4dEJveCB0eCA9IChUZXh0Qm94KXNlbmRlcjtcclxuaWYoMCE9dHguVGV4dC5MZW5ndGgpe1xyXG5CaW5kaW5nRXhwcmVzc2lvbiBleHAgPSB0eC5HZXRCaW5kaW5nRXhwcmVzc2lvbihUZXh0Qm94LlRleHRQcm9wZXJ0eSk7XHJcbk1KSF9Db21tb25EYXRhIGRvYmogPSBleHAuRGF0YUl0ZW0gYXMgTUpIX0NvbW1vbkRhdGE7XHJcbnN0cmluZyBpbnN0YW5jZSA9IGRvYmouTUpIX0luc3RhbmNlO1xyXG5UcmFuc2ZlclN0cmluZyBkcyA9IFRELlRvVHJhbnNmZXJTdHJpbmcoXCJcIik7XHJcbmRzLk5hbWUgPSBleHAuUGFyZW50QmluZGluZy5QYXRoLlBhdGg7XHJcbmRzLkRhdGEgPSB0eC5UZXh0O1xyXG5kcy5JbnN0YW5jZSA9IGluc3RhbmNlO1xyXG5kcy5DbGFzcyA9IEFQTC5HZXRDbGFzc0J5TmFtZShkcy5JbnN0YW5jZSk7XHJcbm9iamVjdCBvYmogPSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBkcy5DbGFzcywgZHMuSW5zdGFuY2UsIHRoaXMpO1xyXG52YXIgYXJndW1lbnRzID0gbmV3IG9iamVjdFtdIHtkcywgdHJ1ZX07ICAgIC8vIEFzIGlmIGVudGVyZWQgZnJvbSBzY3JlZW5cclxuQXNzZW1ibHkgYXNzZW1ibHkgPSBBUEwuR2V0QXNzZW1ibHkoXCJEYXRhQmluZGluZ1wiLCB0aGlzKTtcclxuVHlwZSB0eXBlID0gYXNzZW1ibHkuR2V0VHlwZShcIkRhdGFCaW5kaW5nXCIgKyBcIi5cIiArIGRzLkNsYXNzKTtcclxuTWV0aG9kSW5mbyBtZXRob2QgPSB0eXBlLkdldE1ldGhvZChcIlJ1blByb3BlcnR5Q2hhbmdlZEluXCIpO1xyXG5tZXRob2QuSW52b2tlKG9iaiwgYXJndW1lbnRzKTtcclxufX19XHJcbn19XHJcbiIsInVzaW5nIFN5c3RlbTtcclxudXNpbmcgQVBMRXh0ZW5zaW9uO1xyXG51c2luZyBTeXN0ZW0uUmVmbGVjdGlvbjtcclxudXNpbmcgQVBMQ29udHJvbHM7XHJcbnVzaW5nIFN5c3RlbS5Db2xsZWN0aW9ucy5HZW5lcmljO1xyXG51c2luZyBXaW5kb3dzLlVJLlhhbWw7XHJcbnVzaW5nIERhdGFCaW5kaW5nO1xyXG51c2luZyBDU0hUTUw1O1xyXG5cclxubmFtZXNwYWNlIFFXQ1xyXG57XHJcbiAgICBwdWJsaWMgc3RhdGljIGNsYXNzIE5RXHJcbiAgICB7XHJcbiAgICAgICAgcHVibGljIHN0YXRpYyBTdHJpbmcgRG9BZGRWaXN1YWwoVHJhbnNmZXJTdHJpbmcgZHMsIG9iamVjdCBhY3R0aGlzKVxyXG4gICAgICAgIHtcclxuICAgICAgICAgICAgb2JqZWN0IG9iaiA9IEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgYWN0dGhpcyk7XHJcbiAgICAgICAgICAgIHZhciBhcmd1bWVudHMgPSBuZXcgb2JqZWN0W10geyBkcyB9O1xyXG4gICAgICAgICAgICBBc3NlbWJseSBhc3NlbWJseSA9IEFQTC5HZXRBc3NlbWJseShcIkRhdGFCaW5kaW5nXCIsIGFjdHRoaXMpO1xyXG5cclxuICAgICAgICAgICAgc3RyaW5nIGNsID0gQVBMLkdldENsYXNzQnlOYW1lKGRzLkluc3RhbmNlKTtcclxuICAgICAgICAgICAgaWYgKGNsLkNvbnRhaW5zKFwiX0RhdGFcIikpIGNsID0gY2wuU3Vic3RyaW5nKDAsIGNsLkxlbmd0aCAtIDUpO1xyXG4gICAgICAgICAgICBUeXBlIHR5cGUgPSBhc3NlbWJseS5HZXRUeXBlKFwiRGF0YUJpbmRpbmdcIiArIFwiLlwiICsgY2wpO1xyXG5cclxuICAgICAgICAgICAgTWV0aG9kSW5mbyBtZXRob2QgPSB0eXBlLkdldE1ldGhvZChcIkRvQWRkVmlzdWFsXCIpO1xyXG5cclxuICAgICAgICAgICAgaWYgKFV0aWxzLklzU3RhdGljKG1ldGhvZCkpXHJcbiAgICAgICAgICAgICAgICByZXR1cm4gKFN0cmluZyltZXRob2QuSW52b2tlKG51bGwsIGFyZ3VtZW50cyk7XHJcbiAgICAgICAgICAgIGVsc2VcclxuICAgICAgICAgICAgICAgIHJldHVybiAoU3RyaW5nKW1ldGhvZC5JbnZva2UoKChNSkhfQ29tbW9uRGF0YSlvYmopLk1KSF9DbGFzcywgYXJndW1lbnRzKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHB1YmxpYyBzdGF0aWMgU3RyaW5nIERvUnVuRXZlbnQoVHJhbnNmZXJTdHJpbmcgZHMsIG9iamVjdCBhY3R0aGlzKVxyXG4gICAgICAgIHtcclxuICAgICAgICAgICAgb2JqZWN0IG9iaiA9IEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgYWN0dGhpcyk7XHJcbiAgICAgICAgICAgIHZhciBhcmd1bWVudHMgPSBuZXcgb2JqZWN0W10geyBkcyB9O1xyXG4gICAgICAgICAgICBBc3NlbWJseSBhc3NlbWJseSA9IEFQTC5HZXRBc3NlbWJseShcIkRhdGFCaW5kaW5nXCIsIGFjdHRoaXMpO1xyXG5cclxuICAgICAgICAgICAgc3RyaW5nIGNsID0gQVBMLkdldENsYXNzQnlOYW1lKGRzLkluc3RhbmNlKTtcclxuICAgICAgICAgICAgaWYgKGNsLkNvbnRhaW5zKFwiX0RhdGFcIikpIGNsID0gY2wuU3Vic3RyaW5nKDAsIGNsLkxlbmd0aCAtIDUpO1xyXG4gICAgICAgICAgICBUeXBlIHR5cGUgPSBhc3NlbWJseS5HZXRUeXBlKFwiRGF0YUJpbmRpbmdcIiArIFwiLlwiICsgY2wpO1xyXG5cclxuICAgICAgICAgICAgTWV0aG9kSW5mbyBtZXRob2QgPSB0eXBlLkdldE1ldGhvZChcIkRvUnVuRXZlbnRcIik7XHJcblxyXG4gICAgICAgICAgICBzdHJpbmcgcmVzdWx0ID0gXCJcIjtcclxuICAgICAgICAgICAgaWYgKG1ldGhvZCAhPSBudWxsKVxyXG4gICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICBpZiAoVXRpbHMuSXNTdGF0aWMobWV0aG9kKSlcclxuICAgICAgICAgICAgICAgICAgICByZXN1bHQgPSAoU3RyaW5nKW1ldGhvZC5JbnZva2UobnVsbCwgYXJndW1lbnRzKTtcclxuICAgICAgICAgICAgICAgIGVsc2VcclxuICAgICAgICAgICAgICAgICAgICByZXN1bHQgPSAoU3RyaW5nKW1ldGhvZC5JbnZva2UoKChNSkhfQ29tbW9uRGF0YSlvYmopLk1KSF9DbGFzcywgYXJndW1lbnRzKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICByZXR1cm4gcmVzdWx0O1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcHVibGljIHN0YXRpYyBTdHJpbmcgRG9SdW5NZXRob2QoVHJhbnNmZXJTdHJpbmcgZHMsIG9iamVjdCBhY3R0aGlzKVxyXG4gICAgICAgIHtcclxuICAgICAgICAgICAgc3RyaW5nIHJlc3VsdCA9IFwiXCI7XHJcbiAgICAgICAgICAgIG9iamVjdCBvYmogPSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBkcy5DbGFzcywgZHMuSW5zdGFuY2UsIGFjdHRoaXMpO1xyXG4gICAgICAgICAgICB2YXIgYXJndW1lbnRzID0gbmV3IG9iamVjdFtdIHsgZHMgfTtcclxuICAgICAgICAgICAgQXNzZW1ibHkgYXNzZW1ibHkgPSBBUEwuR2V0QXNzZW1ibHkoXCJEYXRhQmluZGluZ1wiLCBhY3R0aGlzKTtcclxuICAgICAgICAgICAgc3RyaW5nIGNsID0gQVBMLkdldENsYXNzQnlOYW1lKGRzLkluc3RhbmNlKTtcclxuXHJcbiAgICAgICAgICAgIGlmIChjbC5Db250YWlucyhcIl9EYXRhXCIpKSBjbCA9IGNsLlN1YnN0cmluZygwLCBjbC5MZW5ndGggLSA1KTtcclxuICAgICAgICAgICAgVHlwZSB0eXBlID0gYXNzZW1ibHkuR2V0VHlwZShcIkRhdGFCaW5kaW5nXCIgKyBcIi5cIiArIGNsKTtcclxuICAgICAgICAgICAgTWV0aG9kSW5mbyBtZXRob2QgPSB0eXBlLkdldE1ldGhvZChcIkRvXCIgKyBkcy5EYXRhKTtcclxuXHJcbiAgICAgICAgICAgIGlmIChtZXRob2QgIT0gbnVsbClcclxuICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgaWYgKFV0aWxzLklzU3RhdGljKG1ldGhvZCkpIHJlc3VsdCA9IChTdHJpbmcpbWV0aG9kLkludm9rZShudWxsLCBhcmd1bWVudHMpO1xyXG4gICAgICAgICAgICAgICAgZWxzZSByZXN1bHQgPSAoU3RyaW5nKW1ldGhvZC5JbnZva2UoKChNSkhfQ29tbW9uRGF0YSlvYmopLk1KSF9DbGFzcywgYXJndW1lbnRzKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICByZXR1cm4gcmVzdWx0O1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcHVibGljIHN0YXRpYyBzdHJpbmcgRG9HZXRTZXJpYWxObyhUcmFuc2ZlclN0cmluZyBkcywgb2JqZWN0IGFjdHRoaXMpXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgICBNSkhfQ29tbW9uRGF0YSBvYmogPSAoTUpIX0NvbW1vbkRhdGEpQVBMLkdldEluc3RhbmNlKFwiRGF0YUJpbmRpbmdcIiwgZHMuQ2xhc3MsIGRzLkluc3RhbmNlLCBhY3R0aGlzKTtcclxuICAgICAgICAgICAgc3RyaW5nIHJlc3VsdCA9IG9iai5NSkhfU2VyaWFsTm87XHJcbiAgICAgICAgICAgIHJldHVybiByZXN1bHQ7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBwcml2YXRlIHN0YXRpYyBvYmplY3QgTG9ja0luc3RhbmNlcyA9IG5ldyBPYmplY3QoKTtcclxuXHJcbiAgICAgICAgcHVibGljIHN0YXRpYyBzdHJpbmcgRG9EZWxldGUoVHJhbnNmZXJTdHJpbmcgZHMsIG9iamVjdCBhY3R0aGlzKVxyXG4gICAgICAgIHtcclxuICAgICAgICAgICAgaWYgKGRzLkNsYXNzID09IFwicXdjX1Jvb3RcIikgcmV0dXJuIChcIlwiKTtcclxuICAgICAgICAgICAgc3RyaW5nIHJlc3VsdCA9IFwiXCI7XHJcblxyXG4gICAgICAgICAgICBvYmplY3Qgb2JqID0gQVBMLkdldEluc3RhbmNlKGRzLlNlcmlhbE5vKTtcclxuICAgICAgICAgICAgdmFyIGFyZ3VtZW50cyA9IG5ldyBvYmplY3RbXSB7IGRzIH07XHJcbiAgICAgICAgICAgIEFzc2VtYmx5IGFzc2VtYmx5ID0gQVBMLkdldEFzc2VtYmx5KFwiRGF0YUJpbmRpbmdcIiwgYWN0dGhpcyk7XHJcbiAgICAgICAgICAgIGlmICgwICE9IGRzLlNlcmlhbE5vLkxlbmd0aClcclxuICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgc3RyaW5nIGNsID0gQVBMLkdldENsYXNzQnlTZXJpYWxObyhkcy5TZXJpYWxObyk7XHJcblx0XHRcdFx0aWYgKDAgIT0gY2wuTGVuZ3RoKSB7XHJcblx0XHRcdFx0XHRpZiAoY2wuQ29udGFpbnMoXCJfRGF0YVwiKSkgY2wgPSBjbC5TdWJzdHJpbmcoMCwgY2wuTGVuZ3RoIC0gNSk7XHJcblx0XHRcdFx0XHRUeXBlIHR5cGUgPSBhc3NlbWJseS5HZXRUeXBlKFwiRGF0YUJpbmRpbmdcIiArIFwiLlwiICsgY2wpO1xyXG5cclxuXHRcdFx0XHRcdE1ldGhvZEluZm8gbWV0aG9kID0gdHlwZS5HZXRNZXRob2QoXCJEb0RlbGV0ZVwiKTtcclxuXHJcblx0XHRcdFx0XHRpZiAobWV0aG9kICE9IG51bGwpXHJcblx0XHRcdFx0XHR7XHJcblx0XHRcdFx0XHRcdGlmIChVdGlscy5Jc1N0YXRpYyhtZXRob2QpKVxyXG5cdFx0XHRcdFx0XHRcdHJlc3VsdCA9IChTdHJpbmcpbWV0aG9kLkludm9rZShudWxsLCBhcmd1bWVudHMpO1xyXG5cdFx0XHRcdFx0XHRlbHNlXHJcblx0XHRcdFx0XHRcdHtcclxuXHRcdFx0XHRcdFx0XHRNSkhfQ29tbW9uRGF0YSBzZWxmID0gKE1KSF9Db21tb25EYXRhKW9iajtcclxuXHRcdFx0XHRcdFx0XHRyZXN1bHQgPSAoU3RyaW5nKW1ldGhvZC5JbnZva2Uoc2VsZi5NSkhfQ2xhc3MsIGFyZ3VtZW50cyk7XHJcblx0XHRcdFx0XHRcdH1cclxuXHRcdFx0XHRcdH1cclxuXHRcdFx0ICAgfVxyXG4gICAgICAgICAgICAgICAgcmV0dXJuIHJlc3VsdDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIHJldHVybiBcIlwiO1xyXG4gICAgICAgIH1cclxuXHRcdHB1YmxpYyBzdGF0aWMgc3RyaW5nIERvU2V0QWNjZWxlcmF0b3IoVHJhbnNmZXJTdHJpbmcgZHMsIG9iamVjdCBhY3R0aGlzKVxyXG4gICAgICAgIHtcclxuICAgICAgICAgICAgaW50IGtleSA9IENvbnZlcnQuVG9JbnQzMihkcy5BcmdzKTtcclxuICAgICAgICAgICAgaWYgKGtleSAhPSAwKVxyXG4gICAgICAgICAgICB7IC8vIEFkZFxyXG4gICAgICAgICAgICAgICAgQWNjZWxlcmF0b3IuQWRkKGtleSwgZHMuSW5zdGFuY2UpO1xyXG4gICAgICAgICAgICB9IGVsc2UgXHJcbiAgICAgICAgICAgIHsgLy8gUmVtb3ZlXHJcbiAgICAgICAgICAgICAgICBBY2NlbGVyYXRvci5SZW1vdmUoa2V5LCBkcy5JbnN0YW5jZSk7XHJcblxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHJldHVybiBcIlwiO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG4iXQp9Cg==

/**
 * @version 1.0.0.0
 * @author MJH Software Services Ltd
 * @copyright MJH @2017
 * @compiler Bridge.NET 17.9.0
 */
Bridge.assembly("QWC", function ($asm, globals) {
    "use strict";

    Bridge.define("\u01c0\u01c0Qwc\u01c0\u01c0Component\u01c0\u01c0App\u01c0\u01c0Xaml\u01c0\u01c0Factory", {
        statics: {
            methods: {
                Instantiate: function () {
                    var type = QWC.App;
                    return Bridge.global.CSHTML5.Internal.TypeInstantiationHelper.Instantiate(type);
                }
            }
        }
    });

    Bridge.define("\u01c0\u01c0Qwc\u01c0\u01c0Component\u01c0\u01c0Mainpage\u01c0\u01c0Xaml\u01c0\u01c0Factory", {
        statics: {
            methods: {
                Instantiate: function () {
                    var type = QWC.MainPage;
                    return Bridge.global.CSHTML5.Internal.TypeInstantiationHelper.Instantiate(type);
                }
            }
        }
    });

    Bridge.define("QWC.App", {
        inherits: [Windows.UI.Xaml.Application],
        main: function Main () {
            new QWC.App();
        },
        fields: {
            d: null,
            _contentLoaded: false
        },
        ctors: {
            ctor: function () {
                this.$initialize();
                Windows.UI.Xaml.Application.ctor.call(this);
                this.InitializeComponent();
                try {
                    var a = new DataBinding.SenderClass();
                    Windows.UI.Xaml.Application.Current.Resources.setItem("SenderClass", a);
                    Windows.UI.Xaml.Application.Current.Resources.setItem("QWC", this);
                } catch ($e1) {
                    $e1 = System.Exception.create($e1);
                }
                var mainPage = new QWC.MainPage();
                if (mjh_filesloaded) mjh_filesloaded['page'] = mainPage;
                Windows.UI.Xaml.Window.Current.Content = mainPage;
            }
        },
        methods: {
            RunClickMin: function (s, args) {
                var dc = Bridge.cast(Bridge.cast(s, Windows.UI.Xaml.Controls.Button).DataContext, DataBinding.qwcForm_Data);
                dc.SendMargin = false;
                dc.State = 1;
                var root = Bridge.as(APLExtension.APL.GetInstance$3("DataBinding", "qwc_Root", "qwc_Root", this), DataBinding.qwc_Root);
                root.FullScreenId = "";
            },
            RunClickMax: function (s, args) {
                var dc = Bridge.cast(Bridge.cast(s, Windows.UI.Xaml.Controls.Button).DataContext, DataBinding.qwcForm_Data);
                dc.SendMargin = false;
                if (2 === dc.State) {
                    dc.State = 0;
                } else {
                    dc.State = 2;
                }
                var root = Bridge.as(APLExtension.APL.GetInstance$3("DataBinding", "qwc_Root", "qwc_Root", this), DataBinding.qwc_Root);
                root.FullScreenId = "";
            },
            RunClickFullScreen: function (s, args) {
                var dc = Bridge.cast(Bridge.cast(s, Windows.UI.Xaml.Controls.Button).DataContext, DataBinding.qwcForm_Data);
                var obj = Bridge.as(dc.MJH_Self, APLControls.APLForm);
                dc.SendMargin = false;
                var elem = CSHTML5.Interop.GetDiv(obj);
                openFullscreen(elem);
                dc.State = 4;
                var root = Bridge.as(APLExtension.APL.GetInstance$3("DataBinding", "qwc_Root", "qwc_Root", this), DataBinding.qwc_Root);
                root.FullScreenId = dc.Name;
            },
            RunClickClose: function (s, args) {
                var dc = Bridge.cast(Bridge.cast(s, Windows.UI.Xaml.Controls.Button).DataContext, DataBinding.qwcForm_Data);
                dc.SendMargin = false;
                var eventname = "ClickClose";
                var obj = Bridge.as(dc.MJH_Self, APLControls.APLForm);
                obj.Close$1();
            },
            InitializeComponent: function () {
                var $t;
                if (this._contentLoaded) {
                    return;
                }
                this._contentLoaded = true;


                if (Bridge.is(this, Windows.UI.Xaml.UIElement)) {
                    Bridge.cast(this, Windows.UI.Xaml.UIElement).XamlSourcePath = "QWC\\App.xaml";
                }


                Bridge.global.CSHTML5.Internal.StartupAssemblyInfo.OutputRootPath = "Output\\";
                Bridge.global.CSHTML5.Internal.StartupAssemblyInfo.OutputAppFilesPath = "app-cshtml5\\app\\";
                Bridge.global.CSHTML5.Internal.StartupAssemblyInfo.OutputLibrariesPath = "app-cshtml5\\libs\\";
                Bridge.global.CSHTML5.Internal.StartupAssemblyInfo.OutputResourcesPath = "app-cshtml5\\res\\";


                var ResourceDictionary_60529c843b80490a9ff1ff97b3e74a7a = new Bridge.global.Windows.UI.Xaml.ResourceDictionary();
                this.Resources = ResourceDictionary_60529c843b80490a9ff1ff97b3e74a7a;
                var IntConverter_48f3773072e74dd69250293eeaeb52c4 = new Bridge.global.APLExtension.IntConverter();

                var DecConverter_45ea840ac8534a1f8587f54dd8ec4136 = new Bridge.global.APLExtension.DecConverter();

                var ToPolyLineConverter_48eb4abc3ee94ca7a9771de392690e51 = new Bridge.global.APLExtension.ToPolyLineConverter();

                var ToPointsConverter_6db966474058452da8d970b40c953732 = new Bridge.global.APLExtension.ToPointsConverter();

                var ToLinesConverter_0269dd88156f47ffb6edbed85b6abef0 = new Bridge.global.APLExtension.ToLinesConverter();

                var APLColorConverter_0bc1bf56d05847349777da3ff0bf423d = new Bridge.global.APLExtension.APLColorConverter();

                var APLColorCSSConverter_18fd023ef7c343bcb948aded43c0a250 = new Bridge.global.APLExtension.APLColorCSSConverter();

                var APLMultiColorConverter_e2118d6be5af4fda8eb2ddef9de2e6f6 = new Bridge.global.APLExtension.APLMultiColorConverter();

                var APLMultiColorCSSConverter_6e190048f37248d5a87b14da11fdee4a = new Bridge.global.APLExtension.APLMultiColorCSSConverter();

                var IndexInt32Converter_f1b816a0d925448fa86166c730aa2d18 = new Bridge.global.APLExtension.IndexInt32Converter();

                var IndexDoubleConverter_2510a88d51d248b481854a6a152e273d = new Bridge.global.APLExtension.IndexDoubleConverter();

                var IndexStringConverter_003c9f1518d14a16a6a7d7e58311216a = new Bridge.global.APLExtension.IndexStringConverter();

                var IndexAPLColorConverter_cba8c7b1c5fc4ec99f928b40fc1fda15 = new Bridge.global.APLExtension.IndexAPLColorConverter();

                var IndexAPLColourConverter_319a2cf3bced49dc9ce9456071443c1a = new Bridge.global.APLExtension.IndexAPLColourConverter();

                var MathsIConverter_eaff56b6583c49909d170a4b82674190 = new Bridge.global.APLExtension.MathsIConverter();

                var MathsDConverter_4c4e649612744fcfbc4bf25711a0544e = new Bridge.global.APLExtension.MathsDConverter();

                var MathIConverter_cf36b9bdc6584cb6af978c6d35a1c5b5 = new Bridge.global.APLExtension.MathIConverter();

                var MathDConverter_f0dad1f43a9e45c3a86096ab49386c9c = new Bridge.global.APLExtension.MathDConverter();

                var String_fc095f6795a747ce9c5f3da3df71b8e1 = "\u2395WC Cross Platform";

                var String_cb20f7e1cd414d0597a1b961334819df = "MJH Software Services Ltd";

                var String_e560e164bc914bd99dda979cd7293ab5 = "MJH Software Services Ltd";

                var String_a5f84866a81a4108b17ae3464581ece7 = "QWC";

                var String_e69ae49aa56a47acb11ed4a18e32cb67 = "\u2395WC Cross Platform";

                var String_b7a3b20fe02d4cacb6bf206e3f47edf6 = "mjh.ico";

                var String_0815727ca46d4f458815cdae81bffef8 = "12345";

                var String_2744e66a4c83457c9dd2526ecd12603f = "MainPage";

                var String_469436105e9744a6ac5d120dc5877584 = "MainPage:Page";

                var String_1bca7b5271304e3e98ac60db962adc17 = "Direct";

                var String_3a3425b761d748299068e98954e38a0a = "QWC";

                var Style_20132bae93364701b5f3fee185480248 = new Bridge.global.Windows.UI.Xaml.Style.ctor();
                Style_20132bae93364701b5f3fee185480248.TargetType = Bridge.global.Windows.UI.Xaml.Controls.ChildWindow;
                var Setter_017fadc47e5a4468bffeb7f46bdf2242 = new Bridge.global.Windows.UI.Xaml.Setter.ctor();
                Setter_017fadc47e5a4468bffeb7f46bdf2242.Property = Bridge.global.Windows.UI.Xaml.Controls.ChildWindow.OverlayBrushProperty;
                Setter_017fadc47e5a4468bffeb7f46bdf2242.Value = new Bridge.global.Windows.UI.Xaml.Media.SolidColorBrush.$ctor1(($t = new Bridge.global.Windows.UI.Color(), $t.A = 0, $t.R = 255, $t.G = 255, $t.B = 255, $t));

                var Setter_9df1a7de54fa4b669f623db578dcf791 = new Bridge.global.Windows.UI.Xaml.Setter.ctor();
                Setter_9df1a7de54fa4b669f623db578dcf791.Property = Bridge.global.Windows.UI.Xaml.Controls.ChildWindow.OverlayOpacityProperty;
                Setter_9df1a7de54fa4b669f623db578dcf791.Value = Bridge.box(1.0, System.Double, System.Double.format, System.Double.getHashCode);

                var Setter_655906b58a0e44bfa7b41edf4589f8e4 = new Bridge.global.Windows.UI.Xaml.Setter.ctor();
                Setter_655906b58a0e44bfa7b41edf4589f8e4.Property = Bridge.global.Windows.UI.Xaml.FrameworkElement.HorizontalAlignmentProperty;
                Setter_655906b58a0e44bfa7b41edf4589f8e4.Value = Bridge.box(Bridge.global.Windows.UI.Xaml.HorizontalAlignment.Left, Windows.UI.Xaml.HorizontalAlignment, System.Enum.toStringFn(Windows.UI.Xaml.HorizontalAlignment));

                var Setter_1b47d0bf526a45ab87325408e91a8e3b = new Bridge.global.Windows.UI.Xaml.Setter.ctor();
                Setter_1b47d0bf526a45ab87325408e91a8e3b.Property = Bridge.global.Windows.UI.Xaml.FrameworkElement.VerticalAlignmentProperty;
                Setter_1b47d0bf526a45ab87325408e91a8e3b.Value = Bridge.box(Bridge.global.Windows.UI.Xaml.VerticalAlignment.Top, Windows.UI.Xaml.VerticalAlignment, System.Enum.toStringFn(Windows.UI.Xaml.VerticalAlignment));

                var Setter_2c682a5649a848838cb7962fa3ae4aaa = new Bridge.global.Windows.UI.Xaml.Setter.ctor();
                Setter_2c682a5649a848838cb7962fa3ae4aaa.Property = Bridge.global.Windows.UI.Xaml.Controls.Control.TemplateProperty;
                var ControlTemplate_e605c0cf1fea434987750ca63377929d = new Bridge.global.Windows.UI.Xaml.Controls.ControlTemplate();
                ControlTemplate_e605c0cf1fea434987750ca63377929d.TargetType = Bridge.global.Windows.UI.Xaml.Controls.ChildWindow;
                ControlTemplate_e605c0cf1fea434987750ca63377929d.SetMethodToInstantiateFrameworkTemplate(Bridge.fn.bind(this, function (templateOwner_ControlTemplate_e605c0cf1fea434987750ca63377929d) {
                    var $t1;
                    var templateInstance_6c6a561153964fb6ac52735fff3f503c = new Bridge.global.Windows.UI.Xaml.TemplateInstance();
                    templateInstance_6c6a561153964fb6ac52735fff3f503c.TemplateOwner = templateOwner_ControlTemplate_e605c0cf1fea434987750ca63377929d;
                    var VisualState_6d5a5de1dcbc4c4fb338b58cb9f71abb = new Bridge.global.Windows.UI.Xaml.VisualState();
                    var VisualState_cc179cf20f174cd0b3620a5c9832025a = new Bridge.global.Windows.UI.Xaml.VisualState();
                    var VisualStateGroup_c08a352165854351be40aae4cf120b23 = new Bridge.global.Windows.UI.Xaml.VisualStateGroup();
                    var Grid_74407138227c4266a7548bf17b206baf = new Bridge.global.Windows.UI.Xaml.Controls.Grid();
                    var Button_abdae32fbc8f4a76a2044a34790b0daa = new Bridge.global.Windows.UI.Xaml.Controls.Button();
                    var ContentControl_8b8dd66a01294664ba5eebc43f22408f = new Bridge.global.Windows.UI.Xaml.Controls.ContentControl();
                    var Button_59f24a121abe4d2ba85d2f39440177a9 = new Bridge.global.Windows.UI.Xaml.Controls.Button();
                    var Button_c9e7d73cd24b45df83e8191f85827a5c = new Bridge.global.Windows.UI.Xaml.Controls.Button();
                    var Button_88741b5e30e14f5dbbf1a08194c66f21 = new Bridge.global.Windows.UI.Xaml.Controls.Button();
                    var Button_abf446ec47ae404b86a98ae3da450843 = new Bridge.global.Windows.UI.Xaml.Controls.Button();
                    var Button_7a1cb3fe1fa14fcbbfb747333417ab25 = new Bridge.global.Windows.UI.Xaml.Controls.Button();
                    var Border_3c305b883aa54d1798930e026fdf6ca3 = new Bridge.global.Windows.UI.Xaml.Controls.Border();
                    var ContentPresenter_8843295653e94ccd81d61e398ec70514 = new Bridge.global.Windows.UI.Xaml.Controls.ContentPresenter();
                    var Border_a8e50cb52e5a4d0e85b977a2171a5678 = new Bridge.global.Windows.UI.Xaml.Controls.Border();
                    var Border_bb78b02e0592479bb1ce4efe59a3fa52 = new Bridge.global.Windows.UI.Xaml.Controls.Border();
                    var Grid_59b9da72ba604066a4d824c50526f58a = new Bridge.global.Windows.UI.Xaml.Controls.Grid();
                    templateOwner_ControlTemplate_e605c0cf1fea434987750ca63377929d.RegisterName("Root", Grid_59b9da72ba604066a4d824c50526f58a);
                    Grid_59b9da72ba604066a4d824c50526f58a.Name = "Root";
                    Grid_59b9da72ba604066a4d824c50526f58a.RenderTransformOrigin = new Bridge.global.Windows.Foundation.Point.$ctor1(0, 0);
                    templateOwner_ControlTemplate_e605c0cf1fea434987750ca63377929d.RegisterName("ModalStates", VisualStateGroup_c08a352165854351be40aae4cf120b23);
                    VisualStateGroup_c08a352165854351be40aae4cf120b23.Name = "ModalStates";
                    templateOwner_ControlTemplate_e605c0cf1fea434987750ca63377929d.RegisterName("NotModal", VisualState_6d5a5de1dcbc4c4fb338b58cb9f71abb);
                    VisualState_6d5a5de1dcbc4c4fb338b58cb9f71abb.Name = "NotModal";
                    var Storyboard_161b9c8a1db14ff194a28384c4a8d69d = new Bridge.global.Windows.UI.Xaml.Media.Animation.Storyboard();
                    var ObjectAnimationUsingKeyFrames_6dec4dc1050747769c8b5c4c0221ab03 = new Bridge.global.Windows.UI.Xaml.Media.Animation.ObjectAnimationUsingKeyFrames();
                    Bridge.global.Windows.UI.Xaml.Media.Animation.Storyboard.SetTargetName(ObjectAnimationUsingKeyFrames_6dec4dc1050747769c8b5c4c0221ab03, "Overlay");
                    var DiscreteObjectKeyFrame_d648595171e0418fb6f742b2d464dc8b = new Bridge.global.Windows.UI.Xaml.Media.Animation.DiscreteObjectKeyFrame();
                    var NullExtension_c399521555124f4c9abb4a995b2d002d = new Bridge.global.System.Windows.Markup.NullExtension();

                    DiscreteObjectKeyFrame_d648595171e0418fb6f742b2d464dc8b.Value = null;


                    ObjectAnimationUsingKeyFrames_6dec4dc1050747769c8b5c4c0221ab03.KeyFrames.add(DiscreteObjectKeyFrame_d648595171e0418fb6f742b2d464dc8b);


                    var ObjectAnimationUsingKeyFrames_a4fbc0904bac4743bf342da089563dc5 = new Bridge.global.Windows.UI.Xaml.Media.Animation.ObjectAnimationUsingKeyFrames();
                    Bridge.global.Windows.UI.Xaml.Media.Animation.Storyboard.SetTargetName(ObjectAnimationUsingKeyFrames_a4fbc0904bac4743bf342da089563dc5, "Overlay");
                    var DiscreteObjectKeyFrame_f0480c6e737e4cda87f3b6586e393ad1 = new Bridge.global.Windows.UI.Xaml.Media.Animation.DiscreteObjectKeyFrame();
                    DiscreteObjectKeyFrame_f0480c6e737e4cda87f3b6586e393ad1.Value = "False";

                    ObjectAnimationUsingKeyFrames_a4fbc0904bac4743bf342da089563dc5.KeyFrames.add(DiscreteObjectKeyFrame_f0480c6e737e4cda87f3b6586e393ad1);


                    Storyboard_161b9c8a1db14ff194a28384c4a8d69d.Children.add(ObjectAnimationUsingKeyFrames_6dec4dc1050747769c8b5c4c0221ab03);
                    Storyboard_161b9c8a1db14ff194a28384c4a8d69d.Children.add(ObjectAnimationUsingKeyFrames_a4fbc0904bac4743bf342da089563dc5);


                    VisualState_6d5a5de1dcbc4c4fb338b58cb9f71abb.Storyboard = Storyboard_161b9c8a1db14ff194a28384c4a8d69d;


                    templateOwner_ControlTemplate_e605c0cf1fea434987750ca63377929d.RegisterName("Modal", VisualState_cc179cf20f174cd0b3620a5c9832025a);
                    VisualState_cc179cf20f174cd0b3620a5c9832025a.Name = "Modal";

                    System.Array.add(VisualStateGroup_c08a352165854351be40aae4cf120b23.States, VisualState_6d5a5de1dcbc4c4fb338b58cb9f71abb, Object);
                    System.Array.add(VisualStateGroup_c08a352165854351be40aae4cf120b23.States, VisualState_cc179cf20f174cd0b3620a5c9832025a, Object);


                    templateOwner_ControlTemplate_e605c0cf1fea434987750ca63377929d.INTERNAL_GetVisualStateGroups().add(VisualStateGroup_c08a352165854351be40aae4cf120b23);

                    templateOwner_ControlTemplate_e605c0cf1fea434987750ca63377929d.RegisterName("Overlay", Grid_74407138227c4266a7548bf17b206baf);
                    Grid_74407138227c4266a7548bf17b206baf.Name = "Overlay";
                    Grid_74407138227c4266a7548bf17b206baf.HorizontalAlignment = Bridge.global.Windows.UI.Xaml.HorizontalAlignment.Stretch;
                    Grid_74407138227c4266a7548bf17b206baf.VerticalAlignment = Bridge.global.Windows.UI.Xaml.VerticalAlignment.Stretch;
                    Grid_74407138227c4266a7548bf17b206baf.Margin = new Bridge.global.Windows.UI.Xaml.Thickness.$ctor1(0);
                    var Binding_da97ae5142704435a133133417216a78 = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_da97ae5142704435a133133417216a78.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("OverlayBrush");
                    var RelativeSource_36231bae41fb4e3ead5b5f6c124a6e70 = new Bridge.global.Windows.UI.Xaml.Data.RelativeSource.ctor();
                    RelativeSource_36231bae41fb4e3ead5b5f6c124a6e70.Mode = Bridge.global.Windows.UI.Xaml.Data.RelativeSourceMode.TemplatedParent;

                    Binding_da97ae5142704435a133133417216a78.RelativeSource = RelativeSource_36231bae41fb4e3ead5b5f6c124a6e70;


                    Binding_da97ae5142704435a133133417216a78.TemplateOwner = templateInstance_6c6a561153964fb6ac52735fff3f503c;

                    var Binding_6201c3c144a94f79b60cc70d797dfc4a = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_6201c3c144a94f79b60cc70d797dfc4a.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("OverlayOpacity");
                    var RelativeSource_62d849baa2bc447c920dba196d2fd353 = new Bridge.global.Windows.UI.Xaml.Data.RelativeSource.ctor();
                    RelativeSource_62d849baa2bc447c920dba196d2fd353.Mode = Bridge.global.Windows.UI.Xaml.Data.RelativeSourceMode.TemplatedParent;

                    Binding_6201c3c144a94f79b60cc70d797dfc4a.RelativeSource = RelativeSource_62d849baa2bc447c920dba196d2fd353;


                    Binding_6201c3c144a94f79b60cc70d797dfc4a.TemplateOwner = templateInstance_6c6a561153964fb6ac52735fff3f503c;


                    templateOwner_ControlTemplate_e605c0cf1fea434987750ca63377929d.RegisterName("ContentRoot", Border_bb78b02e0592479bb1ce4efe59a3fa52);
                    Border_bb78b02e0592479bb1ce4efe59a3fa52.Name = "ContentRoot";
                    templateOwner_ControlTemplate_e605c0cf1fea434987750ca63377929d.RegisterName("ContentContainer", Border_a8e50cb52e5a4d0e85b977a2171a5678);
                    Border_a8e50cb52e5a4d0e85b977a2171a5678.Name = "ContentContainer";
                    Border_a8e50cb52e5a4d0e85b977a2171a5678.Background = new Bridge.global.Windows.UI.Xaml.Media.SolidColorBrush.$ctor1(($t1 = new Bridge.global.Windows.UI.Color(), $t1.A = 255, $t1.R = 246, $t1.G = 246, $t1.B = 246, $t1));
                    Border_a8e50cb52e5a4d0e85b977a2171a5678.CornerRadius = new Bridge.global.Windows.UI.Xaml.CornerRadius.$ctor1(2);
                    var Grid_42628d274d834483b6119420b1909faf = new Bridge.global.Windows.UI.Xaml.Controls.Grid();
                    var RowDefinition_19c63f9221134004a4013863b910e1a2 = new Bridge.global.Windows.UI.Xaml.Controls.RowDefinition();
                    RowDefinition_19c63f9221134004a4013863b910e1a2.Height = new Bridge.global.Windows.UI.Xaml.GridLength.$ctor2(1.0, Bridge.global.Windows.UI.Xaml.GridUnitType.Auto);

                    var RowDefinition_d6923a113ba1411984482b8adafb68c8 = new Bridge.global.Windows.UI.Xaml.Controls.RowDefinition();
                    RowDefinition_d6923a113ba1411984482b8adafb68c8.Height = new Bridge.global.Windows.UI.Xaml.GridLength.$ctor2(1.0, Bridge.global.Windows.UI.Xaml.GridUnitType.Star);

                    Grid_42628d274d834483b6119420b1909faf.RowDefinitions.add(RowDefinition_19c63f9221134004a4013863b910e1a2);
                    Grid_42628d274d834483b6119420b1909faf.RowDefinitions.add(RowDefinition_d6923a113ba1411984482b8adafb68c8);

                    templateOwner_ControlTemplate_e605c0cf1fea434987750ca63377929d.RegisterName("Chrome", Border_3c305b883aa54d1798930e026fdf6ca3);
                    Border_3c305b883aa54d1798930e026fdf6ca3.Name = "Chrome";
                    Border_3c305b883aa54d1798930e026fdf6ca3.Width = Number.NaN;
                    Border_3c305b883aa54d1798930e026fdf6ca3.BorderBrush = new Bridge.global.Windows.UI.Xaml.Media.SolidColorBrush.$ctor1(($t1 = new Bridge.global.Windows.UI.Color(), $t1.A = 255, $t1.R = 255, $t1.G = 255, $t1.B = 255, $t1));
                    Border_3c305b883aa54d1798930e026fdf6ca3.BorderThickness = new Bridge.global.Windows.UI.Xaml.Thickness.$ctor2(0, 0, 0, 0);
                    Border_3c305b883aa54d1798930e026fdf6ca3.Background = new Bridge.global.Windows.UI.Xaml.Media.SolidColorBrush.$ctor1(($t1 = new Bridge.global.Windows.UI.Color(), $t1.A = 255, $t1.R = 238, $t1.G = 238, $t1.B = 238, $t1));
                    var Grid_6c0a6ad7e1d5487ab6eab37754f57b0a = new Bridge.global.Windows.UI.Xaml.Controls.Grid();
                    var ColumnDefinition_17fd734d0a4f42cd8506d4a319ba7817 = new Bridge.global.Windows.UI.Xaml.Controls.ColumnDefinition();
                    ColumnDefinition_17fd734d0a4f42cd8506d4a319ba7817.Width = new Bridge.global.Windows.UI.Xaml.GridLength.$ctor2(1.0, Bridge.global.Windows.UI.Xaml.GridUnitType.Auto);

                    var ColumnDefinition_e79d66609d03487e96b49eadac0dd504 = new Bridge.global.Windows.UI.Xaml.Controls.ColumnDefinition();
                    ColumnDefinition_e79d66609d03487e96b49eadac0dd504.Width = new Bridge.global.Windows.UI.Xaml.GridLength.$ctor2(1.0, Bridge.global.Windows.UI.Xaml.GridUnitType.Star);

                    var ColumnDefinition_7cf704b66df2423f8fb4a6c9cf080880 = new Bridge.global.Windows.UI.Xaml.Controls.ColumnDefinition();
                    ColumnDefinition_7cf704b66df2423f8fb4a6c9cf080880.Width = new Bridge.global.Windows.UI.Xaml.GridLength.$ctor2(1.0, Bridge.global.Windows.UI.Xaml.GridUnitType.Auto);

                    var ColumnDefinition_7194b0d01768410d9d51e072ce6646ad = new Bridge.global.Windows.UI.Xaml.Controls.ColumnDefinition();
                    ColumnDefinition_7194b0d01768410d9d51e072ce6646ad.Width = new Bridge.global.Windows.UI.Xaml.GridLength.$ctor2(1.0, Bridge.global.Windows.UI.Xaml.GridUnitType.Auto);

                    var ColumnDefinition_4ed7cf95bea0472e872fa1e72877b217 = new Bridge.global.Windows.UI.Xaml.Controls.ColumnDefinition();
                    ColumnDefinition_4ed7cf95bea0472e872fa1e72877b217.Width = new Bridge.global.Windows.UI.Xaml.GridLength.$ctor2(1.0, Bridge.global.Windows.UI.Xaml.GridUnitType.Auto);

                    var ColumnDefinition_c873a038733c4f0bbe6f13b4cdf06d5f = new Bridge.global.Windows.UI.Xaml.Controls.ColumnDefinition();
                    ColumnDefinition_c873a038733c4f0bbe6f13b4cdf06d5f.Width = new Bridge.global.Windows.UI.Xaml.GridLength.$ctor2(1.0, Bridge.global.Windows.UI.Xaml.GridUnitType.Auto);

                    var ColumnDefinition_66f5af740d6444d288a97fa43c12c02d = new Bridge.global.Windows.UI.Xaml.Controls.ColumnDefinition();
                    ColumnDefinition_66f5af740d6444d288a97fa43c12c02d.Width = new Bridge.global.Windows.UI.Xaml.GridLength.$ctor2(1.0, Bridge.global.Windows.UI.Xaml.GridUnitType.Auto);

                    Grid_6c0a6ad7e1d5487ab6eab37754f57b0a.ColumnDefinitions.add(ColumnDefinition_17fd734d0a4f42cd8506d4a319ba7817);
                    Grid_6c0a6ad7e1d5487ab6eab37754f57b0a.ColumnDefinitions.add(ColumnDefinition_e79d66609d03487e96b49eadac0dd504);
                    Grid_6c0a6ad7e1d5487ab6eab37754f57b0a.ColumnDefinitions.add(ColumnDefinition_7cf704b66df2423f8fb4a6c9cf080880);
                    Grid_6c0a6ad7e1d5487ab6eab37754f57b0a.ColumnDefinitions.add(ColumnDefinition_7194b0d01768410d9d51e072ce6646ad);
                    Grid_6c0a6ad7e1d5487ab6eab37754f57b0a.ColumnDefinitions.add(ColumnDefinition_4ed7cf95bea0472e872fa1e72877b217);
                    Grid_6c0a6ad7e1d5487ab6eab37754f57b0a.ColumnDefinitions.add(ColumnDefinition_c873a038733c4f0bbe6f13b4cdf06d5f);
                    Grid_6c0a6ad7e1d5487ab6eab37754f57b0a.ColumnDefinitions.add(ColumnDefinition_66f5af740d6444d288a97fa43c12c02d);

                    templateOwner_ControlTemplate_e605c0cf1fea434987750ca63377929d.RegisterName("IconButton", Button_abdae32fbc8f4a76a2044a34790b0daa);
                    Button_abdae32fbc8f4a76a2044a34790b0daa.Name = "IconButton";
                    Button_abdae32fbc8f4a76a2044a34790b0daa.HorizontalAlignment = Bridge.global.Windows.UI.Xaml.HorizontalAlignment.Left;
                    Button_abdae32fbc8f4a76a2044a34790b0daa.VerticalAlignment = Bridge.global.Windows.UI.Xaml.VerticalAlignment.Center;
                    Button_abdae32fbc8f4a76a2044a34790b0daa.HorizontalContentAlignment = Bridge.global.Windows.UI.Xaml.HorizontalAlignment.Center;
                    Button_abdae32fbc8f4a76a2044a34790b0daa.VerticalContentAlignment = Bridge.global.Windows.UI.Xaml.VerticalAlignment.Center;
                    Button_abdae32fbc8f4a76a2044a34790b0daa.Width = 20.0;
                    Button_abdae32fbc8f4a76a2044a34790b0daa.Padding = new Bridge.global.Windows.UI.Xaml.Thickness.$ctor1(0);
                    var Image_0ef4c5e3b2c546908cc24b8addb5a48a = new Bridge.global.Windows.UI.Xaml.Controls.Image();
                    var Binding_0f12b335f08d4dee9da5961a981faa41 = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_0f12b335f08d4dee9da5961a981faa41.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("Icon");



                    Button_abdae32fbc8f4a76a2044a34790b0daa.Content = Image_0ef4c5e3b2c546908cc24b8addb5a48a;

                    var Binding_99a40f1dd61745d1af06fd47dc426965 = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_99a40f1dd61745d1af06fd47dc426965.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("IconVisibility");



                    templateOwner_ControlTemplate_e605c0cf1fea434987750ca63377929d.RegisterName("Title", ContentControl_8b8dd66a01294664ba5eebc43f22408f);
                    ContentControl_8b8dd66a01294664ba5eebc43f22408f.Name = "Title";
                    Bridge.global.Windows.UI.Xaml.Controls.Grid.SetColumn(ContentControl_8b8dd66a01294664ba5eebc43f22408f, 1);
                    ContentControl_8b8dd66a01294664ba5eebc43f22408f.HorizontalAlignment = Bridge.global.Windows.UI.Xaml.HorizontalAlignment.Left;
                    ContentControl_8b8dd66a01294664ba5eebc43f22408f.VerticalAlignment = Bridge.global.Windows.UI.Xaml.VerticalAlignment.Center;
                    ContentControl_8b8dd66a01294664ba5eebc43f22408f.Margin = new Bridge.global.Windows.UI.Xaml.Thickness.$ctor2(6, 0, 6, 0);
                    var Binding_c0905e644ba64272aca808fc1ae43f12 = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_c0905e644ba64272aca808fc1ae43f12.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("Title");
                    var RelativeSource_403d1de5cd044004ba76ed10e5a9336b = new Bridge.global.Windows.UI.Xaml.Data.RelativeSource.ctor();
                    RelativeSource_403d1de5cd044004ba76ed10e5a9336b.Mode = Bridge.global.Windows.UI.Xaml.Data.RelativeSourceMode.TemplatedParent;

                    Binding_c0905e644ba64272aca808fc1ae43f12.RelativeSource = RelativeSource_403d1de5cd044004ba76ed10e5a9336b;


                    Binding_c0905e644ba64272aca808fc1ae43f12.TemplateOwner = templateInstance_6c6a561153964fb6ac52735fff3f503c;


                    templateOwner_ControlTemplate_e605c0cf1fea434987750ca63377929d.RegisterName("HelpButton", Button_59f24a121abe4d2ba85d2f39440177a9);
                    Button_59f24a121abe4d2ba85d2f39440177a9.Name = "HelpButton";
                    Button_59f24a121abe4d2ba85d2f39440177a9.HorizontalAlignment = Bridge.global.Windows.UI.Xaml.HorizontalAlignment.Right;
                    Button_59f24a121abe4d2ba85d2f39440177a9.VerticalAlignment = Bridge.global.Windows.UI.Xaml.VerticalAlignment.Center;
                    Bridge.global.Windows.UI.Xaml.Controls.Grid.SetColumn(Button_59f24a121abe4d2ba85d2f39440177a9, 2);
                    Button_59f24a121abe4d2ba85d2f39440177a9.HorizontalContentAlignment = Bridge.global.Windows.UI.Xaml.HorizontalAlignment.Center;
                    Button_59f24a121abe4d2ba85d2f39440177a9.VerticalContentAlignment = Bridge.global.Windows.UI.Xaml.VerticalAlignment.Center;
                    Button_59f24a121abe4d2ba85d2f39440177a9.Width = 20.0;
                    Button_59f24a121abe4d2ba85d2f39440177a9.Padding = new Bridge.global.Windows.UI.Xaml.Thickness.$ctor1(0);
                    var Image_82736b8141a94d06956b654463601ac4 = new Bridge.global.Windows.UI.Xaml.Controls.Image();
                    var Binding_d9b94e64ed574f9294bcf185abb6c626 = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_d9b94e64ed574f9294bcf185abb6c626.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("HelpIcon");



                    Button_59f24a121abe4d2ba85d2f39440177a9.Content = Image_82736b8141a94d06956b654463601ac4;

                    var Binding_495b07feabea4048804564ad6a84f42f = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_495b07feabea4048804564ad6a84f42f.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("HelpVisibility");



                    templateOwner_ControlTemplate_e605c0cf1fea434987750ca63377929d.RegisterName("MinButton", Button_c9e7d73cd24b45df83e8191f85827a5c);
                    Button_c9e7d73cd24b45df83e8191f85827a5c.Name = "MinButton";
                    Button_c9e7d73cd24b45df83e8191f85827a5c.HorizontalAlignment = Bridge.global.Windows.UI.Xaml.HorizontalAlignment.Right;
                    Button_c9e7d73cd24b45df83e8191f85827a5c.VerticalAlignment = Bridge.global.Windows.UI.Xaml.VerticalAlignment.Center;
                    Bridge.global.Windows.UI.Xaml.Controls.Grid.SetColumn(Button_c9e7d73cd24b45df83e8191f85827a5c, 3);
                    Button_c9e7d73cd24b45df83e8191f85827a5c.HorizontalContentAlignment = Bridge.global.Windows.UI.Xaml.HorizontalAlignment.Center;
                    Button_c9e7d73cd24b45df83e8191f85827a5c.VerticalContentAlignment = Bridge.global.Windows.UI.Xaml.VerticalAlignment.Center;
                    Button_c9e7d73cd24b45df83e8191f85827a5c.Width = 20.0;
                    Button_c9e7d73cd24b45df83e8191f85827a5c.Padding = new Bridge.global.Windows.UI.Xaml.Thickness.$ctor1(0);
                    Button_c9e7d73cd24b45df83e8191f85827a5c.addClick(Bridge.fn.cacheBind(this, this.RunClickMin));
                    var Image_6f50a157a71e499cbf46a2feb93c28b4 = new Bridge.global.Windows.UI.Xaml.Controls.Image();
                    var Binding_d50b4f59dea84e66864c9480fe855de8 = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_d50b4f59dea84e66864c9480fe855de8.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("MinResIcon");



                    Button_c9e7d73cd24b45df83e8191f85827a5c.Content = Image_6f50a157a71e499cbf46a2feb93c28b4;

                    var Binding_d4f5225c474c4a40a9f143761aa84e4b = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_d4f5225c474c4a40a9f143761aa84e4b.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("MinVisibility");



                    templateOwner_ControlTemplate_e605c0cf1fea434987750ca63377929d.RegisterName("MaxButton", Button_88741b5e30e14f5dbbf1a08194c66f21);
                    Button_88741b5e30e14f5dbbf1a08194c66f21.Name = "MaxButton";
                    Button_88741b5e30e14f5dbbf1a08194c66f21.HorizontalAlignment = Bridge.global.Windows.UI.Xaml.HorizontalAlignment.Right;
                    Button_88741b5e30e14f5dbbf1a08194c66f21.VerticalAlignment = Bridge.global.Windows.UI.Xaml.VerticalAlignment.Center;
                    Bridge.global.Windows.UI.Xaml.Controls.Grid.SetColumn(Button_88741b5e30e14f5dbbf1a08194c66f21, 4);
                    Button_88741b5e30e14f5dbbf1a08194c66f21.HorizontalContentAlignment = Bridge.global.Windows.UI.Xaml.HorizontalAlignment.Center;
                    Button_88741b5e30e14f5dbbf1a08194c66f21.VerticalContentAlignment = Bridge.global.Windows.UI.Xaml.VerticalAlignment.Center;
                    Button_88741b5e30e14f5dbbf1a08194c66f21.Width = 20.0;
                    Button_88741b5e30e14f5dbbf1a08194c66f21.Padding = new Bridge.global.Windows.UI.Xaml.Thickness.$ctor1(0);
                    Button_88741b5e30e14f5dbbf1a08194c66f21.addClick(Bridge.fn.cacheBind(this, this.RunClickMax));
                    var Image_35efb340ab43422287b6a526b6950d15 = new Bridge.global.Windows.UI.Xaml.Controls.Image();
                    var Binding_661830963293424d90f037f4719237ea = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_661830963293424d90f037f4719237ea.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("MaxResIcon");



                    Button_88741b5e30e14f5dbbf1a08194c66f21.Content = Image_35efb340ab43422287b6a526b6950d15;

                    var Binding_92f3f10479e94072ac9cb85fa51d4fed = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_92f3f10479e94072ac9cb85fa51d4fed.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("MaxVisibility");



                    templateOwner_ControlTemplate_e605c0cf1fea434987750ca63377929d.RegisterName("FullScreenButton", Button_abf446ec47ae404b86a98ae3da450843);
                    Button_abf446ec47ae404b86a98ae3da450843.Name = "FullScreenButton";
                    Button_abf446ec47ae404b86a98ae3da450843.HorizontalAlignment = Bridge.global.Windows.UI.Xaml.HorizontalAlignment.Right;
                    Button_abf446ec47ae404b86a98ae3da450843.VerticalAlignment = Bridge.global.Windows.UI.Xaml.VerticalAlignment.Center;
                    Bridge.global.Windows.UI.Xaml.Controls.Grid.SetColumn(Button_abf446ec47ae404b86a98ae3da450843, 5);
                    Button_abf446ec47ae404b86a98ae3da450843.HorizontalContentAlignment = Bridge.global.Windows.UI.Xaml.HorizontalAlignment.Center;
                    Button_abf446ec47ae404b86a98ae3da450843.VerticalContentAlignment = Bridge.global.Windows.UI.Xaml.VerticalAlignment.Center;
                    Button_abf446ec47ae404b86a98ae3da450843.Width = 20.0;
                    Button_abf446ec47ae404b86a98ae3da450843.Padding = new Bridge.global.Windows.UI.Xaml.Thickness.$ctor1(0);
                    Button_abf446ec47ae404b86a98ae3da450843.addClick(Bridge.fn.cacheBind(this, this.RunClickFullScreen));
                    var Image_972d47d929d84191800aaa01f1d54e13 = new Bridge.global.Windows.UI.Xaml.Controls.Image();
                    var Binding_9430918a16a84768a255709e3c5d2053 = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_9430918a16a84768a255709e3c5d2053.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("FullScreenIcon");



                    Button_abf446ec47ae404b86a98ae3da450843.Content = Image_972d47d929d84191800aaa01f1d54e13;

                    var Binding_d428a63e666b4de885da8240c3140601 = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_d428a63e666b4de885da8240c3140601.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("FullScreenVisibility");



                    templateOwner_ControlTemplate_e605c0cf1fea434987750ca63377929d.RegisterName("CloseButton", Button_7a1cb3fe1fa14fcbbfb747333417ab25);
                    Button_7a1cb3fe1fa14fcbbfb747333417ab25.Name = "CloseButton";
                    Button_7a1cb3fe1fa14fcbbfb747333417ab25.HorizontalAlignment = Bridge.global.Windows.UI.Xaml.HorizontalAlignment.Right;
                    Button_7a1cb3fe1fa14fcbbfb747333417ab25.VerticalAlignment = Bridge.global.Windows.UI.Xaml.VerticalAlignment.Center;
                    Bridge.global.Windows.UI.Xaml.Controls.Grid.SetColumn(Button_7a1cb3fe1fa14fcbbfb747333417ab25, 6);
                    Button_7a1cb3fe1fa14fcbbfb747333417ab25.HorizontalContentAlignment = Bridge.global.Windows.UI.Xaml.HorizontalAlignment.Center;
                    Button_7a1cb3fe1fa14fcbbfb747333417ab25.VerticalContentAlignment = Bridge.global.Windows.UI.Xaml.VerticalAlignment.Center;
                    Button_7a1cb3fe1fa14fcbbfb747333417ab25.Width = 20.0;
                    Button_7a1cb3fe1fa14fcbbfb747333417ab25.Padding = new Bridge.global.Windows.UI.Xaml.Thickness.$ctor1(0);
                    Button_7a1cb3fe1fa14fcbbfb747333417ab25.addClick(Bridge.fn.cacheBind(this, this.RunClickClose));
                    var Image_747e6674c3ed4cd98bba807b84862336 = new Bridge.global.Windows.UI.Xaml.Controls.Image();
                    var Binding_31cef72cf0d04c42a77ebf95e8ba0d08 = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_31cef72cf0d04c42a77ebf95e8ba0d08.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("CloseIcon");



                    Button_7a1cb3fe1fa14fcbbfb747333417ab25.Content = Image_747e6674c3ed4cd98bba807b84862336;

                    var Binding_1495d852706d4aa699ff8c8e01bd2832 = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_1495d852706d4aa699ff8c8e01bd2832.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("CloseVisibility");



                    Grid_6c0a6ad7e1d5487ab6eab37754f57b0a.Children.add(Button_abdae32fbc8f4a76a2044a34790b0daa);
                    Grid_6c0a6ad7e1d5487ab6eab37754f57b0a.Children.add(ContentControl_8b8dd66a01294664ba5eebc43f22408f);
                    Grid_6c0a6ad7e1d5487ab6eab37754f57b0a.Children.add(Button_59f24a121abe4d2ba85d2f39440177a9);
                    Grid_6c0a6ad7e1d5487ab6eab37754f57b0a.Children.add(Button_c9e7d73cd24b45df83e8191f85827a5c);
                    Grid_6c0a6ad7e1d5487ab6eab37754f57b0a.Children.add(Button_88741b5e30e14f5dbbf1a08194c66f21);
                    Grid_6c0a6ad7e1d5487ab6eab37754f57b0a.Children.add(Button_abf446ec47ae404b86a98ae3da450843);
                    Grid_6c0a6ad7e1d5487ab6eab37754f57b0a.Children.add(Button_7a1cb3fe1fa14fcbbfb747333417ab25);


                    Border_3c305b883aa54d1798930e026fdf6ca3.Child = Grid_6c0a6ad7e1d5487ab6eab37754f57b0a;

                    var Binding_8550a68ec0574d999168a8a642fa9c96 = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_8550a68ec0574d999168a8a642fa9c96.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("TitleVisibility");



                    var Border_1c4c3e0e417745b8bbd523a7a5a15529 = new Bridge.global.Windows.UI.Xaml.Controls.Border();
                    Bridge.global.Windows.UI.Xaml.Controls.Grid.SetRow(Border_1c4c3e0e417745b8bbd523a7a5a15529, 1);
                    Border_1c4c3e0e417745b8bbd523a7a5a15529.BorderThickness = new Bridge.global.Windows.UI.Xaml.Thickness.$ctor2(0, 0, 0, 0);
                    templateOwner_ControlTemplate_e605c0cf1fea434987750ca63377929d.RegisterName("FormContentPresenter", ContentPresenter_8843295653e94ccd81d61e398ec70514);
                    ContentPresenter_8843295653e94ccd81d61e398ec70514.Name = "FormContentPresenter";
                    ContentPresenter_8843295653e94ccd81d61e398ec70514.ClipToBounds = true;
                    var Binding_2a7f02242b1345e7a3c433cf678c8fbb = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_2a7f02242b1345e7a3c433cf678c8fbb.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("Content");
                    var RelativeSource_6a63380c09c94133bf2653cd58931574 = new Bridge.global.Windows.UI.Xaml.Data.RelativeSource.ctor();
                    RelativeSource_6a63380c09c94133bf2653cd58931574.Mode = Bridge.global.Windows.UI.Xaml.Data.RelativeSourceMode.TemplatedParent;

                    Binding_2a7f02242b1345e7a3c433cf678c8fbb.RelativeSource = RelativeSource_6a63380c09c94133bf2653cd58931574;


                    Binding_2a7f02242b1345e7a3c433cf678c8fbb.TemplateOwner = templateInstance_6c6a561153964fb6ac52735fff3f503c;

                    var Binding_b7ac03de708543eaaf606784f0e38a02 = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_b7ac03de708543eaaf606784f0e38a02.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("ContentTemplate");
                    var RelativeSource_977345c2893d4bbb8d1d172bee24ca76 = new Bridge.global.Windows.UI.Xaml.Data.RelativeSource.ctor();
                    RelativeSource_977345c2893d4bbb8d1d172bee24ca76.Mode = Bridge.global.Windows.UI.Xaml.Data.RelativeSourceMode.TemplatedParent;

                    Binding_b7ac03de708543eaaf606784f0e38a02.RelativeSource = RelativeSource_977345c2893d4bbb8d1d172bee24ca76;


                    Binding_b7ac03de708543eaaf606784f0e38a02.TemplateOwner = templateInstance_6c6a561153964fb6ac52735fff3f503c;

                    var Binding_e3c6fc24c3a24da28485584f58645495 = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_e3c6fc24c3a24da28485584f58645495.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("ClientWidth");


                    var Binding_c52b94abb28546088567bf1007ec63f2 = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_c52b94abb28546088567bf1007ec63f2.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("ClientHeight");


                    var Binding_6138a7674f9840ef9834fe720489f0e4 = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_6138a7674f9840ef9834fe720489f0e4.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("HorizontalAlignment");
                    var RelativeSource_948c1957be354b419676b02536a7a81b = new Bridge.global.Windows.UI.Xaml.Data.RelativeSource.ctor();
                    RelativeSource_948c1957be354b419676b02536a7a81b.Mode = Bridge.global.Windows.UI.Xaml.Data.RelativeSourceMode.TemplatedParent;

                    Binding_6138a7674f9840ef9834fe720489f0e4.RelativeSource = RelativeSource_948c1957be354b419676b02536a7a81b;


                    Binding_6138a7674f9840ef9834fe720489f0e4.TemplateOwner = templateInstance_6c6a561153964fb6ac52735fff3f503c;

                    var Binding_9819e9ab2fb0405a9b98aa1350f684e0 = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_9819e9ab2fb0405a9b98aa1350f684e0.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("VerticalAlignment");
                    var RelativeSource_687437cae6294fc2a456ce7b063e674b = new Bridge.global.Windows.UI.Xaml.Data.RelativeSource.ctor();
                    RelativeSource_687437cae6294fc2a456ce7b063e674b.Mode = Bridge.global.Windows.UI.Xaml.Data.RelativeSourceMode.TemplatedParent;

                    Binding_9819e9ab2fb0405a9b98aa1350f684e0.RelativeSource = RelativeSource_687437cae6294fc2a456ce7b063e674b;


                    Binding_9819e9ab2fb0405a9b98aa1350f684e0.TemplateOwner = templateInstance_6c6a561153964fb6ac52735fff3f503c;


                    Border_1c4c3e0e417745b8bbd523a7a5a15529.Child = ContentPresenter_8843295653e94ccd81d61e398ec70514;

                    var Binding_813364c565224377b59416de5edc12e8 = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_813364c565224377b59416de5edc12e8.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("ClientHeight");


                    var Binding_997fb743f00b4456bfaf6fc3f8ef0a07 = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_997fb743f00b4456bfaf6fc3f8ef0a07.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("ClientWidth");


                    var Binding_870d6e40dd3b4aad81e0c766ebbbce4d = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_870d6e40dd3b4aad81e0c766ebbbce4d.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("Background");
                    var RelativeSource_78a8ca2d2df442b78602e5418d72025e = new Bridge.global.Windows.UI.Xaml.Data.RelativeSource.ctor();
                    RelativeSource_78a8ca2d2df442b78602e5418d72025e.Mode = Bridge.global.Windows.UI.Xaml.Data.RelativeSourceMode.TemplatedParent;

                    Binding_870d6e40dd3b4aad81e0c766ebbbce4d.RelativeSource = RelativeSource_78a8ca2d2df442b78602e5418d72025e;


                    Binding_870d6e40dd3b4aad81e0c766ebbbce4d.TemplateOwner = templateInstance_6c6a561153964fb6ac52735fff3f503c;

                    var Binding_62508792ab1c48258ccdf743cff5f84f = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_62508792ab1c48258ccdf743cff5f84f.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("Background");
                    var RelativeSource_509dc011877643acbf5f905ce49f5c8d = new Bridge.global.Windows.UI.Xaml.Data.RelativeSource.ctor();
                    RelativeSource_509dc011877643acbf5f905ce49f5c8d.Mode = Bridge.global.Windows.UI.Xaml.Data.RelativeSourceMode.TemplatedParent;

                    Binding_62508792ab1c48258ccdf743cff5f84f.RelativeSource = RelativeSource_509dc011877643acbf5f905ce49f5c8d;


                    Binding_62508792ab1c48258ccdf743cff5f84f.TemplateOwner = templateInstance_6c6a561153964fb6ac52735fff3f503c;


                    Grid_42628d274d834483b6119420b1909faf.Children.add(Border_3c305b883aa54d1798930e026fdf6ca3);
                    Grid_42628d274d834483b6119420b1909faf.Children.add(Border_1c4c3e0e417745b8bbd523a7a5a15529);


                    Border_a8e50cb52e5a4d0e85b977a2171a5678.Child = Grid_42628d274d834483b6119420b1909faf;

                    var Binding_3665de4824184fe795e527e514eb1783 = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_3665de4824184fe795e527e514eb1783.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("BorderThickness");
                    var RelativeSource_2c5c1f3b7dc44586b1e6bfb9968ec877 = new Bridge.global.Windows.UI.Xaml.Data.RelativeSource.ctor();
                    RelativeSource_2c5c1f3b7dc44586b1e6bfb9968ec877.Mode = Bridge.global.Windows.UI.Xaml.Data.RelativeSourceMode.TemplatedParent;

                    Binding_3665de4824184fe795e527e514eb1783.RelativeSource = RelativeSource_2c5c1f3b7dc44586b1e6bfb9968ec877;


                    Binding_3665de4824184fe795e527e514eb1783.TemplateOwner = templateInstance_6c6a561153964fb6ac52735fff3f503c;

                    var Binding_ecda92d2843f40b68e60ab4daed19b53 = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_ecda92d2843f40b68e60ab4daed19b53.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("BorderBrush");
                    var RelativeSource_dc5e3766182f496aae5da48357352a9c = new Bridge.global.Windows.UI.Xaml.Data.RelativeSource.ctor();
                    RelativeSource_dc5e3766182f496aae5da48357352a9c.Mode = Bridge.global.Windows.UI.Xaml.Data.RelativeSourceMode.TemplatedParent;

                    Binding_ecda92d2843f40b68e60ab4daed19b53.RelativeSource = RelativeSource_dc5e3766182f496aae5da48357352a9c;


                    Binding_ecda92d2843f40b68e60ab4daed19b53.TemplateOwner = templateInstance_6c6a561153964fb6ac52735fff3f503c;


                    Border_bb78b02e0592479bb1ce4efe59a3fa52.Child = Border_a8e50cb52e5a4d0e85b977a2171a5678;


                    Grid_59b9da72ba604066a4d824c50526f58a.Children.add(Grid_74407138227c4266a7548bf17b206baf);
                    Grid_59b9da72ba604066a4d824c50526f58a.Children.add(Border_bb78b02e0592479bb1ce4efe59a3fa52);

                    var Binding_73e7ac729e2943aeabe705e1c5e5ba5f = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_73e7ac729e2943aeabe705e1c5e5ba5f.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("Height");
                    var RelativeSource_a30b966d241d43e79c80f4725dfce9a4 = new Bridge.global.Windows.UI.Xaml.Data.RelativeSource.ctor();
                    RelativeSource_a30b966d241d43e79c80f4725dfce9a4.Mode = Bridge.global.Windows.UI.Xaml.Data.RelativeSourceMode.TemplatedParent;

                    Binding_73e7ac729e2943aeabe705e1c5e5ba5f.RelativeSource = RelativeSource_a30b966d241d43e79c80f4725dfce9a4;


                    Binding_73e7ac729e2943aeabe705e1c5e5ba5f.TemplateOwner = templateInstance_6c6a561153964fb6ac52735fff3f503c;

                    var Binding_912793ac4a4a4b5c83c051b11ddca7ce = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_912793ac4a4a4b5c83c051b11ddca7ce.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("Width");
                    var RelativeSource_e9822b82be6e4651811b80b55531a5b4 = new Bridge.global.Windows.UI.Xaml.Data.RelativeSource.ctor();
                    RelativeSource_e9822b82be6e4651811b80b55531a5b4.Mode = Bridge.global.Windows.UI.Xaml.Data.RelativeSourceMode.TemplatedParent;

                    Binding_912793ac4a4a4b5c83c051b11ddca7ce.RelativeSource = RelativeSource_e9822b82be6e4651811b80b55531a5b4;


                    Binding_912793ac4a4a4b5c83c051b11ddca7ce.TemplateOwner = templateInstance_6c6a561153964fb6ac52735fff3f503c;

                    var Binding_2ce8388fdcca4a3bb9c4b3ee134b3c10 = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_2ce8388fdcca4a3bb9c4b3ee134b3c10.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("HorizontalAlignment");
                    var RelativeSource_19cd17a11b6c4034a67e5eeff253f31f = new Bridge.global.Windows.UI.Xaml.Data.RelativeSource.ctor();
                    RelativeSource_19cd17a11b6c4034a67e5eeff253f31f.Mode = Bridge.global.Windows.UI.Xaml.Data.RelativeSourceMode.TemplatedParent;

                    Binding_2ce8388fdcca4a3bb9c4b3ee134b3c10.RelativeSource = RelativeSource_19cd17a11b6c4034a67e5eeff253f31f;


                    Binding_2ce8388fdcca4a3bb9c4b3ee134b3c10.TemplateOwner = templateInstance_6c6a561153964fb6ac52735fff3f503c;

                    var Binding_3ac1fd1a075a4996982661696301f1b9 = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_3ac1fd1a075a4996982661696301f1b9.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("VerticalAlignment");
                    var RelativeSource_2125bb54bb024b55b242170485ef43e3 = new Bridge.global.Windows.UI.Xaml.Data.RelativeSource.ctor();
                    RelativeSource_2125bb54bb024b55b242170485ef43e3.Mode = Bridge.global.Windows.UI.Xaml.Data.RelativeSourceMode.TemplatedParent;

                    Binding_3ac1fd1a075a4996982661696301f1b9.RelativeSource = RelativeSource_2125bb54bb024b55b242170485ef43e3;


                    Binding_3ac1fd1a075a4996982661696301f1b9.TemplateOwner = templateInstance_6c6a561153964fb6ac52735fff3f503c;


                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(Grid_74407138227c4266a7548bf17b206baf, Bridge.global.Windows.UI.Xaml.Controls.Panel.BackgroundProperty, Binding_da97ae5142704435a133133417216a78);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(Grid_74407138227c4266a7548bf17b206baf, Bridge.global.Windows.UI.Xaml.UIElement.OpacityProperty, Binding_6201c3c144a94f79b60cc70d797dfc4a);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(Image_0ef4c5e3b2c546908cc24b8addb5a48a, Bridge.global.Windows.UI.Xaml.Controls.Image.SourceProperty, Binding_0f12b335f08d4dee9da5961a981faa41);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(Button_abdae32fbc8f4a76a2044a34790b0daa, Bridge.global.Windows.UI.Xaml.UIElement.VisibilityProperty, Binding_99a40f1dd61745d1af06fd47dc426965);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(ContentControl_8b8dd66a01294664ba5eebc43f22408f, Bridge.global.Windows.UI.Xaml.Controls.ContentControl.ContentProperty, Binding_c0905e644ba64272aca808fc1ae43f12);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(Image_82736b8141a94d06956b654463601ac4, Bridge.global.Windows.UI.Xaml.Controls.Image.SourceProperty, Binding_d9b94e64ed574f9294bcf185abb6c626);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(Button_59f24a121abe4d2ba85d2f39440177a9, Bridge.global.Windows.UI.Xaml.UIElement.VisibilityProperty, Binding_495b07feabea4048804564ad6a84f42f);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(Image_6f50a157a71e499cbf46a2feb93c28b4, Bridge.global.Windows.UI.Xaml.Controls.Image.SourceProperty, Binding_d50b4f59dea84e66864c9480fe855de8);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(Button_c9e7d73cd24b45df83e8191f85827a5c, Bridge.global.Windows.UI.Xaml.UIElement.VisibilityProperty, Binding_d4f5225c474c4a40a9f143761aa84e4b);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(Image_35efb340ab43422287b6a526b6950d15, Bridge.global.Windows.UI.Xaml.Controls.Image.SourceProperty, Binding_661830963293424d90f037f4719237ea);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(Button_88741b5e30e14f5dbbf1a08194c66f21, Bridge.global.Windows.UI.Xaml.UIElement.VisibilityProperty, Binding_92f3f10479e94072ac9cb85fa51d4fed);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(Image_972d47d929d84191800aaa01f1d54e13, Bridge.global.Windows.UI.Xaml.Controls.Image.SourceProperty, Binding_9430918a16a84768a255709e3c5d2053);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(Button_abf446ec47ae404b86a98ae3da450843, Bridge.global.Windows.UI.Xaml.UIElement.VisibilityProperty, Binding_d428a63e666b4de885da8240c3140601);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(Image_747e6674c3ed4cd98bba807b84862336, Bridge.global.Windows.UI.Xaml.Controls.Image.SourceProperty, Binding_31cef72cf0d04c42a77ebf95e8ba0d08);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(Button_7a1cb3fe1fa14fcbbfb747333417ab25, Bridge.global.Windows.UI.Xaml.UIElement.VisibilityProperty, Binding_1495d852706d4aa699ff8c8e01bd2832);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(Border_3c305b883aa54d1798930e026fdf6ca3, Bridge.global.Windows.UI.Xaml.UIElement.VisibilityProperty, Binding_8550a68ec0574d999168a8a642fa9c96);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(ContentPresenter_8843295653e94ccd81d61e398ec70514, Bridge.global.Windows.UI.Xaml.Controls.ContentControl.ContentProperty, Binding_2a7f02242b1345e7a3c433cf678c8fbb);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(ContentPresenter_8843295653e94ccd81d61e398ec70514, Bridge.global.Windows.UI.Xaml.Controls.ContentControl.ContentTemplateProperty, Binding_b7ac03de708543eaaf606784f0e38a02);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(ContentPresenter_8843295653e94ccd81d61e398ec70514, Bridge.global.Windows.UI.Xaml.FrameworkElement.WidthProperty, Binding_e3c6fc24c3a24da28485584f58645495);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(ContentPresenter_8843295653e94ccd81d61e398ec70514, Bridge.global.Windows.UI.Xaml.FrameworkElement.HeightProperty, Binding_c52b94abb28546088567bf1007ec63f2);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(ContentPresenter_8843295653e94ccd81d61e398ec70514, Bridge.global.Windows.UI.Xaml.FrameworkElement.HorizontalAlignmentProperty, Binding_6138a7674f9840ef9834fe720489f0e4);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(ContentPresenter_8843295653e94ccd81d61e398ec70514, Bridge.global.Windows.UI.Xaml.FrameworkElement.VerticalAlignmentProperty, Binding_9819e9ab2fb0405a9b98aa1350f684e0);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(Border_1c4c3e0e417745b8bbd523a7a5a15529, Bridge.global.Windows.UI.Xaml.FrameworkElement.HeightProperty, Binding_813364c565224377b59416de5edc12e8);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(Border_1c4c3e0e417745b8bbd523a7a5a15529, Bridge.global.Windows.UI.Xaml.FrameworkElement.WidthProperty, Binding_997fb743f00b4456bfaf6fc3f8ef0a07);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(Border_1c4c3e0e417745b8bbd523a7a5a15529, Bridge.global.Windows.UI.Xaml.Controls.Border.BackgroundProperty, Binding_870d6e40dd3b4aad81e0c766ebbbce4d);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(Border_1c4c3e0e417745b8bbd523a7a5a15529, Bridge.global.Windows.UI.Xaml.Controls.Border.BorderBrushProperty, Binding_62508792ab1c48258ccdf743cff5f84f);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(Border_a8e50cb52e5a4d0e85b977a2171a5678, Bridge.global.Windows.UI.Xaml.Controls.Border.BorderThicknessProperty, Binding_3665de4824184fe795e527e514eb1783);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(Border_a8e50cb52e5a4d0e85b977a2171a5678, Bridge.global.Windows.UI.Xaml.Controls.Border.BorderBrushProperty, Binding_ecda92d2843f40b68e60ab4daed19b53);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(Grid_59b9da72ba604066a4d824c50526f58a, Bridge.global.Windows.UI.Xaml.FrameworkElement.HeightProperty, Binding_73e7ac729e2943aeabe705e1c5e5ba5f);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(Grid_59b9da72ba604066a4d824c50526f58a, Bridge.global.Windows.UI.Xaml.FrameworkElement.WidthProperty, Binding_912793ac4a4a4b5c83c051b11ddca7ce);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(Grid_59b9da72ba604066a4d824c50526f58a, Bridge.global.Windows.UI.Xaml.FrameworkElement.HorizontalAlignmentProperty, Binding_2ce8388fdcca4a3bb9c4b3ee134b3c10);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(Grid_59b9da72ba604066a4d824c50526f58a, Bridge.global.Windows.UI.Xaml.FrameworkElement.VerticalAlignmentProperty, Binding_3ac1fd1a075a4996982661696301f1b9);

                    Bridge.global.Windows.UI.Xaml.Media.Animation.Storyboard.SetTargetProperty(ObjectAnimationUsingKeyFrames_6dec4dc1050747769c8b5c4c0221ab03, new Bridge.global.Windows.UI.Xaml.PropertyPath.$ctor2("Background", "Background", Bridge.fn.cacheBind(this, this.accessVisualStateProperty_1d2501e02dea4392b77bcc442ea47053), Bridge.fn.cacheBind(this, this.setVisualStateProperty_1d2501e02dea4392b77bcc442ea47053), Bridge.fn.cacheBind(this, this.setAnimationVisualStateProperty_1d2501e02dea4392b77bcc442ea47053), Bridge.fn.cacheBind(this, this.setLocalVisualStateProperty_1d2501e02dea4392b77bcc442ea47053), Bridge.fn.cacheBind(this, this.getVisualStateProperty_1d2501e02dea4392b77bcc442ea47053)));
                    Bridge.global.Windows.UI.Xaml.Media.Animation.Storyboard.SetTarget(ObjectAnimationUsingKeyFrames_6dec4dc1050747769c8b5c4c0221ab03, Grid_74407138227c4266a7548bf17b206baf);


                    Bridge.global.Windows.UI.Xaml.Media.Animation.Storyboard.SetTargetProperty(ObjectAnimationUsingKeyFrames_a4fbc0904bac4743bf342da089563dc5, new Bridge.global.Windows.UI.Xaml.PropertyPath.$ctor2("IsHitTestVisible", "IsHitTestVisible", Bridge.fn.cacheBind(this, this.accessVisualStateProperty_dded4a1b00aa41e09ba3f870e5675e46), Bridge.fn.cacheBind(this, this.setVisualStateProperty_dded4a1b00aa41e09ba3f870e5675e46), Bridge.fn.cacheBind(this, this.setAnimationVisualStateProperty_dded4a1b00aa41e09ba3f870e5675e46), Bridge.fn.cacheBind(this, this.setLocalVisualStateProperty_dded4a1b00aa41e09ba3f870e5675e46), Bridge.fn.cacheBind(this, this.getVisualStateProperty_dded4a1b00aa41e09ba3f870e5675e46)));
                    Bridge.global.Windows.UI.Xaml.Media.Animation.Storyboard.SetTarget(ObjectAnimationUsingKeyFrames_a4fbc0904bac4743bf342da089563dc5, Grid_74407138227c4266a7548bf17b206baf);

                    templateInstance_6c6a561153964fb6ac52735fff3f503c.TemplateContent = Grid_59b9da72ba604066a4d824c50526f58a;
                    return templateInstance_6c6a561153964fb6ac52735fff3f503c;
                }));

                Setter_2c682a5649a848838cb7962fa3ae4aaa.Value = ControlTemplate_e605c0cf1fea434987750ca63377929d;


                Style_20132bae93364701b5f3fee185480248.Setters.add(Setter_017fadc47e5a4468bffeb7f46bdf2242);
                Style_20132bae93364701b5f3fee185480248.Setters.add(Setter_9df1a7de54fa4b669f623db578dcf791);
                Style_20132bae93364701b5f3fee185480248.Setters.add(Setter_655906b58a0e44bfa7b41edf4589f8e4);
                Style_20132bae93364701b5f3fee185480248.Setters.add(Setter_1b47d0bf526a45ab87325408e91a8e3b);
                Style_20132bae93364701b5f3fee185480248.Setters.add(Setter_2c682a5649a848838cb7962fa3ae4aaa);


                var Style_bc9ec12311d94f2da3238c2d75bf7a67 = new Bridge.global.Windows.UI.Xaml.Style.ctor();
                Style_bc9ec12311d94f2da3238c2d75bf7a67.TargetType = Bridge.global.Windows.UI.Xaml.Controls.Button;
                var Setter_8150bd3f113e423d8d6a489e42e8751d = new Bridge.global.Windows.UI.Xaml.Setter.ctor();
                Setter_8150bd3f113e423d8d6a489e42e8751d.Property = Bridge.global.Windows.UI.Xaml.Controls.Control.BackgroundProperty;
                Setter_8150bd3f113e423d8d6a489e42e8751d.Value = new Bridge.global.Windows.UI.Xaml.Media.SolidColorBrush.$ctor1(($t = new Bridge.global.Windows.UI.Color(), $t.A = 255, $t.R = 226, $t.G = 226, $t.B = 226, $t));

                var Setter_42cfec844a5340f8ba6c2d01f4e7e6c2 = new Bridge.global.Windows.UI.Xaml.Setter.ctor();
                Setter_42cfec844a5340f8ba6c2d01f4e7e6c2.Property = Bridge.global.Windows.UI.Xaml.Controls.Control.ForegroundProperty;
                Setter_42cfec844a5340f8ba6c2d01f4e7e6c2.Value = new Bridge.global.Windows.UI.Xaml.Media.SolidColorBrush.$ctor1(($t = new Bridge.global.Windows.UI.Color(), $t.A = 255, $t.R = 0, $t.G = 0, $t.B = 0, $t));

                var Setter_c08238b0cc864885a39a31798c9c9cec = new Bridge.global.Windows.UI.Xaml.Setter.ctor();
                Setter_c08238b0cc864885a39a31798c9c9cec.Property = Bridge.global.Windows.UI.Xaml.Controls.Control.BorderThicknessProperty;
                Setter_c08238b0cc864885a39a31798c9c9cec.Value = new Bridge.global.Windows.UI.Xaml.Thickness.$ctor1(0).$clone();

                var Setter_a5ac289694364b49a20bdab95539cd02 = new Bridge.global.Windows.UI.Xaml.Setter.ctor();
                Setter_a5ac289694364b49a20bdab95539cd02.Property = Bridge.global.Windows.UI.Xaml.Controls.Control.PaddingProperty;
                Setter_a5ac289694364b49a20bdab95539cd02.Value = new Bridge.global.Windows.UI.Xaml.Thickness.$ctor2(12, 4, 12, 4).$clone();

                var Setter_bd6e48d8a0f243158abb1bea8ad2ac91 = new Bridge.global.Windows.UI.Xaml.Setter.ctor();
                Setter_bd6e48d8a0f243158abb1bea8ad2ac91.Property = Bridge.global.Windows.UI.Xaml.FrameworkElement.CursorProperty;
                Setter_bd6e48d8a0f243158abb1bea8ad2ac91.Value = Bridge.global.System.Windows.Input.Cursors.Hand;

                var Setter_9da46ddb27d54c2d9fa4c39b3db0cde5 = new Bridge.global.Windows.UI.Xaml.Setter.ctor();
                Setter_9da46ddb27d54c2d9fa4c39b3db0cde5.Property = Bridge.global.Windows.UI.Xaml.Controls.Control.HorizontalContentAlignmentProperty;
                Setter_9da46ddb27d54c2d9fa4c39b3db0cde5.Value = Bridge.box(Bridge.global.Windows.UI.Xaml.HorizontalAlignment.Center, Windows.UI.Xaml.HorizontalAlignment, System.Enum.toStringFn(Windows.UI.Xaml.HorizontalAlignment));

                var Setter_fe3f2f3b8a39453db3ec7887e400cd4d = new Bridge.global.Windows.UI.Xaml.Setter.ctor();
                Setter_fe3f2f3b8a39453db3ec7887e400cd4d.Property = Bridge.global.Windows.UI.Xaml.Controls.Control.VerticalContentAlignmentProperty;
                Setter_fe3f2f3b8a39453db3ec7887e400cd4d.Value = Bridge.box(Bridge.global.Windows.UI.Xaml.VerticalAlignment.Center, Windows.UI.Xaml.VerticalAlignment, System.Enum.toStringFn(Windows.UI.Xaml.VerticalAlignment));

                var Setter_6d8a5e36f94c4a178a46bd69ae03a62b = new Bridge.global.Windows.UI.Xaml.Setter.ctor();
                Setter_6d8a5e36f94c4a178a46bd69ae03a62b.Property = Bridge.global.Windows.UI.Xaml.Controls.Control.TemplateProperty;
                var ControlTemplate_d950ff2be90347748c95368f0a79a4cf = new Bridge.global.Windows.UI.Xaml.Controls.ControlTemplate();
                ControlTemplate_d950ff2be90347748c95368f0a79a4cf.TargetType = Bridge.global.Windows.UI.Xaml.Controls.Button;
                ControlTemplate_d950ff2be90347748c95368f0a79a4cf.SetMethodToInstantiateFrameworkTemplate(Bridge.fn.bind(this, function (templateOwner_ControlTemplate_d950ff2be90347748c95368f0a79a4cf) {
                    var templateInstance_db06538cdd11474bbb533a72e182a781 = new Bridge.global.Windows.UI.Xaml.TemplateInstance();
                    templateInstance_db06538cdd11474bbb533a72e182a781.TemplateOwner = templateOwner_ControlTemplate_d950ff2be90347748c95368f0a79a4cf;
                    var VisualState_5781490fe9a844119ef992bf79d166ea = new Bridge.global.Windows.UI.Xaml.VisualState();
                    var VisualState_b06efbaf5bd24f3893274e9f533bb66c = new Bridge.global.Windows.UI.Xaml.VisualState();
                    var VisualState_3a9b6fd5895d406c99b9162cad4dcaa8 = new Bridge.global.Windows.UI.Xaml.VisualState();
                    var VisualState_eccd675bbdba478692d39fc91bc8018f = new Bridge.global.Windows.UI.Xaml.VisualState();
                    var VisualStateGroup_fb0df3ced9f5456f8a1a0d0b9078772a = new Bridge.global.Windows.UI.Xaml.VisualStateGroup();
                    var ContentPresenter_8c2636fa35224bb99cafbac1497642ac = new Bridge.global.Windows.UI.Xaml.Controls.ContentPresenter();
                    var Border_5dc88283617849a8afb24e1186b6efd4 = new Bridge.global.Windows.UI.Xaml.Controls.Border();
                    var Border_20aa345ebd10467f8a01d5205b673c74 = new Bridge.global.Windows.UI.Xaml.Controls.Border();
                    templateOwner_ControlTemplate_d950ff2be90347748c95368f0a79a4cf.RegisterName("OuterBorder", Border_20aa345ebd10467f8a01d5205b673c74);
                    Border_20aa345ebd10467f8a01d5205b673c74.Name = "OuterBorder";
                    templateOwner_ControlTemplate_d950ff2be90347748c95368f0a79a4cf.RegisterName("CommonStates", VisualStateGroup_fb0df3ced9f5456f8a1a0d0b9078772a);
                    VisualStateGroup_fb0df3ced9f5456f8a1a0d0b9078772a.Name = "CommonStates";
                    templateOwner_ControlTemplate_d950ff2be90347748c95368f0a79a4cf.RegisterName("Normal", VisualState_5781490fe9a844119ef992bf79d166ea);
                    VisualState_5781490fe9a844119ef992bf79d166ea.Name = "Normal";

                    templateOwner_ControlTemplate_d950ff2be90347748c95368f0a79a4cf.RegisterName("PointerOver", VisualState_b06efbaf5bd24f3893274e9f533bb66c);
                    VisualState_b06efbaf5bd24f3893274e9f533bb66c.Name = "PointerOver";
                    var Storyboard_887aeb3c0ea64ff3ae5f52ba59533c6d = new Bridge.global.Windows.UI.Xaml.Media.Animation.Storyboard();
                    var ObjectAnimationUsingKeyFrames_c6b06c9e4aeb44048ad00b01c796ed3e = new Bridge.global.Windows.UI.Xaml.Media.Animation.ObjectAnimationUsingKeyFrames();
                    Bridge.global.Windows.UI.Xaml.Media.Animation.Storyboard.SetTargetName(ObjectAnimationUsingKeyFrames_c6b06c9e4aeb44048ad00b01c796ed3e, "InnerBorder");
                    var DiscreteObjectKeyFrame_86a6d7d4589749aeb9865f94dccf443f = new Bridge.global.Windows.UI.Xaml.Media.Animation.DiscreteObjectKeyFrame();
                    DiscreteObjectKeyFrame_86a6d7d4589749aeb9865f94dccf443f.KeyTime = Bridge.global.Windows.UI.Xaml.Media.Animation.KeyTime.FromTimeSpan(new Bridge.global.System.TimeSpan(System.Int64(0)));
                    DiscreteObjectKeyFrame_86a6d7d4589749aeb9865f94dccf443f.Value = "#11000000";

                    ObjectAnimationUsingKeyFrames_c6b06c9e4aeb44048ad00b01c796ed3e.KeyFrames.add(DiscreteObjectKeyFrame_86a6d7d4589749aeb9865f94dccf443f);


                    Storyboard_887aeb3c0ea64ff3ae5f52ba59533c6d.Children.add(ObjectAnimationUsingKeyFrames_c6b06c9e4aeb44048ad00b01c796ed3e);


                    VisualState_b06efbaf5bd24f3893274e9f533bb66c.Storyboard = Storyboard_887aeb3c0ea64ff3ae5f52ba59533c6d;


                    templateOwner_ControlTemplate_d950ff2be90347748c95368f0a79a4cf.RegisterName("Pressed", VisualState_3a9b6fd5895d406c99b9162cad4dcaa8);
                    VisualState_3a9b6fd5895d406c99b9162cad4dcaa8.Name = "Pressed";
                    var Storyboard_f7586cafc5bc4ba981735896db84cf41 = new Bridge.global.Windows.UI.Xaml.Media.Animation.Storyboard();
                    var ObjectAnimationUsingKeyFrames_8fbd6518b29b4c16bd1d24a65f4f495d = new Bridge.global.Windows.UI.Xaml.Media.Animation.ObjectAnimationUsingKeyFrames();
                    Bridge.global.Windows.UI.Xaml.Media.Animation.Storyboard.SetTargetName(ObjectAnimationUsingKeyFrames_8fbd6518b29b4c16bd1d24a65f4f495d, "InnerBorder");
                    var DiscreteObjectKeyFrame_1c858fe59e134058bb19de6d98cb39cb = new Bridge.global.Windows.UI.Xaml.Media.Animation.DiscreteObjectKeyFrame();
                    DiscreteObjectKeyFrame_1c858fe59e134058bb19de6d98cb39cb.KeyTime = Bridge.global.Windows.UI.Xaml.Media.Animation.KeyTime.FromTimeSpan(new Bridge.global.System.TimeSpan(System.Int64(0)));
                    DiscreteObjectKeyFrame_1c858fe59e134058bb19de6d98cb39cb.Value = "#22000000";

                    ObjectAnimationUsingKeyFrames_8fbd6518b29b4c16bd1d24a65f4f495d.KeyFrames.add(DiscreteObjectKeyFrame_1c858fe59e134058bb19de6d98cb39cb);


                    Storyboard_f7586cafc5bc4ba981735896db84cf41.Children.add(ObjectAnimationUsingKeyFrames_8fbd6518b29b4c16bd1d24a65f4f495d);


                    VisualState_3a9b6fd5895d406c99b9162cad4dcaa8.Storyboard = Storyboard_f7586cafc5bc4ba981735896db84cf41;


                    templateOwner_ControlTemplate_d950ff2be90347748c95368f0a79a4cf.RegisterName("Disabled", VisualState_eccd675bbdba478692d39fc91bc8018f);
                    VisualState_eccd675bbdba478692d39fc91bc8018f.Name = "Disabled";
                    var Storyboard_de2d251b2d454fa286ac36fad9afc98c = new Bridge.global.Windows.UI.Xaml.Media.Animation.Storyboard();
                    var ObjectAnimationUsingKeyFrames_7daecda5a1e542c48741583ed408f208 = new Bridge.global.Windows.UI.Xaml.Media.Animation.ObjectAnimationUsingKeyFrames();
                    Bridge.global.Windows.UI.Xaml.Media.Animation.Storyboard.SetTargetName(ObjectAnimationUsingKeyFrames_7daecda5a1e542c48741583ed408f208, "InnerBorder");
                    var DiscreteObjectKeyFrame_bc023c7eb70d4d95a283bb71a3f5b631 = new Bridge.global.Windows.UI.Xaml.Media.Animation.DiscreteObjectKeyFrame();
                    DiscreteObjectKeyFrame_bc023c7eb70d4d95a283bb71a3f5b631.KeyTime = Bridge.global.Windows.UI.Xaml.Media.Animation.KeyTime.FromTimeSpan(new Bridge.global.System.TimeSpan(System.Int64(0)));
                    DiscreteObjectKeyFrame_bc023c7eb70d4d95a283bb71a3f5b631.Value = "#33FFFFFF";

                    ObjectAnimationUsingKeyFrames_7daecda5a1e542c48741583ed408f208.KeyFrames.add(DiscreteObjectKeyFrame_bc023c7eb70d4d95a283bb71a3f5b631);


                    Storyboard_de2d251b2d454fa286ac36fad9afc98c.Children.add(ObjectAnimationUsingKeyFrames_7daecda5a1e542c48741583ed408f208);


                    VisualState_eccd675bbdba478692d39fc91bc8018f.Storyboard = Storyboard_de2d251b2d454fa286ac36fad9afc98c;


                    System.Array.add(VisualStateGroup_fb0df3ced9f5456f8a1a0d0b9078772a.States, VisualState_5781490fe9a844119ef992bf79d166ea, Object);
                    System.Array.add(VisualStateGroup_fb0df3ced9f5456f8a1a0d0b9078772a.States, VisualState_b06efbaf5bd24f3893274e9f533bb66c, Object);
                    System.Array.add(VisualStateGroup_fb0df3ced9f5456f8a1a0d0b9078772a.States, VisualState_3a9b6fd5895d406c99b9162cad4dcaa8, Object);
                    System.Array.add(VisualStateGroup_fb0df3ced9f5456f8a1a0d0b9078772a.States, VisualState_eccd675bbdba478692d39fc91bc8018f, Object);


                    templateOwner_ControlTemplate_d950ff2be90347748c95368f0a79a4cf.INTERNAL_GetVisualStateGroups().add(VisualStateGroup_fb0df3ced9f5456f8a1a0d0b9078772a);

                    templateOwner_ControlTemplate_d950ff2be90347748c95368f0a79a4cf.RegisterName("InnerBorder", Border_5dc88283617849a8afb24e1186b6efd4);
                    Border_5dc88283617849a8afb24e1186b6efd4.Name = "InnerBorder";
                    templateOwner_ControlTemplate_d950ff2be90347748c95368f0a79a4cf.RegisterName("ContentPresenter", ContentPresenter_8c2636fa35224bb99cafbac1497642ac);
                    ContentPresenter_8c2636fa35224bb99cafbac1497642ac.Name = "ContentPresenter";
                    var Binding_a1db454a9d79473997fa65577bc86775 = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_a1db454a9d79473997fa65577bc86775.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("ContentTemplate");
                    var RelativeSource_2be0f589904249e18f2d950f0cf77f50 = new Bridge.global.Windows.UI.Xaml.Data.RelativeSource.ctor();
                    RelativeSource_2be0f589904249e18f2d950f0cf77f50.Mode = Bridge.global.Windows.UI.Xaml.Data.RelativeSourceMode.TemplatedParent;

                    Binding_a1db454a9d79473997fa65577bc86775.RelativeSource = RelativeSource_2be0f589904249e18f2d950f0cf77f50;


                    Binding_a1db454a9d79473997fa65577bc86775.TemplateOwner = templateInstance_db06538cdd11474bbb533a72e182a781;

                    var Binding_3fc7ead02ac842d7b5ed05675cf76a3c = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_3fc7ead02ac842d7b5ed05675cf76a3c.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("Content");
                    var RelativeSource_ea0fb376980149bf98370ee60e6530b7 = new Bridge.global.Windows.UI.Xaml.Data.RelativeSource.ctor();
                    RelativeSource_ea0fb376980149bf98370ee60e6530b7.Mode = Bridge.global.Windows.UI.Xaml.Data.RelativeSourceMode.TemplatedParent;

                    Binding_3fc7ead02ac842d7b5ed05675cf76a3c.RelativeSource = RelativeSource_ea0fb376980149bf98370ee60e6530b7;


                    Binding_3fc7ead02ac842d7b5ed05675cf76a3c.TemplateOwner = templateInstance_db06538cdd11474bbb533a72e182a781;

                    var Binding_f46444326f174f3ba63843862a9079b3 = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_f46444326f174f3ba63843862a9079b3.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("Height");
                    var RelativeSource_64d19fdb3ffe4c14b66427eda108971c = new Bridge.global.Windows.UI.Xaml.Data.RelativeSource.ctor();
                    RelativeSource_64d19fdb3ffe4c14b66427eda108971c.Mode = Bridge.global.Windows.UI.Xaml.Data.RelativeSourceMode.TemplatedParent;

                    Binding_f46444326f174f3ba63843862a9079b3.RelativeSource = RelativeSource_64d19fdb3ffe4c14b66427eda108971c;


                    Binding_f46444326f174f3ba63843862a9079b3.TemplateOwner = templateInstance_db06538cdd11474bbb533a72e182a781;

                    var Binding_e0e8804a182442e593be9f6b00059aa3 = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_e0e8804a182442e593be9f6b00059aa3.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("Width");
                    var RelativeSource_5064de041ef947d18ee576f409b88110 = new Bridge.global.Windows.UI.Xaml.Data.RelativeSource.ctor();
                    RelativeSource_5064de041ef947d18ee576f409b88110.Mode = Bridge.global.Windows.UI.Xaml.Data.RelativeSourceMode.TemplatedParent;

                    Binding_e0e8804a182442e593be9f6b00059aa3.RelativeSource = RelativeSource_5064de041ef947d18ee576f409b88110;


                    Binding_e0e8804a182442e593be9f6b00059aa3.TemplateOwner = templateInstance_db06538cdd11474bbb533a72e182a781;

                    var Binding_af3426e3c1f947baa2d4de1fb83ffa1d = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_af3426e3c1f947baa2d4de1fb83ffa1d.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("Padding");
                    var RelativeSource_ac13a0a5f7d14dc39accb633677143bf = new Bridge.global.Windows.UI.Xaml.Data.RelativeSource.ctor();
                    RelativeSource_ac13a0a5f7d14dc39accb633677143bf.Mode = Bridge.global.Windows.UI.Xaml.Data.RelativeSourceMode.TemplatedParent;

                    Binding_af3426e3c1f947baa2d4de1fb83ffa1d.RelativeSource = RelativeSource_ac13a0a5f7d14dc39accb633677143bf;


                    Binding_af3426e3c1f947baa2d4de1fb83ffa1d.TemplateOwner = templateInstance_db06538cdd11474bbb533a72e182a781;

                    var Binding_32df9af6001e42a986bd1ca77c6f96f6 = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_32df9af6001e42a986bd1ca77c6f96f6.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("HorizontalContentAlignment");
                    var RelativeSource_1b0fc6a6f0ae48d79391badfef542810 = new Bridge.global.Windows.UI.Xaml.Data.RelativeSource.ctor();
                    RelativeSource_1b0fc6a6f0ae48d79391badfef542810.Mode = Bridge.global.Windows.UI.Xaml.Data.RelativeSourceMode.TemplatedParent;

                    Binding_32df9af6001e42a986bd1ca77c6f96f6.RelativeSource = RelativeSource_1b0fc6a6f0ae48d79391badfef542810;


                    Binding_32df9af6001e42a986bd1ca77c6f96f6.TemplateOwner = templateInstance_db06538cdd11474bbb533a72e182a781;

                    var Binding_6e9486e303c140769ef2dc1b3dadc2d3 = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_6e9486e303c140769ef2dc1b3dadc2d3.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("VerticalContentAlignment");
                    var RelativeSource_cfcb2c651d8f4719ac6b6ec0179c54bb = new Bridge.global.Windows.UI.Xaml.Data.RelativeSource.ctor();
                    RelativeSource_cfcb2c651d8f4719ac6b6ec0179c54bb.Mode = Bridge.global.Windows.UI.Xaml.Data.RelativeSourceMode.TemplatedParent;

                    Binding_6e9486e303c140769ef2dc1b3dadc2d3.RelativeSource = RelativeSource_cfcb2c651d8f4719ac6b6ec0179c54bb;


                    Binding_6e9486e303c140769ef2dc1b3dadc2d3.TemplateOwner = templateInstance_db06538cdd11474bbb533a72e182a781;

                    var Binding_891ee3631f244eb09ccf5b73f6d22a60 = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_891ee3631f244eb09ccf5b73f6d22a60.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("Visibility");



                    Border_5dc88283617849a8afb24e1186b6efd4.Child = ContentPresenter_8c2636fa35224bb99cafbac1497642ac;

                    var Binding_b264f31456da4453b25d4ed929ba9cda = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_b264f31456da4453b25d4ed929ba9cda.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("Background");
                    var RelativeSource_3e2b8f253c0146b990b25ea5b528701a = new Bridge.global.Windows.UI.Xaml.Data.RelativeSource.ctor();
                    RelativeSource_3e2b8f253c0146b990b25ea5b528701a.Mode = Bridge.global.Windows.UI.Xaml.Data.RelativeSourceMode.TemplatedParent;

                    Binding_b264f31456da4453b25d4ed929ba9cda.RelativeSource = RelativeSource_3e2b8f253c0146b990b25ea5b528701a;


                    Binding_b264f31456da4453b25d4ed929ba9cda.TemplateOwner = templateInstance_db06538cdd11474bbb533a72e182a781;


                    Border_20aa345ebd10467f8a01d5205b673c74.Child = Border_5dc88283617849a8afb24e1186b6efd4;

                    var Binding_6d4b3283ca4c45bea2eed3374e587b6b = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_6d4b3283ca4c45bea2eed3374e587b6b.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("Background");
                    var RelativeSource_e44458769c4d46749df16daad22e891e = new Bridge.global.Windows.UI.Xaml.Data.RelativeSource.ctor();
                    RelativeSource_e44458769c4d46749df16daad22e891e.Mode = Bridge.global.Windows.UI.Xaml.Data.RelativeSourceMode.TemplatedParent;

                    Binding_6d4b3283ca4c45bea2eed3374e587b6b.RelativeSource = RelativeSource_e44458769c4d46749df16daad22e891e;


                    Binding_6d4b3283ca4c45bea2eed3374e587b6b.TemplateOwner = templateInstance_db06538cdd11474bbb533a72e182a781;

                    var Binding_44eb020bf5ef43e590e75a1fdd112e56 = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_44eb020bf5ef43e590e75a1fdd112e56.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("BorderBrush");
                    var RelativeSource_00d7a5b3a6d6459db7be700503ee86bf = new Bridge.global.Windows.UI.Xaml.Data.RelativeSource.ctor();
                    RelativeSource_00d7a5b3a6d6459db7be700503ee86bf.Mode = Bridge.global.Windows.UI.Xaml.Data.RelativeSourceMode.TemplatedParent;

                    Binding_44eb020bf5ef43e590e75a1fdd112e56.RelativeSource = RelativeSource_00d7a5b3a6d6459db7be700503ee86bf;


                    Binding_44eb020bf5ef43e590e75a1fdd112e56.TemplateOwner = templateInstance_db06538cdd11474bbb533a72e182a781;

                    var Binding_0f9bc836e0804d01893a9af7a38f8995 = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_0f9bc836e0804d01893a9af7a38f8995.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("BorderThickness");
                    var RelativeSource_117e9e012b0945ad81cccfc14f9bf533 = new Bridge.global.Windows.UI.Xaml.Data.RelativeSource.ctor();
                    RelativeSource_117e9e012b0945ad81cccfc14f9bf533.Mode = Bridge.global.Windows.UI.Xaml.Data.RelativeSourceMode.TemplatedParent;

                    Binding_0f9bc836e0804d01893a9af7a38f8995.RelativeSource = RelativeSource_117e9e012b0945ad81cccfc14f9bf533;


                    Binding_0f9bc836e0804d01893a9af7a38f8995.TemplateOwner = templateInstance_db06538cdd11474bbb533a72e182a781;

                    var Binding_2a5f765959b84e418edef281c9035ccf = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_2a5f765959b84e418edef281c9035ccf.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("Margin");
                    var RelativeSource_f23a1aa26ffc4ca78e2188fd62481240 = new Bridge.global.Windows.UI.Xaml.Data.RelativeSource.ctor();
                    RelativeSource_f23a1aa26ffc4ca78e2188fd62481240.Mode = Bridge.global.Windows.UI.Xaml.Data.RelativeSourceMode.TemplatedParent;

                    Binding_2a5f765959b84e418edef281c9035ccf.RelativeSource = RelativeSource_f23a1aa26ffc4ca78e2188fd62481240;


                    Binding_2a5f765959b84e418edef281c9035ccf.TemplateOwner = templateInstance_db06538cdd11474bbb533a72e182a781;

                    var Binding_71879619080a4505955ffaaa5fc59484 = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_71879619080a4505955ffaaa5fc59484.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("Visibility");



                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(ContentPresenter_8c2636fa35224bb99cafbac1497642ac, Bridge.global.Windows.UI.Xaml.Controls.ContentControl.ContentTemplateProperty, Binding_a1db454a9d79473997fa65577bc86775);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(ContentPresenter_8c2636fa35224bb99cafbac1497642ac, Bridge.global.Windows.UI.Xaml.Controls.ContentControl.ContentProperty, Binding_3fc7ead02ac842d7b5ed05675cf76a3c);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(ContentPresenter_8c2636fa35224bb99cafbac1497642ac, Bridge.global.Windows.UI.Xaml.FrameworkElement.HeightProperty, Binding_f46444326f174f3ba63843862a9079b3);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(ContentPresenter_8c2636fa35224bb99cafbac1497642ac, Bridge.global.Windows.UI.Xaml.FrameworkElement.WidthProperty, Binding_e0e8804a182442e593be9f6b00059aa3);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(ContentPresenter_8c2636fa35224bb99cafbac1497642ac, Bridge.global.Windows.UI.Xaml.FrameworkElement.MarginProperty, Binding_af3426e3c1f947baa2d4de1fb83ffa1d);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(ContentPresenter_8c2636fa35224bb99cafbac1497642ac, Bridge.global.Windows.UI.Xaml.FrameworkElement.HorizontalAlignmentProperty, Binding_32df9af6001e42a986bd1ca77c6f96f6);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(ContentPresenter_8c2636fa35224bb99cafbac1497642ac, Bridge.global.Windows.UI.Xaml.FrameworkElement.VerticalAlignmentProperty, Binding_6e9486e303c140769ef2dc1b3dadc2d3);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(ContentPresenter_8c2636fa35224bb99cafbac1497642ac, Bridge.global.Windows.UI.Xaml.UIElement.VisibilityProperty, Binding_891ee3631f244eb09ccf5b73f6d22a60);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(Border_5dc88283617849a8afb24e1186b6efd4, Bridge.global.Windows.UI.Xaml.Controls.Border.BackgroundProperty, Binding_b264f31456da4453b25d4ed929ba9cda);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(Border_20aa345ebd10467f8a01d5205b673c74, Bridge.global.Windows.UI.Xaml.Controls.Border.BackgroundProperty, Binding_6d4b3283ca4c45bea2eed3374e587b6b);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(Border_20aa345ebd10467f8a01d5205b673c74, Bridge.global.Windows.UI.Xaml.Controls.Border.BorderBrushProperty, Binding_44eb020bf5ef43e590e75a1fdd112e56);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(Border_20aa345ebd10467f8a01d5205b673c74, Bridge.global.Windows.UI.Xaml.Controls.Border.BorderThicknessProperty, Binding_0f9bc836e0804d01893a9af7a38f8995);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(Border_20aa345ebd10467f8a01d5205b673c74, Bridge.global.Windows.UI.Xaml.FrameworkElement.MarginProperty, Binding_2a5f765959b84e418edef281c9035ccf);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(Border_20aa345ebd10467f8a01d5205b673c74, Bridge.global.Windows.UI.Xaml.UIElement.VisibilityProperty, Binding_71879619080a4505955ffaaa5fc59484);

                    Bridge.global.Windows.UI.Xaml.Media.Animation.Storyboard.SetTargetProperty(ObjectAnimationUsingKeyFrames_c6b06c9e4aeb44048ad00b01c796ed3e, new Bridge.global.Windows.UI.Xaml.PropertyPath.$ctor2("Background", "Background", Bridge.fn.cacheBind(this, this.accessVisualStateProperty_4b6078e43e14424aa15e7c2fdfa4d33e), Bridge.fn.cacheBind(this, this.setVisualStateProperty_4b6078e43e14424aa15e7c2fdfa4d33e), Bridge.fn.cacheBind(this, this.setAnimationVisualStateProperty_4b6078e43e14424aa15e7c2fdfa4d33e), Bridge.fn.cacheBind(this, this.setLocalVisualStateProperty_4b6078e43e14424aa15e7c2fdfa4d33e), Bridge.fn.cacheBind(this, this.getVisualStateProperty_4b6078e43e14424aa15e7c2fdfa4d33e)));
                    Bridge.global.Windows.UI.Xaml.Media.Animation.Storyboard.SetTarget(ObjectAnimationUsingKeyFrames_c6b06c9e4aeb44048ad00b01c796ed3e, Border_5dc88283617849a8afb24e1186b6efd4);


                    Bridge.global.Windows.UI.Xaml.Media.Animation.Storyboard.SetTargetProperty(ObjectAnimationUsingKeyFrames_8fbd6518b29b4c16bd1d24a65f4f495d, new Bridge.global.Windows.UI.Xaml.PropertyPath.$ctor2("Background", "Background", Bridge.fn.cacheBind(this, this.accessVisualStateProperty_54a0cb8873a3411f97f57cfeafa4a445), Bridge.fn.cacheBind(this, this.setVisualStateProperty_54a0cb8873a3411f97f57cfeafa4a445), Bridge.fn.cacheBind(this, this.setAnimationVisualStateProperty_54a0cb8873a3411f97f57cfeafa4a445), Bridge.fn.cacheBind(this, this.setLocalVisualStateProperty_54a0cb8873a3411f97f57cfeafa4a445), Bridge.fn.cacheBind(this, this.getVisualStateProperty_54a0cb8873a3411f97f57cfeafa4a445)));
                    Bridge.global.Windows.UI.Xaml.Media.Animation.Storyboard.SetTarget(ObjectAnimationUsingKeyFrames_8fbd6518b29b4c16bd1d24a65f4f495d, Border_5dc88283617849a8afb24e1186b6efd4);


                    Bridge.global.Windows.UI.Xaml.Media.Animation.Storyboard.SetTargetProperty(ObjectAnimationUsingKeyFrames_7daecda5a1e542c48741583ed408f208, new Bridge.global.Windows.UI.Xaml.PropertyPath.$ctor2("Background", "Background", Bridge.fn.cacheBind(this, this.accessVisualStateProperty_1b4562d2cc794734b887161119b5f390), Bridge.fn.cacheBind(this, this.setVisualStateProperty_1b4562d2cc794734b887161119b5f390), Bridge.fn.cacheBind(this, this.setAnimationVisualStateProperty_1b4562d2cc794734b887161119b5f390), Bridge.fn.cacheBind(this, this.setLocalVisualStateProperty_1b4562d2cc794734b887161119b5f390), Bridge.fn.cacheBind(this, this.getVisualStateProperty_1b4562d2cc794734b887161119b5f390)));
                    Bridge.global.Windows.UI.Xaml.Media.Animation.Storyboard.SetTarget(ObjectAnimationUsingKeyFrames_7daecda5a1e542c48741583ed408f208, Border_5dc88283617849a8afb24e1186b6efd4);

                    templateInstance_db06538cdd11474bbb533a72e182a781.TemplateContent = Border_20aa345ebd10467f8a01d5205b673c74;
                    return templateInstance_db06538cdd11474bbb533a72e182a781;
                }));

                Setter_6d8a5e36f94c4a178a46bd69ae03a62b.Value = ControlTemplate_d950ff2be90347748c95368f0a79a4cf;


                Style_bc9ec12311d94f2da3238c2d75bf7a67.Setters.add(Setter_8150bd3f113e423d8d6a489e42e8751d);
                Style_bc9ec12311d94f2da3238c2d75bf7a67.Setters.add(Setter_42cfec844a5340f8ba6c2d01f4e7e6c2);
                Style_bc9ec12311d94f2da3238c2d75bf7a67.Setters.add(Setter_c08238b0cc864885a39a31798c9c9cec);
                Style_bc9ec12311d94f2da3238c2d75bf7a67.Setters.add(Setter_a5ac289694364b49a20bdab95539cd02);
                Style_bc9ec12311d94f2da3238c2d75bf7a67.Setters.add(Setter_bd6e48d8a0f243158abb1bea8ad2ac91);
                Style_bc9ec12311d94f2da3238c2d75bf7a67.Setters.add(Setter_9da46ddb27d54c2d9fa4c39b3db0cde5);
                Style_bc9ec12311d94f2da3238c2d75bf7a67.Setters.add(Setter_fe3f2f3b8a39453db3ec7887e400cd4d);
                Style_bc9ec12311d94f2da3238c2d75bf7a67.Setters.add(Setter_6d8a5e36f94c4a178a46bd69ae03a62b);


                ResourceDictionary_60529c843b80490a9ff1ff97b3e74a7a.setItem("IntConverter", IntConverter_48f3773072e74dd69250293eeaeb52c4);
                ResourceDictionary_60529c843b80490a9ff1ff97b3e74a7a.setItem("DecConverter", DecConverter_45ea840ac8534a1f8587f54dd8ec4136);
                ResourceDictionary_60529c843b80490a9ff1ff97b3e74a7a.setItem("ToPolyLineConverter", ToPolyLineConverter_48eb4abc3ee94ca7a9771de392690e51);
                ResourceDictionary_60529c843b80490a9ff1ff97b3e74a7a.setItem("ToPointsConverter", ToPointsConverter_6db966474058452da8d970b40c953732);
                ResourceDictionary_60529c843b80490a9ff1ff97b3e74a7a.setItem("ToLinesConverter", ToLinesConverter_0269dd88156f47ffb6edbed85b6abef0);
                ResourceDictionary_60529c843b80490a9ff1ff97b3e74a7a.setItem("APLColorConverter", APLColorConverter_0bc1bf56d05847349777da3ff0bf423d);
                ResourceDictionary_60529c843b80490a9ff1ff97b3e74a7a.setItem("APLColorCSSConverter", APLColorCSSConverter_18fd023ef7c343bcb948aded43c0a250);
                ResourceDictionary_60529c843b80490a9ff1ff97b3e74a7a.setItem("APLMultiColorConverter", APLMultiColorConverter_e2118d6be5af4fda8eb2ddef9de2e6f6);
                ResourceDictionary_60529c843b80490a9ff1ff97b3e74a7a.setItem("APLMultiColorCSSConverter", APLMultiColorCSSConverter_6e190048f37248d5a87b14da11fdee4a);
                ResourceDictionary_60529c843b80490a9ff1ff97b3e74a7a.setItem("IndexInt32Converter", IndexInt32Converter_f1b816a0d925448fa86166c730aa2d18);
                ResourceDictionary_60529c843b80490a9ff1ff97b3e74a7a.setItem("IndexDoubleConverter", IndexDoubleConverter_2510a88d51d248b481854a6a152e273d);
                ResourceDictionary_60529c843b80490a9ff1ff97b3e74a7a.setItem("IndexStringConverter", IndexStringConverter_003c9f1518d14a16a6a7d7e58311216a);
                ResourceDictionary_60529c843b80490a9ff1ff97b3e74a7a.setItem("IndexAPLColorConverter", IndexAPLColorConverter_cba8c7b1c5fc4ec99f928b40fc1fda15);
                ResourceDictionary_60529c843b80490a9ff1ff97b3e74a7a.setItem("IndexAPLColourConverter", IndexAPLColourConverter_319a2cf3bced49dc9ce9456071443c1a);
                ResourceDictionary_60529c843b80490a9ff1ff97b3e74a7a.setItem("MathsIConverter", MathsIConverter_eaff56b6583c49909d170a4b82674190);
                ResourceDictionary_60529c843b80490a9ff1ff97b3e74a7a.setItem("MathsDConverter", MathsDConverter_4c4e649612744fcfbc4bf25711a0544e);
                ResourceDictionary_60529c843b80490a9ff1ff97b3e74a7a.setItem("MathIConverter", MathIConverter_cf36b9bdc6584cb6af978c6d35a1c5b5);
                ResourceDictionary_60529c843b80490a9ff1ff97b3e74a7a.setItem("MathDConverter", MathDConverter_f0dad1f43a9e45c3a86096ab49386c9c);
                ResourceDictionary_60529c843b80490a9ff1ff97b3e74a7a.setItem("Application", String_fc095f6795a747ce9c5f3da3df71b8e1);
                ResourceDictionary_60529c843b80490a9ff1ff97b3e74a7a.setItem("Owner", String_cb20f7e1cd414d0597a1b961334819df);
                ResourceDictionary_60529c843b80490a9ff1ff97b3e74a7a.setItem("Company", String_e560e164bc914bd99dda979cd7293ab5);
                ResourceDictionary_60529c843b80490a9ff1ff97b3e74a7a.setItem("Name", String_a5f84866a81a4108b17ae3464581ece7);
                ResourceDictionary_60529c843b80490a9ff1ff97b3e74a7a.setItem("Title", String_e69ae49aa56a47acb11ed4a18e32cb67);
                ResourceDictionary_60529c843b80490a9ff1ff97b3e74a7a.setItem("FavIcon", String_b7a3b20fe02d4cacb6bf206e3f47edf6);
                ResourceDictionary_60529c843b80490a9ff1ff97b3e74a7a.setItem("Port", String_0815727ca46d4f458815cdae81bffef8);
                ResourceDictionary_60529c843b80490a9ff1ff97b3e74a7a.setItem("Main", String_2744e66a4c83457c9dd2526ecd12603f);
                ResourceDictionary_60529c843b80490a9ff1ff97b3e74a7a.setItem("Base", String_469436105e9744a6ac5d120dc5877584);
                ResourceDictionary_60529c843b80490a9ff1ff97b3e74a7a.setItem("ConnectionType", String_1bca7b5271304e3e98ac60db962adc17);
                ResourceDictionary_60529c843b80490a9ff1ff97b3e74a7a.setItem("Namespace", String_3a3425b761d748299068e98954e38a0a);
                ResourceDictionary_60529c843b80490a9ff1ff97b3e74a7a.setItem("APLFormStyle", Style_20132bae93364701b5f3fee185480248);
                ResourceDictionary_60529c843b80490a9ff1ff97b3e74a7a.setItem("ButtonStyle1", Style_bc9ec12311d94f2da3238c2d75bf7a67);

                this.Resources = ResourceDictionary_60529c843b80490a9ff1ff97b3e74a7a;







            },
            accessVisualStateProperty_1d2501e02dea4392b77bcc442ea47053: function (rootTargetObjectInstance) {
                return new (Bridge.GeneratorEnumerable$1(System.Tuple$3(Windows.UI.Xaml.DependencyObject,Windows.UI.Xaml.DependencyProperty,System.Nullable$1(System.Int32))))(Bridge.fn.bind(this, function (rootTargetObjectInstance) {
                    var $step = 0,
                        $jumpFromFinally,
                        $returnValue,
                        $async_e;

                    var $enumerator = new (Bridge.GeneratorEnumerator$1(System.Tuple$3(Windows.UI.Xaml.DependencyObject,Windows.UI.Xaml.DependencyProperty,System.Nullable$1(System.Int32))))(Bridge.fn.bind(this, function () {
                        try {
                            for (;;) {
                                switch ($step) {
                                    case 0: {
                                        return false;
                                    }
                                    default: {
                                        return false;
                                    }
                                }
                            }
                        } catch($async_e1) {
                            $async_e = System.Exception.create($async_e1);
                            throw $async_e;
                        }
                    }));
                    return $enumerator;
                }, arguments));
            },
            setVisualStateProperty_1d2501e02dea4392b77bcc442ea47053: function (finalTargetInstance, value) {

                var finalTargetInstanceType = Bridge.getType(finalTargetInstance);
                var propertyDeclaringType = Bridge.Reflection.getMembers(finalTargetInstanceType, 16, 284, "Background").td;
                var propertyField = Bridge.Reflection.getMembers(propertyDeclaringType, 4, 284, "BackgroundProperty");
                var property = Bridge.cast(Bridge.Reflection.fieldAccess(propertyField, null), Windows.UI.Xaml.DependencyProperty);

                (finalTargetInstance).SetVisualStateValue(property, value);
            },
            setAnimationVisualStateProperty_1d2501e02dea4392b77bcc442ea47053: function (finalTargetInstance, value) {

                var finalTargetInstanceType = Bridge.getType(finalTargetInstance);
                var propertyDeclaringType = Bridge.Reflection.getMembers(finalTargetInstanceType, 16, 284, "Background").td;
                var propertyField = Bridge.Reflection.getMembers(propertyDeclaringType, 4, 284, "BackgroundProperty");
                var property = Bridge.cast(Bridge.Reflection.fieldAccess(propertyField, null), Windows.UI.Xaml.DependencyProperty);

                (finalTargetInstance).SetAnimationValue(property, value);
            },
            setLocalVisualStateProperty_1d2501e02dea4392b77bcc442ea47053: function (finalTargetInstance, value) {

                var finalTargetInstanceType = Bridge.getType(finalTargetInstance);
                var propertyDeclaringType = Bridge.Reflection.getMembers(finalTargetInstanceType, 16, 284, "Background").td;
                var propertyField = Bridge.Reflection.getMembers(propertyDeclaringType, 4, 284, "BackgroundProperty");
                var property = Bridge.cast(Bridge.Reflection.fieldAccess(propertyField, null), Windows.UI.Xaml.DependencyProperty);

                (finalTargetInstance).SetCurrentValue(property, value);
            },
            getVisualStateProperty_1d2501e02dea4392b77bcc442ea47053: function (finalTargetInstance) {

                var finalTargetInstanceType = Bridge.getType(finalTargetInstance);
                var propertyDeclaringType = Bridge.Reflection.getMembers(finalTargetInstanceType, 16, 284, "Background").td;
                var propertyField = Bridge.Reflection.getMembers(propertyDeclaringType, 4, 284, "BackgroundProperty");
                var property = Bridge.cast(Bridge.Reflection.fieldAccess(propertyField, null), Windows.UI.Xaml.DependencyProperty);

                return finalTargetInstance.GetVisualStateValue(property);
            },
            accessVisualStateProperty_dded4a1b00aa41e09ba3f870e5675e46: function (rootTargetObjectInstance) {
                return new (Bridge.GeneratorEnumerable$1(System.Tuple$3(Windows.UI.Xaml.DependencyObject,Windows.UI.Xaml.DependencyProperty,System.Nullable$1(System.Int32))))(Bridge.fn.bind(this, function (rootTargetObjectInstance) {
                    var $step = 0,
                        $jumpFromFinally,
                        $returnValue,
                        $async_e;

                    var $enumerator = new (Bridge.GeneratorEnumerator$1(System.Tuple$3(Windows.UI.Xaml.DependencyObject,Windows.UI.Xaml.DependencyProperty,System.Nullable$1(System.Int32))))(Bridge.fn.bind(this, function () {
                        try {
                            for (;;) {
                                switch ($step) {
                                    case 0: {
                                        return false;
                                    }
                                    default: {
                                        return false;
                                    }
                                }
                            }
                        } catch($async_e1) {
                            $async_e = System.Exception.create($async_e1);
                            throw $async_e;
                        }
                    }));
                    return $enumerator;
                }, arguments));
            },
            setVisualStateProperty_dded4a1b00aa41e09ba3f870e5675e46: function (finalTargetInstance, value) {

                var finalTargetInstanceType = Bridge.getType(finalTargetInstance);
                var propertyDeclaringType = Bridge.Reflection.getMembers(finalTargetInstanceType, 16, 284, "IsHitTestVisible").td;
                var propertyField = Bridge.Reflection.getMembers(propertyDeclaringType, 4, 284, "IsHitTestVisibleProperty");
                var property = Bridge.cast(Bridge.Reflection.fieldAccess(propertyField, null), Windows.UI.Xaml.DependencyProperty);

                (finalTargetInstance).SetVisualStateValue(property, value);
            },
            setAnimationVisualStateProperty_dded4a1b00aa41e09ba3f870e5675e46: function (finalTargetInstance, value) {

                var finalTargetInstanceType = Bridge.getType(finalTargetInstance);
                var propertyDeclaringType = Bridge.Reflection.getMembers(finalTargetInstanceType, 16, 284, "IsHitTestVisible").td;
                var propertyField = Bridge.Reflection.getMembers(propertyDeclaringType, 4, 284, "IsHitTestVisibleProperty");
                var property = Bridge.cast(Bridge.Reflection.fieldAccess(propertyField, null), Windows.UI.Xaml.DependencyProperty);

                (finalTargetInstance).SetAnimationValue(property, value);
            },
            setLocalVisualStateProperty_dded4a1b00aa41e09ba3f870e5675e46: function (finalTargetInstance, value) {

                var finalTargetInstanceType = Bridge.getType(finalTargetInstance);
                var propertyDeclaringType = Bridge.Reflection.getMembers(finalTargetInstanceType, 16, 284, "IsHitTestVisible").td;
                var propertyField = Bridge.Reflection.getMembers(propertyDeclaringType, 4, 284, "IsHitTestVisibleProperty");
                var property = Bridge.cast(Bridge.Reflection.fieldAccess(propertyField, null), Windows.UI.Xaml.DependencyProperty);

                (finalTargetInstance).SetCurrentValue(property, value);
            },
            getVisualStateProperty_dded4a1b00aa41e09ba3f870e5675e46: function (finalTargetInstance) {

                var finalTargetInstanceType = Bridge.getType(finalTargetInstance);
                var propertyDeclaringType = Bridge.Reflection.getMembers(finalTargetInstanceType, 16, 284, "IsHitTestVisible").td;
                var propertyField = Bridge.Reflection.getMembers(propertyDeclaringType, 4, 284, "IsHitTestVisibleProperty");
                var property = Bridge.cast(Bridge.Reflection.fieldAccess(propertyField, null), Windows.UI.Xaml.DependencyProperty);

                return finalTargetInstance.GetVisualStateValue(property);
            },
            accessVisualStateProperty_4b6078e43e14424aa15e7c2fdfa4d33e: function (rootTargetObjectInstance) {
                return new (Bridge.GeneratorEnumerable$1(System.Tuple$3(Windows.UI.Xaml.DependencyObject,Windows.UI.Xaml.DependencyProperty,System.Nullable$1(System.Int32))))(Bridge.fn.bind(this, function (rootTargetObjectInstance) {
                    var $step = 0,
                        $jumpFromFinally,
                        $returnValue,
                        $async_e;

                    var $enumerator = new (Bridge.GeneratorEnumerator$1(System.Tuple$3(Windows.UI.Xaml.DependencyObject,Windows.UI.Xaml.DependencyProperty,System.Nullable$1(System.Int32))))(Bridge.fn.bind(this, function () {
                        try {
                            for (;;) {
                                switch ($step) {
                                    case 0: {
                                        return false;
                                    }
                                    default: {
                                        return false;
                                    }
                                }
                            }
                        } catch($async_e1) {
                            $async_e = System.Exception.create($async_e1);
                            throw $async_e;
                        }
                    }));
                    return $enumerator;
                }, arguments));
            },
            setVisualStateProperty_4b6078e43e14424aa15e7c2fdfa4d33e: function (finalTargetInstance, value) {

                var finalTargetInstanceType = Bridge.getType(finalTargetInstance);
                var propertyDeclaringType = Bridge.Reflection.getMembers(finalTargetInstanceType, 16, 284, "Background").td;
                var propertyField = Bridge.Reflection.getMembers(propertyDeclaringType, 4, 284, "BackgroundProperty");
                var property = Bridge.cast(Bridge.Reflection.fieldAccess(propertyField, null), Windows.UI.Xaml.DependencyProperty);

                (finalTargetInstance).SetVisualStateValue(property, value);
            },
            setAnimationVisualStateProperty_4b6078e43e14424aa15e7c2fdfa4d33e: function (finalTargetInstance, value) {

                var finalTargetInstanceType = Bridge.getType(finalTargetInstance);
                var propertyDeclaringType = Bridge.Reflection.getMembers(finalTargetInstanceType, 16, 284, "Background").td;
                var propertyField = Bridge.Reflection.getMembers(propertyDeclaringType, 4, 284, "BackgroundProperty");
                var property = Bridge.cast(Bridge.Reflection.fieldAccess(propertyField, null), Windows.UI.Xaml.DependencyProperty);

                (finalTargetInstance).SetAnimationValue(property, value);
            },
            setLocalVisualStateProperty_4b6078e43e14424aa15e7c2fdfa4d33e: function (finalTargetInstance, value) {

                var finalTargetInstanceType = Bridge.getType(finalTargetInstance);
                var propertyDeclaringType = Bridge.Reflection.getMembers(finalTargetInstanceType, 16, 284, "Background").td;
                var propertyField = Bridge.Reflection.getMembers(propertyDeclaringType, 4, 284, "BackgroundProperty");
                var property = Bridge.cast(Bridge.Reflection.fieldAccess(propertyField, null), Windows.UI.Xaml.DependencyProperty);

                (finalTargetInstance).SetCurrentValue(property, value);
            },
            getVisualStateProperty_4b6078e43e14424aa15e7c2fdfa4d33e: function (finalTargetInstance) {

                var finalTargetInstanceType = Bridge.getType(finalTargetInstance);
                var propertyDeclaringType = Bridge.Reflection.getMembers(finalTargetInstanceType, 16, 284, "Background").td;
                var propertyField = Bridge.Reflection.getMembers(propertyDeclaringType, 4, 284, "BackgroundProperty");
                var property = Bridge.cast(Bridge.Reflection.fieldAccess(propertyField, null), Windows.UI.Xaml.DependencyProperty);

                return finalTargetInstance.GetVisualStateValue(property);
            },
            accessVisualStateProperty_54a0cb8873a3411f97f57cfeafa4a445: function (rootTargetObjectInstance) {
                return new (Bridge.GeneratorEnumerable$1(System.Tuple$3(Windows.UI.Xaml.DependencyObject,Windows.UI.Xaml.DependencyProperty,System.Nullable$1(System.Int32))))(Bridge.fn.bind(this, function (rootTargetObjectInstance) {
                    var $step = 0,
                        $jumpFromFinally,
                        $returnValue,
                        $async_e;

                    var $enumerator = new (Bridge.GeneratorEnumerator$1(System.Tuple$3(Windows.UI.Xaml.DependencyObject,Windows.UI.Xaml.DependencyProperty,System.Nullable$1(System.Int32))))(Bridge.fn.bind(this, function () {
                        try {
                            for (;;) {
                                switch ($step) {
                                    case 0: {
                                        return false;
                                    }
                                    default: {
                                        return false;
                                    }
                                }
                            }
                        } catch($async_e1) {
                            $async_e = System.Exception.create($async_e1);
                            throw $async_e;
                        }
                    }));
                    return $enumerator;
                }, arguments));
            },
            setVisualStateProperty_54a0cb8873a3411f97f57cfeafa4a445: function (finalTargetInstance, value) {

                var finalTargetInstanceType = Bridge.getType(finalTargetInstance);
                var propertyDeclaringType = Bridge.Reflection.getMembers(finalTargetInstanceType, 16, 284, "Background").td;
                var propertyField = Bridge.Reflection.getMembers(propertyDeclaringType, 4, 284, "BackgroundProperty");
                var property = Bridge.cast(Bridge.Reflection.fieldAccess(propertyField, null), Windows.UI.Xaml.DependencyProperty);

                (finalTargetInstance).SetVisualStateValue(property, value);
            },
            setAnimationVisualStateProperty_54a0cb8873a3411f97f57cfeafa4a445: function (finalTargetInstance, value) {

                var finalTargetInstanceType = Bridge.getType(finalTargetInstance);
                var propertyDeclaringType = Bridge.Reflection.getMembers(finalTargetInstanceType, 16, 284, "Background").td;
                var propertyField = Bridge.Reflection.getMembers(propertyDeclaringType, 4, 284, "BackgroundProperty");
                var property = Bridge.cast(Bridge.Reflection.fieldAccess(propertyField, null), Windows.UI.Xaml.DependencyProperty);

                (finalTargetInstance).SetAnimationValue(property, value);
            },
            setLocalVisualStateProperty_54a0cb8873a3411f97f57cfeafa4a445: function (finalTargetInstance, value) {

                var finalTargetInstanceType = Bridge.getType(finalTargetInstance);
                var propertyDeclaringType = Bridge.Reflection.getMembers(finalTargetInstanceType, 16, 284, "Background").td;
                var propertyField = Bridge.Reflection.getMembers(propertyDeclaringType, 4, 284, "BackgroundProperty");
                var property = Bridge.cast(Bridge.Reflection.fieldAccess(propertyField, null), Windows.UI.Xaml.DependencyProperty);

                (finalTargetInstance).SetCurrentValue(property, value);
            },
            getVisualStateProperty_54a0cb8873a3411f97f57cfeafa4a445: function (finalTargetInstance) {

                var finalTargetInstanceType = Bridge.getType(finalTargetInstance);
                var propertyDeclaringType = Bridge.Reflection.getMembers(finalTargetInstanceType, 16, 284, "Background").td;
                var propertyField = Bridge.Reflection.getMembers(propertyDeclaringType, 4, 284, "BackgroundProperty");
                var property = Bridge.cast(Bridge.Reflection.fieldAccess(propertyField, null), Windows.UI.Xaml.DependencyProperty);

                return finalTargetInstance.GetVisualStateValue(property);
            },
            accessVisualStateProperty_1b4562d2cc794734b887161119b5f390: function (rootTargetObjectInstance) {
                return new (Bridge.GeneratorEnumerable$1(System.Tuple$3(Windows.UI.Xaml.DependencyObject,Windows.UI.Xaml.DependencyProperty,System.Nullable$1(System.Int32))))(Bridge.fn.bind(this, function (rootTargetObjectInstance) {
                    var $step = 0,
                        $jumpFromFinally,
                        $returnValue,
                        $async_e;

                    var $enumerator = new (Bridge.GeneratorEnumerator$1(System.Tuple$3(Windows.UI.Xaml.DependencyObject,Windows.UI.Xaml.DependencyProperty,System.Nullable$1(System.Int32))))(Bridge.fn.bind(this, function () {
                        try {
                            for (;;) {
                                switch ($step) {
                                    case 0: {
                                        return false;
                                    }
                                    default: {
                                        return false;
                                    }
                                }
                            }
                        } catch($async_e1) {
                            $async_e = System.Exception.create($async_e1);
                            throw $async_e;
                        }
                    }));
                    return $enumerator;
                }, arguments));
            },
            setVisualStateProperty_1b4562d2cc794734b887161119b5f390: function (finalTargetInstance, value) {

                var finalTargetInstanceType = Bridge.getType(finalTargetInstance);
                var propertyDeclaringType = Bridge.Reflection.getMembers(finalTargetInstanceType, 16, 284, "Background").td;
                var propertyField = Bridge.Reflection.getMembers(propertyDeclaringType, 4, 284, "BackgroundProperty");
                var property = Bridge.cast(Bridge.Reflection.fieldAccess(propertyField, null), Windows.UI.Xaml.DependencyProperty);

                (finalTargetInstance).SetVisualStateValue(property, value);
            },
            setAnimationVisualStateProperty_1b4562d2cc794734b887161119b5f390: function (finalTargetInstance, value) {

                var finalTargetInstanceType = Bridge.getType(finalTargetInstance);
                var propertyDeclaringType = Bridge.Reflection.getMembers(finalTargetInstanceType, 16, 284, "Background").td;
                var propertyField = Bridge.Reflection.getMembers(propertyDeclaringType, 4, 284, "BackgroundProperty");
                var property = Bridge.cast(Bridge.Reflection.fieldAccess(propertyField, null), Windows.UI.Xaml.DependencyProperty);

                (finalTargetInstance).SetAnimationValue(property, value);
            },
            setLocalVisualStateProperty_1b4562d2cc794734b887161119b5f390: function (finalTargetInstance, value) {

                var finalTargetInstanceType = Bridge.getType(finalTargetInstance);
                var propertyDeclaringType = Bridge.Reflection.getMembers(finalTargetInstanceType, 16, 284, "Background").td;
                var propertyField = Bridge.Reflection.getMembers(propertyDeclaringType, 4, 284, "BackgroundProperty");
                var property = Bridge.cast(Bridge.Reflection.fieldAccess(propertyField, null), Windows.UI.Xaml.DependencyProperty);

                (finalTargetInstance).SetCurrentValue(property, value);
            },
            getVisualStateProperty_1b4562d2cc794734b887161119b5f390: function (finalTargetInstance) {

                var finalTargetInstanceType = Bridge.getType(finalTargetInstance);
                var propertyDeclaringType = Bridge.Reflection.getMembers(finalTargetInstanceType, 16, 284, "Background").td;
                var propertyField = Bridge.Reflection.getMembers(propertyDeclaringType, 4, 284, "BackgroundProperty");
                var property = Bridge.cast(Bridge.Reflection.fieldAccess(propertyField, null), Windows.UI.Xaml.DependencyProperty);

                return finalTargetInstance.GetVisualStateValue(property);
            }
        }
    });

    Bridge.define("QWC.MainPage", {
        inherits: [Windows.UI.Xaml.Controls.Page],
        fields: {
            filesReady: null,
            webSocketReady: null,
            webSocket: null,
            directwebSocket: null,
            connection: null,
            connectionport: null,
            AllReady: false,
            SetupCompleteRun: false,
            QWCGrid: null,
            QWCIcons: null,
            QWCHidden: null,
            QWCSideBars: null,
            Top: null,
            _contentLoaded: false
        },
        props: {
            FilesReady: {
                get: function () {
                    return this.filesReady.task;
                }
            },
            WebSocketReady: {
                get: function () {
                    return this.webSocketReady.task;
                }
            }
        },
        ctors: {
            init: function () {
                this.filesReady = new System.Threading.Tasks.TaskCompletionSource();
                this.webSocketReady = new System.Threading.Tasks.TaskCompletionSource();
                this.connection = "";
                this.connectionport = "";
                this.AllReady = false;
                this.SetupCompleteRun = false;
            },
            ctor: function () {
                this.$initialize();
                Windows.UI.Xaml.Controls.Page.ctor.call(this);
                this.RunRestMain();
            }
        },
        methods: {
            AddFileLoading: function () {
                mjh_filesloaded.value += 1;
                var FilesLoaded = System.Nullable.getValue(Bridge.cast(Bridge.unbox(mjh_filesloaded.value, System.Int32), System.Int32));
                var TotalFilesToBeLoaded = System.Nullable.getValue(Bridge.cast(Bridge.unbox(mjh_filesloaded.total, System.Int32), System.Int32));
                if (FilesLoaded === TotalFilesToBeLoaded) {
                    var x = this.filesReady.trySetResult(true);
                }
                ;
            },
            CheckFileLoading: function () {
                var FilesLoaded = System.Nullable.getValue(Bridge.cast(Bridge.unbox(mjh_filesloaded.value, System.Int32), System.Int32));
                var TotalFilesToBeLoaded = System.Nullable.getValue(Bridge.cast(Bridge.unbox(mjh_filesloaded.total, System.Int32), System.Int32));
                if (FilesLoaded === TotalFilesToBeLoaded) {
                    var x = this.filesReady.trySetResult(true);
                }
                ;
            },
            EndCustomCSS: function () {
                var runflg = System.Nullable.getValue(Bridge.cast(Bridge.unbox(('undefined' !=typeof ej &&  'undefined' != typeof ej.base), System.Boolean), System.Boolean));
                if (runflg) {
                    ej.base.enableRipple(false);
                }
            },
            RunRestMain: function () {
                window.addEventListener('beforeunload', Bridge.fn.cacheBind(this, this.OnBeforeUnload));
                Windows.UI.Xaml.Application.Current.Resources.setItem("MaxSerialNo", Bridge.box(0, System.Int32));
                Windows.UI.Xaml.Application.Current.Resources.setItem("FrameworkElement", this);
                Windows.UI.Xaml.Application.Current.Resources.setItem("AllReady", Bridge.box(this.AllReady, System.Boolean, System.Boolean.toString));
                var original = System.Windows.Browser.HtmlPage.Document.DocumentUri.getOriginalString();
                Windows.UI.Xaml.Application.Current.Resources.setItem("OriginalURL", original);
                var connection;
                var apps = APLExtension.Utils.GetAppsResource("QWC", "webdetails.html");
                connection = APLExtension.Utils.GetAppResource(apps, "Connection");
                if (0 === connection.length) {
                    connection = Bridge.cast(Windows.UI.Xaml.Application.Current.TryFindResource("Connection"), System.String);
                }
                var connectiontype = APLExtension.Utils.GetAppResource(apps, "ConnectionType");
                if (0 === connectiontype.length) {
                    connectiontype = Bridge.cast(Windows.UI.Xaml.Application.Current.TryFindResource("ConnectionType"), System.String);
                }
                var uploadhost = APLExtension.Utils.GetAppResource(apps, "UploadHost");
                if (null == uploadhost || 0 === uploadhost.length) {
                    uploadhost = Bridge.cast(Windows.UI.Xaml.Application.Current.TryFindResource("UploadHost"), System.String);
                    if (null == uploadhost || 0 === uploadhost.length) {
                        uploadhost = "localhost";
                    }
                }
                Windows.UI.Xaml.Application.Current.Resources.setItem("UploadHost", uploadhost);
                var uploadport = APLExtension.Utils.GetAppResource(apps, "UploadPort");
                if (null == uploadport || 0 === uploadport.length) {
                    uploadport = Bridge.cast(Windows.UI.Xaml.Application.Current.TryFindResource("UploadPort"), System.String);
                    if (null == uploadport || 0 === uploadport.length) {
                        uploadport = "1234";
                    }
                }
                Windows.UI.Xaml.Application.Current.Resources.setItem("UploadPort", uploadport);
                var uploadsecure = APLExtension.Utils.GetAppResource(apps, "UploadSecure");
                if (null == uploadsecure || 0 === uploadsecure.length) {
                    uploadsecure = Bridge.cast(Windows.UI.Xaml.Application.Current.TryFindResource("UploadSecure"), System.String);
                    if (null == uploadsecure || 0 === uploadsecure.length) {
                        uploadsecure = "0";
                    }
                }
                Windows.UI.Xaml.Application.Current.Resources.setItem("UploadSecure", uploadsecure);
                var name = APLExtension.Utils.GetAppResource(apps, "Name");
                if (0 === name.length) {
                    name = Bridge.cast(Windows.UI.Xaml.Application.Current.Resources.getItem("Name"), System.String);
                }
                var WSname = APLExtension.Utils.GetAppResource(apps, "WSName");
                if (0 === WSname.length) {
                    WSname = Bridge.cast(Windows.UI.Xaml.Application.Current.TryFindResource("WSName"), System.String);
                }
                var port = APLExtension.Utils.GetAppResource(apps, "Port");
                if (0 === port.length) {
                    port = Bridge.cast(Windows.UI.Xaml.Application.Current.TryFindResource("Port"), System.String);
                }
                if (null == WSname) {
                    WSname = "WS";
                }
                WSname = WSname.trim();
                if (Bridge.referenceEquals("", WSname)) {
                    WSname = "WS";
                }
                if (Bridge.referenceEquals(WSname.toUpperCase(), "NONE")) {
                    WSname = "";
                }
                if (null == connection) {
                    connection = "";
                }
                connection = connection.trim();
                if (null == connectiontype) {
                    connectiontype = "";
                }
                connectiontype = connectiontype.trim();
                if (Bridge.referenceEquals("", connectiontype)) {
                    connectiontype = "Direct";
                }
                if (Bridge.referenceEquals("", connection)) {
                    if (Bridge.referenceEquals("http", System.Windows.Browser.HtmlPage.Document.DocumentUri.getProtocol())) {
                        connection = System.Windows.Browser.HtmlPage.Document.DocumentUri.getHostName();
                    } else {
                        connection = "localhost";
                    }
                }
                var appname = APLExtension.Utils.GetAppResource(apps, "AppName");
                if (0 === appname.length) {
                    appname = Bridge.cast(Windows.UI.Xaml.Application.Current.TryFindResource("AppName"), System.String);
                }
                if (null == appname) {
                    appname = name;
                }
                if (Bridge.referenceEquals("", appname)) {
                    appname = name;
                }
                Windows.UI.Xaml.Application.Current.Resources.setItem("AppName", appname);
                if (Bridge.referenceEquals("Direct", connectiontype)) {
                    if (null == port) {
                        port = "";
                    }
                    var uri = Bridge.cast(document.location.search, System.String);
                    if (0 !== uri.length) {
                        var p = "";
                        for (var i = 0; i < uri.length; i = (i + 1) | 0) {
                            if (63 !== uri.charCodeAt(i)) {
                                if (48 === uri.charCodeAt(i) || 49 === uri.charCodeAt(i) || 50 === uri.charCodeAt(i) || 51 === uri.charCodeAt(i) || 52 === uri.charCodeAt(i) || 53 === uri.charCodeAt(i) || 54 === uri.charCodeAt(i) || 55 === uri.charCodeAt(i) || 56 === uri.charCodeAt(i) || 57 === uri.charCodeAt(i)) {
                                    p = (p || "") + String.fromCharCode(uri.charCodeAt(i));
                                } else {
                                    break;
                                }
                            }
                        }
                        if (0 !== p.length) {
                            port = p;
                        }
                    }
                    if (Bridge.referenceEquals("", port)) {
                        port = Bridge.toString(System.Windows.Browser.HtmlPage.Document.DocumentUri.getPort());
                    }
                    connection = (connection || "") + ((":" + (port || "") + "/" + (name || "") + "/") || "");
                } else {
                    if (0 !== connection.length) {
                        this.connectionport = APLExtension.Utils.GetAppResource(apps, "ConnectionPort");
                        if (this.connectionport == null || 0 === this.connectionport.length) {
                            this.connectionport = Bridge.cast(Windows.UI.Xaml.Application.Current.TryFindResource("ConnectionPort"), System.String);
                        }
                        if (this.connectionport != null && 0 !== this.connectionport.length) {
                            connection = (connection || "") + ((":" + (this.connectionport || "")) || "");
                        }
                    }
                    connection = (connection || "") + (("/" + (WSname || "")) || "");
                    if (0 !== WSname.length) {
                        connection = (connection || "") + "/";
                    }
                }
                var secureconnection = APLExtension.Utils.GetAppResource(apps, "SecureConnection");
                if (null == secureconnection || 0 === secureconnection.length) {
                    secureconnection = Bridge.cast(Windows.UI.Xaml.Application.Current.TryFindResource("SecureConnection"), System.String);
                    if (null == secureconnection || 0 === secureconnection.length) {
                        secureconnection = "0";
                    }
                }
                Windows.UI.Xaml.Application.Current.Resources.setItem("SecureConnection", secureconnection);
                if (Bridge.referenceEquals(secureconnection, "1")) {
                    connection = "wss://" + (connection || "");
                } else {
                    connection = "ws://" + (connection || "");
                }
                var _WSInternals = Bridge.as(APLExtension.APL.MakeInstance("DataBinding", "WSInternals", "WSInternals", this), DataBinding.WSInternals);
                var _qwc_Root = Bridge.as(APLExtension.APL.MakeInstance("DataBinding", "qwc_Root", "qwc_Root", this), DataBinding.qwc_Root);
                var rnd = new System.Random.ctor();
                var rnds = Bridge.toString(rnd.Next());
                this.webSocket = new CSHTML5.Extensions.WebSockets.WebSocket((connection || "") + "?hash=" + (rnds || ""));
                this.directwebSocket = new CSHTML5.Extensions.WebSockets.WebSocket((connection || "") + "?hash=" + (rnds || ""));
                Windows.UI.Xaml.Application.Current.Resources.setItem("WebSocket", this.webSocket);
                Windows.UI.Xaml.Application.Current.Resources.setItem("DirectWebSocket", this.directwebSocket);
                var xstring;
                var d = "";
                this.webSocket.addOnMessage(Bridge.fn.bind(this, function (s, e) {
                    var $step = 0,
                        $task1, 
                        $taskResult1, 
                        $jumpFromFinally, 
                        data, 
                        ds, 
                        trans, 
                        fullfont, 
                        f, 
                        elem, 
                        cl, 
                        o, 
                        assembly, 
                        type, 
                        ob, 
                        cl1, 
                        obj, 
                        assembly1, 
                        cl2, 
                        obj1, 
                        cla, 
                        method, 
                        $arguments, 
                        assembly2, 
                        cl3, 
                        obj2, 
                        cla1, 
                        method1, 
                        $arguments1, 
                        typecl, 
                        method11, 
                        $arguments2, 
                        NQresult, 
                        obj3, 
                        assembly3, 
                        type1, 
                        method2, 
                        $asyncBody = Bridge.fn.bind(this, function () {
                            for (;;) {
                                $step = System.Array.min([0,1,2,3], $step);
                                switch ($step) {
                                    case 0: {
                                        if (this.SetupCompleteRun) {
                                            $step = 1;
                                            continue;
                                        } 
                                        $step = 3;
                                        continue;
                                    }
                                    case 1: {
                                        this.SetupCompleteRun = false;
                                        this.CheckFileLoading();
                                        $task1 = this.FilesReady;
                                        $step = 2;
                                        if ($task1.isCompleted()) {
                                            continue;
                                        }
                                        $task1.continue($asyncBody);
                                        return;
                                    }
                                    case 2: {
                                        $taskResult1 = $task1.getAwaitedResult();
                                        this.EndCustomCSS();
                                        $step = 3;
                                        continue;
                                    }
                                    case 3: {
                                        data = APLExtension.TD.Split$1(e.Data, APLExtension.TD.delims5);
                                        for (var i1 = 0; i1 < data.length; i1 = (i1 + 1) | 0) {
                                            ds = APLExtension.TD.ToTransferString(data[System.Array.index(i1, data)]);
                                            trans = ds.Trans;
                                            if (Bridge.referenceEquals(ds.Action, "WaitForQueue")) {
                                                this.webSocket.Send(data[System.Array.index(i1, data)]);
                                            } else if (Bridge.referenceEquals(ds.Action, "MJH_CloseServer")) {
                                                this.webSocket.Send(data[System.Array.index(i1, data)]);
                                            } else if (Bridge.referenceEquals(ds.Action, "Ping")) {
                                                this.webSocket.Send(data[System.Array.index(i1, data)]);
                                            } else if (Bridge.referenceEquals(ds.Action, "Loaded")) {
                                                Windows.UI.Xaml.Application.Current.Resources.setItem("Index", ds.Data);
                                                this.webSocketReady.setResult(true);
                                                _WSInternals.Status = "WebSocket Opened ";
                                                this.AllReady = true;
                                                Windows.UI.Xaml.Application.Current.Resources.setItem("AllReady", Bridge.box(this.AllReady, System.Boolean, System.Boolean.toString));
                                                this.InitializeComponent();
                                                this.MakeWinSize(_qwc_Root, _WSInternals);
                                                _qwc_Root.NotifyPropertyChanged("FontList");
                                                _qwc_Root.NotifyPropertyChanged("FontFamily");
                                                _qwc_Root.NotifyPropertyChanged("Caption");
                                                _qwc_Root.NotifyPropertyChanged("URL");
                                                _qwc_Root.NotifyPropertyChanged("URLS");
                                                _qwc_Root.NotifyPropertyChanged("Captions");
                                                loadFont("APL385","app-cshtml5/res/QWC/fonts/apl385-webfont.woff");
                                                fullfont = function (_o1) {
                                                    _o1.add("APL385");
                                                    _o1.add("Andal\u00e9 Mono");
                                                    _o1.add("Arial");
                                                    _o1.add("Arial Black");
                                                    _o1.add("Arial Narrow");
                                                    _o1.add("Arial Rounded MT Bold");
                                                    _o1.add("Baskerville");
                                                    _o1.add("Bodoni 72");
                                                    _o1.add("Bodoni MT");
                                                    _o1.add("Bradley Hand");
                                                    _o1.add("Brush Script MT");
                                                    _o1.add("Calibri");
                                                    _o1.add("Calisto MT");
                                                    _o1.add("Cambria");
                                                    _o1.add("Candara");
                                                    _o1.add("Century Gothic");
                                                    _o1.add("Comic Sans MS");
                                                    _o1.add("Consolas");
                                                    _o1.add("Copperplate Gothic");
                                                    _o1.add("Courier");
                                                    _o1.add("Courier New");
                                                    _o1.add("Dejavu Sans");
                                                    _o1.add("Didot");
                                                    _o1.add("Franklin Gothic");
                                                    _o1.add("Garamond");
                                                    _o1.add("Georgia");
                                                    _o1.add("Gill Sans");
                                                    _o1.add("Goudy Old Style");
                                                    _o1.add("Helvetica");
                                                    _o1.add("Helvetica Neu");
                                                    _o1.add("Impact");
                                                    _o1.add("Lucida");
                                                    _o1.add("Lucida Bright");
                                                    _o1.add("Lucida Handwriting");
                                                    _o1.add("Lucida Sans");
                                                    _o1.add("Luminari");
                                                    _o1.add("Microsoft Sans Serif");
                                                    _o1.add("Monaco");
                                                    _o1.add("Optima");
                                                    _o1.add("Palatino");
                                                    _o1.add("Perpetua");
                                                    _o1.add("Rage");
                                                    _o1.add("Rockwell");
                                                    _o1.add("Script MT");
                                                    _o1.add("Segoe UI");
                                                    _o1.add("Segoe script");
                                                    _o1.add("Snell Roundhand");
                                                    _o1.add("Tahoma");
                                                    _o1.add("Times New Roman");
                                                    _o1.add("Trebuchet MS");
                                                    _o1.add("Verdana");
                                                    return _o1;
                                                }(new (System.Collections.Generic.List$1(System.String)).ctor());
                                                _qwc_Root.MJH_FontList_Shape[System.Array.index(0, _qwc_Root.MJH_FontList_Shape)] = 51;
                                                _qwc_Root.MJH_FontList_Shape[System.Array.index(1, _qwc_Root.MJH_FontList_Shape)] = 8;
                                                _qwc_Root.MJH_FontFamily_Shape = 51;
                                                f = new (System.Collections.Generic.List$1(System.Collections.Generic.List$1(APLExtension.APLItem))).ctor();
                                                for (var r = 0; r < 51; r = (r + 1) | 0) {
                                                    f.add(new (System.Collections.Generic.List$1(APLExtension.APLItem)).ctor());
                                                    f.getItem(r).add(new APLExtension.APLItem.$ctor9(fullfont.getItem(r)));
                                                    f.getItem(r).add(new APLExtension.APLItem.$ctor7(0));
                                                    f.getItem(r).add(new APLExtension.APLItem.$ctor7(0));
                                                    f.getItem(r).add(new APLExtension.APLItem.$ctor7(0));
                                                    f.getItem(r).add(new APLExtension.APLItem.$ctor7(0));
                                                    f.getItem(r).add(new APLExtension.APLItem.$ctor7(0));
                                                    f.getItem(r).add(new APLExtension.APLItem.$ctor7(0));
                                                    f.getItem(r).add(new APLExtension.APLItem.$ctor7(0));
                                                }
                                                _qwc_Root.FontList = f;
                                                _qwc_Root.FontFamily = function (_o2) {
                                                    _o2.add("APL385");
                                                    _o2.add("Andal\u00e9 Mono, monospace");
                                                    _o2.add("Arial, Helvetica Neue, Helvetica, sans-serif");
                                                    _o2.add("Arial Black, Arial Bold, Gadget, sans-serif");
                                                    _o2.add("Arial Narrow, Arial, sans-serif");
                                                    _o2.add("Arial Rounded MT Bold, Helvetica Rounded, Arial, sans-serif");
                                                    _o2.add("Baskerville, Baskerville Old Face, Garamond, Times New Roman, serif");
                                                    _o2.add("Bodoni 72, Bodoni MT, Didot, Didot LT STD, Hoefler Text, Garamond, Times New Roman, serif");
                                                    _o2.add("Bodoni MT, Bodoni 72, Didot, Didot LT STD, Hoefler Text, Garamond, Times New Roman, serif");
                                                    _o2.add("Bradley Hand, cursive");
                                                    _o2.add("Brush Script MT, cursive");
                                                    _o2.add("Calibri, Candara, Segoe, Segoe UI, Optima, Arial, sans-serif");
                                                    _o2.add("Calisto MT, Bookman Old Style, Bookman, Goudy Old Style, Garamond, Hoefler Text, Bitstream Charter, Georgia, serif");
                                                    _o2.add("Cambria, Georgia, serif");
                                                    _o2.add("Candara, Calibri, Segoe, Segoe UI, Optima, Arial, sans-serif");
                                                    _o2.add("Century Gothic, CenturyGothic, AppleGothic, sans-serif");
                                                    _o2.add("Comic Sans MS, cursive");
                                                    _o2.add("Consolas, monaco, monospace");
                                                    _o2.add("Copperplate Gothic, Copperplate Gothic Light, fantasy");
                                                    _o2.add("Courier, monospace");
                                                    _o2.add("Courier New, Courier, Lucida Sans Typewriter, Lucida Typewriter, monospace");
                                                    _o2.add("Dejavu Sans, Arial, Verdana, sans-serif");
                                                    _o2.add("Didot, Didot LT STD, Hoefler Text, Garamond, Calisto MT, Times New Roman, serif");
                                                    _o2.add("Franklin Gothic, Arial Bold, Arial, sans-serif");
                                                    _o2.add("Garamond, Baskerville, Baskerville Old Face, Hoefler Text, Times New Roman, serif");
                                                    _o2.add("Georgia, Times, Times New Roman, serif");
                                                    _o2.add("Gill Sans, Gill Sans MT, Calibri, sans-serif");
                                                    _o2.add("Goudy Old Style, Garamond, Big Caslon, Times New Roman, serif");
                                                    _o2.add("Helvetica, Helvetica Neu, Arial, sans-serif.");
                                                    _o2.add("Helvetica Neu, Helvetica, Arial, sans-serif.");
                                                    _o2.add("Impact, Charcoal, Helvetica Inserat, Bitstream Vera Sans Bold, Arial Black, sans-serif.");
                                                    _o2.add("Lucida, monospace");
                                                    _o2.add("Lucida Bright, Georgia, serif.");
                                                    _o2.add("Lucida Handwriting, cursive");
                                                    _o2.add("Lucida Sans, Helvetica, Arial, sans-serif.");
                                                    _o2.add("Luminari, fantasy");
                                                    _o2.add("Microsoft Sans Serif, sans-serif.");
                                                    _o2.add("Monaco, monospace");
                                                    _o2.add("Optima, Segoe, Segoe UI, Candara, Calibri, Arial, sans-serif.");
                                                    _o2.add("Palatino, Palatino Linotype, Palatino LT STD, Book Antiqua, Georgia, serif.");
                                                    _o2.add("Perpetua, Baskerville, Big Caslon, Palatino Linotype, Palatino, serif.");
                                                    _o2.add("Rage, cursive");
                                                    _o2.add("Rockwell, Courier Bold, Courier, Georgia, Times, Times New Roman, serif.");
                                                    _o2.add("Script MT, cursive");
                                                    _o2.add("Segoe UI, Frutiger, Dejavu Sans, Helvetica Neue, Arial, sans-serif.");
                                                    _o2.add("Segoe script, cursive");
                                                    _o2.add("Snell Roundhand, cursive");
                                                    _o2.add("Tahoma, Verdana, Segoe, sans-serif.");
                                                    _o2.add("Times New Roman, Georgia, serif;");
                                                    _o2.add("Trebuchet MS, Lucida Grande, Lucida Sans Unicode, Lucida Sans, sans-serif.");
                                                    _o2.add("Verdana, Geneva, sans-serif.");
                                                    return _o2;
                                                }(new (System.Collections.Generic.List$1(System.String)).ctor());
                                                _qwc_Root.NotifyPropertyChanged("FontList");
                                                _qwc_Root.NotifyPropertyChanged("FontFamily");
                                                xstring = new APLExtension.TransferString();
                                                xstring.Type = "SetupComplete";
                                                this.SetupCompleteRun = true;
                                                d = APLExtension.TD.FromTransferString(xstring);
                                                this.webSocket.Send(d);
                                                elem = document.getElementById("mjhsplashscreen");
                                                elem.style = "display: none;";
                                            } else if (Bridge.referenceEquals(ds.Action, "Create")) {
                                                this.EndCustomCSS();
                                                ds.Name = "Type";
                                                ds.Data = ds.Class.substr(3);
                                                if (Bridge.referenceEquals(ds.Class, "qwcButton") || Bridge.referenceEquals(ds.Class, "qwcCombo") || Bridge.referenceEquals(ds.Class, "qwcDateTimePicker") || Bridge.referenceEquals(ds.Class, "qwcMsgBox") || Bridge.referenceEquals(ds.Class, "qwcEdit") || Bridge.referenceEquals(ds.Class, "qwcList") || Bridge.referenceEquals(ds.Class, "qwcListViewSingle") || Bridge.referenceEquals(ds.Class, "qwcListViewMulti") || Bridge.referenceEquals(ds.Class, "qwcMenuItem") || Bridge.referenceEquals(ds.Class, "qwcTabControl")) {
                                                    ds.Class = (ds.Class || "") + (ds.Extras || "");
                                                }
                                                cl = (ds.Class || "") + "_Data";
                                                o = APLExtension.APL.MakeInstance("DataBinding", cl, ds.Instance, this);
                                                xstring = new APLExtension.TransferString();
                                                xstring.Trans = trans;
                                                d = APLExtension.TD.FromTransferString(xstring);
                                                this.webSocket.Send(d);
                                            } else if (Bridge.referenceEquals(ds.Action, "EndRunLoaded")) {
                                                this.CreateControl(ds);
                                            } else if (Bridge.referenceEquals(ds.Action, "OldCreate")) {
                                                ds.Name = "Type";
                                                ds.Data = ds.Class.substr(3);
                                                if (Bridge.referenceEquals(ds.Class, "qwcButton") || Bridge.referenceEquals(ds.Class, "qwcCombo") || Bridge.referenceEquals(ds.Class, "qwcDateTimePicker") || Bridge.referenceEquals(ds.Class, "qwcMsgBox") || Bridge.referenceEquals(ds.Class, "qwcEdit") || Bridge.referenceEquals(ds.Class, "qwcList") || Bridge.referenceEquals(ds.Class, "qwcListViewSingle") || Bridge.referenceEquals(ds.Class, "qwcListViewMulti") || Bridge.referenceEquals(ds.Class, "qwcMenuItem") || Bridge.referenceEquals(ds.Class, "qwcTabControl")) {
                                                    ds.Class = (ds.Class || "") + (ds.Extras || "");
                                                }
                                                assembly = APLExtension.APL.GetAssembly("DataBinding", this);
                                                type = Bridge.Reflection.getType("DataBinding." + (ds.Class || ""), assembly);
                                                ob = Bridge.createInstance(type, [ds]);
                                                cl1 = APLExtension.APL.GetClassByName(ds.Instance);
                                                obj = APLExtension.APL.GetInstance$3("DataBinding", cl1, ds.Instance, ob);
                                                xstring = new APLExtension.TransferString();
                                                xstring.Trans = trans;
                                                d = APLExtension.TD.FromTransferString(xstring);
                                                this.webSocket.Send(d);
                                                this.directwebSocket.Send(d);
                                            } else if (Bridge.referenceEquals(ds.Action, "CreateContinue1")) {
                                                if (Bridge.referenceEquals(ds.Class, "qwcButton") || Bridge.referenceEquals(ds.Class, "qwcCombo") || Bridge.referenceEquals(ds.Class, "qwcDateTimePicker") || Bridge.referenceEquals(ds.Class, "qwcMsgBox") || Bridge.referenceEquals(ds.Class, "qwcEdit") || Bridge.referenceEquals(ds.Class, "qwcList") || Bridge.referenceEquals(ds.Class, "qwcListViewSingle") || Bridge.referenceEquals(ds.Class, "qwcListViewMulti") || Bridge.referenceEquals(ds.Class, "qwcMenuItem") || Bridge.referenceEquals(ds.Class, "qwcTabControl")) {
                                                    ds.Class = (ds.Class || "") + (ds.Extras || "");
                                                }
                                                assembly1 = APLExtension.APL.GetAssembly("DataBinding", this);
                                                cl2 = APLExtension.APL.GetClassByName(ds.Instance);
                                                obj1 = APLExtension.APL.GetInstance$3("DataBinding", cl2, ds.Instance, null);
                                                cla = Bridge.Reflection.getType("DataBinding." + (ds.Class || ""), assembly1);
                                                method = Bridge.Reflection.getMembers(cla, 8, 284, "CreateContinue1");
                                                if (method != null) {
                                                    $arguments = System.Array.init([ds], System.Object);
                                                    Bridge.Reflection.midel(method, Bridge.unbox(Bridge.cast(obj1, APLExtension.MJH_CommonData).MJH_Class)).apply(null, Bridge.unbox($arguments));
                                                }
                                                xstring = new APLExtension.TransferString();
                                                xstring.Trans = trans;
                                                d = APLExtension.TD.FromTransferString(xstring);
                                                this.webSocket.Send(d);
                                                this.directwebSocket.Send(d);
                                            } else if (Bridge.referenceEquals(ds.Action, "CreateContinue2")) {
                                                if (Bridge.referenceEquals(ds.Class, "qwcButton") || Bridge.referenceEquals(ds.Class, "qwcCombo") || Bridge.referenceEquals(ds.Class, "qwcDateTimePicker") || Bridge.referenceEquals(ds.Class, "qwcMsgBox") || Bridge.referenceEquals(ds.Class, "qwcEdit") || Bridge.referenceEquals(ds.Class, "qwcList") || Bridge.referenceEquals(ds.Class, "qwcListViewSingle") || Bridge.referenceEquals(ds.Class, "qwcListViewMulti") || Bridge.referenceEquals(ds.Class, "qwcMenuItem") || Bridge.referenceEquals(ds.Class, "qwcTabControl")) {
                                                    ds.Class = (ds.Class || "") + (ds.Extras || "");
                                                }
                                                assembly2 = APLExtension.APL.GetAssembly("DataBinding", this);
                                                cl3 = APLExtension.APL.GetClassByName(ds.Instance);
                                                obj2 = APLExtension.APL.GetInstance$3("DataBinding", cl3, ds.Instance, null);
                                                cla1 = Bridge.Reflection.getType("DataBinding." + (ds.Class || ""), assembly2);
                                                method1 = Bridge.Reflection.getMembers(cla1, 8, 284, "CreateContinue2");
                                                if (method1 != null) {
                                                    $arguments1 = System.Array.init([ds], System.Object);
                                                    Bridge.Reflection.midel(method1, Bridge.unbox(Bridge.cast(obj2, APLExtension.MJH_CommonData).MJH_Class)).apply(null, Bridge.unbox($arguments1));
                                                }
                                                if (0 !== ds.Extras.length) {
                                                    ds.Name = "Style";
                                                    ds.Data = ds.Extras;
                                                    typecl = Bridge.Reflection.getType("DataBinding." + (cl3 || ""), assembly2);
                                                    method11 = Bridge.Reflection.getMembers(typecl, 8, 284, "RunPropertyChangedIn");
                                                    $arguments2 = System.Array.init([ds, Bridge.box(false, System.Boolean, System.Boolean.toString)], System.Object);
                                                    Bridge.Reflection.midel(method11, Bridge.unbox(obj2)).apply(null, Bridge.unbox($arguments2));
                                                }
                                                xstring = new APLExtension.TransferString();
                                                xstring.Trans = trans;
                                                d = APLExtension.TD.FromTransferString(xstring);
                                                this.webSocket.Send(d);
                                                this.directwebSocket.Send(d);
                                            } else if (Bridge.referenceEquals(ds.Action, "EnQueue")) {
                                        ds.Class = APLExtension.APL.GetClassByName(ds.Instance);
                                                if (null != ds.Class) {
                                                    obj3 = APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this);
                                                    $arguments1 = System.Array.init([ds, this], System.Object);
                                                    assembly3 = APLExtension.APL.GetAssembly("QWC", this);
                                                    type1 = Bridge.Reflection.getType("QWC.NQ", assembly3);
                                                    method2 = Bridge.Reflection.getMembers(type1, 8, 284, "Do" + (ds.Name || ""));
                                                    if (APLExtension.Utils.IsStatic(method2)) {
                                                        NQresult = Bridge.cast(Bridge.Reflection.midel(method2, null).apply(null, Bridge.unbox($arguments1)), System.String);
                                                    } else {
                                                        NQresult = Bridge.cast(Bridge.Reflection.midel(method2, Bridge.unbox(obj3)).apply(null, Bridge.unbox($arguments1)), System.String);
                                                    }
                                                } else {
                                                    NQresult = "False";
                                                }
                                                xstring = new APLExtension.TransferString();
                                                xstring.Type = "EnQueue";
                                                xstring.Data = NQresult;
                                                xstring.Trans = trans;
                                                d = APLExtension.TD.FromTransferString(xstring);
                                                this.directwebSocket.Send(d);
                                            } else {
                                                this.RunDataBinding(ds);
                                            }
                                        }
                                        return;
                                    }
                                    default: {
                                        return;
                                    }
                                }
                            }
                        }, arguments);

                    $asyncBody();
                }));
                this.webSocket.addOnError(function (s, e) {
                    _WSInternals.Status = "ERROR : " + (e.Data || "");
                });
                this.webSocket.addOnClose(function (s, e) {
                    _WSInternals.Status = "WebSocket Closed ";
                });
                this.webSocket.addOnOpen(Bridge.fn.bind(this, function (s, e) {
                    xstring = new APLExtension.TransferString();
                    xstring.Type = "SessionStart";
                    xstring.Data = Bridge.cast(Windows.UI.Xaml.Application.Current.Resources.getItem("OriginalURL"), System.String);
                    d = APLExtension.TD.FromTransferString(xstring);
                    this.webSocket.Send(d);
                }));
                this.directwebSocket.addOnOpen(Bridge.fn.bind(this, function (s, e) {
                    var $step = 0,
                        $task1, 
                        $taskResult1, 
                        $jumpFromFinally, 
                        dx, 
                        $asyncBody = Bridge.fn.bind(this, function () {
                            for (;;) {
                                $step = System.Array.min([0,1], $step);
                                switch ($step) {
                                    case 0: {
                                        xstring = new APLExtension.TransferString();
                                        $task1 = this.WebSocketReady;
                                        $step = 1;
                                        if ($task1.isCompleted()) {
                                            continue;
                                        }
                                        $task1.continue($asyncBody);
                                        return;
                                    }
                                    case 1: {
                                        $taskResult1 = $task1.getAwaitedResult();
                                        xstring.Data = Bridge.cast(Windows.UI.Xaml.Application.Current.Resources.getItem("Index"), System.String);
                                        xstring.Type = "Index";
                                        dx = APLExtension.TD.FromTransferString(xstring);
                                        this.directwebSocket.Send(dx);
                                        return;
                                    }
                                    default: {
                                        return;
                                    }
                                }
                            }
                        }, arguments);

                    $asyncBody();
                }));
                this.directwebSocket.addOnMessage(Bridge.fn.bind(this, function (s, e) {
                    var ds = APLExtension.TD.ToTransferString(e.Data);
                    var trans = ds.Trans;
                    if (Bridge.referenceEquals(ds.Action, "MJH_CloseServer")) {
                        this.directwebSocket.Send(e.Data);
                    } else if (Bridge.referenceEquals(ds.Action, "EnQueue")) {
                        var NQresult;
                        ds.Class = APLExtension.APL.GetClassByName(ds.Instance);
                        if (null != ds.Class) {
                            var obj = APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this);
                            var $arguments = System.Array.init([ds, this], System.Object);
                            var assembly = APLExtension.APL.GetAssembly("QWC", this);
                            var type = Bridge.Reflection.getType("QWC.NQ", assembly);
                            var method = Bridge.Reflection.getMembers(type, 8, 284, "Do" + (ds.Name || ""));
                            if (APLExtension.Utils.IsStatic(method)) {
                                NQresult = Bridge.cast(Bridge.Reflection.midel(method, null).apply(null, Bridge.unbox($arguments)), System.String);
                            } else {
                                NQresult = Bridge.cast(Bridge.Reflection.midel(method, Bridge.unbox(obj)).apply(null, Bridge.unbox($arguments)), System.String);
                            }
                        } else {
                            NQresult = "False";
                        }
                        xstring = new APLExtension.TransferString();
                        xstring.Type = "EnQueue";
                        xstring.Data = NQresult;
                        xstring.Trans = trans;
                        d = APLExtension.TD.FromTransferString(xstring);
                        this.directwebSocket.Send(d);
                    } else if (Bridge.referenceEquals(ds.Action, "ReturnEvent")) {
                        APLExtension.APL.RaiseEventReturned(e.Data);
                    }
                }));
            },
            IsEJ1: function (inp) {
                return false;
            },
            IsEJ2: function (inp) {
                if (Bridge.referenceEquals(inp, "qwcAppBar_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcAvatar_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcBadge_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcBarCode_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcBreadCrumb_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcCalendar_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcCard_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcCarousel_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcChart_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcChips_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcCircularGauge_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcColourPicker_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcColorPicker_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcComboDrop_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcComboDropEdit_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcComboSimple_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcContextMenu_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcDashBoard_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcDataGrid_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcDataManager_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcDateTimePickerCombo_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcDiagram_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcMsgBoxMsg_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcMsgBoxInfo_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcMsgBoxQuery_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcMsgBoxWarn_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcMsgBoxError_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcDocumentEditor_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcFileManager_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcGantt_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcGrid_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcImageEditor_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcLinearGauge_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcImage_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcKanban_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcListSingle_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcListMulti_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcListViewSingle_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcListViewMulti_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcMaps_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcMention_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcMenuBar_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcMessage_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcPager_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcPDFViewer_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcPivotTable_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcProgressBar_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcProgressButton_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcQueryBuilder_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcQRCode_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcRating_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcRibbon_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcRichTextEditor_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcSchedule_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcSideBar_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcSignature_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcSkeleton_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcSplitter_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcTabControl_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcText_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcTreeView_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcUploader_Data")) {
                    return true;
                }
                return false;
            },
            CreateControl: function (ds) {
                var assembly = APLExtension.APL.GetAssembly("DataBinding", this);
                var type = Bridge.Reflection.getType("DataBinding." + (ds.Class || ""), assembly);
                var cl = (ds.Class || "") + "_Data";
                var isEJ1 = this.IsEJ1(cl);
                var isEJ2 = this.IsEJ2(cl);
                var ob = Bridge.createInstance(type, [ds]);
                var method = Bridge.Reflection.getMembers(type, 8, 284, "CreateContinue1");
                var obj = APLExtension.APL.GetInstance$3("DataBinding", cl, ds.Instance, null);
                if (method != null) {
                    var $arguments = System.Array.init([ds], System.Object);
                    Bridge.Reflection.midel(method, Bridge.unbox(Bridge.cast(obj, APLExtension.MJH_CommonData).MJH_Class)).apply(null, Bridge.unbox($arguments));
                }
                method = Bridge.Reflection.getMembers(type, 8, 284, "CreateContinue2");
                if (method != null) {
                    var $arguments1 = System.Array.init([ds], System.Object);
                    Bridge.Reflection.midel(method, Bridge.unbox(Bridge.cast(obj, APLExtension.MJH_CommonData).MJH_Class)).apply(null, Bridge.unbox($arguments1));
                }
                if (0 !== ds.Extras.length) {
                    ds.Name = "Style";
                    ds.Data = ds.Extras;
                    var typecl = Bridge.Reflection.getType("DataBinding." + (cl || ""), assembly);
                    method = Bridge.Reflection.getMembers(typecl, 8, 284, "RunPropertyChangedIn");
                    var $arguments2 = System.Array.init([ds, Bridge.box(false, System.Boolean, System.Boolean.toString)], System.Object);
                    Bridge.Reflection.midel(method, Bridge.unbox(obj)).apply(null, Bridge.unbox($arguments2));
                }
            },
            RunDataBinding: function (ds) {
                if (Bridge.referenceEquals(ds.Class, "qwc_Root")) {
                    var dbobj1 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwc_Root);
                    if (null != dbobj1) {
                        dbobj1.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "MJH_DQ_Data")) {
                    var dbobj2 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.MJH_DQ_Data);
                    if (null != dbobj2) {
                        dbobj2.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "MJH_MinForm_Data")) {
                    var dbobj3 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.MJH_MinForm_Data);
                    if (null != dbobj3) {
                        dbobj3.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcAppBar_Data")) {
                    var dbobj4 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcAppBar_Data);
                    if (null != dbobj4) {
                        dbobj4.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcAvatar_Data")) {
                    var dbobj5 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcAvatar_Data);
                    if (null != dbobj5) {
                        dbobj5.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcBadge_Data")) {
                    var dbobj6 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcBadge_Data);
                    if (null != dbobj6) {
                        dbobj6.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcBarCode_Data")) {
                    var dbobj7 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcBarCode_Data);
                    if (null != dbobj7) {
                        dbobj7.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcBreadCrumb_Data")) {
                    var dbobj8 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcBreadCrumb_Data);
                    if (null != dbobj8) {
                        dbobj8.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcBridgeScore_Data")) {
                    var dbobj9 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcBridgeScore_Data);
                    if (null != dbobj9) {
                        dbobj9.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcButtonCheck_Data")) {
                    var dbobj10 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcButtonCheck_Data);
                    if (null != dbobj10) {
                        dbobj10.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcButtonCommandLink_Data")) {
                    var dbobj11 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcButtonCommandLink_Data);
                    if (null != dbobj11) {
                        dbobj11.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcButtonPush_Data")) {
                    var dbobj12 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcButtonPush_Data);
                    if (null != dbobj12) {
                        dbobj12.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcButtonRadio_Data")) {
                    var dbobj13 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcButtonRadio_Data);
                    if (null != dbobj13) {
                        dbobj13.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcButtonSplit_Data")) {
                    var dbobj14 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcButtonSplit_Data);
                    if (null != dbobj14) {
                        dbobj14.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcButtonToggle_Data")) {
                    var dbobj15 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcButtonToggle_Data);
                    if (null != dbobj15) {
                        dbobj15.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcCalendar_Data")) {
                    var dbobj16 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcCalendar_Data);
                    if (null != dbobj16) {
                        dbobj16.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcCard_Data")) {
                    var dbobj17 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcCard_Data);
                    if (null != dbobj17) {
                        dbobj17.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcCarousel_Data")) {
                    var dbobj18 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcCarousel_Data);
                    if (null != dbobj18) {
                        dbobj18.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcChart_Data")) {
                    var dbobj19 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcChart_Data);
                    if (null != dbobj19) {
                        dbobj19.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcChips_Data")) {
                    var dbobj20 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcChips_Data);
                    if (null != dbobj20) {
                        dbobj20.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcCircularGauge_Data")) {
                    var dbobj21 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcCircularGauge_Data);
                    if (null != dbobj21) {
                        dbobj21.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcColourPicker_Data")) {
                    var dbobj22 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcColourPicker_Data);
                    if (null != dbobj22) {
                        dbobj22.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcColorPicker_Data")) {
                    var dbobj23 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcColorPicker_Data);
                    if (null != dbobj23) {
                        dbobj23.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcComboDrop_Data")) {
                    var dbobj24 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcComboDrop_Data);
                    if (null != dbobj24) {
                        dbobj24.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcComboDropEdit_Data")) {
                    var dbobj25 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcComboDropEdit_Data);
                    if (null != dbobj25) {
                        dbobj25.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcComboSimple_Data")) {
                    var dbobj26 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcComboSimple_Data);
                    if (null != dbobj26) {
                        dbobj26.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcContextMenu_Data")) {
                    var dbobj27 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcContextMenu_Data);
                    if (null != dbobj27) {
                        dbobj27.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcDashBoard_Data")) {
                    var dbobj28 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcDashBoard_Data);
                    if (null != dbobj28) {
                        dbobj28.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcDataGrid_Data")) {
                    var dbobj29 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcDataGrid_Data);
                    if (null != dbobj29) {
                        dbobj29.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcDataManager_Data")) {
                    var dbobj30 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcDataManager_Data);
                    if (null != dbobj30) {
                        dbobj30.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcDatePicker_Data")) {
                    var dbobj31 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcDatePicker_Data);
                    if (null != dbobj31) {
                        dbobj31.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcDateTimePickerCombo_Data")) {
                    var dbobj32 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcDateTimePickerCombo_Data);
                    if (null != dbobj32) {
                        dbobj32.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcDiagram_Data")) {
                    var dbobj33 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcDiagram_Data);
                    if (null != dbobj33) {
                        dbobj33.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcMsgBoxMsg_Data")) {
                    var dbobj34 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcMsgBoxMsg_Data);
                    if (null != dbobj34) {
                        dbobj34.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcMsgBoxInfo_Data")) {
                    var dbobj35 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcMsgBoxInfo_Data);
                    if (null != dbobj35) {
                        dbobj35.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcMsgBoxQuery_Data")) {
                    var dbobj36 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcMsgBoxQuery_Data);
                    if (null != dbobj36) {
                        dbobj36.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcMsgBoxWarn_Data")) {
                    var dbobj37 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcMsgBoxWarn_Data);
                    if (null != dbobj37) {
                        dbobj37.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcMsgBoxError_Data")) {
                    var dbobj38 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcMsgBoxError_Data);
                    if (null != dbobj38) {
                        dbobj38.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcDocumentEditor_Data")) {
                    var dbobj39 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcDocumentEditor_Data);
                    if (null != dbobj39) {
                        dbobj39.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcEditSingle_Data")) {
                    var dbobj40 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcEditSingle_Data);
                    if (null != dbobj40) {
                        dbobj40.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcEditMulti_Data")) {
                    var dbobj41 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcEditMulti_Data);
                    if (null != dbobj41) {
                        dbobj41.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcExpander_Data")) {
                    var dbobj42 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcExpander_Data);
                    if (null != dbobj42) {
                        dbobj42.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcFileManager_Data")) {
                    var dbobj43 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcFileManager_Data);
                    if (null != dbobj43) {
                        dbobj43.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcFont_Data")) {
                    var dbobj44 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcFont_Data);
                    if (null != dbobj44) {
                        dbobj44.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcForm_Data")) {
                    var dbobj45 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcForm_Data);
                    if (null != dbobj45) {
                        dbobj45.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcGantt_Data")) {
                    var dbobj46 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcGantt_Data);
                    if (null != dbobj46) {
                        dbobj46.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcGrid_Data")) {
                    var dbobj47 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcGrid_Data);
                    if (null != dbobj47) {
                        dbobj47.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcGroup_Data")) {
                    var dbobj48 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcGroup_Data);
                    if (null != dbobj48) {
                        dbobj48.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcImageEditor_Data")) {
                    var dbobj49 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcImageEditor_Data);
                    if (null != dbobj49) {
                        dbobj49.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcKanban_Data")) {
                    var dbobj50 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcKanban_Data);
                    if (null != dbobj50) {
                        dbobj50.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcLabel_Data")) {
                    var dbobj51 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcLabel_Data);
                    if (null != dbobj51) {
                        dbobj51.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcLinearGauge_Data")) {
                    var dbobj52 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcLinearGauge_Data);
                    if (null != dbobj52) {
                        dbobj52.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcImage_Data")) {
                    var dbobj53 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcImage_Data);
                    if (null != dbobj53) {
                        dbobj53.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcImageList_Data")) {
                    var dbobj54 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcImageList_Data);
                    if (null != dbobj54) {
                        dbobj54.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcKanban_Data")) {
                    var dbobj55 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcKanban_Data);
                    if (null != dbobj55) {
                        dbobj55.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcListSingle_Data")) {
                    var dbobj56 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcListSingle_Data);
                    if (null != dbobj56) {
                        dbobj56.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcListMulti_Data")) {
                    var dbobj57 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcListMulti_Data);
                    if (null != dbobj57) {
                        dbobj57.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcListViewSingle_Data")) {
                    var dbobj58 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcListViewSingle_Data);
                    if (null != dbobj58) {
                        dbobj58.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcListViewMulti_Data")) {
                    var dbobj59 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcListViewMulti_Data);
                    if (null != dbobj59) {
                        dbobj59.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcMaps_Data")) {
                    var dbobj60 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcMaps_Data);
                    if (null != dbobj60) {
                        dbobj60.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcMention_Data")) {
                    var dbobj61 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcMention_Data);
                    if (null != dbobj61) {
                        dbobj61.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcMenu_Data")) {
                    var dbobj62 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcMenu_Data);
                    if (null != dbobj62) {
                        dbobj62.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcMenuBar_Data")) {
                    var dbobj63 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcMenuBar_Data);
                    if (null != dbobj63) {
                        dbobj63.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcMenuItemCheck_Data")) {
                    var dbobj64 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcMenuItemCheck_Data);
                    if (null != dbobj64) {
                        dbobj64.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcMenuItemRadio_Data")) {
                    var dbobj65 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcMenuItemRadio_Data);
                    if (null != dbobj65) {
                        dbobj65.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcMessage_Data")) {
                    var dbobj66 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcMessage_Data);
                    if (null != dbobj66) {
                        dbobj66.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcPager_Data")) {
                    var dbobj67 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcPager_Data);
                    if (null != dbobj67) {
                        dbobj67.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcPDFViewer_Data")) {
                    var dbobj68 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcPDFViewer_Data);
                    if (null != dbobj68) {
                        dbobj68.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcPivotTable_Data")) {
                    var dbobj69 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcPivotTable_Data);
                    if (null != dbobj69) {
                        dbobj69.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcProgressBar_Data")) {
                    var dbobj70 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcProgressBar_Data);
                    if (null != dbobj70) {
                        dbobj70.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcProgressButton_Data")) {
                    var dbobj71 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcProgressButton_Data);
                    if (null != dbobj71) {
                        dbobj71.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcQueryBuilder_Data")) {
                    var dbobj72 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcQueryBuilder_Data);
                    if (null != dbobj72) {
                        dbobj72.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcQRCode_Data")) {
                    var dbobj73 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcQRCode_Data);
                    if (null != dbobj73) {
                        dbobj73.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcRating_Data")) {
                    var dbobj74 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcRating_Data);
                    if (null != dbobj74) {
                        dbobj74.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcRibbon_Data")) {
                    var dbobj75 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcRibbon_Data);
                    if (null != dbobj75) {
                        dbobj75.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcRichTextEditor_Data")) {
                    var dbobj76 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcRichTextEditor_Data);
                    if (null != dbobj76) {
                        dbobj76.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcSchedule_Data")) {
                    var dbobj77 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcSchedule_Data);
                    if (null != dbobj77) {
                        dbobj77.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcSeparator_Data")) {
                    var dbobj78 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcSeparator_Data);
                    if (null != dbobj78) {
                        dbobj78.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcSideBar_Data")) {
                    var dbobj79 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcSideBar_Data);
                    if (null != dbobj79) {
                        dbobj79.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcSignature_Data")) {
                    var dbobj80 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcSignature_Data);
                    if (null != dbobj80) {
                        dbobj80.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcSkeleton_Data")) {
                    var dbobj81 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcSkeleton_Data);
                    if (null != dbobj81) {
                        dbobj81.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcSplitter_Data")) {
                    var dbobj82 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcSplitter_Data);
                    if (null != dbobj82) {
                        dbobj82.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcSubForm_Data")) {
                    var dbobj83 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcSubForm_Data);
                    if (null != dbobj83) {
                        dbobj83.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcTabButton_Data")) {
                    var dbobj84 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcTabButton_Data);
                    if (null != dbobj84) {
                        dbobj84.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcTabButton1_Data")) {
                    var dbobj85 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcTabButton1_Data);
                    if (null != dbobj85) {
                        dbobj85.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcTabControl_Data")) {
                    var dbobj86 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcTabControl_Data);
                    if (null != dbobj86) {
                        dbobj86.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcTabControlButtons_Data")) {
                    var dbobj87 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcTabControlButtons_Data);
                    if (null != dbobj87) {
                        dbobj87.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcTabControlFlatButtons_Data")) {
                    var dbobj88 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcTabControlFlatButtons_Data);
                    if (null != dbobj88) {
                        dbobj88.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcTabControlTabs_Data")) {
                    var dbobj89 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcTabControlTabs_Data);
                    if (null != dbobj89) {
                        dbobj89.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcText_Data")) {
                    var dbobj90 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcText_Data);
                    if (null != dbobj90) {
                        dbobj90.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcTreeView_Data")) {
                    var dbobj91 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcTreeView_Data);
                    if (null != dbobj91) {
                        dbobj91.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcUploader_Data")) {
                    var dbobj92 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcUploader_Data);
                    if (null != dbobj92) {
                        dbobj92.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "WSInternals")) {
                    var dbobj93 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.WSInternals);
                    if (null != dbobj93) {
                        dbobj93.RunPropertyChangedIn(ds, false);
                    }
                }

            },
            OnBeforeUnload: function (e) {
                var msg = "Do you want to leave QWC?";
                e.preventDefault();
                e.returnValue = msg;
                return msg;
            },
            MakeWinSize: function (rt, wi) {
                wi.SetValue("Status", "WebSocket Opened");
                var fsz = new Windows.Foundation.Size.ctor();
                fsz.Width = System.Nullable.getValue(Bridge.cast(Bridge.unbox(screen.width, System.Double), System.Double));
                fsz.Height = System.Nullable.getValue(Bridge.cast(Bridge.unbox(screen.height, System.Double), System.Double));
                Windows.UI.Xaml.Application.Current.Resources.setItem("FullScreenHeight", Bridge.box(fsz.Height, System.Double, System.Double.format, System.Double.getHashCode));
                Windows.UI.Xaml.Application.Current.Resources.setItem("FullScreenWidth", Bridge.box(fsz.Width, System.Double, System.Double.format, System.Double.getHashCode));
                rt.SetValue("FullScreenSize", fsz.$clone());
                var win = Windows.UI.Xaml.Window.Current;
                Windows.UI.Xaml.Application.Current.Resources.setItem("Screen", win);
                var rect = win.Bounds.$clone();
                Windows.UI.Xaml.Application.Current.Resources.setItem("ScreenHeight", Bridge.box(rect.Height, System.Double, System.Double.format, System.Double.getHashCode));
                Windows.UI.Xaml.Application.Current.Resources.setItem("ScreenWidth", Bridge.box(rect.Width, System.Double, System.Double.format, System.Double.getHashCode));
                rt.SetValue("ScreenSize", rect.Size.$clone());
                rt.SetValue("BrowserScreenSize", rect.Size.$clone());
                var ratio = System.Nullable.getValue(Bridge.cast(Bridge.unbox(window.devicePixelRatio, System.Double), System.Double));
                if (ratio < 1) {
                    ratio = 1 / ratio;
                }
                var fSize = new Windows.Foundation.Size.$ctor1(Bridge.Int.clip32(fsz.Width) * ratio, Bridge.Int.clip32(fsz.Height) * ratio);
                Windows.UI.Xaml.Application.Current.Resources.setItem("FullScreenHeight", Bridge.box(fSize.Height, System.Double, System.Double.format, System.Double.getHashCode));
                Windows.UI.Xaml.Application.Current.Resources.setItem("FullScreenWidth", Bridge.box(fSize.Width, System.Double, System.Double.format, System.Double.getHashCode));
                rt.SetValue("FullScreenSize", fSize.$clone());
                win.addSizeChanged$1(Bridge.fn.bind(this, function (s1, e1) {
                    var newsz = e1.Size.$clone();
                    var root = Bridge.as(APLExtension.APL.GetInstance$3("DataBinding", "qwc_Root", "qwc_Root", this), DataBinding.qwc_Root);
                    root.SetValue("ScreenSize", newsz.$clone());
                    root.SetValue("BrowserScreenSize", newsz.$clone());
                    var ratio1 = System.Nullable.getValue(Bridge.cast(Bridge.unbox(window.devicePixelRatio, System.Double), System.Double));
                    if (ratio1 < 1) {
                        ratio1 = 1 / ratio1 + 0.5;
                    }
                    var fSize1 = new Windows.Foundation.Size.$ctor1(Bridge.Int.clip32(fsz.Width) * ratio1, Bridge.Int.clip32(fsz.Height) * ratio1);
                    Windows.UI.Xaml.Application.Current.Resources.setItem("FullScreenHeight", Bridge.box(fSize1.Height, System.Double, System.Double.format, System.Double.getHashCode));
                    Windows.UI.Xaml.Application.Current.Resources.setItem("FullScreenWidth", Bridge.box(fSize1.Width, System.Double, System.Double.format, System.Double.getHashCode));
                    root.SetValue("FullScreenSize", fSize1.$clone());
                    Windows.UI.Xaml.Application.Current.Resources.setItem("ScreenHeight", Bridge.box(newsz.Height, System.Double, System.Double.format, System.Double.getHashCode));
                    Windows.UI.Xaml.Application.Current.Resources.setItem("ScreenWidth", Bridge.box(newsz.Width, System.Double, System.Double.format, System.Double.getHashCode));
                    Windows.UI.Xaml.Application.Current.Resources.setItem("BrowserScreenHeight", Bridge.box(newsz.Height, System.Double, System.Double.format, System.Double.getHashCode));
                    Windows.UI.Xaml.Application.Current.Resources.setItem("BrowserScreenWidth", Bridge.box(newsz.Width, System.Double, System.Double.format, System.Double.getHashCode));
                    var fm = Bridge.cast(root.GetValue("FullScreenId"), System.String);
                    if (0 !== fm.length) {
                        var ds = Bridge.as(APLExtension.APL.GetInstance$3("DataBinding", "qwcForm_Data", fm, this), DataBinding.qwcForm_Data);
                        if (fm != null && 4 === System.Nullable.getValue(Bridge.cast(Bridge.unbox(ds.GetValue("State"), System.Int32), System.Int32))) {
                            ds.NotifyPropertyChanged("Size");
                        }
                    }
                }));
            },
            UpdateBindingLostFocus: function (sender, e) {
                var tx = Bridge.cast(sender, Windows.UI.Xaml.Controls.TextBox);
                if (0 !== tx.Text.length) {
                    var exp = tx.GetBindingExpression(Windows.UI.Xaml.Controls.TextBox.TextProperty);
                    var dobj = Bridge.as(exp.DataItem, APLExtension.MJH_CommonData);
                    var instance = dobj.MJH_Instance;
                    var ds = APLExtension.TD.ToTransferString("");
                    ds.Name = exp.ParentBinding.Path.Path;
                    ds.Data = tx.Text;
                    ds.Instance = instance;
                    ds.Class = APLExtension.APL.GetClassByName(ds.Instance);
                    var obj = APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this);
                    var $arguments = System.Array.init([ds, Bridge.box(true, System.Boolean, System.Boolean.toString)], System.Object);
                    var assembly = APLExtension.APL.GetAssembly("DataBinding", this);
                    var type = Bridge.Reflection.getType("DataBinding." + (ds.Class || ""), assembly);
                    var method = Bridge.Reflection.getMembers(type, 8, 284, "RunPropertyChangedIn");
                    Bridge.Reflection.midel(method, Bridge.unbox(obj)).apply(null, Bridge.unbox($arguments));
                }
            },
            UpdateBindingKeyDown: function (sender, e) {
                if (e.Key === Windows.System.VirtualKey.Enter) {
                    var tx = Bridge.cast(sender, Windows.UI.Xaml.Controls.TextBox);
                    if (0 !== tx.Text.length) {
                        var exp = tx.GetBindingExpression(Windows.UI.Xaml.Controls.TextBox.TextProperty);
                        var dobj = Bridge.as(exp.DataItem, APLExtension.MJH_CommonData);
                        var instance = dobj.MJH_Instance;
                        var ds = APLExtension.TD.ToTransferString("");
                        ds.Name = exp.ParentBinding.Path.Path;
                        ds.Data = tx.Text;
                        ds.Instance = instance;
                        ds.Class = APLExtension.APL.GetClassByName(ds.Instance);
                        var obj = APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this);
                        var $arguments = System.Array.init([ds, Bridge.box(true, System.Boolean, System.Boolean.toString)], System.Object);
                        var assembly = APLExtension.APL.GetAssembly("DataBinding", this);
                        var type = Bridge.Reflection.getType("DataBinding." + (ds.Class || ""), assembly);
                        var method = Bridge.Reflection.getMembers(type, 8, 284, "RunPropertyChangedIn");
                        Bridge.Reflection.midel(method, Bridge.unbox(obj)).apply(null, Bridge.unbox($arguments));
                    }
                }
            },
            InitializeComponent: function () {
                if (this._contentLoaded) {
                    return;
                }
                this._contentLoaded = true;


                if (Bridge.is(this, Windows.UI.Xaml.UIElement)) {
                    Bridge.cast(this, Windows.UI.Xaml.UIElement).XamlSourcePath = "QWC\\MainPage.xaml";
                }

                var Grid_c0fbb892d8dc48fc954b32034d970906 = new Bridge.global.Windows.UI.Xaml.Controls.Grid();
                var WrapPanel_085e34ff59424d80b43a982c0f6e1f90 = new Bridge.global.Windows.UI.Xaml.Controls.WrapPanel();
                var Grid_6bcfde4e69a540be954bedc37e6c868b = new Bridge.global.Windows.UI.Xaml.Controls.Grid();
                var Grid_18dca0dda72f415c8a4f916601b5f943 = new Bridge.global.Windows.UI.Xaml.Controls.Grid();

                this.RegisterName$1("Top", this);
                this.Name = "Top";
                var IntConverter_cb07c22e80964a46bd97b5a1b5ccd0af = new Bridge.global.APLExtension.IntConverter();

                var DecConverter_543883217bea43f3b6f7301373ac8c64 = new Bridge.global.APLExtension.DecConverter();

                this.Resources.setItem("IntConverter", IntConverter_cb07c22e80964a46bd97b5a1b5ccd0af);
                this.Resources.setItem("DecConverter", DecConverter_543883217bea43f3b6f7301373ac8c64);

                var Grid_aabfa88274774fd1b64b29c0811ee156 = new Bridge.global.Windows.UI.Xaml.Controls.Grid();
                var RowDefinition_dfae27ab75b947be8d5e9a10f820ec8e = new Bridge.global.Windows.UI.Xaml.Controls.RowDefinition();
                RowDefinition_dfae27ab75b947be8d5e9a10f820ec8e.Height = new Bridge.global.Windows.UI.Xaml.GridLength.$ctor2(1.0, Bridge.global.Windows.UI.Xaml.GridUnitType.Star);

                var RowDefinition_46ad6ef044ee4e5aa4f4688baa81781c = new Bridge.global.Windows.UI.Xaml.Controls.RowDefinition();
                RowDefinition_46ad6ef044ee4e5aa4f4688baa81781c.Height = new Bridge.global.Windows.UI.Xaml.GridLength.$ctor2(1.0, Bridge.global.Windows.UI.Xaml.GridUnitType.Auto);

                Grid_aabfa88274774fd1b64b29c0811ee156.RowDefinitions.add(RowDefinition_dfae27ab75b947be8d5e9a10f820ec8e);
                Grid_aabfa88274774fd1b64b29c0811ee156.RowDefinitions.add(RowDefinition_46ad6ef044ee4e5aa4f4688baa81781c);

                this.RegisterName$1("QWCGrid", Grid_c0fbb892d8dc48fc954b32034d970906);
                Grid_c0fbb892d8dc48fc954b32034d970906.Name = "QWCGrid";

                this.RegisterName$1("QWCIcons", WrapPanel_085e34ff59424d80b43a982c0f6e1f90);
                WrapPanel_085e34ff59424d80b43a982c0f6e1f90.Name = "QWCIcons";
                Bridge.global.Windows.UI.Xaml.Controls.Grid.SetRow(WrapPanel_085e34ff59424d80b43a982c0f6e1f90, 1);

                this.RegisterName$1("QWCHidden", Grid_6bcfde4e69a540be954bedc37e6c868b);
                Grid_6bcfde4e69a540be954bedc37e6c868b.Name = "QWCHidden";
                Bridge.global.Windows.UI.Xaml.Controls.Grid.SetRow(Grid_6bcfde4e69a540be954bedc37e6c868b, 1);
                Grid_6bcfde4e69a540be954bedc37e6c868b.Visibility = Bridge.global.Windows.UI.Xaml.Visibility.Collapsed;

                this.RegisterName$1("QWCSideBars", Grid_18dca0dda72f415c8a4f916601b5f943);
                Grid_18dca0dda72f415c8a4f916601b5f943.Name = "QWCSideBars";
                Bridge.global.Windows.UI.Xaml.Controls.Grid.SetRow(Grid_18dca0dda72f415c8a4f916601b5f943, 1);
                Grid_18dca0dda72f415c8a4f916601b5f943.Visibility = Bridge.global.Windows.UI.Xaml.Visibility.Collapsed;

                Grid_aabfa88274774fd1b64b29c0811ee156.Children.add(Grid_c0fbb892d8dc48fc954b32034d970906);
                Grid_aabfa88274774fd1b64b29c0811ee156.Children.add(WrapPanel_085e34ff59424d80b43a982c0f6e1f90);
                Grid_aabfa88274774fd1b64b29c0811ee156.Children.add(Grid_6bcfde4e69a540be954bedc37e6c868b);
                Grid_aabfa88274774fd1b64b29c0811ee156.Children.add(Grid_18dca0dda72f415c8a4f916601b5f943);


                this.Content = Grid_aabfa88274774fd1b64b29c0811ee156;

                var DataContextExtension_6791ee5553424f5084f453fc96327ff8 = new Bridge.global.APLExtension.DataContextExtension.ctor();
                DataContextExtension_6791ee5553424f5084f453fc96327ff8.Instance = "qwc_Root";
                DataContextExtension_6791ee5553424f5084f453fc96327ff8.Class = "qwc_Root";
                DataContextExtension_6791ee5553424f5084f453fc96327ff8.NS = "DataBinding";




                this.QWCGrid = Grid_c0fbb892d8dc48fc954b32034d970906;
                this.QWCIcons = WrapPanel_085e34ff59424d80b43a982c0f6e1f90;
                this.QWCHidden = Grid_6bcfde4e69a540be954bedc37e6c868b;
                this.QWCSideBars = Grid_18dca0dda72f415c8a4f916601b5f943;
                this.Top = this;

                var customMarkupValue_71d1cc8edd5b42a3bafeb8d1cacb7748 = DataContextExtension_6791ee5553424f5084f453fc96327ff8.ProvideValue(new Bridge.global.System.ServiceProvider.ctor(this, Bridge.global.Windows.UI.Xaml.FrameworkElement.DataContextProperty));
                if (Bridge.is(customMarkupValue_71d1cc8edd5b42a3bafeb8d1cacb7748, Windows.UI.Xaml.Data.Binding)) {
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(this, Bridge.global.Windows.UI.Xaml.FrameworkElement.DataContextProperty, Bridge.cast(customMarkupValue_71d1cc8edd5b42a3bafeb8d1cacb7748, Windows.UI.Xaml.Data.Binding));
                } else {
                    this.DataContext = customMarkupValue_71d1cc8edd5b42a3bafeb8d1cacb7748;
                }

            }
        }
    });

    Bridge.define("QWC.NQ", {
        statics: {
            fields: {
                LockInstances: null
            },
            ctors: {
                init: function () {
                    this.LockInstances = { };
                }
            },
            methods: {
                DoAddVisual: function (ds, actthis) {
                    var obj = APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, actthis);
                    var $arguments = System.Array.init([ds], System.Object);
                    var assembly = APLExtension.APL.GetAssembly("DataBinding", actthis);

                    var cl = APLExtension.APL.GetClassByName(ds.Instance);
                    if (System.String.contains(cl,"_Data")) {
                        cl = cl.substr(0, ((cl.length - 5) | 0));
                    }
                    var type = Bridge.Reflection.getType("DataBinding." + (cl || ""), assembly);

                    var method = Bridge.Reflection.getMembers(type, 8, 284, "DoAddVisual");

                    if (APLExtension.Utils.IsStatic(method)) {
                        return Bridge.cast(Bridge.Reflection.midel(method, null).apply(null, Bridge.unbox($arguments)), System.String);
                    } else {
                        return Bridge.cast(Bridge.Reflection.midel(method, Bridge.unbox(Bridge.cast(obj, APLExtension.MJH_CommonData).MJH_Class)).apply(null, Bridge.unbox($arguments)), System.String);
                    }
                },
                DoRunEvent: function (ds, actthis) {
                    var obj = APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, actthis);
                    var $arguments = System.Array.init([ds], System.Object);
                    var assembly = APLExtension.APL.GetAssembly("DataBinding", actthis);

                    var cl = APLExtension.APL.GetClassByName(ds.Instance);
                    if (System.String.contains(cl,"_Data")) {
                        cl = cl.substr(0, ((cl.length - 5) | 0));
                    }
                    var type = Bridge.Reflection.getType("DataBinding." + (cl || ""), assembly);

                    var method = Bridge.Reflection.getMembers(type, 8, 284, "DoRunEvent");

                    var result = "";
                    if (method != null) {
                        if (APLExtension.Utils.IsStatic(method)) {
                            result = Bridge.cast(Bridge.Reflection.midel(method, null).apply(null, Bridge.unbox($arguments)), System.String);
                        } else {
                            result = Bridge.cast(Bridge.Reflection.midel(method, Bridge.unbox(Bridge.cast(obj, APLExtension.MJH_CommonData).MJH_Class)).apply(null, Bridge.unbox($arguments)), System.String);
                        }
                    }
                    return result;
                },
                DoRunMethod: function (ds, actthis) {
                    var result = "";
                    var obj = APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, actthis);
                    var $arguments = System.Array.init([ds], System.Object);
                    var assembly = APLExtension.APL.GetAssembly("DataBinding", actthis);
                    var cl = APLExtension.APL.GetClassByName(ds.Instance);

                    if (System.String.contains(cl,"_Data")) {
                        cl = cl.substr(0, ((cl.length - 5) | 0));
                    }
                    var type = Bridge.Reflection.getType("DataBinding." + (cl || ""), assembly);
                    var method = Bridge.Reflection.getMembers(type, 8, 284, "Do" + (ds.Data || ""));

                    if (method != null) {
                        if (APLExtension.Utils.IsStatic(method)) {
                            result = Bridge.cast(Bridge.Reflection.midel(method, null).apply(null, Bridge.unbox($arguments)), System.String);
                        } else {
                            result = Bridge.cast(Bridge.Reflection.midel(method, Bridge.unbox(Bridge.cast(obj, APLExtension.MJH_CommonData).MJH_Class)).apply(null, Bridge.unbox($arguments)), System.String);
                        }
                    }
                    return result;
                },
                DoGetSerialNo: function (ds, actthis) {
                    var obj = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, actthis), APLExtension.MJH_CommonData);
                    var result = obj.MJH_SerialNo;
                    return result;
                },
                DoDelete: function (ds, actthis) {
                    if (Bridge.referenceEquals(ds.Class, "qwc_Root")) {
                        return ("");
                    }
                    var result = "";

                    var obj = APLExtension.APL.GetInstance(ds.SerialNo);
                    var $arguments = System.Array.init([ds], System.Object);
                    var assembly = APLExtension.APL.GetAssembly("DataBinding", actthis);
                    if (0 !== ds.SerialNo.length) {
                        var cl = APLExtension.APL.GetClassBySerialNo(ds.SerialNo);
                        if (0 !== cl.length) {
                            if (System.String.contains(cl,"_Data")) {
                                cl = cl.substr(0, ((cl.length - 5) | 0));
                            }
                            var type = Bridge.Reflection.getType("DataBinding." + (cl || ""), assembly);

                            var method = Bridge.Reflection.getMembers(type, 8, 284, "DoDelete");

                            if (method != null) {
                                if (APLExtension.Utils.IsStatic(method)) {
                                    result = Bridge.cast(Bridge.Reflection.midel(method, null).apply(null, Bridge.unbox($arguments)), System.String);
                                } else {
                                    var self = Bridge.cast(obj, APLExtension.MJH_CommonData);
                                    result = Bridge.cast(Bridge.Reflection.midel(method, Bridge.unbox(self.MJH_Class)).apply(null, Bridge.unbox($arguments)), System.String);
                                }
                            }
                        }
                        return result;
                    } else {
                        return "";
                    }
                },
                DoSetAccelerator: function (ds, actthis) {
                    var key = System.Convert.toInt32(ds.Args);
                    if (key !== 0) {
                        APLExtension.Accelerator.Add(key, ds.Instance);
                    } else {
                        APLExtension.Accelerator.Remove(key, ds.Instance);

                    }
                    return "";
                }
            }
        }
    });
});

//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAiZmlsZSI6ICJRV0MuanMiLAogICJzb3VyY2VSb290IjogIiIsCiAgInNvdXJjZXMiOiBbIm9iai9EZWJ1Zy9BcHAueGFtbC5nLmNzIiwib2JqL0RlYnVnL01haW5QYWdlLnhhbWwuZy5jcyIsIkFwcC54YW1sLmNzIiwiTWFpblBhZ2UueGFtbC5jcyIsIk1KSF9FbnF1ZXVlLmNzIl0sCiAgIm5hbWVzIjogWyIiXSwKICAibWFwcGluZ3MiOiAiOzs7Ozs7Ozs7Ozs7O29CQVFRQSxXQUEyQkEsQUFBT0E7b0JBQ2xDQSxPQUFPQSxtRUFBNkRBOzs7Ozs7Ozs7O29CQ0RwRUEsV0FBMkJBLEFBQU9BO29CQUNsQ0EsT0FBT0EsbUVBQTZEQTs7Ozs7Ozs7O1lEaXlDeEVBLElBQUlBOzs7Ozs7Ozs7O2dCRXZ4Q0lBO2dCQUVBQTtvQkFFSUEsUUFBNEJBLElBQUlBO29CQUNoQ0EscUVBQStDQTtvQkFDL0NBLDZEQUF1Q0E7Ozs7Z0JBRTNDQSxlQUFlQSxJQUFJQTtnQkFDNUJBLCtDQUErRUE7Z0JBQ3RFQSx5Q0FBeUJBOzs7O21DQUVwQkEsR0FBVUE7Z0JBQzNCQSxTQUFrQkEsWUFBZUEsQUFBQ0EsWUFBU0E7Z0JBQzNDQTtnQkFDQUE7Z0JBQ0FBLFdBQWdCQSxnRkFBdURBO2dCQUN2RUE7O21DQUVpQkEsR0FBVUE7Z0JBQzNCQSxTQUFrQkEsWUFBY0EsQUFBQ0EsWUFBUUE7Z0JBQ3pDQTtnQkFDQUEsSUFBSUEsTUFBS0E7b0JBQVVBOztvQkFDZEE7O2dCQUNMQSxXQUFnQkEsZ0ZBQXVEQTtnQkFDdkVBOzswQ0FFd0JBLEdBQVVBO2dCQUNsQ0EsU0FBa0JBLFlBQWNBLEFBQUNBLFlBQVFBO2dCQUN6Q0EsVUFBY0E7Z0JBQ2RBO2dCQUNBQSxXQUEyQ0EsdUJBQWVBO2dCQUMxREE7Z0JBQ0FBO2dCQUNBQSxXQUFnQkEsZ0ZBQXVEQTtnQkFDdkVBLG9CQUFvQkE7O3FDQUVEQSxHQUFVQTtnQkFDN0JBLFNBQWtCQSxZQUFjQSxBQUFDQSxZQUFRQTtnQkFDekNBO2dCQUNBQTtnQkFDQUEsVUFBY0E7Z0JBQ2RBOzs7O2dCRnBCWUEsSUFBSUE7b0JBQ0FBOztnQkFDSkE7OztnQkFHQUEsSUFBSUE7b0JBRUFBLEFBQUNBLFlBQW1DQSxBQUFRQTs7OztnQkFLNURBO2dCQUNBQTtnQkFDQUE7Z0JBQ0FBOzs7Z0JBR0FBLDBEQUEwREEsSUFBSUE7Z0JBQzlEQSxpQkFBaUJBO2dCQUNqQkEsb0RBQW9EQSxJQUFJQTs7Z0JBRXhEQSxvREFBb0RBLElBQUlBOztnQkFFeERBLDJEQUEyREEsSUFBSUE7O2dCQUUvREEseURBQXlEQSxJQUFJQTs7Z0JBRTdEQSx3REFBd0RBLElBQUlBOztnQkFFNURBLHlEQUF5REEsSUFBSUE7O2dCQUU3REEsNERBQTREQSxJQUFJQTs7Z0JBRWhFQSw4REFBOERBLElBQUlBOztnQkFFbEVBLGlFQUFpRUEsSUFBSUE7O2dCQUVyRUEsMkRBQTJEQSxJQUFJQTs7Z0JBRS9EQSw0REFBNERBLElBQUlBOztnQkFFaEVBLDREQUE0REEsSUFBSUE7O2dCQUVoRUEsOERBQThEQSxJQUFJQTs7Z0JBRWxFQSwrREFBK0RBLElBQUlBOztnQkFFbkVBLHVEQUF1REEsSUFBSUE7O2dCQUUzREEsdURBQXVEQSxJQUFJQTs7Z0JBRTNEQSxzREFBc0RBLElBQUlBOztnQkFFMURBLHNEQUFzREEsSUFBSUE7O2dCQUUxREE7O2dCQUVBQTs7Z0JBRUFBOztnQkFFQUE7O2dCQUVBQTs7Z0JBRUFBOztnQkFFQUE7O2dCQUVBQTs7Z0JBRUFBOztnQkFFQUE7O2dCQUVBQTs7Z0JBRUFBLDZDQUE2Q0EsSUFBSUE7Z0JBQ2pEQSxvREFBb0RBLEFBQU9BO2dCQUMzREEsOENBQThDQSxJQUFJQTtnQkFDbERBLG1EQUFtREE7Z0JBQ25EQSxnREFBZ0RBLElBQUlBLDJEQUE4Q0EsVUFBSUEseUNBQWlDQSxVQUFhQSxZQUFlQSxZQUFlQTs7Z0JBRWxMQSw4Q0FBOENBLElBQUlBO2dCQUNsREEsbURBQW1EQTtnQkFDbkRBOztnQkFFQUEsOENBQThDQSxJQUFJQTtnQkFDbERBLG1EQUFtREE7Z0JBQ25EQSxnREFBZ0RBOztnQkFFaERBLDhDQUE4Q0EsSUFBSUE7Z0JBQ2xEQSxtREFBbURBO2dCQUNuREEsZ0RBQWdEQTs7Z0JBRWhEQSw4Q0FBOENBLElBQUlBO2dCQUNsREEsbURBQW1EQTtnQkFDbkRBLHVEQUF1REEsSUFBSUE7Z0JBQzNEQSw4REFBOERBLEFBQU9BO2dCQUNyRUEseUZBQXlGQSxBQUFpRkE7O29CQUUxS0Esd0RBQXdEQSxJQUFJQTtvQkFDNURBLGtFQUFrRUE7b0JBQ2xFQSxtREFBbURBLElBQUlBO29CQUN2REEsbURBQW1EQSxJQUFJQTtvQkFDdkRBLHdEQUF3REEsSUFBSUE7b0JBQzVEQSw0Q0FBNENBLElBQUlBO29CQUNoREEsOENBQThDQSxJQUFJQTtvQkFDbERBLHNEQUFzREEsSUFBSUE7b0JBQzFEQSw4Q0FBOENBLElBQUlBO29CQUNsREEsOENBQThDQSxJQUFJQTtvQkFDbERBLDhDQUE4Q0EsSUFBSUE7b0JBQ2xEQSw4Q0FBOENBLElBQUlBO29CQUNsREEsOENBQThDQSxJQUFJQTtvQkFDbERBLDhDQUE4Q0EsSUFBSUE7b0JBQ2xEQSx3REFBd0RBLElBQUlBO29CQUM1REEsOENBQThDQSxJQUFJQTtvQkFDbERBLDhDQUE4Q0EsSUFBSUE7b0JBQ2xEQSw0Q0FBNENBLElBQUlBO29CQUNoREEsb0ZBQW9GQTtvQkFDcEZBO29CQUNBQSw4REFBOERBLElBQUlBO29CQUNsRUEsMkZBQTJGQTtvQkFDM0ZBO29CQUNBQSx3RkFBd0ZBO29CQUN4RkE7b0JBQ0FBLGtEQUFrREEsSUFBSUE7b0JBQ3REQSxxRUFBcUVBLElBQUlBO29CQUN6RUEsdUVBQWlFQTtvQkFDakVBLDhEQUE4REEsSUFBSUE7b0JBQ2xFQSxxREFBcURBLElBQUlBOztvQkFFekRBLGdFQUFnRUE7OztvQkFHaEVBLDZFQUE2RUE7OztvQkFHN0VBLHFFQUFxRUEsSUFBSUE7b0JBQ3pFQSx1RUFBaUVBO29CQUNqRUEsOERBQThEQSxJQUFJQTtvQkFDbEVBOztvQkFFQUEsNkVBQTZFQTs7O29CQUc3RUEseURBQXlEQTtvQkFDekRBLHlEQUF5REE7OztvQkFHekRBLDBEQUEwREE7OztvQkFHMURBLHFGQUFxRkE7b0JBQ3JGQTs7b0JBRUFBLDJFQUE2REE7b0JBQzdEQSwyRUFBNkRBOzs7b0JBRzdEQSxtR0FBbUdBOztvQkFFbkdBLHVGQUF1RkE7b0JBQ3ZGQTtvQkFDQUEsNERBQTREQTtvQkFDNURBLDBEQUEwREE7b0JBQzFEQSwrQ0FBK0NBLElBQUlBO29CQUNuREEsK0NBQStDQSxJQUFJQTtvQkFDbkRBLGdEQUFnREEsSUFBSUE7b0JBQ3BEQSxzREFBc0RBLElBQUlBO29CQUMxREEsdURBQXVEQTs7b0JBRXZEQSwwREFBMERBOzs7b0JBRzFEQSx5REFBeURBOztvQkFFekRBLCtDQUErQ0EsSUFBSUE7b0JBQ25EQSxnREFBZ0RBLElBQUlBO29CQUNwREEsc0RBQXNEQSxJQUFJQTtvQkFDMURBLHVEQUF1REE7O29CQUV2REEsMERBQTBEQTs7O29CQUcxREEseURBQXlEQTs7O29CQUd6REEsMkZBQTJGQTtvQkFDM0ZBO29CQUNBQSxnR0FBZ0dBO29CQUNoR0E7b0JBQ0FBLHFEQUFxREEsSUFBSUEsMkRBQThDQSxXQUFJQSwwQ0FBaUNBLGFBQWVBLGFBQWVBLGFBQWVBO29CQUN6TEEsdURBQXVEQSxJQUFJQTtvQkFDM0RBLDRDQUE0Q0EsSUFBSUE7b0JBQ2hEQSxxREFBcURBLElBQUlBO29CQUN6REEsd0RBQXdEQSxJQUFJQSxxREFBd0NBOztvQkFFcEdBLHFEQUFxREEsSUFBSUE7b0JBQ3pEQSx3REFBd0RBLElBQUlBLHFEQUF3Q0E7O29CQUVwR0EseURBQXlEQTtvQkFDekRBLHlEQUF5REE7O29CQUV6REEsc0ZBQXNGQTtvQkFDdEZBO29CQUNBQSxnREFBZ0RBO29CQUNoREEsc0RBQXNEQSxJQUFJQSwyREFBOENBLFdBQUlBLDBDQUFpQ0EsYUFBZUEsYUFBZUEsYUFBZUE7b0JBQzFMQSwwREFBMERBLElBQUlBO29CQUM5REEscURBQXFEQSxJQUFJQSwyREFBOENBLFdBQUlBLDBDQUFpQ0EsYUFBZUEsYUFBZUEsYUFBZUE7b0JBQ3pMQSw0Q0FBNENBLElBQUlBO29CQUNoREEsd0RBQXdEQSxJQUFJQTtvQkFDNURBLDBEQUEwREEsSUFBSUEscURBQXdDQTs7b0JBRXRHQSx3REFBd0RBLElBQUlBO29CQUM1REEsMERBQTBEQSxJQUFJQSxxREFBd0NBOztvQkFFdEdBLHdEQUF3REEsSUFBSUE7b0JBQzVEQSwwREFBMERBLElBQUlBLHFEQUF3Q0E7O29CQUV0R0Esd0RBQXdEQSxJQUFJQTtvQkFDNURBLDBEQUEwREEsSUFBSUEscURBQXdDQTs7b0JBRXRHQSx3REFBd0RBLElBQUlBO29CQUM1REEsMERBQTBEQSxJQUFJQSxxREFBd0NBOztvQkFFdEdBLHdEQUF3REEsSUFBSUE7b0JBQzVEQSwwREFBMERBLElBQUlBLHFEQUF3Q0E7O29CQUV0R0Esd0RBQXdEQSxJQUFJQTtvQkFDNURBLDBEQUEwREEsSUFBSUEscURBQXdDQTs7b0JBRXRHQSw0REFBNERBO29CQUM1REEsNERBQTREQTtvQkFDNURBLDREQUE0REE7b0JBQzVEQSw0REFBNERBO29CQUM1REEsNERBQTREQTtvQkFDNURBLDREQUE0REE7b0JBQzVEQSw0REFBNERBOztvQkFFNURBLDBGQUEwRkE7b0JBQzFGQTtvQkFDQUEsOERBQThEQTtvQkFDOURBLDREQUE0REE7b0JBQzVEQSxxRUFBcUVBO29CQUNyRUEsbUVBQW1FQTtvQkFDbkVBO29CQUNBQSxrREFBa0RBLElBQUlBO29CQUN0REEsNkNBQTZDQSxJQUFJQTtvQkFDakRBLCtDQUErQ0EsSUFBSUE7b0JBQ25EQSxnREFBZ0RBLElBQUlBOzs7O29CQUlwREEsa0RBQWtEQTs7b0JBRWxEQSwrQ0FBK0NBLElBQUlBO29CQUNuREEsZ0RBQWdEQSxJQUFJQTs7OztvQkFJcERBLHFGQUFxRkE7b0JBQ3JGQTtvQkFDQUEsc0RBQWdEQTtvQkFDaERBLHNFQUFzRUE7b0JBQ3RFQSxvRUFBb0VBO29CQUNwRUEseURBQXlEQSxJQUFJQTtvQkFDN0RBLCtDQUErQ0EsSUFBSUE7b0JBQ25EQSxnREFBZ0RBLElBQUlBO29CQUNwREEsc0RBQXNEQSxJQUFJQTtvQkFDMURBLHVEQUF1REE7O29CQUV2REEsMERBQTBEQTs7O29CQUcxREEseURBQXlEQTs7O29CQUd6REEsMEZBQTBGQTtvQkFDMUZBO29CQUNBQSw4REFBOERBO29CQUM5REEsNERBQTREQTtvQkFDNURBLHNEQUFnREE7b0JBQ2hEQSxxRUFBcUVBO29CQUNyRUEsbUVBQW1FQTtvQkFDbkVBO29CQUNBQSxrREFBa0RBLElBQUlBO29CQUN0REEsNkNBQTZDQSxJQUFJQTtvQkFDakRBLCtDQUErQ0EsSUFBSUE7b0JBQ25EQSxnREFBZ0RBLElBQUlBOzs7O29CQUlwREEsa0RBQWtEQTs7b0JBRWxEQSwrQ0FBK0NBLElBQUlBO29CQUNuREEsZ0RBQWdEQSxJQUFJQTs7OztvQkFJcERBLHlGQUF5RkE7b0JBQ3pGQTtvQkFDQUEsOERBQThEQTtvQkFDOURBLDREQUE0REE7b0JBQzVEQSxzREFBZ0RBO29CQUNoREEscUVBQXFFQTtvQkFDckVBLG1FQUFtRUE7b0JBQ25FQTtvQkFDQUEsa0RBQWtEQSxJQUFJQTtvQkFDdERBLGlEQUFpREE7b0JBQ2pEQSw2Q0FBNkNBLElBQUlBO29CQUNqREEsK0NBQStDQSxJQUFJQTtvQkFDbkRBLGdEQUFnREEsSUFBSUE7Ozs7b0JBSXBEQSxrREFBa0RBOztvQkFFbERBLCtDQUErQ0EsSUFBSUE7b0JBQ25EQSxnREFBZ0RBLElBQUlBOzs7O29CQUlwREEseUZBQXlGQTtvQkFDekZBO29CQUNBQSw4REFBOERBO29CQUM5REEsNERBQTREQTtvQkFDNURBLHNEQUFnREE7b0JBQ2hEQSxxRUFBcUVBO29CQUNyRUEsbUVBQW1FQTtvQkFDbkVBO29CQUNBQSxrREFBa0RBLElBQUlBO29CQUN0REEsaURBQWlEQTtvQkFDakRBLDZDQUE2Q0EsSUFBSUE7b0JBQ2pEQSwrQ0FBK0NBLElBQUlBO29CQUNuREEsZ0RBQWdEQSxJQUFJQTs7OztvQkFJcERBLGtEQUFrREE7O29CQUVsREEsK0NBQStDQSxJQUFJQTtvQkFDbkRBLGdEQUFnREEsSUFBSUE7Ozs7b0JBSXBEQSxnR0FBZ0dBO29CQUNoR0E7b0JBQ0FBLDhEQUE4REE7b0JBQzlEQSw0REFBNERBO29CQUM1REEsc0RBQWdEQTtvQkFDaERBLHFFQUFxRUE7b0JBQ3JFQSxtRUFBbUVBO29CQUNuRUE7b0JBQ0FBLGtEQUFrREEsSUFBSUE7b0JBQ3REQSxpREFBaURBO29CQUNqREEsNkNBQTZDQSxJQUFJQTtvQkFDakRBLCtDQUErQ0EsSUFBSUE7b0JBQ25EQSxnREFBZ0RBLElBQUlBOzs7O29CQUlwREEsa0RBQWtEQTs7b0JBRWxEQSwrQ0FBK0NBLElBQUlBO29CQUNuREEsZ0RBQWdEQSxJQUFJQTs7OztvQkFJcERBLDJGQUEyRkE7b0JBQzNGQTtvQkFDQUEsOERBQThEQTtvQkFDOURBLDREQUE0REE7b0JBQzVEQSxzREFBZ0RBO29CQUNoREEscUVBQXFFQTtvQkFDckVBLG1FQUFtRUE7b0JBQ25FQTtvQkFDQUEsa0RBQWtEQSxJQUFJQTtvQkFDdERBLGlEQUFpREE7b0JBQ2pEQSw2Q0FBNkNBLElBQUlBO29CQUNqREEsK0NBQStDQSxJQUFJQTtvQkFDbkRBLGdEQUFnREEsSUFBSUE7Ozs7b0JBSXBEQSxrREFBa0RBOztvQkFFbERBLCtDQUErQ0EsSUFBSUE7b0JBQ25EQSxnREFBZ0RBLElBQUlBOzs7O29CQUlwREEsbURBQW1EQTtvQkFDbkRBLG1EQUFtREE7b0JBQ25EQSxtREFBbURBO29CQUNuREEsbURBQW1EQTtvQkFDbkRBLG1EQUFtREE7b0JBQ25EQSxtREFBbURBO29CQUNuREEsbURBQW1EQTs7O29CQUduREEsZ0RBQWdEQTs7b0JBRWhEQSwrQ0FBK0NBLElBQUlBO29CQUNuREEsZ0RBQWdEQSxJQUFJQTs7OztvQkFJcERBLDhDQUE4Q0EsSUFBSUE7b0JBQ2xEQSxtREFBNkNBO29CQUM3Q0EsMERBQTBEQSxJQUFJQTtvQkFDOURBLG9HQUFvR0E7b0JBQ3BHQTtvQkFDQUE7b0JBQ0FBLCtDQUErQ0EsSUFBSUE7b0JBQ25EQSxnREFBZ0RBLElBQUlBO29CQUNwREEsc0RBQXNEQSxJQUFJQTtvQkFDMURBLHVEQUF1REE7O29CQUV2REEsMERBQTBEQTs7O29CQUcxREEseURBQXlEQTs7b0JBRXpEQSwrQ0FBK0NBLElBQUlBO29CQUNuREEsZ0RBQWdEQSxJQUFJQTtvQkFDcERBLHNEQUFzREEsSUFBSUE7b0JBQzFEQSx1REFBdURBOztvQkFFdkRBLDBEQUEwREE7OztvQkFHMURBLHlEQUF5REE7O29CQUV6REEsK0NBQStDQSxJQUFJQTtvQkFDbkRBLGdEQUFnREEsSUFBSUE7OztvQkFHcERBLCtDQUErQ0EsSUFBSUE7b0JBQ25EQSxnREFBZ0RBLElBQUlBOzs7b0JBR3BEQSwrQ0FBK0NBLElBQUlBO29CQUNuREEsZ0RBQWdEQSxJQUFJQTtvQkFDcERBLHNEQUFzREEsSUFBSUE7b0JBQzFEQSx1REFBdURBOztvQkFFdkRBLDBEQUEwREE7OztvQkFHMURBLHlEQUF5REE7O29CQUV6REEsK0NBQStDQSxJQUFJQTtvQkFDbkRBLGdEQUFnREEsSUFBSUE7b0JBQ3BEQSxzREFBc0RBLElBQUlBO29CQUMxREEsdURBQXVEQTs7b0JBRXZEQSwwREFBMERBOzs7b0JBRzFEQSx5REFBeURBOzs7b0JBR3pEQSxnREFBZ0RBOztvQkFFaERBLCtDQUErQ0EsSUFBSUE7b0JBQ25EQSxnREFBZ0RBLElBQUlBOzs7b0JBR3BEQSwrQ0FBK0NBLElBQUlBO29CQUNuREEsZ0RBQWdEQSxJQUFJQTs7O29CQUdwREEsK0NBQStDQSxJQUFJQTtvQkFDbkRBLGdEQUFnREEsSUFBSUE7b0JBQ3BEQSxzREFBc0RBLElBQUlBO29CQUMxREEsdURBQXVEQTs7b0JBRXZEQSwwREFBMERBOzs7b0JBRzFEQSx5REFBeURBOztvQkFFekRBLCtDQUErQ0EsSUFBSUE7b0JBQ25EQSxnREFBZ0RBLElBQUlBO29CQUNwREEsc0RBQXNEQSxJQUFJQTtvQkFDMURBLHVEQUF1REE7O29CQUV2REEsMERBQTBEQTs7O29CQUcxREEseURBQXlEQTs7O29CQUd6REEsbURBQW1EQTtvQkFDbkRBLG1EQUFtREE7OztvQkFHbkRBLGdEQUFnREE7O29CQUVoREEsK0NBQStDQSxJQUFJQTtvQkFDbkRBLGdEQUFnREEsSUFBSUE7b0JBQ3BEQSxzREFBc0RBLElBQUlBO29CQUMxREEsdURBQXVEQTs7b0JBRXZEQSwwREFBMERBOzs7b0JBRzFEQSx5REFBeURBOztvQkFFekRBLCtDQUErQ0EsSUFBSUE7b0JBQ25EQSxnREFBZ0RBLElBQUlBO29CQUNwREEsc0RBQXNEQSxJQUFJQTtvQkFDMURBLHVEQUF1REE7O29CQUV2REEsMERBQTBEQTs7O29CQUcxREEseURBQXlEQTs7O29CQUd6REEsZ0RBQWdEQTs7O29CQUdoREEsbURBQW1EQTtvQkFDbkRBLG1EQUFtREE7O29CQUVuREEsK0NBQStDQSxJQUFJQTtvQkFDbkRBLGdEQUFnREEsSUFBSUE7b0JBQ3BEQSxzREFBc0RBLElBQUlBO29CQUMxREEsdURBQXVEQTs7b0JBRXZEQSwwREFBMERBOzs7b0JBRzFEQSx5REFBeURBOztvQkFFekRBLCtDQUErQ0EsSUFBSUE7b0JBQ25EQSxnREFBZ0RBLElBQUlBO29CQUNwREEsc0RBQXNEQSxJQUFJQTtvQkFDMURBLHVEQUF1REE7O29CQUV2REEsMERBQTBEQTs7O29CQUcxREEseURBQXlEQTs7b0JBRXpEQSwrQ0FBK0NBLElBQUlBO29CQUNuREEsZ0RBQWdEQSxJQUFJQTtvQkFDcERBLHNEQUFzREEsSUFBSUE7b0JBQzFEQSx1REFBdURBOztvQkFFdkRBLDBEQUEwREE7OztvQkFHMURBLHlEQUF5REE7O29CQUV6REEsK0NBQStDQSxJQUFJQTtvQkFDbkRBLGdEQUFnREEsSUFBSUE7b0JBQ3BEQSxzREFBc0RBLElBQUlBO29CQUMxREEsdURBQXVEQTs7b0JBRXZEQSwwREFBMERBOzs7b0JBRzFEQSx5REFBeURBOzs7b0JBR3pEQSxnRUFBMERBLHVDQUF1Q0EsaUVBQTJEQTtvQkFDNUpBLGdFQUEwREEsdUNBQXVDQSx5REFBbURBO29CQUNwSkEsZ0VBQTBEQSx3Q0FBd0NBLDZEQUF1REE7b0JBQ3pKQSxnRUFBMERBLHlDQUF5Q0EsNERBQXNEQTtvQkFDekpBLGdFQUEwREEsaURBQWlEQSx1RUFBaUVBO29CQUM1S0EsZ0VBQTBEQSx3Q0FBd0NBLDZEQUF1REE7b0JBQ3pKQSxnRUFBMERBLHlDQUF5Q0EsNERBQXNEQTtvQkFDekpBLGdFQUEwREEsd0NBQXdDQSw2REFBdURBO29CQUN6SkEsZ0VBQTBEQSx5Q0FBeUNBLDREQUFzREE7b0JBQ3pKQSxnRUFBMERBLHdDQUF3Q0EsNkRBQXVEQTtvQkFDekpBLGdFQUEwREEseUNBQXlDQSw0REFBc0RBO29CQUN6SkEsZ0VBQTBEQSx3Q0FBd0NBLDZEQUF1REE7b0JBQ3pKQSxnRUFBMERBLHlDQUF5Q0EsNERBQXNEQTtvQkFDekpBLGdFQUEwREEsd0NBQXdDQSw2REFBdURBO29CQUN6SkEsZ0VBQTBEQSx5Q0FBeUNBLDREQUFzREE7b0JBQ3pKQSxnRUFBMERBLHlDQUF5Q0EsNERBQXNEQTtvQkFDekpBLGdFQUEwREEsbURBQW1EQSx1RUFBaUVBO29CQUM5S0EsZ0VBQTBEQSxtREFBbURBLCtFQUF5RUE7b0JBQ3RMQSxnRUFBMERBLG1EQUFtREEsOERBQXdEQTtvQkFDcktBLGdFQUEwREEsbURBQW1EQSwrREFBeURBO29CQUN0S0EsZ0VBQTBEQSxtREFBbURBLDRFQUFzRUE7b0JBQ25MQSxnRUFBMERBLG1EQUFtREEsMEVBQW9FQTtvQkFDakxBLGdFQUEwREEseUNBQXlDQSwrREFBeURBO29CQUM1SkEsZ0VBQTBEQSx5Q0FBeUNBLDhEQUF3REE7b0JBQzNKQSxnRUFBMERBLHlDQUF5Q0Esa0VBQTREQTtvQkFDL0pBLGdFQUEwREEseUNBQXlDQSxtRUFBNkRBO29CQUNoS0EsZ0VBQTBEQSx5Q0FBeUNBLHVFQUFpRUE7b0JBQ3BLQSxnRUFBMERBLHlDQUF5Q0EsbUVBQTZEQTtvQkFDaEtBLGdFQUEwREEsdUNBQXVDQSwrREFBeURBO29CQUMxSkEsZ0VBQTBEQSx1Q0FBdUNBLDhEQUF3REE7b0JBQ3pKQSxnRUFBMERBLHVDQUF1Q0EsNEVBQXNFQTtvQkFDdktBLGdFQUEwREEsdUNBQXVDQSwwRUFBb0VBOztvQkFFcktBLDJFQUFxRUEsZ0VBQ2pFQSxJQUFJQSw4RUFHQUEsNEZBQ0FBLHlGQUNBQSxrR0FDQUEsOEZBQ0FBO29CQUNSQSxtRUFBNkRBLGdFQUFnRUE7OztvQkFHN0hBLDJFQUFxRUEsZ0VBQ2pFQSxJQUFJQSwwRkFHQUEsNEZBQ0FBLHlGQUNBQSxrR0FDQUEsOEZBQ0FBO29CQUNSQSxtRUFBNkRBLGdFQUFnRUE7O29CQUU3SEEsb0VBQW9FQTtvQkFDcEVBLE9BQU9BOzs7Z0JBR1BBLGdEQUFnREE7OztnQkFHaERBLG1EQUFtREE7Z0JBQ25EQSxtREFBbURBO2dCQUNuREEsbURBQW1EQTtnQkFDbkRBLG1EQUFtREE7Z0JBQ25EQSxtREFBbURBOzs7Z0JBR25EQSw2Q0FBNkNBLElBQUlBO2dCQUNqREEsb0RBQW9EQSxBQUFPQTtnQkFDM0RBLDhDQUE4Q0EsSUFBSUE7Z0JBQ2xEQSxtREFBbURBO2dCQUNuREEsZ0RBQWdEQSxJQUFJQSwyREFBOENBLFVBQUlBLHlDQUFpQ0EsWUFBZUEsWUFBZUEsWUFBZUE7O2dCQUVwTEEsOENBQThDQSxJQUFJQTtnQkFDbERBLG1EQUFtREE7Z0JBQ25EQSxnREFBZ0RBLElBQUlBLDJEQUE4Q0EsVUFBSUEseUNBQWlDQSxZQUFlQSxVQUFhQSxVQUFhQTs7Z0JBRWhMQSw4Q0FBOENBLElBQUlBO2dCQUNsREEsbURBQW1EQTtnQkFDbkRBLGdEQUFnREEsSUFBSUE7O2dCQUVwREEsOENBQThDQSxJQUFJQTtnQkFDbERBLG1EQUFtREE7Z0JBQ25EQSxnREFBZ0RBLElBQUlBOztnQkFFcERBLDhDQUE4Q0EsSUFBSUE7Z0JBQ2xEQSxtREFBbURBO2dCQUNuREEsZ0RBQWdEQTs7Z0JBRWhEQSw4Q0FBOENBLElBQUlBO2dCQUNsREEsbURBQW1EQTtnQkFDbkRBLGdEQUFnREE7O2dCQUVoREEsOENBQThDQSxJQUFJQTtnQkFDbERBLG1EQUFtREE7Z0JBQ25EQSxnREFBZ0RBOztnQkFFaERBLDhDQUE4Q0EsSUFBSUE7Z0JBQ2xEQSxtREFBbURBO2dCQUNuREEsdURBQXVEQSxJQUFJQTtnQkFDM0RBLDhEQUE4REEsQUFBT0E7Z0JBQ3JFQSx5RkFBeUZBLEFBQWlGQTtvQkFFMUtBLHdEQUF3REEsSUFBSUE7b0JBQzVEQSxrRUFBa0VBO29CQUNsRUEsbURBQW1EQSxJQUFJQTtvQkFDdkRBLG1EQUFtREEsSUFBSUE7b0JBQ3ZEQSxtREFBbURBLElBQUlBO29CQUN2REEsbURBQW1EQSxJQUFJQTtvQkFDdkRBLHdEQUF3REEsSUFBSUE7b0JBQzVEQSx3REFBd0RBLElBQUlBO29CQUM1REEsOENBQThDQSxJQUFJQTtvQkFDbERBLDhDQUE4Q0EsSUFBSUE7b0JBQ2xEQSwyRkFBMkZBO29CQUMzRkE7b0JBQ0FBLDRGQUE0RkE7b0JBQzVGQTtvQkFDQUEsc0ZBQXNGQTtvQkFDdEZBOztvQkFFQUEsMkZBQTJGQTtvQkFDM0ZBO29CQUNBQSxrREFBa0RBLElBQUlBO29CQUN0REEscUVBQXFFQSxJQUFJQTtvQkFDekVBLHVFQUFpRUE7b0JBQ2pFQSw4REFBOERBLElBQUlBO29CQUNsRUEsa0VBQWtFQSxtRUFBNkRBLElBQUlBO29CQUNuSUE7O29CQUVBQSw2RUFBNkVBOzs7b0JBRzdFQSx5REFBeURBOzs7b0JBR3pEQSwwREFBMERBOzs7b0JBRzFEQSx1RkFBdUZBO29CQUN2RkE7b0JBQ0FBLGtEQUFrREEsSUFBSUE7b0JBQ3REQSxxRUFBcUVBLElBQUlBO29CQUN6RUEsdUVBQWlFQTtvQkFDakVBLDhEQUE4REEsSUFBSUE7b0JBQ2xFQSxrRUFBa0VBLG1FQUE2REEsSUFBSUE7b0JBQ25JQTs7b0JBRUFBLDZFQUE2RUE7OztvQkFHN0VBLHlEQUF5REE7OztvQkFHekRBLDBEQUEwREE7OztvQkFHMURBLHdGQUF3RkE7b0JBQ3hGQTtvQkFDQUEsa0RBQWtEQSxJQUFJQTtvQkFDdERBLHFFQUFxRUEsSUFBSUE7b0JBQ3pFQSx1RUFBaUVBO29CQUNqRUEsOERBQThEQSxJQUFJQTtvQkFDbEVBLGtFQUFrRUEsbUVBQTZEQSxJQUFJQTtvQkFDbklBOztvQkFFQUEsNkVBQTZFQTs7O29CQUc3RUEseURBQXlEQTs7O29CQUd6REEsMERBQTBEQTs7O29CQUcxREEsMkVBQTZEQTtvQkFDN0RBLDJFQUE2REE7b0JBQzdEQSwyRUFBNkRBO29CQUM3REEsMkVBQTZEQTs7O29CQUc3REEsbUdBQW1HQTs7b0JBRW5HQSwyRkFBMkZBO29CQUMzRkE7b0JBQ0FBLGdHQUFnR0E7b0JBQ2hHQTtvQkFDQUEsK0NBQStDQSxJQUFJQTtvQkFDbkRBLGdEQUFnREEsSUFBSUE7b0JBQ3BEQSxzREFBc0RBLElBQUlBO29CQUMxREEsdURBQXVEQTs7b0JBRXZEQSwwREFBMERBOzs7b0JBRzFEQSx5REFBeURBOztvQkFFekRBLCtDQUErQ0EsSUFBSUE7b0JBQ25EQSxnREFBZ0RBLElBQUlBO29CQUNwREEsc0RBQXNEQSxJQUFJQTtvQkFDMURBLHVEQUF1REE7O29CQUV2REEsMERBQTBEQTs7O29CQUcxREEseURBQXlEQTs7b0JBRXpEQSwrQ0FBK0NBLElBQUlBO29CQUNuREEsZ0RBQWdEQSxJQUFJQTtvQkFDcERBLHNEQUFzREEsSUFBSUE7b0JBQzFEQSx1REFBdURBOztvQkFFdkRBLDBEQUEwREE7OztvQkFHMURBLHlEQUF5REE7O29CQUV6REEsK0NBQStDQSxJQUFJQTtvQkFDbkRBLGdEQUFnREEsSUFBSUE7b0JBQ3BEQSxzREFBc0RBLElBQUlBO29CQUMxREEsdURBQXVEQTs7b0JBRXZEQSwwREFBMERBOzs7b0JBRzFEQSx5REFBeURBOztvQkFFekRBLCtDQUErQ0EsSUFBSUE7b0JBQ25EQSxnREFBZ0RBLElBQUlBO29CQUNwREEsc0RBQXNEQSxJQUFJQTtvQkFDMURBLHVEQUF1REE7O29CQUV2REEsMERBQTBEQTs7O29CQUcxREEseURBQXlEQTs7b0JBRXpEQSwrQ0FBK0NBLElBQUlBO29CQUNuREEsZ0RBQWdEQSxJQUFJQTtvQkFDcERBLHNEQUFzREEsSUFBSUE7b0JBQzFEQSx1REFBdURBOztvQkFFdkRBLDBEQUEwREE7OztvQkFHMURBLHlEQUF5REE7O29CQUV6REEsK0NBQStDQSxJQUFJQTtvQkFDbkRBLGdEQUFnREEsSUFBSUE7b0JBQ3BEQSxzREFBc0RBLElBQUlBO29CQUMxREEsdURBQXVEQTs7b0JBRXZEQSwwREFBMERBOzs7b0JBRzFEQSx5REFBeURBOztvQkFFekRBLCtDQUErQ0EsSUFBSUE7b0JBQ25EQSxnREFBZ0RBLElBQUlBOzs7O29CQUlwREEsZ0RBQWdEQTs7b0JBRWhEQSwrQ0FBK0NBLElBQUlBO29CQUNuREEsZ0RBQWdEQSxJQUFJQTtvQkFDcERBLHNEQUFzREEsSUFBSUE7b0JBQzFEQSx1REFBdURBOztvQkFFdkRBLDBEQUEwREE7OztvQkFHMURBLHlEQUF5REE7OztvQkFHekRBLGdEQUFnREE7O29CQUVoREEsK0NBQStDQSxJQUFJQTtvQkFDbkRBLGdEQUFnREEsSUFBSUE7b0JBQ3BEQSxzREFBc0RBLElBQUlBO29CQUMxREEsdURBQXVEQTs7b0JBRXZEQSwwREFBMERBOzs7b0JBRzFEQSx5REFBeURBOztvQkFFekRBLCtDQUErQ0EsSUFBSUE7b0JBQ25EQSxnREFBZ0RBLElBQUlBO29CQUNwREEsc0RBQXNEQSxJQUFJQTtvQkFDMURBLHVEQUF1REE7O29CQUV2REEsMERBQTBEQTs7O29CQUcxREEseURBQXlEQTs7b0JBRXpEQSwrQ0FBK0NBLElBQUlBO29CQUNuREEsZ0RBQWdEQSxJQUFJQTtvQkFDcERBLHNEQUFzREEsSUFBSUE7b0JBQzFEQSx1REFBdURBOztvQkFFdkRBLDBEQUEwREE7OztvQkFHMURBLHlEQUF5REE7O29CQUV6REEsK0NBQStDQSxJQUFJQTtvQkFDbkRBLGdEQUFnREEsSUFBSUE7b0JBQ3BEQSxzREFBc0RBLElBQUlBO29CQUMxREEsdURBQXVEQTs7b0JBRXZEQSwwREFBMERBOzs7b0JBRzFEQSx5REFBeURBOztvQkFFekRBLCtDQUErQ0EsSUFBSUE7b0JBQ25EQSxnREFBZ0RBLElBQUlBOzs7O29CQUlwREEsZ0VBQTBEQSxtREFBbURBLCtFQUF5RUE7b0JBQ3RMQSxnRUFBMERBLG1EQUFtREEsdUVBQWlFQTtvQkFDOUtBLGdFQUEwREEsbURBQW1EQSwrREFBeURBO29CQUN0S0EsZ0VBQTBEQSxtREFBbURBLDhEQUF3REE7b0JBQ3JLQSxnRUFBMERBLG1EQUFtREEsK0RBQXlEQTtvQkFDdEtBLGdFQUEwREEsbURBQW1EQSw0RUFBc0VBO29CQUNuTEEsZ0VBQTBEQSxtREFBbURBLDBFQUFvRUE7b0JBQ2pMQSxnRUFBMERBLG1EQUFtREEsNERBQXNEQTtvQkFDbktBLGdFQUEwREEseUNBQXlDQSxrRUFBNERBO29CQUMvSkEsZ0VBQTBEQSx5Q0FBeUNBLGtFQUE0REE7b0JBQy9KQSxnRUFBMERBLHlDQUF5Q0EsbUVBQTZEQTtvQkFDaEtBLGdFQUEwREEseUNBQXlDQSx1RUFBaUVBO29CQUNwS0EsZ0VBQTBEQSx5Q0FBeUNBLCtEQUF5REE7b0JBQzVKQSxnRUFBMERBLHlDQUF5Q0EsNERBQXNEQTs7b0JBRXpKQSwyRUFBcUVBLGdFQUNqRUEsSUFBSUEsOEVBR0FBLDRGQUNBQSx5RkFDQUEsa0dBQ0FBLDhGQUNBQTtvQkFDUkEsbUVBQTZEQSxnRUFBZ0VBOzs7b0JBRzdIQSwyRUFBcUVBLGdFQUNqRUEsSUFBSUEsOEVBR0FBLDRGQUNBQSx5RkFDQUEsa0dBQ0FBLDhGQUNBQTtvQkFDUkEsbUVBQTZEQSxnRUFBZ0VBOzs7b0JBRzdIQSwyRUFBcUVBLGdFQUNqRUEsSUFBSUEsOEVBR0FBLDRGQUNBQSx5RkFDQUEsa0dBQ0FBLDhGQUNBQTtvQkFDUkEsbUVBQTZEQSxnRUFBZ0VBOztvQkFFN0hBLG9FQUFvRUE7b0JBQ3BFQSxPQUFPQTs7O2dCQUdQQSxnREFBZ0RBOzs7Z0JBR2hEQSxtREFBbURBO2dCQUNuREEsbURBQW1EQTtnQkFDbkRBLG1EQUFtREE7Z0JBQ25EQSxtREFBbURBO2dCQUNuREEsbURBQW1EQTtnQkFDbkRBLG1EQUFtREE7Z0JBQ25EQSxtREFBbURBO2dCQUNuREEsbURBQW1EQTs7O2dCQUduREEsNEVBQXNFQTtnQkFDdEVBLDRFQUFzRUE7Z0JBQ3RFQSxtRkFBNkVBO2dCQUM3RUEsaUZBQTJFQTtnQkFDM0VBLGdGQUEwRUE7Z0JBQzFFQSxpRkFBMkVBO2dCQUMzRUEsb0ZBQThFQTtnQkFDOUVBLHNGQUFnRkE7Z0JBQ2hGQSx5RkFBbUZBO2dCQUNuRkEsbUZBQTZFQTtnQkFDN0VBLG9GQUE4RUE7Z0JBQzlFQSxvRkFBOEVBO2dCQUM5RUEsc0ZBQWdGQTtnQkFDaEZBLHVGQUFpRkE7Z0JBQ2pGQSwrRUFBeUVBO2dCQUN6RUEsK0VBQXlFQTtnQkFDekVBLDhFQUF3RUE7Z0JBQ3hFQSw4RUFBd0VBO2dCQUN4RUEsMkVBQXFFQTtnQkFDckVBLHFFQUErREE7Z0JBQy9EQSx1RUFBaUVBO2dCQUNqRUEsb0VBQThEQTtnQkFDOURBLHFFQUErREE7Z0JBQy9EQSx1RUFBaUVBO2dCQUNqRUEsb0VBQThEQTtnQkFDOURBLG9FQUE4REE7Z0JBQzlEQSxvRUFBOERBO2dCQUM5REEsOEVBQXdFQTtnQkFDeEVBLHlFQUFtRUE7Z0JBQ25FQSw0RUFBc0VBO2dCQUN0RUEsNEVBQXNFQTs7Z0JBRXRFQSxpQkFBaUJBOzs7Ozs7Ozs7a0ZBWW1OQTs7Ozs7Ozs7Ozs7O3dDQUdwT0E7Ozs7Ozs7Ozs7Ozs7OzsrRUFJcUVBLHFCQUE4REE7O2dCQUduSUEsOEJBQThDQTtnQkFDOUNBLDRCQUE0Q0E7Z0JBQzVDQSxvQkFBb0RBO2dCQUNwREEsZUFBc0RBLFlBQTRDQSw2Q0FBdUJBOztnQkFFdkhBLENBQUNBLHlDQUF5Q0EsVUFBVUE7O3dGQUl3QkEscUJBQThEQTs7Z0JBRzVJQSw4QkFBOENBO2dCQUM5Q0EsNEJBQTRDQTtnQkFDNUNBLG9CQUFvREE7Z0JBQ3BEQSxlQUFzREEsWUFBNENBLDZDQUF1QkE7O2dCQUV2SEEsQ0FBQ0EsdUNBQXVDQSxVQUFVQTs7b0ZBSXNCQSxxQkFBOERBOztnQkFHeElBLDhCQUE4Q0E7Z0JBQzlDQSw0QkFBNENBO2dCQUM1Q0Esb0JBQW9EQTtnQkFDcERBLGVBQXNEQSxZQUE0Q0EsNkNBQXVCQTs7Z0JBRXZIQSxDQUFDQSxxQ0FBcUNBLFVBQVVBOzsrRUFJb0NBOztnQkFHdEZBLDhCQUE4Q0E7Z0JBQzlDQSw0QkFBNENBO2dCQUM1Q0Esb0JBQW9EQTtnQkFDcERBLGVBQXNEQSxZQUE0Q0EsNkNBQXVCQTs7Z0JBRXZIQSxPQUFPQSx3Q0FBd0NBOztrRkFJbUxBOzs7Ozs7Ozs7Ozs7d0NBR3BPQTs7Ozs7Ozs7Ozs7Ozs7OytFQUlxRUEscUJBQThEQTs7Z0JBR25JQSw4QkFBOENBO2dCQUM5Q0EsNEJBQTRDQTtnQkFDNUNBLG9CQUFvREE7Z0JBQ3BEQSxlQUFzREEsWUFBNENBLDZDQUF1QkE7O2dCQUV2SEEsQ0FBQ0EseUNBQXlDQSxVQUFVQTs7d0ZBSXdCQSxxQkFBOERBOztnQkFHNUlBLDhCQUE4Q0E7Z0JBQzlDQSw0QkFBNENBO2dCQUM1Q0Esb0JBQW9EQTtnQkFDcERBLGVBQXNEQSxZQUE0Q0EsNkNBQXVCQTs7Z0JBRXZIQSxDQUFDQSx1Q0FBdUNBLFVBQVVBOztvRkFJc0JBLHFCQUE4REE7O2dCQUd4SUEsOEJBQThDQTtnQkFDOUNBLDRCQUE0Q0E7Z0JBQzVDQSxvQkFBb0RBO2dCQUNwREEsZUFBc0RBLFlBQTRDQSw2Q0FBdUJBOztnQkFFdkhBLENBQUNBLHFDQUFxQ0EsVUFBVUE7OytFQUlvQ0E7O2dCQUd0RkEsOEJBQThDQTtnQkFDOUNBLDRCQUE0Q0E7Z0JBQzVDQSxvQkFBb0RBO2dCQUNwREEsZUFBc0RBLFlBQTRDQSw2Q0FBdUJBOztnQkFFdkhBLE9BQU9BLHdDQUF3Q0E7O2tGQUltTEE7Ozs7Ozs7Ozs7Ozt3Q0FHcE9BOzs7Ozs7Ozs7Ozs7Ozs7K0VBSXFFQSxxQkFBOERBOztnQkFHbklBLDhCQUE4Q0E7Z0JBQzlDQSw0QkFBNENBO2dCQUM1Q0Esb0JBQW9EQTtnQkFDcERBLGVBQXNEQSxZQUE0Q0EsNkNBQXVCQTs7Z0JBRXZIQSxDQUFDQSx5Q0FBeUNBLFVBQVVBOzt3RkFJd0JBLHFCQUE4REE7O2dCQUc1SUEsOEJBQThDQTtnQkFDOUNBLDRCQUE0Q0E7Z0JBQzVDQSxvQkFBb0RBO2dCQUNwREEsZUFBc0RBLFlBQTRDQSw2Q0FBdUJBOztnQkFFdkhBLENBQUNBLHVDQUF1Q0EsVUFBVUE7O29GQUlzQkEscUJBQThEQTs7Z0JBR3hJQSw4QkFBOENBO2dCQUM5Q0EsNEJBQTRDQTtnQkFDNUNBLG9CQUFvREE7Z0JBQ3BEQSxlQUFzREEsWUFBNENBLDZDQUF1QkE7O2dCQUV2SEEsQ0FBQ0EscUNBQXFDQSxVQUFVQTs7K0VBSW9DQTs7Z0JBR3RGQSw4QkFBOENBO2dCQUM5Q0EsNEJBQTRDQTtnQkFDNUNBLG9CQUFvREE7Z0JBQ3BEQSxlQUFzREEsWUFBNENBLDZDQUF1QkE7O2dCQUV2SEEsT0FBT0Esd0NBQXdDQTs7a0ZBSW1MQTs7Ozs7Ozs7Ozs7O3dDQUdwT0E7Ozs7Ozs7Ozs7Ozs7OzsrRUFJcUVBLHFCQUE4REE7O2dCQUduSUEsOEJBQThDQTtnQkFDOUNBLDRCQUE0Q0E7Z0JBQzVDQSxvQkFBb0RBO2dCQUNwREEsZUFBc0RBLFlBQTRDQSw2Q0FBdUJBOztnQkFFdkhBLENBQUNBLHlDQUF5Q0EsVUFBVUE7O3dGQUl3QkEscUJBQThEQTs7Z0JBRzVJQSw4QkFBOENBO2dCQUM5Q0EsNEJBQTRDQTtnQkFDNUNBLG9CQUFvREE7Z0JBQ3BEQSxlQUFzREEsWUFBNENBLDZDQUF1QkE7O2dCQUV2SEEsQ0FBQ0EsdUNBQXVDQSxVQUFVQTs7b0ZBSXNCQSxxQkFBOERBOztnQkFHeElBLDhCQUE4Q0E7Z0JBQzlDQSw0QkFBNENBO2dCQUM1Q0Esb0JBQW9EQTtnQkFDcERBLGVBQXNEQSxZQUE0Q0EsNkNBQXVCQTs7Z0JBRXZIQSxDQUFDQSxxQ0FBcUNBLFVBQVVBOzsrRUFJb0NBOztnQkFHdEZBLDhCQUE4Q0E7Z0JBQzlDQSw0QkFBNENBO2dCQUM1Q0Esb0JBQW9EQTtnQkFDcERBLGVBQXNEQSxZQUE0Q0EsNkNBQXVCQTs7Z0JBRXZIQSxPQUFPQSx3Q0FBd0NBOztrRkFJbUxBOzs7Ozs7Ozs7Ozs7d0NBR3BPQTs7Ozs7Ozs7Ozs7Ozs7OytFQUlxRUEscUJBQThEQTs7Z0JBR25JQSw4QkFBOENBO2dCQUM5Q0EsNEJBQTRDQTtnQkFDNUNBLG9CQUFvREE7Z0JBQ3BEQSxlQUFzREEsWUFBNENBLDZDQUF1QkE7O2dCQUV2SEEsQ0FBQ0EseUNBQXlDQSxVQUFVQTs7d0ZBSXdCQSxxQkFBOERBOztnQkFHNUlBLDhCQUE4Q0E7Z0JBQzlDQSw0QkFBNENBO2dCQUM1Q0Esb0JBQW9EQTtnQkFDcERBLGVBQXNEQSxZQUE0Q0EsNkNBQXVCQTs7Z0JBRXZIQSxDQUFDQSx1Q0FBdUNBLFVBQVVBOztvRkFJc0JBLHFCQUE4REE7O2dCQUd4SUEsOEJBQThDQTtnQkFDOUNBLDRCQUE0Q0E7Z0JBQzVDQSxvQkFBb0RBO2dCQUNwREEsZUFBc0RBLFlBQTRDQSw2Q0FBdUJBOztnQkFFdkhBLENBQUNBLHFDQUFxQ0EsVUFBVUE7OytFQUlvQ0E7O2dCQUd0RkEsOEJBQThDQTtnQkFDOUNBLDRCQUE0Q0E7Z0JBQzVDQSxvQkFBb0RBO2dCQUNwREEsZUFBc0RBLFlBQTRDQSw2Q0FBdUJBOztnQkFFdkhBLE9BQU9BLHdDQUF3Q0E7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O29CRzF3Q1pBLE9BQU9BOzs7OztvQkFFSEEsT0FBT0E7Ozs7OztrQ0FIUUEsSUFBSUE7c0NBRVBBLElBQUlBOzs7Ozs7Ozs7Z0JBU3pEQTs7Ozs7Z0JBR0FBO2dCQUNBQSxrQkFBa0JBLHFDQUFNQTtnQkFDeEJBLDJCQUEyQkEscUNBQU1BO2dCQUNqQ0EsSUFBSUEsZ0JBQWVBO29CQUF1QkEsUUFBU0E7O2dCQUErQkE7OztnQkFHbEZBLGtCQUFrQkEscUNBQU1BO2dCQUN4QkEsMkJBQTJCQSxxQ0FBTUE7Z0JBQ2pDQSxJQUFJQSxnQkFBZUE7b0JBQXVCQSxRQUFTQTs7Z0JBQStCQTs7O2dCQUdsRkEsYUFBY0EscUNBQU9BO2dCQUNyQkEsSUFBSUE7b0JBQ0pBOzs7O2dCQUlBQSx3Q0FBeUVBLEFBQXFCQTtnQkFDOUZBO2dCQUNBQSwwRUFBb0RBO2dCQUNwREEsa0VBQTRDQTtnQkFDNUNBLGVBQWtCQTtnQkFDbEJBLHFFQUErQ0E7Z0JBQy9DQTtnQkFDQUEsV0FBaUNBO2dCQUNqQ0EsYUFBYUEsa0NBQXFCQTtnQkFDbENBLElBQUlBLE1BQUtBO29CQUNUQSxhQUFhQSxZQUFRQTs7Z0JBRXJCQSxxQkFBd0JBLGtDQUFxQkE7Z0JBQzdDQSxJQUFJQSxNQUFLQTtvQkFDVEEsaUJBQWlCQSxZQUFRQTs7Z0JBRXpCQSxpQkFBb0JBLGtDQUFxQkE7Z0JBQ3pDQSxJQUFJQSxRQUFRQSxjQUFjQSxNQUFLQTtvQkFDL0JBLGFBQWFBLFlBQVFBO29CQUNyQkEsSUFBSUEsUUFBUUEsY0FBY0EsTUFBS0E7d0JBQW1CQTs7O2dCQUVsREEsb0VBQThDQTtnQkFDOUNBLGlCQUFvQkEsa0NBQXFCQTtnQkFDekNBLElBQUlBLFFBQVFBLGNBQWNBLE1BQUtBO29CQUMvQkEsYUFBYUEsWUFBUUE7b0JBQ3JCQSxJQUFJQSxRQUFRQSxjQUFjQSxNQUFLQTt3QkFBbUJBOzs7Z0JBRWxEQSxvRUFBOENBO2dCQUM5Q0EsbUJBQXNCQSxrQ0FBcUJBO2dCQUMzQ0EsSUFBSUEsUUFBUUEsZ0JBQWdCQSxNQUFLQTtvQkFDakNBLGVBQWVBLFlBQVFBO29CQUN2QkEsSUFBSUEsUUFBUUEsZ0JBQWdCQSxNQUFLQTt3QkFBcUJBOzs7Z0JBRXREQSxzRUFBZ0RBO2dCQUNoREEsV0FBY0Esa0NBQXFCQTtnQkFDbkNBLElBQUlBLE1BQUtBO29CQUNUQSxPQUFPQSxZQUFRQTs7Z0JBRWZBLGFBQWdCQSxrQ0FBcUJBO2dCQUNyQ0EsSUFBSUEsTUFBS0E7b0JBQ1RBLFNBQVNBLFlBQVFBOztnQkFFakJBLFdBQWNBLGtDQUFxQkE7Z0JBQ25DQSxJQUFJQSxNQUFLQTtvQkFDVEEsT0FBT0EsWUFBUUE7O2dCQUVmQSxJQUFJQSxRQUFRQTtvQkFBV0E7O2dCQUN2QkEsU0FBU0E7Z0JBQ1RBLElBQUlBLDJCQUFNQTtvQkFBVUE7O2dCQUNwQkEsSUFBSUE7b0JBQTRCQTs7Z0JBQ2hDQSxJQUFJQSxRQUFRQTtvQkFBY0E7O2dCQUMxQkEsYUFBYUE7Z0JBQ2JBLElBQUlBLFFBQVFBO29CQUFrQkE7O2dCQUM5QkEsaUJBQWlCQTtnQkFDakJBLElBQUlBLDJCQUFNQTtvQkFBa0JBOztnQkFDNUJBLElBQUlBLDJCQUFNQTtvQkFDVkEsSUFBSUEsK0JBQVVBO3dCQUFzQ0EsYUFBYUE7O3dCQUM1REE7OztnQkFFTEEsY0FBaUJBLGtDQUFxQkE7Z0JBQ3RDQSxJQUFJQSxNQUFLQTtvQkFBZ0JBLFVBQVVBLFlBQVFBOztnQkFDM0NBLElBQUlBLFFBQVFBO29CQUFTQSxVQUFVQTs7Z0JBQy9CQSxJQUFJQSwyQkFBTUE7b0JBQVNBLFVBQVVBOztnQkFDN0JBLGlFQUEyQ0E7Z0JBQzNDQSxJQUFJQSxpQ0FBWUE7b0JBQ2hCQSxJQUFJQSxRQUFRQTt3QkFBUUE7O29CQUNwQkEsVUFBYUEsWUFBU0E7b0JBQ3RCQSxJQUFJQSxNQUFLQTt3QkFDVEE7d0JBQ0FBLEtBQUlBLFdBQVNBLElBQUlBLFlBQVlBOzRCQUM3QkEsSUFBSUEsT0FBT0EsZUFBSUE7Z0NBQ2ZBLElBQUlBLE9BQU9BLGVBQUlBLE1BQU1BLE9BQU9BLGVBQUlBLE1BQU1BLE9BQU9BLGVBQUlBLE1BQU1BLE9BQU9BLGVBQUlBLE1BQU1BLE9BQU9BLGVBQUlBLE1BQU1BLE9BQU9BLGVBQUlBLE1BQU1BLE9BQU9BLGVBQUlBLE1BQU1BLE9BQU9BLGVBQUlBLE1BQU1BLE9BQU9BLGVBQUlBLE1BQU1BLE9BQU9BLGVBQUlBO29DQUN4S0Esb0NBQUtBLGVBQUlBOztvQ0FFSkE7Ozs7d0JBR0xBLElBQUlBLE1BQUtBOzRCQUFVQSxPQUFPQTs7O29CQUUxQkEsSUFBSUEsMkJBQU1BO3dCQUFRQSxPQUFPQTs7b0JBQ3pCQSxtQ0FBY0EsUUFBTUEscUJBQWFBOztvQkFFakNBLElBQUlBLE1BQUtBO3dCQUNUQSxzQkFBaUJBLGtDQUFxQkE7d0JBQ3RDQSxJQUFJQSx1QkFBa0JBLFFBQVFBLE1BQUtBOzRCQUF1QkEsc0JBQWlCQSxZQUFRQTs7d0JBQ25GQSxJQUFJQSx1QkFBa0JBLFFBQVFBLE1BQUtBOzRCQUF1QkEsbUNBQWNBLFFBQU1BOzs7b0JBRTlFQSxtQ0FBY0EsUUFBTUE7b0JBQ3BCQSxJQUFJQSxNQUFLQTt3QkFBZUE7OztnQkFFeEJBLHVCQUEwQkEsa0NBQXFCQTtnQkFDL0NBLElBQUlBLFFBQVFBLG9CQUFvQkEsTUFBS0E7b0JBQ3JDQSxtQkFBbUJBLFlBQVFBO29CQUMzQkEsSUFBSUEsUUFBUUEsb0JBQW9CQSxNQUFLQTt3QkFBeUJBOzs7Z0JBRTlEQSwwRUFBb0RBO2dCQUNwREEsSUFBSUE7b0JBQXlCQSxhQUFhQSxZQUFXQTs7b0JBQ2hEQSxhQUFhQSxXQUFVQTs7Z0JBQzVCQSxtQkFBMkJBLHFGQUEyREE7Z0JBQ3RGQSxnQkFBcUJBLCtFQUFxREE7Z0JBRTFFQSxVQUFhQSxJQUFJQTtnQkFDakJBLFdBQWNBO2dCQUNkQSxpQkFBWUEsSUFBSUEsd0NBQXdDQSxpQ0FBd0JBO2dCQUNoRkEsdUJBQWtCQSxJQUFJQSx3Q0FBd0NBLGlDQUF3QkE7Z0JBQ3RGQSxtRUFBNkNBO2dCQUM3Q0EseUVBQW1EQTtnQkFDbkRBO2dCQUNBQTtnQkFDQUEsNEJBQXNCQSwrQkFBT0EsR0FBR0E7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7d0NBQ2hDQSxJQUFJQTs7Ozs7Ozs7d0NBQ0pBO3dDQUNBQTt3Q0FDQUEsU0FBTUE7Ozs7Ozs7Ozs7d0NBQ05BOzs7Ozt3Q0FFQUEsT0FBZ0JBLEFBQVVBLHdCQUFTQSxRQUFRQTt3Q0FDM0NBLEtBQUtBLFlBQVdBLEtBQUlBLGFBQWFBOzRDQUNqQ0EsS0FBa0JBLGlDQUFvQkEsd0JBQUtBLElBQUxBOzRDQUN0Q0EsUUFBZUE7NENBQ2ZBLElBQUlBO2dEQUNKQSxvQkFBZUEsd0JBQUtBLElBQUxBO21EQUNSQSxJQUFJQTtnREFDWEEsb0JBQWVBLHdCQUFLQSxJQUFMQTttREFDUkEsSUFBSUE7Z0RBQ1hBLG9CQUFlQSx3QkFBS0EsSUFBTEE7bURBQ1JBLElBQUlBO2dEQUNYQSwrREFBeUNBO2dEQUN6Q0E7Z0RBQ0FBO2dEQUNBQTtnREFDQUEsa0VBQTRDQTtnREFDNUNBO2dEQUNBQSxpQkFBWUEsV0FBVUE7Z0RBQ3RCQTtnREFDQUE7Z0RBQ0FBO2dEQUNBQTtnREFDQUE7Z0RBQ0FBO2dEQUNBQTtnREFDQUEsV0FBd0JBLEFBQWlEQSxVQUFDQTtvREFBT0E7b0RBQWtCQTtvREFBdUJBO29EQUFpQkE7b0RBQXVCQTtvREFBd0JBO29EQUFpQ0E7b0RBQXVCQTtvREFBcUJBO29EQUFxQkE7b0RBQXdCQTtvREFBMkJBO29EQUFtQkE7b0RBQXNCQTtvREFBbUJBO29EQUFtQkE7b0RBQTBCQTtvREFBeUJBO29EQUFvQkE7b0RBQThCQTtvREFBbUJBO29EQUF1QkE7b0RBQXVCQTtvREFBaUJBO29EQUEyQkE7b0RBQW9CQTtvREFBbUJBO29EQUFxQkE7b0RBQTJCQTtvREFBcUJBO29EQUF5QkE7b0RBQWtCQTtvREFBa0JBO29EQUF5QkE7b0RBQThCQTtvREFBdUJBO29EQUFvQkE7b0RBQWdDQTtvREFBa0JBO29EQUFrQkE7b0RBQW9CQTtvREFBb0JBO29EQUFnQkE7b0RBQW9CQTtvREFBcUJBO29EQUFvQkE7b0RBQXdCQTtvREFBMkJBO29EQUFrQkE7b0RBQTJCQTtvREFBd0JBO29EQUFtQkEsT0FBT0E7a0RBQWhwQ0EsS0FBSUE7Z0RBQzFEQTtnREFDQUE7Z0RBQ0FBO2dEQUNBQSxJQUF3QkEsS0FBSUE7Z0RBQzVCQSxLQUFLQSxXQUFVQSxRQUFNQTtvREFDckJBLE1BQU1BLEtBQUlBO29EQUNWQSxVQUFFQSxPQUFPQSxJQUFJQSw0QkFBUUEsaUJBQVNBO29EQUM5QkEsVUFBRUEsT0FBT0EsSUFBSUE7b0RBQ2JBLFVBQUVBLE9BQU9BLElBQUlBO29EQUNiQSxVQUFFQSxPQUFPQSxJQUFJQTtvREFDYkEsVUFBRUEsT0FBT0EsSUFBSUE7b0RBQ2JBLFVBQUVBLE9BQU9BLElBQUlBO29EQUNiQSxVQUFFQSxPQUFPQSxJQUFJQTtvREFDYkEsVUFBRUEsT0FBT0EsSUFBSUE7O2dEQUViQSxxQkFBcUJBO2dEQUNyQkEsdUJBQXdCQSxBQUFpREEsVUFBQ0E7b0RBQU9BO29EQUFrQkE7b0RBQWtDQTtvREFBd0RBO29EQUF1REE7b0RBQTJDQTtvREFBdUVBO29EQUErRUE7b0RBQXFHQTtvREFBcUdBO29EQUFpQ0E7b0RBQW9DQTtvREFBd0VBO29EQUE4SEE7b0RBQW1DQTtvREFBd0VBO29EQUFrRUE7b0RBQWtDQTtvREFBdUNBO29EQUFpRUE7b0RBQThCQTtvREFBc0ZBO29EQUFtREE7b0RBQTJGQTtvREFBMERBO29EQUE2RkE7b0RBQWtEQTtvREFBd0RBO29EQUF5RUE7b0RBQXdEQTtvREFBd0RBO29EQUFtR0E7b0RBQTZCQTtvREFBMENBO29EQUF1Q0E7b0RBQXNEQTtvREFBNkJBO29EQUE2Q0E7b0RBQTZCQTtvREFBeUVBO29EQUF1RkE7b0RBQWtGQTtvREFBeUJBO29EQUFvRkE7b0RBQThCQTtvREFBK0VBO29EQUFpQ0E7b0RBQW9DQTtvREFBK0NBO29EQUE0Q0E7b0RBQXNGQTtvREFBd0NBLE9BQU9BO2tEQUF0NkZBLEtBQUlBO2dEQUMxREE7Z0RBQ0FBO2dEQUNBQSxVQUFVQSxJQUFJQTtnREFDZEE7Z0RBQ0FBO2dEQUNBQSxJQUFJQSxtQ0FBc0JBO2dEQUMxQkEsb0JBQWVBO2dEQUNmQSxPQUFXQTtnREFDWEEsQUFBNENBO21EQUNyQ0EsSUFBSUE7Z0RBQ1hBO2dEQUNBQTtnREFDQUEsVUFBVUE7Z0RBQ1ZBLElBQUlBLGlEQUEwQkEsZ0RBQXlCQSx5REFBa0NBLGlEQUEwQkEsK0NBQXdCQSwrQ0FBd0JBLHlEQUFrQ0Esd0RBQWlDQSxtREFBNEJBO29EQUNsUUEsK0JBQVlBOztnREFFWkEsS0FBWUE7Z0RBQ1pBLElBQVdBLDZDQUFnQ0EsSUFBSUEsYUFBYUE7Z0RBQzVEQSxVQUFVQSxJQUFJQTtnREFDZEEsZ0JBQWdCQTtnREFDaEJBLElBQUlBLG1DQUFzQkE7Z0RBQzFCQSxvQkFBZUE7bURBQ1JBLElBQUlBO2dEQUNYQSxtQkFBY0E7bURBQ1BBLElBQUlBO2dEQUNYQTtnREFDQUEsVUFBVUE7Z0RBQ1ZBLElBQUlBLGlEQUEwQkEsZ0RBQXlCQSx5REFBa0NBLGlEQUEwQkEsK0NBQXdCQSwrQ0FBd0JBLHlEQUFrQ0Esd0RBQWlDQSxtREFBNEJBO29EQUNsUUEsK0JBQVlBOztnREFFWkEsV0FBb0JBLDRDQUErQkE7Z0RBQ25EQSxPQUFZQSwwQkFBaUJBLGtCQUFzQkE7Z0RBQ25EQSxLQUFTQSxzQkFBeUJBLE9BQUtBO2dEQUN2Q0EsTUFBWUEsZ0NBQW1CQTtnREFDL0JBLE1BQVVBLDhDQUErQkEsS0FBSUEsYUFBY0E7Z0RBQzNEQSxVQUFVQSxJQUFJQTtnREFDZEEsZ0JBQWdCQTtnREFDaEJBLElBQUVBLG1DQUFzQkE7Z0RBQ3hCQSxvQkFBZUE7Z0RBQ2ZBLDBCQUFxQkE7bURBQ2RBLElBQUlBO2dEQUNYQSxJQUFJQSxpREFBMEJBLGdEQUF5QkEseURBQWtDQSxpREFBMEJBLCtDQUF3QkEsK0NBQXdCQSx5REFBa0NBLHdEQUFpQ0EsbURBQTRCQTtvREFDbFFBLCtCQUFZQTs7Z0RBQ1pBLFlBQW9CQSw0Q0FBK0JBO2dEQUNuREEsTUFBWUEsZ0NBQW1CQTtnREFDL0JBLE9BQVVBLDhDQUErQkEsS0FBSUEsYUFBYUE7Z0RBQzFEQSxNQUFXQSwwQkFBaUJBLGtCQUFzQkE7Z0RBQ2xEQSxTQUFvQkE7Z0RBQ3BCQSxJQUFJQSxVQUFVQTtvREFDZEEsYUFBZ0JBLG1CQUFlQTtvREFDL0JBLGdDQUFjQSxhQUFDQSxZQUFnQkEsMkRBQWdCQTs7Z0RBQy9DQSxVQUFVQSxJQUFJQTtnREFDZEEsZ0JBQWdCQTtnREFDaEJBLElBQUlBLG1DQUFzQkE7Z0RBQzFCQSxvQkFBZUE7Z0RBQ2ZBLDBCQUFxQkE7bURBQ2RBLElBQUlBO2dEQUNYQSxJQUFJQSxpREFBMEJBLGdEQUF5QkEseURBQWtDQSxpREFBMEJBLCtDQUF3QkEsK0NBQXdCQSx5REFBa0NBLHdEQUFpQ0EsbURBQTRCQTtvREFDbFFBLCtCQUFZQTs7Z0RBRVpBLFlBQW9CQSw0Q0FBOEJBO2dEQUNsREEsTUFBWUEsZ0NBQW1CQTtnREFDL0JBLE9BQVVBLDhDQUErQkEsS0FBSUEsYUFBWUE7Z0RBQ3pEQSxPQUFXQSwwQkFBaUJBLGtCQUFzQkE7Z0RBQ2xEQSxVQUFvQkE7Z0RBQ3BCQSxJQUFJQSxXQUFVQTtvREFDZEEsY0FBZ0JBLG1CQUFlQTtvREFDL0JBLGlDQUFjQSxhQUFDQSxZQUFpQkEsMkRBQWdCQTs7Z0RBRWhEQSxJQUFJQSxNQUFHQTtvREFDUEE7b0RBQ0FBLFVBQVVBO29EQUNWQSxTQUFjQSwwQkFBaUJBLGtCQUFzQkE7b0RBQ3JEQSxXQUFxQkE7b0RBQ3JCQSxjQUFnQkEsbUJBQWVBO29EQUMvQkEsa0NBQWVBLGdDQUFLQTs7Z0RBRXBCQSxVQUFVQSxJQUFJQTtnREFDZEEsZ0JBQWdCQTtnREFDaEJBLElBQUVBLG1DQUFzQkE7Z0RBQ3hCQSxvQkFBZUE7Z0RBQ2ZBLDBCQUFxQkE7bURBQ2RBLElBQUlBO3dDQUVYQSxXQUFXQSxnQ0FBbUJBO2dEQUM5QkEsSUFBSUEsUUFBUUE7b0RBQ1pBLE9BQWFBLDhDQUErQkEsVUFBVUEsYUFBYUE7b0RBQ25FQSxjQUFnQkEsbUJBQWVBLElBQUlBO29EQUNuQ0EsWUFBb0JBLG9DQUF1QkE7b0RBQzNDQSxRQUFZQSwwQkFBaUJBO29EQUM3QkEsVUFBb0JBLDRDQUFlQSxRQUFPQTtvREFDMUNBLElBQUlBLDRCQUFlQTt3REFDbkJBLFdBQVdBLFlBQVFBLGlDQUFjQSxrQkFBTUE7O3dEQUV2Q0EsV0FBV0EsWUFBUUEsaUNBQWNBLGdDQUFLQTs7O29EQUd0Q0E7O2dEQUVBQSxVQUFVQSxJQUFJQTtnREFDZEE7Z0RBQ0FBLGVBQWVBO2dEQUNmQSxnQkFBZ0JBO2dEQUNoQkEsSUFBSUEsbUNBQXNCQTtnREFDMUJBLDBCQUFxQkE7O2dEQUNkQSxvQkFBZUE7Ozs7Ozs7Ozs7Ozs7O2dCQUV0QkEsMEJBQW1CQSxVQUFDQSxHQUFFQTtvQkFBSUEsc0JBQW9CQSxjQUFhQTs7Z0JBQzNEQSwwQkFBbUJBLFVBQUNBLEdBQUVBO29CQUFJQTs7Z0JBQzFCQSx5QkFBa0JBLCtCQUFDQSxHQUFFQTtvQkFDckJBLFVBQVVBLElBQUlBO29CQUNkQTtvQkFDQUEsZUFBZUEsWUFBU0E7b0JBQ3hCQSxJQUFJQSxtQ0FBc0JBO29CQUMxQkEsb0JBQWVBOztnQkFFZkEsK0JBQTBCQSwrQkFBT0EsR0FBR0E7Ozs7Ozs7Ozs7O3dDQUVwQ0EsVUFBVUEsSUFBSUE7d0NBQ2RBLFNBQU1BOzs7Ozs7Ozs7O3dDQUNOQSxlQUFlQSxZQUFTQTt3Q0FDeEJBO3dDQUNBQSxLQUFZQSxtQ0FBc0JBO3dDQUNsQ0EsMEJBQXFCQTs7Ozs7Ozs7Ozs7O2dCQUVyQkEsa0NBQTZCQSwrQkFBQ0EsR0FBR0E7b0JBQ2pDQSxTQUFvQkEsaUNBQW9CQTtvQkFDeENBLFlBQWVBO29CQUNmQSxJQUFJQTt3QkFDSkEsMEJBQXFCQTsyQkFDZEEsSUFBSUE7d0JBQ1hBO3dCQUNBQSxXQUFXQSxnQ0FBbUJBO3dCQUM5QkEsSUFBSUEsUUFBUUE7NEJBQ1pBLFVBQWFBLDhDQUErQkEsVUFBVUEsYUFBYUE7NEJBQ25FQSxpQkFBZ0JBLG1CQUFlQSxJQUFJQTs0QkFDbkNBLGVBQW9CQSxvQ0FBdUJBOzRCQUMzQ0EsV0FBWUEsMEJBQWlCQTs0QkFDN0JBLGFBQW9CQSwyQ0FBZUEsUUFBT0E7NEJBQzFDQSxJQUFJQSw0QkFBZUE7Z0NBQ25CQSxXQUFXQSxZQUFRQSxnQ0FBY0Esa0JBQU1BOztnQ0FFdkNBLFdBQVdBLFlBQVFBLGdDQUFjQSwrQkFBS0E7Ozs0QkFHdENBOzt3QkFFQUEsVUFBVUEsSUFBSUE7d0JBQ2RBO3dCQUNBQSxlQUFlQTt3QkFDZkEsZ0JBQWdCQTt3QkFDaEJBLElBQUlBLG1DQUFzQkE7d0JBQzFCQSwwQkFBcUJBOzJCQUNkQSxJQUFJQTt3QkFDWEEsb0NBQXVCQTs7Ozs2QkFJWkE7Z0JBQ1hBOzs2QkFFV0E7Z0JBQ1hBLElBQUlBO29CQUF5QkE7O2dCQUM3QkEsSUFBSUE7b0JBQXlCQTs7Z0JBQzdCQSxJQUFJQTtvQkFBd0JBOztnQkFDNUJBLElBQUlBO29CQUEwQkE7O2dCQUM5QkEsSUFBSUE7b0JBQTZCQTs7Z0JBQ2pDQSxJQUFJQTtvQkFBMkJBOztnQkFDL0JBLElBQUlBO29CQUF1QkE7O2dCQUMzQkEsSUFBSUE7b0JBQTJCQTs7Z0JBQy9CQSxJQUFJQTtvQkFBd0JBOztnQkFDNUJBLElBQUlBO29CQUF3QkE7O2dCQUM1QkEsSUFBSUE7b0JBQWdDQTs7Z0JBQ3BDQSxJQUFJQTtvQkFBK0JBOztnQkFDbkNBLElBQUlBO29CQUE4QkE7O2dCQUNsQ0EsSUFBSUE7b0JBQTRCQTs7Z0JBQ2hDQSxJQUFJQTtvQkFBZ0NBOztnQkFDcENBLElBQUlBO29CQUE4QkE7O2dCQUNsQ0EsSUFBSUE7b0JBQThCQTs7Z0JBQ2xDQSxJQUFJQTtvQkFBNEJBOztnQkFDaENBLElBQUlBO29CQUEyQkE7O2dCQUMvQkEsSUFBSUE7b0JBQThCQTs7Z0JBQ2xDQSxJQUFJQTtvQkFBc0NBOztnQkFDMUNBLElBQUlBO29CQUEwQkE7O2dCQUM5QkEsSUFBSUE7b0JBQTRCQTs7Z0JBQ2hDQSxJQUFJQTtvQkFBNkJBOztnQkFDakNBLElBQUlBO29CQUE4QkE7O2dCQUNsQ0EsSUFBSUE7b0JBQTZCQTs7Z0JBQ2pDQSxJQUFJQTtvQkFBOEJBOztnQkFDbENBLElBQUlBO29CQUFpQ0E7O2dCQUNyQ0EsSUFBSUE7b0JBQThCQTs7Z0JBQ2xDQSxJQUFJQTtvQkFBd0JBOztnQkFDNUJBLElBQUlBO29CQUF1QkE7O2dCQUMzQkEsSUFBSUE7b0JBQThCQTs7Z0JBQ2xDQSxJQUFJQTtvQkFBOEJBOztnQkFDbENBLElBQUlBO29CQUF3QkE7O2dCQUM1QkEsSUFBSUE7b0JBQXlCQTs7Z0JBQzdCQSxJQUFJQTtvQkFBNkJBOztnQkFDakNBLElBQUlBO29CQUE0QkE7O2dCQUNoQ0EsSUFBSUE7b0JBQWlDQTs7Z0JBQ3JDQSxJQUFJQTtvQkFBZ0NBOztnQkFDcENBLElBQUlBO29CQUF1QkE7O2dCQUMzQkEsSUFBSUE7b0JBQTBCQTs7Z0JBQzlCQSxJQUFJQTtvQkFBMEJBOztnQkFDOUJBLElBQUlBO29CQUEwQkE7O2dCQUM5QkEsSUFBSUE7b0JBQXdCQTs7Z0JBQzVCQSxJQUFJQTtvQkFBNEJBOztnQkFDaENBLElBQUlBO29CQUE2QkE7O2dCQUNqQ0EsSUFBSUE7b0JBQThCQTs7Z0JBQ2xDQSxJQUFJQTtvQkFBaUNBOztnQkFDckNBLElBQUlBO29CQUErQkE7O2dCQUNuQ0EsSUFBSUE7b0JBQXlCQTs7Z0JBQzdCQSxJQUFJQTtvQkFBeUJBOztnQkFDN0JBLElBQUlBO29CQUF5QkE7O2dCQUM3QkEsSUFBSUE7b0JBQWlDQTs7Z0JBQ3JDQSxJQUFJQTtvQkFBMkJBOztnQkFDL0JBLElBQUlBO29CQUEwQkE7O2dCQUM5QkEsSUFBSUE7b0JBQTRCQTs7Z0JBQ2hDQSxJQUFJQTtvQkFBMkJBOztnQkFDL0JBLElBQUlBO29CQUEyQkE7O2dCQUMvQkEsSUFBSUE7b0JBQTZCQTs7Z0JBQ2pDQSxJQUFJQTtvQkFBdUJBOztnQkFDM0JBLElBQUlBO29CQUEyQkE7O2dCQUMvQkEsSUFBSUE7b0JBQTJCQTs7Z0JBQy9CQTs7cUNBRTJCQTtnQkFDM0JBLGVBQW9CQSw0Q0FBK0JBO2dCQUNuREEsV0FBWUEsMEJBQWlCQSxrQkFBc0JBO2dCQUNuREEsU0FBWUE7Z0JBQ1pBLFlBQWFBLFdBQU1BO2dCQUNuQkEsWUFBYUEsV0FBTUE7Z0JBQ25CQSxTQUFTQSxzQkFBeUJBLE9BQU1BO2dCQUN4Q0EsYUFBb0JBO2dCQUNwQkEsVUFBVUEsOENBQStCQSxJQUFJQSxhQUFhQTtnQkFDMURBLElBQUlBLFVBQVVBO29CQUNkQSxpQkFBZ0JBLG1CQUFlQTtvQkFDL0JBLGdDQUFjQSxhQUFDQSxZQUFnQkEsMERBQWdCQTs7Z0JBRS9DQSxTQUFTQTtnQkFDVEEsSUFBSUEsVUFBVUE7b0JBQ2RBLGtCQUFnQkEsbUJBQWVBO29CQUMvQkEsZ0NBQWNBLGFBQUNBLFlBQWdCQSwwREFBZ0JBOztnQkFFL0NBLElBQUlBLE1BQUtBO29CQUNUQTtvQkFDQUEsVUFBVUE7b0JBQ1ZBLGFBQWNBLDBCQUFpQkEsa0JBQXNCQTtvQkFDckRBLFNBQVNBO29CQUNUQSxrQkFBZ0JBLG1CQUFlQTtvQkFDL0JBLGdDQUFjQSwrQkFBS0E7OztzQ0FFU0E7Z0JBQzVCQSxJQUFHQTtvQkFDSEEsYUFBa0JBLFlBQVdBLDhDQUErQkEsVUFBVUEsYUFBYUE7b0JBQ25GQSxJQUFJQSxRQUFRQTt3QkFBUUEsNEJBQTRCQTs7dUJBRzNDQSxJQUFHQTtvQkFDUkEsYUFBcUJBLFlBQWNBLDhDQUErQkEsVUFBVUEsYUFBYUE7b0JBQ3pGQSxJQUFJQSxRQUFRQTt3QkFBUUEsNEJBQTRCQTs7dUJBRzNDQSxJQUFHQTtvQkFDUkEsYUFBMEJBLFlBQW1CQSw4Q0FBK0JBLFVBQVVBLGFBQWFBO29CQUNuR0EsSUFBSUEsUUFBUUE7d0JBQVFBLDRCQUE0QkE7O3VCQUczQ0EsSUFBR0E7b0JBQ1JBLGFBQXdCQSxZQUFpQkEsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDL0ZBLElBQUlBLFFBQVFBO3dCQUFRQSw0QkFBNEJBOzt1QkFHM0NBLElBQUdBO29CQUNSQSxhQUF3QkEsWUFBaUJBLDhDQUErQkEsVUFBVUEsYUFBYUE7b0JBQy9GQSxJQUFJQSxRQUFRQTt3QkFBUUEsNEJBQTRCQTs7dUJBRzNDQSxJQUFHQTtvQkFDUkEsYUFBdUJBLFlBQWdCQSw4Q0FBK0JBLFVBQVVBLGFBQWFBO29CQUM3RkEsSUFBSUEsUUFBUUE7d0JBQVFBLDRCQUE0QkE7O3VCQUczQ0EsSUFBR0E7b0JBQ1JBLGFBQXlCQSxZQUFrQkEsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDakdBLElBQUlBLFFBQVFBO3dCQUFRQSw0QkFBNEJBOzt1QkFHM0NBLElBQUdBO29CQUNSQSxhQUE0QkEsWUFBcUJBLDhDQUErQkEsVUFBVUEsYUFBYUE7b0JBQ3ZHQSxJQUFJQSxRQUFRQTt3QkFBUUEsNEJBQTRCQTs7dUJBRzNDQSxJQUFHQTtvQkFDUkEsYUFBNkJBLFlBQXNCQSw4Q0FBK0JBLFVBQVVBLGFBQWFBO29CQUN6R0EsSUFBSUEsUUFBUUE7d0JBQVFBLDRCQUE0QkE7O3VCQUczQ0EsSUFBR0E7b0JBQ1JBLGNBQThCQSxZQUFzQkEsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDMUdBLElBQUlBLFFBQVFBO3dCQUFTQSw2QkFBNkJBOzt1QkFHN0NBLElBQUdBO29CQUNSQSxjQUFvQ0EsWUFBNEJBLDhDQUErQkEsVUFBVUEsYUFBYUE7b0JBQ3RIQSxJQUFJQSxRQUFRQTt3QkFBU0EsNkJBQTZCQTs7dUJBRzdDQSxJQUFHQTtvQkFDUkEsY0FBNkJBLFlBQXFCQSw4Q0FBK0JBLFVBQVVBLGFBQWFBO29CQUN4R0EsSUFBSUEsUUFBUUE7d0JBQVNBLDZCQUE2QkE7O3VCQUc3Q0EsSUFBR0E7b0JBQ1JBLGNBQThCQSxZQUFzQkEsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDMUdBLElBQUlBLFFBQVFBO3dCQUFTQSw2QkFBNkJBOzt1QkFHN0NBLElBQUdBO29CQUNSQSxjQUE4QkEsWUFBc0JBLDhDQUErQkEsVUFBVUEsYUFBYUE7b0JBQzFHQSxJQUFJQSxRQUFRQTt3QkFBU0EsNkJBQTZCQTs7dUJBRzdDQSxJQUFHQTtvQkFDUkEsY0FBK0JBLFlBQXVCQSw4Q0FBK0JBLFVBQVVBLGFBQWFBO29CQUM1R0EsSUFBSUEsUUFBUUE7d0JBQVNBLDZCQUE2QkE7O3VCQUc3Q0EsSUFBR0E7b0JBQ1JBLGNBQTJCQSxZQUFtQkEsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDcEdBLElBQUlBLFFBQVFBO3dCQUFTQSw2QkFBNkJBOzt1QkFHN0NBLElBQUdBO29CQUNSQSxjQUF1QkEsWUFBZUEsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDNUZBLElBQUlBLFFBQVFBO3dCQUFTQSw2QkFBNkJBOzt1QkFHN0NBLElBQUdBO29CQUNSQSxjQUEyQkEsWUFBbUJBLDhDQUErQkEsVUFBVUEsYUFBYUE7b0JBQ3BHQSxJQUFJQSxRQUFRQTt3QkFBU0EsNkJBQTZCQTs7dUJBRzdDQSxJQUFHQTtvQkFDUkEsY0FBd0JBLFlBQWdCQSw4Q0FBK0JBLFVBQVVBLGFBQWFBO29CQUM5RkEsSUFBSUEsUUFBUUE7d0JBQVNBLDZCQUE2QkE7O3VCQUc3Q0EsSUFBR0E7b0JBQ1JBLGNBQXdCQSxZQUFnQkEsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDOUZBLElBQUlBLFFBQVFBO3dCQUFTQSw2QkFBNkJBOzt1QkFHN0NBLElBQUdBO29CQUNSQSxjQUFnQ0EsWUFBd0JBLDhDQUErQkEsVUFBVUEsYUFBYUE7b0JBQzlHQSxJQUFJQSxRQUFRQTt3QkFBU0EsNkJBQTZCQTs7dUJBRzdDQSxJQUFHQTtvQkFDUkEsY0FBK0JBLFlBQXVCQSw4Q0FBK0JBLFVBQVVBLGFBQWFBO29CQUM1R0EsSUFBSUEsUUFBUUE7d0JBQVNBLDZCQUE2QkE7O3VCQUc3Q0EsSUFBR0E7b0JBQ1JBLGNBQThCQSxZQUFzQkEsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDMUdBLElBQUlBLFFBQVFBO3dCQUFTQSw2QkFBNkJBOzt1QkFHN0NBLElBQUdBO29CQUNSQSxjQUE0QkEsWUFBb0JBLDhDQUErQkEsVUFBVUEsYUFBYUE7b0JBQ3RHQSxJQUFJQSxRQUFRQTt3QkFBU0EsNkJBQTZCQTs7dUJBRzdDQSxJQUFHQTtvQkFDUkEsY0FBZ0NBLFlBQXdCQSw4Q0FBK0JBLFVBQVVBLGFBQWFBO29CQUM5R0EsSUFBSUEsUUFBUUE7d0JBQVNBLDZCQUE2QkE7O3VCQUc3Q0EsSUFBR0E7b0JBQ1JBLGNBQThCQSxZQUFzQkEsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDMUdBLElBQUlBLFFBQVFBO3dCQUFTQSw2QkFBNkJBOzt1QkFHN0NBLElBQUdBO29CQUNSQSxjQUE4QkEsWUFBc0JBLDhDQUErQkEsVUFBVUEsYUFBYUE7b0JBQzFHQSxJQUFJQSxRQUFRQTt3QkFBU0EsNkJBQTZCQTs7dUJBRzdDQSxJQUFHQTtvQkFDUkEsY0FBNEJBLFlBQW9CQSw4Q0FBK0JBLFVBQVVBLGFBQWFBO29CQUN0R0EsSUFBSUEsUUFBUUE7d0JBQVNBLDZCQUE2QkE7O3VCQUc3Q0EsSUFBR0E7b0JBQ1JBLGNBQTJCQSxZQUFtQkEsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDcEdBLElBQUlBLFFBQVFBO3dCQUFTQSw2QkFBNkJBOzt1QkFHN0NBLElBQUdBO29CQUNSQSxjQUE4QkEsWUFBc0JBLDhDQUErQkEsVUFBVUEsYUFBYUE7b0JBQzFHQSxJQUFJQSxRQUFRQTt3QkFBU0EsNkJBQTZCQTs7dUJBRzdDQSxJQUFHQTtvQkFDUkEsY0FBNkJBLFlBQXFCQSw4Q0FBK0JBLFVBQVVBLGFBQWFBO29CQUN4R0EsSUFBSUEsUUFBUUE7d0JBQVNBLDZCQUE2QkE7O3VCQUc3Q0EsSUFBR0E7b0JBQ1JBLGNBQXNDQSxZQUE4QkEsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDMUhBLElBQUlBLFFBQVFBO3dCQUFTQSw2QkFBNkJBOzt1QkFHN0NBLElBQUdBO29CQUNSQSxjQUEwQkEsWUFBa0JBLDhDQUErQkEsVUFBVUEsYUFBYUE7b0JBQ2xHQSxJQUFJQSxRQUFRQTt3QkFBU0EsNkJBQTZCQTs7dUJBRzdDQSxJQUFHQTtvQkFDUkEsY0FBNEJBLFlBQW9CQSw4Q0FBK0JBLFVBQVVBLGFBQWFBO29CQUN0R0EsSUFBSUEsUUFBUUE7d0JBQVNBLDZCQUE2QkE7O3VCQUc3Q0EsSUFBR0E7b0JBQ1JBLGNBQTZCQSxZQUFxQkEsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDeEdBLElBQUlBLFFBQVFBO3dCQUFTQSw2QkFBNkJBOzt1QkFHN0NBLElBQUdBO29CQUNSQSxjQUE4QkEsWUFBc0JBLDhDQUErQkEsVUFBVUEsYUFBYUE7b0JBQzFHQSxJQUFJQSxRQUFRQTt3QkFBU0EsNkJBQTZCQTs7dUJBRzdDQSxJQUFHQTtvQkFDUkEsY0FBNkJBLFlBQXFCQSw4Q0FBK0JBLFVBQVVBLGFBQWFBO29CQUN4R0EsSUFBSUEsUUFBUUE7d0JBQVNBLDZCQUE2QkE7O3VCQUc3Q0EsSUFBR0E7b0JBQ1JBLGNBQThCQSxZQUFzQkEsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDMUdBLElBQUlBLFFBQVFBO3dCQUFTQSw2QkFBNkJBOzt1QkFHN0NBLElBQUdBO29CQUNSQSxjQUFpQ0EsWUFBeUJBLDhDQUErQkEsVUFBVUEsYUFBYUE7b0JBQ2hIQSxJQUFJQSxRQUFRQTt3QkFBU0EsNkJBQTZCQTs7dUJBRzdDQSxJQUFHQTtvQkFDUkEsY0FBNkJBLFlBQXFCQSw4Q0FBK0JBLFVBQVVBLGFBQWFBO29CQUN4R0EsSUFBSUEsUUFBUUE7d0JBQVNBLDZCQUE2QkE7O3VCQUc3Q0EsSUFBR0E7b0JBQ1JBLGNBQTRCQSxZQUFvQkEsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDdEdBLElBQUlBLFFBQVFBO3dCQUFTQSw2QkFBNkJBOzt1QkFHN0NBLElBQUdBO29CQUNSQSxjQUEyQkEsWUFBbUJBLDhDQUErQkEsVUFBVUEsYUFBYUE7b0JBQ3BHQSxJQUFJQSxRQUFRQTt3QkFBU0EsNkJBQTZCQTs7dUJBRzdDQSxJQUFHQTtvQkFDUkEsY0FBOEJBLFlBQXNCQSw4Q0FBK0JBLFVBQVVBLGFBQWFBO29CQUMxR0EsSUFBSUEsUUFBUUE7d0JBQVNBLDZCQUE2QkE7O3VCQUc3Q0EsSUFBR0E7b0JBQ1JBLGNBQXVCQSxZQUFlQSw4Q0FBK0JBLFVBQVVBLGFBQWFBO29CQUM1RkEsSUFBSUEsUUFBUUE7d0JBQVNBLDZCQUE2QkE7O3VCQUc3Q0EsSUFBR0E7b0JBQ1JBLGNBQXVCQSxZQUFlQSw4Q0FBK0JBLFVBQVVBLGFBQWFBO29CQUM1RkEsSUFBSUEsUUFBUUE7d0JBQVNBLDZCQUE2QkE7O3VCQUc3Q0EsSUFBR0E7b0JBQ1JBLGNBQXdCQSxZQUFnQkEsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDOUZBLElBQUlBLFFBQVFBO3dCQUFTQSw2QkFBNkJBOzt1QkFHN0NBLElBQUdBO29CQUNSQSxjQUF1QkEsWUFBZUEsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDNUZBLElBQUlBLFFBQVFBO3dCQUFTQSw2QkFBNkJBOzt1QkFHN0NBLElBQUdBO29CQUNSQSxjQUF3QkEsWUFBZ0JBLDhDQUErQkEsVUFBVUEsYUFBYUE7b0JBQzlGQSxJQUFJQSxRQUFRQTt3QkFBU0EsNkJBQTZCQTs7dUJBRzdDQSxJQUFHQTtvQkFDUkEsY0FBOEJBLFlBQXNCQSw4Q0FBK0JBLFVBQVVBLGFBQWFBO29CQUMxR0EsSUFBSUEsUUFBUUE7d0JBQVNBLDZCQUE2QkE7O3VCQUc3Q0EsSUFBR0E7b0JBQ1JBLGNBQXlCQSxZQUFpQkEsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDaEdBLElBQUlBLFFBQVFBO3dCQUFTQSw2QkFBNkJBOzt1QkFHN0NBLElBQUdBO29CQUNSQSxjQUF3QkEsWUFBZ0JBLDhDQUErQkEsVUFBVUEsYUFBYUE7b0JBQzlGQSxJQUFJQSxRQUFRQTt3QkFBU0EsNkJBQTZCQTs7dUJBRzdDQSxJQUFHQTtvQkFDUkEsY0FBOEJBLFlBQXNCQSw4Q0FBK0JBLFVBQVVBLGFBQWFBO29CQUMxR0EsSUFBSUEsUUFBUUE7d0JBQVNBLDZCQUE2QkE7O3VCQUc3Q0EsSUFBR0E7b0JBQ1JBLGNBQXdCQSxZQUFnQkEsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDOUZBLElBQUlBLFFBQVFBO3dCQUFTQSw2QkFBNkJBOzt1QkFHN0NBLElBQUdBO29CQUNSQSxjQUE0QkEsWUFBb0JBLDhDQUErQkEsVUFBVUEsYUFBYUE7b0JBQ3RHQSxJQUFJQSxRQUFRQTt3QkFBU0EsNkJBQTZCQTs7dUJBRzdDQSxJQUFHQTtvQkFDUkEsY0FBeUJBLFlBQWlCQSw4Q0FBK0JBLFVBQVVBLGFBQWFBO29CQUNoR0EsSUFBSUEsUUFBUUE7d0JBQVNBLDZCQUE2QkE7O3VCQUc3Q0EsSUFBR0E7b0JBQ1JBLGNBQTZCQSxZQUFxQkEsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDeEdBLElBQUlBLFFBQVFBO3dCQUFTQSw2QkFBNkJBOzt1QkFHN0NBLElBQUdBO29CQUNSQSxjQUE0QkEsWUFBb0JBLDhDQUErQkEsVUFBVUEsYUFBYUE7b0JBQ3RHQSxJQUFJQSxRQUFRQTt3QkFBU0EsNkJBQTZCQTs7dUJBRzdDQSxJQUFHQTtvQkFDUkEsY0FBaUNBLFlBQXlCQSw4Q0FBK0JBLFVBQVVBLGFBQWFBO29CQUNoSEEsSUFBSUEsUUFBUUE7d0JBQVNBLDZCQUE2QkE7O3VCQUc3Q0EsSUFBR0E7b0JBQ1JBLGNBQWdDQSxZQUF3QkEsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDOUdBLElBQUlBLFFBQVFBO3dCQUFTQSw2QkFBNkJBOzt1QkFHN0NBLElBQUdBO29CQUNSQSxjQUF1QkEsWUFBZUEsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDNUZBLElBQUlBLFFBQVFBO3dCQUFTQSw2QkFBNkJBOzt1QkFHN0NBLElBQUdBO29CQUNSQSxjQUEwQkEsWUFBa0JBLDhDQUErQkEsVUFBVUEsYUFBYUE7b0JBQ2xHQSxJQUFJQSxRQUFRQTt3QkFBU0EsNkJBQTZCQTs7dUJBRzdDQSxJQUFHQTtvQkFDUkEsY0FBdUJBLFlBQWVBLDhDQUErQkEsVUFBVUEsYUFBYUE7b0JBQzVGQSxJQUFJQSxRQUFRQTt3QkFBU0EsNkJBQTZCQTs7dUJBRzdDQSxJQUFHQTtvQkFDUkEsY0FBMEJBLFlBQWtCQSw4Q0FBK0JBLFVBQVVBLGFBQWFBO29CQUNsR0EsSUFBSUEsUUFBUUE7d0JBQVNBLDZCQUE2QkE7O3VCQUc3Q0EsSUFBR0E7b0JBQ1JBLGNBQWdDQSxZQUF3QkEsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDOUdBLElBQUlBLFFBQVFBO3dCQUFTQSw2QkFBNkJBOzt1QkFHN0NBLElBQUdBO29CQUNSQSxjQUFnQ0EsWUFBd0JBLDhDQUErQkEsVUFBVUEsYUFBYUE7b0JBQzlHQSxJQUFJQSxRQUFRQTt3QkFBU0EsNkJBQTZCQTs7dUJBRzdDQSxJQUFHQTtvQkFDUkEsY0FBMEJBLFlBQWtCQSw4Q0FBK0JBLFVBQVVBLGFBQWFBO29CQUNsR0EsSUFBSUEsUUFBUUE7d0JBQVNBLDZCQUE2QkE7O3VCQUc3Q0EsSUFBR0E7b0JBQ1JBLGNBQXdCQSxZQUFnQkEsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDOUZBLElBQUlBLFFBQVFBO3dCQUFTQSw2QkFBNkJBOzt1QkFHN0NBLElBQUdBO29CQUNSQSxjQUE0QkEsWUFBb0JBLDhDQUErQkEsVUFBVUEsYUFBYUE7b0JBQ3RHQSxJQUFJQSxRQUFRQTt3QkFBU0EsNkJBQTZCQTs7dUJBRzdDQSxJQUFHQTtvQkFDUkEsY0FBNkJBLFlBQXFCQSw4Q0FBK0JBLFVBQVVBLGFBQWFBO29CQUN4R0EsSUFBSUEsUUFBUUE7d0JBQVNBLDZCQUE2QkE7O3VCQUc3Q0EsSUFBR0E7b0JBQ1JBLGNBQThCQSxZQUFzQkEsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDMUdBLElBQUlBLFFBQVFBO3dCQUFTQSw2QkFBNkJBOzt1QkFHN0NBLElBQUdBO29CQUNSQSxjQUFpQ0EsWUFBeUJBLDhDQUErQkEsVUFBVUEsYUFBYUE7b0JBQ2hIQSxJQUFJQSxRQUFRQTt3QkFBU0EsNkJBQTZCQTs7dUJBRzdDQSxJQUFHQTtvQkFDUkEsY0FBK0JBLFlBQXVCQSw4Q0FBK0JBLFVBQVVBLGFBQWFBO29CQUM1R0EsSUFBSUEsUUFBUUE7d0JBQVNBLDZCQUE2QkE7O3VCQUc3Q0EsSUFBR0E7b0JBQ1JBLGNBQXlCQSxZQUFpQkEsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDaEdBLElBQUlBLFFBQVFBO3dCQUFTQSw2QkFBNkJBOzt1QkFHN0NBLElBQUdBO29CQUNSQSxjQUF5QkEsWUFBaUJBLDhDQUErQkEsVUFBVUEsYUFBYUE7b0JBQ2hHQSxJQUFJQSxRQUFRQTt3QkFBU0EsNkJBQTZCQTs7dUJBRzdDQSxJQUFHQTtvQkFDUkEsY0FBeUJBLFlBQWlCQSw4Q0FBK0JBLFVBQVVBLGFBQWFBO29CQUNoR0EsSUFBSUEsUUFBUUE7d0JBQVNBLDZCQUE2QkE7O3VCQUc3Q0EsSUFBR0E7b0JBQ1JBLGNBQWlDQSxZQUF5QkEsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDaEhBLElBQUlBLFFBQVFBO3dCQUFTQSw2QkFBNkJBOzt1QkFHN0NBLElBQUdBO29CQUNSQSxjQUEyQkEsWUFBbUJBLDhDQUErQkEsVUFBVUEsYUFBYUE7b0JBQ3BHQSxJQUFJQSxRQUFRQTt3QkFBU0EsNkJBQTZCQTs7dUJBRzdDQSxJQUFHQTtvQkFDUkEsY0FBNEJBLFlBQW9CQSw4Q0FBK0JBLFVBQVVBLGFBQWFBO29CQUN0R0EsSUFBSUEsUUFBUUE7d0JBQVNBLDZCQUE2QkE7O3VCQUc3Q0EsSUFBR0E7b0JBQ1JBLGNBQTBCQSxZQUFrQkEsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDbEdBLElBQUlBLFFBQVFBO3dCQUFTQSw2QkFBNkJBOzt1QkFHN0NBLElBQUdBO29CQUNSQSxjQUE0QkEsWUFBb0JBLDhDQUErQkEsVUFBVUEsYUFBYUE7b0JBQ3RHQSxJQUFJQSxRQUFRQTt3QkFBU0EsNkJBQTZCQTs7dUJBRzdDQSxJQUFHQTtvQkFDUkEsY0FBMkJBLFlBQW1CQSw4Q0FBK0JBLFVBQVVBLGFBQWFBO29CQUNwR0EsSUFBSUEsUUFBUUE7d0JBQVNBLDZCQUE2QkE7O3VCQUc3Q0EsSUFBR0E7b0JBQ1JBLGNBQTJCQSxZQUFtQkEsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDcEdBLElBQUlBLFFBQVFBO3dCQUFTQSw2QkFBNkJBOzt1QkFHN0NBLElBQUdBO29CQUNSQSxjQUEwQkEsWUFBa0JBLDhDQUErQkEsVUFBVUEsYUFBYUE7b0JBQ2xHQSxJQUFJQSxRQUFRQTt3QkFBU0EsNkJBQTZCQTs7dUJBRzdDQSxJQUFHQTtvQkFDUkEsY0FBNEJBLFlBQW9CQSw4Q0FBK0JBLFVBQVVBLGFBQWFBO29CQUN0R0EsSUFBSUEsUUFBUUE7d0JBQVNBLDZCQUE2QkE7O3VCQUc3Q0EsSUFBR0E7b0JBQ1JBLGNBQTZCQSxZQUFxQkEsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDeEdBLElBQUlBLFFBQVFBO3dCQUFTQSw2QkFBNkJBOzt1QkFHN0NBLElBQUdBO29CQUNSQSxjQUE2QkEsWUFBcUJBLDhDQUErQkEsVUFBVUEsYUFBYUE7b0JBQ3hHQSxJQUFJQSxRQUFRQTt3QkFBU0EsNkJBQTZCQTs7dUJBRzdDQSxJQUFHQTtvQkFDUkEsY0FBb0NBLFlBQTRCQSw4Q0FBK0JBLFVBQVVBLGFBQWFBO29CQUN0SEEsSUFBSUEsUUFBUUE7d0JBQVNBLDZCQUE2QkE7O3VCQUc3Q0EsSUFBR0E7b0JBQ1JBLGNBQXdDQSxZQUFnQ0EsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDOUhBLElBQUlBLFFBQVFBO3dCQUFTQSw2QkFBNkJBOzt1QkFHN0NBLElBQUdBO29CQUNSQSxjQUFpQ0EsWUFBeUJBLDhDQUErQkEsVUFBVUEsYUFBYUE7b0JBQ2hIQSxJQUFJQSxRQUFRQTt3QkFBU0EsNkJBQTZCQTs7dUJBRzdDQSxJQUFHQTtvQkFDUkEsY0FBdUJBLFlBQWVBLDhDQUErQkEsVUFBVUEsYUFBYUE7b0JBQzVGQSxJQUFJQSxRQUFRQTt3QkFBU0EsNkJBQTZCQTs7dUJBRzdDQSxJQUFHQTtvQkFDUkEsY0FBMkJBLFlBQW1CQSw4Q0FBK0JBLFVBQVVBLGFBQWFBO29CQUNwR0EsSUFBSUEsUUFBUUE7d0JBQVNBLDZCQUE2QkE7O3VCQUc3Q0EsSUFBR0E7b0JBQ1JBLGNBQTJCQSxZQUFtQkEsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDcEdBLElBQUlBLFFBQVFBO3dCQUFTQSw2QkFBNkJBOzt1QkFHN0NBLElBQUdBO29CQUNSQSxjQUFzQkEsWUFBY0EsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDMUZBLElBQUlBLFFBQVFBO3dCQUFTQSw2QkFBNkJBOzs7OztzQ0FJNUJBO2dCQUN0QkE7Z0JBQ0FBLEFBQWlEQTtnQkFDakRBLEFBQWdEQSxnQkFBRUE7Z0JBQ2xEQSxPQUFPQTs7bUNBRWtCQSxJQUFhQTtnQkFDdENBO2dCQUNBQSxVQUFXQSxJQUFJQTtnQkFDZkEsWUFBWUEscUNBQVNBO2dCQUNyQkEsYUFBYUEscUNBQVNBO2dCQUN0QkEsMEVBQW9EQTtnQkFDcERBLHlFQUFtREE7Z0JBQ25EQSw4QkFBNkJBO2dCQUM3QkEsVUFBYUE7Z0JBQ2JBLGdFQUEwQ0E7Z0JBQzFDQSxXQUFZQTtnQkFDWkEsc0VBQWdEQTtnQkFDaERBLHFFQUErQ0E7Z0JBQy9DQSwwQkFBeUJBO2dCQUN6QkEsaUNBQWdDQTtnQkFDaENBLFlBQWFBLHFDQUFTQTtnQkFDdEJBLElBQUlBO29CQUFTQSxRQUFNQSxJQUFFQTs7Z0JBQ3JCQSxZQUFXQSxJQUFJQSwrQkFBS0Esa0JBQU1BLGFBQVVBLE9BQU9BLGtCQUFNQSxjQUFXQTtnQkFDNURBLDBFQUFvREE7Z0JBQ3BEQSx5RUFBbURBO2dCQUNuREEsOEJBQTZCQTtnQkFDN0JBLHFCQUFtQkEsK0JBQUNBLElBQUlBO29CQUN4QkEsWUFBYUE7b0JBQ2JBLFdBQWdCQSxnRkFBdURBO29CQUN2RUEsNEJBQTRCQTtvQkFDNUJBLG1DQUFtQ0E7b0JBQ25DQSxhQUFjQSxxQ0FBU0E7b0JBQ3ZCQSxJQUFJQTt3QkFBVUEsU0FBT0EsSUFBRUE7O29CQUN2QkEsYUFBWUEsSUFBSUEsK0JBQUtBLGtCQUFNQSxhQUFVQSxRQUFRQSxrQkFBTUEsY0FBV0E7b0JBQzlEQSwwRUFBb0RBO29CQUNwREEseUVBQW1EQTtvQkFDbkRBLGdDQUErQkE7b0JBQy9CQSxzRUFBZ0RBO29CQUNoREEscUVBQStDQTtvQkFDL0NBLDZFQUF1REE7b0JBQ3ZEQSw0RUFBc0RBO29CQUN0REEsU0FBWUEsWUFBUUE7b0JBQ3BCQSxJQUFJQSxNQUFLQTt3QkFDVEEsU0FBa0JBLHdFQUErQ0EsSUFBSUE7d0JBQ3JFQSxJQUFJQSxNQUFNQSxRQUFRQSxNQUFLQSxxQ0FBS0E7NEJBQzVCQTs7Ozs7OENBR29DQSxRQUFlQTtnQkFFbkRBLFNBQWFBLFlBQVNBO2dCQUN0QkEsSUFBSUEsTUFBS0E7b0JBQ1RBLFVBQXdCQSx3QkFBd0JBO29CQUNoREEsV0FBc0JBO29CQUN0QkEsZUFBa0JBO29CQUNsQkEsU0FBb0JBO29CQUNwQkEsVUFBVUE7b0JBQ1ZBLFVBQVVBO29CQUNWQSxjQUFjQTtvQkFDZEEsV0FBV0EsZ0NBQW1CQTtvQkFDOUJBLFVBQWFBLDhDQUErQkEsVUFBVUEsYUFBYUE7b0JBQ25FQSxpQkFBZ0JBLG1CQUFjQTtvQkFDOUJBLGVBQW9CQSw0Q0FBK0JBO29CQUNuREEsV0FBWUEsMEJBQWlCQSxrQkFBc0JBO29CQUNuREEsYUFBb0JBO29CQUNwQkEsZ0NBQWNBLCtCQUFLQTs7OzRDQUVlQSxRQUFlQTtnQkFFakRBLElBQUlBLFVBQVNBO29CQUViQSxTQUFhQSxZQUFTQTtvQkFDdEJBLElBQUdBLE1BQUdBO3dCQUNOQSxVQUF3QkEsd0JBQXdCQTt3QkFDaERBLFdBQXNCQTt3QkFDdEJBLGVBQWtCQTt3QkFDbEJBLFNBQW9CQTt3QkFDcEJBLFVBQVVBO3dCQUNWQSxVQUFVQTt3QkFDVkEsY0FBY0E7d0JBQ2RBLFdBQVdBLGdDQUFtQkE7d0JBQzlCQSxVQUFhQSw4Q0FBK0JBLFVBQVVBLGFBQWFBO3dCQUNuRUEsaUJBQWdCQSxtQkFBY0E7d0JBQzlCQSxlQUFvQkEsNENBQStCQTt3QkFDbkRBLFdBQVlBLDBCQUFpQkEsa0JBQXNCQTt3QkFDbkRBLGFBQW9CQTt3QkFDcEJBLGdDQUFjQSwrQkFBS0E7Ozs7O2dCRmg5QlBBLElBQUlBO29CQUNBQTs7Z0JBQ0pBOzs7Z0JBR0FBLElBQUlBO29CQUVBQSxBQUFDQSxZQUFtQ0EsQUFBUUE7OztnQkFJNURBLDRDQUE0Q0EsSUFBSUE7Z0JBQ2hEQSxpREFBaURBLElBQUlBO2dCQUNyREEsNENBQTRDQSxJQUFJQTtnQkFDaERBLDRDQUE0Q0EsSUFBSUE7O2dCQUVoREEsMkJBQXlCQTtnQkFDekJBO2dCQUNBQSxvREFBb0RBLElBQUlBOztnQkFFeERBLG9EQUFvREEsSUFBSUE7O2dCQUV4REEsdUNBQWlDQTtnQkFDakNBLHVDQUFpQ0E7O2dCQUVqQ0EsNENBQTRDQSxJQUFJQTtnQkFDaERBLHFEQUFxREEsSUFBSUE7Z0JBQ3pEQSx3REFBd0RBLElBQUlBLHFEQUF3Q0E7O2dCQUVwR0EscURBQXFEQSxJQUFJQTtnQkFDekRBLHdEQUF3REEsSUFBSUEscURBQXdDQTs7Z0JBRXBHQSx5REFBeURBO2dCQUN6REEseURBQXlEQTs7Z0JBRXpEQSwrQkFBNkJBO2dCQUM3QkE7O2dCQUVBQSxnQ0FBOEJBO2dCQUM5QkE7Z0JBQ0FBLG1EQUE2Q0E7O2dCQUU3Q0EsaUNBQStCQTtnQkFDL0JBO2dCQUNBQSxtREFBNkNBO2dCQUM3Q0EsbURBQW1EQTs7Z0JBRW5EQSxtQ0FBaUNBO2dCQUNqQ0E7Z0JBQ0FBLG1EQUE2Q0E7Z0JBQzdDQSxtREFBbURBOztnQkFFbkRBLG1EQUFtREE7Z0JBQ25EQSxtREFBbURBO2dCQUNuREEsbURBQW1EQTtnQkFDbkRBLG1EQUFtREE7OztnQkFHbkRBLGVBQWVBOztnQkFFZkEsNERBQTREQSxJQUFJQTtnQkFDaEVBO2dCQUNBQTtnQkFDQUE7Ozs7O2dCQUtBQSxlQUFVQTtnQkFDVkEsZ0JBQVdBO2dCQUNYQSxpQkFBWUE7Z0JBQ1pBLG1CQUFjQTtnQkFDZEEsV0FBTUE7O2dCQUVOQSx5REFBeURBLG1FQUFtRUEsSUFBSUEsMENBQStCQSxNQUFNQTtnQkFDcktBLElBQUdBO29CQUVDQSxnRUFBMERBLE1BQU1BLG9FQUE4REEsWUFBOEJBOztvQkFJNUpBLG1CQUFtQkEsQUFBdUJBOzs7Ozs7Ozs7Ozs7Ozt5Q0c3Q0FBOzs7O3VDQXBFTEEsSUFBbUJBO29CQUVoREEsVUFBYUEsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDbkVBLGlCQUFnQkEsbUJBQWVBO29CQUMvQkEsZUFBb0JBLDRDQUErQkE7O29CQUVuREEsU0FBWUEsZ0NBQW1CQTtvQkFDL0JBLElBQUlBO3dCQUFzQkEsS0FBS0EsYUFBZ0JBOztvQkFDL0NBLFdBQVlBLDBCQUFpQkEsa0JBQXNCQTs7b0JBRW5EQSxhQUFvQkE7O29CQUVwQkEsSUFBSUEsNEJBQWVBO3dCQUNmQSxPQUFPQSxZQUFRQSxnQ0FBY0Esa0JBQU1BOzt3QkFFbkNBLE9BQU9BLFlBQVFBLGdDQUFjQSxhQUFDQSxZQUFnQkEsMERBQWdCQTs7O3NDQUd0Q0EsSUFBbUJBO29CQUUvQ0EsVUFBYUEsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDbkVBLGlCQUFnQkEsbUJBQWVBO29CQUMvQkEsZUFBb0JBLDRDQUErQkE7O29CQUVuREEsU0FBWUEsZ0NBQW1CQTtvQkFDL0JBLElBQUlBO3dCQUFzQkEsS0FBS0EsYUFBZ0JBOztvQkFDL0NBLFdBQVlBLDBCQUFpQkEsa0JBQXNCQTs7b0JBRW5EQSxhQUFvQkE7O29CQUVwQkE7b0JBQ0FBLElBQUlBLFVBQVVBO3dCQUVWQSxJQUFJQSw0QkFBZUE7NEJBQ2ZBLFNBQVNBLFlBQVFBLGdDQUFjQSxrQkFBTUE7OzRCQUVyQ0EsU0FBU0EsWUFBUUEsZ0NBQWNBLGFBQUNBLFlBQWdCQSwwREFBZ0JBOzs7b0JBRXhFQSxPQUFPQTs7dUNBR3NCQSxJQUFtQkE7b0JBRWhEQTtvQkFDQUEsVUFBYUEsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDbkVBLGlCQUFnQkEsbUJBQWVBO29CQUMvQkEsZUFBb0JBLDRDQUErQkE7b0JBQ25EQSxTQUFZQSxnQ0FBbUJBOztvQkFFL0JBLElBQUlBO3dCQUFzQkEsS0FBS0EsYUFBZ0JBOztvQkFDL0NBLFdBQVlBLDBCQUFpQkEsa0JBQXNCQTtvQkFDbkRBLGFBQW9CQSwyQ0FBZUEsUUFBT0E7O29CQUUxQ0EsSUFBSUEsVUFBVUE7d0JBRVZBLElBQUlBLDRCQUFlQTs0QkFBU0EsU0FBU0EsWUFBUUEsZ0NBQWNBLGtCQUFNQTs7NEJBQzVEQSxTQUFTQSxZQUFRQSxnQ0FBY0EsYUFBQ0EsWUFBZ0JBLDBEQUFnQkE7OztvQkFFekVBLE9BQU9BOzt5Q0FHd0JBLElBQW1CQTtvQkFFbERBLFVBQXFCQSxZQUFnQkEsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDM0ZBLGFBQWdCQTtvQkFDaEJBLE9BQU9BOztvQ0FLbUJBLElBQW1CQTtvQkFFN0NBLElBQUlBO3dCQUF3QkEsT0FBT0E7O29CQUNuQ0E7O29CQUVBQSxVQUFhQSw2QkFBZ0JBO29CQUM3QkEsaUJBQWdCQSxtQkFBZUE7b0JBQy9CQSxlQUFvQkEsNENBQStCQTtvQkFDbkRBLElBQUlBLE1BQUtBO3dCQUVMQSxTQUFZQSxvQ0FBdUJBO3dCQUMvQ0EsSUFBSUEsTUFBS0E7NEJBQ1JBLElBQUlBO2dDQUFzQkEsS0FBS0EsYUFBZ0JBOzs0QkFDL0NBLFdBQVlBLDBCQUFpQkEsa0JBQXNCQTs7NEJBRW5EQSxhQUFvQkE7OzRCQUVwQkEsSUFBSUEsVUFBVUE7Z0NBRWJBLElBQUlBLDRCQUFlQTtvQ0FDbEJBLFNBQVNBLFlBQVFBLGdDQUFjQSxrQkFBTUE7O29DQUdyQ0EsV0FBc0JBLFlBQWdCQTtvQ0FDdENBLFNBQVNBLFlBQVFBLGdDQUFjQSwwQ0FBZ0JBOzs7O3dCQUl0Q0EsT0FBT0E7O3dCQUVOQTs7OzRDQUV1QkEsSUFBbUJBO29CQUUvQ0EsVUFBVUEsdUJBQWdCQTtvQkFDMUJBLElBQUlBO3dCQUVBQSw2QkFBZ0JBLEtBQUtBOzt3QkFHckJBLGdDQUFtQkEsS0FBS0E7OztvQkFHNUJBIiwKICAic291cmNlc0NvbnRlbnQiOiBbIi8vIDxDU0hUTUw1PjxYYW1sSGFzaD45MDNEMjFBN0I4RTVGOThGMDRFNTgzNjNFOTIxQjhFRDwvWGFtbEhhc2g+PFBhc3NOdW1iZXI+MjwvUGFzc051bWJlcj48Q29tcGlsYXRpb25EYXRlPjE0LzA5LzIwMjQgMjA6NTc6NDE8L0NvbXBpbGF0aW9uRGF0ZT48L0NTSFRNTDU+XHJcblxyXG5cclxuXHJcbnB1YmxpYyBzdGF0aWMgY2xhc3Mgx4DHgFF3Y8eAx4BDb21wb25lbnTHgMeAQXBwx4DHgFhhbWzHgMeARmFjdG9yeVxyXG57XHJcbiAgICBwdWJsaWMgc3RhdGljIG9iamVjdCBJbnN0YW50aWF0ZSgpXHJcbiAgICB7XHJcbiAgICAgICAgZ2xvYmFsOjpTeXN0ZW0uVHlwZSB0eXBlID0gdHlwZW9mKFFXQy5BcHApO1xyXG4gICAgICAgIHJldHVybiBnbG9iYWw6OkNTSFRNTDUuSW50ZXJuYWwuVHlwZUluc3RhbnRpYXRpb25IZWxwZXIuSW5zdGFudGlhdGUodHlwZSk7XHJcbiAgICB9XHJcbn1cclxuXHJcbm5hbWVzcGFjZSBRV0Ncclxue1xyXG5cclxuXHJcbi8vLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcbi8vIDxhdXRvLWdlbmVyYXRlZD5cclxuLy8gICAgIFRoaXMgY29kZSB3YXMgYXV0by1nZW5lcmF0ZWQgYnkgXCJDIy9YQU1MIGZvciBIVE1MNVwiXHJcbi8vXHJcbi8vICAgICBDaGFuZ2VzIHRvIHRoaXMgZmlsZSBtYXkgY2F1c2UgaW5jb3JyZWN0IGJlaGF2aW9yIGFuZCB3aWxsIGJlIGxvc3QgaWZcclxuLy8gICAgIHRoZSBjb2RlIGlzIHJlZ2VuZXJhdGVkLlxyXG4vLyA8L2F1dG8tZ2VuZXJhdGVkPlxyXG4vLy0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG5cclxuXHJcblxyXG5wYXJ0aWFsIGNsYXNzIEFwcCA6IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkFwcGxpY2F0aW9uXHJcbntcclxuXHJcbiNwcmFnbWEgd2FybmluZyBkaXNhYmxlIDE2OSwgNjQ5LCAwNjI4IC8vIFByZXZlbnRzIHdhcm5pbmcgQ1MwMTY5ICgnZmllbGQgLi4uIGlzIG5ldmVyIHVzZWQnKSwgQ1MwNjQ5ICgnZmllbGQgLi4uIGlzIG5ldmVyIGFzc2lnbmVkIHRvLCBhbmQgd2lsbCBhbHdheXMgaGF2ZSBpdHMgZGVmYXVsdCB2YWx1ZSBudWxsJyksIGFuZCBDUzA2MjggKCdtZW1iZXIgOiBuZXcgcHJvdGVjdGVkIG1lbWJlciBkZWNsYXJlZCBpbiBzZWFsZWQgY2xhc3MnKVxyXG5cclxuXHJcblxyXG4jcHJhZ21hIHdhcm5pbmcgcmVzdG9yZSAxNjksIDY0OSwgMDYyOFxyXG5cclxuXHJcbiAgICAgICAgcHJpdmF0ZSBib29sIF9jb250ZW50TG9hZGVkO1xyXG4gICAgICAgIHB1YmxpYyB2b2lkIEluaXRpYWxpemVDb21wb25lbnQoKVxyXG4gICAgICAgIHtcclxuICAgICAgICAgICAgaWYgKF9jb250ZW50TG9hZGVkKVxyXG4gICAgICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgICAgICBfY29udGVudExvYWRlZCA9IHRydWU7XHJcblxyXG4jcHJhZ21hIHdhcm5pbmcgZGlzYWJsZSAwMTg0IC8vIFByZXZlbnRzIHdhcm5pbmcgQ1MwMTg0ICgnVGhlIGdpdmVuIGV4cHJlc3Npb24gaXMgbmV2ZXIgb2YgdGhlIHByb3ZpZGVkICgndHlwZScpIHR5cGUnKVxyXG4gICAgICAgICAgICBpZiAodGhpcyBpcyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5VSUVsZW1lbnQpXHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICgoZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuVUlFbGVtZW50KShvYmplY3QpdGhpcykuWGFtbFNvdXJjZVBhdGggPSBAXCJRV0NcXEFwcC54YW1sXCI7XHJcbiAgICAgICAgICAgIH1cclxuI3ByYWdtYSB3YXJuaW5nIHJlc3RvcmUgMDE4NFxyXG5cclxuXHJcbmdsb2JhbDo6Q1NIVE1MNS5JbnRlcm5hbC5TdGFydHVwQXNzZW1ibHlJbmZvLk91dHB1dFJvb3RQYXRoID0gQFwiT3V0cHV0XFxcIjtcclxuZ2xvYmFsOjpDU0hUTUw1LkludGVybmFsLlN0YXJ0dXBBc3NlbWJseUluZm8uT3V0cHV0QXBwRmlsZXNQYXRoID0gQFwiYXBwLWNzaHRtbDVcXGFwcFxcXCI7XHJcbmdsb2JhbDo6Q1NIVE1MNS5JbnRlcm5hbC5TdGFydHVwQXNzZW1ibHlJbmZvLk91dHB1dExpYnJhcmllc1BhdGggPSBAXCJhcHAtY3NodG1sNVxcbGlic1xcXCI7XHJcbmdsb2JhbDo6Q1NIVE1MNS5JbnRlcm5hbC5TdGFydHVwQXNzZW1ibHlJbmZvLk91dHB1dFJlc291cmNlc1BhdGggPSBAXCJhcHAtY3NodG1sNVxccmVzXFxcIjtcclxuXHJcblxyXG52YXIgUmVzb3VyY2VEaWN0aW9uYXJ5XzYwNTI5Yzg0M2I4MDQ5MGE5ZmYxZmY5N2IzZTc0YTdhID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlJlc291cmNlRGljdGlvbmFyeSgpO1xyXG50aGlzLlJlc291cmNlcyA9IFJlc291cmNlRGljdGlvbmFyeV82MDUyOWM4NDNiODA0OTBhOWZmMWZmOTdiM2U3NGE3YTtcclxudmFyIEludENvbnZlcnRlcl80OGYzNzczMDcyZTc0ZGQ2OTI1MDI5M2VlYWViNTJjNCA9IG5ldyBnbG9iYWw6OkFQTEV4dGVuc2lvbi5JbnRDb252ZXJ0ZXIoKTtcclxuXHJcbnZhciBEZWNDb252ZXJ0ZXJfNDVlYTg0MGFjODUzNGExZjg1ODdmNTRkZDhlYzQxMzYgPSBuZXcgZ2xvYmFsOjpBUExFeHRlbnNpb24uRGVjQ29udmVydGVyKCk7XHJcblxyXG52YXIgVG9Qb2x5TGluZUNvbnZlcnRlcl80OGViNGFiYzNlZTk0Y2E3YTk3NzFkZTM5MjY5MGU1MSA9IG5ldyBnbG9iYWw6OkFQTEV4dGVuc2lvbi5Ub1BvbHlMaW5lQ29udmVydGVyKCk7XHJcblxyXG52YXIgVG9Qb2ludHNDb252ZXJ0ZXJfNmRiOTY2NDc0MDU4NDUyZGE4ZDk3MGI0MGM5NTM3MzIgPSBuZXcgZ2xvYmFsOjpBUExFeHRlbnNpb24uVG9Qb2ludHNDb252ZXJ0ZXIoKTtcclxuXHJcbnZhciBUb0xpbmVzQ29udmVydGVyXzAyNjlkZDg4MTU2ZjQ3ZmZiNmVkYmVkODViNmFiZWYwID0gbmV3IGdsb2JhbDo6QVBMRXh0ZW5zaW9uLlRvTGluZXNDb252ZXJ0ZXIoKTtcclxuXHJcbnZhciBBUExDb2xvckNvbnZlcnRlcl8wYmMxYmY1NmQwNTg0NzM0OTc3N2RhM2ZmMGJmNDIzZCA9IG5ldyBnbG9iYWw6OkFQTEV4dGVuc2lvbi5BUExDb2xvckNvbnZlcnRlcigpO1xyXG5cclxudmFyIEFQTENvbG9yQ1NTQ29udmVydGVyXzE4ZmQwMjNlZjdjMzQzYmNiOTQ4YWRlZDQzYzBhMjUwID0gbmV3IGdsb2JhbDo6QVBMRXh0ZW5zaW9uLkFQTENvbG9yQ1NTQ29udmVydGVyKCk7XHJcblxyXG52YXIgQVBMTXVsdGlDb2xvckNvbnZlcnRlcl9lMjExOGQ2YmU1YWY0ZmRhOGViMmRkZWY5ZGUyZTZmNiA9IG5ldyBnbG9iYWw6OkFQTEV4dGVuc2lvbi5BUExNdWx0aUNvbG9yQ29udmVydGVyKCk7XHJcblxyXG52YXIgQVBMTXVsdGlDb2xvckNTU0NvbnZlcnRlcl82ZTE5MDA0OGYzNzI0OGQ1YTg3YjE0ZGExMWZkZWU0YSA9IG5ldyBnbG9iYWw6OkFQTEV4dGVuc2lvbi5BUExNdWx0aUNvbG9yQ1NTQ29udmVydGVyKCk7XHJcblxyXG52YXIgSW5kZXhJbnQzMkNvbnZlcnRlcl9mMWI4MTZhMGQ5MjU0NDhmYTg2MTY2YzczMGFhMmQxOCA9IG5ldyBnbG9iYWw6OkFQTEV4dGVuc2lvbi5JbmRleEludDMyQ29udmVydGVyKCk7XHJcblxyXG52YXIgSW5kZXhEb3VibGVDb252ZXJ0ZXJfMjUxMGE4OGQ1MWQyNDhiNDgxODU0YTZhMTUyZTI3M2QgPSBuZXcgZ2xvYmFsOjpBUExFeHRlbnNpb24uSW5kZXhEb3VibGVDb252ZXJ0ZXIoKTtcclxuXHJcbnZhciBJbmRleFN0cmluZ0NvbnZlcnRlcl8wMDNjOWYxNTE4ZDE0YTE2YTZhN2Q3ZTU4MzExMjE2YSA9IG5ldyBnbG9iYWw6OkFQTEV4dGVuc2lvbi5JbmRleFN0cmluZ0NvbnZlcnRlcigpO1xyXG5cclxudmFyIEluZGV4QVBMQ29sb3JDb252ZXJ0ZXJfY2JhOGM3YjFjNWZjNGVjOTlmOTI4YjQwZmMxZmRhMTUgPSBuZXcgZ2xvYmFsOjpBUExFeHRlbnNpb24uSW5kZXhBUExDb2xvckNvbnZlcnRlcigpO1xyXG5cclxudmFyIEluZGV4QVBMQ29sb3VyQ29udmVydGVyXzMxOWEyY2YzYmNlZDQ5ZGM5Y2U5NDU2MDcxNDQzYzFhID0gbmV3IGdsb2JhbDo6QVBMRXh0ZW5zaW9uLkluZGV4QVBMQ29sb3VyQ29udmVydGVyKCk7XHJcblxyXG52YXIgTWF0aHNJQ29udmVydGVyX2VhZmY1NmI2NTgzYzQ5OTA5ZDE3MGE0YjgyNjc0MTkwID0gbmV3IGdsb2JhbDo6QVBMRXh0ZW5zaW9uLk1hdGhzSUNvbnZlcnRlcigpO1xyXG5cclxudmFyIE1hdGhzRENvbnZlcnRlcl80YzRlNjQ5NjEyNzQ0ZmNmYmM0YmYyNTcxMWEwNTQ0ZSA9IG5ldyBnbG9iYWw6OkFQTEV4dGVuc2lvbi5NYXRoc0RDb252ZXJ0ZXIoKTtcclxuXHJcbnZhciBNYXRoSUNvbnZlcnRlcl9jZjM2YjliZGM2NTg0Y2I2YWY5NzhjNmQzNWExYzViNSA9IG5ldyBnbG9iYWw6OkFQTEV4dGVuc2lvbi5NYXRoSUNvbnZlcnRlcigpO1xyXG5cclxudmFyIE1hdGhEQ29udmVydGVyX2YwZGFkMWY0M2E5ZTQ1YzNhODYwOTZhYjQ5Mzg2YzljID0gbmV3IGdsb2JhbDo6QVBMRXh0ZW5zaW9uLk1hdGhEQ29udmVydGVyKCk7XHJcblxyXG5nbG9iYWw6OlN5c3RlbS5TdHJpbmcgU3RyaW5nX2ZjMDk1ZjY3OTVhNzQ3Y2U5YzVmM2RhM2RmNzFiOGUxID0gQFwi4o6VV0MgQ3Jvc3MgUGxhdGZvcm1cIjtcclxuXHJcbmdsb2JhbDo6U3lzdGVtLlN0cmluZyBTdHJpbmdfY2IyMGY3ZTFjZDQxNGQwNTk3YTFiOTYxMzM0ODE5ZGYgPSBAXCJNSkggU29mdHdhcmUgU2VydmljZXMgTHRkXCI7XHJcblxyXG5nbG9iYWw6OlN5c3RlbS5TdHJpbmcgU3RyaW5nX2U1NjBlMTY0YmM5MTRiZDk5ZGRhOTc5Y2Q3MjkzYWI1ID0gQFwiTUpIIFNvZnR3YXJlIFNlcnZpY2VzIEx0ZFwiO1xyXG5cclxuZ2xvYmFsOjpTeXN0ZW0uU3RyaW5nIFN0cmluZ19hNWY4NDg2NmE4MWE0MTA4YjE3YWUzNDY0NTgxZWNlNyA9IEBcIlFXQ1wiO1xyXG5cclxuZ2xvYmFsOjpTeXN0ZW0uU3RyaW5nIFN0cmluZ19lNjlhZTQ5YWE1NmE0N2FjYjExZWQ0YTE4ZTMyY2I2NyA9IEBcIuKOlVdDIENyb3NzIFBsYXRmb3JtXCI7XHJcblxyXG5nbG9iYWw6OlN5c3RlbS5TdHJpbmcgU3RyaW5nX2I3YTNiMjBmZTAyZDRjYWNiNmJmMjA2ZTNmNDdlZGY2ID0gQFwibWpoLmljb1wiO1xyXG5cclxuZ2xvYmFsOjpTeXN0ZW0uU3RyaW5nIFN0cmluZ18wODE1NzI3Y2E0NmQ0ZjQ1ODgxNWNkYWU4MWJmZmVmOCA9IEBcIjEyMzQ1XCI7XHJcblxyXG5nbG9iYWw6OlN5c3RlbS5TdHJpbmcgU3RyaW5nXzI3NDRlNjZhNGM4MzQ1N2M5ZGQyNTI2ZWNkMTI2MDNmID0gQFwiTWFpblBhZ2VcIjtcclxuXHJcbmdsb2JhbDo6U3lzdGVtLlN0cmluZyBTdHJpbmdfNDY5NDM2MTA1ZTk3NDRhNmFjNWQxMjBkYzU4Nzc1ODQgPSBAXCJNYWluUGFnZTpQYWdlXCI7XHJcblxyXG5nbG9iYWw6OlN5c3RlbS5TdHJpbmcgU3RyaW5nXzFiY2E3YjUyNzEzMDRlM2U5OGFjNjBkYjk2MmFkYzE3ID0gQFwiRGlyZWN0XCI7XHJcblxyXG5nbG9iYWw6OlN5c3RlbS5TdHJpbmcgU3RyaW5nXzNhMzQyNWI3NjFkNzQ4Mjk5MDY4ZTk4OTU0ZTM4YTBhID0gQFwiUVdDXCI7XHJcblxyXG52YXIgU3R5bGVfMjAxMzJiYWU5MzM2NDcwMWI1ZjNmZWUxODU0ODAyNDggPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuU3R5bGUoKTtcclxuU3R5bGVfMjAxMzJiYWU5MzM2NDcwMWI1ZjNmZWUxODU0ODAyNDguVGFyZ2V0VHlwZSA9IHR5cGVvZihnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Db250cm9scy5DaGlsZFdpbmRvdyk7XHJcbnZhciBTZXR0ZXJfMDE3ZmFkYzQ3ZTVhNDQ2OGJmZmViN2Y0NmJkZjIyNDIgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuU2V0dGVyKCk7XHJcblNldHRlcl8wMTdmYWRjNDdlNWE0NDY4YmZmZWI3ZjQ2YmRmMjI0Mi5Qcm9wZXJ0eSA9IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkNvbnRyb2xzLkNoaWxkV2luZG93Lk92ZXJsYXlCcnVzaFByb3BlcnR5O1xyXG5TZXR0ZXJfMDE3ZmFkYzQ3ZTVhNDQ2OGJmZmViN2Y0NmJkZjIyNDIuVmFsdWUgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuTWVkaWEuU29saWRDb2xvckJydXNoKG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuQ29sb3IoKSB7IEEgPSAoYnl0ZSkwLCBSID0gKGJ5dGUpMjU1LCBHID0gKGJ5dGUpMjU1LCBCID0gKGJ5dGUpMjU1IH0pO1xyXG5cclxudmFyIFNldHRlcl85ZGYxYTdkZTU0ZmE0YjY2OWY2MjNkYjU3OGRjZjc5MSA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5TZXR0ZXIoKTtcclxuU2V0dGVyXzlkZjFhN2RlNTRmYTRiNjY5ZjYyM2RiNTc4ZGNmNzkxLlByb3BlcnR5ID0gZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuQ29udHJvbHMuQ2hpbGRXaW5kb3cuT3ZlcmxheU9wYWNpdHlQcm9wZXJ0eTtcclxuU2V0dGVyXzlkZjFhN2RlNTRmYTRiNjY5ZjYyM2RiNTc4ZGNmNzkxLlZhbHVlID0gMUQ7XHJcblxyXG52YXIgU2V0dGVyXzY1NTkwNmI1OGEwZTQ0YmZhN2I0MWVkZjQ1ODlmOGU0ID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlNldHRlcigpO1xyXG5TZXR0ZXJfNjU1OTA2YjU4YTBlNDRiZmE3YjQxZWRmNDU4OWY4ZTQuUHJvcGVydHkgPSBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Db250cm9scy5DaGlsZFdpbmRvdy5Ib3Jpem9udGFsQWxpZ25tZW50UHJvcGVydHk7XHJcblNldHRlcl82NTU5MDZiNThhMGU0NGJmYTdiNDFlZGY0NTg5ZjhlNC5WYWx1ZSA9IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkhvcml6b250YWxBbGlnbm1lbnQuTGVmdDtcclxuXHJcbnZhciBTZXR0ZXJfMWI0N2QwYmY1MjZhNDVhYjg3MzI1NDA4ZTkxYThlM2IgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuU2V0dGVyKCk7XHJcblNldHRlcl8xYjQ3ZDBiZjUyNmE0NWFiODczMjU0MDhlOTFhOGUzYi5Qcm9wZXJ0eSA9IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkNvbnRyb2xzLkNoaWxkV2luZG93LlZlcnRpY2FsQWxpZ25tZW50UHJvcGVydHk7XHJcblNldHRlcl8xYjQ3ZDBiZjUyNmE0NWFiODczMjU0MDhlOTFhOGUzYi5WYWx1ZSA9IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlZlcnRpY2FsQWxpZ25tZW50LlRvcDtcclxuXHJcbnZhciBTZXR0ZXJfMmM2ODJhNTY0OWE4NDg4MzhjYjc5NjJmYTNhZTRhYWEgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuU2V0dGVyKCk7XHJcblNldHRlcl8yYzY4MmE1NjQ5YTg0ODgzOGNiNzk2MmZhM2FlNGFhYS5Qcm9wZXJ0eSA9IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkNvbnRyb2xzLkNoaWxkV2luZG93LlRlbXBsYXRlUHJvcGVydHk7XHJcbnZhciBDb250cm9sVGVtcGxhdGVfZTYwNWMwY2YxZmVhNDM0OTg3NzUwY2E2MzM3NzkyOWQgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuQ29udHJvbHMuQ29udHJvbFRlbXBsYXRlKCk7XHJcbkNvbnRyb2xUZW1wbGF0ZV9lNjA1YzBjZjFmZWE0MzQ5ODc3NTBjYTYzMzc3OTI5ZC5UYXJnZXRUeXBlID0gdHlwZW9mKGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkNvbnRyb2xzLkNoaWxkV2luZG93KTtcclxuQ29udHJvbFRlbXBsYXRlX2U2MDVjMGNmMWZlYTQzNDk4Nzc1MGNhNjMzNzc5MjlkLlNldE1ldGhvZFRvSW5zdGFudGlhdGVGcmFtZXdvcmtUZW1wbGF0ZSgoU3lzdGVtLkZ1bmM8V2luZG93cy5VSS5YYW1sLkNvbnRyb2xzLkNvbnRyb2wsV2luZG93cy5VSS5YYW1sLlRlbXBsYXRlSW5zdGFuY2U+KSh0ZW1wbGF0ZU93bmVyX0NvbnRyb2xUZW1wbGF0ZV9lNjA1YzBjZjFmZWE0MzQ5ODc3NTBjYTYzMzc3OTI5ZCA9PiBcclxue1xyXG52YXIgdGVtcGxhdGVJbnN0YW5jZV82YzZhNTYxMTUzOTY0ZmI2YWM1MjczNWZmZjNmNTAzYyA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5UZW1wbGF0ZUluc3RhbmNlKCk7XHJcbnRlbXBsYXRlSW5zdGFuY2VfNmM2YTU2MTE1Mzk2NGZiNmFjNTI3MzVmZmYzZjUwM2MuVGVtcGxhdGVPd25lciA9IHRlbXBsYXRlT3duZXJfQ29udHJvbFRlbXBsYXRlX2U2MDVjMGNmMWZlYTQzNDk4Nzc1MGNhNjMzNzc5MjlkO1xyXG52YXIgVmlzdWFsU3RhdGVfNmQ1YTVkZTFkY2JjNGM0ZmIzMzhiNThjYjlmNzFhYmIgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuVmlzdWFsU3RhdGUoKTtcclxudmFyIFZpc3VhbFN0YXRlX2NjMTc5Y2YyMGYxNzRjZDBiMzYyMGE1Yzk4MzIwMjVhID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlZpc3VhbFN0YXRlKCk7XHJcbnZhciBWaXN1YWxTdGF0ZUdyb3VwX2MwOGEzNTIxNjU4NTQzNTFiZTQwYWFlNGNmMTIwYjIzID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlZpc3VhbFN0YXRlR3JvdXAoKTtcclxudmFyIEdyaWRfNzQ0MDcxMzgyMjdjNDI2NmE3NTQ4YmYxN2IyMDZiYWYgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuQ29udHJvbHMuR3JpZCgpO1xyXG52YXIgQnV0dG9uX2FiZGFlMzJmYmM4ZjRhNzZhMjA0NGEzNDc5MGIwZGFhID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkNvbnRyb2xzLkJ1dHRvbigpO1xyXG52YXIgQ29udGVudENvbnRyb2xfOGI4ZGQ2NmEwMTI5NDY2NGJhNWVlYmM0M2YyMjQwOGYgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuQ29udHJvbHMuQ29udGVudENvbnRyb2woKTtcclxudmFyIEJ1dHRvbl81OWYyNGExMjFhYmU0ZDJiYTg1ZDJmMzk0NDAxNzdhOSA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Db250cm9scy5CdXR0b24oKTtcclxudmFyIEJ1dHRvbl9jOWU3ZDczY2QyNGI0NWRmODNlODE5MWY4NTgyN2E1YyA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Db250cm9scy5CdXR0b24oKTtcclxudmFyIEJ1dHRvbl84ODc0MWI1ZTMwZTE0ZjVkYmJmMWEwODE5NGM2NmYyMSA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Db250cm9scy5CdXR0b24oKTtcclxudmFyIEJ1dHRvbl9hYmY0NDZlYzQ3YWU0MDRiODZhOThhZTNkYTQ1MDg0MyA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Db250cm9scy5CdXR0b24oKTtcclxudmFyIEJ1dHRvbl83YTFjYjNmZTFmYTE0ZmNiYmZiNzQ3MzMzNDE3YWIyNSA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Db250cm9scy5CdXR0b24oKTtcclxudmFyIEJvcmRlcl8zYzMwNWI4ODNhYTU0ZDE3OTg5MzBlMDI2ZmRmNmNhMyA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Db250cm9scy5Cb3JkZXIoKTtcclxudmFyIENvbnRlbnRQcmVzZW50ZXJfODg0MzI5NTY1M2U5NGNjZDgxZDYxZTM5OGVjNzA1MTQgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuQ29udHJvbHMuQ29udGVudFByZXNlbnRlcigpO1xyXG52YXIgQm9yZGVyX2E4ZTUwY2I1MmU1YTRkMGU4NWI5NzdhMjE3MWE1Njc4ID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkNvbnRyb2xzLkJvcmRlcigpO1xyXG52YXIgQm9yZGVyX2JiNzhiMDJlMDU5MjQ3OWJiMWNlNGVmZTU5YTNmYTUyID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkNvbnRyb2xzLkJvcmRlcigpO1xyXG52YXIgR3JpZF81OWI5ZGE3MmJhNjA0MDY2YTRkODI0YzUwNTI2ZjU4YSA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Db250cm9scy5HcmlkKCk7XHJcbnRlbXBsYXRlT3duZXJfQ29udHJvbFRlbXBsYXRlX2U2MDVjMGNmMWZlYTQzNDk4Nzc1MGNhNjMzNzc5MjlkLlJlZ2lzdGVyTmFtZShcIlJvb3RcIiwgR3JpZF81OWI5ZGE3MmJhNjA0MDY2YTRkODI0YzUwNTI2ZjU4YSk7XHJcbkdyaWRfNTliOWRhNzJiYTYwNDA2NmE0ZDgyNGM1MDUyNmY1OGEuTmFtZSA9IFwiUm9vdFwiO1xyXG5HcmlkXzU5YjlkYTcyYmE2MDQwNjZhNGQ4MjRjNTA1MjZmNThhLlJlbmRlclRyYW5zZm9ybU9yaWdpbiA9IG5ldyBnbG9iYWw6OldpbmRvd3MuRm91bmRhdGlvbi5Qb2ludCgwLCAwKTtcclxudGVtcGxhdGVPd25lcl9Db250cm9sVGVtcGxhdGVfZTYwNWMwY2YxZmVhNDM0OTg3NzUwY2E2MzM3NzkyOWQuUmVnaXN0ZXJOYW1lKFwiTW9kYWxTdGF0ZXNcIiwgVmlzdWFsU3RhdGVHcm91cF9jMDhhMzUyMTY1ODU0MzUxYmU0MGFhZTRjZjEyMGIyMyk7XHJcblZpc3VhbFN0YXRlR3JvdXBfYzA4YTM1MjE2NTg1NDM1MWJlNDBhYWU0Y2YxMjBiMjMuTmFtZSA9IFwiTW9kYWxTdGF0ZXNcIjtcclxudGVtcGxhdGVPd25lcl9Db250cm9sVGVtcGxhdGVfZTYwNWMwY2YxZmVhNDM0OTg3NzUwY2E2MzM3NzkyOWQuUmVnaXN0ZXJOYW1lKFwiTm90TW9kYWxcIiwgVmlzdWFsU3RhdGVfNmQ1YTVkZTFkY2JjNGM0ZmIzMzhiNThjYjlmNzFhYmIpO1xyXG5WaXN1YWxTdGF0ZV82ZDVhNWRlMWRjYmM0YzRmYjMzOGI1OGNiOWY3MWFiYi5OYW1lID0gXCJOb3RNb2RhbFwiO1xyXG52YXIgU3Rvcnlib2FyZF8xNjFiOWM4YTFkYjE0ZmYxOTRhMjgzODRjNGE4ZDY5ZCA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5NZWRpYS5BbmltYXRpb24uU3Rvcnlib2FyZCgpO1xyXG52YXIgT2JqZWN0QW5pbWF0aW9uVXNpbmdLZXlGcmFtZXNfNmRlYzRkYzEwNTA3NDc3NjljOGI1YzRjMDIyMWFiMDMgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuTWVkaWEuQW5pbWF0aW9uLk9iamVjdEFuaW1hdGlvblVzaW5nS2V5RnJhbWVzKCk7XHJcbmdsb2JhbDo6V2luZG93cy5VSS5YYW1sLk1lZGlhLkFuaW1hdGlvbi5TdG9yeWJvYXJkLlNldFRhcmdldE5hbWUoT2JqZWN0QW5pbWF0aW9uVXNpbmdLZXlGcmFtZXNfNmRlYzRkYzEwNTA3NDc3NjljOGI1YzRjMDIyMWFiMDMsQFwiT3ZlcmxheVwiKTtcclxudmFyIERpc2NyZXRlT2JqZWN0S2V5RnJhbWVfZDY0ODU5NTE3MWUwNDE4ZmI2Zjc0MmIyZDQ2NGRjOGIgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuTWVkaWEuQW5pbWF0aW9uLkRpc2NyZXRlT2JqZWN0S2V5RnJhbWUoKTtcclxudmFyIE51bGxFeHRlbnNpb25fYzM5OTUyMTU1NTEyNGY0YzlhYmI0YTk5NWIyZDAwMmQgPSBuZXcgZ2xvYmFsOjpTeXN0ZW0uV2luZG93cy5NYXJrdXAuTnVsbEV4dGVuc2lvbigpO1xyXG5cclxuRGlzY3JldGVPYmplY3RLZXlGcmFtZV9kNjQ4NTk1MTcxZTA0MThmYjZmNzQyYjJkNDY0ZGM4Yi5WYWx1ZSA9IG51bGw7XHJcblxyXG5cclxuT2JqZWN0QW5pbWF0aW9uVXNpbmdLZXlGcmFtZXNfNmRlYzRkYzEwNTA3NDc3NjljOGI1YzRjMDIyMWFiMDMuS2V5RnJhbWVzLkFkZChEaXNjcmV0ZU9iamVjdEtleUZyYW1lX2Q2NDg1OTUxNzFlMDQxOGZiNmY3NDJiMmQ0NjRkYzhiKTtcclxuXHJcblxyXG52YXIgT2JqZWN0QW5pbWF0aW9uVXNpbmdLZXlGcmFtZXNfYTRmYmMwOTA0YmFjNDc0M2JmMzQyZGEwODk1NjNkYzUgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuTWVkaWEuQW5pbWF0aW9uLk9iamVjdEFuaW1hdGlvblVzaW5nS2V5RnJhbWVzKCk7XHJcbmdsb2JhbDo6V2luZG93cy5VSS5YYW1sLk1lZGlhLkFuaW1hdGlvbi5TdG9yeWJvYXJkLlNldFRhcmdldE5hbWUoT2JqZWN0QW5pbWF0aW9uVXNpbmdLZXlGcmFtZXNfYTRmYmMwOTA0YmFjNDc0M2JmMzQyZGEwODk1NjNkYzUsQFwiT3ZlcmxheVwiKTtcclxudmFyIERpc2NyZXRlT2JqZWN0S2V5RnJhbWVfZjA0ODBjNmU3MzdlNGNkYTg3ZjNiNjU4NmUzOTNhZDEgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuTWVkaWEuQW5pbWF0aW9uLkRpc2NyZXRlT2JqZWN0S2V5RnJhbWUoKTtcclxuRGlzY3JldGVPYmplY3RLZXlGcmFtZV9mMDQ4MGM2ZTczN2U0Y2RhODdmM2I2NTg2ZTM5M2FkMS5WYWx1ZSA9IEBcIkZhbHNlXCI7XHJcblxyXG5PYmplY3RBbmltYXRpb25Vc2luZ0tleUZyYW1lc19hNGZiYzA5MDRiYWM0NzQzYmYzNDJkYTA4OTU2M2RjNS5LZXlGcmFtZXMuQWRkKERpc2NyZXRlT2JqZWN0S2V5RnJhbWVfZjA0ODBjNmU3MzdlNGNkYTg3ZjNiNjU4NmUzOTNhZDEpO1xyXG5cclxuXHJcblN0b3J5Ym9hcmRfMTYxYjljOGExZGIxNGZmMTk0YTI4Mzg0YzRhOGQ2OWQuQ2hpbGRyZW4uQWRkKE9iamVjdEFuaW1hdGlvblVzaW5nS2V5RnJhbWVzXzZkZWM0ZGMxMDUwNzQ3NzY5YzhiNWM0YzAyMjFhYjAzKTtcclxuU3Rvcnlib2FyZF8xNjFiOWM4YTFkYjE0ZmYxOTRhMjgzODRjNGE4ZDY5ZC5DaGlsZHJlbi5BZGQoT2JqZWN0QW5pbWF0aW9uVXNpbmdLZXlGcmFtZXNfYTRmYmMwOTA0YmFjNDc0M2JmMzQyZGEwODk1NjNkYzUpO1xyXG5cclxuXHJcblZpc3VhbFN0YXRlXzZkNWE1ZGUxZGNiYzRjNGZiMzM4YjU4Y2I5ZjcxYWJiLlN0b3J5Ym9hcmQgPSBTdG9yeWJvYXJkXzE2MWI5YzhhMWRiMTRmZjE5NGEyODM4NGM0YThkNjlkO1xyXG5cclxuXHJcbnRlbXBsYXRlT3duZXJfQ29udHJvbFRlbXBsYXRlX2U2MDVjMGNmMWZlYTQzNDk4Nzc1MGNhNjMzNzc5MjlkLlJlZ2lzdGVyTmFtZShcIk1vZGFsXCIsIFZpc3VhbFN0YXRlX2NjMTc5Y2YyMGYxNzRjZDBiMzYyMGE1Yzk4MzIwMjVhKTtcclxuVmlzdWFsU3RhdGVfY2MxNzljZjIwZjE3NGNkMGIzNjIwYTVjOTgzMjAyNWEuTmFtZSA9IFwiTW9kYWxcIjtcclxuXHJcblZpc3VhbFN0YXRlR3JvdXBfYzA4YTM1MjE2NTg1NDM1MWJlNDBhYWU0Y2YxMjBiMjMuU3RhdGVzLkFkZChWaXN1YWxTdGF0ZV82ZDVhNWRlMWRjYmM0YzRmYjMzOGI1OGNiOWY3MWFiYik7XHJcblZpc3VhbFN0YXRlR3JvdXBfYzA4YTM1MjE2NTg1NDM1MWJlNDBhYWU0Y2YxMjBiMjMuU3RhdGVzLkFkZChWaXN1YWxTdGF0ZV9jYzE3OWNmMjBmMTc0Y2QwYjM2MjBhNWM5ODMyMDI1YSk7XHJcblxyXG5cclxudGVtcGxhdGVPd25lcl9Db250cm9sVGVtcGxhdGVfZTYwNWMwY2YxZmVhNDM0OTg3NzUwY2E2MzM3NzkyOWQuSU5URVJOQUxfR2V0VmlzdWFsU3RhdGVHcm91cHMoKS5BZGQoVmlzdWFsU3RhdGVHcm91cF9jMDhhMzUyMTY1ODU0MzUxYmU0MGFhZTRjZjEyMGIyMyk7XHJcblxyXG50ZW1wbGF0ZU93bmVyX0NvbnRyb2xUZW1wbGF0ZV9lNjA1YzBjZjFmZWE0MzQ5ODc3NTBjYTYzMzc3OTI5ZC5SZWdpc3Rlck5hbWUoXCJPdmVybGF5XCIsIEdyaWRfNzQ0MDcxMzgyMjdjNDI2NmE3NTQ4YmYxN2IyMDZiYWYpO1xyXG5HcmlkXzc0NDA3MTM4MjI3YzQyNjZhNzU0OGJmMTdiMjA2YmFmLk5hbWUgPSBcIk92ZXJsYXlcIjtcclxuR3JpZF83NDQwNzEzODIyN2M0MjY2YTc1NDhiZjE3YjIwNmJhZi5Ib3Jpem9udGFsQWxpZ25tZW50ID0gZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuSG9yaXpvbnRhbEFsaWdubWVudC5TdHJldGNoO1xyXG5HcmlkXzc0NDA3MTM4MjI3YzQyNjZhNzU0OGJmMTdiMjA2YmFmLlZlcnRpY2FsQWxpZ25tZW50ID0gZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuVmVydGljYWxBbGlnbm1lbnQuU3RyZXRjaDtcclxuR3JpZF83NDQwNzEzODIyN2M0MjY2YTc1NDhiZjE3YjIwNmJhZi5NYXJnaW4gPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuVGhpY2tuZXNzKDApO1xyXG52YXIgQmluZGluZ19kYTk3YWU1MTQyNzA0NDM1YTEzMzEzMzQxNzIxNmE3OCA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmcoKTtcclxuQmluZGluZ19kYTk3YWU1MTQyNzA0NDM1YTEzMzEzMzQxNzIxNmE3OC5QYXRoID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlByb3BlcnR5UGF0aChAXCJPdmVybGF5QnJ1c2hcIik7XHJcbnZhciBSZWxhdGl2ZVNvdXJjZV8zNjIzMWJhZTQxZmI0ZTNlYWQ1YjVmNmMxMjRhNmU3MCA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLlJlbGF0aXZlU291cmNlKCk7XHJcblJlbGF0aXZlU291cmNlXzM2MjMxYmFlNDFmYjRlM2VhZDViNWY2YzEyNGE2ZTcwLk1vZGUgPSBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLlJlbGF0aXZlU291cmNlTW9kZS5UZW1wbGF0ZWRQYXJlbnQ7XHJcblxyXG5CaW5kaW5nX2RhOTdhZTUxNDI3MDQ0MzVhMTMzMTMzNDE3MjE2YTc4LlJlbGF0aXZlU291cmNlID0gUmVsYXRpdmVTb3VyY2VfMzYyMzFiYWU0MWZiNGUzZWFkNWI1ZjZjMTI0YTZlNzA7XHJcblxyXG5cclxuQmluZGluZ19kYTk3YWU1MTQyNzA0NDM1YTEzMzEzMzQxNzIxNmE3OC5UZW1wbGF0ZU93bmVyID0gdGVtcGxhdGVJbnN0YW5jZV82YzZhNTYxMTUzOTY0ZmI2YWM1MjczNWZmZjNmNTAzYztcclxuXHJcbnZhciBCaW5kaW5nXzYyMDFjM2MxNDRhOTRmNzliNjBjYzcwZDc5N2RmYzRhID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuQmluZGluZygpO1xyXG5CaW5kaW5nXzYyMDFjM2MxNDRhOTRmNzliNjBjYzcwZDc5N2RmYzRhLlBhdGggPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuUHJvcGVydHlQYXRoKEBcIk92ZXJsYXlPcGFjaXR5XCIpO1xyXG52YXIgUmVsYXRpdmVTb3VyY2VfNjJkODQ5YmFhMmJjNDQ3YzkyMGRiYTE5NmQyZmQzNTMgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5SZWxhdGl2ZVNvdXJjZSgpO1xyXG5SZWxhdGl2ZVNvdXJjZV82MmQ4NDliYWEyYmM0NDdjOTIwZGJhMTk2ZDJmZDM1My5Nb2RlID0gZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5SZWxhdGl2ZVNvdXJjZU1vZGUuVGVtcGxhdGVkUGFyZW50O1xyXG5cclxuQmluZGluZ182MjAxYzNjMTQ0YTk0Zjc5YjYwY2M3MGQ3OTdkZmM0YS5SZWxhdGl2ZVNvdXJjZSA9IFJlbGF0aXZlU291cmNlXzYyZDg0OWJhYTJiYzQ0N2M5MjBkYmExOTZkMmZkMzUzO1xyXG5cclxuXHJcbkJpbmRpbmdfNjIwMWMzYzE0NGE5NGY3OWI2MGNjNzBkNzk3ZGZjNGEuVGVtcGxhdGVPd25lciA9IHRlbXBsYXRlSW5zdGFuY2VfNmM2YTU2MTE1Mzk2NGZiNmFjNTI3MzVmZmYzZjUwM2M7XHJcblxyXG5cclxudGVtcGxhdGVPd25lcl9Db250cm9sVGVtcGxhdGVfZTYwNWMwY2YxZmVhNDM0OTg3NzUwY2E2MzM3NzkyOWQuUmVnaXN0ZXJOYW1lKFwiQ29udGVudFJvb3RcIiwgQm9yZGVyX2JiNzhiMDJlMDU5MjQ3OWJiMWNlNGVmZTU5YTNmYTUyKTtcclxuQm9yZGVyX2JiNzhiMDJlMDU5MjQ3OWJiMWNlNGVmZTU5YTNmYTUyLk5hbWUgPSBcIkNvbnRlbnRSb290XCI7XHJcbnRlbXBsYXRlT3duZXJfQ29udHJvbFRlbXBsYXRlX2U2MDVjMGNmMWZlYTQzNDk4Nzc1MGNhNjMzNzc5MjlkLlJlZ2lzdGVyTmFtZShcIkNvbnRlbnRDb250YWluZXJcIiwgQm9yZGVyX2E4ZTUwY2I1MmU1YTRkMGU4NWI5NzdhMjE3MWE1Njc4KTtcclxuQm9yZGVyX2E4ZTUwY2I1MmU1YTRkMGU4NWI5NzdhMjE3MWE1Njc4Lk5hbWUgPSBcIkNvbnRlbnRDb250YWluZXJcIjtcclxuQm9yZGVyX2E4ZTUwY2I1MmU1YTRkMGU4NWI5NzdhMjE3MWE1Njc4LkJhY2tncm91bmQgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuTWVkaWEuU29saWRDb2xvckJydXNoKG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuQ29sb3IoKSB7IEEgPSAoYnl0ZSkyNTUsIFIgPSAoYnl0ZSkyNDYsIEcgPSAoYnl0ZSkyNDYsIEIgPSAoYnl0ZSkyNDYgfSk7XHJcbkJvcmRlcl9hOGU1MGNiNTJlNWE0ZDBlODViOTc3YTIxNzFhNTY3OC5Db3JuZXJSYWRpdXMgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuQ29ybmVyUmFkaXVzKDIpO1xyXG52YXIgR3JpZF80MjYyOGQyNzRkODM0NDgzYjYxMTk0MjBiMTkwOWZhZiA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Db250cm9scy5HcmlkKCk7XHJcbnZhciBSb3dEZWZpbml0aW9uXzE5YzYzZjkyMjExMzQwMDRhNDAxMzg2M2I5MTBlMWEyID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkNvbnRyb2xzLlJvd0RlZmluaXRpb24oKTtcclxuUm93RGVmaW5pdGlvbl8xOWM2M2Y5MjIxMTM0MDA0YTQwMTM4NjNiOTEwZTFhMi5IZWlnaHQgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuR3JpZExlbmd0aCgxLjAsIGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkdyaWRVbml0VHlwZS5BdXRvKTtcclxuXHJcbnZhciBSb3dEZWZpbml0aW9uX2Q2OTIzYTExM2JhMTQxMTk4NDQ4MmI4YWRhZmI2OGM4ID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkNvbnRyb2xzLlJvd0RlZmluaXRpb24oKTtcclxuUm93RGVmaW5pdGlvbl9kNjkyM2ExMTNiYTE0MTE5ODQ0ODJiOGFkYWZiNjhjOC5IZWlnaHQgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuR3JpZExlbmd0aCgxLjAsIGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkdyaWRVbml0VHlwZS5TdGFyKTtcclxuXHJcbkdyaWRfNDI2MjhkMjc0ZDgzNDQ4M2I2MTE5NDIwYjE5MDlmYWYuUm93RGVmaW5pdGlvbnMuQWRkKFJvd0RlZmluaXRpb25fMTljNjNmOTIyMTEzNDAwNGE0MDEzODYzYjkxMGUxYTIpO1xyXG5HcmlkXzQyNjI4ZDI3NGQ4MzQ0ODNiNjExOTQyMGIxOTA5ZmFmLlJvd0RlZmluaXRpb25zLkFkZChSb3dEZWZpbml0aW9uX2Q2OTIzYTExM2JhMTQxMTk4NDQ4MmI4YWRhZmI2OGM4KTtcclxuXHJcbnRlbXBsYXRlT3duZXJfQ29udHJvbFRlbXBsYXRlX2U2MDVjMGNmMWZlYTQzNDk4Nzc1MGNhNjMzNzc5MjlkLlJlZ2lzdGVyTmFtZShcIkNocm9tZVwiLCBCb3JkZXJfM2MzMDViODgzYWE1NGQxNzk4OTMwZTAyNmZkZjZjYTMpO1xyXG5Cb3JkZXJfM2MzMDViODgzYWE1NGQxNzk4OTMwZTAyNmZkZjZjYTMuTmFtZSA9IFwiQ2hyb21lXCI7XHJcbkJvcmRlcl8zYzMwNWI4ODNhYTU0ZDE3OTg5MzBlMDI2ZmRmNmNhMy5XaWR0aCA9IGdsb2JhbDo6U3lzdGVtLkRvdWJsZS5OYU47XHJcbkJvcmRlcl8zYzMwNWI4ODNhYTU0ZDE3OTg5MzBlMDI2ZmRmNmNhMy5Cb3JkZXJCcnVzaCA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5NZWRpYS5Tb2xpZENvbG9yQnJ1c2gobmV3IGdsb2JhbDo6V2luZG93cy5VSS5Db2xvcigpIHsgQSA9IChieXRlKTI1NSwgUiA9IChieXRlKTI1NSwgRyA9IChieXRlKTI1NSwgQiA9IChieXRlKTI1NSB9KTtcclxuQm9yZGVyXzNjMzA1Yjg4M2FhNTRkMTc5ODkzMGUwMjZmZGY2Y2EzLkJvcmRlclRoaWNrbmVzcyA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5UaGlja25lc3MoMCwgMCwgMCwgMCk7XHJcbkJvcmRlcl8zYzMwNWI4ODNhYTU0ZDE3OTg5MzBlMDI2ZmRmNmNhMy5CYWNrZ3JvdW5kID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLk1lZGlhLlNvbGlkQ29sb3JCcnVzaChuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLkNvbG9yKCkgeyBBID0gKGJ5dGUpMjU1LCBSID0gKGJ5dGUpMjM4LCBHID0gKGJ5dGUpMjM4LCBCID0gKGJ5dGUpMjM4IH0pO1xyXG52YXIgR3JpZF82YzBhNmFkN2UxZDU0ODdhYjZlYWIzNzc1NGY1N2IwYSA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Db250cm9scy5HcmlkKCk7XHJcbnZhciBDb2x1bW5EZWZpbml0aW9uXzE3ZmQ3MzRkMGE0ZjQyY2Q4NTA2ZDRhMzE5YmE3ODE3ID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkNvbnRyb2xzLkNvbHVtbkRlZmluaXRpb24oKTtcclxuQ29sdW1uRGVmaW5pdGlvbl8xN2ZkNzM0ZDBhNGY0MmNkODUwNmQ0YTMxOWJhNzgxNy5XaWR0aCA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5HcmlkTGVuZ3RoKDEuMCwgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuR3JpZFVuaXRUeXBlLkF1dG8pO1xyXG5cclxudmFyIENvbHVtbkRlZmluaXRpb25fZTc5ZDY2NjA5ZDAzNDg3ZTk2YjQ5ZWFkYWMwZGQ1MDQgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuQ29udHJvbHMuQ29sdW1uRGVmaW5pdGlvbigpO1xyXG5Db2x1bW5EZWZpbml0aW9uX2U3OWQ2NjYwOWQwMzQ4N2U5NmI0OWVhZGFjMGRkNTA0LldpZHRoID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkdyaWRMZW5ndGgoMS4wLCBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5HcmlkVW5pdFR5cGUuU3Rhcik7XHJcblxyXG52YXIgQ29sdW1uRGVmaW5pdGlvbl83Y2Y3MDRiNjZkZjI0MjNmOGZiNGE2YzljZjA4MDg4MCA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Db250cm9scy5Db2x1bW5EZWZpbml0aW9uKCk7XHJcbkNvbHVtbkRlZmluaXRpb25fN2NmNzA0YjY2ZGYyNDIzZjhmYjRhNmM5Y2YwODA4ODAuV2lkdGggPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuR3JpZExlbmd0aCgxLjAsIGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkdyaWRVbml0VHlwZS5BdXRvKTtcclxuXHJcbnZhciBDb2x1bW5EZWZpbml0aW9uXzcxOTRiMGQwMTc2ODQxMGQ5ZDUxZTA3MmNlNjY0NmFkID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkNvbnRyb2xzLkNvbHVtbkRlZmluaXRpb24oKTtcclxuQ29sdW1uRGVmaW5pdGlvbl83MTk0YjBkMDE3Njg0MTBkOWQ1MWUwNzJjZTY2NDZhZC5XaWR0aCA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5HcmlkTGVuZ3RoKDEuMCwgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuR3JpZFVuaXRUeXBlLkF1dG8pO1xyXG5cclxudmFyIENvbHVtbkRlZmluaXRpb25fNGVkN2NmOTViZWEwNDcyZTg3MmZhMWU3Mjg3N2IyMTcgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuQ29udHJvbHMuQ29sdW1uRGVmaW5pdGlvbigpO1xyXG5Db2x1bW5EZWZpbml0aW9uXzRlZDdjZjk1YmVhMDQ3MmU4NzJmYTFlNzI4NzdiMjE3LldpZHRoID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkdyaWRMZW5ndGgoMS4wLCBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5HcmlkVW5pdFR5cGUuQXV0byk7XHJcblxyXG52YXIgQ29sdW1uRGVmaW5pdGlvbl9jODczYTAzODczM2M0ZjBiYmU2ZjEzYjRjZGYwNmQ1ZiA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Db250cm9scy5Db2x1bW5EZWZpbml0aW9uKCk7XHJcbkNvbHVtbkRlZmluaXRpb25fYzg3M2EwMzg3MzNjNGYwYmJlNmYxM2I0Y2RmMDZkNWYuV2lkdGggPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuR3JpZExlbmd0aCgxLjAsIGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkdyaWRVbml0VHlwZS5BdXRvKTtcclxuXHJcbnZhciBDb2x1bW5EZWZpbml0aW9uXzY2ZjVhZjc0MGQ2NDQ0ZDI4OGE5N2ZhNDNjMTJjMDJkID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkNvbnRyb2xzLkNvbHVtbkRlZmluaXRpb24oKTtcclxuQ29sdW1uRGVmaW5pdGlvbl82NmY1YWY3NDBkNjQ0NGQyODhhOTdmYTQzYzEyYzAyZC5XaWR0aCA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5HcmlkTGVuZ3RoKDEuMCwgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuR3JpZFVuaXRUeXBlLkF1dG8pO1xyXG5cclxuR3JpZF82YzBhNmFkN2UxZDU0ODdhYjZlYWIzNzc1NGY1N2IwYS5Db2x1bW5EZWZpbml0aW9ucy5BZGQoQ29sdW1uRGVmaW5pdGlvbl8xN2ZkNzM0ZDBhNGY0MmNkODUwNmQ0YTMxOWJhNzgxNyk7XHJcbkdyaWRfNmMwYTZhZDdlMWQ1NDg3YWI2ZWFiMzc3NTRmNTdiMGEuQ29sdW1uRGVmaW5pdGlvbnMuQWRkKENvbHVtbkRlZmluaXRpb25fZTc5ZDY2NjA5ZDAzNDg3ZTk2YjQ5ZWFkYWMwZGQ1MDQpO1xyXG5HcmlkXzZjMGE2YWQ3ZTFkNTQ4N2FiNmVhYjM3NzU0ZjU3YjBhLkNvbHVtbkRlZmluaXRpb25zLkFkZChDb2x1bW5EZWZpbml0aW9uXzdjZjcwNGI2NmRmMjQyM2Y4ZmI0YTZjOWNmMDgwODgwKTtcclxuR3JpZF82YzBhNmFkN2UxZDU0ODdhYjZlYWIzNzc1NGY1N2IwYS5Db2x1bW5EZWZpbml0aW9ucy5BZGQoQ29sdW1uRGVmaW5pdGlvbl83MTk0YjBkMDE3Njg0MTBkOWQ1MWUwNzJjZTY2NDZhZCk7XHJcbkdyaWRfNmMwYTZhZDdlMWQ1NDg3YWI2ZWFiMzc3NTRmNTdiMGEuQ29sdW1uRGVmaW5pdGlvbnMuQWRkKENvbHVtbkRlZmluaXRpb25fNGVkN2NmOTViZWEwNDcyZTg3MmZhMWU3Mjg3N2IyMTcpO1xyXG5HcmlkXzZjMGE2YWQ3ZTFkNTQ4N2FiNmVhYjM3NzU0ZjU3YjBhLkNvbHVtbkRlZmluaXRpb25zLkFkZChDb2x1bW5EZWZpbml0aW9uX2M4NzNhMDM4NzMzYzRmMGJiZTZmMTNiNGNkZjA2ZDVmKTtcclxuR3JpZF82YzBhNmFkN2UxZDU0ODdhYjZlYWIzNzc1NGY1N2IwYS5Db2x1bW5EZWZpbml0aW9ucy5BZGQoQ29sdW1uRGVmaW5pdGlvbl82NmY1YWY3NDBkNjQ0NGQyODhhOTdmYTQzYzEyYzAyZCk7XHJcblxyXG50ZW1wbGF0ZU93bmVyX0NvbnRyb2xUZW1wbGF0ZV9lNjA1YzBjZjFmZWE0MzQ5ODc3NTBjYTYzMzc3OTI5ZC5SZWdpc3Rlck5hbWUoXCJJY29uQnV0dG9uXCIsIEJ1dHRvbl9hYmRhZTMyZmJjOGY0YTc2YTIwNDRhMzQ3OTBiMGRhYSk7XHJcbkJ1dHRvbl9hYmRhZTMyZmJjOGY0YTc2YTIwNDRhMzQ3OTBiMGRhYS5OYW1lID0gXCJJY29uQnV0dG9uXCI7XHJcbkJ1dHRvbl9hYmRhZTMyZmJjOGY0YTc2YTIwNDRhMzQ3OTBiMGRhYS5Ib3Jpem9udGFsQWxpZ25tZW50ID0gZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuSG9yaXpvbnRhbEFsaWdubWVudC5MZWZ0O1xyXG5CdXR0b25fYWJkYWUzMmZiYzhmNGE3NmEyMDQ0YTM0NzkwYjBkYWEuVmVydGljYWxBbGlnbm1lbnQgPSBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5WZXJ0aWNhbEFsaWdubWVudC5DZW50ZXI7XHJcbkJ1dHRvbl9hYmRhZTMyZmJjOGY0YTc2YTIwNDRhMzQ3OTBiMGRhYS5Ib3Jpem9udGFsQ29udGVudEFsaWdubWVudCA9IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkhvcml6b250YWxBbGlnbm1lbnQuQ2VudGVyO1xyXG5CdXR0b25fYWJkYWUzMmZiYzhmNGE3NmEyMDQ0YTM0NzkwYjBkYWEuVmVydGljYWxDb250ZW50QWxpZ25tZW50ID0gZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuVmVydGljYWxBbGlnbm1lbnQuQ2VudGVyO1xyXG5CdXR0b25fYWJkYWUzMmZiYzhmNGE3NmEyMDQ0YTM0NzkwYjBkYWEuV2lkdGggPSAyMEQ7XHJcbkJ1dHRvbl9hYmRhZTMyZmJjOGY0YTc2YTIwNDRhMzQ3OTBiMGRhYS5QYWRkaW5nID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlRoaWNrbmVzcygwKTtcclxudmFyIEltYWdlXzBlZjRjNWUzYjJjNTQ2OTA4Y2MyNGI4YWRkYjVhNDhhID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkNvbnRyb2xzLkltYWdlKCk7XHJcbnZhciBCaW5kaW5nXzBmMTJiMzM1ZjA4ZDRkZWU5ZGE1OTYxYTk4MWZhYTQxID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuQmluZGluZygpO1xyXG5CaW5kaW5nXzBmMTJiMzM1ZjA4ZDRkZWU5ZGE1OTYxYTk4MWZhYTQxLlBhdGggPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuUHJvcGVydHlQYXRoKEBcIkljb25cIik7XHJcblxyXG5cclxuXHJcbkJ1dHRvbl9hYmRhZTMyZmJjOGY0YTc2YTIwNDRhMzQ3OTBiMGRhYS5Db250ZW50ID0gSW1hZ2VfMGVmNGM1ZTNiMmM1NDY5MDhjYzI0YjhhZGRiNWE0OGE7XHJcblxyXG52YXIgQmluZGluZ185OWE0MGYxZGQ2MTc0NWQxYWYwNmZkNDdkYzQyNjk2NSA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmcoKTtcclxuQmluZGluZ185OWE0MGYxZGQ2MTc0NWQxYWYwNmZkNDdkYzQyNjk2NS5QYXRoID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlByb3BlcnR5UGF0aChAXCJJY29uVmlzaWJpbGl0eVwiKTtcclxuXHJcblxyXG5cclxudGVtcGxhdGVPd25lcl9Db250cm9sVGVtcGxhdGVfZTYwNWMwY2YxZmVhNDM0OTg3NzUwY2E2MzM3NzkyOWQuUmVnaXN0ZXJOYW1lKFwiVGl0bGVcIiwgQ29udGVudENvbnRyb2xfOGI4ZGQ2NmEwMTI5NDY2NGJhNWVlYmM0M2YyMjQwOGYpO1xyXG5Db250ZW50Q29udHJvbF84YjhkZDY2YTAxMjk0NjY0YmE1ZWViYzQzZjIyNDA4Zi5OYW1lID0gXCJUaXRsZVwiO1xyXG5nbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Db250cm9scy5HcmlkLlNldENvbHVtbihDb250ZW50Q29udHJvbF84YjhkZDY2YTAxMjk0NjY0YmE1ZWViYzQzZjIyNDA4ZiwxKTtcclxuQ29udGVudENvbnRyb2xfOGI4ZGQ2NmEwMTI5NDY2NGJhNWVlYmM0M2YyMjQwOGYuSG9yaXpvbnRhbEFsaWdubWVudCA9IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkhvcml6b250YWxBbGlnbm1lbnQuTGVmdDtcclxuQ29udGVudENvbnRyb2xfOGI4ZGQ2NmEwMTI5NDY2NGJhNWVlYmM0M2YyMjQwOGYuVmVydGljYWxBbGlnbm1lbnQgPSBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5WZXJ0aWNhbEFsaWdubWVudC5DZW50ZXI7XHJcbkNvbnRlbnRDb250cm9sXzhiOGRkNjZhMDEyOTQ2NjRiYTVlZWJjNDNmMjI0MDhmLk1hcmdpbiA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5UaGlja25lc3MoNiwgMCwgNiwgMCk7XHJcbnZhciBCaW5kaW5nX2MwOTA1ZTY0NGJhNjQyNzJhY2E4MDhmYzFhZTQzZjEyID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuQmluZGluZygpO1xyXG5CaW5kaW5nX2MwOTA1ZTY0NGJhNjQyNzJhY2E4MDhmYzFhZTQzZjEyLlBhdGggPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuUHJvcGVydHlQYXRoKEBcIlRpdGxlXCIpO1xyXG52YXIgUmVsYXRpdmVTb3VyY2VfNDAzZDFkZTVjZDA0NDAwNGJhNzZlZDEwZTVhOTMzNmIgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5SZWxhdGl2ZVNvdXJjZSgpO1xyXG5SZWxhdGl2ZVNvdXJjZV80MDNkMWRlNWNkMDQ0MDA0YmE3NmVkMTBlNWE5MzM2Yi5Nb2RlID0gZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5SZWxhdGl2ZVNvdXJjZU1vZGUuVGVtcGxhdGVkUGFyZW50O1xyXG5cclxuQmluZGluZ19jMDkwNWU2NDRiYTY0MjcyYWNhODA4ZmMxYWU0M2YxMi5SZWxhdGl2ZVNvdXJjZSA9IFJlbGF0aXZlU291cmNlXzQwM2QxZGU1Y2QwNDQwMDRiYTc2ZWQxMGU1YTkzMzZiO1xyXG5cclxuXHJcbkJpbmRpbmdfYzA5MDVlNjQ0YmE2NDI3MmFjYTgwOGZjMWFlNDNmMTIuVGVtcGxhdGVPd25lciA9IHRlbXBsYXRlSW5zdGFuY2VfNmM2YTU2MTE1Mzk2NGZiNmFjNTI3MzVmZmYzZjUwM2M7XHJcblxyXG5cclxudGVtcGxhdGVPd25lcl9Db250cm9sVGVtcGxhdGVfZTYwNWMwY2YxZmVhNDM0OTg3NzUwY2E2MzM3NzkyOWQuUmVnaXN0ZXJOYW1lKFwiSGVscEJ1dHRvblwiLCBCdXR0b25fNTlmMjRhMTIxYWJlNGQyYmE4NWQyZjM5NDQwMTc3YTkpO1xyXG5CdXR0b25fNTlmMjRhMTIxYWJlNGQyYmE4NWQyZjM5NDQwMTc3YTkuTmFtZSA9IFwiSGVscEJ1dHRvblwiO1xyXG5CdXR0b25fNTlmMjRhMTIxYWJlNGQyYmE4NWQyZjM5NDQwMTc3YTkuSG9yaXpvbnRhbEFsaWdubWVudCA9IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkhvcml6b250YWxBbGlnbm1lbnQuUmlnaHQ7XHJcbkJ1dHRvbl81OWYyNGExMjFhYmU0ZDJiYTg1ZDJmMzk0NDAxNzdhOS5WZXJ0aWNhbEFsaWdubWVudCA9IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlZlcnRpY2FsQWxpZ25tZW50LkNlbnRlcjtcclxuZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuQ29udHJvbHMuR3JpZC5TZXRDb2x1bW4oQnV0dG9uXzU5ZjI0YTEyMWFiZTRkMmJhODVkMmYzOTQ0MDE3N2E5LDIpO1xyXG5CdXR0b25fNTlmMjRhMTIxYWJlNGQyYmE4NWQyZjM5NDQwMTc3YTkuSG9yaXpvbnRhbENvbnRlbnRBbGlnbm1lbnQgPSBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Ib3Jpem9udGFsQWxpZ25tZW50LkNlbnRlcjtcclxuQnV0dG9uXzU5ZjI0YTEyMWFiZTRkMmJhODVkMmYzOTQ0MDE3N2E5LlZlcnRpY2FsQ29udGVudEFsaWdubWVudCA9IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlZlcnRpY2FsQWxpZ25tZW50LkNlbnRlcjtcclxuQnV0dG9uXzU5ZjI0YTEyMWFiZTRkMmJhODVkMmYzOTQ0MDE3N2E5LldpZHRoID0gMjBEO1xyXG5CdXR0b25fNTlmMjRhMTIxYWJlNGQyYmE4NWQyZjM5NDQwMTc3YTkuUGFkZGluZyA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5UaGlja25lc3MoMCk7XHJcbnZhciBJbWFnZV84MjczNmI4MTQxYTk0ZDA2OTU2YjY1NDQ2MzYwMWFjNCA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Db250cm9scy5JbWFnZSgpO1xyXG52YXIgQmluZGluZ19kOWI5NGU2NGVkNTc0ZjkyOTRiY2YxODVhYmI2YzYyNiA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmcoKTtcclxuQmluZGluZ19kOWI5NGU2NGVkNTc0ZjkyOTRiY2YxODVhYmI2YzYyNi5QYXRoID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlByb3BlcnR5UGF0aChAXCJIZWxwSWNvblwiKTtcclxuXHJcblxyXG5cclxuQnV0dG9uXzU5ZjI0YTEyMWFiZTRkMmJhODVkMmYzOTQ0MDE3N2E5LkNvbnRlbnQgPSBJbWFnZV84MjczNmI4MTQxYTk0ZDA2OTU2YjY1NDQ2MzYwMWFjNDtcclxuXHJcbnZhciBCaW5kaW5nXzQ5NWIwN2ZlYWJlYTQwNDg4MDQ1NjRhZDZhODRmNDJmID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuQmluZGluZygpO1xyXG5CaW5kaW5nXzQ5NWIwN2ZlYWJlYTQwNDg4MDQ1NjRhZDZhODRmNDJmLlBhdGggPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuUHJvcGVydHlQYXRoKEBcIkhlbHBWaXNpYmlsaXR5XCIpO1xyXG5cclxuXHJcblxyXG50ZW1wbGF0ZU93bmVyX0NvbnRyb2xUZW1wbGF0ZV9lNjA1YzBjZjFmZWE0MzQ5ODc3NTBjYTYzMzc3OTI5ZC5SZWdpc3Rlck5hbWUoXCJNaW5CdXR0b25cIiwgQnV0dG9uX2M5ZTdkNzNjZDI0YjQ1ZGY4M2U4MTkxZjg1ODI3YTVjKTtcclxuQnV0dG9uX2M5ZTdkNzNjZDI0YjQ1ZGY4M2U4MTkxZjg1ODI3YTVjLk5hbWUgPSBcIk1pbkJ1dHRvblwiO1xyXG5CdXR0b25fYzllN2Q3M2NkMjRiNDVkZjgzZTgxOTFmODU4MjdhNWMuSG9yaXpvbnRhbEFsaWdubWVudCA9IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkhvcml6b250YWxBbGlnbm1lbnQuUmlnaHQ7XHJcbkJ1dHRvbl9jOWU3ZDczY2QyNGI0NWRmODNlODE5MWY4NTgyN2E1Yy5WZXJ0aWNhbEFsaWdubWVudCA9IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlZlcnRpY2FsQWxpZ25tZW50LkNlbnRlcjtcclxuZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuQ29udHJvbHMuR3JpZC5TZXRDb2x1bW4oQnV0dG9uX2M5ZTdkNzNjZDI0YjQ1ZGY4M2U4MTkxZjg1ODI3YTVjLDMpO1xyXG5CdXR0b25fYzllN2Q3M2NkMjRiNDVkZjgzZTgxOTFmODU4MjdhNWMuSG9yaXpvbnRhbENvbnRlbnRBbGlnbm1lbnQgPSBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Ib3Jpem9udGFsQWxpZ25tZW50LkNlbnRlcjtcclxuQnV0dG9uX2M5ZTdkNzNjZDI0YjQ1ZGY4M2U4MTkxZjg1ODI3YTVjLlZlcnRpY2FsQ29udGVudEFsaWdubWVudCA9IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlZlcnRpY2FsQWxpZ25tZW50LkNlbnRlcjtcclxuQnV0dG9uX2M5ZTdkNzNjZDI0YjQ1ZGY4M2U4MTkxZjg1ODI3YTVjLldpZHRoID0gMjBEO1xyXG5CdXR0b25fYzllN2Q3M2NkMjRiNDVkZjgzZTgxOTFmODU4MjdhNWMuUGFkZGluZyA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5UaGlja25lc3MoMCk7XHJcbkJ1dHRvbl9jOWU3ZDczY2QyNGI0NWRmODNlODE5MWY4NTgyN2E1Yy5DbGljayArPSBSdW5DbGlja01pbjtcclxudmFyIEltYWdlXzZmNTBhMTU3YTcxZTQ5OWNiZjQ2YTJmZWI5M2MyOGI0ID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkNvbnRyb2xzLkltYWdlKCk7XHJcbnZhciBCaW5kaW5nX2Q1MGI0ZjU5ZGVhODRlNjY4NjRjOTQ4MGZlODU1ZGU4ID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuQmluZGluZygpO1xyXG5CaW5kaW5nX2Q1MGI0ZjU5ZGVhODRlNjY4NjRjOTQ4MGZlODU1ZGU4LlBhdGggPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuUHJvcGVydHlQYXRoKEBcIk1pblJlc0ljb25cIik7XHJcblxyXG5cclxuXHJcbkJ1dHRvbl9jOWU3ZDczY2QyNGI0NWRmODNlODE5MWY4NTgyN2E1Yy5Db250ZW50ID0gSW1hZ2VfNmY1MGExNTdhNzFlNDk5Y2JmNDZhMmZlYjkzYzI4YjQ7XHJcblxyXG52YXIgQmluZGluZ19kNGY1MjI1YzQ3NGM0YTQwYTlmMTQzNzYxYWE4NGU0YiA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmcoKTtcclxuQmluZGluZ19kNGY1MjI1YzQ3NGM0YTQwYTlmMTQzNzYxYWE4NGU0Yi5QYXRoID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlByb3BlcnR5UGF0aChAXCJNaW5WaXNpYmlsaXR5XCIpO1xyXG5cclxuXHJcblxyXG50ZW1wbGF0ZU93bmVyX0NvbnRyb2xUZW1wbGF0ZV9lNjA1YzBjZjFmZWE0MzQ5ODc3NTBjYTYzMzc3OTI5ZC5SZWdpc3Rlck5hbWUoXCJNYXhCdXR0b25cIiwgQnV0dG9uXzg4NzQxYjVlMzBlMTRmNWRiYmYxYTA4MTk0YzY2ZjIxKTtcclxuQnV0dG9uXzg4NzQxYjVlMzBlMTRmNWRiYmYxYTA4MTk0YzY2ZjIxLk5hbWUgPSBcIk1heEJ1dHRvblwiO1xyXG5CdXR0b25fODg3NDFiNWUzMGUxNGY1ZGJiZjFhMDgxOTRjNjZmMjEuSG9yaXpvbnRhbEFsaWdubWVudCA9IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkhvcml6b250YWxBbGlnbm1lbnQuUmlnaHQ7XHJcbkJ1dHRvbl84ODc0MWI1ZTMwZTE0ZjVkYmJmMWEwODE5NGM2NmYyMS5WZXJ0aWNhbEFsaWdubWVudCA9IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlZlcnRpY2FsQWxpZ25tZW50LkNlbnRlcjtcclxuZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuQ29udHJvbHMuR3JpZC5TZXRDb2x1bW4oQnV0dG9uXzg4NzQxYjVlMzBlMTRmNWRiYmYxYTA4MTk0YzY2ZjIxLDQpO1xyXG5CdXR0b25fODg3NDFiNWUzMGUxNGY1ZGJiZjFhMDgxOTRjNjZmMjEuSG9yaXpvbnRhbENvbnRlbnRBbGlnbm1lbnQgPSBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Ib3Jpem9udGFsQWxpZ25tZW50LkNlbnRlcjtcclxuQnV0dG9uXzg4NzQxYjVlMzBlMTRmNWRiYmYxYTA4MTk0YzY2ZjIxLlZlcnRpY2FsQ29udGVudEFsaWdubWVudCA9IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlZlcnRpY2FsQWxpZ25tZW50LkNlbnRlcjtcclxuQnV0dG9uXzg4NzQxYjVlMzBlMTRmNWRiYmYxYTA4MTk0YzY2ZjIxLldpZHRoID0gMjBEO1xyXG5CdXR0b25fODg3NDFiNWUzMGUxNGY1ZGJiZjFhMDgxOTRjNjZmMjEuUGFkZGluZyA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5UaGlja25lc3MoMCk7XHJcbkJ1dHRvbl84ODc0MWI1ZTMwZTE0ZjVkYmJmMWEwODE5NGM2NmYyMS5DbGljayArPSBSdW5DbGlja01heDtcclxudmFyIEltYWdlXzM1ZWZiMzQwYWI0MzQyMjI4N2I2YTUyNmI2OTUwZDE1ID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkNvbnRyb2xzLkltYWdlKCk7XHJcbnZhciBCaW5kaW5nXzY2MTgzMDk2MzI5MzQyNGQ5MGYwMzdmNDcxOTIzN2VhID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuQmluZGluZygpO1xyXG5CaW5kaW5nXzY2MTgzMDk2MzI5MzQyNGQ5MGYwMzdmNDcxOTIzN2VhLlBhdGggPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuUHJvcGVydHlQYXRoKEBcIk1heFJlc0ljb25cIik7XHJcblxyXG5cclxuXHJcbkJ1dHRvbl84ODc0MWI1ZTMwZTE0ZjVkYmJmMWEwODE5NGM2NmYyMS5Db250ZW50ID0gSW1hZ2VfMzVlZmIzNDBhYjQzNDIyMjg3YjZhNTI2YjY5NTBkMTU7XHJcblxyXG52YXIgQmluZGluZ185MmYzZjEwNDc5ZTk0MDcyYWM5Y2I4NWZhNTFkNGZlZCA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmcoKTtcclxuQmluZGluZ185MmYzZjEwNDc5ZTk0MDcyYWM5Y2I4NWZhNTFkNGZlZC5QYXRoID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlByb3BlcnR5UGF0aChAXCJNYXhWaXNpYmlsaXR5XCIpO1xyXG5cclxuXHJcblxyXG50ZW1wbGF0ZU93bmVyX0NvbnRyb2xUZW1wbGF0ZV9lNjA1YzBjZjFmZWE0MzQ5ODc3NTBjYTYzMzc3OTI5ZC5SZWdpc3Rlck5hbWUoXCJGdWxsU2NyZWVuQnV0dG9uXCIsIEJ1dHRvbl9hYmY0NDZlYzQ3YWU0MDRiODZhOThhZTNkYTQ1MDg0Myk7XHJcbkJ1dHRvbl9hYmY0NDZlYzQ3YWU0MDRiODZhOThhZTNkYTQ1MDg0My5OYW1lID0gXCJGdWxsU2NyZWVuQnV0dG9uXCI7XHJcbkJ1dHRvbl9hYmY0NDZlYzQ3YWU0MDRiODZhOThhZTNkYTQ1MDg0My5Ib3Jpem9udGFsQWxpZ25tZW50ID0gZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuSG9yaXpvbnRhbEFsaWdubWVudC5SaWdodDtcclxuQnV0dG9uX2FiZjQ0NmVjNDdhZTQwNGI4NmE5OGFlM2RhNDUwODQzLlZlcnRpY2FsQWxpZ25tZW50ID0gZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuVmVydGljYWxBbGlnbm1lbnQuQ2VudGVyO1xyXG5nbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Db250cm9scy5HcmlkLlNldENvbHVtbihCdXR0b25fYWJmNDQ2ZWM0N2FlNDA0Yjg2YTk4YWUzZGE0NTA4NDMsNSk7XHJcbkJ1dHRvbl9hYmY0NDZlYzQ3YWU0MDRiODZhOThhZTNkYTQ1MDg0My5Ib3Jpem9udGFsQ29udGVudEFsaWdubWVudCA9IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkhvcml6b250YWxBbGlnbm1lbnQuQ2VudGVyO1xyXG5CdXR0b25fYWJmNDQ2ZWM0N2FlNDA0Yjg2YTk4YWUzZGE0NTA4NDMuVmVydGljYWxDb250ZW50QWxpZ25tZW50ID0gZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuVmVydGljYWxBbGlnbm1lbnQuQ2VudGVyO1xyXG5CdXR0b25fYWJmNDQ2ZWM0N2FlNDA0Yjg2YTk4YWUzZGE0NTA4NDMuV2lkdGggPSAyMEQ7XHJcbkJ1dHRvbl9hYmY0NDZlYzQ3YWU0MDRiODZhOThhZTNkYTQ1MDg0My5QYWRkaW5nID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlRoaWNrbmVzcygwKTtcclxuQnV0dG9uX2FiZjQ0NmVjNDdhZTQwNGI4NmE5OGFlM2RhNDUwODQzLkNsaWNrICs9IFJ1bkNsaWNrRnVsbFNjcmVlbjtcclxudmFyIEltYWdlXzk3MmQ0N2Q5MjlkODQxOTE4MDBhYWEwMWYxZDU0ZTEzID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkNvbnRyb2xzLkltYWdlKCk7XHJcbnZhciBCaW5kaW5nXzk0MzA5MThhMTZhODQ3NjhhMjU1NzA5ZTNjNWQyMDUzID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuQmluZGluZygpO1xyXG5CaW5kaW5nXzk0MzA5MThhMTZhODQ3NjhhMjU1NzA5ZTNjNWQyMDUzLlBhdGggPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuUHJvcGVydHlQYXRoKEBcIkZ1bGxTY3JlZW5JY29uXCIpO1xyXG5cclxuXHJcblxyXG5CdXR0b25fYWJmNDQ2ZWM0N2FlNDA0Yjg2YTk4YWUzZGE0NTA4NDMuQ29udGVudCA9IEltYWdlXzk3MmQ0N2Q5MjlkODQxOTE4MDBhYWEwMWYxZDU0ZTEzO1xyXG5cclxudmFyIEJpbmRpbmdfZDQyOGE2M2U2NjZiNGRlODg1ZGE4MjQwYzMxNDA2MDEgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5CaW5kaW5nKCk7XHJcbkJpbmRpbmdfZDQyOGE2M2U2NjZiNGRlODg1ZGE4MjQwYzMxNDA2MDEuUGF0aCA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Qcm9wZXJ0eVBhdGgoQFwiRnVsbFNjcmVlblZpc2liaWxpdHlcIik7XHJcblxyXG5cclxuXHJcbnRlbXBsYXRlT3duZXJfQ29udHJvbFRlbXBsYXRlX2U2MDVjMGNmMWZlYTQzNDk4Nzc1MGNhNjMzNzc5MjlkLlJlZ2lzdGVyTmFtZShcIkNsb3NlQnV0dG9uXCIsIEJ1dHRvbl83YTFjYjNmZTFmYTE0ZmNiYmZiNzQ3MzMzNDE3YWIyNSk7XHJcbkJ1dHRvbl83YTFjYjNmZTFmYTE0ZmNiYmZiNzQ3MzMzNDE3YWIyNS5OYW1lID0gXCJDbG9zZUJ1dHRvblwiO1xyXG5CdXR0b25fN2ExY2IzZmUxZmExNGZjYmJmYjc0NzMzMzQxN2FiMjUuSG9yaXpvbnRhbEFsaWdubWVudCA9IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkhvcml6b250YWxBbGlnbm1lbnQuUmlnaHQ7XHJcbkJ1dHRvbl83YTFjYjNmZTFmYTE0ZmNiYmZiNzQ3MzMzNDE3YWIyNS5WZXJ0aWNhbEFsaWdubWVudCA9IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlZlcnRpY2FsQWxpZ25tZW50LkNlbnRlcjtcclxuZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuQ29udHJvbHMuR3JpZC5TZXRDb2x1bW4oQnV0dG9uXzdhMWNiM2ZlMWZhMTRmY2JiZmI3NDczMzM0MTdhYjI1LDYpO1xyXG5CdXR0b25fN2ExY2IzZmUxZmExNGZjYmJmYjc0NzMzMzQxN2FiMjUuSG9yaXpvbnRhbENvbnRlbnRBbGlnbm1lbnQgPSBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Ib3Jpem9udGFsQWxpZ25tZW50LkNlbnRlcjtcclxuQnV0dG9uXzdhMWNiM2ZlMWZhMTRmY2JiZmI3NDczMzM0MTdhYjI1LlZlcnRpY2FsQ29udGVudEFsaWdubWVudCA9IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlZlcnRpY2FsQWxpZ25tZW50LkNlbnRlcjtcclxuQnV0dG9uXzdhMWNiM2ZlMWZhMTRmY2JiZmI3NDczMzM0MTdhYjI1LldpZHRoID0gMjBEO1xyXG5CdXR0b25fN2ExY2IzZmUxZmExNGZjYmJmYjc0NzMzMzQxN2FiMjUuUGFkZGluZyA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5UaGlja25lc3MoMCk7XHJcbkJ1dHRvbl83YTFjYjNmZTFmYTE0ZmNiYmZiNzQ3MzMzNDE3YWIyNS5DbGljayArPSBSdW5DbGlja0Nsb3NlO1xyXG52YXIgSW1hZ2VfNzQ3ZTY2NzRjM2VkNGNkOThiYmE4MDdiODQ4NjIzMzYgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuQ29udHJvbHMuSW1hZ2UoKTtcclxudmFyIEJpbmRpbmdfMzFjZWY3MmNmMGQwNGM0MmE3N2ViZjk1ZThiYTBkMDggPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5CaW5kaW5nKCk7XHJcbkJpbmRpbmdfMzFjZWY3MmNmMGQwNGM0MmE3N2ViZjk1ZThiYTBkMDguUGF0aCA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Qcm9wZXJ0eVBhdGgoQFwiQ2xvc2VJY29uXCIpO1xyXG5cclxuXHJcblxyXG5CdXR0b25fN2ExY2IzZmUxZmExNGZjYmJmYjc0NzMzMzQxN2FiMjUuQ29udGVudCA9IEltYWdlXzc0N2U2Njc0YzNlZDRjZDk4YmJhODA3Yjg0ODYyMzM2O1xyXG5cclxudmFyIEJpbmRpbmdfMTQ5NWQ4NTI3MDZkNGFhNjk5ZmY4YzhlMDFiZDI4MzIgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5CaW5kaW5nKCk7XHJcbkJpbmRpbmdfMTQ5NWQ4NTI3MDZkNGFhNjk5ZmY4YzhlMDFiZDI4MzIuUGF0aCA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Qcm9wZXJ0eVBhdGgoQFwiQ2xvc2VWaXNpYmlsaXR5XCIpO1xyXG5cclxuXHJcblxyXG5HcmlkXzZjMGE2YWQ3ZTFkNTQ4N2FiNmVhYjM3NzU0ZjU3YjBhLkNoaWxkcmVuLkFkZChCdXR0b25fYWJkYWUzMmZiYzhmNGE3NmEyMDQ0YTM0NzkwYjBkYWEpO1xyXG5HcmlkXzZjMGE2YWQ3ZTFkNTQ4N2FiNmVhYjM3NzU0ZjU3YjBhLkNoaWxkcmVuLkFkZChDb250ZW50Q29udHJvbF84YjhkZDY2YTAxMjk0NjY0YmE1ZWViYzQzZjIyNDA4Zik7XHJcbkdyaWRfNmMwYTZhZDdlMWQ1NDg3YWI2ZWFiMzc3NTRmNTdiMGEuQ2hpbGRyZW4uQWRkKEJ1dHRvbl81OWYyNGExMjFhYmU0ZDJiYTg1ZDJmMzk0NDAxNzdhOSk7XHJcbkdyaWRfNmMwYTZhZDdlMWQ1NDg3YWI2ZWFiMzc3NTRmNTdiMGEuQ2hpbGRyZW4uQWRkKEJ1dHRvbl9jOWU3ZDczY2QyNGI0NWRmODNlODE5MWY4NTgyN2E1Yyk7XHJcbkdyaWRfNmMwYTZhZDdlMWQ1NDg3YWI2ZWFiMzc3NTRmNTdiMGEuQ2hpbGRyZW4uQWRkKEJ1dHRvbl84ODc0MWI1ZTMwZTE0ZjVkYmJmMWEwODE5NGM2NmYyMSk7XHJcbkdyaWRfNmMwYTZhZDdlMWQ1NDg3YWI2ZWFiMzc3NTRmNTdiMGEuQ2hpbGRyZW4uQWRkKEJ1dHRvbl9hYmY0NDZlYzQ3YWU0MDRiODZhOThhZTNkYTQ1MDg0Myk7XHJcbkdyaWRfNmMwYTZhZDdlMWQ1NDg3YWI2ZWFiMzc3NTRmNTdiMGEuQ2hpbGRyZW4uQWRkKEJ1dHRvbl83YTFjYjNmZTFmYTE0ZmNiYmZiNzQ3MzMzNDE3YWIyNSk7XHJcblxyXG5cclxuQm9yZGVyXzNjMzA1Yjg4M2FhNTRkMTc5ODkzMGUwMjZmZGY2Y2EzLkNoaWxkID0gR3JpZF82YzBhNmFkN2UxZDU0ODdhYjZlYWIzNzc1NGY1N2IwYTtcclxuXHJcbnZhciBCaW5kaW5nXzg1NTBhNjhlYzA1NzRkOTk5MTY4YThhNjQyZmE5Yzk2ID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuQmluZGluZygpO1xyXG5CaW5kaW5nXzg1NTBhNjhlYzA1NzRkOTk5MTY4YThhNjQyZmE5Yzk2LlBhdGggPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuUHJvcGVydHlQYXRoKEBcIlRpdGxlVmlzaWJpbGl0eVwiKTtcclxuXHJcblxyXG5cclxudmFyIEJvcmRlcl8xYzRjM2UwZTQxNzc0NWI4YmJkNTIzYTdhNWExNTUyOSA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Db250cm9scy5Cb3JkZXIoKTtcclxuZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuQ29udHJvbHMuR3JpZC5TZXRSb3coQm9yZGVyXzFjNGMzZTBlNDE3NzQ1YjhiYmQ1MjNhN2E1YTE1NTI5LDEpO1xyXG5Cb3JkZXJfMWM0YzNlMGU0MTc3NDViOGJiZDUyM2E3YTVhMTU1MjkuQm9yZGVyVGhpY2tuZXNzID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlRoaWNrbmVzcygwLCAwLCAwLCAwKTtcclxudGVtcGxhdGVPd25lcl9Db250cm9sVGVtcGxhdGVfZTYwNWMwY2YxZmVhNDM0OTg3NzUwY2E2MzM3NzkyOWQuUmVnaXN0ZXJOYW1lKFwiRm9ybUNvbnRlbnRQcmVzZW50ZXJcIiwgQ29udGVudFByZXNlbnRlcl84ODQzMjk1NjUzZTk0Y2NkODFkNjFlMzk4ZWM3MDUxNCk7XHJcbkNvbnRlbnRQcmVzZW50ZXJfODg0MzI5NTY1M2U5NGNjZDgxZDYxZTM5OGVjNzA1MTQuTmFtZSA9IFwiRm9ybUNvbnRlbnRQcmVzZW50ZXJcIjtcclxuQ29udGVudFByZXNlbnRlcl84ODQzMjk1NjUzZTk0Y2NkODFkNjFlMzk4ZWM3MDUxNC5DbGlwVG9Cb3VuZHMgPSB0cnVlO1xyXG52YXIgQmluZGluZ18yYTdmMDIyNDJiMTM0NWU3YTNjNDMzY2Y2NzhjOGZiYiA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmcoKTtcclxuQmluZGluZ18yYTdmMDIyNDJiMTM0NWU3YTNjNDMzY2Y2NzhjOGZiYi5QYXRoID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlByb3BlcnR5UGF0aChAXCJDb250ZW50XCIpO1xyXG52YXIgUmVsYXRpdmVTb3VyY2VfNmE2MzM4MGMwOWM5NDEzM2JmMjY1M2NkNTg5MzE1NzQgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5SZWxhdGl2ZVNvdXJjZSgpO1xyXG5SZWxhdGl2ZVNvdXJjZV82YTYzMzgwYzA5Yzk0MTMzYmYyNjUzY2Q1ODkzMTU3NC5Nb2RlID0gZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5SZWxhdGl2ZVNvdXJjZU1vZGUuVGVtcGxhdGVkUGFyZW50O1xyXG5cclxuQmluZGluZ18yYTdmMDIyNDJiMTM0NWU3YTNjNDMzY2Y2NzhjOGZiYi5SZWxhdGl2ZVNvdXJjZSA9IFJlbGF0aXZlU291cmNlXzZhNjMzODBjMDljOTQxMzNiZjI2NTNjZDU4OTMxNTc0O1xyXG5cclxuXHJcbkJpbmRpbmdfMmE3ZjAyMjQyYjEzNDVlN2EzYzQzM2NmNjc4YzhmYmIuVGVtcGxhdGVPd25lciA9IHRlbXBsYXRlSW5zdGFuY2VfNmM2YTU2MTE1Mzk2NGZiNmFjNTI3MzVmZmYzZjUwM2M7XHJcblxyXG52YXIgQmluZGluZ19iN2FjMDNkZTcwODU0M2VhYWY2MDY3ODRmMGUzOGEwMiA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmcoKTtcclxuQmluZGluZ19iN2FjMDNkZTcwODU0M2VhYWY2MDY3ODRmMGUzOGEwMi5QYXRoID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlByb3BlcnR5UGF0aChAXCJDb250ZW50VGVtcGxhdGVcIik7XHJcbnZhciBSZWxhdGl2ZVNvdXJjZV85NzczNDVjMjg5M2Q0YmJiOGQxZDE3MmJlZTI0Y2E3NiA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLlJlbGF0aXZlU291cmNlKCk7XHJcblJlbGF0aXZlU291cmNlXzk3NzM0NWMyODkzZDRiYmI4ZDFkMTcyYmVlMjRjYTc2Lk1vZGUgPSBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLlJlbGF0aXZlU291cmNlTW9kZS5UZW1wbGF0ZWRQYXJlbnQ7XHJcblxyXG5CaW5kaW5nX2I3YWMwM2RlNzA4NTQzZWFhZjYwNjc4NGYwZTM4YTAyLlJlbGF0aXZlU291cmNlID0gUmVsYXRpdmVTb3VyY2VfOTc3MzQ1YzI4OTNkNGJiYjhkMWQxNzJiZWUyNGNhNzY7XHJcblxyXG5cclxuQmluZGluZ19iN2FjMDNkZTcwODU0M2VhYWY2MDY3ODRmMGUzOGEwMi5UZW1wbGF0ZU93bmVyID0gdGVtcGxhdGVJbnN0YW5jZV82YzZhNTYxMTUzOTY0ZmI2YWM1MjczNWZmZjNmNTAzYztcclxuXHJcbnZhciBCaW5kaW5nX2UzYzZmYzI0YzNhMjRkYTI4NDg1NTg0ZjU4NjQ1NDk1ID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuQmluZGluZygpO1xyXG5CaW5kaW5nX2UzYzZmYzI0YzNhMjRkYTI4NDg1NTg0ZjU4NjQ1NDk1LlBhdGggPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuUHJvcGVydHlQYXRoKEBcIkNsaWVudFdpZHRoXCIpO1xyXG5cclxuXHJcbnZhciBCaW5kaW5nX2M1MmI5NGFiYjI4NTQ2MDg4NTY3YmYxMDA3ZWM2M2YyID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuQmluZGluZygpO1xyXG5CaW5kaW5nX2M1MmI5NGFiYjI4NTQ2MDg4NTY3YmYxMDA3ZWM2M2YyLlBhdGggPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuUHJvcGVydHlQYXRoKEBcIkNsaWVudEhlaWdodFwiKTtcclxuXHJcblxyXG52YXIgQmluZGluZ182MTM4YTc2NzRmOTg0MGVmOTgzNGZlNzIwNDg5ZjBlNCA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmcoKTtcclxuQmluZGluZ182MTM4YTc2NzRmOTg0MGVmOTgzNGZlNzIwNDg5ZjBlNC5QYXRoID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlByb3BlcnR5UGF0aChAXCJIb3Jpem9udGFsQWxpZ25tZW50XCIpO1xyXG52YXIgUmVsYXRpdmVTb3VyY2VfOTQ4YzE5NTdiZTM1NGI0MTk2NzZiMDI1MzZhN2E4MWIgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5SZWxhdGl2ZVNvdXJjZSgpO1xyXG5SZWxhdGl2ZVNvdXJjZV85NDhjMTk1N2JlMzU0YjQxOTY3NmIwMjUzNmE3YTgxYi5Nb2RlID0gZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5SZWxhdGl2ZVNvdXJjZU1vZGUuVGVtcGxhdGVkUGFyZW50O1xyXG5cclxuQmluZGluZ182MTM4YTc2NzRmOTg0MGVmOTgzNGZlNzIwNDg5ZjBlNC5SZWxhdGl2ZVNvdXJjZSA9IFJlbGF0aXZlU291cmNlXzk0OGMxOTU3YmUzNTRiNDE5Njc2YjAyNTM2YTdhODFiO1xyXG5cclxuXHJcbkJpbmRpbmdfNjEzOGE3Njc0Zjk4NDBlZjk4MzRmZTcyMDQ4OWYwZTQuVGVtcGxhdGVPd25lciA9IHRlbXBsYXRlSW5zdGFuY2VfNmM2YTU2MTE1Mzk2NGZiNmFjNTI3MzVmZmYzZjUwM2M7XHJcblxyXG52YXIgQmluZGluZ185ODE5ZTlhYjJmYjA0MDVhOWI5OGFhMTM1MGY2ODRlMCA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmcoKTtcclxuQmluZGluZ185ODE5ZTlhYjJmYjA0MDVhOWI5OGFhMTM1MGY2ODRlMC5QYXRoID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlByb3BlcnR5UGF0aChAXCJWZXJ0aWNhbEFsaWdubWVudFwiKTtcclxudmFyIFJlbGF0aXZlU291cmNlXzY4NzQzN2NhZTYyOTRmYzJhNDU2Y2U3YjA2M2U2NzRiID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuUmVsYXRpdmVTb3VyY2UoKTtcclxuUmVsYXRpdmVTb3VyY2VfNjg3NDM3Y2FlNjI5NGZjMmE0NTZjZTdiMDYzZTY3NGIuTW9kZSA9IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuUmVsYXRpdmVTb3VyY2VNb2RlLlRlbXBsYXRlZFBhcmVudDtcclxuXHJcbkJpbmRpbmdfOTgxOWU5YWIyZmIwNDA1YTliOThhYTEzNTBmNjg0ZTAuUmVsYXRpdmVTb3VyY2UgPSBSZWxhdGl2ZVNvdXJjZV82ODc0MzdjYWU2Mjk0ZmMyYTQ1NmNlN2IwNjNlNjc0YjtcclxuXHJcblxyXG5CaW5kaW5nXzk4MTllOWFiMmZiMDQwNWE5Yjk4YWExMzUwZjY4NGUwLlRlbXBsYXRlT3duZXIgPSB0ZW1wbGF0ZUluc3RhbmNlXzZjNmE1NjExNTM5NjRmYjZhYzUyNzM1ZmZmM2Y1MDNjO1xyXG5cclxuXHJcbkJvcmRlcl8xYzRjM2UwZTQxNzc0NWI4YmJkNTIzYTdhNWExNTUyOS5DaGlsZCA9IENvbnRlbnRQcmVzZW50ZXJfODg0MzI5NTY1M2U5NGNjZDgxZDYxZTM5OGVjNzA1MTQ7XHJcblxyXG52YXIgQmluZGluZ184MTMzNjRjNTY1MjI0Mzc3YjU5NDE2ZGU1ZWRjMTJlOCA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmcoKTtcclxuQmluZGluZ184MTMzNjRjNTY1MjI0Mzc3YjU5NDE2ZGU1ZWRjMTJlOC5QYXRoID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlByb3BlcnR5UGF0aChAXCJDbGllbnRIZWlnaHRcIik7XHJcblxyXG5cclxudmFyIEJpbmRpbmdfOTk3ZmI3NDNmMDBiNDQ1NmJmYWY2ZmMzZjhlZjBhMDcgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5CaW5kaW5nKCk7XHJcbkJpbmRpbmdfOTk3ZmI3NDNmMDBiNDQ1NmJmYWY2ZmMzZjhlZjBhMDcuUGF0aCA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Qcm9wZXJ0eVBhdGgoQFwiQ2xpZW50V2lkdGhcIik7XHJcblxyXG5cclxudmFyIEJpbmRpbmdfODcwZDZlNDBkZDNiNGFhZDgxZTBjNzY2ZWJiYmNlNGQgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5CaW5kaW5nKCk7XHJcbkJpbmRpbmdfODcwZDZlNDBkZDNiNGFhZDgxZTBjNzY2ZWJiYmNlNGQuUGF0aCA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Qcm9wZXJ0eVBhdGgoQFwiQmFja2dyb3VuZFwiKTtcclxudmFyIFJlbGF0aXZlU291cmNlXzc4YThjYTJkMmRmNDQyYjc4NjAyZTU0MThkNzIwMjVlID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuUmVsYXRpdmVTb3VyY2UoKTtcclxuUmVsYXRpdmVTb3VyY2VfNzhhOGNhMmQyZGY0NDJiNzg2MDJlNTQxOGQ3MjAyNWUuTW9kZSA9IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuUmVsYXRpdmVTb3VyY2VNb2RlLlRlbXBsYXRlZFBhcmVudDtcclxuXHJcbkJpbmRpbmdfODcwZDZlNDBkZDNiNGFhZDgxZTBjNzY2ZWJiYmNlNGQuUmVsYXRpdmVTb3VyY2UgPSBSZWxhdGl2ZVNvdXJjZV83OGE4Y2EyZDJkZjQ0MmI3ODYwMmU1NDE4ZDcyMDI1ZTtcclxuXHJcblxyXG5CaW5kaW5nXzg3MGQ2ZTQwZGQzYjRhYWQ4MWUwYzc2NmViYmJjZTRkLlRlbXBsYXRlT3duZXIgPSB0ZW1wbGF0ZUluc3RhbmNlXzZjNmE1NjExNTM5NjRmYjZhYzUyNzM1ZmZmM2Y1MDNjO1xyXG5cclxudmFyIEJpbmRpbmdfNjI1MDg3OTJhYjFjNDgyNThjY2RmNzQzY2ZmNWY4NGYgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5CaW5kaW5nKCk7XHJcbkJpbmRpbmdfNjI1MDg3OTJhYjFjNDgyNThjY2RmNzQzY2ZmNWY4NGYuUGF0aCA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Qcm9wZXJ0eVBhdGgoQFwiQmFja2dyb3VuZFwiKTtcclxudmFyIFJlbGF0aXZlU291cmNlXzUwOWRjMDExODc3NjQzYWNiZjVmOTA1Y2U0OWY1YzhkID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuUmVsYXRpdmVTb3VyY2UoKTtcclxuUmVsYXRpdmVTb3VyY2VfNTA5ZGMwMTE4Nzc2NDNhY2JmNWY5MDVjZTQ5ZjVjOGQuTW9kZSA9IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuUmVsYXRpdmVTb3VyY2VNb2RlLlRlbXBsYXRlZFBhcmVudDtcclxuXHJcbkJpbmRpbmdfNjI1MDg3OTJhYjFjNDgyNThjY2RmNzQzY2ZmNWY4NGYuUmVsYXRpdmVTb3VyY2UgPSBSZWxhdGl2ZVNvdXJjZV81MDlkYzAxMTg3NzY0M2FjYmY1ZjkwNWNlNDlmNWM4ZDtcclxuXHJcblxyXG5CaW5kaW5nXzYyNTA4NzkyYWIxYzQ4MjU4Y2NkZjc0M2NmZjVmODRmLlRlbXBsYXRlT3duZXIgPSB0ZW1wbGF0ZUluc3RhbmNlXzZjNmE1NjExNTM5NjRmYjZhYzUyNzM1ZmZmM2Y1MDNjO1xyXG5cclxuXHJcbkdyaWRfNDI2MjhkMjc0ZDgzNDQ4M2I2MTE5NDIwYjE5MDlmYWYuQ2hpbGRyZW4uQWRkKEJvcmRlcl8zYzMwNWI4ODNhYTU0ZDE3OTg5MzBlMDI2ZmRmNmNhMyk7XHJcbkdyaWRfNDI2MjhkMjc0ZDgzNDQ4M2I2MTE5NDIwYjE5MDlmYWYuQ2hpbGRyZW4uQWRkKEJvcmRlcl8xYzRjM2UwZTQxNzc0NWI4YmJkNTIzYTdhNWExNTUyOSk7XHJcblxyXG5cclxuQm9yZGVyX2E4ZTUwY2I1MmU1YTRkMGU4NWI5NzdhMjE3MWE1Njc4LkNoaWxkID0gR3JpZF80MjYyOGQyNzRkODM0NDgzYjYxMTk0MjBiMTkwOWZhZjtcclxuXHJcbnZhciBCaW5kaW5nXzM2NjVkZTQ4MjQxODRmZTc5NWU1MjdlNTE0ZWIxNzgzID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuQmluZGluZygpO1xyXG5CaW5kaW5nXzM2NjVkZTQ4MjQxODRmZTc5NWU1MjdlNTE0ZWIxNzgzLlBhdGggPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuUHJvcGVydHlQYXRoKEBcIkJvcmRlclRoaWNrbmVzc1wiKTtcclxudmFyIFJlbGF0aXZlU291cmNlXzJjNWMxZjNiN2RjNDQ1ODZiMWU2YmZiOTk2OGVjODc3ID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuUmVsYXRpdmVTb3VyY2UoKTtcclxuUmVsYXRpdmVTb3VyY2VfMmM1YzFmM2I3ZGM0NDU4NmIxZTZiZmI5OTY4ZWM4NzcuTW9kZSA9IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuUmVsYXRpdmVTb3VyY2VNb2RlLlRlbXBsYXRlZFBhcmVudDtcclxuXHJcbkJpbmRpbmdfMzY2NWRlNDgyNDE4NGZlNzk1ZTUyN2U1MTRlYjE3ODMuUmVsYXRpdmVTb3VyY2UgPSBSZWxhdGl2ZVNvdXJjZV8yYzVjMWYzYjdkYzQ0NTg2YjFlNmJmYjk5NjhlYzg3NztcclxuXHJcblxyXG5CaW5kaW5nXzM2NjVkZTQ4MjQxODRmZTc5NWU1MjdlNTE0ZWIxNzgzLlRlbXBsYXRlT3duZXIgPSB0ZW1wbGF0ZUluc3RhbmNlXzZjNmE1NjExNTM5NjRmYjZhYzUyNzM1ZmZmM2Y1MDNjO1xyXG5cclxudmFyIEJpbmRpbmdfZWNkYTkyZDI4NDNmNDBiNjhlNjBhYjRkYWVkMTliNTMgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5CaW5kaW5nKCk7XHJcbkJpbmRpbmdfZWNkYTkyZDI4NDNmNDBiNjhlNjBhYjRkYWVkMTliNTMuUGF0aCA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Qcm9wZXJ0eVBhdGgoQFwiQm9yZGVyQnJ1c2hcIik7XHJcbnZhciBSZWxhdGl2ZVNvdXJjZV9kYzVlMzc2NjE4MmY0OTZhYWU1ZGE0ODM1NzM1MmE5YyA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLlJlbGF0aXZlU291cmNlKCk7XHJcblJlbGF0aXZlU291cmNlX2RjNWUzNzY2MTgyZjQ5NmFhZTVkYTQ4MzU3MzUyYTljLk1vZGUgPSBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLlJlbGF0aXZlU291cmNlTW9kZS5UZW1wbGF0ZWRQYXJlbnQ7XHJcblxyXG5CaW5kaW5nX2VjZGE5MmQyODQzZjQwYjY4ZTYwYWI0ZGFlZDE5YjUzLlJlbGF0aXZlU291cmNlID0gUmVsYXRpdmVTb3VyY2VfZGM1ZTM3NjYxODJmNDk2YWFlNWRhNDgzNTczNTJhOWM7XHJcblxyXG5cclxuQmluZGluZ19lY2RhOTJkMjg0M2Y0MGI2OGU2MGFiNGRhZWQxOWI1My5UZW1wbGF0ZU93bmVyID0gdGVtcGxhdGVJbnN0YW5jZV82YzZhNTYxMTUzOTY0ZmI2YWM1MjczNWZmZjNmNTAzYztcclxuXHJcblxyXG5Cb3JkZXJfYmI3OGIwMmUwNTkyNDc5YmIxY2U0ZWZlNTlhM2ZhNTIuQ2hpbGQgPSBCb3JkZXJfYThlNTBjYjUyZTVhNGQwZTg1Yjk3N2EyMTcxYTU2Nzg7XHJcblxyXG5cclxuR3JpZF81OWI5ZGE3MmJhNjA0MDY2YTRkODI0YzUwNTI2ZjU4YS5DaGlsZHJlbi5BZGQoR3JpZF83NDQwNzEzODIyN2M0MjY2YTc1NDhiZjE3YjIwNmJhZik7XHJcbkdyaWRfNTliOWRhNzJiYTYwNDA2NmE0ZDgyNGM1MDUyNmY1OGEuQ2hpbGRyZW4uQWRkKEJvcmRlcl9iYjc4YjAyZTA1OTI0NzliYjFjZTRlZmU1OWEzZmE1Mik7XHJcblxyXG52YXIgQmluZGluZ183M2U3YWM3MjllMjk0M2FlYWJlNzA1ZTFjNWU1YmE1ZiA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmcoKTtcclxuQmluZGluZ183M2U3YWM3MjllMjk0M2FlYWJlNzA1ZTFjNWU1YmE1Zi5QYXRoID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlByb3BlcnR5UGF0aChAXCJIZWlnaHRcIik7XHJcbnZhciBSZWxhdGl2ZVNvdXJjZV9hMzBiOTY2ZDI0MWQ0M2U3OWM4MGY0NzI1ZGZjZTlhNCA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLlJlbGF0aXZlU291cmNlKCk7XHJcblJlbGF0aXZlU291cmNlX2EzMGI5NjZkMjQxZDQzZTc5YzgwZjQ3MjVkZmNlOWE0Lk1vZGUgPSBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLlJlbGF0aXZlU291cmNlTW9kZS5UZW1wbGF0ZWRQYXJlbnQ7XHJcblxyXG5CaW5kaW5nXzczZTdhYzcyOWUyOTQzYWVhYmU3MDVlMWM1ZTViYTVmLlJlbGF0aXZlU291cmNlID0gUmVsYXRpdmVTb3VyY2VfYTMwYjk2NmQyNDFkNDNlNzljODBmNDcyNWRmY2U5YTQ7XHJcblxyXG5cclxuQmluZGluZ183M2U3YWM3MjllMjk0M2FlYWJlNzA1ZTFjNWU1YmE1Zi5UZW1wbGF0ZU93bmVyID0gdGVtcGxhdGVJbnN0YW5jZV82YzZhNTYxMTUzOTY0ZmI2YWM1MjczNWZmZjNmNTAzYztcclxuXHJcbnZhciBCaW5kaW5nXzkxMjc5M2FjNGE0YTRiNWM4M2MwNTFiMTFkZGNhN2NlID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuQmluZGluZygpO1xyXG5CaW5kaW5nXzkxMjc5M2FjNGE0YTRiNWM4M2MwNTFiMTFkZGNhN2NlLlBhdGggPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuUHJvcGVydHlQYXRoKEBcIldpZHRoXCIpO1xyXG52YXIgUmVsYXRpdmVTb3VyY2VfZTk4MjJiODJiZTZlNDY1MTgxMWI4MGI1NTUzMWE1YjQgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5SZWxhdGl2ZVNvdXJjZSgpO1xyXG5SZWxhdGl2ZVNvdXJjZV9lOTgyMmI4MmJlNmU0NjUxODExYjgwYjU1NTMxYTViNC5Nb2RlID0gZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5SZWxhdGl2ZVNvdXJjZU1vZGUuVGVtcGxhdGVkUGFyZW50O1xyXG5cclxuQmluZGluZ185MTI3OTNhYzRhNGE0YjVjODNjMDUxYjExZGRjYTdjZS5SZWxhdGl2ZVNvdXJjZSA9IFJlbGF0aXZlU291cmNlX2U5ODIyYjgyYmU2ZTQ2NTE4MTFiODBiNTU1MzFhNWI0O1xyXG5cclxuXHJcbkJpbmRpbmdfOTEyNzkzYWM0YTRhNGI1YzgzYzA1MWIxMWRkY2E3Y2UuVGVtcGxhdGVPd25lciA9IHRlbXBsYXRlSW5zdGFuY2VfNmM2YTU2MTE1Mzk2NGZiNmFjNTI3MzVmZmYzZjUwM2M7XHJcblxyXG52YXIgQmluZGluZ18yY2U4Mzg4ZmRjY2E0YTNiYjljNGIzZWUxMzRiM2MxMCA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmcoKTtcclxuQmluZGluZ18yY2U4Mzg4ZmRjY2E0YTNiYjljNGIzZWUxMzRiM2MxMC5QYXRoID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlByb3BlcnR5UGF0aChAXCJIb3Jpem9udGFsQWxpZ25tZW50XCIpO1xyXG52YXIgUmVsYXRpdmVTb3VyY2VfMTljZDE3YTExYjZjNDAzNGE2N2U1ZWVmZjI1M2YzMWYgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5SZWxhdGl2ZVNvdXJjZSgpO1xyXG5SZWxhdGl2ZVNvdXJjZV8xOWNkMTdhMTFiNmM0MDM0YTY3ZTVlZWZmMjUzZjMxZi5Nb2RlID0gZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5SZWxhdGl2ZVNvdXJjZU1vZGUuVGVtcGxhdGVkUGFyZW50O1xyXG5cclxuQmluZGluZ18yY2U4Mzg4ZmRjY2E0YTNiYjljNGIzZWUxMzRiM2MxMC5SZWxhdGl2ZVNvdXJjZSA9IFJlbGF0aXZlU291cmNlXzE5Y2QxN2ExMWI2YzQwMzRhNjdlNWVlZmYyNTNmMzFmO1xyXG5cclxuXHJcbkJpbmRpbmdfMmNlODM4OGZkY2NhNGEzYmI5YzRiM2VlMTM0YjNjMTAuVGVtcGxhdGVPd25lciA9IHRlbXBsYXRlSW5zdGFuY2VfNmM2YTU2MTE1Mzk2NGZiNmFjNTI3MzVmZmYzZjUwM2M7XHJcblxyXG52YXIgQmluZGluZ18zYWMxZmQxYTA3NWE0OTk2OTgyNjYxNjk2MzAxZjFiOSA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmcoKTtcclxuQmluZGluZ18zYWMxZmQxYTA3NWE0OTk2OTgyNjYxNjk2MzAxZjFiOS5QYXRoID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlByb3BlcnR5UGF0aChAXCJWZXJ0aWNhbEFsaWdubWVudFwiKTtcclxudmFyIFJlbGF0aXZlU291cmNlXzIxMjViYjU0YmIwMjRiNTViMjQyMTcwNDg1ZWY0M2UzID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuUmVsYXRpdmVTb3VyY2UoKTtcclxuUmVsYXRpdmVTb3VyY2VfMjEyNWJiNTRiYjAyNGI1NWIyNDIxNzA0ODVlZjQzZTMuTW9kZSA9IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuUmVsYXRpdmVTb3VyY2VNb2RlLlRlbXBsYXRlZFBhcmVudDtcclxuXHJcbkJpbmRpbmdfM2FjMWZkMWEwNzVhNDk5Njk4MjY2MTY5NjMwMWYxYjkuUmVsYXRpdmVTb3VyY2UgPSBSZWxhdGl2ZVNvdXJjZV8yMTI1YmI1NGJiMDI0YjU1YjI0MjE3MDQ4NWVmNDNlMztcclxuXHJcblxyXG5CaW5kaW5nXzNhYzFmZDFhMDc1YTQ5OTY5ODI2NjE2OTYzMDFmMWI5LlRlbXBsYXRlT3duZXIgPSB0ZW1wbGF0ZUluc3RhbmNlXzZjNmE1NjExNTM5NjRmYjZhYzUyNzM1ZmZmM2Y1MDNjO1xyXG5cclxuXHJcbmdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuQmluZGluZ09wZXJhdGlvbnMuU2V0QmluZGluZyhHcmlkXzc0NDA3MTM4MjI3YzQyNjZhNzU0OGJmMTdiMjA2YmFmLCBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Db250cm9scy5QYW5lbC5CYWNrZ3JvdW5kUHJvcGVydHksIEJpbmRpbmdfZGE5N2FlNTE0MjcwNDQzNWExMzMxMzM0MTcyMTZhNzgpO1xyXG5nbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmdPcGVyYXRpb25zLlNldEJpbmRpbmcoR3JpZF83NDQwNzEzODIyN2M0MjY2YTc1NDhiZjE3YjIwNmJhZiwgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuVUlFbGVtZW50Lk9wYWNpdHlQcm9wZXJ0eSwgQmluZGluZ182MjAxYzNjMTQ0YTk0Zjc5YjYwY2M3MGQ3OTdkZmM0YSk7XHJcbmdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuQmluZGluZ09wZXJhdGlvbnMuU2V0QmluZGluZyhJbWFnZV8wZWY0YzVlM2IyYzU0NjkwOGNjMjRiOGFkZGI1YTQ4YSwgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuQ29udHJvbHMuSW1hZ2UuU291cmNlUHJvcGVydHksIEJpbmRpbmdfMGYxMmIzMzVmMDhkNGRlZTlkYTU5NjFhOTgxZmFhNDEpO1xyXG5nbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmdPcGVyYXRpb25zLlNldEJpbmRpbmcoQnV0dG9uX2FiZGFlMzJmYmM4ZjRhNzZhMjA0NGEzNDc5MGIwZGFhLCBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5VSUVsZW1lbnQuVmlzaWJpbGl0eVByb3BlcnR5LCBCaW5kaW5nXzk5YTQwZjFkZDYxNzQ1ZDFhZjA2ZmQ0N2RjNDI2OTY1KTtcclxuZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5CaW5kaW5nT3BlcmF0aW9ucy5TZXRCaW5kaW5nKENvbnRlbnRDb250cm9sXzhiOGRkNjZhMDEyOTQ2NjRiYTVlZWJjNDNmMjI0MDhmLCBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Db250cm9scy5Db250ZW50Q29udHJvbC5Db250ZW50UHJvcGVydHksIEJpbmRpbmdfYzA5MDVlNjQ0YmE2NDI3MmFjYTgwOGZjMWFlNDNmMTIpO1xyXG5nbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmdPcGVyYXRpb25zLlNldEJpbmRpbmcoSW1hZ2VfODI3MzZiODE0MWE5NGQwNjk1NmI2NTQ0NjM2MDFhYzQsIGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkNvbnRyb2xzLkltYWdlLlNvdXJjZVByb3BlcnR5LCBCaW5kaW5nX2Q5Yjk0ZTY0ZWQ1NzRmOTI5NGJjZjE4NWFiYjZjNjI2KTtcclxuZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5CaW5kaW5nT3BlcmF0aW9ucy5TZXRCaW5kaW5nKEJ1dHRvbl81OWYyNGExMjFhYmU0ZDJiYTg1ZDJmMzk0NDAxNzdhOSwgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuVUlFbGVtZW50LlZpc2liaWxpdHlQcm9wZXJ0eSwgQmluZGluZ180OTViMDdmZWFiZWE0MDQ4ODA0NTY0YWQ2YTg0ZjQyZik7XHJcbmdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuQmluZGluZ09wZXJhdGlvbnMuU2V0QmluZGluZyhJbWFnZV82ZjUwYTE1N2E3MWU0OTljYmY0NmEyZmViOTNjMjhiNCwgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuQ29udHJvbHMuSW1hZ2UuU291cmNlUHJvcGVydHksIEJpbmRpbmdfZDUwYjRmNTlkZWE4NGU2Njg2NGM5NDgwZmU4NTVkZTgpO1xyXG5nbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmdPcGVyYXRpb25zLlNldEJpbmRpbmcoQnV0dG9uX2M5ZTdkNzNjZDI0YjQ1ZGY4M2U4MTkxZjg1ODI3YTVjLCBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5VSUVsZW1lbnQuVmlzaWJpbGl0eVByb3BlcnR5LCBCaW5kaW5nX2Q0ZjUyMjVjNDc0YzRhNDBhOWYxNDM3NjFhYTg0ZTRiKTtcclxuZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5CaW5kaW5nT3BlcmF0aW9ucy5TZXRCaW5kaW5nKEltYWdlXzM1ZWZiMzQwYWI0MzQyMjI4N2I2YTUyNmI2OTUwZDE1LCBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Db250cm9scy5JbWFnZS5Tb3VyY2VQcm9wZXJ0eSwgQmluZGluZ182NjE4MzA5NjMyOTM0MjRkOTBmMDM3ZjQ3MTkyMzdlYSk7XHJcbmdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuQmluZGluZ09wZXJhdGlvbnMuU2V0QmluZGluZyhCdXR0b25fODg3NDFiNWUzMGUxNGY1ZGJiZjFhMDgxOTRjNjZmMjEsIGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlVJRWxlbWVudC5WaXNpYmlsaXR5UHJvcGVydHksIEJpbmRpbmdfOTJmM2YxMDQ3OWU5NDA3MmFjOWNiODVmYTUxZDRmZWQpO1xyXG5nbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmdPcGVyYXRpb25zLlNldEJpbmRpbmcoSW1hZ2VfOTcyZDQ3ZDkyOWQ4NDE5MTgwMGFhYTAxZjFkNTRlMTMsIGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkNvbnRyb2xzLkltYWdlLlNvdXJjZVByb3BlcnR5LCBCaW5kaW5nXzk0MzA5MThhMTZhODQ3NjhhMjU1NzA5ZTNjNWQyMDUzKTtcclxuZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5CaW5kaW5nT3BlcmF0aW9ucy5TZXRCaW5kaW5nKEJ1dHRvbl9hYmY0NDZlYzQ3YWU0MDRiODZhOThhZTNkYTQ1MDg0MywgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuVUlFbGVtZW50LlZpc2liaWxpdHlQcm9wZXJ0eSwgQmluZGluZ19kNDI4YTYzZTY2NmI0ZGU4ODVkYTgyNDBjMzE0MDYwMSk7XHJcbmdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuQmluZGluZ09wZXJhdGlvbnMuU2V0QmluZGluZyhJbWFnZV83NDdlNjY3NGMzZWQ0Y2Q5OGJiYTgwN2I4NDg2MjMzNiwgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuQ29udHJvbHMuSW1hZ2UuU291cmNlUHJvcGVydHksIEJpbmRpbmdfMzFjZWY3MmNmMGQwNGM0MmE3N2ViZjk1ZThiYTBkMDgpO1xyXG5nbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmdPcGVyYXRpb25zLlNldEJpbmRpbmcoQnV0dG9uXzdhMWNiM2ZlMWZhMTRmY2JiZmI3NDczMzM0MTdhYjI1LCBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5VSUVsZW1lbnQuVmlzaWJpbGl0eVByb3BlcnR5LCBCaW5kaW5nXzE0OTVkODUyNzA2ZDRhYTY5OWZmOGM4ZTAxYmQyODMyKTtcclxuZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5CaW5kaW5nT3BlcmF0aW9ucy5TZXRCaW5kaW5nKEJvcmRlcl8zYzMwNWI4ODNhYTU0ZDE3OTg5MzBlMDI2ZmRmNmNhMywgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuVUlFbGVtZW50LlZpc2liaWxpdHlQcm9wZXJ0eSwgQmluZGluZ184NTUwYTY4ZWMwNTc0ZDk5OTE2OGE4YTY0MmZhOWM5Nik7XHJcbmdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuQmluZGluZ09wZXJhdGlvbnMuU2V0QmluZGluZyhDb250ZW50UHJlc2VudGVyXzg4NDMyOTU2NTNlOTRjY2Q4MWQ2MWUzOThlYzcwNTE0LCBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Db250cm9scy5Db250ZW50Q29udHJvbC5Db250ZW50UHJvcGVydHksIEJpbmRpbmdfMmE3ZjAyMjQyYjEzNDVlN2EzYzQzM2NmNjc4YzhmYmIpO1xyXG5nbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmdPcGVyYXRpb25zLlNldEJpbmRpbmcoQ29udGVudFByZXNlbnRlcl84ODQzMjk1NjUzZTk0Y2NkODFkNjFlMzk4ZWM3MDUxNCwgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuQ29udHJvbHMuQ29udGVudENvbnRyb2wuQ29udGVudFRlbXBsYXRlUHJvcGVydHksIEJpbmRpbmdfYjdhYzAzZGU3MDg1NDNlYWFmNjA2Nzg0ZjBlMzhhMDIpO1xyXG5nbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmdPcGVyYXRpb25zLlNldEJpbmRpbmcoQ29udGVudFByZXNlbnRlcl84ODQzMjk1NjUzZTk0Y2NkODFkNjFlMzk4ZWM3MDUxNCwgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRnJhbWV3b3JrRWxlbWVudC5XaWR0aFByb3BlcnR5LCBCaW5kaW5nX2UzYzZmYzI0YzNhMjRkYTI4NDg1NTg0ZjU4NjQ1NDk1KTtcclxuZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5CaW5kaW5nT3BlcmF0aW9ucy5TZXRCaW5kaW5nKENvbnRlbnRQcmVzZW50ZXJfODg0MzI5NTY1M2U5NGNjZDgxZDYxZTM5OGVjNzA1MTQsIGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkZyYW1ld29ya0VsZW1lbnQuSGVpZ2h0UHJvcGVydHksIEJpbmRpbmdfYzUyYjk0YWJiMjg1NDYwODg1NjdiZjEwMDdlYzYzZjIpO1xyXG5nbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmdPcGVyYXRpb25zLlNldEJpbmRpbmcoQ29udGVudFByZXNlbnRlcl84ODQzMjk1NjUzZTk0Y2NkODFkNjFlMzk4ZWM3MDUxNCwgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRnJhbWV3b3JrRWxlbWVudC5Ib3Jpem9udGFsQWxpZ25tZW50UHJvcGVydHksIEJpbmRpbmdfNjEzOGE3Njc0Zjk4NDBlZjk4MzRmZTcyMDQ4OWYwZTQpO1xyXG5nbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmdPcGVyYXRpb25zLlNldEJpbmRpbmcoQ29udGVudFByZXNlbnRlcl84ODQzMjk1NjUzZTk0Y2NkODFkNjFlMzk4ZWM3MDUxNCwgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRnJhbWV3b3JrRWxlbWVudC5WZXJ0aWNhbEFsaWdubWVudFByb3BlcnR5LCBCaW5kaW5nXzk4MTllOWFiMmZiMDQwNWE5Yjk4YWExMzUwZjY4NGUwKTtcclxuZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5CaW5kaW5nT3BlcmF0aW9ucy5TZXRCaW5kaW5nKEJvcmRlcl8xYzRjM2UwZTQxNzc0NWI4YmJkNTIzYTdhNWExNTUyOSwgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRnJhbWV3b3JrRWxlbWVudC5IZWlnaHRQcm9wZXJ0eSwgQmluZGluZ184MTMzNjRjNTY1MjI0Mzc3YjU5NDE2ZGU1ZWRjMTJlOCk7XHJcbmdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuQmluZGluZ09wZXJhdGlvbnMuU2V0QmluZGluZyhCb3JkZXJfMWM0YzNlMGU0MTc3NDViOGJiZDUyM2E3YTVhMTU1MjksIGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkZyYW1ld29ya0VsZW1lbnQuV2lkdGhQcm9wZXJ0eSwgQmluZGluZ185OTdmYjc0M2YwMGI0NDU2YmZhZjZmYzNmOGVmMGEwNyk7XHJcbmdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuQmluZGluZ09wZXJhdGlvbnMuU2V0QmluZGluZyhCb3JkZXJfMWM0YzNlMGU0MTc3NDViOGJiZDUyM2E3YTVhMTU1MjksIGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkNvbnRyb2xzLkJvcmRlci5CYWNrZ3JvdW5kUHJvcGVydHksIEJpbmRpbmdfODcwZDZlNDBkZDNiNGFhZDgxZTBjNzY2ZWJiYmNlNGQpO1xyXG5nbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmdPcGVyYXRpb25zLlNldEJpbmRpbmcoQm9yZGVyXzFjNGMzZTBlNDE3NzQ1YjhiYmQ1MjNhN2E1YTE1NTI5LCBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Db250cm9scy5Cb3JkZXIuQm9yZGVyQnJ1c2hQcm9wZXJ0eSwgQmluZGluZ182MjUwODc5MmFiMWM0ODI1OGNjZGY3NDNjZmY1Zjg0Zik7XHJcbmdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuQmluZGluZ09wZXJhdGlvbnMuU2V0QmluZGluZyhCb3JkZXJfYThlNTBjYjUyZTVhNGQwZTg1Yjk3N2EyMTcxYTU2NzgsIGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkNvbnRyb2xzLkJvcmRlci5Cb3JkZXJUaGlja25lc3NQcm9wZXJ0eSwgQmluZGluZ18zNjY1ZGU0ODI0MTg0ZmU3OTVlNTI3ZTUxNGViMTc4Myk7XHJcbmdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuQmluZGluZ09wZXJhdGlvbnMuU2V0QmluZGluZyhCb3JkZXJfYThlNTBjYjUyZTVhNGQwZTg1Yjk3N2EyMTcxYTU2NzgsIGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkNvbnRyb2xzLkJvcmRlci5Cb3JkZXJCcnVzaFByb3BlcnR5LCBCaW5kaW5nX2VjZGE5MmQyODQzZjQwYjY4ZTYwYWI0ZGFlZDE5YjUzKTtcclxuZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5CaW5kaW5nT3BlcmF0aW9ucy5TZXRCaW5kaW5nKEdyaWRfNTliOWRhNzJiYTYwNDA2NmE0ZDgyNGM1MDUyNmY1OGEsIGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkZyYW1ld29ya0VsZW1lbnQuSGVpZ2h0UHJvcGVydHksIEJpbmRpbmdfNzNlN2FjNzI5ZTI5NDNhZWFiZTcwNWUxYzVlNWJhNWYpO1xyXG5nbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmdPcGVyYXRpb25zLlNldEJpbmRpbmcoR3JpZF81OWI5ZGE3MmJhNjA0MDY2YTRkODI0YzUwNTI2ZjU4YSwgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRnJhbWV3b3JrRWxlbWVudC5XaWR0aFByb3BlcnR5LCBCaW5kaW5nXzkxMjc5M2FjNGE0YTRiNWM4M2MwNTFiMTFkZGNhN2NlKTtcclxuZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5CaW5kaW5nT3BlcmF0aW9ucy5TZXRCaW5kaW5nKEdyaWRfNTliOWRhNzJiYTYwNDA2NmE0ZDgyNGM1MDUyNmY1OGEsIGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkZyYW1ld29ya0VsZW1lbnQuSG9yaXpvbnRhbEFsaWdubWVudFByb3BlcnR5LCBCaW5kaW5nXzJjZTgzODhmZGNjYTRhM2JiOWM0YjNlZTEzNGIzYzEwKTtcclxuZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5CaW5kaW5nT3BlcmF0aW9ucy5TZXRCaW5kaW5nKEdyaWRfNTliOWRhNzJiYTYwNDA2NmE0ZDgyNGM1MDUyNmY1OGEsIGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkZyYW1ld29ya0VsZW1lbnQuVmVydGljYWxBbGlnbm1lbnRQcm9wZXJ0eSwgQmluZGluZ18zYWMxZmQxYTA3NWE0OTk2OTgyNjYxNjk2MzAxZjFiOSk7XHJcblxyXG5nbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5NZWRpYS5BbmltYXRpb24uU3Rvcnlib2FyZC5TZXRUYXJnZXRQcm9wZXJ0eShPYmplY3RBbmltYXRpb25Vc2luZ0tleUZyYW1lc182ZGVjNGRjMTA1MDc0Nzc2OWM4YjVjNGMwMjIxYWIwMyxcclxuICAgIG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Qcm9wZXJ0eVBhdGgoXHJcbiAgICAgICAgXCJCYWNrZ3JvdW5kXCIsXHJcbiAgICAgICAgXCJCYWNrZ3JvdW5kXCIsXHJcbiAgICAgICAgYWNjZXNzVmlzdWFsU3RhdGVQcm9wZXJ0eV8xZDI1MDFlMDJkZWE0MzkyYjc3YmNjNDQyZWE0NzA1MyxcclxuICAgICAgICBzZXRWaXN1YWxTdGF0ZVByb3BlcnR5XzFkMjUwMWUwMmRlYTQzOTJiNzdiY2M0NDJlYTQ3MDUzLFxyXG4gICAgICAgIHNldEFuaW1hdGlvblZpc3VhbFN0YXRlUHJvcGVydHlfMWQyNTAxZTAyZGVhNDM5MmI3N2JjYzQ0MmVhNDcwNTMsICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgIHNldExvY2FsVmlzdWFsU3RhdGVQcm9wZXJ0eV8xZDI1MDFlMDJkZWE0MzkyYjc3YmNjNDQyZWE0NzA1MyxcclxuICAgICAgICBnZXRWaXN1YWxTdGF0ZVByb3BlcnR5XzFkMjUwMWUwMmRlYTQzOTJiNzdiY2M0NDJlYTQ3MDUzKSk7XHJcbmdsb2JhbDo6V2luZG93cy5VSS5YYW1sLk1lZGlhLkFuaW1hdGlvbi5TdG9yeWJvYXJkLlNldFRhcmdldChPYmplY3RBbmltYXRpb25Vc2luZ0tleUZyYW1lc182ZGVjNGRjMTA1MDc0Nzc2OWM4YjVjNGMwMjIxYWIwMywgR3JpZF83NDQwNzEzODIyN2M0MjY2YTc1NDhiZjE3YjIwNmJhZik7XHJcblxyXG5cclxuZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuTWVkaWEuQW5pbWF0aW9uLlN0b3J5Ym9hcmQuU2V0VGFyZ2V0UHJvcGVydHkoT2JqZWN0QW5pbWF0aW9uVXNpbmdLZXlGcmFtZXNfYTRmYmMwOTA0YmFjNDc0M2JmMzQyZGEwODk1NjNkYzUsXHJcbiAgICBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuUHJvcGVydHlQYXRoKFxyXG4gICAgICAgIFwiSXNIaXRUZXN0VmlzaWJsZVwiLFxyXG4gICAgICAgIFwiSXNIaXRUZXN0VmlzaWJsZVwiLFxyXG4gICAgICAgIGFjY2Vzc1Zpc3VhbFN0YXRlUHJvcGVydHlfZGRlZDRhMWIwMGFhNDFlMDliYTNmODcwZTU2NzVlNDYsXHJcbiAgICAgICAgc2V0VmlzdWFsU3RhdGVQcm9wZXJ0eV9kZGVkNGExYjAwYWE0MWUwOWJhM2Y4NzBlNTY3NWU0NixcclxuICAgICAgICBzZXRBbmltYXRpb25WaXN1YWxTdGF0ZVByb3BlcnR5X2RkZWQ0YTFiMDBhYTQxZTA5YmEzZjg3MGU1Njc1ZTQ2LCAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICBzZXRMb2NhbFZpc3VhbFN0YXRlUHJvcGVydHlfZGRlZDRhMWIwMGFhNDFlMDliYTNmODcwZTU2NzVlNDYsXHJcbiAgICAgICAgZ2V0VmlzdWFsU3RhdGVQcm9wZXJ0eV9kZGVkNGExYjAwYWE0MWUwOWJhM2Y4NzBlNTY3NWU0NikpO1xyXG5nbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5NZWRpYS5BbmltYXRpb24uU3Rvcnlib2FyZC5TZXRUYXJnZXQoT2JqZWN0QW5pbWF0aW9uVXNpbmdLZXlGcmFtZXNfYTRmYmMwOTA0YmFjNDc0M2JmMzQyZGEwODk1NjNkYzUsIEdyaWRfNzQ0MDcxMzgyMjdjNDI2NmE3NTQ4YmYxN2IyMDZiYWYpO1xyXG5cclxudGVtcGxhdGVJbnN0YW5jZV82YzZhNTYxMTUzOTY0ZmI2YWM1MjczNWZmZjNmNTAzYy5UZW1wbGF0ZUNvbnRlbnQgPSBHcmlkXzU5YjlkYTcyYmE2MDQwNjZhNGQ4MjRjNTA1MjZmNThhO1xyXG5yZXR1cm4gdGVtcGxhdGVJbnN0YW5jZV82YzZhNTYxMTUzOTY0ZmI2YWM1MjczNWZmZjNmNTAzYztcclxufSkpO1xyXG5cclxuU2V0dGVyXzJjNjgyYTU2NDlhODQ4ODM4Y2I3OTYyZmEzYWU0YWFhLlZhbHVlID0gQ29udHJvbFRlbXBsYXRlX2U2MDVjMGNmMWZlYTQzNDk4Nzc1MGNhNjMzNzc5MjlkO1xyXG5cclxuXHJcblN0eWxlXzIwMTMyYmFlOTMzNjQ3MDFiNWYzZmVlMTg1NDgwMjQ4LlNldHRlcnMuQWRkKFNldHRlcl8wMTdmYWRjNDdlNWE0NDY4YmZmZWI3ZjQ2YmRmMjI0Mik7XHJcblN0eWxlXzIwMTMyYmFlOTMzNjQ3MDFiNWYzZmVlMTg1NDgwMjQ4LlNldHRlcnMuQWRkKFNldHRlcl85ZGYxYTdkZTU0ZmE0YjY2OWY2MjNkYjU3OGRjZjc5MSk7XHJcblN0eWxlXzIwMTMyYmFlOTMzNjQ3MDFiNWYzZmVlMTg1NDgwMjQ4LlNldHRlcnMuQWRkKFNldHRlcl82NTU5MDZiNThhMGU0NGJmYTdiNDFlZGY0NTg5ZjhlNCk7XHJcblN0eWxlXzIwMTMyYmFlOTMzNjQ3MDFiNWYzZmVlMTg1NDgwMjQ4LlNldHRlcnMuQWRkKFNldHRlcl8xYjQ3ZDBiZjUyNmE0NWFiODczMjU0MDhlOTFhOGUzYik7XHJcblN0eWxlXzIwMTMyYmFlOTMzNjQ3MDFiNWYzZmVlMTg1NDgwMjQ4LlNldHRlcnMuQWRkKFNldHRlcl8yYzY4MmE1NjQ5YTg0ODgzOGNiNzk2MmZhM2FlNGFhYSk7XHJcblxyXG5cclxudmFyIFN0eWxlX2JjOWVjMTIzMTFkOTRmMmRhMzIzOGMyZDc1YmY3YTY3ID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlN0eWxlKCk7XHJcblN0eWxlX2JjOWVjMTIzMTFkOTRmMmRhMzIzOGMyZDc1YmY3YTY3LlRhcmdldFR5cGUgPSB0eXBlb2YoZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuQ29udHJvbHMuQnV0dG9uKTtcclxudmFyIFNldHRlcl84MTUwYmQzZjExM2U0MjNkOGQ2YTQ4OWU0MmU4NzUxZCA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5TZXR0ZXIoKTtcclxuU2V0dGVyXzgxNTBiZDNmMTEzZTQyM2Q4ZDZhNDg5ZTQyZTg3NTFkLlByb3BlcnR5ID0gZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuQ29udHJvbHMuQnV0dG9uLkJhY2tncm91bmRQcm9wZXJ0eTtcclxuU2V0dGVyXzgxNTBiZDNmMTEzZTQyM2Q4ZDZhNDg5ZTQyZTg3NTFkLlZhbHVlID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLk1lZGlhLlNvbGlkQ29sb3JCcnVzaChuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLkNvbG9yKCkgeyBBID0gKGJ5dGUpMjU1LCBSID0gKGJ5dGUpMjI2LCBHID0gKGJ5dGUpMjI2LCBCID0gKGJ5dGUpMjI2IH0pO1xyXG5cclxudmFyIFNldHRlcl80MmNmZWM4NDRhNTM0MGY4YmE2YzJkMDFmNGU3ZTZjMiA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5TZXR0ZXIoKTtcclxuU2V0dGVyXzQyY2ZlYzg0NGE1MzQwZjhiYTZjMmQwMWY0ZTdlNmMyLlByb3BlcnR5ID0gZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuQ29udHJvbHMuQnV0dG9uLkZvcmVncm91bmRQcm9wZXJ0eTtcclxuU2V0dGVyXzQyY2ZlYzg0NGE1MzQwZjhiYTZjMmQwMWY0ZTdlNmMyLlZhbHVlID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLk1lZGlhLlNvbGlkQ29sb3JCcnVzaChuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLkNvbG9yKCkgeyBBID0gKGJ5dGUpMjU1LCBSID0gKGJ5dGUpMCwgRyA9IChieXRlKTAsIEIgPSAoYnl0ZSkwIH0pO1xyXG5cclxudmFyIFNldHRlcl9jMDgyMzhiMGNjODY0ODg1YTM5YTMxNzk4YzljOWNlYyA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5TZXR0ZXIoKTtcclxuU2V0dGVyX2MwODIzOGIwY2M4NjQ4ODVhMzlhMzE3OThjOWM5Y2VjLlByb3BlcnR5ID0gZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuQ29udHJvbHMuQnV0dG9uLkJvcmRlclRoaWNrbmVzc1Byb3BlcnR5O1xyXG5TZXR0ZXJfYzA4MjM4YjBjYzg2NDg4NWEzOWEzMTc5OGM5YzljZWMuVmFsdWUgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuVGhpY2tuZXNzKDApO1xyXG5cclxudmFyIFNldHRlcl9hNWFjMjg5Njk0MzY0YjQ5YTIwYmRhYjk1NTM5Y2QwMiA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5TZXR0ZXIoKTtcclxuU2V0dGVyX2E1YWMyODk2OTQzNjRiNDlhMjBiZGFiOTU1MzljZDAyLlByb3BlcnR5ID0gZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuQ29udHJvbHMuQnV0dG9uLlBhZGRpbmdQcm9wZXJ0eTtcclxuU2V0dGVyX2E1YWMyODk2OTQzNjRiNDlhMjBiZGFiOTU1MzljZDAyLlZhbHVlID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlRoaWNrbmVzcygxMiwgNCwgMTIsIDQpO1xyXG5cclxudmFyIFNldHRlcl9iZDZlNDhkOGEwZjI0MzE1OGFiYjFiZWE4YWQyYWM5MSA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5TZXR0ZXIoKTtcclxuU2V0dGVyX2JkNmU0OGQ4YTBmMjQzMTU4YWJiMWJlYThhZDJhYzkxLlByb3BlcnR5ID0gZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuQ29udHJvbHMuQnV0dG9uLkN1cnNvclByb3BlcnR5O1xyXG5TZXR0ZXJfYmQ2ZTQ4ZDhhMGYyNDMxNThhYmIxYmVhOGFkMmFjOTEuVmFsdWUgPSBnbG9iYWw6OlN5c3RlbS5XaW5kb3dzLklucHV0LkN1cnNvcnMuSGFuZDtcclxuXHJcbnZhciBTZXR0ZXJfOWRhNDZkZGIyN2Q1NGMyZDlmYTRjMzliM2RiMGNkZTUgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuU2V0dGVyKCk7XHJcblNldHRlcl85ZGE0NmRkYjI3ZDU0YzJkOWZhNGMzOWIzZGIwY2RlNS5Qcm9wZXJ0eSA9IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkNvbnRyb2xzLkJ1dHRvbi5Ib3Jpem9udGFsQ29udGVudEFsaWdubWVudFByb3BlcnR5O1xyXG5TZXR0ZXJfOWRhNDZkZGIyN2Q1NGMyZDlmYTRjMzliM2RiMGNkZTUuVmFsdWUgPSBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Ib3Jpem9udGFsQWxpZ25tZW50LkNlbnRlcjtcclxuXHJcbnZhciBTZXR0ZXJfZmUzZjJmM2I4YTM5NDUzZGIzZWM3ODg3ZTQwMGNkNGQgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuU2V0dGVyKCk7XHJcblNldHRlcl9mZTNmMmYzYjhhMzk0NTNkYjNlYzc4ODdlNDAwY2Q0ZC5Qcm9wZXJ0eSA9IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkNvbnRyb2xzLkJ1dHRvbi5WZXJ0aWNhbENvbnRlbnRBbGlnbm1lbnRQcm9wZXJ0eTtcclxuU2V0dGVyX2ZlM2YyZjNiOGEzOTQ1M2RiM2VjNzg4N2U0MDBjZDRkLlZhbHVlID0gZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuVmVydGljYWxBbGlnbm1lbnQuQ2VudGVyO1xyXG5cclxudmFyIFNldHRlcl82ZDhhNWUzNmY5NGM0YTE3OGE0NmJkNjlhZTAzYTYyYiA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5TZXR0ZXIoKTtcclxuU2V0dGVyXzZkOGE1ZTM2Zjk0YzRhMTc4YTQ2YmQ2OWFlMDNhNjJiLlByb3BlcnR5ID0gZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuQ29udHJvbHMuQnV0dG9uLlRlbXBsYXRlUHJvcGVydHk7XHJcbnZhciBDb250cm9sVGVtcGxhdGVfZDk1MGZmMmJlOTAzNDc3NDhjOTUzNjhmMGE3OWE0Y2YgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuQ29udHJvbHMuQ29udHJvbFRlbXBsYXRlKCk7XHJcbkNvbnRyb2xUZW1wbGF0ZV9kOTUwZmYyYmU5MDM0Nzc0OGM5NTM2OGYwYTc5YTRjZi5UYXJnZXRUeXBlID0gdHlwZW9mKGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkNvbnRyb2xzLkJ1dHRvbik7XHJcbkNvbnRyb2xUZW1wbGF0ZV9kOTUwZmYyYmU5MDM0Nzc0OGM5NTM2OGYwYTc5YTRjZi5TZXRNZXRob2RUb0luc3RhbnRpYXRlRnJhbWV3b3JrVGVtcGxhdGUoKFN5c3RlbS5GdW5jPFdpbmRvd3MuVUkuWGFtbC5Db250cm9scy5Db250cm9sLFdpbmRvd3MuVUkuWGFtbC5UZW1wbGF0ZUluc3RhbmNlPikodGVtcGxhdGVPd25lcl9Db250cm9sVGVtcGxhdGVfZDk1MGZmMmJlOTAzNDc3NDhjOTUzNjhmMGE3OWE0Y2YgPT4gXHJcbntcclxudmFyIHRlbXBsYXRlSW5zdGFuY2VfZGIwNjUzOGNkZDExNDc0YmJiNTMzYTcyZTE4MmE3ODEgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuVGVtcGxhdGVJbnN0YW5jZSgpO1xyXG50ZW1wbGF0ZUluc3RhbmNlX2RiMDY1MzhjZGQxMTQ3NGJiYjUzM2E3MmUxODJhNzgxLlRlbXBsYXRlT3duZXIgPSB0ZW1wbGF0ZU93bmVyX0NvbnRyb2xUZW1wbGF0ZV9kOTUwZmYyYmU5MDM0Nzc0OGM5NTM2OGYwYTc5YTRjZjtcclxudmFyIFZpc3VhbFN0YXRlXzU3ODE0OTBmZTlhODQ0MTE5ZWY5OTJiZjc5ZDE2NmVhID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlZpc3VhbFN0YXRlKCk7XHJcbnZhciBWaXN1YWxTdGF0ZV9iMDZlZmJhZjViZDI0ZjM4OTMyNzRlOWY1MzNiYjY2YyA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5WaXN1YWxTdGF0ZSgpO1xyXG52YXIgVmlzdWFsU3RhdGVfM2E5YjZmZDU4OTVkNDA2Yzk5YjkxNjJjYWQ0ZGNhYTggPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuVmlzdWFsU3RhdGUoKTtcclxudmFyIFZpc3VhbFN0YXRlX2VjY2Q2NzViYmRiYTQ3ODY5MmQzOWZjOTFiYzgwMThmID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlZpc3VhbFN0YXRlKCk7XHJcbnZhciBWaXN1YWxTdGF0ZUdyb3VwX2ZiMGRmM2NlZDlmNTQ1NmY4YTFhMGQwYjkwNzg3NzJhID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlZpc3VhbFN0YXRlR3JvdXAoKTtcclxudmFyIENvbnRlbnRQcmVzZW50ZXJfOGMyNjM2ZmEzNTIyNGJiOTljYWZiYWMxNDk3NjQyYWMgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuQ29udHJvbHMuQ29udGVudFByZXNlbnRlcigpO1xyXG52YXIgQm9yZGVyXzVkYzg4MjgzNjE3ODQ5YThhZmIyNGUxMTg2YjZlZmQ0ID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkNvbnRyb2xzLkJvcmRlcigpO1xyXG52YXIgQm9yZGVyXzIwYWEzNDVlYmQxMDQ2N2Y4YTAxZDUyMDViNjczYzc0ID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkNvbnRyb2xzLkJvcmRlcigpO1xyXG50ZW1wbGF0ZU93bmVyX0NvbnRyb2xUZW1wbGF0ZV9kOTUwZmYyYmU5MDM0Nzc0OGM5NTM2OGYwYTc5YTRjZi5SZWdpc3Rlck5hbWUoXCJPdXRlckJvcmRlclwiLCBCb3JkZXJfMjBhYTM0NWViZDEwNDY3ZjhhMDFkNTIwNWI2NzNjNzQpO1xyXG5Cb3JkZXJfMjBhYTM0NWViZDEwNDY3ZjhhMDFkNTIwNWI2NzNjNzQuTmFtZSA9IFwiT3V0ZXJCb3JkZXJcIjtcclxudGVtcGxhdGVPd25lcl9Db250cm9sVGVtcGxhdGVfZDk1MGZmMmJlOTAzNDc3NDhjOTUzNjhmMGE3OWE0Y2YuUmVnaXN0ZXJOYW1lKFwiQ29tbW9uU3RhdGVzXCIsIFZpc3VhbFN0YXRlR3JvdXBfZmIwZGYzY2VkOWY1NDU2ZjhhMWEwZDBiOTA3ODc3MmEpO1xyXG5WaXN1YWxTdGF0ZUdyb3VwX2ZiMGRmM2NlZDlmNTQ1NmY4YTFhMGQwYjkwNzg3NzJhLk5hbWUgPSBcIkNvbW1vblN0YXRlc1wiO1xyXG50ZW1wbGF0ZU93bmVyX0NvbnRyb2xUZW1wbGF0ZV9kOTUwZmYyYmU5MDM0Nzc0OGM5NTM2OGYwYTc5YTRjZi5SZWdpc3Rlck5hbWUoXCJOb3JtYWxcIiwgVmlzdWFsU3RhdGVfNTc4MTQ5MGZlOWE4NDQxMTllZjk5MmJmNzlkMTY2ZWEpO1xyXG5WaXN1YWxTdGF0ZV81NzgxNDkwZmU5YTg0NDExOWVmOTkyYmY3OWQxNjZlYS5OYW1lID0gXCJOb3JtYWxcIjtcclxuXHJcbnRlbXBsYXRlT3duZXJfQ29udHJvbFRlbXBsYXRlX2Q5NTBmZjJiZTkwMzQ3NzQ4Yzk1MzY4ZjBhNzlhNGNmLlJlZ2lzdGVyTmFtZShcIlBvaW50ZXJPdmVyXCIsIFZpc3VhbFN0YXRlX2IwNmVmYmFmNWJkMjRmMzg5MzI3NGU5ZjUzM2JiNjZjKTtcclxuVmlzdWFsU3RhdGVfYjA2ZWZiYWY1YmQyNGYzODkzMjc0ZTlmNTMzYmI2NmMuTmFtZSA9IFwiUG9pbnRlck92ZXJcIjtcclxudmFyIFN0b3J5Ym9hcmRfODg3YWViM2MwZWE2NGZmM2FlNWY1MmJhNTk1MzNjNmQgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuTWVkaWEuQW5pbWF0aW9uLlN0b3J5Ym9hcmQoKTtcclxudmFyIE9iamVjdEFuaW1hdGlvblVzaW5nS2V5RnJhbWVzX2M2YjA2YzllNGFlYjQ0MDQ4YWQwMGIwMWM3OTZlZDNlID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLk1lZGlhLkFuaW1hdGlvbi5PYmplY3RBbmltYXRpb25Vc2luZ0tleUZyYW1lcygpO1xyXG5nbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5NZWRpYS5BbmltYXRpb24uU3Rvcnlib2FyZC5TZXRUYXJnZXROYW1lKE9iamVjdEFuaW1hdGlvblVzaW5nS2V5RnJhbWVzX2M2YjA2YzllNGFlYjQ0MDQ4YWQwMGIwMWM3OTZlZDNlLEBcIklubmVyQm9yZGVyXCIpO1xyXG52YXIgRGlzY3JldGVPYmplY3RLZXlGcmFtZV84NmE2ZDdkNDU4OTc0OWFlYjk4NjVmOTRkY2NmNDQzZiA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5NZWRpYS5BbmltYXRpb24uRGlzY3JldGVPYmplY3RLZXlGcmFtZSgpO1xyXG5EaXNjcmV0ZU9iamVjdEtleUZyYW1lXzg2YTZkN2Q0NTg5NzQ5YWViOTg2NWY5NGRjY2Y0NDNmLktleVRpbWUgPSBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5NZWRpYS5BbmltYXRpb24uS2V5VGltZS5Gcm9tVGltZVNwYW4obmV3IGdsb2JhbDo6U3lzdGVtLlRpbWVTcGFuKDBMKSk7XHJcbkRpc2NyZXRlT2JqZWN0S2V5RnJhbWVfODZhNmQ3ZDQ1ODk3NDlhZWI5ODY1Zjk0ZGNjZjQ0M2YuVmFsdWUgPSBAXCIjMTEwMDAwMDBcIjtcclxuXHJcbk9iamVjdEFuaW1hdGlvblVzaW5nS2V5RnJhbWVzX2M2YjA2YzllNGFlYjQ0MDQ4YWQwMGIwMWM3OTZlZDNlLktleUZyYW1lcy5BZGQoRGlzY3JldGVPYmplY3RLZXlGcmFtZV84NmE2ZDdkNDU4OTc0OWFlYjk4NjVmOTRkY2NmNDQzZik7XHJcblxyXG5cclxuU3Rvcnlib2FyZF84ODdhZWIzYzBlYTY0ZmYzYWU1ZjUyYmE1OTUzM2M2ZC5DaGlsZHJlbi5BZGQoT2JqZWN0QW5pbWF0aW9uVXNpbmdLZXlGcmFtZXNfYzZiMDZjOWU0YWViNDQwNDhhZDAwYjAxYzc5NmVkM2UpO1xyXG5cclxuXHJcblZpc3VhbFN0YXRlX2IwNmVmYmFmNWJkMjRmMzg5MzI3NGU5ZjUzM2JiNjZjLlN0b3J5Ym9hcmQgPSBTdG9yeWJvYXJkXzg4N2FlYjNjMGVhNjRmZjNhZTVmNTJiYTU5NTMzYzZkO1xyXG5cclxuXHJcbnRlbXBsYXRlT3duZXJfQ29udHJvbFRlbXBsYXRlX2Q5NTBmZjJiZTkwMzQ3NzQ4Yzk1MzY4ZjBhNzlhNGNmLlJlZ2lzdGVyTmFtZShcIlByZXNzZWRcIiwgVmlzdWFsU3RhdGVfM2E5YjZmZDU4OTVkNDA2Yzk5YjkxNjJjYWQ0ZGNhYTgpO1xyXG5WaXN1YWxTdGF0ZV8zYTliNmZkNTg5NWQ0MDZjOTliOTE2MmNhZDRkY2FhOC5OYW1lID0gXCJQcmVzc2VkXCI7XHJcbnZhciBTdG9yeWJvYXJkX2Y3NTg2Y2FmYzViYzRiYTk4MTczNTg5NmRiODRjZjQxID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLk1lZGlhLkFuaW1hdGlvbi5TdG9yeWJvYXJkKCk7XHJcbnZhciBPYmplY3RBbmltYXRpb25Vc2luZ0tleUZyYW1lc184ZmJkNjUxOGIyOWI0YzE2YmQxZDI0YTY1ZjRmNDk1ZCA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5NZWRpYS5BbmltYXRpb24uT2JqZWN0QW5pbWF0aW9uVXNpbmdLZXlGcmFtZXMoKTtcclxuZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuTWVkaWEuQW5pbWF0aW9uLlN0b3J5Ym9hcmQuU2V0VGFyZ2V0TmFtZShPYmplY3RBbmltYXRpb25Vc2luZ0tleUZyYW1lc184ZmJkNjUxOGIyOWI0YzE2YmQxZDI0YTY1ZjRmNDk1ZCxAXCJJbm5lckJvcmRlclwiKTtcclxudmFyIERpc2NyZXRlT2JqZWN0S2V5RnJhbWVfMWM4NThmZTU5ZTEzNDA1OGJiMTlkZTZkOThjYjM5Y2IgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuTWVkaWEuQW5pbWF0aW9uLkRpc2NyZXRlT2JqZWN0S2V5RnJhbWUoKTtcclxuRGlzY3JldGVPYmplY3RLZXlGcmFtZV8xYzg1OGZlNTllMTM0MDU4YmIxOWRlNmQ5OGNiMzljYi5LZXlUaW1lID0gZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuTWVkaWEuQW5pbWF0aW9uLktleVRpbWUuRnJvbVRpbWVTcGFuKG5ldyBnbG9iYWw6OlN5c3RlbS5UaW1lU3BhbigwTCkpO1xyXG5EaXNjcmV0ZU9iamVjdEtleUZyYW1lXzFjODU4ZmU1OWUxMzQwNThiYjE5ZGU2ZDk4Y2IzOWNiLlZhbHVlID0gQFwiIzIyMDAwMDAwXCI7XHJcblxyXG5PYmplY3RBbmltYXRpb25Vc2luZ0tleUZyYW1lc184ZmJkNjUxOGIyOWI0YzE2YmQxZDI0YTY1ZjRmNDk1ZC5LZXlGcmFtZXMuQWRkKERpc2NyZXRlT2JqZWN0S2V5RnJhbWVfMWM4NThmZTU5ZTEzNDA1OGJiMTlkZTZkOThjYjM5Y2IpO1xyXG5cclxuXHJcblN0b3J5Ym9hcmRfZjc1ODZjYWZjNWJjNGJhOTgxNzM1ODk2ZGI4NGNmNDEuQ2hpbGRyZW4uQWRkKE9iamVjdEFuaW1hdGlvblVzaW5nS2V5RnJhbWVzXzhmYmQ2NTE4YjI5YjRjMTZiZDFkMjRhNjVmNGY0OTVkKTtcclxuXHJcblxyXG5WaXN1YWxTdGF0ZV8zYTliNmZkNTg5NWQ0MDZjOTliOTE2MmNhZDRkY2FhOC5TdG9yeWJvYXJkID0gU3Rvcnlib2FyZF9mNzU4NmNhZmM1YmM0YmE5ODE3MzU4OTZkYjg0Y2Y0MTtcclxuXHJcblxyXG50ZW1wbGF0ZU93bmVyX0NvbnRyb2xUZW1wbGF0ZV9kOTUwZmYyYmU5MDM0Nzc0OGM5NTM2OGYwYTc5YTRjZi5SZWdpc3Rlck5hbWUoXCJEaXNhYmxlZFwiLCBWaXN1YWxTdGF0ZV9lY2NkNjc1YmJkYmE0Nzg2OTJkMzlmYzkxYmM4MDE4Zik7XHJcblZpc3VhbFN0YXRlX2VjY2Q2NzViYmRiYTQ3ODY5MmQzOWZjOTFiYzgwMThmLk5hbWUgPSBcIkRpc2FibGVkXCI7XHJcbnZhciBTdG9yeWJvYXJkX2RlMmQyNTFiMmQ0NTRmYTI4NmFjMzZmYWQ5YWZjOThjID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLk1lZGlhLkFuaW1hdGlvbi5TdG9yeWJvYXJkKCk7XHJcbnZhciBPYmplY3RBbmltYXRpb25Vc2luZ0tleUZyYW1lc183ZGFlY2RhNWExZTU0MmM0ODc0MTU4M2VkNDA4ZjIwOCA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5NZWRpYS5BbmltYXRpb24uT2JqZWN0QW5pbWF0aW9uVXNpbmdLZXlGcmFtZXMoKTtcclxuZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuTWVkaWEuQW5pbWF0aW9uLlN0b3J5Ym9hcmQuU2V0VGFyZ2V0TmFtZShPYmplY3RBbmltYXRpb25Vc2luZ0tleUZyYW1lc183ZGFlY2RhNWExZTU0MmM0ODc0MTU4M2VkNDA4ZjIwOCxAXCJJbm5lckJvcmRlclwiKTtcclxudmFyIERpc2NyZXRlT2JqZWN0S2V5RnJhbWVfYmMwMjNjN2ViNzBkNGQ5NWEyODNiYjcxYTNmNWI2MzEgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuTWVkaWEuQW5pbWF0aW9uLkRpc2NyZXRlT2JqZWN0S2V5RnJhbWUoKTtcclxuRGlzY3JldGVPYmplY3RLZXlGcmFtZV9iYzAyM2M3ZWI3MGQ0ZDk1YTI4M2JiNzFhM2Y1YjYzMS5LZXlUaW1lID0gZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuTWVkaWEuQW5pbWF0aW9uLktleVRpbWUuRnJvbVRpbWVTcGFuKG5ldyBnbG9iYWw6OlN5c3RlbS5UaW1lU3BhbigwTCkpO1xyXG5EaXNjcmV0ZU9iamVjdEtleUZyYW1lX2JjMDIzYzdlYjcwZDRkOTVhMjgzYmI3MWEzZjViNjMxLlZhbHVlID0gQFwiIzMzRkZGRkZGXCI7XHJcblxyXG5PYmplY3RBbmltYXRpb25Vc2luZ0tleUZyYW1lc183ZGFlY2RhNWExZTU0MmM0ODc0MTU4M2VkNDA4ZjIwOC5LZXlGcmFtZXMuQWRkKERpc2NyZXRlT2JqZWN0S2V5RnJhbWVfYmMwMjNjN2ViNzBkNGQ5NWEyODNiYjcxYTNmNWI2MzEpO1xyXG5cclxuXHJcblN0b3J5Ym9hcmRfZGUyZDI1MWIyZDQ1NGZhMjg2YWMzNmZhZDlhZmM5OGMuQ2hpbGRyZW4uQWRkKE9iamVjdEFuaW1hdGlvblVzaW5nS2V5RnJhbWVzXzdkYWVjZGE1YTFlNTQyYzQ4NzQxNTgzZWQ0MDhmMjA4KTtcclxuXHJcblxyXG5WaXN1YWxTdGF0ZV9lY2NkNjc1YmJkYmE0Nzg2OTJkMzlmYzkxYmM4MDE4Zi5TdG9yeWJvYXJkID0gU3Rvcnlib2FyZF9kZTJkMjUxYjJkNDU0ZmEyODZhYzM2ZmFkOWFmYzk4YztcclxuXHJcblxyXG5WaXN1YWxTdGF0ZUdyb3VwX2ZiMGRmM2NlZDlmNTQ1NmY4YTFhMGQwYjkwNzg3NzJhLlN0YXRlcy5BZGQoVmlzdWFsU3RhdGVfNTc4MTQ5MGZlOWE4NDQxMTllZjk5MmJmNzlkMTY2ZWEpO1xyXG5WaXN1YWxTdGF0ZUdyb3VwX2ZiMGRmM2NlZDlmNTQ1NmY4YTFhMGQwYjkwNzg3NzJhLlN0YXRlcy5BZGQoVmlzdWFsU3RhdGVfYjA2ZWZiYWY1YmQyNGYzODkzMjc0ZTlmNTMzYmI2NmMpO1xyXG5WaXN1YWxTdGF0ZUdyb3VwX2ZiMGRmM2NlZDlmNTQ1NmY4YTFhMGQwYjkwNzg3NzJhLlN0YXRlcy5BZGQoVmlzdWFsU3RhdGVfM2E5YjZmZDU4OTVkNDA2Yzk5YjkxNjJjYWQ0ZGNhYTgpO1xyXG5WaXN1YWxTdGF0ZUdyb3VwX2ZiMGRmM2NlZDlmNTQ1NmY4YTFhMGQwYjkwNzg3NzJhLlN0YXRlcy5BZGQoVmlzdWFsU3RhdGVfZWNjZDY3NWJiZGJhNDc4NjkyZDM5ZmM5MWJjODAxOGYpO1xyXG5cclxuXHJcbnRlbXBsYXRlT3duZXJfQ29udHJvbFRlbXBsYXRlX2Q5NTBmZjJiZTkwMzQ3NzQ4Yzk1MzY4ZjBhNzlhNGNmLklOVEVSTkFMX0dldFZpc3VhbFN0YXRlR3JvdXBzKCkuQWRkKFZpc3VhbFN0YXRlR3JvdXBfZmIwZGYzY2VkOWY1NDU2ZjhhMWEwZDBiOTA3ODc3MmEpO1xyXG5cclxudGVtcGxhdGVPd25lcl9Db250cm9sVGVtcGxhdGVfZDk1MGZmMmJlOTAzNDc3NDhjOTUzNjhmMGE3OWE0Y2YuUmVnaXN0ZXJOYW1lKFwiSW5uZXJCb3JkZXJcIiwgQm9yZGVyXzVkYzg4MjgzNjE3ODQ5YThhZmIyNGUxMTg2YjZlZmQ0KTtcclxuQm9yZGVyXzVkYzg4MjgzNjE3ODQ5YThhZmIyNGUxMTg2YjZlZmQ0Lk5hbWUgPSBcIklubmVyQm9yZGVyXCI7XHJcbnRlbXBsYXRlT3duZXJfQ29udHJvbFRlbXBsYXRlX2Q5NTBmZjJiZTkwMzQ3NzQ4Yzk1MzY4ZjBhNzlhNGNmLlJlZ2lzdGVyTmFtZShcIkNvbnRlbnRQcmVzZW50ZXJcIiwgQ29udGVudFByZXNlbnRlcl84YzI2MzZmYTM1MjI0YmI5OWNhZmJhYzE0OTc2NDJhYyk7XHJcbkNvbnRlbnRQcmVzZW50ZXJfOGMyNjM2ZmEzNTIyNGJiOTljYWZiYWMxNDk3NjQyYWMuTmFtZSA9IFwiQ29udGVudFByZXNlbnRlclwiO1xyXG52YXIgQmluZGluZ19hMWRiNDU0YTlkNzk0NzM5OTdmYTY1NTc3YmM4Njc3NSA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmcoKTtcclxuQmluZGluZ19hMWRiNDU0YTlkNzk0NzM5OTdmYTY1NTc3YmM4Njc3NS5QYXRoID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlByb3BlcnR5UGF0aChAXCJDb250ZW50VGVtcGxhdGVcIik7XHJcbnZhciBSZWxhdGl2ZVNvdXJjZV8yYmUwZjU4OTkwNDI0OWUxOGYyZDk1MGYwY2Y3N2Y1MCA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLlJlbGF0aXZlU291cmNlKCk7XHJcblJlbGF0aXZlU291cmNlXzJiZTBmNTg5OTA0MjQ5ZTE4ZjJkOTUwZjBjZjc3ZjUwLk1vZGUgPSBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLlJlbGF0aXZlU291cmNlTW9kZS5UZW1wbGF0ZWRQYXJlbnQ7XHJcblxyXG5CaW5kaW5nX2ExZGI0NTRhOWQ3OTQ3Mzk5N2ZhNjU1NzdiYzg2Nzc1LlJlbGF0aXZlU291cmNlID0gUmVsYXRpdmVTb3VyY2VfMmJlMGY1ODk5MDQyNDllMThmMmQ5NTBmMGNmNzdmNTA7XHJcblxyXG5cclxuQmluZGluZ19hMWRiNDU0YTlkNzk0NzM5OTdmYTY1NTc3YmM4Njc3NS5UZW1wbGF0ZU93bmVyID0gdGVtcGxhdGVJbnN0YW5jZV9kYjA2NTM4Y2RkMTE0NzRiYmI1MzNhNzJlMTgyYTc4MTtcclxuXHJcbnZhciBCaW5kaW5nXzNmYzdlYWQwMmFjODQyZDdiNWVkMDU2NzVjZjc2YTNjID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuQmluZGluZygpO1xyXG5CaW5kaW5nXzNmYzdlYWQwMmFjODQyZDdiNWVkMDU2NzVjZjc2YTNjLlBhdGggPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuUHJvcGVydHlQYXRoKEBcIkNvbnRlbnRcIik7XHJcbnZhciBSZWxhdGl2ZVNvdXJjZV9lYTBmYjM3Njk4MDE0OWJmOTgzNzBlZTYwZTY1MzBiNyA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLlJlbGF0aXZlU291cmNlKCk7XHJcblJlbGF0aXZlU291cmNlX2VhMGZiMzc2OTgwMTQ5YmY5ODM3MGVlNjBlNjUzMGI3Lk1vZGUgPSBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLlJlbGF0aXZlU291cmNlTW9kZS5UZW1wbGF0ZWRQYXJlbnQ7XHJcblxyXG5CaW5kaW5nXzNmYzdlYWQwMmFjODQyZDdiNWVkMDU2NzVjZjc2YTNjLlJlbGF0aXZlU291cmNlID0gUmVsYXRpdmVTb3VyY2VfZWEwZmIzNzY5ODAxNDliZjk4MzcwZWU2MGU2NTMwYjc7XHJcblxyXG5cclxuQmluZGluZ18zZmM3ZWFkMDJhYzg0MmQ3YjVlZDA1Njc1Y2Y3NmEzYy5UZW1wbGF0ZU93bmVyID0gdGVtcGxhdGVJbnN0YW5jZV9kYjA2NTM4Y2RkMTE0NzRiYmI1MzNhNzJlMTgyYTc4MTtcclxuXHJcbnZhciBCaW5kaW5nX2Y0NjQ0NDMyNmYxNzRmM2JhNjM4NDM4NjJhOTA3OWIzID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuQmluZGluZygpO1xyXG5CaW5kaW5nX2Y0NjQ0NDMyNmYxNzRmM2JhNjM4NDM4NjJhOTA3OWIzLlBhdGggPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuUHJvcGVydHlQYXRoKEBcIkhlaWdodFwiKTtcclxudmFyIFJlbGF0aXZlU291cmNlXzY0ZDE5ZmRiM2ZmZTRjMTRiNjY0MjdlZGExMDg5NzFjID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuUmVsYXRpdmVTb3VyY2UoKTtcclxuUmVsYXRpdmVTb3VyY2VfNjRkMTlmZGIzZmZlNGMxNGI2NjQyN2VkYTEwODk3MWMuTW9kZSA9IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuUmVsYXRpdmVTb3VyY2VNb2RlLlRlbXBsYXRlZFBhcmVudDtcclxuXHJcbkJpbmRpbmdfZjQ2NDQ0MzI2ZjE3NGYzYmE2Mzg0Mzg2MmE5MDc5YjMuUmVsYXRpdmVTb3VyY2UgPSBSZWxhdGl2ZVNvdXJjZV82NGQxOWZkYjNmZmU0YzE0YjY2NDI3ZWRhMTA4OTcxYztcclxuXHJcblxyXG5CaW5kaW5nX2Y0NjQ0NDMyNmYxNzRmM2JhNjM4NDM4NjJhOTA3OWIzLlRlbXBsYXRlT3duZXIgPSB0ZW1wbGF0ZUluc3RhbmNlX2RiMDY1MzhjZGQxMTQ3NGJiYjUzM2E3MmUxODJhNzgxO1xyXG5cclxudmFyIEJpbmRpbmdfZTBlODgwNGExODI0NDJlNTkzYmU5ZjZiMDAwNTlhYTMgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5CaW5kaW5nKCk7XHJcbkJpbmRpbmdfZTBlODgwNGExODI0NDJlNTkzYmU5ZjZiMDAwNTlhYTMuUGF0aCA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Qcm9wZXJ0eVBhdGgoQFwiV2lkdGhcIik7XHJcbnZhciBSZWxhdGl2ZVNvdXJjZV81MDY0ZGUwNDFlZjk0N2QxOGVlNTc2ZjQwOWI4ODExMCA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLlJlbGF0aXZlU291cmNlKCk7XHJcblJlbGF0aXZlU291cmNlXzUwNjRkZTA0MWVmOTQ3ZDE4ZWU1NzZmNDA5Yjg4MTEwLk1vZGUgPSBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLlJlbGF0aXZlU291cmNlTW9kZS5UZW1wbGF0ZWRQYXJlbnQ7XHJcblxyXG5CaW5kaW5nX2UwZTg4MDRhMTgyNDQyZTU5M2JlOWY2YjAwMDU5YWEzLlJlbGF0aXZlU291cmNlID0gUmVsYXRpdmVTb3VyY2VfNTA2NGRlMDQxZWY5NDdkMThlZTU3NmY0MDliODgxMTA7XHJcblxyXG5cclxuQmluZGluZ19lMGU4ODA0YTE4MjQ0MmU1OTNiZTlmNmIwMDA1OWFhMy5UZW1wbGF0ZU93bmVyID0gdGVtcGxhdGVJbnN0YW5jZV9kYjA2NTM4Y2RkMTE0NzRiYmI1MzNhNzJlMTgyYTc4MTtcclxuXHJcbnZhciBCaW5kaW5nX2FmMzQyNmUzYzFmOTQ3YmFhMmQ0ZGUxZmI4M2ZmYTFkID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuQmluZGluZygpO1xyXG5CaW5kaW5nX2FmMzQyNmUzYzFmOTQ3YmFhMmQ0ZGUxZmI4M2ZmYTFkLlBhdGggPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuUHJvcGVydHlQYXRoKEBcIlBhZGRpbmdcIik7XHJcbnZhciBSZWxhdGl2ZVNvdXJjZV9hYzEzYTBhNWY3ZDE0ZGMzOWFjY2I2MzM2NzcxNDNiZiA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLlJlbGF0aXZlU291cmNlKCk7XHJcblJlbGF0aXZlU291cmNlX2FjMTNhMGE1ZjdkMTRkYzM5YWNjYjYzMzY3NzE0M2JmLk1vZGUgPSBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLlJlbGF0aXZlU291cmNlTW9kZS5UZW1wbGF0ZWRQYXJlbnQ7XHJcblxyXG5CaW5kaW5nX2FmMzQyNmUzYzFmOTQ3YmFhMmQ0ZGUxZmI4M2ZmYTFkLlJlbGF0aXZlU291cmNlID0gUmVsYXRpdmVTb3VyY2VfYWMxM2EwYTVmN2QxNGRjMzlhY2NiNjMzNjc3MTQzYmY7XHJcblxyXG5cclxuQmluZGluZ19hZjM0MjZlM2MxZjk0N2JhYTJkNGRlMWZiODNmZmExZC5UZW1wbGF0ZU93bmVyID0gdGVtcGxhdGVJbnN0YW5jZV9kYjA2NTM4Y2RkMTE0NzRiYmI1MzNhNzJlMTgyYTc4MTtcclxuXHJcbnZhciBCaW5kaW5nXzMyZGY5YWY2MDAxZTQyYTk4NmJkMWNhNzdjNmY5NmY2ID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuQmluZGluZygpO1xyXG5CaW5kaW5nXzMyZGY5YWY2MDAxZTQyYTk4NmJkMWNhNzdjNmY5NmY2LlBhdGggPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuUHJvcGVydHlQYXRoKEBcIkhvcml6b250YWxDb250ZW50QWxpZ25tZW50XCIpO1xyXG52YXIgUmVsYXRpdmVTb3VyY2VfMWIwZmM2YTZmMGFlNDhkNzkzOTFiYWRmZWY1NDI4MTAgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5SZWxhdGl2ZVNvdXJjZSgpO1xyXG5SZWxhdGl2ZVNvdXJjZV8xYjBmYzZhNmYwYWU0OGQ3OTM5MWJhZGZlZjU0MjgxMC5Nb2RlID0gZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5SZWxhdGl2ZVNvdXJjZU1vZGUuVGVtcGxhdGVkUGFyZW50O1xyXG5cclxuQmluZGluZ18zMmRmOWFmNjAwMWU0MmE5ODZiZDFjYTc3YzZmOTZmNi5SZWxhdGl2ZVNvdXJjZSA9IFJlbGF0aXZlU291cmNlXzFiMGZjNmE2ZjBhZTQ4ZDc5MzkxYmFkZmVmNTQyODEwO1xyXG5cclxuXHJcbkJpbmRpbmdfMzJkZjlhZjYwMDFlNDJhOTg2YmQxY2E3N2M2Zjk2ZjYuVGVtcGxhdGVPd25lciA9IHRlbXBsYXRlSW5zdGFuY2VfZGIwNjUzOGNkZDExNDc0YmJiNTMzYTcyZTE4MmE3ODE7XHJcblxyXG52YXIgQmluZGluZ182ZTk0ODZlMzAzYzE0MDc2OWVmMmRjMWIzZGFkYzJkMyA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmcoKTtcclxuQmluZGluZ182ZTk0ODZlMzAzYzE0MDc2OWVmMmRjMWIzZGFkYzJkMy5QYXRoID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlByb3BlcnR5UGF0aChAXCJWZXJ0aWNhbENvbnRlbnRBbGlnbm1lbnRcIik7XHJcbnZhciBSZWxhdGl2ZVNvdXJjZV9jZmNiMmM2NTFkOGY0NzE5YWM2YjZlYzAxNzljNTRiYiA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLlJlbGF0aXZlU291cmNlKCk7XHJcblJlbGF0aXZlU291cmNlX2NmY2IyYzY1MWQ4ZjQ3MTlhYzZiNmVjMDE3OWM1NGJiLk1vZGUgPSBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLlJlbGF0aXZlU291cmNlTW9kZS5UZW1wbGF0ZWRQYXJlbnQ7XHJcblxyXG5CaW5kaW5nXzZlOTQ4NmUzMDNjMTQwNzY5ZWYyZGMxYjNkYWRjMmQzLlJlbGF0aXZlU291cmNlID0gUmVsYXRpdmVTb3VyY2VfY2ZjYjJjNjUxZDhmNDcxOWFjNmI2ZWMwMTc5YzU0YmI7XHJcblxyXG5cclxuQmluZGluZ182ZTk0ODZlMzAzYzE0MDc2OWVmMmRjMWIzZGFkYzJkMy5UZW1wbGF0ZU93bmVyID0gdGVtcGxhdGVJbnN0YW5jZV9kYjA2NTM4Y2RkMTE0NzRiYmI1MzNhNzJlMTgyYTc4MTtcclxuXHJcbnZhciBCaW5kaW5nXzg5MWVlMzYzMWYyNDRlYjA5Y2NmNWI3M2Y2ZDIyYTYwID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuQmluZGluZygpO1xyXG5CaW5kaW5nXzg5MWVlMzYzMWYyNDRlYjA5Y2NmNWI3M2Y2ZDIyYTYwLlBhdGggPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuUHJvcGVydHlQYXRoKEBcIlZpc2liaWxpdHlcIik7XHJcblxyXG5cclxuXHJcbkJvcmRlcl81ZGM4ODI4MzYxNzg0OWE4YWZiMjRlMTE4NmI2ZWZkNC5DaGlsZCA9IENvbnRlbnRQcmVzZW50ZXJfOGMyNjM2ZmEzNTIyNGJiOTljYWZiYWMxNDk3NjQyYWM7XHJcblxyXG52YXIgQmluZGluZ19iMjY0ZjMxNDU2ZGE0NDUzYjI1ZDRlZDkyOWJhOWNkYSA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmcoKTtcclxuQmluZGluZ19iMjY0ZjMxNDU2ZGE0NDUzYjI1ZDRlZDkyOWJhOWNkYS5QYXRoID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlByb3BlcnR5UGF0aChAXCJCYWNrZ3JvdW5kXCIpO1xyXG52YXIgUmVsYXRpdmVTb3VyY2VfM2UyYjhmMjUzYzAxNDZiOTkwYjI1ZWE1YjUyODcwMWEgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5SZWxhdGl2ZVNvdXJjZSgpO1xyXG5SZWxhdGl2ZVNvdXJjZV8zZTJiOGYyNTNjMDE0NmI5OTBiMjVlYTViNTI4NzAxYS5Nb2RlID0gZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5SZWxhdGl2ZVNvdXJjZU1vZGUuVGVtcGxhdGVkUGFyZW50O1xyXG5cclxuQmluZGluZ19iMjY0ZjMxNDU2ZGE0NDUzYjI1ZDRlZDkyOWJhOWNkYS5SZWxhdGl2ZVNvdXJjZSA9IFJlbGF0aXZlU291cmNlXzNlMmI4ZjI1M2MwMTQ2Yjk5MGIyNWVhNWI1Mjg3MDFhO1xyXG5cclxuXHJcbkJpbmRpbmdfYjI2NGYzMTQ1NmRhNDQ1M2IyNWQ0ZWQ5MjliYTljZGEuVGVtcGxhdGVPd25lciA9IHRlbXBsYXRlSW5zdGFuY2VfZGIwNjUzOGNkZDExNDc0YmJiNTMzYTcyZTE4MmE3ODE7XHJcblxyXG5cclxuQm9yZGVyXzIwYWEzNDVlYmQxMDQ2N2Y4YTAxZDUyMDViNjczYzc0LkNoaWxkID0gQm9yZGVyXzVkYzg4MjgzNjE3ODQ5YThhZmIyNGUxMTg2YjZlZmQ0O1xyXG5cclxudmFyIEJpbmRpbmdfNmQ0YjMyODNjYTRjNDViZWEyZWVkMzM3NGU1ODdiNmIgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5CaW5kaW5nKCk7XHJcbkJpbmRpbmdfNmQ0YjMyODNjYTRjNDViZWEyZWVkMzM3NGU1ODdiNmIuUGF0aCA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Qcm9wZXJ0eVBhdGgoQFwiQmFja2dyb3VuZFwiKTtcclxudmFyIFJlbGF0aXZlU291cmNlX2U0NDQ1ODc2OWM0ZDQ2NzQ5ZGYxNmRhYWQyMmU4OTFlID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuUmVsYXRpdmVTb3VyY2UoKTtcclxuUmVsYXRpdmVTb3VyY2VfZTQ0NDU4NzY5YzRkNDY3NDlkZjE2ZGFhZDIyZTg5MWUuTW9kZSA9IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuUmVsYXRpdmVTb3VyY2VNb2RlLlRlbXBsYXRlZFBhcmVudDtcclxuXHJcbkJpbmRpbmdfNmQ0YjMyODNjYTRjNDViZWEyZWVkMzM3NGU1ODdiNmIuUmVsYXRpdmVTb3VyY2UgPSBSZWxhdGl2ZVNvdXJjZV9lNDQ0NTg3NjljNGQ0Njc0OWRmMTZkYWFkMjJlODkxZTtcclxuXHJcblxyXG5CaW5kaW5nXzZkNGIzMjgzY2E0YzQ1YmVhMmVlZDMzNzRlNTg3YjZiLlRlbXBsYXRlT3duZXIgPSB0ZW1wbGF0ZUluc3RhbmNlX2RiMDY1MzhjZGQxMTQ3NGJiYjUzM2E3MmUxODJhNzgxO1xyXG5cclxudmFyIEJpbmRpbmdfNDRlYjAyMGJmNWVmNDNlNTkwZTc1YTFmZGQxMTJlNTYgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5CaW5kaW5nKCk7XHJcbkJpbmRpbmdfNDRlYjAyMGJmNWVmNDNlNTkwZTc1YTFmZGQxMTJlNTYuUGF0aCA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Qcm9wZXJ0eVBhdGgoQFwiQm9yZGVyQnJ1c2hcIik7XHJcbnZhciBSZWxhdGl2ZVNvdXJjZV8wMGQ3YTViM2E2ZDY0NTlkYjdiZTcwMDUwM2VlODZiZiA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLlJlbGF0aXZlU291cmNlKCk7XHJcblJlbGF0aXZlU291cmNlXzAwZDdhNWIzYTZkNjQ1OWRiN2JlNzAwNTAzZWU4NmJmLk1vZGUgPSBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLlJlbGF0aXZlU291cmNlTW9kZS5UZW1wbGF0ZWRQYXJlbnQ7XHJcblxyXG5CaW5kaW5nXzQ0ZWIwMjBiZjVlZjQzZTU5MGU3NWExZmRkMTEyZTU2LlJlbGF0aXZlU291cmNlID0gUmVsYXRpdmVTb3VyY2VfMDBkN2E1YjNhNmQ2NDU5ZGI3YmU3MDA1MDNlZTg2YmY7XHJcblxyXG5cclxuQmluZGluZ180NGViMDIwYmY1ZWY0M2U1OTBlNzVhMWZkZDExMmU1Ni5UZW1wbGF0ZU93bmVyID0gdGVtcGxhdGVJbnN0YW5jZV9kYjA2NTM4Y2RkMTE0NzRiYmI1MzNhNzJlMTgyYTc4MTtcclxuXHJcbnZhciBCaW5kaW5nXzBmOWJjODM2ZTA4MDRkMDE4OTNhOWFmN2EzOGY4OTk1ID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuQmluZGluZygpO1xyXG5CaW5kaW5nXzBmOWJjODM2ZTA4MDRkMDE4OTNhOWFmN2EzOGY4OTk1LlBhdGggPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuUHJvcGVydHlQYXRoKEBcIkJvcmRlclRoaWNrbmVzc1wiKTtcclxudmFyIFJlbGF0aXZlU291cmNlXzExN2U5ZTAxMmIwOTQ1YWQ4MWNjY2ZjMTRmOWJmNTMzID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuUmVsYXRpdmVTb3VyY2UoKTtcclxuUmVsYXRpdmVTb3VyY2VfMTE3ZTllMDEyYjA5NDVhZDgxY2NjZmMxNGY5YmY1MzMuTW9kZSA9IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuUmVsYXRpdmVTb3VyY2VNb2RlLlRlbXBsYXRlZFBhcmVudDtcclxuXHJcbkJpbmRpbmdfMGY5YmM4MzZlMDgwNGQwMTg5M2E5YWY3YTM4Zjg5OTUuUmVsYXRpdmVTb3VyY2UgPSBSZWxhdGl2ZVNvdXJjZV8xMTdlOWUwMTJiMDk0NWFkODFjY2NmYzE0ZjliZjUzMztcclxuXHJcblxyXG5CaW5kaW5nXzBmOWJjODM2ZTA4MDRkMDE4OTNhOWFmN2EzOGY4OTk1LlRlbXBsYXRlT3duZXIgPSB0ZW1wbGF0ZUluc3RhbmNlX2RiMDY1MzhjZGQxMTQ3NGJiYjUzM2E3MmUxODJhNzgxO1xyXG5cclxudmFyIEJpbmRpbmdfMmE1Zjc2NTk1OWI4NGU0MThlZGVmMjgxYzkwMzVjY2YgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5CaW5kaW5nKCk7XHJcbkJpbmRpbmdfMmE1Zjc2NTk1OWI4NGU0MThlZGVmMjgxYzkwMzVjY2YuUGF0aCA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Qcm9wZXJ0eVBhdGgoQFwiTWFyZ2luXCIpO1xyXG52YXIgUmVsYXRpdmVTb3VyY2VfZjIzYTFhYTI2ZmZjNGNhNzhlMjE4OGZkNjI0ODEyNDAgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5SZWxhdGl2ZVNvdXJjZSgpO1xyXG5SZWxhdGl2ZVNvdXJjZV9mMjNhMWFhMjZmZmM0Y2E3OGUyMTg4ZmQ2MjQ4MTI0MC5Nb2RlID0gZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5SZWxhdGl2ZVNvdXJjZU1vZGUuVGVtcGxhdGVkUGFyZW50O1xyXG5cclxuQmluZGluZ18yYTVmNzY1OTU5Yjg0ZTQxOGVkZWYyODFjOTAzNWNjZi5SZWxhdGl2ZVNvdXJjZSA9IFJlbGF0aXZlU291cmNlX2YyM2ExYWEyNmZmYzRjYTc4ZTIxODhmZDYyNDgxMjQwO1xyXG5cclxuXHJcbkJpbmRpbmdfMmE1Zjc2NTk1OWI4NGU0MThlZGVmMjgxYzkwMzVjY2YuVGVtcGxhdGVPd25lciA9IHRlbXBsYXRlSW5zdGFuY2VfZGIwNjUzOGNkZDExNDc0YmJiNTMzYTcyZTE4MmE3ODE7XHJcblxyXG52YXIgQmluZGluZ183MTg3OTYxOTA4MGE0NTA1OTU1ZmZhYWE1ZmM1OTQ4NCA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmcoKTtcclxuQmluZGluZ183MTg3OTYxOTA4MGE0NTA1OTU1ZmZhYWE1ZmM1OTQ4NC5QYXRoID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlByb3BlcnR5UGF0aChAXCJWaXNpYmlsaXR5XCIpO1xyXG5cclxuXHJcblxyXG5nbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmdPcGVyYXRpb25zLlNldEJpbmRpbmcoQ29udGVudFByZXNlbnRlcl84YzI2MzZmYTM1MjI0YmI5OWNhZmJhYzE0OTc2NDJhYywgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuQ29udHJvbHMuQ29udGVudENvbnRyb2wuQ29udGVudFRlbXBsYXRlUHJvcGVydHksIEJpbmRpbmdfYTFkYjQ1NGE5ZDc5NDczOTk3ZmE2NTU3N2JjODY3NzUpO1xyXG5nbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmdPcGVyYXRpb25zLlNldEJpbmRpbmcoQ29udGVudFByZXNlbnRlcl84YzI2MzZmYTM1MjI0YmI5OWNhZmJhYzE0OTc2NDJhYywgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuQ29udHJvbHMuQ29udGVudENvbnRyb2wuQ29udGVudFByb3BlcnR5LCBCaW5kaW5nXzNmYzdlYWQwMmFjODQyZDdiNWVkMDU2NzVjZjc2YTNjKTtcclxuZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5CaW5kaW5nT3BlcmF0aW9ucy5TZXRCaW5kaW5nKENvbnRlbnRQcmVzZW50ZXJfOGMyNjM2ZmEzNTIyNGJiOTljYWZiYWMxNDk3NjQyYWMsIGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkZyYW1ld29ya0VsZW1lbnQuSGVpZ2h0UHJvcGVydHksIEJpbmRpbmdfZjQ2NDQ0MzI2ZjE3NGYzYmE2Mzg0Mzg2MmE5MDc5YjMpO1xyXG5nbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmdPcGVyYXRpb25zLlNldEJpbmRpbmcoQ29udGVudFByZXNlbnRlcl84YzI2MzZmYTM1MjI0YmI5OWNhZmJhYzE0OTc2NDJhYywgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRnJhbWV3b3JrRWxlbWVudC5XaWR0aFByb3BlcnR5LCBCaW5kaW5nX2UwZTg4MDRhMTgyNDQyZTU5M2JlOWY2YjAwMDU5YWEzKTtcclxuZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5CaW5kaW5nT3BlcmF0aW9ucy5TZXRCaW5kaW5nKENvbnRlbnRQcmVzZW50ZXJfOGMyNjM2ZmEzNTIyNGJiOTljYWZiYWMxNDk3NjQyYWMsIGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkZyYW1ld29ya0VsZW1lbnQuTWFyZ2luUHJvcGVydHksIEJpbmRpbmdfYWYzNDI2ZTNjMWY5NDdiYWEyZDRkZTFmYjgzZmZhMWQpO1xyXG5nbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmdPcGVyYXRpb25zLlNldEJpbmRpbmcoQ29udGVudFByZXNlbnRlcl84YzI2MzZmYTM1MjI0YmI5OWNhZmJhYzE0OTc2NDJhYywgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRnJhbWV3b3JrRWxlbWVudC5Ib3Jpem9udGFsQWxpZ25tZW50UHJvcGVydHksIEJpbmRpbmdfMzJkZjlhZjYwMDFlNDJhOTg2YmQxY2E3N2M2Zjk2ZjYpO1xyXG5nbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmdPcGVyYXRpb25zLlNldEJpbmRpbmcoQ29udGVudFByZXNlbnRlcl84YzI2MzZmYTM1MjI0YmI5OWNhZmJhYzE0OTc2NDJhYywgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRnJhbWV3b3JrRWxlbWVudC5WZXJ0aWNhbEFsaWdubWVudFByb3BlcnR5LCBCaW5kaW5nXzZlOTQ4NmUzMDNjMTQwNzY5ZWYyZGMxYjNkYWRjMmQzKTtcclxuZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5CaW5kaW5nT3BlcmF0aW9ucy5TZXRCaW5kaW5nKENvbnRlbnRQcmVzZW50ZXJfOGMyNjM2ZmEzNTIyNGJiOTljYWZiYWMxNDk3NjQyYWMsIGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlVJRWxlbWVudC5WaXNpYmlsaXR5UHJvcGVydHksIEJpbmRpbmdfODkxZWUzNjMxZjI0NGViMDljY2Y1YjczZjZkMjJhNjApO1xyXG5nbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmdPcGVyYXRpb25zLlNldEJpbmRpbmcoQm9yZGVyXzVkYzg4MjgzNjE3ODQ5YThhZmIyNGUxMTg2YjZlZmQ0LCBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Db250cm9scy5Cb3JkZXIuQmFja2dyb3VuZFByb3BlcnR5LCBCaW5kaW5nX2IyNjRmMzE0NTZkYTQ0NTNiMjVkNGVkOTI5YmE5Y2RhKTtcclxuZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5CaW5kaW5nT3BlcmF0aW9ucy5TZXRCaW5kaW5nKEJvcmRlcl8yMGFhMzQ1ZWJkMTA0NjdmOGEwMWQ1MjA1YjY3M2M3NCwgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuQ29udHJvbHMuQm9yZGVyLkJhY2tncm91bmRQcm9wZXJ0eSwgQmluZGluZ182ZDRiMzI4M2NhNGM0NWJlYTJlZWQzMzc0ZTU4N2I2Yik7XHJcbmdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuQmluZGluZ09wZXJhdGlvbnMuU2V0QmluZGluZyhCb3JkZXJfMjBhYTM0NWViZDEwNDY3ZjhhMDFkNTIwNWI2NzNjNzQsIGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkNvbnRyb2xzLkJvcmRlci5Cb3JkZXJCcnVzaFByb3BlcnR5LCBCaW5kaW5nXzQ0ZWIwMjBiZjVlZjQzZTU5MGU3NWExZmRkMTEyZTU2KTtcclxuZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5CaW5kaW5nT3BlcmF0aW9ucy5TZXRCaW5kaW5nKEJvcmRlcl8yMGFhMzQ1ZWJkMTA0NjdmOGEwMWQ1MjA1YjY3M2M3NCwgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuQ29udHJvbHMuQm9yZGVyLkJvcmRlclRoaWNrbmVzc1Byb3BlcnR5LCBCaW5kaW5nXzBmOWJjODM2ZTA4MDRkMDE4OTNhOWFmN2EzOGY4OTk1KTtcclxuZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5CaW5kaW5nT3BlcmF0aW9ucy5TZXRCaW5kaW5nKEJvcmRlcl8yMGFhMzQ1ZWJkMTA0NjdmOGEwMWQ1MjA1YjY3M2M3NCwgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRnJhbWV3b3JrRWxlbWVudC5NYXJnaW5Qcm9wZXJ0eSwgQmluZGluZ18yYTVmNzY1OTU5Yjg0ZTQxOGVkZWYyODFjOTAzNWNjZik7XHJcbmdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuQmluZGluZ09wZXJhdGlvbnMuU2V0QmluZGluZyhCb3JkZXJfMjBhYTM0NWViZDEwNDY3ZjhhMDFkNTIwNWI2NzNjNzQsIGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlVJRWxlbWVudC5WaXNpYmlsaXR5UHJvcGVydHksIEJpbmRpbmdfNzE4Nzk2MTkwODBhNDUwNTk1NWZmYWFhNWZjNTk0ODQpO1xyXG5cclxuZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuTWVkaWEuQW5pbWF0aW9uLlN0b3J5Ym9hcmQuU2V0VGFyZ2V0UHJvcGVydHkoT2JqZWN0QW5pbWF0aW9uVXNpbmdLZXlGcmFtZXNfYzZiMDZjOWU0YWViNDQwNDhhZDAwYjAxYzc5NmVkM2UsXHJcbiAgICBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuUHJvcGVydHlQYXRoKFxyXG4gICAgICAgIFwiQmFja2dyb3VuZFwiLFxyXG4gICAgICAgIFwiQmFja2dyb3VuZFwiLFxyXG4gICAgICAgIGFjY2Vzc1Zpc3VhbFN0YXRlUHJvcGVydHlfNGI2MDc4ZTQzZTE0NDI0YWExNWU3YzJmZGZhNGQzM2UsXHJcbiAgICAgICAgc2V0VmlzdWFsU3RhdGVQcm9wZXJ0eV80YjYwNzhlNDNlMTQ0MjRhYTE1ZTdjMmZkZmE0ZDMzZSxcclxuICAgICAgICBzZXRBbmltYXRpb25WaXN1YWxTdGF0ZVByb3BlcnR5XzRiNjA3OGU0M2UxNDQyNGFhMTVlN2MyZmRmYTRkMzNlLCAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICBzZXRMb2NhbFZpc3VhbFN0YXRlUHJvcGVydHlfNGI2MDc4ZTQzZTE0NDI0YWExNWU3YzJmZGZhNGQzM2UsXHJcbiAgICAgICAgZ2V0VmlzdWFsU3RhdGVQcm9wZXJ0eV80YjYwNzhlNDNlMTQ0MjRhYTE1ZTdjMmZkZmE0ZDMzZSkpO1xyXG5nbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5NZWRpYS5BbmltYXRpb24uU3Rvcnlib2FyZC5TZXRUYXJnZXQoT2JqZWN0QW5pbWF0aW9uVXNpbmdLZXlGcmFtZXNfYzZiMDZjOWU0YWViNDQwNDhhZDAwYjAxYzc5NmVkM2UsIEJvcmRlcl81ZGM4ODI4MzYxNzg0OWE4YWZiMjRlMTE4NmI2ZWZkNCk7XHJcblxyXG5cclxuZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuTWVkaWEuQW5pbWF0aW9uLlN0b3J5Ym9hcmQuU2V0VGFyZ2V0UHJvcGVydHkoT2JqZWN0QW5pbWF0aW9uVXNpbmdLZXlGcmFtZXNfOGZiZDY1MThiMjliNGMxNmJkMWQyNGE2NWY0ZjQ5NWQsXHJcbiAgICBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuUHJvcGVydHlQYXRoKFxyXG4gICAgICAgIFwiQmFja2dyb3VuZFwiLFxyXG4gICAgICAgIFwiQmFja2dyb3VuZFwiLFxyXG4gICAgICAgIGFjY2Vzc1Zpc3VhbFN0YXRlUHJvcGVydHlfNTRhMGNiODg3M2EzNDExZjk3ZjU3Y2ZlYWZhNGE0NDUsXHJcbiAgICAgICAgc2V0VmlzdWFsU3RhdGVQcm9wZXJ0eV81NGEwY2I4ODczYTM0MTFmOTdmNTdjZmVhZmE0YTQ0NSxcclxuICAgICAgICBzZXRBbmltYXRpb25WaXN1YWxTdGF0ZVByb3BlcnR5XzU0YTBjYjg4NzNhMzQxMWY5N2Y1N2NmZWFmYTRhNDQ1LCAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICBzZXRMb2NhbFZpc3VhbFN0YXRlUHJvcGVydHlfNTRhMGNiODg3M2EzNDExZjk3ZjU3Y2ZlYWZhNGE0NDUsXHJcbiAgICAgICAgZ2V0VmlzdWFsU3RhdGVQcm9wZXJ0eV81NGEwY2I4ODczYTM0MTFmOTdmNTdjZmVhZmE0YTQ0NSkpO1xyXG5nbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5NZWRpYS5BbmltYXRpb24uU3Rvcnlib2FyZC5TZXRUYXJnZXQoT2JqZWN0QW5pbWF0aW9uVXNpbmdLZXlGcmFtZXNfOGZiZDY1MThiMjliNGMxNmJkMWQyNGE2NWY0ZjQ5NWQsIEJvcmRlcl81ZGM4ODI4MzYxNzg0OWE4YWZiMjRlMTE4NmI2ZWZkNCk7XHJcblxyXG5cclxuZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuTWVkaWEuQW5pbWF0aW9uLlN0b3J5Ym9hcmQuU2V0VGFyZ2V0UHJvcGVydHkoT2JqZWN0QW5pbWF0aW9uVXNpbmdLZXlGcmFtZXNfN2RhZWNkYTVhMWU1NDJjNDg3NDE1ODNlZDQwOGYyMDgsXHJcbiAgICBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuUHJvcGVydHlQYXRoKFxyXG4gICAgICAgIFwiQmFja2dyb3VuZFwiLFxyXG4gICAgICAgIFwiQmFja2dyb3VuZFwiLFxyXG4gICAgICAgIGFjY2Vzc1Zpc3VhbFN0YXRlUHJvcGVydHlfMWI0NTYyZDJjYzc5NDczNGI4ODcxNjExMTliNWYzOTAsXHJcbiAgICAgICAgc2V0VmlzdWFsU3RhdGVQcm9wZXJ0eV8xYjQ1NjJkMmNjNzk0NzM0Yjg4NzE2MTExOWI1ZjM5MCxcclxuICAgICAgICBzZXRBbmltYXRpb25WaXN1YWxTdGF0ZVByb3BlcnR5XzFiNDU2MmQyY2M3OTQ3MzRiODg3MTYxMTE5YjVmMzkwLCAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICBzZXRMb2NhbFZpc3VhbFN0YXRlUHJvcGVydHlfMWI0NTYyZDJjYzc5NDczNGI4ODcxNjExMTliNWYzOTAsXHJcbiAgICAgICAgZ2V0VmlzdWFsU3RhdGVQcm9wZXJ0eV8xYjQ1NjJkMmNjNzk0NzM0Yjg4NzE2MTExOWI1ZjM5MCkpO1xyXG5nbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5NZWRpYS5BbmltYXRpb24uU3Rvcnlib2FyZC5TZXRUYXJnZXQoT2JqZWN0QW5pbWF0aW9uVXNpbmdLZXlGcmFtZXNfN2RhZWNkYTVhMWU1NDJjNDg3NDE1ODNlZDQwOGYyMDgsIEJvcmRlcl81ZGM4ODI4MzYxNzg0OWE4YWZiMjRlMTE4NmI2ZWZkNCk7XHJcblxyXG50ZW1wbGF0ZUluc3RhbmNlX2RiMDY1MzhjZGQxMTQ3NGJiYjUzM2E3MmUxODJhNzgxLlRlbXBsYXRlQ29udGVudCA9IEJvcmRlcl8yMGFhMzQ1ZWJkMTA0NjdmOGEwMWQ1MjA1YjY3M2M3NDtcclxucmV0dXJuIHRlbXBsYXRlSW5zdGFuY2VfZGIwNjUzOGNkZDExNDc0YmJiNTMzYTcyZTE4MmE3ODE7XHJcbn0pKTtcclxuXHJcblNldHRlcl82ZDhhNWUzNmY5NGM0YTE3OGE0NmJkNjlhZTAzYTYyYi5WYWx1ZSA9IENvbnRyb2xUZW1wbGF0ZV9kOTUwZmYyYmU5MDM0Nzc0OGM5NTM2OGYwYTc5YTRjZjtcclxuXHJcblxyXG5TdHlsZV9iYzllYzEyMzExZDk0ZjJkYTMyMzhjMmQ3NWJmN2E2Ny5TZXR0ZXJzLkFkZChTZXR0ZXJfODE1MGJkM2YxMTNlNDIzZDhkNmE0ODllNDJlODc1MWQpO1xyXG5TdHlsZV9iYzllYzEyMzExZDk0ZjJkYTMyMzhjMmQ3NWJmN2E2Ny5TZXR0ZXJzLkFkZChTZXR0ZXJfNDJjZmVjODQ0YTUzNDBmOGJhNmMyZDAxZjRlN2U2YzIpO1xyXG5TdHlsZV9iYzllYzEyMzExZDk0ZjJkYTMyMzhjMmQ3NWJmN2E2Ny5TZXR0ZXJzLkFkZChTZXR0ZXJfYzA4MjM4YjBjYzg2NDg4NWEzOWEzMTc5OGM5YzljZWMpO1xyXG5TdHlsZV9iYzllYzEyMzExZDk0ZjJkYTMyMzhjMmQ3NWJmN2E2Ny5TZXR0ZXJzLkFkZChTZXR0ZXJfYTVhYzI4OTY5NDM2NGI0OWEyMGJkYWI5NTUzOWNkMDIpO1xyXG5TdHlsZV9iYzllYzEyMzExZDk0ZjJkYTMyMzhjMmQ3NWJmN2E2Ny5TZXR0ZXJzLkFkZChTZXR0ZXJfYmQ2ZTQ4ZDhhMGYyNDMxNThhYmIxYmVhOGFkMmFjOTEpO1xyXG5TdHlsZV9iYzllYzEyMzExZDk0ZjJkYTMyMzhjMmQ3NWJmN2E2Ny5TZXR0ZXJzLkFkZChTZXR0ZXJfOWRhNDZkZGIyN2Q1NGMyZDlmYTRjMzliM2RiMGNkZTUpO1xyXG5TdHlsZV9iYzllYzEyMzExZDk0ZjJkYTMyMzhjMmQ3NWJmN2E2Ny5TZXR0ZXJzLkFkZChTZXR0ZXJfZmUzZjJmM2I4YTM5NDUzZGIzZWM3ODg3ZTQwMGNkNGQpO1xyXG5TdHlsZV9iYzllYzEyMzExZDk0ZjJkYTMyMzhjMmQ3NWJmN2E2Ny5TZXR0ZXJzLkFkZChTZXR0ZXJfNmQ4YTVlMzZmOTRjNGExNzhhNDZiZDY5YWUwM2E2MmIpO1xyXG5cclxuXHJcblJlc291cmNlRGljdGlvbmFyeV82MDUyOWM4NDNiODA0OTBhOWZmMWZmOTdiM2U3NGE3YVtcIkludENvbnZlcnRlclwiXSA9IEludENvbnZlcnRlcl80OGYzNzczMDcyZTc0ZGQ2OTI1MDI5M2VlYWViNTJjNDtcclxuUmVzb3VyY2VEaWN0aW9uYXJ5XzYwNTI5Yzg0M2I4MDQ5MGE5ZmYxZmY5N2IzZTc0YTdhW1wiRGVjQ29udmVydGVyXCJdID0gRGVjQ29udmVydGVyXzQ1ZWE4NDBhYzg1MzRhMWY4NTg3ZjU0ZGQ4ZWM0MTM2O1xyXG5SZXNvdXJjZURpY3Rpb25hcnlfNjA1MjljODQzYjgwNDkwYTlmZjFmZjk3YjNlNzRhN2FbXCJUb1BvbHlMaW5lQ29udmVydGVyXCJdID0gVG9Qb2x5TGluZUNvbnZlcnRlcl80OGViNGFiYzNlZTk0Y2E3YTk3NzFkZTM5MjY5MGU1MTtcclxuUmVzb3VyY2VEaWN0aW9uYXJ5XzYwNTI5Yzg0M2I4MDQ5MGE5ZmYxZmY5N2IzZTc0YTdhW1wiVG9Qb2ludHNDb252ZXJ0ZXJcIl0gPSBUb1BvaW50c0NvbnZlcnRlcl82ZGI5NjY0NzQwNTg0NTJkYThkOTcwYjQwYzk1MzczMjtcclxuUmVzb3VyY2VEaWN0aW9uYXJ5XzYwNTI5Yzg0M2I4MDQ5MGE5ZmYxZmY5N2IzZTc0YTdhW1wiVG9MaW5lc0NvbnZlcnRlclwiXSA9IFRvTGluZXNDb252ZXJ0ZXJfMDI2OWRkODgxNTZmNDdmZmI2ZWRiZWQ4NWI2YWJlZjA7XHJcblJlc291cmNlRGljdGlvbmFyeV82MDUyOWM4NDNiODA0OTBhOWZmMWZmOTdiM2U3NGE3YVtcIkFQTENvbG9yQ29udmVydGVyXCJdID0gQVBMQ29sb3JDb252ZXJ0ZXJfMGJjMWJmNTZkMDU4NDczNDk3NzdkYTNmZjBiZjQyM2Q7XHJcblJlc291cmNlRGljdGlvbmFyeV82MDUyOWM4NDNiODA0OTBhOWZmMWZmOTdiM2U3NGE3YVtcIkFQTENvbG9yQ1NTQ29udmVydGVyXCJdID0gQVBMQ29sb3JDU1NDb252ZXJ0ZXJfMThmZDAyM2VmN2MzNDNiY2I5NDhhZGVkNDNjMGEyNTA7XHJcblJlc291cmNlRGljdGlvbmFyeV82MDUyOWM4NDNiODA0OTBhOWZmMWZmOTdiM2U3NGE3YVtcIkFQTE11bHRpQ29sb3JDb252ZXJ0ZXJcIl0gPSBBUExNdWx0aUNvbG9yQ29udmVydGVyX2UyMTE4ZDZiZTVhZjRmZGE4ZWIyZGRlZjlkZTJlNmY2O1xyXG5SZXNvdXJjZURpY3Rpb25hcnlfNjA1MjljODQzYjgwNDkwYTlmZjFmZjk3YjNlNzRhN2FbXCJBUExNdWx0aUNvbG9yQ1NTQ29udmVydGVyXCJdID0gQVBMTXVsdGlDb2xvckNTU0NvbnZlcnRlcl82ZTE5MDA0OGYzNzI0OGQ1YTg3YjE0ZGExMWZkZWU0YTtcclxuUmVzb3VyY2VEaWN0aW9uYXJ5XzYwNTI5Yzg0M2I4MDQ5MGE5ZmYxZmY5N2IzZTc0YTdhW1wiSW5kZXhJbnQzMkNvbnZlcnRlclwiXSA9IEluZGV4SW50MzJDb252ZXJ0ZXJfZjFiODE2YTBkOTI1NDQ4ZmE4NjE2NmM3MzBhYTJkMTg7XHJcblJlc291cmNlRGljdGlvbmFyeV82MDUyOWM4NDNiODA0OTBhOWZmMWZmOTdiM2U3NGE3YVtcIkluZGV4RG91YmxlQ29udmVydGVyXCJdID0gSW5kZXhEb3VibGVDb252ZXJ0ZXJfMjUxMGE4OGQ1MWQyNDhiNDgxODU0YTZhMTUyZTI3M2Q7XHJcblJlc291cmNlRGljdGlvbmFyeV82MDUyOWM4NDNiODA0OTBhOWZmMWZmOTdiM2U3NGE3YVtcIkluZGV4U3RyaW5nQ29udmVydGVyXCJdID0gSW5kZXhTdHJpbmdDb252ZXJ0ZXJfMDAzYzlmMTUxOGQxNGExNmE2YTdkN2U1ODMxMTIxNmE7XHJcblJlc291cmNlRGljdGlvbmFyeV82MDUyOWM4NDNiODA0OTBhOWZmMWZmOTdiM2U3NGE3YVtcIkluZGV4QVBMQ29sb3JDb252ZXJ0ZXJcIl0gPSBJbmRleEFQTENvbG9yQ29udmVydGVyX2NiYThjN2IxYzVmYzRlYzk5ZjkyOGI0MGZjMWZkYTE1O1xyXG5SZXNvdXJjZURpY3Rpb25hcnlfNjA1MjljODQzYjgwNDkwYTlmZjFmZjk3YjNlNzRhN2FbXCJJbmRleEFQTENvbG91ckNvbnZlcnRlclwiXSA9IEluZGV4QVBMQ29sb3VyQ29udmVydGVyXzMxOWEyY2YzYmNlZDQ5ZGM5Y2U5NDU2MDcxNDQzYzFhO1xyXG5SZXNvdXJjZURpY3Rpb25hcnlfNjA1MjljODQzYjgwNDkwYTlmZjFmZjk3YjNlNzRhN2FbXCJNYXRoc0lDb252ZXJ0ZXJcIl0gPSBNYXRoc0lDb252ZXJ0ZXJfZWFmZjU2YjY1ODNjNDk5MDlkMTcwYTRiODI2NzQxOTA7XHJcblJlc291cmNlRGljdGlvbmFyeV82MDUyOWM4NDNiODA0OTBhOWZmMWZmOTdiM2U3NGE3YVtcIk1hdGhzRENvbnZlcnRlclwiXSA9IE1hdGhzRENvbnZlcnRlcl80YzRlNjQ5NjEyNzQ0ZmNmYmM0YmYyNTcxMWEwNTQ0ZTtcclxuUmVzb3VyY2VEaWN0aW9uYXJ5XzYwNTI5Yzg0M2I4MDQ5MGE5ZmYxZmY5N2IzZTc0YTdhW1wiTWF0aElDb252ZXJ0ZXJcIl0gPSBNYXRoSUNvbnZlcnRlcl9jZjM2YjliZGM2NTg0Y2I2YWY5NzhjNmQzNWExYzViNTtcclxuUmVzb3VyY2VEaWN0aW9uYXJ5XzYwNTI5Yzg0M2I4MDQ5MGE5ZmYxZmY5N2IzZTc0YTdhW1wiTWF0aERDb252ZXJ0ZXJcIl0gPSBNYXRoRENvbnZlcnRlcl9mMGRhZDFmNDNhOWU0NWMzYTg2MDk2YWI0OTM4NmM5YztcclxuUmVzb3VyY2VEaWN0aW9uYXJ5XzYwNTI5Yzg0M2I4MDQ5MGE5ZmYxZmY5N2IzZTc0YTdhW1wiQXBwbGljYXRpb25cIl0gPSBTdHJpbmdfZmMwOTVmNjc5NWE3NDdjZTljNWYzZGEzZGY3MWI4ZTE7XHJcblJlc291cmNlRGljdGlvbmFyeV82MDUyOWM4NDNiODA0OTBhOWZmMWZmOTdiM2U3NGE3YVtcIk93bmVyXCJdID0gU3RyaW5nX2NiMjBmN2UxY2Q0MTRkMDU5N2ExYjk2MTMzNDgxOWRmO1xyXG5SZXNvdXJjZURpY3Rpb25hcnlfNjA1MjljODQzYjgwNDkwYTlmZjFmZjk3YjNlNzRhN2FbXCJDb21wYW55XCJdID0gU3RyaW5nX2U1NjBlMTY0YmM5MTRiZDk5ZGRhOTc5Y2Q3MjkzYWI1O1xyXG5SZXNvdXJjZURpY3Rpb25hcnlfNjA1MjljODQzYjgwNDkwYTlmZjFmZjk3YjNlNzRhN2FbXCJOYW1lXCJdID0gU3RyaW5nX2E1Zjg0ODY2YTgxYTQxMDhiMTdhZTM0NjQ1ODFlY2U3O1xyXG5SZXNvdXJjZURpY3Rpb25hcnlfNjA1MjljODQzYjgwNDkwYTlmZjFmZjk3YjNlNzRhN2FbXCJUaXRsZVwiXSA9IFN0cmluZ19lNjlhZTQ5YWE1NmE0N2FjYjExZWQ0YTE4ZTMyY2I2NztcclxuUmVzb3VyY2VEaWN0aW9uYXJ5XzYwNTI5Yzg0M2I4MDQ5MGE5ZmYxZmY5N2IzZTc0YTdhW1wiRmF2SWNvblwiXSA9IFN0cmluZ19iN2EzYjIwZmUwMmQ0Y2FjYjZiZjIwNmUzZjQ3ZWRmNjtcclxuUmVzb3VyY2VEaWN0aW9uYXJ5XzYwNTI5Yzg0M2I4MDQ5MGE5ZmYxZmY5N2IzZTc0YTdhW1wiUG9ydFwiXSA9IFN0cmluZ18wODE1NzI3Y2E0NmQ0ZjQ1ODgxNWNkYWU4MWJmZmVmODtcclxuUmVzb3VyY2VEaWN0aW9uYXJ5XzYwNTI5Yzg0M2I4MDQ5MGE5ZmYxZmY5N2IzZTc0YTdhW1wiTWFpblwiXSA9IFN0cmluZ18yNzQ0ZTY2YTRjODM0NTdjOWRkMjUyNmVjZDEyNjAzZjtcclxuUmVzb3VyY2VEaWN0aW9uYXJ5XzYwNTI5Yzg0M2I4MDQ5MGE5ZmYxZmY5N2IzZTc0YTdhW1wiQmFzZVwiXSA9IFN0cmluZ180Njk0MzYxMDVlOTc0NGE2YWM1ZDEyMGRjNTg3NzU4NDtcclxuUmVzb3VyY2VEaWN0aW9uYXJ5XzYwNTI5Yzg0M2I4MDQ5MGE5ZmYxZmY5N2IzZTc0YTdhW1wiQ29ubmVjdGlvblR5cGVcIl0gPSBTdHJpbmdfMWJjYTdiNTI3MTMwNGUzZTk4YWM2MGRiOTYyYWRjMTc7XHJcblJlc291cmNlRGljdGlvbmFyeV82MDUyOWM4NDNiODA0OTBhOWZmMWZmOTdiM2U3NGE3YVtcIk5hbWVzcGFjZVwiXSA9IFN0cmluZ18zYTM0MjViNzYxZDc0ODI5OTA2OGU5ODk1NGUzOGEwYTtcclxuUmVzb3VyY2VEaWN0aW9uYXJ5XzYwNTI5Yzg0M2I4MDQ5MGE5ZmYxZmY5N2IzZTc0YTdhW1wiQVBMRm9ybVN0eWxlXCJdID0gU3R5bGVfMjAxMzJiYWU5MzM2NDcwMWI1ZjNmZWUxODU0ODAyNDg7XHJcblJlc291cmNlRGljdGlvbmFyeV82MDUyOWM4NDNiODA0OTBhOWZmMWZmOTdiM2U3NGE3YVtcIkJ1dHRvblN0eWxlMVwiXSA9IFN0eWxlX2JjOWVjMTIzMTFkOTRmMmRhMzIzOGMyZDc1YmY3YTY3O1xyXG5cclxudGhpcy5SZXNvdXJjZXMgPSBSZXNvdXJjZURpY3Rpb25hcnlfNjA1MjljODQzYjgwNDkwYTlmZjFmZjk3YjNlNzRhN2E7XHJcblxyXG5cclxuXHJcblxyXG5cclxuXHJcbiAgICBcclxuICAgICAgICB9XHJcblxyXG5cclxuXHJcbnB1YmxpYyBnbG9iYWw6OlN5c3RlbS5Db2xsZWN0aW9ucy5HZW5lcmljLklFbnVtZXJhYmxlPGdsb2JhbDo6U3lzdGVtLlR1cGxlPGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRlcGVuZGVuY3lPYmplY3QsIGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRlcGVuZGVuY3lQcm9wZXJ0eSwgaW50Pz4+IGFjY2Vzc1Zpc3VhbFN0YXRlUHJvcGVydHlfMWQyNTAxZTAyZGVhNDM5MmI3N2JjYzQ0MmVhNDcwNTMgKGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRlcGVuZGVuY3lPYmplY3Qgcm9vdFRhcmdldE9iamVjdEluc3RhbmNlKVxyXG57XHJcbiAgXHJcbnlpZWxkIGJyZWFrO1xyXG59XHJcblxyXG5cclxucHVibGljIHZvaWQgc2V0VmlzdWFsU3RhdGVQcm9wZXJ0eV8xZDI1MDFlMDJkZWE0MzkyYjc3YmNjNDQyZWE0NzA1MyAoZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGVwZW5kZW5jeU9iamVjdCBmaW5hbFRhcmdldEluc3RhbmNlLCBvYmplY3QgdmFsdWUpXHJcbntcclxuICBcclxuZ2xvYmFsOjpTeXN0ZW0uVHlwZSBmaW5hbFRhcmdldEluc3RhbmNlVHlwZSA9IGZpbmFsVGFyZ2V0SW5zdGFuY2UuR2V0VHlwZSgpO1xyXG5nbG9iYWw6OlN5c3RlbS5UeXBlIHByb3BlcnR5RGVjbGFyaW5nVHlwZSA9IGZpbmFsVGFyZ2V0SW5zdGFuY2VUeXBlLkdldFByb3BlcnR5KFwiQmFja2dyb3VuZFwiKS5EZWNsYXJpbmdUeXBlO1xyXG5nbG9iYWw6OlN5c3RlbS5SZWZsZWN0aW9uLkZpZWxkSW5mbyBwcm9wZXJ0eUZpZWxkID0gcHJvcGVydHlEZWNsYXJpbmdUeXBlLkdldEZpZWxkKFwiQmFja2dyb3VuZFByb3BlcnR5XCIpO1xyXG5nbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EZXBlbmRlbmN5UHJvcGVydHkgcHJvcGVydHkgPSAoZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGVwZW5kZW5jeVByb3BlcnR5KXByb3BlcnR5RmllbGQuR2V0VmFsdWUobnVsbCk7XHJcblxyXG4gIChmaW5hbFRhcmdldEluc3RhbmNlKS5TZXRWaXN1YWxTdGF0ZVZhbHVlKHByb3BlcnR5LCB2YWx1ZSk7XHJcbn1cclxuXHJcblxyXG5wdWJsaWMgdm9pZCBzZXRBbmltYXRpb25WaXN1YWxTdGF0ZVByb3BlcnR5XzFkMjUwMWUwMmRlYTQzOTJiNzdiY2M0NDJlYTQ3MDUzIChnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EZXBlbmRlbmN5T2JqZWN0IGZpbmFsVGFyZ2V0SW5zdGFuY2UsIG9iamVjdCB2YWx1ZSlcclxue1xyXG4gIFxyXG5nbG9iYWw6OlN5c3RlbS5UeXBlIGZpbmFsVGFyZ2V0SW5zdGFuY2VUeXBlID0gZmluYWxUYXJnZXRJbnN0YW5jZS5HZXRUeXBlKCk7XHJcbmdsb2JhbDo6U3lzdGVtLlR5cGUgcHJvcGVydHlEZWNsYXJpbmdUeXBlID0gZmluYWxUYXJnZXRJbnN0YW5jZVR5cGUuR2V0UHJvcGVydHkoXCJCYWNrZ3JvdW5kXCIpLkRlY2xhcmluZ1R5cGU7XHJcbmdsb2JhbDo6U3lzdGVtLlJlZmxlY3Rpb24uRmllbGRJbmZvIHByb3BlcnR5RmllbGQgPSBwcm9wZXJ0eURlY2xhcmluZ1R5cGUuR2V0RmllbGQoXCJCYWNrZ3JvdW5kUHJvcGVydHlcIik7XHJcbmdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRlcGVuZGVuY3lQcm9wZXJ0eSBwcm9wZXJ0eSA9IChnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EZXBlbmRlbmN5UHJvcGVydHkpcHJvcGVydHlGaWVsZC5HZXRWYWx1ZShudWxsKTtcclxuXHJcbiAgKGZpbmFsVGFyZ2V0SW5zdGFuY2UpLlNldEFuaW1hdGlvblZhbHVlKHByb3BlcnR5LCB2YWx1ZSk7XHJcbn1cclxuXHJcblxyXG5wdWJsaWMgdm9pZCBzZXRMb2NhbFZpc3VhbFN0YXRlUHJvcGVydHlfMWQyNTAxZTAyZGVhNDM5MmI3N2JjYzQ0MmVhNDcwNTMgKGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRlcGVuZGVuY3lPYmplY3QgZmluYWxUYXJnZXRJbnN0YW5jZSwgb2JqZWN0IHZhbHVlKVxyXG57XHJcbiAgXHJcbmdsb2JhbDo6U3lzdGVtLlR5cGUgZmluYWxUYXJnZXRJbnN0YW5jZVR5cGUgPSBmaW5hbFRhcmdldEluc3RhbmNlLkdldFR5cGUoKTtcclxuZ2xvYmFsOjpTeXN0ZW0uVHlwZSBwcm9wZXJ0eURlY2xhcmluZ1R5cGUgPSBmaW5hbFRhcmdldEluc3RhbmNlVHlwZS5HZXRQcm9wZXJ0eShcIkJhY2tncm91bmRcIikuRGVjbGFyaW5nVHlwZTtcclxuZ2xvYmFsOjpTeXN0ZW0uUmVmbGVjdGlvbi5GaWVsZEluZm8gcHJvcGVydHlGaWVsZCA9IHByb3BlcnR5RGVjbGFyaW5nVHlwZS5HZXRGaWVsZChcIkJhY2tncm91bmRQcm9wZXJ0eVwiKTtcclxuZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGVwZW5kZW5jeVByb3BlcnR5IHByb3BlcnR5ID0gKGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRlcGVuZGVuY3lQcm9wZXJ0eSlwcm9wZXJ0eUZpZWxkLkdldFZhbHVlKG51bGwpO1xyXG5cclxuICAoZmluYWxUYXJnZXRJbnN0YW5jZSkuU2V0Q3VycmVudFZhbHVlKHByb3BlcnR5LCB2YWx1ZSk7XHJcbn1cclxuXHJcblxyXG5wdWJsaWMgZ2xvYmFsOjpTeXN0ZW0uT2JqZWN0IGdldFZpc3VhbFN0YXRlUHJvcGVydHlfMWQyNTAxZTAyZGVhNDM5MmI3N2JjYzQ0MmVhNDcwNTMgKGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRlcGVuZGVuY3lPYmplY3QgZmluYWxUYXJnZXRJbnN0YW5jZSlcclxue1xyXG4gIFxyXG5nbG9iYWw6OlN5c3RlbS5UeXBlIGZpbmFsVGFyZ2V0SW5zdGFuY2VUeXBlID0gZmluYWxUYXJnZXRJbnN0YW5jZS5HZXRUeXBlKCk7XHJcbmdsb2JhbDo6U3lzdGVtLlR5cGUgcHJvcGVydHlEZWNsYXJpbmdUeXBlID0gZmluYWxUYXJnZXRJbnN0YW5jZVR5cGUuR2V0UHJvcGVydHkoXCJCYWNrZ3JvdW5kXCIpLkRlY2xhcmluZ1R5cGU7XHJcbmdsb2JhbDo6U3lzdGVtLlJlZmxlY3Rpb24uRmllbGRJbmZvIHByb3BlcnR5RmllbGQgPSBwcm9wZXJ0eURlY2xhcmluZ1R5cGUuR2V0RmllbGQoXCJCYWNrZ3JvdW5kUHJvcGVydHlcIik7XHJcbmdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRlcGVuZGVuY3lQcm9wZXJ0eSBwcm9wZXJ0eSA9IChnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EZXBlbmRlbmN5UHJvcGVydHkpcHJvcGVydHlGaWVsZC5HZXRWYWx1ZShudWxsKTtcclxuXHJcbiAgcmV0dXJuIGZpbmFsVGFyZ2V0SW5zdGFuY2UuR2V0VmlzdWFsU3RhdGVWYWx1ZShwcm9wZXJ0eSk7XHJcbn1cclxuXHJcblxyXG5wdWJsaWMgZ2xvYmFsOjpTeXN0ZW0uQ29sbGVjdGlvbnMuR2VuZXJpYy5JRW51bWVyYWJsZTxnbG9iYWw6OlN5c3RlbS5UdXBsZTxnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EZXBlbmRlbmN5T2JqZWN0LCBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EZXBlbmRlbmN5UHJvcGVydHksIGludD8+PiBhY2Nlc3NWaXN1YWxTdGF0ZVByb3BlcnR5X2RkZWQ0YTFiMDBhYTQxZTA5YmEzZjg3MGU1Njc1ZTQ2IChnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EZXBlbmRlbmN5T2JqZWN0IHJvb3RUYXJnZXRPYmplY3RJbnN0YW5jZSlcclxue1xyXG4gIFxyXG55aWVsZCBicmVhaztcclxufVxyXG5cclxuXHJcbnB1YmxpYyB2b2lkIHNldFZpc3VhbFN0YXRlUHJvcGVydHlfZGRlZDRhMWIwMGFhNDFlMDliYTNmODcwZTU2NzVlNDYgKGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRlcGVuZGVuY3lPYmplY3QgZmluYWxUYXJnZXRJbnN0YW5jZSwgb2JqZWN0IHZhbHVlKVxyXG57XHJcbiAgXHJcbmdsb2JhbDo6U3lzdGVtLlR5cGUgZmluYWxUYXJnZXRJbnN0YW5jZVR5cGUgPSBmaW5hbFRhcmdldEluc3RhbmNlLkdldFR5cGUoKTtcclxuZ2xvYmFsOjpTeXN0ZW0uVHlwZSBwcm9wZXJ0eURlY2xhcmluZ1R5cGUgPSBmaW5hbFRhcmdldEluc3RhbmNlVHlwZS5HZXRQcm9wZXJ0eShcIklzSGl0VGVzdFZpc2libGVcIikuRGVjbGFyaW5nVHlwZTtcclxuZ2xvYmFsOjpTeXN0ZW0uUmVmbGVjdGlvbi5GaWVsZEluZm8gcHJvcGVydHlGaWVsZCA9IHByb3BlcnR5RGVjbGFyaW5nVHlwZS5HZXRGaWVsZChcIklzSGl0VGVzdFZpc2libGVQcm9wZXJ0eVwiKTtcclxuZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGVwZW5kZW5jeVByb3BlcnR5IHByb3BlcnR5ID0gKGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRlcGVuZGVuY3lQcm9wZXJ0eSlwcm9wZXJ0eUZpZWxkLkdldFZhbHVlKG51bGwpO1xyXG5cclxuICAoZmluYWxUYXJnZXRJbnN0YW5jZSkuU2V0VmlzdWFsU3RhdGVWYWx1ZShwcm9wZXJ0eSwgdmFsdWUpO1xyXG59XHJcblxyXG5cclxucHVibGljIHZvaWQgc2V0QW5pbWF0aW9uVmlzdWFsU3RhdGVQcm9wZXJ0eV9kZGVkNGExYjAwYWE0MWUwOWJhM2Y4NzBlNTY3NWU0NiAoZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGVwZW5kZW5jeU9iamVjdCBmaW5hbFRhcmdldEluc3RhbmNlLCBvYmplY3QgdmFsdWUpXHJcbntcclxuICBcclxuZ2xvYmFsOjpTeXN0ZW0uVHlwZSBmaW5hbFRhcmdldEluc3RhbmNlVHlwZSA9IGZpbmFsVGFyZ2V0SW5zdGFuY2UuR2V0VHlwZSgpO1xyXG5nbG9iYWw6OlN5c3RlbS5UeXBlIHByb3BlcnR5RGVjbGFyaW5nVHlwZSA9IGZpbmFsVGFyZ2V0SW5zdGFuY2VUeXBlLkdldFByb3BlcnR5KFwiSXNIaXRUZXN0VmlzaWJsZVwiKS5EZWNsYXJpbmdUeXBlO1xyXG5nbG9iYWw6OlN5c3RlbS5SZWZsZWN0aW9uLkZpZWxkSW5mbyBwcm9wZXJ0eUZpZWxkID0gcHJvcGVydHlEZWNsYXJpbmdUeXBlLkdldEZpZWxkKFwiSXNIaXRUZXN0VmlzaWJsZVByb3BlcnR5XCIpO1xyXG5nbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EZXBlbmRlbmN5UHJvcGVydHkgcHJvcGVydHkgPSAoZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGVwZW5kZW5jeVByb3BlcnR5KXByb3BlcnR5RmllbGQuR2V0VmFsdWUobnVsbCk7XHJcblxyXG4gIChmaW5hbFRhcmdldEluc3RhbmNlKS5TZXRBbmltYXRpb25WYWx1ZShwcm9wZXJ0eSwgdmFsdWUpO1xyXG59XHJcblxyXG5cclxucHVibGljIHZvaWQgc2V0TG9jYWxWaXN1YWxTdGF0ZVByb3BlcnR5X2RkZWQ0YTFiMDBhYTQxZTA5YmEzZjg3MGU1Njc1ZTQ2IChnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EZXBlbmRlbmN5T2JqZWN0IGZpbmFsVGFyZ2V0SW5zdGFuY2UsIG9iamVjdCB2YWx1ZSlcclxue1xyXG4gIFxyXG5nbG9iYWw6OlN5c3RlbS5UeXBlIGZpbmFsVGFyZ2V0SW5zdGFuY2VUeXBlID0gZmluYWxUYXJnZXRJbnN0YW5jZS5HZXRUeXBlKCk7XHJcbmdsb2JhbDo6U3lzdGVtLlR5cGUgcHJvcGVydHlEZWNsYXJpbmdUeXBlID0gZmluYWxUYXJnZXRJbnN0YW5jZVR5cGUuR2V0UHJvcGVydHkoXCJJc0hpdFRlc3RWaXNpYmxlXCIpLkRlY2xhcmluZ1R5cGU7XHJcbmdsb2JhbDo6U3lzdGVtLlJlZmxlY3Rpb24uRmllbGRJbmZvIHByb3BlcnR5RmllbGQgPSBwcm9wZXJ0eURlY2xhcmluZ1R5cGUuR2V0RmllbGQoXCJJc0hpdFRlc3RWaXNpYmxlUHJvcGVydHlcIik7XHJcbmdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRlcGVuZGVuY3lQcm9wZXJ0eSBwcm9wZXJ0eSA9IChnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EZXBlbmRlbmN5UHJvcGVydHkpcHJvcGVydHlGaWVsZC5HZXRWYWx1ZShudWxsKTtcclxuXHJcbiAgKGZpbmFsVGFyZ2V0SW5zdGFuY2UpLlNldEN1cnJlbnRWYWx1ZShwcm9wZXJ0eSwgdmFsdWUpO1xyXG59XHJcblxyXG5cclxucHVibGljIGdsb2JhbDo6U3lzdGVtLk9iamVjdCBnZXRWaXN1YWxTdGF0ZVByb3BlcnR5X2RkZWQ0YTFiMDBhYTQxZTA5YmEzZjg3MGU1Njc1ZTQ2IChnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EZXBlbmRlbmN5T2JqZWN0IGZpbmFsVGFyZ2V0SW5zdGFuY2UpXHJcbntcclxuICBcclxuZ2xvYmFsOjpTeXN0ZW0uVHlwZSBmaW5hbFRhcmdldEluc3RhbmNlVHlwZSA9IGZpbmFsVGFyZ2V0SW5zdGFuY2UuR2V0VHlwZSgpO1xyXG5nbG9iYWw6OlN5c3RlbS5UeXBlIHByb3BlcnR5RGVjbGFyaW5nVHlwZSA9IGZpbmFsVGFyZ2V0SW5zdGFuY2VUeXBlLkdldFByb3BlcnR5KFwiSXNIaXRUZXN0VmlzaWJsZVwiKS5EZWNsYXJpbmdUeXBlO1xyXG5nbG9iYWw6OlN5c3RlbS5SZWZsZWN0aW9uLkZpZWxkSW5mbyBwcm9wZXJ0eUZpZWxkID0gcHJvcGVydHlEZWNsYXJpbmdUeXBlLkdldEZpZWxkKFwiSXNIaXRUZXN0VmlzaWJsZVByb3BlcnR5XCIpO1xyXG5nbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EZXBlbmRlbmN5UHJvcGVydHkgcHJvcGVydHkgPSAoZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGVwZW5kZW5jeVByb3BlcnR5KXByb3BlcnR5RmllbGQuR2V0VmFsdWUobnVsbCk7XHJcblxyXG4gIHJldHVybiBmaW5hbFRhcmdldEluc3RhbmNlLkdldFZpc3VhbFN0YXRlVmFsdWUocHJvcGVydHkpO1xyXG59XHJcblxyXG5cclxucHVibGljIGdsb2JhbDo6U3lzdGVtLkNvbGxlY3Rpb25zLkdlbmVyaWMuSUVudW1lcmFibGU8Z2xvYmFsOjpTeXN0ZW0uVHVwbGU8Z2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGVwZW5kZW5jeU9iamVjdCwgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGVwZW5kZW5jeVByb3BlcnR5LCBpbnQ/Pj4gYWNjZXNzVmlzdWFsU3RhdGVQcm9wZXJ0eV80YjYwNzhlNDNlMTQ0MjRhYTE1ZTdjMmZkZmE0ZDMzZSAoZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGVwZW5kZW5jeU9iamVjdCByb290VGFyZ2V0T2JqZWN0SW5zdGFuY2UpXHJcbntcclxuICBcclxueWllbGQgYnJlYWs7XHJcbn1cclxuXHJcblxyXG5wdWJsaWMgdm9pZCBzZXRWaXN1YWxTdGF0ZVByb3BlcnR5XzRiNjA3OGU0M2UxNDQyNGFhMTVlN2MyZmRmYTRkMzNlIChnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EZXBlbmRlbmN5T2JqZWN0IGZpbmFsVGFyZ2V0SW5zdGFuY2UsIG9iamVjdCB2YWx1ZSlcclxue1xyXG4gIFxyXG5nbG9iYWw6OlN5c3RlbS5UeXBlIGZpbmFsVGFyZ2V0SW5zdGFuY2VUeXBlID0gZmluYWxUYXJnZXRJbnN0YW5jZS5HZXRUeXBlKCk7XHJcbmdsb2JhbDo6U3lzdGVtLlR5cGUgcHJvcGVydHlEZWNsYXJpbmdUeXBlID0gZmluYWxUYXJnZXRJbnN0YW5jZVR5cGUuR2V0UHJvcGVydHkoXCJCYWNrZ3JvdW5kXCIpLkRlY2xhcmluZ1R5cGU7XHJcbmdsb2JhbDo6U3lzdGVtLlJlZmxlY3Rpb24uRmllbGRJbmZvIHByb3BlcnR5RmllbGQgPSBwcm9wZXJ0eURlY2xhcmluZ1R5cGUuR2V0RmllbGQoXCJCYWNrZ3JvdW5kUHJvcGVydHlcIik7XHJcbmdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRlcGVuZGVuY3lQcm9wZXJ0eSBwcm9wZXJ0eSA9IChnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EZXBlbmRlbmN5UHJvcGVydHkpcHJvcGVydHlGaWVsZC5HZXRWYWx1ZShudWxsKTtcclxuXHJcbiAgKGZpbmFsVGFyZ2V0SW5zdGFuY2UpLlNldFZpc3VhbFN0YXRlVmFsdWUocHJvcGVydHksIHZhbHVlKTtcclxufVxyXG5cclxuXHJcbnB1YmxpYyB2b2lkIHNldEFuaW1hdGlvblZpc3VhbFN0YXRlUHJvcGVydHlfNGI2MDc4ZTQzZTE0NDI0YWExNWU3YzJmZGZhNGQzM2UgKGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRlcGVuZGVuY3lPYmplY3QgZmluYWxUYXJnZXRJbnN0YW5jZSwgb2JqZWN0IHZhbHVlKVxyXG57XHJcbiAgXHJcbmdsb2JhbDo6U3lzdGVtLlR5cGUgZmluYWxUYXJnZXRJbnN0YW5jZVR5cGUgPSBmaW5hbFRhcmdldEluc3RhbmNlLkdldFR5cGUoKTtcclxuZ2xvYmFsOjpTeXN0ZW0uVHlwZSBwcm9wZXJ0eURlY2xhcmluZ1R5cGUgPSBmaW5hbFRhcmdldEluc3RhbmNlVHlwZS5HZXRQcm9wZXJ0eShcIkJhY2tncm91bmRcIikuRGVjbGFyaW5nVHlwZTtcclxuZ2xvYmFsOjpTeXN0ZW0uUmVmbGVjdGlvbi5GaWVsZEluZm8gcHJvcGVydHlGaWVsZCA9IHByb3BlcnR5RGVjbGFyaW5nVHlwZS5HZXRGaWVsZChcIkJhY2tncm91bmRQcm9wZXJ0eVwiKTtcclxuZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGVwZW5kZW5jeVByb3BlcnR5IHByb3BlcnR5ID0gKGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRlcGVuZGVuY3lQcm9wZXJ0eSlwcm9wZXJ0eUZpZWxkLkdldFZhbHVlKG51bGwpO1xyXG5cclxuICAoZmluYWxUYXJnZXRJbnN0YW5jZSkuU2V0QW5pbWF0aW9uVmFsdWUocHJvcGVydHksIHZhbHVlKTtcclxufVxyXG5cclxuXHJcbnB1YmxpYyB2b2lkIHNldExvY2FsVmlzdWFsU3RhdGVQcm9wZXJ0eV80YjYwNzhlNDNlMTQ0MjRhYTE1ZTdjMmZkZmE0ZDMzZSAoZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGVwZW5kZW5jeU9iamVjdCBmaW5hbFRhcmdldEluc3RhbmNlLCBvYmplY3QgdmFsdWUpXHJcbntcclxuICBcclxuZ2xvYmFsOjpTeXN0ZW0uVHlwZSBmaW5hbFRhcmdldEluc3RhbmNlVHlwZSA9IGZpbmFsVGFyZ2V0SW5zdGFuY2UuR2V0VHlwZSgpO1xyXG5nbG9iYWw6OlN5c3RlbS5UeXBlIHByb3BlcnR5RGVjbGFyaW5nVHlwZSA9IGZpbmFsVGFyZ2V0SW5zdGFuY2VUeXBlLkdldFByb3BlcnR5KFwiQmFja2dyb3VuZFwiKS5EZWNsYXJpbmdUeXBlO1xyXG5nbG9iYWw6OlN5c3RlbS5SZWZsZWN0aW9uLkZpZWxkSW5mbyBwcm9wZXJ0eUZpZWxkID0gcHJvcGVydHlEZWNsYXJpbmdUeXBlLkdldEZpZWxkKFwiQmFja2dyb3VuZFByb3BlcnR5XCIpO1xyXG5nbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EZXBlbmRlbmN5UHJvcGVydHkgcHJvcGVydHkgPSAoZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGVwZW5kZW5jeVByb3BlcnR5KXByb3BlcnR5RmllbGQuR2V0VmFsdWUobnVsbCk7XHJcblxyXG4gIChmaW5hbFRhcmdldEluc3RhbmNlKS5TZXRDdXJyZW50VmFsdWUocHJvcGVydHksIHZhbHVlKTtcclxufVxyXG5cclxuXHJcbnB1YmxpYyBnbG9iYWw6OlN5c3RlbS5PYmplY3QgZ2V0VmlzdWFsU3RhdGVQcm9wZXJ0eV80YjYwNzhlNDNlMTQ0MjRhYTE1ZTdjMmZkZmE0ZDMzZSAoZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGVwZW5kZW5jeU9iamVjdCBmaW5hbFRhcmdldEluc3RhbmNlKVxyXG57XHJcbiAgXHJcbmdsb2JhbDo6U3lzdGVtLlR5cGUgZmluYWxUYXJnZXRJbnN0YW5jZVR5cGUgPSBmaW5hbFRhcmdldEluc3RhbmNlLkdldFR5cGUoKTtcclxuZ2xvYmFsOjpTeXN0ZW0uVHlwZSBwcm9wZXJ0eURlY2xhcmluZ1R5cGUgPSBmaW5hbFRhcmdldEluc3RhbmNlVHlwZS5HZXRQcm9wZXJ0eShcIkJhY2tncm91bmRcIikuRGVjbGFyaW5nVHlwZTtcclxuZ2xvYmFsOjpTeXN0ZW0uUmVmbGVjdGlvbi5GaWVsZEluZm8gcHJvcGVydHlGaWVsZCA9IHByb3BlcnR5RGVjbGFyaW5nVHlwZS5HZXRGaWVsZChcIkJhY2tncm91bmRQcm9wZXJ0eVwiKTtcclxuZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGVwZW5kZW5jeVByb3BlcnR5IHByb3BlcnR5ID0gKGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRlcGVuZGVuY3lQcm9wZXJ0eSlwcm9wZXJ0eUZpZWxkLkdldFZhbHVlKG51bGwpO1xyXG5cclxuICByZXR1cm4gZmluYWxUYXJnZXRJbnN0YW5jZS5HZXRWaXN1YWxTdGF0ZVZhbHVlKHByb3BlcnR5KTtcclxufVxyXG5cclxuXHJcbnB1YmxpYyBnbG9iYWw6OlN5c3RlbS5Db2xsZWN0aW9ucy5HZW5lcmljLklFbnVtZXJhYmxlPGdsb2JhbDo6U3lzdGVtLlR1cGxlPGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRlcGVuZGVuY3lPYmplY3QsIGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRlcGVuZGVuY3lQcm9wZXJ0eSwgaW50Pz4+IGFjY2Vzc1Zpc3VhbFN0YXRlUHJvcGVydHlfNTRhMGNiODg3M2EzNDExZjk3ZjU3Y2ZlYWZhNGE0NDUgKGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRlcGVuZGVuY3lPYmplY3Qgcm9vdFRhcmdldE9iamVjdEluc3RhbmNlKVxyXG57XHJcbiAgXHJcbnlpZWxkIGJyZWFrO1xyXG59XHJcblxyXG5cclxucHVibGljIHZvaWQgc2V0VmlzdWFsU3RhdGVQcm9wZXJ0eV81NGEwY2I4ODczYTM0MTFmOTdmNTdjZmVhZmE0YTQ0NSAoZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGVwZW5kZW5jeU9iamVjdCBmaW5hbFRhcmdldEluc3RhbmNlLCBvYmplY3QgdmFsdWUpXHJcbntcclxuICBcclxuZ2xvYmFsOjpTeXN0ZW0uVHlwZSBmaW5hbFRhcmdldEluc3RhbmNlVHlwZSA9IGZpbmFsVGFyZ2V0SW5zdGFuY2UuR2V0VHlwZSgpO1xyXG5nbG9iYWw6OlN5c3RlbS5UeXBlIHByb3BlcnR5RGVjbGFyaW5nVHlwZSA9IGZpbmFsVGFyZ2V0SW5zdGFuY2VUeXBlLkdldFByb3BlcnR5KFwiQmFja2dyb3VuZFwiKS5EZWNsYXJpbmdUeXBlO1xyXG5nbG9iYWw6OlN5c3RlbS5SZWZsZWN0aW9uLkZpZWxkSW5mbyBwcm9wZXJ0eUZpZWxkID0gcHJvcGVydHlEZWNsYXJpbmdUeXBlLkdldEZpZWxkKFwiQmFja2dyb3VuZFByb3BlcnR5XCIpO1xyXG5nbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EZXBlbmRlbmN5UHJvcGVydHkgcHJvcGVydHkgPSAoZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGVwZW5kZW5jeVByb3BlcnR5KXByb3BlcnR5RmllbGQuR2V0VmFsdWUobnVsbCk7XHJcblxyXG4gIChmaW5hbFRhcmdldEluc3RhbmNlKS5TZXRWaXN1YWxTdGF0ZVZhbHVlKHByb3BlcnR5LCB2YWx1ZSk7XHJcbn1cclxuXHJcblxyXG5wdWJsaWMgdm9pZCBzZXRBbmltYXRpb25WaXN1YWxTdGF0ZVByb3BlcnR5XzU0YTBjYjg4NzNhMzQxMWY5N2Y1N2NmZWFmYTRhNDQ1IChnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EZXBlbmRlbmN5T2JqZWN0IGZpbmFsVGFyZ2V0SW5zdGFuY2UsIG9iamVjdCB2YWx1ZSlcclxue1xyXG4gIFxyXG5nbG9iYWw6OlN5c3RlbS5UeXBlIGZpbmFsVGFyZ2V0SW5zdGFuY2VUeXBlID0gZmluYWxUYXJnZXRJbnN0YW5jZS5HZXRUeXBlKCk7XHJcbmdsb2JhbDo6U3lzdGVtLlR5cGUgcHJvcGVydHlEZWNsYXJpbmdUeXBlID0gZmluYWxUYXJnZXRJbnN0YW5jZVR5cGUuR2V0UHJvcGVydHkoXCJCYWNrZ3JvdW5kXCIpLkRlY2xhcmluZ1R5cGU7XHJcbmdsb2JhbDo6U3lzdGVtLlJlZmxlY3Rpb24uRmllbGRJbmZvIHByb3BlcnR5RmllbGQgPSBwcm9wZXJ0eURlY2xhcmluZ1R5cGUuR2V0RmllbGQoXCJCYWNrZ3JvdW5kUHJvcGVydHlcIik7XHJcbmdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRlcGVuZGVuY3lQcm9wZXJ0eSBwcm9wZXJ0eSA9IChnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EZXBlbmRlbmN5UHJvcGVydHkpcHJvcGVydHlGaWVsZC5HZXRWYWx1ZShudWxsKTtcclxuXHJcbiAgKGZpbmFsVGFyZ2V0SW5zdGFuY2UpLlNldEFuaW1hdGlvblZhbHVlKHByb3BlcnR5LCB2YWx1ZSk7XHJcbn1cclxuXHJcblxyXG5wdWJsaWMgdm9pZCBzZXRMb2NhbFZpc3VhbFN0YXRlUHJvcGVydHlfNTRhMGNiODg3M2EzNDExZjk3ZjU3Y2ZlYWZhNGE0NDUgKGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRlcGVuZGVuY3lPYmplY3QgZmluYWxUYXJnZXRJbnN0YW5jZSwgb2JqZWN0IHZhbHVlKVxyXG57XHJcbiAgXHJcbmdsb2JhbDo6U3lzdGVtLlR5cGUgZmluYWxUYXJnZXRJbnN0YW5jZVR5cGUgPSBmaW5hbFRhcmdldEluc3RhbmNlLkdldFR5cGUoKTtcclxuZ2xvYmFsOjpTeXN0ZW0uVHlwZSBwcm9wZXJ0eURlY2xhcmluZ1R5cGUgPSBmaW5hbFRhcmdldEluc3RhbmNlVHlwZS5HZXRQcm9wZXJ0eShcIkJhY2tncm91bmRcIikuRGVjbGFyaW5nVHlwZTtcclxuZ2xvYmFsOjpTeXN0ZW0uUmVmbGVjdGlvbi5GaWVsZEluZm8gcHJvcGVydHlGaWVsZCA9IHByb3BlcnR5RGVjbGFyaW5nVHlwZS5HZXRGaWVsZChcIkJhY2tncm91bmRQcm9wZXJ0eVwiKTtcclxuZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGVwZW5kZW5jeVByb3BlcnR5IHByb3BlcnR5ID0gKGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRlcGVuZGVuY3lQcm9wZXJ0eSlwcm9wZXJ0eUZpZWxkLkdldFZhbHVlKG51bGwpO1xyXG5cclxuICAoZmluYWxUYXJnZXRJbnN0YW5jZSkuU2V0Q3VycmVudFZhbHVlKHByb3BlcnR5LCB2YWx1ZSk7XHJcbn1cclxuXHJcblxyXG5wdWJsaWMgZ2xvYmFsOjpTeXN0ZW0uT2JqZWN0IGdldFZpc3VhbFN0YXRlUHJvcGVydHlfNTRhMGNiODg3M2EzNDExZjk3ZjU3Y2ZlYWZhNGE0NDUgKGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRlcGVuZGVuY3lPYmplY3QgZmluYWxUYXJnZXRJbnN0YW5jZSlcclxue1xyXG4gIFxyXG5nbG9iYWw6OlN5c3RlbS5UeXBlIGZpbmFsVGFyZ2V0SW5zdGFuY2VUeXBlID0gZmluYWxUYXJnZXRJbnN0YW5jZS5HZXRUeXBlKCk7XHJcbmdsb2JhbDo6U3lzdGVtLlR5cGUgcHJvcGVydHlEZWNsYXJpbmdUeXBlID0gZmluYWxUYXJnZXRJbnN0YW5jZVR5cGUuR2V0UHJvcGVydHkoXCJCYWNrZ3JvdW5kXCIpLkRlY2xhcmluZ1R5cGU7XHJcbmdsb2JhbDo6U3lzdGVtLlJlZmxlY3Rpb24uRmllbGRJbmZvIHByb3BlcnR5RmllbGQgPSBwcm9wZXJ0eURlY2xhcmluZ1R5cGUuR2V0RmllbGQoXCJCYWNrZ3JvdW5kUHJvcGVydHlcIik7XHJcbmdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRlcGVuZGVuY3lQcm9wZXJ0eSBwcm9wZXJ0eSA9IChnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EZXBlbmRlbmN5UHJvcGVydHkpcHJvcGVydHlGaWVsZC5HZXRWYWx1ZShudWxsKTtcclxuXHJcbiAgcmV0dXJuIGZpbmFsVGFyZ2V0SW5zdGFuY2UuR2V0VmlzdWFsU3RhdGVWYWx1ZShwcm9wZXJ0eSk7XHJcbn1cclxuXHJcblxyXG5wdWJsaWMgZ2xvYmFsOjpTeXN0ZW0uQ29sbGVjdGlvbnMuR2VuZXJpYy5JRW51bWVyYWJsZTxnbG9iYWw6OlN5c3RlbS5UdXBsZTxnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EZXBlbmRlbmN5T2JqZWN0LCBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EZXBlbmRlbmN5UHJvcGVydHksIGludD8+PiBhY2Nlc3NWaXN1YWxTdGF0ZVByb3BlcnR5XzFiNDU2MmQyY2M3OTQ3MzRiODg3MTYxMTE5YjVmMzkwIChnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EZXBlbmRlbmN5T2JqZWN0IHJvb3RUYXJnZXRPYmplY3RJbnN0YW5jZSlcclxue1xyXG4gIFxyXG55aWVsZCBicmVhaztcclxufVxyXG5cclxuXHJcbnB1YmxpYyB2b2lkIHNldFZpc3VhbFN0YXRlUHJvcGVydHlfMWI0NTYyZDJjYzc5NDczNGI4ODcxNjExMTliNWYzOTAgKGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRlcGVuZGVuY3lPYmplY3QgZmluYWxUYXJnZXRJbnN0YW5jZSwgb2JqZWN0IHZhbHVlKVxyXG57XHJcbiAgXHJcbmdsb2JhbDo6U3lzdGVtLlR5cGUgZmluYWxUYXJnZXRJbnN0YW5jZVR5cGUgPSBmaW5hbFRhcmdldEluc3RhbmNlLkdldFR5cGUoKTtcclxuZ2xvYmFsOjpTeXN0ZW0uVHlwZSBwcm9wZXJ0eURlY2xhcmluZ1R5cGUgPSBmaW5hbFRhcmdldEluc3RhbmNlVHlwZS5HZXRQcm9wZXJ0eShcIkJhY2tncm91bmRcIikuRGVjbGFyaW5nVHlwZTtcclxuZ2xvYmFsOjpTeXN0ZW0uUmVmbGVjdGlvbi5GaWVsZEluZm8gcHJvcGVydHlGaWVsZCA9IHByb3BlcnR5RGVjbGFyaW5nVHlwZS5HZXRGaWVsZChcIkJhY2tncm91bmRQcm9wZXJ0eVwiKTtcclxuZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGVwZW5kZW5jeVByb3BlcnR5IHByb3BlcnR5ID0gKGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRlcGVuZGVuY3lQcm9wZXJ0eSlwcm9wZXJ0eUZpZWxkLkdldFZhbHVlKG51bGwpO1xyXG5cclxuICAoZmluYWxUYXJnZXRJbnN0YW5jZSkuU2V0VmlzdWFsU3RhdGVWYWx1ZShwcm9wZXJ0eSwgdmFsdWUpO1xyXG59XHJcblxyXG5cclxucHVibGljIHZvaWQgc2V0QW5pbWF0aW9uVmlzdWFsU3RhdGVQcm9wZXJ0eV8xYjQ1NjJkMmNjNzk0NzM0Yjg4NzE2MTExOWI1ZjM5MCAoZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGVwZW5kZW5jeU9iamVjdCBmaW5hbFRhcmdldEluc3RhbmNlLCBvYmplY3QgdmFsdWUpXHJcbntcclxuICBcclxuZ2xvYmFsOjpTeXN0ZW0uVHlwZSBmaW5hbFRhcmdldEluc3RhbmNlVHlwZSA9IGZpbmFsVGFyZ2V0SW5zdGFuY2UuR2V0VHlwZSgpO1xyXG5nbG9iYWw6OlN5c3RlbS5UeXBlIHByb3BlcnR5RGVjbGFyaW5nVHlwZSA9IGZpbmFsVGFyZ2V0SW5zdGFuY2VUeXBlLkdldFByb3BlcnR5KFwiQmFja2dyb3VuZFwiKS5EZWNsYXJpbmdUeXBlO1xyXG5nbG9iYWw6OlN5c3RlbS5SZWZsZWN0aW9uLkZpZWxkSW5mbyBwcm9wZXJ0eUZpZWxkID0gcHJvcGVydHlEZWNsYXJpbmdUeXBlLkdldEZpZWxkKFwiQmFja2dyb3VuZFByb3BlcnR5XCIpO1xyXG5nbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EZXBlbmRlbmN5UHJvcGVydHkgcHJvcGVydHkgPSAoZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGVwZW5kZW5jeVByb3BlcnR5KXByb3BlcnR5RmllbGQuR2V0VmFsdWUobnVsbCk7XHJcblxyXG4gIChmaW5hbFRhcmdldEluc3RhbmNlKS5TZXRBbmltYXRpb25WYWx1ZShwcm9wZXJ0eSwgdmFsdWUpO1xyXG59XHJcblxyXG5cclxucHVibGljIHZvaWQgc2V0TG9jYWxWaXN1YWxTdGF0ZVByb3BlcnR5XzFiNDU2MmQyY2M3OTQ3MzRiODg3MTYxMTE5YjVmMzkwIChnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EZXBlbmRlbmN5T2JqZWN0IGZpbmFsVGFyZ2V0SW5zdGFuY2UsIG9iamVjdCB2YWx1ZSlcclxue1xyXG4gIFxyXG5nbG9iYWw6OlN5c3RlbS5UeXBlIGZpbmFsVGFyZ2V0SW5zdGFuY2VUeXBlID0gZmluYWxUYXJnZXRJbnN0YW5jZS5HZXRUeXBlKCk7XHJcbmdsb2JhbDo6U3lzdGVtLlR5cGUgcHJvcGVydHlEZWNsYXJpbmdUeXBlID0gZmluYWxUYXJnZXRJbnN0YW5jZVR5cGUuR2V0UHJvcGVydHkoXCJCYWNrZ3JvdW5kXCIpLkRlY2xhcmluZ1R5cGU7XHJcbmdsb2JhbDo6U3lzdGVtLlJlZmxlY3Rpb24uRmllbGRJbmZvIHByb3BlcnR5RmllbGQgPSBwcm9wZXJ0eURlY2xhcmluZ1R5cGUuR2V0RmllbGQoXCJCYWNrZ3JvdW5kUHJvcGVydHlcIik7XHJcbmdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRlcGVuZGVuY3lQcm9wZXJ0eSBwcm9wZXJ0eSA9IChnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EZXBlbmRlbmN5UHJvcGVydHkpcHJvcGVydHlGaWVsZC5HZXRWYWx1ZShudWxsKTtcclxuXHJcbiAgKGZpbmFsVGFyZ2V0SW5zdGFuY2UpLlNldEN1cnJlbnRWYWx1ZShwcm9wZXJ0eSwgdmFsdWUpO1xyXG59XHJcblxyXG5cclxucHVibGljIGdsb2JhbDo6U3lzdGVtLk9iamVjdCBnZXRWaXN1YWxTdGF0ZVByb3BlcnR5XzFiNDU2MmQyY2M3OTQ3MzRiODg3MTYxMTE5YjVmMzkwIChnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EZXBlbmRlbmN5T2JqZWN0IGZpbmFsVGFyZ2V0SW5zdGFuY2UpXHJcbntcclxuICBcclxuZ2xvYmFsOjpTeXN0ZW0uVHlwZSBmaW5hbFRhcmdldEluc3RhbmNlVHlwZSA9IGZpbmFsVGFyZ2V0SW5zdGFuY2UuR2V0VHlwZSgpO1xyXG5nbG9iYWw6OlN5c3RlbS5UeXBlIHByb3BlcnR5RGVjbGFyaW5nVHlwZSA9IGZpbmFsVGFyZ2V0SW5zdGFuY2VUeXBlLkdldFByb3BlcnR5KFwiQmFja2dyb3VuZFwiKS5EZWNsYXJpbmdUeXBlO1xyXG5nbG9iYWw6OlN5c3RlbS5SZWZsZWN0aW9uLkZpZWxkSW5mbyBwcm9wZXJ0eUZpZWxkID0gcHJvcGVydHlEZWNsYXJpbmdUeXBlLkdldEZpZWxkKFwiQmFja2dyb3VuZFByb3BlcnR5XCIpO1xyXG5nbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EZXBlbmRlbmN5UHJvcGVydHkgcHJvcGVydHkgPSAoZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGVwZW5kZW5jeVByb3BlcnR5KXByb3BlcnR5RmllbGQuR2V0VmFsdWUobnVsbCk7XHJcblxyXG4gIHJldHVybiBmaW5hbFRhcmdldEluc3RhbmNlLkdldFZpc3VhbFN0YXRlVmFsdWUocHJvcGVydHkpO1xyXG59XHJcblxyXG5cclxucHVibGljIHN0YXRpYyB2b2lkIE1haW4oKVxyXG57XHJcbiAgICBuZXcgQXBwKCk7XHJcbn1cclxuXHJcbn1cclxuXHJcblxyXG59XHJcbiIsIi8vIDxDU0hUTUw1PjxYYW1sSGFzaD4wNkE2NDE2NEY5NEIyNjg0MkI2RkY3MTUwMEJGQjY5RjwvWGFtbEhhc2g+PFBhc3NOdW1iZXI+MjwvUGFzc051bWJlcj48Q29tcGlsYXRpb25EYXRlPjE0LzA5LzIwMjQgMjA6NTc6NDE8L0NvbXBpbGF0aW9uRGF0ZT48L0NTSFRNTDU+XHJcblxyXG5cclxuXHJcbnB1YmxpYyBzdGF0aWMgY2xhc3Mgx4DHgFF3Y8eAx4BDb21wb25lbnTHgMeATWFpbnBhZ2XHgMeAWGFtbMeAx4BGYWN0b3J5XHJcbntcclxuICAgIHB1YmxpYyBzdGF0aWMgb2JqZWN0IEluc3RhbnRpYXRlKClcclxuICAgIHtcclxuICAgICAgICBnbG9iYWw6OlN5c3RlbS5UeXBlIHR5cGUgPSB0eXBlb2YoUVdDLk1haW5QYWdlKTtcclxuICAgICAgICByZXR1cm4gZ2xvYmFsOjpDU0hUTUw1LkludGVybmFsLlR5cGVJbnN0YW50aWF0aW9uSGVscGVyLkluc3RhbnRpYXRlKHR5cGUpO1xyXG4gICAgfVxyXG59XHJcblxyXG5uYW1lc3BhY2UgUVdDXHJcbntcclxuXHJcblxyXG4vLy0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG4vLyA8YXV0by1nZW5lcmF0ZWQ+XHJcbi8vICAgICBUaGlzIGNvZGUgd2FzIGF1dG8tZ2VuZXJhdGVkIGJ5IFwiQyMvWEFNTCBmb3IgSFRNTDVcIlxyXG4vL1xyXG4vLyAgICAgQ2hhbmdlcyB0byB0aGlzIGZpbGUgbWF5IGNhdXNlIGluY29ycmVjdCBiZWhhdmlvciBhbmQgd2lsbCBiZSBsb3N0IGlmXHJcbi8vICAgICB0aGUgY29kZSBpcyByZWdlbmVyYXRlZC5cclxuLy8gPC9hdXRvLWdlbmVyYXRlZD5cclxuLy8tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuXHJcblxyXG5cclxucGFydGlhbCBjbGFzcyBNYWluUGFnZSA6IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkNvbnRyb2xzLlBhZ2Vcclxue1xyXG5cclxuI3ByYWdtYSB3YXJuaW5nIGRpc2FibGUgMTY5LCA2NDksIDA2MjggLy8gUHJldmVudHMgd2FybmluZyBDUzAxNjkgKCdmaWVsZCAuLi4gaXMgbmV2ZXIgdXNlZCcpLCBDUzA2NDkgKCdmaWVsZCAuLi4gaXMgbmV2ZXIgYXNzaWduZWQgdG8sIGFuZCB3aWxsIGFsd2F5cyBoYXZlIGl0cyBkZWZhdWx0IHZhbHVlIG51bGwnKSwgYW5kIENTMDYyOCAoJ21lbWJlciA6IG5ldyBwcm90ZWN0ZWQgbWVtYmVyIGRlY2xhcmVkIGluIHNlYWxlZCBjbGFzcycpXHJcbnByb3RlY3RlZCBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Db250cm9scy5HcmlkIFFXQ0dyaWQ7XHJcbnByb3RlY3RlZCBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Db250cm9scy5XcmFwUGFuZWwgUVdDSWNvbnM7XHJcbnByb3RlY3RlZCBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Db250cm9scy5HcmlkIFFXQ0hpZGRlbjtcclxucHJvdGVjdGVkIGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkNvbnRyb2xzLkdyaWQgUVdDU2lkZUJhcnM7XHJcbnByb3RlY3RlZCBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Db250cm9scy5QYWdlIFRvcDtcclxuXHJcblxyXG4jcHJhZ21hIHdhcm5pbmcgcmVzdG9yZSAxNjksIDY0OSwgMDYyOFxyXG5cclxuXHJcbiAgICAgICAgcHJpdmF0ZSBib29sIF9jb250ZW50TG9hZGVkO1xyXG4gICAgICAgIHB1YmxpYyB2b2lkIEluaXRpYWxpemVDb21wb25lbnQoKVxyXG4gICAgICAgIHtcclxuICAgICAgICAgICAgaWYgKF9jb250ZW50TG9hZGVkKVxyXG4gICAgICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgICAgICBfY29udGVudExvYWRlZCA9IHRydWU7XHJcblxyXG4jcHJhZ21hIHdhcm5pbmcgZGlzYWJsZSAwMTg0IC8vIFByZXZlbnRzIHdhcm5pbmcgQ1MwMTg0ICgnVGhlIGdpdmVuIGV4cHJlc3Npb24gaXMgbmV2ZXIgb2YgdGhlIHByb3ZpZGVkICgndHlwZScpIHR5cGUnKVxyXG4gICAgICAgICAgICBpZiAodGhpcyBpcyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5VSUVsZW1lbnQpXHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICgoZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuVUlFbGVtZW50KShvYmplY3QpdGhpcykuWGFtbFNvdXJjZVBhdGggPSBAXCJRV0NcXE1haW5QYWdlLnhhbWxcIjtcclxuICAgICAgICAgICAgfVxyXG4jcHJhZ21hIHdhcm5pbmcgcmVzdG9yZSAwMTg0XHJcblxyXG52YXIgR3JpZF9jMGZiYjg5MmQ4ZGM0OGZjOTU0YjMyMDM0ZDk3MDkwNiA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Db250cm9scy5HcmlkKCk7XHJcbnZhciBXcmFwUGFuZWxfMDg1ZTM0ZmY1OTQyNGQ4MGI0M2E5ODJjMGY2ZTFmOTAgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuQ29udHJvbHMuV3JhcFBhbmVsKCk7XHJcbnZhciBHcmlkXzZiY2ZkZTRlNjlhNTQwYmU5NTRiZWRjMzdlNmM4NjhiID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkNvbnRyb2xzLkdyaWQoKTtcclxudmFyIEdyaWRfMThkY2EwZGRhNzJmNDE1YzhhNGY5MTY2MDFiNWY5NDMgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuQ29udHJvbHMuR3JpZCgpO1xyXG5cclxudGhpcy5SZWdpc3Rlck5hbWUoXCJUb3BcIiwgdGhpcyk7XHJcbnRoaXMuTmFtZSA9IFwiVG9wXCI7XHJcbnZhciBJbnRDb252ZXJ0ZXJfY2IwN2MyMmU4MDk2NGE0NmJkOTdiNWExYjVjY2QwYWYgPSBuZXcgZ2xvYmFsOjpBUExFeHRlbnNpb24uSW50Q29udmVydGVyKCk7XHJcblxyXG52YXIgRGVjQ29udmVydGVyXzU0Mzg4MzIxN2JlYTQzZjNiNmY3MzAxMzczYWM4YzY0ID0gbmV3IGdsb2JhbDo6QVBMRXh0ZW5zaW9uLkRlY0NvbnZlcnRlcigpO1xyXG5cclxudGhpcy5SZXNvdXJjZXNbXCJJbnRDb252ZXJ0ZXJcIl0gPSBJbnRDb252ZXJ0ZXJfY2IwN2MyMmU4MDk2NGE0NmJkOTdiNWExYjVjY2QwYWY7XHJcbnRoaXMuUmVzb3VyY2VzW1wiRGVjQ29udmVydGVyXCJdID0gRGVjQ29udmVydGVyXzU0Mzg4MzIxN2JlYTQzZjNiNmY3MzAxMzczYWM4YzY0O1xyXG5cclxudmFyIEdyaWRfYWFiZmE4ODI3NDc3NGZkMWI2NGIyOWMwODExZWUxNTYgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuQ29udHJvbHMuR3JpZCgpO1xyXG52YXIgUm93RGVmaW5pdGlvbl9kZmFlMjdhYjc1Yjk0N2JlOGQ1ZTlhMTBmODIwZWM4ZSA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Db250cm9scy5Sb3dEZWZpbml0aW9uKCk7XHJcblJvd0RlZmluaXRpb25fZGZhZTI3YWI3NWI5NDdiZThkNWU5YTEwZjgyMGVjOGUuSGVpZ2h0ID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkdyaWRMZW5ndGgoMS4wLCBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5HcmlkVW5pdFR5cGUuU3Rhcik7XHJcblxyXG52YXIgUm93RGVmaW5pdGlvbl80NmFkNmVmMDQ0ZWU0ZTVhYTRmNDY4OGJhYTgxNzgxYyA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Db250cm9scy5Sb3dEZWZpbml0aW9uKCk7XHJcblJvd0RlZmluaXRpb25fNDZhZDZlZjA0NGVlNGU1YWE0ZjQ2ODhiYWE4MTc4MWMuSGVpZ2h0ID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkdyaWRMZW5ndGgoMS4wLCBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5HcmlkVW5pdFR5cGUuQXV0byk7XHJcblxyXG5HcmlkX2FhYmZhODgyNzQ3NzRmZDFiNjRiMjljMDgxMWVlMTU2LlJvd0RlZmluaXRpb25zLkFkZChSb3dEZWZpbml0aW9uX2RmYWUyN2FiNzViOTQ3YmU4ZDVlOWExMGY4MjBlYzhlKTtcclxuR3JpZF9hYWJmYTg4Mjc0Nzc0ZmQxYjY0YjI5YzA4MTFlZTE1Ni5Sb3dEZWZpbml0aW9ucy5BZGQoUm93RGVmaW5pdGlvbl80NmFkNmVmMDQ0ZWU0ZTVhYTRmNDY4OGJhYTgxNzgxYyk7XHJcblxyXG50aGlzLlJlZ2lzdGVyTmFtZShcIlFXQ0dyaWRcIiwgR3JpZF9jMGZiYjg5MmQ4ZGM0OGZjOTU0YjMyMDM0ZDk3MDkwNik7XHJcbkdyaWRfYzBmYmI4OTJkOGRjNDhmYzk1NGIzMjAzNGQ5NzA5MDYuTmFtZSA9IFwiUVdDR3JpZFwiO1xyXG5cclxudGhpcy5SZWdpc3Rlck5hbWUoXCJRV0NJY29uc1wiLCBXcmFwUGFuZWxfMDg1ZTM0ZmY1OTQyNGQ4MGI0M2E5ODJjMGY2ZTFmOTApO1xyXG5XcmFwUGFuZWxfMDg1ZTM0ZmY1OTQyNGQ4MGI0M2E5ODJjMGY2ZTFmOTAuTmFtZSA9IFwiUVdDSWNvbnNcIjtcclxuZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuQ29udHJvbHMuR3JpZC5TZXRSb3coV3JhcFBhbmVsXzA4NWUzNGZmNTk0MjRkODBiNDNhOTgyYzBmNmUxZjkwLDEpO1xyXG5cclxudGhpcy5SZWdpc3Rlck5hbWUoXCJRV0NIaWRkZW5cIiwgR3JpZF82YmNmZGU0ZTY5YTU0MGJlOTU0YmVkYzM3ZTZjODY4Yik7XHJcbkdyaWRfNmJjZmRlNGU2OWE1NDBiZTk1NGJlZGMzN2U2Yzg2OGIuTmFtZSA9IFwiUVdDSGlkZGVuXCI7XHJcbmdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkNvbnRyb2xzLkdyaWQuU2V0Um93KEdyaWRfNmJjZmRlNGU2OWE1NDBiZTk1NGJlZGMzN2U2Yzg2OGIsMSk7XHJcbkdyaWRfNmJjZmRlNGU2OWE1NDBiZTk1NGJlZGMzN2U2Yzg2OGIuVmlzaWJpbGl0eSA9IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlZpc2liaWxpdHkuQ29sbGFwc2VkO1xyXG5cclxudGhpcy5SZWdpc3Rlck5hbWUoXCJRV0NTaWRlQmFyc1wiLCBHcmlkXzE4ZGNhMGRkYTcyZjQxNWM4YTRmOTE2NjAxYjVmOTQzKTtcclxuR3JpZF8xOGRjYTBkZGE3MmY0MTVjOGE0ZjkxNjYwMWI1Zjk0My5OYW1lID0gXCJRV0NTaWRlQmFyc1wiO1xyXG5nbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Db250cm9scy5HcmlkLlNldFJvdyhHcmlkXzE4ZGNhMGRkYTcyZjQxNWM4YTRmOTE2NjAxYjVmOTQzLDEpO1xyXG5HcmlkXzE4ZGNhMGRkYTcyZjQxNWM4YTRmOTE2NjAxYjVmOTQzLlZpc2liaWxpdHkgPSBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5WaXNpYmlsaXR5LkNvbGxhcHNlZDtcclxuXHJcbkdyaWRfYWFiZmE4ODI3NDc3NGZkMWI2NGIyOWMwODExZWUxNTYuQ2hpbGRyZW4uQWRkKEdyaWRfYzBmYmI4OTJkOGRjNDhmYzk1NGIzMjAzNGQ5NzA5MDYpO1xyXG5HcmlkX2FhYmZhODgyNzQ3NzRmZDFiNjRiMjljMDgxMWVlMTU2LkNoaWxkcmVuLkFkZChXcmFwUGFuZWxfMDg1ZTM0ZmY1OTQyNGQ4MGI0M2E5ODJjMGY2ZTFmOTApO1xyXG5HcmlkX2FhYmZhODgyNzQ3NzRmZDFiNjRiMjljMDgxMWVlMTU2LkNoaWxkcmVuLkFkZChHcmlkXzZiY2ZkZTRlNjlhNTQwYmU5NTRiZWRjMzdlNmM4NjhiKTtcclxuR3JpZF9hYWJmYTg4Mjc0Nzc0ZmQxYjY0YjI5YzA4MTFlZTE1Ni5DaGlsZHJlbi5BZGQoR3JpZF8xOGRjYTBkZGE3MmY0MTVjOGE0ZjkxNjYwMWI1Zjk0Myk7XHJcblxyXG5cclxudGhpcy5Db250ZW50ID0gR3JpZF9hYWJmYTg4Mjc0Nzc0ZmQxYjY0YjI5YzA4MTFlZTE1NjtcclxuXHJcbnZhciBEYXRhQ29udGV4dEV4dGVuc2lvbl82NzkxZWU1NTUzNDI0ZjUwODRmNDUzZmM5NjMyN2ZmOCA9IG5ldyBnbG9iYWw6OkFQTEV4dGVuc2lvbi5EYXRhQ29udGV4dEV4dGVuc2lvbigpO1xyXG5EYXRhQ29udGV4dEV4dGVuc2lvbl82NzkxZWU1NTUzNDI0ZjUwODRmNDUzZmM5NjMyN2ZmOC5JbnN0YW5jZSA9IEBcInF3Y19Sb290XCI7XHJcbkRhdGFDb250ZXh0RXh0ZW5zaW9uXzY3OTFlZTU1NTM0MjRmNTA4NGY0NTNmYzk2MzI3ZmY4LkNsYXNzID0gQFwicXdjX1Jvb3RcIjtcclxuRGF0YUNvbnRleHRFeHRlbnNpb25fNjc5MWVlNTU1MzQyNGY1MDg0ZjQ1M2ZjOTYzMjdmZjguTlMgPSBAXCJEYXRhQmluZGluZ1wiO1xyXG5cclxuXHJcblxyXG5cclxuUVdDR3JpZCA9IEdyaWRfYzBmYmI4OTJkOGRjNDhmYzk1NGIzMjAzNGQ5NzA5MDY7XHJcblFXQ0ljb25zID0gV3JhcFBhbmVsXzA4NWUzNGZmNTk0MjRkODBiNDNhOTgyYzBmNmUxZjkwO1xyXG5RV0NIaWRkZW4gPSBHcmlkXzZiY2ZkZTRlNjlhNTQwYmU5NTRiZWRjMzdlNmM4NjhiO1xyXG5RV0NTaWRlQmFycyA9IEdyaWRfMThkY2EwZGRhNzJmNDE1YzhhNGY5MTY2MDFiNWY5NDM7XHJcblRvcCA9IHRoaXM7XHJcblxyXG52YXIgY3VzdG9tTWFya3VwVmFsdWVfNzFkMWNjOGVkZDViNDJhM2JhZmViOGQxY2FjYjc3NDggPSBEYXRhQ29udGV4dEV4dGVuc2lvbl82NzkxZWU1NTUzNDI0ZjUwODRmNDUzZmM5NjMyN2ZmOC5Qcm92aWRlVmFsdWUobmV3IGdsb2JhbDo6U3lzdGVtLlNlcnZpY2VQcm92aWRlcih0aGlzLCBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5GcmFtZXdvcmtFbGVtZW50LkRhdGFDb250ZXh0UHJvcGVydHkpKTtcclxuaWYoY3VzdG9tTWFya3VwVmFsdWVfNzFkMWNjOGVkZDViNDJhM2JhZmViOGQxY2FjYjc3NDggaXMgV2luZG93cy5VSS5YYW1sLkRhdGEuQmluZGluZylcclxue1xyXG4gICAgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5CaW5kaW5nT3BlcmF0aW9ucy5TZXRCaW5kaW5nKHRoaXMsIGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkZyYW1ld29ya0VsZW1lbnQuRGF0YUNvbnRleHRQcm9wZXJ0eSwgKFdpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmcpY3VzdG9tTWFya3VwVmFsdWVfNzFkMWNjOGVkZDViNDJhM2JhZmViOGQxY2FjYjc3NDgpO1xyXG59XHJcbmVsc2Vcclxue1xyXG4gICAgdGhpcy5EYXRhQ29udGV4dCA9IChnbG9iYWw6OlN5c3RlbS5PYmplY3QpY3VzdG9tTWFya3VwVmFsdWVfNzFkMWNjOGVkZDViNDJhM2JhZmViOGQxY2FjYjc3NDg7XHJcbn1cclxuICAgIFxyXG4gICAgICAgIH1cclxuXHJcblxyXG5cclxuXHJcbn1cclxuXHJcblxyXG59XHJcbiIsInVzaW5nIEFQTENvbnRyb2xzO1xyXG51c2luZyBBUExDb250cm9scztcclxudXNpbmcgQVBMRXh0ZW5zaW9uO1xyXG51c2luZyBEYXRhQmluZGluZztcclxudXNpbmcgU3lzdGVtO1xyXG51c2luZyBDU0hUTUw1O1xyXG51c2luZyBTeXN0ZW0uQ29sbGVjdGlvbnMuR2VuZXJpYztcclxudXNpbmcgU3lzdGVtLklPO1xyXG51c2luZyBTeXN0ZW0uTGlucTtcclxudXNpbmcgV2luZG93cy5VSS5YYW1sO1xyXG51c2luZyBXaW5kb3dzLlVJLlhhbWwuQ29udHJvbHM7XHJcbnVzaW5nIFdpbmRvd3MuRm91bmRhdGlvbjtcclxubmFtZXNwYWNlIFFXQ1xyXG57XHJcbiAgICBwdWJsaWMgc2VhbGVkIHBhcnRpYWwgY2xhc3MgQXBwIDogQXBwbGljYXRpb25cclxuICAgIHtcclxuICAgICAgICBBUExFeHRlbnNpb24uRGF0YUNvbnRleHRFeHRlbnNpb24gZDtcclxuICAgICAgICBwdWJsaWMgQXBwKClcclxuICAgICAgICB7XHJcbiAgICAgICAgICAgIHRoaXMuSW5pdGlhbGl6ZUNvbXBvbmVudCgpO1xyXG4gICAgICAgICAgICAvLyBFbnRlciBjb25zdHJ1Y3Rpb24gbG9naWMgaGVyZS4uLlxyXG4gICAgICAgICAgICB0cnlcclxuICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgRGF0YUJpbmRpbmcuU2VuZGVyQ2xhc3MgYSA9IG5ldyBEYXRhQmluZGluZy5TZW5kZXJDbGFzcygpO1xyXG4gICAgICAgICAgICAgICAgQXBwbGljYXRpb24uQ3VycmVudC5SZXNvdXJjZXNbXCJTZW5kZXJDbGFzc1wiXSA9IGE7XHJcbiAgICAgICAgICAgICAgICBBcHBsaWNhdGlvbi5DdXJyZW50LlJlc291cmNlc1tcIlFXQ1wiXSA9IHRoaXM7XHJcbiAgICAgICAgICAgIH0gY2F0Y2ggeyB9XHJcbiAgICAgICAgICAgIHZhciBtYWluUGFnZSA9IG5ldyBNYWluUGFnZSgpO1xyXG4gICBJbnRlcm9wLkV4ZWN1dGVKYXZhU2NyaXB0KFwiaWYgKG1qaF9maWxlc2xvYWRlZCkgbWpoX2ZpbGVzbG9hZGVkWydwYWdlJ10gPSAkMFwiLCBtYWluUGFnZSk7XHJcbiAgICAgICAgICAgIFdpbmRvdy5DdXJyZW50LkNvbnRlbnQgPSBtYWluUGFnZTtcclxuICAgICAgICB9XHJcbnZvaWQgUnVuQ2xpY2tNaW4oT2JqZWN0IHMsIFJvdXRlZEV2ZW50QXJncyBhcmdzKSB7XHJcbnF3Y0Zvcm1fRGF0YSBkYyA9IChxd2NGb3JtX0RhdGEpICgoQnV0dG9uKSBzKS5EYXRhQ29udGV4dDtcclxuZGMuU2VuZE1hcmdpbiA9IGZhbHNlO1xyXG5kYy5TdGF0ZSA9IDE7XHJcbnF3Y19Sb290IHJvb3QgPSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBcInF3Y19Sb290XCIsIFwicXdjX1Jvb3RcIiwgdGhpcykgYXMgcXdjX1Jvb3Q7XHJcbnJvb3QuRnVsbFNjcmVlbklkID0gXCJcIjtcclxufSBcclxudm9pZCBSdW5DbGlja01heChPYmplY3QgcywgUm91dGVkRXZlbnRBcmdzIGFyZ3MpIHtcclxucXdjRm9ybV9EYXRhIGRjID0gKHF3Y0Zvcm1fRGF0YSkoKEJ1dHRvbilzKS5EYXRhQ29udGV4dDtcclxuZGMuU2VuZE1hcmdpbiA9IGZhbHNlO1xyXG5pZiAoMiA9PSBkYy5TdGF0ZSkgZGMuU3RhdGUgID0gMDtcclxuZWxzZSBkYy5TdGF0ZSA9IDI7XHJcbnF3Y19Sb290IHJvb3QgPSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBcInF3Y19Sb290XCIsIFwicXdjX1Jvb3RcIiwgdGhpcykgYXMgcXdjX1Jvb3Q7XHJcbnJvb3QuRnVsbFNjcmVlbklkID0gXCJcIjtcclxufSBcclxudm9pZCBSdW5DbGlja0Z1bGxTY3JlZW4oT2JqZWN0IHMsIFJvdXRlZEV2ZW50QXJncyBhcmdzKSB7XHJcbnF3Y0Zvcm1fRGF0YSBkYyA9IChxd2NGb3JtX0RhdGEpKChCdXR0b24pcykuRGF0YUNvbnRleHQ7XHJcbkFQTEZvcm0gb2JqID0gZGMuTUpIX1NlbGYgYXMgQVBMRm9ybTtcclxuZGMuU2VuZE1hcmdpbiA9IGZhbHNlO1xyXG5JbnRlcm9wLkV4ZWN1dGVKYXZhU2NyaXB0KFwidmFyIGVsZW0gPSAkMFwiLCBJbnRlcm9wLkdldERpdihvYmopKTtcclxuSW50ZXJvcC5FeGVjdXRlSmF2YVNjcmlwdChcIm9wZW5GdWxsc2NyZWVuKGVsZW0pXCIpO1xyXG5kYy5TdGF0ZSA9IDQ7XHJcbnF3Y19Sb290IHJvb3QgPSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBcInF3Y19Sb290XCIsIFwicXdjX1Jvb3RcIiwgdGhpcykgYXMgcXdjX1Jvb3Q7XHJcbnJvb3QuRnVsbFNjcmVlbklkID0gZGMuTmFtZTtcclxufSBcclxudm9pZCBSdW5DbGlja0Nsb3NlKE9iamVjdCBzLCBSb3V0ZWRFdmVudEFyZ3MgYXJncykge1xyXG5xd2NGb3JtX0RhdGEgZGMgPSAocXdjRm9ybV9EYXRhKSgoQnV0dG9uKXMpLkRhdGFDb250ZXh0O1xyXG5kYy5TZW5kTWFyZ2luID0gZmFsc2U7XHJcblN0cmluZyBldmVudG5hbWUgPSBcIkNsaWNrQ2xvc2VcIjtcclxuQVBMRm9ybSBvYmogPSBkYy5NSkhfU2VsZiBhcyBBUExGb3JtO1xyXG5vYmouQ2xvc2UoKTtcclxufSBcclxufX1cclxuIiwidXNpbmcgU3lzdGVtO1xyXG51c2luZyBTeXN0ZW0uQ29sbGVjdGlvbnMuR2VuZXJpYztcclxudXNpbmcgU3lzdGVtLklPO1xyXG51c2luZyBTeXN0ZW0uTGlucTtcclxudXNpbmcgV2luZG93cy5TeXN0ZW07XHJcbnVzaW5nIFdpbmRvd3MuVUkuWGFtbDtcclxudXNpbmcgV2luZG93cy5VSS5YYW1sLkNvbnRyb2xzO1xyXG51c2luZyBTeXN0ZW0uV2luZG93cy5JbnB1dDtcclxudXNpbmcgV2luZG93cy5VSS5YYW1sLklucHV0O1xyXG51c2luZyBXaW5kb3dzLlVJLlhhbWwuRGF0YTtcclxudXNpbmcgV2luZG93cy5Gb3VuZGF0aW9uO1xyXG51c2luZyBTeXN0ZW0uQ29sbGVjdGlvbnMuT2JqZWN0TW9kZWw7XHJcbnVzaW5nIFN5c3RlbS5XaW5kb3dzLkJyb3dzZXI7XHJcbnVzaW5nIFN5c3RlbS5SZWZsZWN0aW9uO1xyXG51c2luZyBBUExFeHRlbnNpb247XHJcbnVzaW5nIERhdGFCaW5kaW5nO1xyXG51c2luZyBDU0hUTUw1O1xyXG51c2luZyBTeXN0ZW0uVGhyZWFkaW5nLlRhc2tzO1xyXG51c2luZyBNSkhTb2Z0d2FyZS5Db21tb247XHJcbnVzaW5nIEFQTENvbnRyb2xzO1xyXG51c2luZyBTeXN0ZW0uVGhyZWFkaW5nO1xyXG5uYW1lc3BhY2UgUVdDXHJcbnsgXHJcbnB1YmxpYyBzZWFsZWQgcGFydGlhbCBjbGFzcyBNYWluUGFnZSA6IFBhZ2VcclxueyBcclxucHVibGljIHJlYWRvbmx5IFRhc2tDb21wbGV0aW9uU291cmNlPGJvb2w+IGZpbGVzUmVhZHkgPSBuZXcgVGFza0NvbXBsZXRpb25Tb3VyY2U8Ym9vbD4oKTtcclxucHVibGljIFRhc2s8Ym9vbD4gRmlsZXNSZWFkeSB7IGdldCB7IHJldHVybiBmaWxlc1JlYWR5LlRhc2s7IH0gfVxyXG5yZWFkb25seSBUYXNrQ29tcGxldGlvblNvdXJjZTxib29sPiB3ZWJTb2NrZXRSZWFkeSA9IG5ldyBUYXNrQ29tcGxldGlvblNvdXJjZTxib29sPigpO1xyXG5wdWJsaWMgVGFzazxib29sPiBXZWJTb2NrZXRSZWFkeSB7IGdldCB7IHJldHVybiB3ZWJTb2NrZXRSZWFkeS5UYXNrOyB9IH1cclxuQ1NIVE1MNS5FeHRlbnNpb25zLldlYlNvY2tldHMuV2ViU29ja2V0IHdlYlNvY2tldDtcclxuQ1NIVE1MNS5FeHRlbnNpb25zLldlYlNvY2tldHMuV2ViU29ja2V0IGRpcmVjdHdlYlNvY2tldDtcclxuU3RyaW5nIGNvbm5lY3Rpb24gPSBcIlwiO1xyXG5TdHJpbmcgY29ubmVjdGlvbnBvcnQgPSBcIlwiO1xyXG5Cb29sZWFuIEFsbFJlYWR5ID0gZmFsc2U7XHJcbkJvb2xlYW4gU2V0dXBDb21wbGV0ZVJ1biA9IGZhbHNlO1xyXG5wdWJsaWMgTWFpblBhZ2UoKSB7XHJcblJ1blJlc3RNYWluKCk7XHJcbn0gXHJcbnZvaWQgQWRkRmlsZUxvYWRpbmcoKSB7XHJcbkludGVyb3AuRXhlY3V0ZUphdmFTY3JpcHQoXCJtamhfZmlsZXNsb2FkZWQudmFsdWUgKz0gMVwiKTtcclxuaW50IEZpbGVzTG9hZGVkID0gKGludCkgSW50ZXJvcC5FeGVjdXRlSmF2YVNjcmlwdChcIm1qaF9maWxlc2xvYWRlZC52YWx1ZVwiKTtcclxuaW50IFRvdGFsRmlsZXNUb0JlTG9hZGVkID0gKGludCkgSW50ZXJvcC5FeGVjdXRlSmF2YVNjcmlwdChcIm1qaF9maWxlc2xvYWRlZC50b3RhbFwiKTtcclxuaWYgKEZpbGVzTG9hZGVkID09IFRvdGFsRmlsZXNUb0JlTG9hZGVkKSB7Ym9vbCB4ID0gZmlsZXNSZWFkeS5UcnlTZXRSZXN1bHQodHJ1ZSk7fTtcclxufSBcclxudm9pZCBDaGVja0ZpbGVMb2FkaW5nKCkge1xyXG5pbnQgRmlsZXNMb2FkZWQgPSAoaW50KSBJbnRlcm9wLkV4ZWN1dGVKYXZhU2NyaXB0KFwibWpoX2ZpbGVzbG9hZGVkLnZhbHVlXCIpO1xyXG5pbnQgVG90YWxGaWxlc1RvQmVMb2FkZWQgPSAoaW50KSBJbnRlcm9wLkV4ZWN1dGVKYXZhU2NyaXB0KFwibWpoX2ZpbGVzbG9hZGVkLnRvdGFsXCIpO1xyXG5pZiAoRmlsZXNMb2FkZWQgPT0gVG90YWxGaWxlc1RvQmVMb2FkZWQpIHtib29sIHggPSBmaWxlc1JlYWR5LlRyeVNldFJlc3VsdCh0cnVlKTt9O1xyXG59IFxyXG52b2lkIEVuZEN1c3RvbUNTUygpIHtcclxuYm9vbCBydW5mbGcgPSAoYm9vbCkgSW50ZXJvcC5FeGVjdXRlSmF2YVNjcmlwdChcIigndW5kZWZpbmVkJyAhPXR5cGVvZiBlaiAmJiAgJ3VuZGVmaW5lZCcgIT0gdHlwZW9mIGVqLmJhc2UpXCIpO1xyXG5pZiAocnVuZmxnKSB7XHJcbkludGVyb3AuRXhlY3V0ZUphdmFTY3JpcHQoXCJlai5iYXNlLmVuYWJsZVJpcHBsZShmYWxzZSlcIik7XHJcbn0gXHJcbn0gXHJcbnZvaWQgUnVuUmVzdE1haW4oKSB7XHJcbkludGVyb3AuRXhlY3V0ZUphdmFTY3JpcHQoXCJ3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcignYmVmb3JldW5sb2FkJywgJDApXCIsIChGdW5jPG9iamVjdCxzdHJpbmc+KU9uQmVmb3JlVW5sb2FkKTtcclxuQXBwbGljYXRpb24uQ3VycmVudC5SZXNvdXJjZXNbXCJNYXhTZXJpYWxOb1wiXSA9IDA7XHJcbkFwcGxpY2F0aW9uLkN1cnJlbnQuUmVzb3VyY2VzW1wiRnJhbWV3b3JrRWxlbWVudFwiXSA9IHRoaXM7XHJcbkFwcGxpY2F0aW9uLkN1cnJlbnQuUmVzb3VyY2VzW1wiQWxsUmVhZHlcIl0gPSBBbGxSZWFkeTtcclxuU3RyaW5nIG9yaWdpbmFsID0gSHRtbFBhZ2UuRG9jdW1lbnQuRG9jdW1lbnRVcmkuT3JpZ2luYWxTdHJpbmc7XHJcbkFwcGxpY2F0aW9uLkN1cnJlbnQuUmVzb3VyY2VzW1wiT3JpZ2luYWxVUkxcIl0gPSBvcmlnaW5hbDtcclxuU3RyaW5nIGNvbm5lY3Rpb247XHJcbkRpY3Rpb25hcnk8c3RyaW5nLHN0cmluZz4gYXBwcyA9IFV0aWxzLkdldEFwcHNSZXNvdXJjZShcIlFXQ1wiLFwid2ViZGV0YWlscy5odG1sXCIpO1xyXG5jb25uZWN0aW9uID0gVXRpbHMuR2V0QXBwUmVzb3VyY2UoYXBwcywgXCJDb25uZWN0aW9uXCIpO1xyXG5pZiAoMCA9PSBjb25uZWN0aW9uLkxlbmd0aCkge1xyXG5jb25uZWN0aW9uID0gKFN0cmluZylBcHBsaWNhdGlvbi5DdXJyZW50LlRyeUZpbmRSZXNvdXJjZShcIkNvbm5lY3Rpb25cIik7XHJcbn0gXHJcblN0cmluZyBjb25uZWN0aW9udHlwZSA9IFV0aWxzLkdldEFwcFJlc291cmNlKGFwcHMsIFwiQ29ubmVjdGlvblR5cGVcIik7XHJcbmlmICgwID09IGNvbm5lY3Rpb250eXBlLkxlbmd0aCkgeyBcclxuY29ubmVjdGlvbnR5cGUgPSAoU3RyaW5nKUFwcGxpY2F0aW9uLkN1cnJlbnQuVHJ5RmluZFJlc291cmNlKFwiQ29ubmVjdGlvblR5cGVcIik7XHJcbn0gXHJcbnN0cmluZyB1cGxvYWRob3N0ID0gVXRpbHMuR2V0QXBwUmVzb3VyY2UoYXBwcywgXCJVcGxvYWRIb3N0XCIpO1xyXG5pZiAobnVsbCA9PSB1cGxvYWRob3N0IHx8IDAgPT0gdXBsb2FkaG9zdC5MZW5ndGgpIHtcclxudXBsb2FkaG9zdCA9IChTdHJpbmcpQXBwbGljYXRpb24uQ3VycmVudC5UcnlGaW5kUmVzb3VyY2UoXCJVcGxvYWRIb3N0XCIpO1xyXG5pZiAobnVsbCA9PSB1cGxvYWRob3N0IHx8IDAgPT0gdXBsb2FkaG9zdC5MZW5ndGgpIHVwbG9hZGhvc3QgPSBcImxvY2FsaG9zdFwiO1xyXG59IFxyXG5BcHBsaWNhdGlvbi5DdXJyZW50LlJlc291cmNlc1tcIlVwbG9hZEhvc3RcIl0gPSB1cGxvYWRob3N0O1xyXG5zdHJpbmcgdXBsb2FkcG9ydCA9IFV0aWxzLkdldEFwcFJlc291cmNlKGFwcHMsIFwiVXBsb2FkUG9ydFwiKTtcclxuaWYgKG51bGwgPT0gdXBsb2FkcG9ydCB8fCAwID09IHVwbG9hZHBvcnQuTGVuZ3RoKSB7XHJcbnVwbG9hZHBvcnQgPSAoU3RyaW5nKUFwcGxpY2F0aW9uLkN1cnJlbnQuVHJ5RmluZFJlc291cmNlKFwiVXBsb2FkUG9ydFwiKTtcclxuaWYgKG51bGwgPT0gdXBsb2FkcG9ydCB8fCAwID09IHVwbG9hZHBvcnQuTGVuZ3RoKSB1cGxvYWRwb3J0ID0gXCIxMjM0XCI7XHJcbn0gXHJcbkFwcGxpY2F0aW9uLkN1cnJlbnQuUmVzb3VyY2VzW1wiVXBsb2FkUG9ydFwiXSA9IHVwbG9hZHBvcnQ7XHJcbnN0cmluZyB1cGxvYWRzZWN1cmUgPSBVdGlscy5HZXRBcHBSZXNvdXJjZShhcHBzLCBcIlVwbG9hZFNlY3VyZVwiKTtcclxuaWYgKG51bGwgPT0gdXBsb2Fkc2VjdXJlIHx8IDAgPT0gdXBsb2Fkc2VjdXJlLkxlbmd0aCkge1xyXG51cGxvYWRzZWN1cmUgPSAoU3RyaW5nKUFwcGxpY2F0aW9uLkN1cnJlbnQuVHJ5RmluZFJlc291cmNlKFwiVXBsb2FkU2VjdXJlXCIpO1xyXG5pZiAobnVsbCA9PSB1cGxvYWRzZWN1cmUgfHwgMCA9PSB1cGxvYWRzZWN1cmUuTGVuZ3RoKSB1cGxvYWRzZWN1cmUgPSBcIjBcIjtcclxufSBcclxuQXBwbGljYXRpb24uQ3VycmVudC5SZXNvdXJjZXNbXCJVcGxvYWRTZWN1cmVcIl0gPSB1cGxvYWRzZWN1cmU7XHJcbnN0cmluZyBuYW1lID0gVXRpbHMuR2V0QXBwUmVzb3VyY2UoYXBwcywgXCJOYW1lXCIpO1xyXG5pZiAoMCA9PSBuYW1lLkxlbmd0aCkge1xyXG5uYW1lID0gKFN0cmluZylBcHBsaWNhdGlvbi5DdXJyZW50LlJlc291cmNlc1tcIk5hbWVcIl07XHJcbn0gXHJcbnN0cmluZyBXU25hbWUgPSBVdGlscy5HZXRBcHBSZXNvdXJjZShhcHBzLCBcIldTTmFtZVwiKTtcclxuaWYgKDAgPT0gV1NuYW1lLkxlbmd0aCkge1xyXG5XU25hbWUgPSAoU3RyaW5nKUFwcGxpY2F0aW9uLkN1cnJlbnQuVHJ5RmluZFJlc291cmNlKFwiV1NOYW1lXCIpO1xyXG59IFxyXG5zdHJpbmcgcG9ydCA9IFV0aWxzLkdldEFwcFJlc291cmNlKGFwcHMsIFwiUG9ydFwiKTtcclxuaWYgKDAgPT0gcG9ydC5MZW5ndGgpIHtcclxucG9ydCA9IChTdHJpbmcpQXBwbGljYXRpb24uQ3VycmVudC5UcnlGaW5kUmVzb3VyY2UoXCJQb3J0XCIpO1xyXG59IFxyXG5pZiAobnVsbCA9PSBXU25hbWUgKSB7IFdTbmFtZSA9IFwiV1NcIjsgfVxyXG5XU25hbWUgPSBXU25hbWUuVHJpbSgpO1xyXG5pZiAoXCJcIiA9PSBXU25hbWUpIHsgV1NuYW1lID0gXCJXU1wiOyB9XHJcbmlmIChXU25hbWUuVG9VcHBlcigpID09IFwiTk9ORVwiKSBXU25hbWUgPSBcIlwiO1xyXG5pZiAobnVsbCA9PSBjb25uZWN0aW9uKSB7IGNvbm5lY3Rpb24gPSBcIlwiOyB9XHJcbmNvbm5lY3Rpb24gPSBjb25uZWN0aW9uLlRyaW0oKTtcclxuaWYgKG51bGwgPT0gY29ubmVjdGlvbnR5cGUpIHsgY29ubmVjdGlvbnR5cGUgPSBcIlwiOyB9XHJcbmNvbm5lY3Rpb250eXBlID0gY29ubmVjdGlvbnR5cGUuVHJpbSgpO1xyXG5pZiAoXCJcIiA9PSBjb25uZWN0aW9udHlwZSkgeyBjb25uZWN0aW9udHlwZSA9IFwiRGlyZWN0XCI7IH1cclxuaWYgKFwiXCIgPT0gY29ubmVjdGlvbikge1xyXG5pZiAoXCJodHRwXCIgPT0gSHRtbFBhZ2UuRG9jdW1lbnQuRG9jdW1lbnRVcmkuU2NoZW1lKSBjb25uZWN0aW9uID0gSHRtbFBhZ2UuRG9jdW1lbnQuRG9jdW1lbnRVcmkuSG9zdDtcclxuZWxzZSBjb25uZWN0aW9uID0gXCJsb2NhbGhvc3RcIjtcclxuIH1cclxuc3RyaW5nIGFwcG5hbWUgPSBVdGlscy5HZXRBcHBSZXNvdXJjZShhcHBzLCBcIkFwcE5hbWVcIik7XHJcbmlmICgwID09IGFwcG5hbWUuTGVuZ3RoKSBhcHBuYW1lID0gKFN0cmluZylBcHBsaWNhdGlvbi5DdXJyZW50LlRyeUZpbmRSZXNvdXJjZShcIkFwcE5hbWVcIik7XHJcbmlmIChudWxsID09IGFwcG5hbWUpIGFwcG5hbWUgPSBuYW1lO1xyXG5pZiAoXCJcIiA9PSBhcHBuYW1lKSBhcHBuYW1lID0gbmFtZTtcclxuQXBwbGljYXRpb24uQ3VycmVudC5SZXNvdXJjZXNbXCJBcHBOYW1lXCJdID0gYXBwbmFtZTtcclxuaWYgKFwiRGlyZWN0XCIgPT0gY29ubmVjdGlvbnR5cGUpIHtcclxuaWYgKG51bGwgPT0gcG9ydCkgeyBwb3J0ID0gXCJcIjsgfVxyXG5zdHJpbmcgdXJpID0gKHN0cmluZykgSW50ZXJvcC5FeGVjdXRlSmF2YVNjcmlwdChcImRvY3VtZW50LmxvY2F0aW9uLnNlYXJjaFwiKTtcclxuaWYgKDAgIT0gdXJpLkxlbmd0aCkge1xyXG5zdHJpbmcgcCA9IFwiXCI7XHJcbmZvcihpbnQgaT0wOyBpIDwgdXJpLkxlbmd0aDsgaSsrKSB7XHJcbmlmICgnPycgIT0gdXJpW2ldKSB7XHJcbmlmICgnMCcgPT0gdXJpW2ldIHx8ICcxJyA9PSB1cmlbaV0gfHwgJzInID09IHVyaVtpXSB8fCAnMycgPT0gdXJpW2ldIHx8ICc0JyA9PSB1cmlbaV0gfHwgJzUnID09IHVyaVtpXSB8fCAnNicgPT0gdXJpW2ldIHx8ICc3JyA9PSB1cmlbaV0gfHwgJzgnID09IHVyaVtpXSB8fCAnOScgPT0gdXJpW2ldKSB7XHJcbnAgKz0gdXJpW2ldO1xyXG59IFxyXG5lbHNlIGJyZWFrO1xyXG59IFxyXG59IFxyXG5pZiAoMCAhPSBwLkxlbmd0aCkgcG9ydCA9IHA7XHJcbn0gXHJcbmlmIChcIlwiID09IHBvcnQpIHsgcG9ydCA9IEh0bWxQYWdlLkRvY3VtZW50LkRvY3VtZW50VXJpLlBvcnQuVG9TdHJpbmcoKTsgfVxyXG5jb25uZWN0aW9uICs9IFwiOlwiICsgcG9ydCArIFwiL1wiICsgbmFtZSArXCIvXCI7XHJcbn0gZWxzZSB7XHJcbmlmICgwICE9IGNvbm5lY3Rpb24uTGVuZ3RoKSB7XHJcbmNvbm5lY3Rpb25wb3J0ID0gVXRpbHMuR2V0QXBwUmVzb3VyY2UoYXBwcywgXCJDb25uZWN0aW9uUG9ydFwiKTtcclxuaWYgKGNvbm5lY3Rpb25wb3J0ID09IG51bGwgfHwgMCA9PSBjb25uZWN0aW9ucG9ydC5MZW5ndGgpIGNvbm5lY3Rpb25wb3J0ID0gKFN0cmluZylBcHBsaWNhdGlvbi5DdXJyZW50LlRyeUZpbmRSZXNvdXJjZShcIkNvbm5lY3Rpb25Qb3J0XCIpO1xyXG5pZiAoY29ubmVjdGlvbnBvcnQgIT0gbnVsbCAmJiAwICE9IGNvbm5lY3Rpb25wb3J0Lkxlbmd0aCkgY29ubmVjdGlvbiArPSBcIjpcIiArIGNvbm5lY3Rpb25wb3J0O1xyXG59IFxyXG5jb25uZWN0aW9uICs9IFwiL1wiICsgV1NuYW1lO1xyXG5pZiAoMCAhPSBXU25hbWUuTGVuZ3RoKSBjb25uZWN0aW9uICs9IFwiL1wiO1xyXG59IFxyXG5zdHJpbmcgc2VjdXJlY29ubmVjdGlvbiA9IFV0aWxzLkdldEFwcFJlc291cmNlKGFwcHMsIFwiU2VjdXJlQ29ubmVjdGlvblwiKTtcclxuaWYgKG51bGwgPT0gc2VjdXJlY29ubmVjdGlvbiB8fCAwID09IHNlY3VyZWNvbm5lY3Rpb24uTGVuZ3RoKSB7XHJcbnNlY3VyZWNvbm5lY3Rpb24gPSAoU3RyaW5nKUFwcGxpY2F0aW9uLkN1cnJlbnQuVHJ5RmluZFJlc291cmNlKFwiU2VjdXJlQ29ubmVjdGlvblwiKTtcclxuaWYgKG51bGwgPT0gc2VjdXJlY29ubmVjdGlvbiB8fCAwID09IHNlY3VyZWNvbm5lY3Rpb24uTGVuZ3RoKSBzZWN1cmVjb25uZWN0aW9uID0gXCIwXCI7XHJcbn0gXHJcbkFwcGxpY2F0aW9uLkN1cnJlbnQuUmVzb3VyY2VzW1wiU2VjdXJlQ29ubmVjdGlvblwiXSA9IHNlY3VyZWNvbm5lY3Rpb247XHJcbmlmIChzZWN1cmVjb25uZWN0aW9uID09IFwiMVwiKSBjb25uZWN0aW9uID0gXCJ3c3M6Ly9cIiArIGNvbm5lY3Rpb247XHJcbmVsc2UgY29ubmVjdGlvbiA9IFwid3M6Ly9cIiArIGNvbm5lY3Rpb247XHJcbldTSW50ZXJuYWxzIF9XU0ludGVybmFscyA9IEFQTC5NYWtlSW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLFwiV1NJbnRlcm5hbHNcIixcIldTSW50ZXJuYWxzXCIsdGhpcykgYXMgV1NJbnRlcm5hbHM7XHJcbnF3Y19Sb290IF9xd2NfUm9vdCA9IEFQTC5NYWtlSW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLFwicXdjX1Jvb3RcIixcInF3Y19Sb290XCIsdGhpcykgYXMgcXdjX1Jvb3Q7XHJcbi8vIFJhbmRvbSBybmQgPSBuZXcgUmFuZG9tKEd1aWQuTmV3R3VpZCgpLkdldEhhc2hDb2RlKCkpO1xyXG5SYW5kb20gcm5kID0gbmV3IFJhbmRvbSgpO1xyXG5zdHJpbmcgcm5kcyA9IHJuZC5OZXh0KCkuVG9TdHJpbmcoKTtcclxud2ViU29ja2V0ID0gbmV3IENTSFRNTDUuRXh0ZW5zaW9ucy5XZWJTb2NrZXRzLldlYlNvY2tldChjb25uZWN0aW9uICsgXCI/aGFzaD1cIiArIHJuZHMpO1xyXG5kaXJlY3R3ZWJTb2NrZXQgPSBuZXcgQ1NIVE1MNS5FeHRlbnNpb25zLldlYlNvY2tldHMuV2ViU29ja2V0KGNvbm5lY3Rpb24gKyBcIj9oYXNoPVwiICsgcm5kcyk7XHJcbkFwcGxpY2F0aW9uLkN1cnJlbnQuUmVzb3VyY2VzW1wiV2ViU29ja2V0XCJdID0gd2ViU29ja2V0O1xyXG5BcHBsaWNhdGlvbi5DdXJyZW50LlJlc291cmNlc1tcIkRpcmVjdFdlYlNvY2tldFwiXSA9IGRpcmVjdHdlYlNvY2tldDtcclxuVHJhbnNmZXJTdHJpbmcgeHN0cmluZztcclxuc3RyaW5nIGQgPSBcIlwiO1xyXG53ZWJTb2NrZXQuT25NZXNzYWdlKz0gYXN5bmMgKHMsIGUpID0+e1xyXG5pZiAoU2V0dXBDb21wbGV0ZVJ1bikge1xyXG5TZXR1cENvbXBsZXRlUnVuID0gZmFsc2U7XHJcbkNoZWNrRmlsZUxvYWRpbmcoKTtcclxuYXdhaXQgRmlsZXNSZWFkeTtcclxuRW5kQ3VzdG9tQ1NTKCk7XHJcbn0gXHJcbnN0cmluZ1tdIGRhdGEgPSAoc3RyaW5nW10pVEQuU3BsaXQoZS5EYXRhLCBURC5kZWxpbXM1KTtcclxuZm9yIChpbnQgaSA9IDA7IGkgPCBkYXRhLkxlbmd0aDsgaSsrKSB7XHJcblRyYW5zZmVyU3RyaW5nIGRzPVRELlRvVHJhbnNmZXJTdHJpbmcoZGF0YVtpXSk7XHJcbnN0cmluZyB0cmFucyA9IGRzLlRyYW5zO1xyXG5pZiAoZHMuQWN0aW9uID09IFwiV2FpdEZvclF1ZXVlXCIpIHtcclxud2ViU29ja2V0LlNlbmQoZGF0YVtpXSk7XHJcbn0gZWxzZSBpZiAoZHMuQWN0aW9uID09IFwiTUpIX0Nsb3NlU2VydmVyXCIpIHtcclxud2ViU29ja2V0LlNlbmQoZGF0YVtpXSk7XHJcbn0gZWxzZSBpZiAoZHMuQWN0aW9uID09IFwiUGluZ1wiKSB7XHJcbndlYlNvY2tldC5TZW5kKGRhdGFbaV0pO1xyXG59IGVsc2UgaWYgKGRzLkFjdGlvbiA9PSBcIkxvYWRlZFwiKSB7XHJcbkFwcGxpY2F0aW9uLkN1cnJlbnQuUmVzb3VyY2VzW1wiSW5kZXhcIl0gPSBkcy5EYXRhO1xyXG53ZWJTb2NrZXRSZWFkeS5TZXRSZXN1bHQodHJ1ZSk7XHJcbl9XU0ludGVybmFscy5TdGF0dXMgPSBcIldlYlNvY2tldCBPcGVuZWQgXCI7XHJcbkFsbFJlYWR5ID0gdHJ1ZTtcclxuQXBwbGljYXRpb24uQ3VycmVudC5SZXNvdXJjZXNbXCJBbGxSZWFkeVwiXSA9IEFsbFJlYWR5O1xyXG50aGlzLkluaXRpYWxpemVDb21wb25lbnQoKTtcclxuTWFrZVdpblNpemUoX3F3Y19Sb290LF9XU0ludGVybmFscyk7XHJcbl9xd2NfUm9vdC5Ob3RpZnlQcm9wZXJ0eUNoYW5nZWQoXCJGb250TGlzdFwiKTtcclxuX3F3Y19Sb290Lk5vdGlmeVByb3BlcnR5Q2hhbmdlZChcIkZvbnRGYW1pbHlcIik7XHJcbl9xd2NfUm9vdC5Ob3RpZnlQcm9wZXJ0eUNoYW5nZWQoXCJDYXB0aW9uXCIpO1xyXG5fcXdjX1Jvb3QuTm90aWZ5UHJvcGVydHlDaGFuZ2VkKFwiVVJMXCIpO1xyXG5fcXdjX1Jvb3QuTm90aWZ5UHJvcGVydHlDaGFuZ2VkKFwiVVJMU1wiKTtcclxuX3F3Y19Sb290Lk5vdGlmeVByb3BlcnR5Q2hhbmdlZChcIkNhcHRpb25zXCIpO1xyXG5JbnRlcm9wLkV4ZWN1dGVKYXZhU2NyaXB0KFwibG9hZEZvbnQoJDAsJDEpXCIsXCJBUEwzODVcIixcImFwcC1jc2h0bWw1L3Jlcy9RV0MvZm9udHMvYXBsMzg1LXdlYmZvbnQud29mZlwiKTtcclxuTGlzdDxzdHJpbmc+IGZ1bGxmb250ID0gZ2xvYmFsOjpCcmlkZ2UuU2NyaXB0LkNhbGxGb3IobmV3IExpc3Q8c3RyaW5nPigpLChfbzEpPT57X28xLkFkZChcIkFQTDM4NVwiKTtfbzEuQWRkKFwiQW5kYWzDqSBNb25vXCIpO19vMS5BZGQoXCJBcmlhbFwiKTtfbzEuQWRkKFwiQXJpYWwgQmxhY2tcIik7X28xLkFkZChcIkFyaWFsIE5hcnJvd1wiKTtfbzEuQWRkKFwiQXJpYWwgUm91bmRlZCBNVCBCb2xkXCIpO19vMS5BZGQoXCJCYXNrZXJ2aWxsZVwiKTtfbzEuQWRkKFwiQm9kb25pIDcyXCIpO19vMS5BZGQoXCJCb2RvbmkgTVRcIik7X28xLkFkZChcIkJyYWRsZXkgSGFuZFwiKTtfbzEuQWRkKFwiQnJ1c2ggU2NyaXB0IE1UXCIpO19vMS5BZGQoXCJDYWxpYnJpXCIpO19vMS5BZGQoXCJDYWxpc3RvIE1UXCIpO19vMS5BZGQoXCJDYW1icmlhXCIpO19vMS5BZGQoXCJDYW5kYXJhXCIpO19vMS5BZGQoXCJDZW50dXJ5IEdvdGhpY1wiKTtfbzEuQWRkKFwiQ29taWMgU2FucyBNU1wiKTtfbzEuQWRkKFwiQ29uc29sYXNcIik7X28xLkFkZChcIkNvcHBlcnBsYXRlIEdvdGhpY1wiKTtfbzEuQWRkKFwiQ291cmllclwiKTtfbzEuQWRkKFwiQ291cmllciBOZXdcIik7X28xLkFkZChcIkRlamF2dSBTYW5zXCIpO19vMS5BZGQoXCJEaWRvdFwiKTtfbzEuQWRkKFwiRnJhbmtsaW4gR290aGljXCIpO19vMS5BZGQoXCJHYXJhbW9uZFwiKTtfbzEuQWRkKFwiR2VvcmdpYVwiKTtfbzEuQWRkKFwiR2lsbCBTYW5zXCIpO19vMS5BZGQoXCJHb3VkeSBPbGQgU3R5bGVcIik7X28xLkFkZChcIkhlbHZldGljYVwiKTtfbzEuQWRkKFwiSGVsdmV0aWNhIE5ldVwiKTtfbzEuQWRkKFwiSW1wYWN0XCIpO19vMS5BZGQoXCJMdWNpZGFcIik7X28xLkFkZChcIkx1Y2lkYSBCcmlnaHRcIik7X28xLkFkZChcIkx1Y2lkYSBIYW5kd3JpdGluZ1wiKTtfbzEuQWRkKFwiTHVjaWRhIFNhbnNcIik7X28xLkFkZChcIkx1bWluYXJpXCIpO19vMS5BZGQoXCJNaWNyb3NvZnQgU2FucyBTZXJpZlwiKTtfbzEuQWRkKFwiTW9uYWNvXCIpO19vMS5BZGQoXCJPcHRpbWFcIik7X28xLkFkZChcIlBhbGF0aW5vXCIpO19vMS5BZGQoXCJQZXJwZXR1YVwiKTtfbzEuQWRkKFwiUmFnZVwiKTtfbzEuQWRkKFwiUm9ja3dlbGxcIik7X28xLkFkZChcIlNjcmlwdCBNVFwiKTtfbzEuQWRkKFwiU2Vnb2UgVUlcIik7X28xLkFkZChcIlNlZ29lIHNjcmlwdFwiKTtfbzEuQWRkKFwiU25lbGwgUm91bmRoYW5kXCIpO19vMS5BZGQoXCJUYWhvbWFcIik7X28xLkFkZChcIlRpbWVzIE5ldyBSb21hblwiKTtfbzEuQWRkKFwiVHJlYnVjaGV0IE1TXCIpO19vMS5BZGQoXCJWZXJkYW5hXCIpO3JldHVybiBfbzE7fSk7XHJcbl9xd2NfUm9vdC5NSkhfRm9udExpc3RfU2hhcGVbMF0gPSA1MTtcclxuX3F3Y19Sb290Lk1KSF9Gb250TGlzdF9TaGFwZVsxXSA9IDg7XHJcbl9xd2NfUm9vdC5NSkhfRm9udEZhbWlseV9TaGFwZSA9IDUxO1xyXG5MaXN0PExpc3Q8QVBMSXRlbT4+IGYgPSBuZXcgTGlzdDxMaXN0PEFQTEl0ZW0+PigpO1xyXG5mb3IgKGludCByID0gMDtyPDUxOyByKyspIHtcclxuZi5BZGQobmV3IExpc3Q8QVBMSXRlbT4oKSk7XHJcbmZbcl0uQWRkKG5ldyBBUExJdGVtKGZ1bGxmb250W3JdKSk7XHJcbmZbcl0uQWRkKG5ldyBBUExJdGVtKDApKTtcclxuZltyXS5BZGQobmV3IEFQTEl0ZW0oMCkpO1xyXG5mW3JdLkFkZChuZXcgQVBMSXRlbSgwKSk7XHJcbmZbcl0uQWRkKG5ldyBBUExJdGVtKDApKTtcclxuZltyXS5BZGQobmV3IEFQTEl0ZW0oMCkpO1xyXG5mW3JdLkFkZChuZXcgQVBMSXRlbSgwKSk7XHJcbmZbcl0uQWRkKG5ldyBBUExJdGVtKDApKTtcclxufSBcclxuX3F3Y19Sb290LkZvbnRMaXN0ID0gZjtcclxuX3F3Y19Sb290LkZvbnRGYW1pbHkgPSAgZ2xvYmFsOjpCcmlkZ2UuU2NyaXB0LkNhbGxGb3IobmV3IExpc3Q8c3RyaW5nPigpLChfbzIpPT57X28yLkFkZChcIkFQTDM4NVwiKTtfbzIuQWRkKFwiQW5kYWzDqSBNb25vLCBtb25vc3BhY2VcIik7X28yLkFkZChcIkFyaWFsLCBIZWx2ZXRpY2EgTmV1ZSwgSGVsdmV0aWNhLCBzYW5zLXNlcmlmXCIpO19vMi5BZGQoXCJBcmlhbCBCbGFjaywgQXJpYWwgQm9sZCwgR2FkZ2V0LCBzYW5zLXNlcmlmXCIpO19vMi5BZGQoXCJBcmlhbCBOYXJyb3csIEFyaWFsLCBzYW5zLXNlcmlmXCIpO19vMi5BZGQoXCJBcmlhbCBSb3VuZGVkIE1UIEJvbGQsIEhlbHZldGljYSBSb3VuZGVkLCBBcmlhbCwgc2Fucy1zZXJpZlwiKTtfbzIuQWRkKFwiQmFza2VydmlsbGUsIEJhc2tlcnZpbGxlIE9sZCBGYWNlLCBHYXJhbW9uZCwgVGltZXMgTmV3IFJvbWFuLCBzZXJpZlwiKTtfbzIuQWRkKFwiQm9kb25pIDcyLCBCb2RvbmkgTVQsIERpZG90LCBEaWRvdCBMVCBTVEQsIEhvZWZsZXIgVGV4dCwgR2FyYW1vbmQsIFRpbWVzIE5ldyBSb21hbiwgc2VyaWZcIik7X28yLkFkZChcIkJvZG9uaSBNVCwgQm9kb25pIDcyLCBEaWRvdCwgRGlkb3QgTFQgU1RELCBIb2VmbGVyIFRleHQsIEdhcmFtb25kLCBUaW1lcyBOZXcgUm9tYW4sIHNlcmlmXCIpO19vMi5BZGQoXCJCcmFkbGV5IEhhbmQsIGN1cnNpdmVcIik7X28yLkFkZChcIkJydXNoIFNjcmlwdCBNVCwgY3Vyc2l2ZVwiKTtfbzIuQWRkKFwiQ2FsaWJyaSwgQ2FuZGFyYSwgU2Vnb2UsIFNlZ29lIFVJLCBPcHRpbWEsIEFyaWFsLCBzYW5zLXNlcmlmXCIpO19vMi5BZGQoXCJDYWxpc3RvIE1ULCBCb29rbWFuIE9sZCBTdHlsZSwgQm9va21hbiwgR291ZHkgT2xkIFN0eWxlLCBHYXJhbW9uZCwgSG9lZmxlciBUZXh0LCBCaXRzdHJlYW0gQ2hhcnRlciwgR2VvcmdpYSwgc2VyaWZcIik7X28yLkFkZChcIkNhbWJyaWEsIEdlb3JnaWEsIHNlcmlmXCIpO19vMi5BZGQoXCJDYW5kYXJhLCBDYWxpYnJpLCBTZWdvZSwgU2Vnb2UgVUksIE9wdGltYSwgQXJpYWwsIHNhbnMtc2VyaWZcIik7X28yLkFkZChcIkNlbnR1cnkgR290aGljLCBDZW50dXJ5R290aGljLCBBcHBsZUdvdGhpYywgc2Fucy1zZXJpZlwiKTtfbzIuQWRkKFwiQ29taWMgU2FucyBNUywgY3Vyc2l2ZVwiKTtfbzIuQWRkKFwiQ29uc29sYXMsIG1vbmFjbywgbW9ub3NwYWNlXCIpO19vMi5BZGQoXCJDb3BwZXJwbGF0ZSBHb3RoaWMsIENvcHBlcnBsYXRlIEdvdGhpYyBMaWdodCwgZmFudGFzeVwiKTtfbzIuQWRkKFwiQ291cmllciwgbW9ub3NwYWNlXCIpO19vMi5BZGQoXCJDb3VyaWVyIE5ldywgQ291cmllciwgTHVjaWRhIFNhbnMgVHlwZXdyaXRlciwgTHVjaWRhIFR5cGV3cml0ZXIsIG1vbm9zcGFjZVwiKTtfbzIuQWRkKFwiRGVqYXZ1IFNhbnMsIEFyaWFsLCBWZXJkYW5hLCBzYW5zLXNlcmlmXCIpO19vMi5BZGQoXCJEaWRvdCwgRGlkb3QgTFQgU1RELCBIb2VmbGVyIFRleHQsIEdhcmFtb25kLCBDYWxpc3RvIE1ULCBUaW1lcyBOZXcgUm9tYW4sIHNlcmlmXCIpO19vMi5BZGQoXCJGcmFua2xpbiBHb3RoaWMsIEFyaWFsIEJvbGQsIEFyaWFsLCBzYW5zLXNlcmlmXCIpO19vMi5BZGQoXCJHYXJhbW9uZCwgQmFza2VydmlsbGUsIEJhc2tlcnZpbGxlIE9sZCBGYWNlLCBIb2VmbGVyIFRleHQsIFRpbWVzIE5ldyBSb21hbiwgc2VyaWZcIik7X28yLkFkZChcIkdlb3JnaWEsIFRpbWVzLCBUaW1lcyBOZXcgUm9tYW4sIHNlcmlmXCIpO19vMi5BZGQoXCJHaWxsIFNhbnMsIEdpbGwgU2FucyBNVCwgQ2FsaWJyaSwgc2Fucy1zZXJpZlwiKTtfbzIuQWRkKFwiR291ZHkgT2xkIFN0eWxlLCBHYXJhbW9uZCwgQmlnIENhc2xvbiwgVGltZXMgTmV3IFJvbWFuLCBzZXJpZlwiKTtfbzIuQWRkKFwiSGVsdmV0aWNhLCBIZWx2ZXRpY2EgTmV1LCBBcmlhbCwgc2Fucy1zZXJpZi5cIik7X28yLkFkZChcIkhlbHZldGljYSBOZXUsIEhlbHZldGljYSwgQXJpYWwsIHNhbnMtc2VyaWYuXCIpO19vMi5BZGQoXCJJbXBhY3QsIENoYXJjb2FsLCBIZWx2ZXRpY2EgSW5zZXJhdCwgQml0c3RyZWFtIFZlcmEgU2FucyBCb2xkLCBBcmlhbCBCbGFjaywgc2Fucy1zZXJpZi5cIik7X28yLkFkZChcIkx1Y2lkYSwgbW9ub3NwYWNlXCIpO19vMi5BZGQoXCJMdWNpZGEgQnJpZ2h0LCBHZW9yZ2lhLCBzZXJpZi5cIik7X28yLkFkZChcIkx1Y2lkYSBIYW5kd3JpdGluZywgY3Vyc2l2ZVwiKTtfbzIuQWRkKFwiTHVjaWRhIFNhbnMsIEhlbHZldGljYSwgQXJpYWwsIHNhbnMtc2VyaWYuXCIpO19vMi5BZGQoXCJMdW1pbmFyaSwgZmFudGFzeVwiKTtfbzIuQWRkKFwiTWljcm9zb2Z0IFNhbnMgU2VyaWYsIHNhbnMtc2VyaWYuXCIpO19vMi5BZGQoXCJNb25hY28sIG1vbm9zcGFjZVwiKTtfbzIuQWRkKFwiT3B0aW1hLCBTZWdvZSwgU2Vnb2UgVUksIENhbmRhcmEsIENhbGlicmksIEFyaWFsLCBzYW5zLXNlcmlmLlwiKTtfbzIuQWRkKFwiUGFsYXRpbm8sIFBhbGF0aW5vIExpbm90eXBlLCBQYWxhdGlubyBMVCBTVEQsIEJvb2sgQW50aXF1YSwgR2VvcmdpYSwgc2VyaWYuXCIpO19vMi5BZGQoXCJQZXJwZXR1YSwgQmFza2VydmlsbGUsIEJpZyBDYXNsb24sIFBhbGF0aW5vIExpbm90eXBlLCBQYWxhdGlubywgc2VyaWYuXCIpO19vMi5BZGQoXCJSYWdlLCBjdXJzaXZlXCIpO19vMi5BZGQoXCJSb2Nrd2VsbCwgQ291cmllciBCb2xkLCBDb3VyaWVyLCBHZW9yZ2lhLCBUaW1lcywgVGltZXMgTmV3IFJvbWFuLCBzZXJpZi5cIik7X28yLkFkZChcIlNjcmlwdCBNVCwgY3Vyc2l2ZVwiKTtfbzIuQWRkKFwiU2Vnb2UgVUksIEZydXRpZ2VyLCBEZWphdnUgU2FucywgSGVsdmV0aWNhIE5ldWUsIEFyaWFsLCBzYW5zLXNlcmlmLlwiKTtfbzIuQWRkKFwiU2Vnb2Ugc2NyaXB0LCBjdXJzaXZlXCIpO19vMi5BZGQoXCJTbmVsbCBSb3VuZGhhbmQsIGN1cnNpdmVcIik7X28yLkFkZChcIlRhaG9tYSwgVmVyZGFuYSwgU2Vnb2UsIHNhbnMtc2VyaWYuXCIpO19vMi5BZGQoXCJUaW1lcyBOZXcgUm9tYW4sIEdlb3JnaWEsIHNlcmlmO1wiKTtfbzIuQWRkKFwiVHJlYnVjaGV0IE1TLCBMdWNpZGEgR3JhbmRlLCBMdWNpZGEgU2FucyBVbmljb2RlLCBMdWNpZGEgU2Fucywgc2Fucy1zZXJpZi5cIik7X28yLkFkZChcIlZlcmRhbmEsIEdlbmV2YSwgc2Fucy1zZXJpZi5cIik7cmV0dXJuIF9vMjt9KTtcclxuX3F3Y19Sb290Lk5vdGlmeVByb3BlcnR5Q2hhbmdlZChcIkZvbnRMaXN0XCIpO1xyXG5fcXdjX1Jvb3QuTm90aWZ5UHJvcGVydHlDaGFuZ2VkKFwiRm9udEZhbWlseVwiKTtcclxueHN0cmluZyA9IG5ldyBUcmFuc2ZlclN0cmluZygpO1xyXG54c3RyaW5nLlR5cGUgPSBcIlNldHVwQ29tcGxldGVcIjtcclxuU2V0dXBDb21wbGV0ZVJ1biA9IHRydWU7XHJcbmQgPSBURC5Gcm9tVHJhbnNmZXJTdHJpbmcoeHN0cmluZyk7XHJcbndlYlNvY2tldC5TZW5kKGQpO1xyXG52YXIgZWxlbSA9IEludGVyb3AuRXhlY3V0ZUphdmFTY3JpcHQoXCJkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgkMCk7XCIsXCJtamhzcGxhc2hzY3JlZW5cIik7XHJcbkludGVyb3AuRXhlY3V0ZUphdmFTY3JpcHQoXCIkMC5zdHlsZSA9ICQxO1wiLCBlbGVtLCBcImRpc3BsYXk6IG5vbmU7XCIpO1xyXG59IGVsc2UgaWYgKGRzLkFjdGlvbiA9PSBcIkNyZWF0ZVwiKSB7ICAvLyBxV0NcclxuRW5kQ3VzdG9tQ1NTKCk7XHJcbmRzLk5hbWUgPSBcIlR5cGVcIjtcclxuZHMuRGF0YSA9IGRzLkNsYXNzLlN1YnN0cmluZygzKTtcclxuaWYgKGRzLkNsYXNzID09IFwicXdjQnV0dG9uXCIgfHxkcy5DbGFzcyA9PSBcInF3Y0NvbWJvXCIgfHxkcy5DbGFzcyA9PSBcInF3Y0RhdGVUaW1lUGlja2VyXCIgfHxkcy5DbGFzcyA9PSBcInF3Y01zZ0JveFwiIHx8ZHMuQ2xhc3MgPT0gXCJxd2NFZGl0XCIgfHxkcy5DbGFzcyA9PSBcInF3Y0xpc3RcIiB8fGRzLkNsYXNzID09IFwicXdjTGlzdFZpZXdTaW5nbGVcIiB8fGRzLkNsYXNzID09IFwicXdjTGlzdFZpZXdNdWx0aVwiIHx8ZHMuQ2xhc3MgPT0gXCJxd2NNZW51SXRlbVwiIHx8ZHMuQ2xhc3MgPT0gXCJxd2NUYWJDb250cm9sXCIgKSB7XHJcbmRzLkNsYXNzICs9IGRzLkV4dHJhcztcclxufVxyXG5zdHJpbmcgY2wgPSBkcy5DbGFzcyArIFwiX0RhdGFcIjtcclxub2JqZWN0IG8gPSBBUEwuTWFrZUluc3RhbmNlKFwiRGF0YUJpbmRpbmdcIiwgY2wsIGRzLkluc3RhbmNlLCB0aGlzKTtcclxueHN0cmluZyA9IG5ldyBUcmFuc2ZlclN0cmluZygpO1xyXG54c3RyaW5nLlRyYW5zID0gdHJhbnM7XHJcbmQgPSBURC5Gcm9tVHJhbnNmZXJTdHJpbmcoeHN0cmluZyk7XHJcbndlYlNvY2tldC5TZW5kKGQpO1xyXG59IGVsc2UgaWYgKGRzLkFjdGlvbiA9PSBcIkVuZFJ1bkxvYWRlZFwiKSB7XHJcbkNyZWF0ZUNvbnRyb2woZHMpO1xyXG59IGVsc2UgaWYgKGRzLkFjdGlvbiA9PSBcIk9sZENyZWF0ZVwiKSB7ICAvLyBxV0NcclxuZHMuTmFtZSA9IFwiVHlwZVwiO1xyXG5kcy5EYXRhID0gZHMuQ2xhc3MuU3Vic3RyaW5nKDMpO1xyXG5pZiAoZHMuQ2xhc3MgPT0gXCJxd2NCdXR0b25cIiB8fGRzLkNsYXNzID09IFwicXdjQ29tYm9cIiB8fGRzLkNsYXNzID09IFwicXdjRGF0ZVRpbWVQaWNrZXJcIiB8fGRzLkNsYXNzID09IFwicXdjTXNnQm94XCIgfHxkcy5DbGFzcyA9PSBcInF3Y0VkaXRcIiB8fGRzLkNsYXNzID09IFwicXdjTGlzdFwiIHx8ZHMuQ2xhc3MgPT0gXCJxd2NMaXN0Vmlld1NpbmdsZVwiIHx8ZHMuQ2xhc3MgPT0gXCJxd2NMaXN0Vmlld011bHRpXCIgfHxkcy5DbGFzcyA9PSBcInF3Y01lbnVJdGVtXCIgfHxkcy5DbGFzcyA9PSBcInF3Y1RhYkNvbnRyb2xcIiApIHtcclxuZHMuQ2xhc3MgKz0gZHMuRXh0cmFzO1xyXG59XHJcbkFzc2VtYmx5IGFzc2VtYmx5ID0gQVBMLkdldEFzc2VtYmx5KFwiRGF0YUJpbmRpbmdcIiwgdGhpcyk7XHJcblR5cGUgdHlwZSA9IGFzc2VtYmx5LkdldFR5cGUoXCJEYXRhQmluZGluZ1wiICsgXCIuXCIgKyBkcy5DbGFzcyk7XHJcbnZhciBvYiA9IEFjdGl2YXRvci5DcmVhdGVJbnN0YW5jZSh0eXBlLGRzKTtcclxuU3RyaW5nIGNsID0gQVBMLkdldENsYXNzQnlOYW1lKGRzLkluc3RhbmNlKTtcclxudmFyIG9iaiA9IEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGNsLCBkcy5JbnN0YW5jZSwgIG9iKTtcclxueHN0cmluZyA9IG5ldyBUcmFuc2ZlclN0cmluZygpO1xyXG54c3RyaW5nLlRyYW5zID0gdHJhbnM7XHJcbmQ9VEQuRnJvbVRyYW5zZmVyU3RyaW5nKHhzdHJpbmcpO1xyXG53ZWJTb2NrZXQuU2VuZChkKTtcclxuZGlyZWN0d2ViU29ja2V0LlNlbmQoZCk7XHJcbn0gZWxzZSBpZiAoZHMuQWN0aW9uID09IFwiQ3JlYXRlQ29udGludWUxXCIpIHtcclxuaWYgKGRzLkNsYXNzID09IFwicXdjQnV0dG9uXCIgfHxkcy5DbGFzcyA9PSBcInF3Y0NvbWJvXCIgfHxkcy5DbGFzcyA9PSBcInF3Y0RhdGVUaW1lUGlja2VyXCIgfHxkcy5DbGFzcyA9PSBcInF3Y01zZ0JveFwiIHx8ZHMuQ2xhc3MgPT0gXCJxd2NFZGl0XCIgfHxkcy5DbGFzcyA9PSBcInF3Y0xpc3RcIiB8fGRzLkNsYXNzID09IFwicXdjTGlzdFZpZXdTaW5nbGVcIiB8fGRzLkNsYXNzID09IFwicXdjTGlzdFZpZXdNdWx0aVwiIHx8ZHMuQ2xhc3MgPT0gXCJxd2NNZW51SXRlbVwiIHx8ZHMuQ2xhc3MgPT0gXCJxd2NUYWJDb250cm9sXCIgKSB7XHJcbmRzLkNsYXNzICs9IGRzLkV4dHJhczsgfVxyXG5Bc3NlbWJseSBhc3NlbWJseSA9IEFQTC5HZXRBc3NlbWJseShcIkRhdGFCaW5kaW5nXCIsIHRoaXMpO1xyXG5TdHJpbmcgY2wgPSBBUEwuR2V0Q2xhc3NCeU5hbWUoZHMuSW5zdGFuY2UpO1xyXG52YXIgb2JqID0gQVBMLkdldEluc3RhbmNlKFwiRGF0YUJpbmRpbmdcIiwgY2wsIGRzLkluc3RhbmNlLCBudWxsKTtcclxuVHlwZSBjbGEgPSBhc3NlbWJseS5HZXRUeXBlKFwiRGF0YUJpbmRpbmdcIiArIFwiLlwiICsgZHMuQ2xhc3MpO1xyXG5NZXRob2RJbmZvIG1ldGhvZCA9IGNsYS5HZXRNZXRob2QoXCJDcmVhdGVDb250aW51ZTFcIik7XHJcbmlmIChtZXRob2QgIT0gbnVsbCkge1xyXG52YXIgYXJndW1lbnRzID0gbmV3IG9iamVjdFtdIHsgZHMgfTtcclxubWV0aG9kLkludm9rZSgoKE1KSF9Db21tb25EYXRhKW9iaikuTUpIX0NsYXNzLCBhcmd1bWVudHMpOyB9XHJcbnhzdHJpbmcgPSBuZXcgVHJhbnNmZXJTdHJpbmcoKTtcclxueHN0cmluZy5UcmFucyA9IHRyYW5zO1xyXG5kID0gVEQuRnJvbVRyYW5zZmVyU3RyaW5nKHhzdHJpbmcpO1xyXG53ZWJTb2NrZXQuU2VuZChkKTtcclxuZGlyZWN0d2ViU29ja2V0LlNlbmQoZCk7XHJcbn0gZWxzZSBpZiAoZHMuQWN0aW9uID09IFwiQ3JlYXRlQ29udGludWUyXCIpIHsgIC8vIFxyXG5pZiAoZHMuQ2xhc3MgPT0gXCJxd2NCdXR0b25cIiB8fGRzLkNsYXNzID09IFwicXdjQ29tYm9cIiB8fGRzLkNsYXNzID09IFwicXdjRGF0ZVRpbWVQaWNrZXJcIiB8fGRzLkNsYXNzID09IFwicXdjTXNnQm94XCIgfHxkcy5DbGFzcyA9PSBcInF3Y0VkaXRcIiB8fGRzLkNsYXNzID09IFwicXdjTGlzdFwiIHx8ZHMuQ2xhc3MgPT0gXCJxd2NMaXN0Vmlld1NpbmdsZVwiIHx8ZHMuQ2xhc3MgPT0gXCJxd2NMaXN0Vmlld011bHRpXCIgfHxkcy5DbGFzcyA9PSBcInF3Y01lbnVJdGVtXCIgfHxkcy5DbGFzcyA9PSBcInF3Y1RhYkNvbnRyb2xcIiApIHtcclxuZHMuQ2xhc3MgKz0gZHMuRXh0cmFzO1xyXG59XHJcbkFzc2VtYmx5IGFzc2VtYmx5ID0gQVBMLkdldEFzc2VtYmx5KFwiRGF0YUJpbmRpbmdcIix0aGlzKTtcclxuU3RyaW5nIGNsID0gQVBMLkdldENsYXNzQnlOYW1lKGRzLkluc3RhbmNlKTtcclxudmFyIG9iaiA9IEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGNsLCBkcy5JbnN0YW5jZSxudWxsKTtcclxuVHlwZSBjbGEgPSBhc3NlbWJseS5HZXRUeXBlKFwiRGF0YUJpbmRpbmdcIiArIFwiLlwiICsgZHMuQ2xhc3MpO1xyXG5NZXRob2RJbmZvIG1ldGhvZCA9IGNsYS5HZXRNZXRob2QoXCJDcmVhdGVDb250aW51ZTJcIik7XHJcbmlmIChtZXRob2QgIT0gbnVsbCkge1xyXG52YXIgYXJndW1lbnRzID0gbmV3IG9iamVjdFtdIHsgZHMgfTtcclxubWV0aG9kLkludm9rZSgoKE1KSF9Db21tb25EYXRhKSBvYmopLk1KSF9DbGFzcywgYXJndW1lbnRzKTtcclxufSBcclxuaWYgKDAhPWRzLkV4dHJhcy5MZW5ndGgpIHtcclxuZHMuTmFtZSA9IFwiU3R5bGVcIjtcclxuZHMuRGF0YSA9IGRzLkV4dHJhcztcclxuVHlwZSB0eXBlY2wgPSBhc3NlbWJseS5HZXRUeXBlKFwiRGF0YUJpbmRpbmdcIiArIFwiLlwiICsgY2wpO1xyXG5NZXRob2RJbmZvIG1ldGhvZDEgPSB0eXBlY2wuR2V0TWV0aG9kKFwiUnVuUHJvcGVydHlDaGFuZ2VkSW5cIik7XHJcbnZhciBhcmd1bWVudHMgPSBuZXcgb2JqZWN0W10geyBkcywgZmFsc2UgfTtcclxubWV0aG9kMS5JbnZva2Uob2JqLCBhcmd1bWVudHMpO1xyXG59IFxyXG54c3RyaW5nID0gbmV3IFRyYW5zZmVyU3RyaW5nKCk7XHJcbnhzdHJpbmcuVHJhbnMgPSB0cmFucztcclxuZD1URC5Gcm9tVHJhbnNmZXJTdHJpbmcoeHN0cmluZyk7XHJcbndlYlNvY2tldC5TZW5kKGQpO1xyXG5kaXJlY3R3ZWJTb2NrZXQuU2VuZChkKTtcclxufSBlbHNlIGlmIChkcy5BY3Rpb24gPT0gXCJFblF1ZXVlXCIpIHsgIC8vIHFOUVxyXG5TdHJpbmcgTlFyZXN1bHQ7XHJcbmRzLkNsYXNzID0gQVBMLkdldENsYXNzQnlOYW1lKGRzLkluc3RhbmNlKTtcclxuaWYgKG51bGwgIT0gZHMuQ2xhc3MpIHtcclxub2JqZWN0IG9iaiA9IEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgdGhpcyk7XHJcbnZhciBhcmd1bWVudHMgPSBuZXcgb2JqZWN0W10geyBkcywgdGhpcyB9O1xyXG5Bc3NlbWJseSBhc3NlbWJseSA9IEFQTC5HZXRBc3NlbWJseShcIlFXQ1wiLCB0aGlzKTtcclxuVHlwZSB0eXBlID0gYXNzZW1ibHkuR2V0VHlwZShcIlFXQ1wiICsgXCIuTlFcIik7XHJcbk1ldGhvZEluZm8gbWV0aG9kID0gdHlwZS5HZXRNZXRob2QoXCJEb1wiICsgZHMuTmFtZSk7XHJcbmlmIChVdGlscy5Jc1N0YXRpYyhtZXRob2QpKSB7XHJcbk5RcmVzdWx0ID0gKFN0cmluZyltZXRob2QuSW52b2tlKG51bGwsIGFyZ3VtZW50cyk7XHJcbn0gZWxzZSB7XHJcbk5RcmVzdWx0ID0gKFN0cmluZyltZXRob2QuSW52b2tlKG9iaiwgYXJndW1lbnRzKTtcclxufSBcclxufSBlbHNlIHtcclxuTlFyZXN1bHQ9XCJGYWxzZVwiO1xyXG59IFxyXG54c3RyaW5nID0gbmV3IFRyYW5zZmVyU3RyaW5nKCk7XHJcbnhzdHJpbmcuVHlwZSA9IFwiRW5RdWV1ZVwiO1xyXG54c3RyaW5nLkRhdGEgPSBOUXJlc3VsdDtcclxueHN0cmluZy5UcmFucyA9IHRyYW5zO1xyXG5kID0gVEQuRnJvbVRyYW5zZmVyU3RyaW5nKHhzdHJpbmcpO1xyXG5kaXJlY3R3ZWJTb2NrZXQuU2VuZChkKTsgICAvLyBQcm9jZXNzIHFOUSBcclxufSBlbHNlIFJ1bkRhdGFCaW5kaW5nKGRzKTtcclxufX07XHJcbndlYlNvY2tldC5PbkVycm9yKz0ocyxlKT0+X1dTSW50ZXJuYWxzLlN0YXR1cz1cIkVSUk9SIDogXCIgKyBlLkRhdGE7XHJcbndlYlNvY2tldC5PbkNsb3NlKz0ocyxlKT0+X1dTSW50ZXJuYWxzLlN0YXR1cz1cIldlYlNvY2tldCBDbG9zZWQgXCI7XHJcbndlYlNvY2tldC5Pbk9wZW4rPShzLGUpPT4ge1xyXG54c3RyaW5nID0gbmV3IFRyYW5zZmVyU3RyaW5nKCk7XHJcbnhzdHJpbmcuVHlwZSA9IFwiU2Vzc2lvblN0YXJ0XCI7XHJcbnhzdHJpbmcuRGF0YSA9IChzdHJpbmcpIEFwcGxpY2F0aW9uLkN1cnJlbnQuUmVzb3VyY2VzW1wiT3JpZ2luYWxVUkxcIl07XHJcbmQgPSBURC5Gcm9tVHJhbnNmZXJTdHJpbmcoeHN0cmluZyk7XHJcbndlYlNvY2tldC5TZW5kKGQpO1xyXG59O1xyXG5kaXJlY3R3ZWJTb2NrZXQuT25PcGVuICs9IGFzeW5jIChzLCBlKSA9PlxyXG57IFxyXG54c3RyaW5nID0gbmV3IFRyYW5zZmVyU3RyaW5nKCk7XHJcbmF3YWl0IFdlYlNvY2tldFJlYWR5O1xyXG54c3RyaW5nLkRhdGEgPSAoc3RyaW5nKSBBcHBsaWNhdGlvbi5DdXJyZW50LlJlc291cmNlc1tcIkluZGV4XCJdOyAgLy8gSW5kZXhcclxueHN0cmluZy5UeXBlID0gXCJJbmRleFwiO1xyXG5zdHJpbmcgZHggPSBURC5Gcm9tVHJhbnNmZXJTdHJpbmcoeHN0cmluZyk7XHJcbmRpcmVjdHdlYlNvY2tldC5TZW5kKGR4KTtcclxufTtcclxuZGlyZWN0d2ViU29ja2V0Lk9uTWVzc2FnZSArPSAocywgZSkgPT4ge1xyXG5UcmFuc2ZlclN0cmluZyBkcyA9IFRELlRvVHJhbnNmZXJTdHJpbmcoZS5EYXRhKTtcclxuc3RyaW5nIHRyYW5zID0gZHMuVHJhbnM7XHJcbmlmIChkcy5BY3Rpb24gPT0gXCJNSkhfQ2xvc2VTZXJ2ZXJcIikge1xyXG5kaXJlY3R3ZWJTb2NrZXQuU2VuZChlLkRhdGEpOyAgIC8vIFByb2Nlc3MgTUpIX0Nsb3NlU2VydmVyXHJcbn0gZWxzZSBpZiAoZHMuQWN0aW9uID09IFwiRW5RdWV1ZVwiKXsgIC8vIHFOUVxyXG5TdHJpbmcgTlFyZXN1bHQ7XHJcbmRzLkNsYXNzID0gQVBMLkdldENsYXNzQnlOYW1lKGRzLkluc3RhbmNlKTtcclxuaWYgKG51bGwgIT0gZHMuQ2xhc3MpIHtcclxub2JqZWN0IG9iaiA9IEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgdGhpcyk7XHJcbnZhciBhcmd1bWVudHMgPSBuZXcgb2JqZWN0W10geyBkcywgdGhpcyB9O1xyXG5Bc3NlbWJseSBhc3NlbWJseSA9IEFQTC5HZXRBc3NlbWJseShcIlFXQ1wiLCB0aGlzKTtcclxuVHlwZSB0eXBlID0gYXNzZW1ibHkuR2V0VHlwZShcIlFXQ1wiICsgXCIuTlFcIik7XHJcbk1ldGhvZEluZm8gbWV0aG9kID0gdHlwZS5HZXRNZXRob2QoXCJEb1wiICsgZHMuTmFtZSk7XHJcbmlmIChVdGlscy5Jc1N0YXRpYyhtZXRob2QpKSB7XHJcbk5RcmVzdWx0ID0gKFN0cmluZyltZXRob2QuSW52b2tlKG51bGwsIGFyZ3VtZW50cyk7XHJcbn0gZWxzZSB7XHJcbk5RcmVzdWx0ID0gKFN0cmluZyltZXRob2QuSW52b2tlKG9iaiwgYXJndW1lbnRzKTtcclxufSBcclxufSBlbHNlIHtcclxuTlFyZXN1bHQgPSBcIkZhbHNlXCI7XHJcbn0gXHJcbnhzdHJpbmcgPSBuZXcgVHJhbnNmZXJTdHJpbmcoKTtcclxueHN0cmluZy5UeXBlID0gXCJFblF1ZXVlXCI7XHJcbnhzdHJpbmcuRGF0YSA9IE5RcmVzdWx0O1xyXG54c3RyaW5nLlRyYW5zID0gdHJhbnM7XHJcbmQgPSBURC5Gcm9tVHJhbnNmZXJTdHJpbmcoeHN0cmluZyk7XHJcbmRpcmVjdHdlYlNvY2tldC5TZW5kKGQpOyAgIC8vIFByb2Nlc3MgcU5RXHJcbn0gZWxzZSBpZiAoZHMuQWN0aW9uID09IFwiUmV0dXJuRXZlbnRcIil7XHJcbkFQTC5SYWlzZUV2ZW50UmV0dXJuZWQoZS5EYXRhKTtcclxufSBcclxufTtcclxufSBcclxuYm9vbCBJc0VKMShzdHJpbmcgaW5wKSB7XHJcbnJldHVybiBmYWxzZTtcclxufSBcclxuYm9vbCBJc0VKMihzdHJpbmcgaW5wKSB7XHJcbmlmIChpbnAgPT0gXCJxd2NBcHBCYXJfRGF0YVwiKSByZXR1cm4gdHJ1ZTtcclxuaWYgKGlucCA9PSBcInF3Y0F2YXRhcl9EYXRhXCIpIHJldHVybiB0cnVlO1xyXG5pZiAoaW5wID09IFwicXdjQmFkZ2VfRGF0YVwiKSByZXR1cm4gdHJ1ZTtcclxuaWYgKGlucCA9PSBcInF3Y0JhckNvZGVfRGF0YVwiKSByZXR1cm4gdHJ1ZTtcclxuaWYgKGlucCA9PSBcInF3Y0JyZWFkQ3J1bWJfRGF0YVwiKSByZXR1cm4gdHJ1ZTtcclxuaWYgKGlucCA9PSBcInF3Y0NhbGVuZGFyX0RhdGFcIikgcmV0dXJuIHRydWU7XHJcbmlmIChpbnAgPT0gXCJxd2NDYXJkX0RhdGFcIikgcmV0dXJuIHRydWU7XHJcbmlmIChpbnAgPT0gXCJxd2NDYXJvdXNlbF9EYXRhXCIpIHJldHVybiB0cnVlO1xyXG5pZiAoaW5wID09IFwicXdjQ2hhcnRfRGF0YVwiKSByZXR1cm4gdHJ1ZTtcclxuaWYgKGlucCA9PSBcInF3Y0NoaXBzX0RhdGFcIikgcmV0dXJuIHRydWU7XHJcbmlmIChpbnAgPT0gXCJxd2NDaXJjdWxhckdhdWdlX0RhdGFcIikgcmV0dXJuIHRydWU7XHJcbmlmIChpbnAgPT0gXCJxd2NDb2xvdXJQaWNrZXJfRGF0YVwiKSByZXR1cm4gdHJ1ZTtcclxuaWYgKGlucCA9PSBcInF3Y0NvbG9yUGlja2VyX0RhdGFcIikgcmV0dXJuIHRydWU7XHJcbmlmIChpbnAgPT0gXCJxd2NDb21ib0Ryb3BfRGF0YVwiKSByZXR1cm4gdHJ1ZTtcclxuaWYgKGlucCA9PSBcInF3Y0NvbWJvRHJvcEVkaXRfRGF0YVwiKSByZXR1cm4gdHJ1ZTtcclxuaWYgKGlucCA9PSBcInF3Y0NvbWJvU2ltcGxlX0RhdGFcIikgcmV0dXJuIHRydWU7XHJcbmlmIChpbnAgPT0gXCJxd2NDb250ZXh0TWVudV9EYXRhXCIpIHJldHVybiB0cnVlO1xyXG5pZiAoaW5wID09IFwicXdjRGFzaEJvYXJkX0RhdGFcIikgcmV0dXJuIHRydWU7XHJcbmlmIChpbnAgPT0gXCJxd2NEYXRhR3JpZF9EYXRhXCIpIHJldHVybiB0cnVlO1xyXG5pZiAoaW5wID09IFwicXdjRGF0YU1hbmFnZXJfRGF0YVwiKSByZXR1cm4gdHJ1ZTtcclxuaWYgKGlucCA9PSBcInF3Y0RhdGVUaW1lUGlja2VyQ29tYm9fRGF0YVwiKSByZXR1cm4gdHJ1ZTtcclxuaWYgKGlucCA9PSBcInF3Y0RpYWdyYW1fRGF0YVwiKSByZXR1cm4gdHJ1ZTtcclxuaWYgKGlucCA9PSBcInF3Y01zZ0JveE1zZ19EYXRhXCIpIHJldHVybiB0cnVlO1xyXG5pZiAoaW5wID09IFwicXdjTXNnQm94SW5mb19EYXRhXCIpIHJldHVybiB0cnVlO1xyXG5pZiAoaW5wID09IFwicXdjTXNnQm94UXVlcnlfRGF0YVwiKSByZXR1cm4gdHJ1ZTtcclxuaWYgKGlucCA9PSBcInF3Y01zZ0JveFdhcm5fRGF0YVwiKSByZXR1cm4gdHJ1ZTtcclxuaWYgKGlucCA9PSBcInF3Y01zZ0JveEVycm9yX0RhdGFcIikgcmV0dXJuIHRydWU7XHJcbmlmIChpbnAgPT0gXCJxd2NEb2N1bWVudEVkaXRvcl9EYXRhXCIpIHJldHVybiB0cnVlO1xyXG5pZiAoaW5wID09IFwicXdjRmlsZU1hbmFnZXJfRGF0YVwiKSByZXR1cm4gdHJ1ZTtcclxuaWYgKGlucCA9PSBcInF3Y0dhbnR0X0RhdGFcIikgcmV0dXJuIHRydWU7XHJcbmlmIChpbnAgPT0gXCJxd2NHcmlkX0RhdGFcIikgcmV0dXJuIHRydWU7XHJcbmlmIChpbnAgPT0gXCJxd2NJbWFnZUVkaXRvcl9EYXRhXCIpIHJldHVybiB0cnVlO1xyXG5pZiAoaW5wID09IFwicXdjTGluZWFyR2F1Z2VfRGF0YVwiKSByZXR1cm4gdHJ1ZTtcclxuaWYgKGlucCA9PSBcInF3Y0ltYWdlX0RhdGFcIikgcmV0dXJuIHRydWU7XHJcbmlmIChpbnAgPT0gXCJxd2NLYW5iYW5fRGF0YVwiKSByZXR1cm4gdHJ1ZTtcclxuaWYgKGlucCA9PSBcInF3Y0xpc3RTaW5nbGVfRGF0YVwiKSByZXR1cm4gdHJ1ZTtcclxuaWYgKGlucCA9PSBcInF3Y0xpc3RNdWx0aV9EYXRhXCIpIHJldHVybiB0cnVlO1xyXG5pZiAoaW5wID09IFwicXdjTGlzdFZpZXdTaW5nbGVfRGF0YVwiKSByZXR1cm4gdHJ1ZTtcclxuaWYgKGlucCA9PSBcInF3Y0xpc3RWaWV3TXVsdGlfRGF0YVwiKSByZXR1cm4gdHJ1ZTtcclxuaWYgKGlucCA9PSBcInF3Y01hcHNfRGF0YVwiKSByZXR1cm4gdHJ1ZTtcclxuaWYgKGlucCA9PSBcInF3Y01lbnRpb25fRGF0YVwiKSByZXR1cm4gdHJ1ZTtcclxuaWYgKGlucCA9PSBcInF3Y01lbnVCYXJfRGF0YVwiKSByZXR1cm4gdHJ1ZTtcclxuaWYgKGlucCA9PSBcInF3Y01lc3NhZ2VfRGF0YVwiKSByZXR1cm4gdHJ1ZTtcclxuaWYgKGlucCA9PSBcInF3Y1BhZ2VyX0RhdGFcIikgcmV0dXJuIHRydWU7XHJcbmlmIChpbnAgPT0gXCJxd2NQREZWaWV3ZXJfRGF0YVwiKSByZXR1cm4gdHJ1ZTtcclxuaWYgKGlucCA9PSBcInF3Y1Bpdm90VGFibGVfRGF0YVwiKSByZXR1cm4gdHJ1ZTtcclxuaWYgKGlucCA9PSBcInF3Y1Byb2dyZXNzQmFyX0RhdGFcIikgcmV0dXJuIHRydWU7XHJcbmlmIChpbnAgPT0gXCJxd2NQcm9ncmVzc0J1dHRvbl9EYXRhXCIpIHJldHVybiB0cnVlO1xyXG5pZiAoaW5wID09IFwicXdjUXVlcnlCdWlsZGVyX0RhdGFcIikgcmV0dXJuIHRydWU7XHJcbmlmIChpbnAgPT0gXCJxd2NRUkNvZGVfRGF0YVwiKSByZXR1cm4gdHJ1ZTtcclxuaWYgKGlucCA9PSBcInF3Y1JhdGluZ19EYXRhXCIpIHJldHVybiB0cnVlO1xyXG5pZiAoaW5wID09IFwicXdjUmliYm9uX0RhdGFcIikgcmV0dXJuIHRydWU7XHJcbmlmIChpbnAgPT0gXCJxd2NSaWNoVGV4dEVkaXRvcl9EYXRhXCIpIHJldHVybiB0cnVlO1xyXG5pZiAoaW5wID09IFwicXdjU2NoZWR1bGVfRGF0YVwiKSByZXR1cm4gdHJ1ZTtcclxuaWYgKGlucCA9PSBcInF3Y1NpZGVCYXJfRGF0YVwiKSByZXR1cm4gdHJ1ZTtcclxuaWYgKGlucCA9PSBcInF3Y1NpZ25hdHVyZV9EYXRhXCIpIHJldHVybiB0cnVlO1xyXG5pZiAoaW5wID09IFwicXdjU2tlbGV0b25fRGF0YVwiKSByZXR1cm4gdHJ1ZTtcclxuaWYgKGlucCA9PSBcInF3Y1NwbGl0dGVyX0RhdGFcIikgcmV0dXJuIHRydWU7XHJcbmlmIChpbnAgPT0gXCJxd2NUYWJDb250cm9sX0RhdGFcIikgcmV0dXJuIHRydWU7XHJcbmlmIChpbnAgPT0gXCJxd2NUZXh0X0RhdGFcIikgcmV0dXJuIHRydWU7XHJcbmlmIChpbnAgPT0gXCJxd2NUcmVlVmlld19EYXRhXCIpIHJldHVybiB0cnVlO1xyXG5pZiAoaW5wID09IFwicXdjVXBsb2FkZXJfRGF0YVwiKSByZXR1cm4gdHJ1ZTtcclxucmV0dXJuIGZhbHNlO1xyXG59IFxyXG5wcml2YXRlIHZvaWQgQ3JlYXRlQ29udHJvbChUcmFuc2ZlclN0cmluZyBkcykge1xyXG5Bc3NlbWJseSBhc3NlbWJseSA9IEFQTC5HZXRBc3NlbWJseShcIkRhdGFCaW5kaW5nXCIsIHRoaXMpO1xyXG5UeXBlIHR5cGUgPSBhc3NlbWJseS5HZXRUeXBlKFwiRGF0YUJpbmRpbmdcIiArIFwiLlwiICsgZHMuQ2xhc3MpO1xyXG5zdHJpbmcgY2wgPSBkcy5DbGFzcyArIFwiX0RhdGFcIjtcclxuYm9vbCBpc0VKMSA9IElzRUoxKGNsKTtcclxuYm9vbCBpc0VKMiA9IElzRUoyKGNsKTtcclxudmFyIG9iID0gQWN0aXZhdG9yLkNyZWF0ZUluc3RhbmNlKHR5cGUsIGRzKTtcclxuTWV0aG9kSW5mbyBtZXRob2QgPSB0eXBlLkdldE1ldGhvZChcIkNyZWF0ZUNvbnRpbnVlMVwiKTtcclxudmFyIG9iaiA9IEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGNsLCBkcy5JbnN0YW5jZSwgbnVsbCk7XHJcbmlmIChtZXRob2QgIT0gbnVsbCkge1xyXG52YXIgYXJndW1lbnRzID0gbmV3IG9iamVjdFtdIHsgZHMgfTtcclxubWV0aG9kLkludm9rZSgoKE1KSF9Db21tb25EYXRhKW9iaikuTUpIX0NsYXNzLCBhcmd1bWVudHMpO1xyXG59IFxyXG5tZXRob2QgPSB0eXBlLkdldE1ldGhvZChcIkNyZWF0ZUNvbnRpbnVlMlwiKTtcclxuaWYgKG1ldGhvZCAhPSBudWxsKSB7XHJcbnZhciBhcmd1bWVudHMgPSBuZXcgb2JqZWN0W10geyBkcyB9O1xyXG5tZXRob2QuSW52b2tlKCgoTUpIX0NvbW1vbkRhdGEpb2JqKS5NSkhfQ2xhc3MsIGFyZ3VtZW50cyk7XHJcbn0gXHJcbmlmICgwICE9IGRzLkV4dHJhcy5MZW5ndGgpIHsgICAvLyBQcm9jZXNzIFN0eWxlIHByb3BlcnR5XHJcbmRzLk5hbWUgPSBcIlN0eWxlXCI7XHJcbmRzLkRhdGEgPSBkcy5FeHRyYXM7XHJcblR5cGUgdHlwZWNsID0gYXNzZW1ibHkuR2V0VHlwZShcIkRhdGFCaW5kaW5nXCIgKyBcIi5cIiArIGNsKTtcclxubWV0aG9kID0gdHlwZWNsLkdldE1ldGhvZChcIlJ1blByb3BlcnR5Q2hhbmdlZEluXCIpO1xyXG52YXIgYXJndW1lbnRzID0gbmV3IG9iamVjdFtdIHsgZHMsIGZhbHNlIH07XHJcbm1ldGhvZC5JbnZva2Uob2JqLCBhcmd1bWVudHMpO1xyXG59fVxyXG5wcml2YXRlIHZvaWQgUnVuRGF0YUJpbmRpbmcoVHJhbnNmZXJTdHJpbmcgZHMpIHtcclxuaWYoZHMuQ2xhc3MgPT0gXCJxd2NfUm9vdFwiKSB7XHJcbnF3Y19Sb290IGRib2JqMSA9IChxd2NfUm9vdCkgQVBMLkdldEluc3RhbmNlKFwiRGF0YUJpbmRpbmdcIiwgZHMuQ2xhc3MsIGRzLkluc3RhbmNlLCB0aGlzKTtcclxuaWYgKG51bGwgIT0gZGJvYmoxKSBkYm9iajEuUnVuUHJvcGVydHlDaGFuZ2VkSW4oZHMsZmFsc2UpO1xyXG59XHJcbiBcclxuZWxzZSBpZihkcy5DbGFzcyA9PSBcIk1KSF9EUV9EYXRhXCIpIHtcclxuTUpIX0RRX0RhdGEgZGJvYmoyID0gKE1KSF9EUV9EYXRhKSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBkcy5DbGFzcywgZHMuSW5zdGFuY2UsIHRoaXMpO1xyXG5pZiAobnVsbCAhPSBkYm9iajIpIGRib2JqMi5SdW5Qcm9wZXJ0eUNoYW5nZWRJbihkcyxmYWxzZSk7XHJcbn1cclxuIFxyXG5lbHNlIGlmKGRzLkNsYXNzID09IFwiTUpIX01pbkZvcm1fRGF0YVwiKSB7XHJcbk1KSF9NaW5Gb3JtX0RhdGEgZGJvYmozID0gKE1KSF9NaW5Gb3JtX0RhdGEpIEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgdGhpcyk7XHJcbmlmIChudWxsICE9IGRib2JqMykgZGJvYmozLlJ1blByb3BlcnR5Q2hhbmdlZEluKGRzLGZhbHNlKTtcclxufVxyXG4gXHJcbmVsc2UgaWYoZHMuQ2xhc3MgPT0gXCJxd2NBcHBCYXJfRGF0YVwiKSB7XHJcbnF3Y0FwcEJhcl9EYXRhIGRib2JqNCA9IChxd2NBcHBCYXJfRGF0YSkgQVBMLkdldEluc3RhbmNlKFwiRGF0YUJpbmRpbmdcIiwgZHMuQ2xhc3MsIGRzLkluc3RhbmNlLCB0aGlzKTtcclxuaWYgKG51bGwgIT0gZGJvYmo0KSBkYm9iajQuUnVuUHJvcGVydHlDaGFuZ2VkSW4oZHMsZmFsc2UpO1xyXG59XHJcbiBcclxuZWxzZSBpZihkcy5DbGFzcyA9PSBcInF3Y0F2YXRhcl9EYXRhXCIpIHtcclxucXdjQXZhdGFyX0RhdGEgZGJvYmo1ID0gKHF3Y0F2YXRhcl9EYXRhKSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBkcy5DbGFzcywgZHMuSW5zdGFuY2UsIHRoaXMpO1xyXG5pZiAobnVsbCAhPSBkYm9iajUpIGRib2JqNS5SdW5Qcm9wZXJ0eUNoYW5nZWRJbihkcyxmYWxzZSk7XHJcbn1cclxuIFxyXG5lbHNlIGlmKGRzLkNsYXNzID09IFwicXdjQmFkZ2VfRGF0YVwiKSB7XHJcbnF3Y0JhZGdlX0RhdGEgZGJvYmo2ID0gKHF3Y0JhZGdlX0RhdGEpIEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgdGhpcyk7XHJcbmlmIChudWxsICE9IGRib2JqNikgZGJvYmo2LlJ1blByb3BlcnR5Q2hhbmdlZEluKGRzLGZhbHNlKTtcclxufVxyXG4gXHJcbmVsc2UgaWYoZHMuQ2xhc3MgPT0gXCJxd2NCYXJDb2RlX0RhdGFcIikge1xyXG5xd2NCYXJDb2RlX0RhdGEgZGJvYmo3ID0gKHF3Y0JhckNvZGVfRGF0YSkgQVBMLkdldEluc3RhbmNlKFwiRGF0YUJpbmRpbmdcIiwgZHMuQ2xhc3MsIGRzLkluc3RhbmNlLCB0aGlzKTtcclxuaWYgKG51bGwgIT0gZGJvYmo3KSBkYm9iajcuUnVuUHJvcGVydHlDaGFuZ2VkSW4oZHMsZmFsc2UpO1xyXG59XHJcbiBcclxuZWxzZSBpZihkcy5DbGFzcyA9PSBcInF3Y0JyZWFkQ3J1bWJfRGF0YVwiKSB7XHJcbnF3Y0JyZWFkQ3J1bWJfRGF0YSBkYm9iajggPSAocXdjQnJlYWRDcnVtYl9EYXRhKSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBkcy5DbGFzcywgZHMuSW5zdGFuY2UsIHRoaXMpO1xyXG5pZiAobnVsbCAhPSBkYm9iajgpIGRib2JqOC5SdW5Qcm9wZXJ0eUNoYW5nZWRJbihkcyxmYWxzZSk7XHJcbn1cclxuIFxyXG5lbHNlIGlmKGRzLkNsYXNzID09IFwicXdjQnJpZGdlU2NvcmVfRGF0YVwiKSB7XHJcbnF3Y0JyaWRnZVNjb3JlX0RhdGEgZGJvYmo5ID0gKHF3Y0JyaWRnZVNjb3JlX0RhdGEpIEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgdGhpcyk7XHJcbmlmIChudWxsICE9IGRib2JqOSkgZGJvYmo5LlJ1blByb3BlcnR5Q2hhbmdlZEluKGRzLGZhbHNlKTtcclxufVxyXG4gXHJcbmVsc2UgaWYoZHMuQ2xhc3MgPT0gXCJxd2NCdXR0b25DaGVja19EYXRhXCIpIHtcclxucXdjQnV0dG9uQ2hlY2tfRGF0YSBkYm9iajEwID0gKHF3Y0J1dHRvbkNoZWNrX0RhdGEpIEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgdGhpcyk7XHJcbmlmIChudWxsICE9IGRib2JqMTApIGRib2JqMTAuUnVuUHJvcGVydHlDaGFuZ2VkSW4oZHMsZmFsc2UpO1xyXG59XHJcbiBcclxuZWxzZSBpZihkcy5DbGFzcyA9PSBcInF3Y0J1dHRvbkNvbW1hbmRMaW5rX0RhdGFcIikge1xyXG5xd2NCdXR0b25Db21tYW5kTGlua19EYXRhIGRib2JqMTEgPSAocXdjQnV0dG9uQ29tbWFuZExpbmtfRGF0YSkgQVBMLkdldEluc3RhbmNlKFwiRGF0YUJpbmRpbmdcIiwgZHMuQ2xhc3MsIGRzLkluc3RhbmNlLCB0aGlzKTtcclxuaWYgKG51bGwgIT0gZGJvYmoxMSkgZGJvYmoxMS5SdW5Qcm9wZXJ0eUNoYW5nZWRJbihkcyxmYWxzZSk7XHJcbn1cclxuIFxyXG5lbHNlIGlmKGRzLkNsYXNzID09IFwicXdjQnV0dG9uUHVzaF9EYXRhXCIpIHtcclxucXdjQnV0dG9uUHVzaF9EYXRhIGRib2JqMTIgPSAocXdjQnV0dG9uUHVzaF9EYXRhKSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBkcy5DbGFzcywgZHMuSW5zdGFuY2UsIHRoaXMpO1xyXG5pZiAobnVsbCAhPSBkYm9iajEyKSBkYm9iajEyLlJ1blByb3BlcnR5Q2hhbmdlZEluKGRzLGZhbHNlKTtcclxufVxyXG4gXHJcbmVsc2UgaWYoZHMuQ2xhc3MgPT0gXCJxd2NCdXR0b25SYWRpb19EYXRhXCIpIHtcclxucXdjQnV0dG9uUmFkaW9fRGF0YSBkYm9iajEzID0gKHF3Y0J1dHRvblJhZGlvX0RhdGEpIEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgdGhpcyk7XHJcbmlmIChudWxsICE9IGRib2JqMTMpIGRib2JqMTMuUnVuUHJvcGVydHlDaGFuZ2VkSW4oZHMsZmFsc2UpO1xyXG59XHJcbiBcclxuZWxzZSBpZihkcy5DbGFzcyA9PSBcInF3Y0J1dHRvblNwbGl0X0RhdGFcIikge1xyXG5xd2NCdXR0b25TcGxpdF9EYXRhIGRib2JqMTQgPSAocXdjQnV0dG9uU3BsaXRfRGF0YSkgQVBMLkdldEluc3RhbmNlKFwiRGF0YUJpbmRpbmdcIiwgZHMuQ2xhc3MsIGRzLkluc3RhbmNlLCB0aGlzKTtcclxuaWYgKG51bGwgIT0gZGJvYmoxNCkgZGJvYmoxNC5SdW5Qcm9wZXJ0eUNoYW5nZWRJbihkcyxmYWxzZSk7XHJcbn1cclxuIFxyXG5lbHNlIGlmKGRzLkNsYXNzID09IFwicXdjQnV0dG9uVG9nZ2xlX0RhdGFcIikge1xyXG5xd2NCdXR0b25Ub2dnbGVfRGF0YSBkYm9iajE1ID0gKHF3Y0J1dHRvblRvZ2dsZV9EYXRhKSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBkcy5DbGFzcywgZHMuSW5zdGFuY2UsIHRoaXMpO1xyXG5pZiAobnVsbCAhPSBkYm9iajE1KSBkYm9iajE1LlJ1blByb3BlcnR5Q2hhbmdlZEluKGRzLGZhbHNlKTtcclxufVxyXG4gXHJcbmVsc2UgaWYoZHMuQ2xhc3MgPT0gXCJxd2NDYWxlbmRhcl9EYXRhXCIpIHtcclxucXdjQ2FsZW5kYXJfRGF0YSBkYm9iajE2ID0gKHF3Y0NhbGVuZGFyX0RhdGEpIEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgdGhpcyk7XHJcbmlmIChudWxsICE9IGRib2JqMTYpIGRib2JqMTYuUnVuUHJvcGVydHlDaGFuZ2VkSW4oZHMsZmFsc2UpO1xyXG59XHJcbiBcclxuZWxzZSBpZihkcy5DbGFzcyA9PSBcInF3Y0NhcmRfRGF0YVwiKSB7XHJcbnF3Y0NhcmRfRGF0YSBkYm9iajE3ID0gKHF3Y0NhcmRfRGF0YSkgQVBMLkdldEluc3RhbmNlKFwiRGF0YUJpbmRpbmdcIiwgZHMuQ2xhc3MsIGRzLkluc3RhbmNlLCB0aGlzKTtcclxuaWYgKG51bGwgIT0gZGJvYmoxNykgZGJvYmoxNy5SdW5Qcm9wZXJ0eUNoYW5nZWRJbihkcyxmYWxzZSk7XHJcbn1cclxuIFxyXG5lbHNlIGlmKGRzLkNsYXNzID09IFwicXdjQ2Fyb3VzZWxfRGF0YVwiKSB7XHJcbnF3Y0Nhcm91c2VsX0RhdGEgZGJvYmoxOCA9IChxd2NDYXJvdXNlbF9EYXRhKSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBkcy5DbGFzcywgZHMuSW5zdGFuY2UsIHRoaXMpO1xyXG5pZiAobnVsbCAhPSBkYm9iajE4KSBkYm9iajE4LlJ1blByb3BlcnR5Q2hhbmdlZEluKGRzLGZhbHNlKTtcclxufVxyXG4gXHJcbmVsc2UgaWYoZHMuQ2xhc3MgPT0gXCJxd2NDaGFydF9EYXRhXCIpIHtcclxucXdjQ2hhcnRfRGF0YSBkYm9iajE5ID0gKHF3Y0NoYXJ0X0RhdGEpIEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgdGhpcyk7XHJcbmlmIChudWxsICE9IGRib2JqMTkpIGRib2JqMTkuUnVuUHJvcGVydHlDaGFuZ2VkSW4oZHMsZmFsc2UpO1xyXG59XHJcbiBcclxuZWxzZSBpZihkcy5DbGFzcyA9PSBcInF3Y0NoaXBzX0RhdGFcIikge1xyXG5xd2NDaGlwc19EYXRhIGRib2JqMjAgPSAocXdjQ2hpcHNfRGF0YSkgQVBMLkdldEluc3RhbmNlKFwiRGF0YUJpbmRpbmdcIiwgZHMuQ2xhc3MsIGRzLkluc3RhbmNlLCB0aGlzKTtcclxuaWYgKG51bGwgIT0gZGJvYmoyMCkgZGJvYmoyMC5SdW5Qcm9wZXJ0eUNoYW5nZWRJbihkcyxmYWxzZSk7XHJcbn1cclxuIFxyXG5lbHNlIGlmKGRzLkNsYXNzID09IFwicXdjQ2lyY3VsYXJHYXVnZV9EYXRhXCIpIHtcclxucXdjQ2lyY3VsYXJHYXVnZV9EYXRhIGRib2JqMjEgPSAocXdjQ2lyY3VsYXJHYXVnZV9EYXRhKSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBkcy5DbGFzcywgZHMuSW5zdGFuY2UsIHRoaXMpO1xyXG5pZiAobnVsbCAhPSBkYm9iajIxKSBkYm9iajIxLlJ1blByb3BlcnR5Q2hhbmdlZEluKGRzLGZhbHNlKTtcclxufVxyXG4gXHJcbmVsc2UgaWYoZHMuQ2xhc3MgPT0gXCJxd2NDb2xvdXJQaWNrZXJfRGF0YVwiKSB7XHJcbnF3Y0NvbG91clBpY2tlcl9EYXRhIGRib2JqMjIgPSAocXdjQ29sb3VyUGlja2VyX0RhdGEpIEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgdGhpcyk7XHJcbmlmIChudWxsICE9IGRib2JqMjIpIGRib2JqMjIuUnVuUHJvcGVydHlDaGFuZ2VkSW4oZHMsZmFsc2UpO1xyXG59XHJcbiBcclxuZWxzZSBpZihkcy5DbGFzcyA9PSBcInF3Y0NvbG9yUGlja2VyX0RhdGFcIikge1xyXG5xd2NDb2xvclBpY2tlcl9EYXRhIGRib2JqMjMgPSAocXdjQ29sb3JQaWNrZXJfRGF0YSkgQVBMLkdldEluc3RhbmNlKFwiRGF0YUJpbmRpbmdcIiwgZHMuQ2xhc3MsIGRzLkluc3RhbmNlLCB0aGlzKTtcclxuaWYgKG51bGwgIT0gZGJvYmoyMykgZGJvYmoyMy5SdW5Qcm9wZXJ0eUNoYW5nZWRJbihkcyxmYWxzZSk7XHJcbn1cclxuIFxyXG5lbHNlIGlmKGRzLkNsYXNzID09IFwicXdjQ29tYm9Ecm9wX0RhdGFcIikge1xyXG5xd2NDb21ib0Ryb3BfRGF0YSBkYm9iajI0ID0gKHF3Y0NvbWJvRHJvcF9EYXRhKSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBkcy5DbGFzcywgZHMuSW5zdGFuY2UsIHRoaXMpO1xyXG5pZiAobnVsbCAhPSBkYm9iajI0KSBkYm9iajI0LlJ1blByb3BlcnR5Q2hhbmdlZEluKGRzLGZhbHNlKTtcclxufVxyXG4gXHJcbmVsc2UgaWYoZHMuQ2xhc3MgPT0gXCJxd2NDb21ib0Ryb3BFZGl0X0RhdGFcIikge1xyXG5xd2NDb21ib0Ryb3BFZGl0X0RhdGEgZGJvYmoyNSA9IChxd2NDb21ib0Ryb3BFZGl0X0RhdGEpIEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgdGhpcyk7XHJcbmlmIChudWxsICE9IGRib2JqMjUpIGRib2JqMjUuUnVuUHJvcGVydHlDaGFuZ2VkSW4oZHMsZmFsc2UpO1xyXG59XHJcbiBcclxuZWxzZSBpZihkcy5DbGFzcyA9PSBcInF3Y0NvbWJvU2ltcGxlX0RhdGFcIikge1xyXG5xd2NDb21ib1NpbXBsZV9EYXRhIGRib2JqMjYgPSAocXdjQ29tYm9TaW1wbGVfRGF0YSkgQVBMLkdldEluc3RhbmNlKFwiRGF0YUJpbmRpbmdcIiwgZHMuQ2xhc3MsIGRzLkluc3RhbmNlLCB0aGlzKTtcclxuaWYgKG51bGwgIT0gZGJvYmoyNikgZGJvYmoyNi5SdW5Qcm9wZXJ0eUNoYW5nZWRJbihkcyxmYWxzZSk7XHJcbn1cclxuIFxyXG5lbHNlIGlmKGRzLkNsYXNzID09IFwicXdjQ29udGV4dE1lbnVfRGF0YVwiKSB7XHJcbnF3Y0NvbnRleHRNZW51X0RhdGEgZGJvYmoyNyA9IChxd2NDb250ZXh0TWVudV9EYXRhKSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBkcy5DbGFzcywgZHMuSW5zdGFuY2UsIHRoaXMpO1xyXG5pZiAobnVsbCAhPSBkYm9iajI3KSBkYm9iajI3LlJ1blByb3BlcnR5Q2hhbmdlZEluKGRzLGZhbHNlKTtcclxufVxyXG4gXHJcbmVsc2UgaWYoZHMuQ2xhc3MgPT0gXCJxd2NEYXNoQm9hcmRfRGF0YVwiKSB7XHJcbnF3Y0Rhc2hCb2FyZF9EYXRhIGRib2JqMjggPSAocXdjRGFzaEJvYXJkX0RhdGEpIEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgdGhpcyk7XHJcbmlmIChudWxsICE9IGRib2JqMjgpIGRib2JqMjguUnVuUHJvcGVydHlDaGFuZ2VkSW4oZHMsZmFsc2UpO1xyXG59XHJcbiBcclxuZWxzZSBpZihkcy5DbGFzcyA9PSBcInF3Y0RhdGFHcmlkX0RhdGFcIikge1xyXG5xd2NEYXRhR3JpZF9EYXRhIGRib2JqMjkgPSAocXdjRGF0YUdyaWRfRGF0YSkgQVBMLkdldEluc3RhbmNlKFwiRGF0YUJpbmRpbmdcIiwgZHMuQ2xhc3MsIGRzLkluc3RhbmNlLCB0aGlzKTtcclxuaWYgKG51bGwgIT0gZGJvYmoyOSkgZGJvYmoyOS5SdW5Qcm9wZXJ0eUNoYW5nZWRJbihkcyxmYWxzZSk7XHJcbn1cclxuIFxyXG5lbHNlIGlmKGRzLkNsYXNzID09IFwicXdjRGF0YU1hbmFnZXJfRGF0YVwiKSB7XHJcbnF3Y0RhdGFNYW5hZ2VyX0RhdGEgZGJvYmozMCA9IChxd2NEYXRhTWFuYWdlcl9EYXRhKSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBkcy5DbGFzcywgZHMuSW5zdGFuY2UsIHRoaXMpO1xyXG5pZiAobnVsbCAhPSBkYm9iajMwKSBkYm9iajMwLlJ1blByb3BlcnR5Q2hhbmdlZEluKGRzLGZhbHNlKTtcclxufVxyXG4gXHJcbmVsc2UgaWYoZHMuQ2xhc3MgPT0gXCJxd2NEYXRlUGlja2VyX0RhdGFcIikge1xyXG5xd2NEYXRlUGlja2VyX0RhdGEgZGJvYmozMSA9IChxd2NEYXRlUGlja2VyX0RhdGEpIEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgdGhpcyk7XHJcbmlmIChudWxsICE9IGRib2JqMzEpIGRib2JqMzEuUnVuUHJvcGVydHlDaGFuZ2VkSW4oZHMsZmFsc2UpO1xyXG59XHJcbiBcclxuZWxzZSBpZihkcy5DbGFzcyA9PSBcInF3Y0RhdGVUaW1lUGlja2VyQ29tYm9fRGF0YVwiKSB7XHJcbnF3Y0RhdGVUaW1lUGlja2VyQ29tYm9fRGF0YSBkYm9iajMyID0gKHF3Y0RhdGVUaW1lUGlja2VyQ29tYm9fRGF0YSkgQVBMLkdldEluc3RhbmNlKFwiRGF0YUJpbmRpbmdcIiwgZHMuQ2xhc3MsIGRzLkluc3RhbmNlLCB0aGlzKTtcclxuaWYgKG51bGwgIT0gZGJvYmozMikgZGJvYmozMi5SdW5Qcm9wZXJ0eUNoYW5nZWRJbihkcyxmYWxzZSk7XHJcbn1cclxuIFxyXG5lbHNlIGlmKGRzLkNsYXNzID09IFwicXdjRGlhZ3JhbV9EYXRhXCIpIHtcclxucXdjRGlhZ3JhbV9EYXRhIGRib2JqMzMgPSAocXdjRGlhZ3JhbV9EYXRhKSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBkcy5DbGFzcywgZHMuSW5zdGFuY2UsIHRoaXMpO1xyXG5pZiAobnVsbCAhPSBkYm9iajMzKSBkYm9iajMzLlJ1blByb3BlcnR5Q2hhbmdlZEluKGRzLGZhbHNlKTtcclxufVxyXG4gXHJcbmVsc2UgaWYoZHMuQ2xhc3MgPT0gXCJxd2NNc2dCb3hNc2dfRGF0YVwiKSB7XHJcbnF3Y01zZ0JveE1zZ19EYXRhIGRib2JqMzQgPSAocXdjTXNnQm94TXNnX0RhdGEpIEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgdGhpcyk7XHJcbmlmIChudWxsICE9IGRib2JqMzQpIGRib2JqMzQuUnVuUHJvcGVydHlDaGFuZ2VkSW4oZHMsZmFsc2UpO1xyXG59XHJcbiBcclxuZWxzZSBpZihkcy5DbGFzcyA9PSBcInF3Y01zZ0JveEluZm9fRGF0YVwiKSB7XHJcbnF3Y01zZ0JveEluZm9fRGF0YSBkYm9iajM1ID0gKHF3Y01zZ0JveEluZm9fRGF0YSkgQVBMLkdldEluc3RhbmNlKFwiRGF0YUJpbmRpbmdcIiwgZHMuQ2xhc3MsIGRzLkluc3RhbmNlLCB0aGlzKTtcclxuaWYgKG51bGwgIT0gZGJvYmozNSkgZGJvYmozNS5SdW5Qcm9wZXJ0eUNoYW5nZWRJbihkcyxmYWxzZSk7XHJcbn1cclxuIFxyXG5lbHNlIGlmKGRzLkNsYXNzID09IFwicXdjTXNnQm94UXVlcnlfRGF0YVwiKSB7XHJcbnF3Y01zZ0JveFF1ZXJ5X0RhdGEgZGJvYmozNiA9IChxd2NNc2dCb3hRdWVyeV9EYXRhKSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBkcy5DbGFzcywgZHMuSW5zdGFuY2UsIHRoaXMpO1xyXG5pZiAobnVsbCAhPSBkYm9iajM2KSBkYm9iajM2LlJ1blByb3BlcnR5Q2hhbmdlZEluKGRzLGZhbHNlKTtcclxufVxyXG4gXHJcbmVsc2UgaWYoZHMuQ2xhc3MgPT0gXCJxd2NNc2dCb3hXYXJuX0RhdGFcIikge1xyXG5xd2NNc2dCb3hXYXJuX0RhdGEgZGJvYmozNyA9IChxd2NNc2dCb3hXYXJuX0RhdGEpIEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgdGhpcyk7XHJcbmlmIChudWxsICE9IGRib2JqMzcpIGRib2JqMzcuUnVuUHJvcGVydHlDaGFuZ2VkSW4oZHMsZmFsc2UpO1xyXG59XHJcbiBcclxuZWxzZSBpZihkcy5DbGFzcyA9PSBcInF3Y01zZ0JveEVycm9yX0RhdGFcIikge1xyXG5xd2NNc2dCb3hFcnJvcl9EYXRhIGRib2JqMzggPSAocXdjTXNnQm94RXJyb3JfRGF0YSkgQVBMLkdldEluc3RhbmNlKFwiRGF0YUJpbmRpbmdcIiwgZHMuQ2xhc3MsIGRzLkluc3RhbmNlLCB0aGlzKTtcclxuaWYgKG51bGwgIT0gZGJvYmozOCkgZGJvYmozOC5SdW5Qcm9wZXJ0eUNoYW5nZWRJbihkcyxmYWxzZSk7XHJcbn1cclxuIFxyXG5lbHNlIGlmKGRzLkNsYXNzID09IFwicXdjRG9jdW1lbnRFZGl0b3JfRGF0YVwiKSB7XHJcbnF3Y0RvY3VtZW50RWRpdG9yX0RhdGEgZGJvYmozOSA9IChxd2NEb2N1bWVudEVkaXRvcl9EYXRhKSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBkcy5DbGFzcywgZHMuSW5zdGFuY2UsIHRoaXMpO1xyXG5pZiAobnVsbCAhPSBkYm9iajM5KSBkYm9iajM5LlJ1blByb3BlcnR5Q2hhbmdlZEluKGRzLGZhbHNlKTtcclxufVxyXG4gXHJcbmVsc2UgaWYoZHMuQ2xhc3MgPT0gXCJxd2NFZGl0U2luZ2xlX0RhdGFcIikge1xyXG5xd2NFZGl0U2luZ2xlX0RhdGEgZGJvYmo0MCA9IChxd2NFZGl0U2luZ2xlX0RhdGEpIEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgdGhpcyk7XHJcbmlmIChudWxsICE9IGRib2JqNDApIGRib2JqNDAuUnVuUHJvcGVydHlDaGFuZ2VkSW4oZHMsZmFsc2UpO1xyXG59XHJcbiBcclxuZWxzZSBpZihkcy5DbGFzcyA9PSBcInF3Y0VkaXRNdWx0aV9EYXRhXCIpIHtcclxucXdjRWRpdE11bHRpX0RhdGEgZGJvYmo0MSA9IChxd2NFZGl0TXVsdGlfRGF0YSkgQVBMLkdldEluc3RhbmNlKFwiRGF0YUJpbmRpbmdcIiwgZHMuQ2xhc3MsIGRzLkluc3RhbmNlLCB0aGlzKTtcclxuaWYgKG51bGwgIT0gZGJvYmo0MSkgZGJvYmo0MS5SdW5Qcm9wZXJ0eUNoYW5nZWRJbihkcyxmYWxzZSk7XHJcbn1cclxuIFxyXG5lbHNlIGlmKGRzLkNsYXNzID09IFwicXdjRXhwYW5kZXJfRGF0YVwiKSB7XHJcbnF3Y0V4cGFuZGVyX0RhdGEgZGJvYmo0MiA9IChxd2NFeHBhbmRlcl9EYXRhKSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBkcy5DbGFzcywgZHMuSW5zdGFuY2UsIHRoaXMpO1xyXG5pZiAobnVsbCAhPSBkYm9iajQyKSBkYm9iajQyLlJ1blByb3BlcnR5Q2hhbmdlZEluKGRzLGZhbHNlKTtcclxufVxyXG4gXHJcbmVsc2UgaWYoZHMuQ2xhc3MgPT0gXCJxd2NGaWxlTWFuYWdlcl9EYXRhXCIpIHtcclxucXdjRmlsZU1hbmFnZXJfRGF0YSBkYm9iajQzID0gKHF3Y0ZpbGVNYW5hZ2VyX0RhdGEpIEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgdGhpcyk7XHJcbmlmIChudWxsICE9IGRib2JqNDMpIGRib2JqNDMuUnVuUHJvcGVydHlDaGFuZ2VkSW4oZHMsZmFsc2UpO1xyXG59XHJcbiBcclxuZWxzZSBpZihkcy5DbGFzcyA9PSBcInF3Y0ZvbnRfRGF0YVwiKSB7XHJcbnF3Y0ZvbnRfRGF0YSBkYm9iajQ0ID0gKHF3Y0ZvbnRfRGF0YSkgQVBMLkdldEluc3RhbmNlKFwiRGF0YUJpbmRpbmdcIiwgZHMuQ2xhc3MsIGRzLkluc3RhbmNlLCB0aGlzKTtcclxuaWYgKG51bGwgIT0gZGJvYmo0NCkgZGJvYmo0NC5SdW5Qcm9wZXJ0eUNoYW5nZWRJbihkcyxmYWxzZSk7XHJcbn1cclxuIFxyXG5lbHNlIGlmKGRzLkNsYXNzID09IFwicXdjRm9ybV9EYXRhXCIpIHtcclxucXdjRm9ybV9EYXRhIGRib2JqNDUgPSAocXdjRm9ybV9EYXRhKSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBkcy5DbGFzcywgZHMuSW5zdGFuY2UsIHRoaXMpO1xyXG5pZiAobnVsbCAhPSBkYm9iajQ1KSBkYm9iajQ1LlJ1blByb3BlcnR5Q2hhbmdlZEluKGRzLGZhbHNlKTtcclxufVxyXG4gXHJcbmVsc2UgaWYoZHMuQ2xhc3MgPT0gXCJxd2NHYW50dF9EYXRhXCIpIHtcclxucXdjR2FudHRfRGF0YSBkYm9iajQ2ID0gKHF3Y0dhbnR0X0RhdGEpIEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgdGhpcyk7XHJcbmlmIChudWxsICE9IGRib2JqNDYpIGRib2JqNDYuUnVuUHJvcGVydHlDaGFuZ2VkSW4oZHMsZmFsc2UpO1xyXG59XHJcbiBcclxuZWxzZSBpZihkcy5DbGFzcyA9PSBcInF3Y0dyaWRfRGF0YVwiKSB7XHJcbnF3Y0dyaWRfRGF0YSBkYm9iajQ3ID0gKHF3Y0dyaWRfRGF0YSkgQVBMLkdldEluc3RhbmNlKFwiRGF0YUJpbmRpbmdcIiwgZHMuQ2xhc3MsIGRzLkluc3RhbmNlLCB0aGlzKTtcclxuaWYgKG51bGwgIT0gZGJvYmo0NykgZGJvYmo0Ny5SdW5Qcm9wZXJ0eUNoYW5nZWRJbihkcyxmYWxzZSk7XHJcbn1cclxuIFxyXG5lbHNlIGlmKGRzLkNsYXNzID09IFwicXdjR3JvdXBfRGF0YVwiKSB7XHJcbnF3Y0dyb3VwX0RhdGEgZGJvYmo0OCA9IChxd2NHcm91cF9EYXRhKSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBkcy5DbGFzcywgZHMuSW5zdGFuY2UsIHRoaXMpO1xyXG5pZiAobnVsbCAhPSBkYm9iajQ4KSBkYm9iajQ4LlJ1blByb3BlcnR5Q2hhbmdlZEluKGRzLGZhbHNlKTtcclxufVxyXG4gXHJcbmVsc2UgaWYoZHMuQ2xhc3MgPT0gXCJxd2NJbWFnZUVkaXRvcl9EYXRhXCIpIHtcclxucXdjSW1hZ2VFZGl0b3JfRGF0YSBkYm9iajQ5ID0gKHF3Y0ltYWdlRWRpdG9yX0RhdGEpIEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgdGhpcyk7XHJcbmlmIChudWxsICE9IGRib2JqNDkpIGRib2JqNDkuUnVuUHJvcGVydHlDaGFuZ2VkSW4oZHMsZmFsc2UpO1xyXG59XHJcbiBcclxuZWxzZSBpZihkcy5DbGFzcyA9PSBcInF3Y0thbmJhbl9EYXRhXCIpIHtcclxucXdjS2FuYmFuX0RhdGEgZGJvYmo1MCA9IChxd2NLYW5iYW5fRGF0YSkgQVBMLkdldEluc3RhbmNlKFwiRGF0YUJpbmRpbmdcIiwgZHMuQ2xhc3MsIGRzLkluc3RhbmNlLCB0aGlzKTtcclxuaWYgKG51bGwgIT0gZGJvYmo1MCkgZGJvYmo1MC5SdW5Qcm9wZXJ0eUNoYW5nZWRJbihkcyxmYWxzZSk7XHJcbn1cclxuIFxyXG5lbHNlIGlmKGRzLkNsYXNzID09IFwicXdjTGFiZWxfRGF0YVwiKSB7XHJcbnF3Y0xhYmVsX0RhdGEgZGJvYmo1MSA9IChxd2NMYWJlbF9EYXRhKSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBkcy5DbGFzcywgZHMuSW5zdGFuY2UsIHRoaXMpO1xyXG5pZiAobnVsbCAhPSBkYm9iajUxKSBkYm9iajUxLlJ1blByb3BlcnR5Q2hhbmdlZEluKGRzLGZhbHNlKTtcclxufVxyXG4gXHJcbmVsc2UgaWYoZHMuQ2xhc3MgPT0gXCJxd2NMaW5lYXJHYXVnZV9EYXRhXCIpIHtcclxucXdjTGluZWFyR2F1Z2VfRGF0YSBkYm9iajUyID0gKHF3Y0xpbmVhckdhdWdlX0RhdGEpIEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgdGhpcyk7XHJcbmlmIChudWxsICE9IGRib2JqNTIpIGRib2JqNTIuUnVuUHJvcGVydHlDaGFuZ2VkSW4oZHMsZmFsc2UpO1xyXG59XHJcbiBcclxuZWxzZSBpZihkcy5DbGFzcyA9PSBcInF3Y0ltYWdlX0RhdGFcIikge1xyXG5xd2NJbWFnZV9EYXRhIGRib2JqNTMgPSAocXdjSW1hZ2VfRGF0YSkgQVBMLkdldEluc3RhbmNlKFwiRGF0YUJpbmRpbmdcIiwgZHMuQ2xhc3MsIGRzLkluc3RhbmNlLCB0aGlzKTtcclxuaWYgKG51bGwgIT0gZGJvYmo1MykgZGJvYmo1My5SdW5Qcm9wZXJ0eUNoYW5nZWRJbihkcyxmYWxzZSk7XHJcbn1cclxuIFxyXG5lbHNlIGlmKGRzLkNsYXNzID09IFwicXdjSW1hZ2VMaXN0X0RhdGFcIikge1xyXG5xd2NJbWFnZUxpc3RfRGF0YSBkYm9iajU0ID0gKHF3Y0ltYWdlTGlzdF9EYXRhKSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBkcy5DbGFzcywgZHMuSW5zdGFuY2UsIHRoaXMpO1xyXG5pZiAobnVsbCAhPSBkYm9iajU0KSBkYm9iajU0LlJ1blByb3BlcnR5Q2hhbmdlZEluKGRzLGZhbHNlKTtcclxufVxyXG4gXHJcbmVsc2UgaWYoZHMuQ2xhc3MgPT0gXCJxd2NLYW5iYW5fRGF0YVwiKSB7XHJcbnF3Y0thbmJhbl9EYXRhIGRib2JqNTUgPSAocXdjS2FuYmFuX0RhdGEpIEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgdGhpcyk7XHJcbmlmIChudWxsICE9IGRib2JqNTUpIGRib2JqNTUuUnVuUHJvcGVydHlDaGFuZ2VkSW4oZHMsZmFsc2UpO1xyXG59XHJcbiBcclxuZWxzZSBpZihkcy5DbGFzcyA9PSBcInF3Y0xpc3RTaW5nbGVfRGF0YVwiKSB7XHJcbnF3Y0xpc3RTaW5nbGVfRGF0YSBkYm9iajU2ID0gKHF3Y0xpc3RTaW5nbGVfRGF0YSkgQVBMLkdldEluc3RhbmNlKFwiRGF0YUJpbmRpbmdcIiwgZHMuQ2xhc3MsIGRzLkluc3RhbmNlLCB0aGlzKTtcclxuaWYgKG51bGwgIT0gZGJvYmo1NikgZGJvYmo1Ni5SdW5Qcm9wZXJ0eUNoYW5nZWRJbihkcyxmYWxzZSk7XHJcbn1cclxuIFxyXG5lbHNlIGlmKGRzLkNsYXNzID09IFwicXdjTGlzdE11bHRpX0RhdGFcIikge1xyXG5xd2NMaXN0TXVsdGlfRGF0YSBkYm9iajU3ID0gKHF3Y0xpc3RNdWx0aV9EYXRhKSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBkcy5DbGFzcywgZHMuSW5zdGFuY2UsIHRoaXMpO1xyXG5pZiAobnVsbCAhPSBkYm9iajU3KSBkYm9iajU3LlJ1blByb3BlcnR5Q2hhbmdlZEluKGRzLGZhbHNlKTtcclxufVxyXG4gXHJcbmVsc2UgaWYoZHMuQ2xhc3MgPT0gXCJxd2NMaXN0Vmlld1NpbmdsZV9EYXRhXCIpIHtcclxucXdjTGlzdFZpZXdTaW5nbGVfRGF0YSBkYm9iajU4ID0gKHF3Y0xpc3RWaWV3U2luZ2xlX0RhdGEpIEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgdGhpcyk7XHJcbmlmIChudWxsICE9IGRib2JqNTgpIGRib2JqNTguUnVuUHJvcGVydHlDaGFuZ2VkSW4oZHMsZmFsc2UpO1xyXG59XHJcbiBcclxuZWxzZSBpZihkcy5DbGFzcyA9PSBcInF3Y0xpc3RWaWV3TXVsdGlfRGF0YVwiKSB7XHJcbnF3Y0xpc3RWaWV3TXVsdGlfRGF0YSBkYm9iajU5ID0gKHF3Y0xpc3RWaWV3TXVsdGlfRGF0YSkgQVBMLkdldEluc3RhbmNlKFwiRGF0YUJpbmRpbmdcIiwgZHMuQ2xhc3MsIGRzLkluc3RhbmNlLCB0aGlzKTtcclxuaWYgKG51bGwgIT0gZGJvYmo1OSkgZGJvYmo1OS5SdW5Qcm9wZXJ0eUNoYW5nZWRJbihkcyxmYWxzZSk7XHJcbn1cclxuIFxyXG5lbHNlIGlmKGRzLkNsYXNzID09IFwicXdjTWFwc19EYXRhXCIpIHtcclxucXdjTWFwc19EYXRhIGRib2JqNjAgPSAocXdjTWFwc19EYXRhKSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBkcy5DbGFzcywgZHMuSW5zdGFuY2UsIHRoaXMpO1xyXG5pZiAobnVsbCAhPSBkYm9iajYwKSBkYm9iajYwLlJ1blByb3BlcnR5Q2hhbmdlZEluKGRzLGZhbHNlKTtcclxufVxyXG4gXHJcbmVsc2UgaWYoZHMuQ2xhc3MgPT0gXCJxd2NNZW50aW9uX0RhdGFcIikge1xyXG5xd2NNZW50aW9uX0RhdGEgZGJvYmo2MSA9IChxd2NNZW50aW9uX0RhdGEpIEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgdGhpcyk7XHJcbmlmIChudWxsICE9IGRib2JqNjEpIGRib2JqNjEuUnVuUHJvcGVydHlDaGFuZ2VkSW4oZHMsZmFsc2UpO1xyXG59XHJcbiBcclxuZWxzZSBpZihkcy5DbGFzcyA9PSBcInF3Y01lbnVfRGF0YVwiKSB7XHJcbnF3Y01lbnVfRGF0YSBkYm9iajYyID0gKHF3Y01lbnVfRGF0YSkgQVBMLkdldEluc3RhbmNlKFwiRGF0YUJpbmRpbmdcIiwgZHMuQ2xhc3MsIGRzLkluc3RhbmNlLCB0aGlzKTtcclxuaWYgKG51bGwgIT0gZGJvYmo2MikgZGJvYmo2Mi5SdW5Qcm9wZXJ0eUNoYW5nZWRJbihkcyxmYWxzZSk7XHJcbn1cclxuIFxyXG5lbHNlIGlmKGRzLkNsYXNzID09IFwicXdjTWVudUJhcl9EYXRhXCIpIHtcclxucXdjTWVudUJhcl9EYXRhIGRib2JqNjMgPSAocXdjTWVudUJhcl9EYXRhKSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBkcy5DbGFzcywgZHMuSW5zdGFuY2UsIHRoaXMpO1xyXG5pZiAobnVsbCAhPSBkYm9iajYzKSBkYm9iajYzLlJ1blByb3BlcnR5Q2hhbmdlZEluKGRzLGZhbHNlKTtcclxufVxyXG4gXHJcbmVsc2UgaWYoZHMuQ2xhc3MgPT0gXCJxd2NNZW51SXRlbUNoZWNrX0RhdGFcIikge1xyXG5xd2NNZW51SXRlbUNoZWNrX0RhdGEgZGJvYmo2NCA9IChxd2NNZW51SXRlbUNoZWNrX0RhdGEpIEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgdGhpcyk7XHJcbmlmIChudWxsICE9IGRib2JqNjQpIGRib2JqNjQuUnVuUHJvcGVydHlDaGFuZ2VkSW4oZHMsZmFsc2UpO1xyXG59XHJcbiBcclxuZWxzZSBpZihkcy5DbGFzcyA9PSBcInF3Y01lbnVJdGVtUmFkaW9fRGF0YVwiKSB7XHJcbnF3Y01lbnVJdGVtUmFkaW9fRGF0YSBkYm9iajY1ID0gKHF3Y01lbnVJdGVtUmFkaW9fRGF0YSkgQVBMLkdldEluc3RhbmNlKFwiRGF0YUJpbmRpbmdcIiwgZHMuQ2xhc3MsIGRzLkluc3RhbmNlLCB0aGlzKTtcclxuaWYgKG51bGwgIT0gZGJvYmo2NSkgZGJvYmo2NS5SdW5Qcm9wZXJ0eUNoYW5nZWRJbihkcyxmYWxzZSk7XHJcbn1cclxuIFxyXG5lbHNlIGlmKGRzLkNsYXNzID09IFwicXdjTWVzc2FnZV9EYXRhXCIpIHtcclxucXdjTWVzc2FnZV9EYXRhIGRib2JqNjYgPSAocXdjTWVzc2FnZV9EYXRhKSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBkcy5DbGFzcywgZHMuSW5zdGFuY2UsIHRoaXMpO1xyXG5pZiAobnVsbCAhPSBkYm9iajY2KSBkYm9iajY2LlJ1blByb3BlcnR5Q2hhbmdlZEluKGRzLGZhbHNlKTtcclxufVxyXG4gXHJcbmVsc2UgaWYoZHMuQ2xhc3MgPT0gXCJxd2NQYWdlcl9EYXRhXCIpIHtcclxucXdjUGFnZXJfRGF0YSBkYm9iajY3ID0gKHF3Y1BhZ2VyX0RhdGEpIEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgdGhpcyk7XHJcbmlmIChudWxsICE9IGRib2JqNjcpIGRib2JqNjcuUnVuUHJvcGVydHlDaGFuZ2VkSW4oZHMsZmFsc2UpO1xyXG59XHJcbiBcclxuZWxzZSBpZihkcy5DbGFzcyA9PSBcInF3Y1BERlZpZXdlcl9EYXRhXCIpIHtcclxucXdjUERGVmlld2VyX0RhdGEgZGJvYmo2OCA9IChxd2NQREZWaWV3ZXJfRGF0YSkgQVBMLkdldEluc3RhbmNlKFwiRGF0YUJpbmRpbmdcIiwgZHMuQ2xhc3MsIGRzLkluc3RhbmNlLCB0aGlzKTtcclxuaWYgKG51bGwgIT0gZGJvYmo2OCkgZGJvYmo2OC5SdW5Qcm9wZXJ0eUNoYW5nZWRJbihkcyxmYWxzZSk7XHJcbn1cclxuIFxyXG5lbHNlIGlmKGRzLkNsYXNzID09IFwicXdjUGl2b3RUYWJsZV9EYXRhXCIpIHtcclxucXdjUGl2b3RUYWJsZV9EYXRhIGRib2JqNjkgPSAocXdjUGl2b3RUYWJsZV9EYXRhKSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBkcy5DbGFzcywgZHMuSW5zdGFuY2UsIHRoaXMpO1xyXG5pZiAobnVsbCAhPSBkYm9iajY5KSBkYm9iajY5LlJ1blByb3BlcnR5Q2hhbmdlZEluKGRzLGZhbHNlKTtcclxufVxyXG4gXHJcbmVsc2UgaWYoZHMuQ2xhc3MgPT0gXCJxd2NQcm9ncmVzc0Jhcl9EYXRhXCIpIHtcclxucXdjUHJvZ3Jlc3NCYXJfRGF0YSBkYm9iajcwID0gKHF3Y1Byb2dyZXNzQmFyX0RhdGEpIEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgdGhpcyk7XHJcbmlmIChudWxsICE9IGRib2JqNzApIGRib2JqNzAuUnVuUHJvcGVydHlDaGFuZ2VkSW4oZHMsZmFsc2UpO1xyXG59XHJcbiBcclxuZWxzZSBpZihkcy5DbGFzcyA9PSBcInF3Y1Byb2dyZXNzQnV0dG9uX0RhdGFcIikge1xyXG5xd2NQcm9ncmVzc0J1dHRvbl9EYXRhIGRib2JqNzEgPSAocXdjUHJvZ3Jlc3NCdXR0b25fRGF0YSkgQVBMLkdldEluc3RhbmNlKFwiRGF0YUJpbmRpbmdcIiwgZHMuQ2xhc3MsIGRzLkluc3RhbmNlLCB0aGlzKTtcclxuaWYgKG51bGwgIT0gZGJvYmo3MSkgZGJvYmo3MS5SdW5Qcm9wZXJ0eUNoYW5nZWRJbihkcyxmYWxzZSk7XHJcbn1cclxuIFxyXG5lbHNlIGlmKGRzLkNsYXNzID09IFwicXdjUXVlcnlCdWlsZGVyX0RhdGFcIikge1xyXG5xd2NRdWVyeUJ1aWxkZXJfRGF0YSBkYm9iajcyID0gKHF3Y1F1ZXJ5QnVpbGRlcl9EYXRhKSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBkcy5DbGFzcywgZHMuSW5zdGFuY2UsIHRoaXMpO1xyXG5pZiAobnVsbCAhPSBkYm9iajcyKSBkYm9iajcyLlJ1blByb3BlcnR5Q2hhbmdlZEluKGRzLGZhbHNlKTtcclxufVxyXG4gXHJcbmVsc2UgaWYoZHMuQ2xhc3MgPT0gXCJxd2NRUkNvZGVfRGF0YVwiKSB7XHJcbnF3Y1FSQ29kZV9EYXRhIGRib2JqNzMgPSAocXdjUVJDb2RlX0RhdGEpIEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgdGhpcyk7XHJcbmlmIChudWxsICE9IGRib2JqNzMpIGRib2JqNzMuUnVuUHJvcGVydHlDaGFuZ2VkSW4oZHMsZmFsc2UpO1xyXG59XHJcbiBcclxuZWxzZSBpZihkcy5DbGFzcyA9PSBcInF3Y1JhdGluZ19EYXRhXCIpIHtcclxucXdjUmF0aW5nX0RhdGEgZGJvYmo3NCA9IChxd2NSYXRpbmdfRGF0YSkgQVBMLkdldEluc3RhbmNlKFwiRGF0YUJpbmRpbmdcIiwgZHMuQ2xhc3MsIGRzLkluc3RhbmNlLCB0aGlzKTtcclxuaWYgKG51bGwgIT0gZGJvYmo3NCkgZGJvYmo3NC5SdW5Qcm9wZXJ0eUNoYW5nZWRJbihkcyxmYWxzZSk7XHJcbn1cclxuIFxyXG5lbHNlIGlmKGRzLkNsYXNzID09IFwicXdjUmliYm9uX0RhdGFcIikge1xyXG5xd2NSaWJib25fRGF0YSBkYm9iajc1ID0gKHF3Y1JpYmJvbl9EYXRhKSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBkcy5DbGFzcywgZHMuSW5zdGFuY2UsIHRoaXMpO1xyXG5pZiAobnVsbCAhPSBkYm9iajc1KSBkYm9iajc1LlJ1blByb3BlcnR5Q2hhbmdlZEluKGRzLGZhbHNlKTtcclxufVxyXG4gXHJcbmVsc2UgaWYoZHMuQ2xhc3MgPT0gXCJxd2NSaWNoVGV4dEVkaXRvcl9EYXRhXCIpIHtcclxucXdjUmljaFRleHRFZGl0b3JfRGF0YSBkYm9iajc2ID0gKHF3Y1JpY2hUZXh0RWRpdG9yX0RhdGEpIEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgdGhpcyk7XHJcbmlmIChudWxsICE9IGRib2JqNzYpIGRib2JqNzYuUnVuUHJvcGVydHlDaGFuZ2VkSW4oZHMsZmFsc2UpO1xyXG59XHJcbiBcclxuZWxzZSBpZihkcy5DbGFzcyA9PSBcInF3Y1NjaGVkdWxlX0RhdGFcIikge1xyXG5xd2NTY2hlZHVsZV9EYXRhIGRib2JqNzcgPSAocXdjU2NoZWR1bGVfRGF0YSkgQVBMLkdldEluc3RhbmNlKFwiRGF0YUJpbmRpbmdcIiwgZHMuQ2xhc3MsIGRzLkluc3RhbmNlLCB0aGlzKTtcclxuaWYgKG51bGwgIT0gZGJvYmo3NykgZGJvYmo3Ny5SdW5Qcm9wZXJ0eUNoYW5nZWRJbihkcyxmYWxzZSk7XHJcbn1cclxuIFxyXG5lbHNlIGlmKGRzLkNsYXNzID09IFwicXdjU2VwYXJhdG9yX0RhdGFcIikge1xyXG5xd2NTZXBhcmF0b3JfRGF0YSBkYm9iajc4ID0gKHF3Y1NlcGFyYXRvcl9EYXRhKSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBkcy5DbGFzcywgZHMuSW5zdGFuY2UsIHRoaXMpO1xyXG5pZiAobnVsbCAhPSBkYm9iajc4KSBkYm9iajc4LlJ1blByb3BlcnR5Q2hhbmdlZEluKGRzLGZhbHNlKTtcclxufVxyXG4gXHJcbmVsc2UgaWYoZHMuQ2xhc3MgPT0gXCJxd2NTaWRlQmFyX0RhdGFcIikge1xyXG5xd2NTaWRlQmFyX0RhdGEgZGJvYmo3OSA9IChxd2NTaWRlQmFyX0RhdGEpIEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgdGhpcyk7XHJcbmlmIChudWxsICE9IGRib2JqNzkpIGRib2JqNzkuUnVuUHJvcGVydHlDaGFuZ2VkSW4oZHMsZmFsc2UpO1xyXG59XHJcbiBcclxuZWxzZSBpZihkcy5DbGFzcyA9PSBcInF3Y1NpZ25hdHVyZV9EYXRhXCIpIHtcclxucXdjU2lnbmF0dXJlX0RhdGEgZGJvYmo4MCA9IChxd2NTaWduYXR1cmVfRGF0YSkgQVBMLkdldEluc3RhbmNlKFwiRGF0YUJpbmRpbmdcIiwgZHMuQ2xhc3MsIGRzLkluc3RhbmNlLCB0aGlzKTtcclxuaWYgKG51bGwgIT0gZGJvYmo4MCkgZGJvYmo4MC5SdW5Qcm9wZXJ0eUNoYW5nZWRJbihkcyxmYWxzZSk7XHJcbn1cclxuIFxyXG5lbHNlIGlmKGRzLkNsYXNzID09IFwicXdjU2tlbGV0b25fRGF0YVwiKSB7XHJcbnF3Y1NrZWxldG9uX0RhdGEgZGJvYmo4MSA9IChxd2NTa2VsZXRvbl9EYXRhKSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBkcy5DbGFzcywgZHMuSW5zdGFuY2UsIHRoaXMpO1xyXG5pZiAobnVsbCAhPSBkYm9iajgxKSBkYm9iajgxLlJ1blByb3BlcnR5Q2hhbmdlZEluKGRzLGZhbHNlKTtcclxufVxyXG4gXHJcbmVsc2UgaWYoZHMuQ2xhc3MgPT0gXCJxd2NTcGxpdHRlcl9EYXRhXCIpIHtcclxucXdjU3BsaXR0ZXJfRGF0YSBkYm9iajgyID0gKHF3Y1NwbGl0dGVyX0RhdGEpIEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgdGhpcyk7XHJcbmlmIChudWxsICE9IGRib2JqODIpIGRib2JqODIuUnVuUHJvcGVydHlDaGFuZ2VkSW4oZHMsZmFsc2UpO1xyXG59XHJcbiBcclxuZWxzZSBpZihkcy5DbGFzcyA9PSBcInF3Y1N1YkZvcm1fRGF0YVwiKSB7XHJcbnF3Y1N1YkZvcm1fRGF0YSBkYm9iajgzID0gKHF3Y1N1YkZvcm1fRGF0YSkgQVBMLkdldEluc3RhbmNlKFwiRGF0YUJpbmRpbmdcIiwgZHMuQ2xhc3MsIGRzLkluc3RhbmNlLCB0aGlzKTtcclxuaWYgKG51bGwgIT0gZGJvYmo4MykgZGJvYmo4My5SdW5Qcm9wZXJ0eUNoYW5nZWRJbihkcyxmYWxzZSk7XHJcbn1cclxuIFxyXG5lbHNlIGlmKGRzLkNsYXNzID09IFwicXdjVGFiQnV0dG9uX0RhdGFcIikge1xyXG5xd2NUYWJCdXR0b25fRGF0YSBkYm9iajg0ID0gKHF3Y1RhYkJ1dHRvbl9EYXRhKSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBkcy5DbGFzcywgZHMuSW5zdGFuY2UsIHRoaXMpO1xyXG5pZiAobnVsbCAhPSBkYm9iajg0KSBkYm9iajg0LlJ1blByb3BlcnR5Q2hhbmdlZEluKGRzLGZhbHNlKTtcclxufVxyXG4gXHJcbmVsc2UgaWYoZHMuQ2xhc3MgPT0gXCJxd2NUYWJCdXR0b24xX0RhdGFcIikge1xyXG5xd2NUYWJCdXR0b24xX0RhdGEgZGJvYmo4NSA9IChxd2NUYWJCdXR0b24xX0RhdGEpIEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgdGhpcyk7XHJcbmlmIChudWxsICE9IGRib2JqODUpIGRib2JqODUuUnVuUHJvcGVydHlDaGFuZ2VkSW4oZHMsZmFsc2UpO1xyXG59XHJcbiBcclxuZWxzZSBpZihkcy5DbGFzcyA9PSBcInF3Y1RhYkNvbnRyb2xfRGF0YVwiKSB7XHJcbnF3Y1RhYkNvbnRyb2xfRGF0YSBkYm9iajg2ID0gKHF3Y1RhYkNvbnRyb2xfRGF0YSkgQVBMLkdldEluc3RhbmNlKFwiRGF0YUJpbmRpbmdcIiwgZHMuQ2xhc3MsIGRzLkluc3RhbmNlLCB0aGlzKTtcclxuaWYgKG51bGwgIT0gZGJvYmo4NikgZGJvYmo4Ni5SdW5Qcm9wZXJ0eUNoYW5nZWRJbihkcyxmYWxzZSk7XHJcbn1cclxuIFxyXG5lbHNlIGlmKGRzLkNsYXNzID09IFwicXdjVGFiQ29udHJvbEJ1dHRvbnNfRGF0YVwiKSB7XHJcbnF3Y1RhYkNvbnRyb2xCdXR0b25zX0RhdGEgZGJvYmo4NyA9IChxd2NUYWJDb250cm9sQnV0dG9uc19EYXRhKSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBkcy5DbGFzcywgZHMuSW5zdGFuY2UsIHRoaXMpO1xyXG5pZiAobnVsbCAhPSBkYm9iajg3KSBkYm9iajg3LlJ1blByb3BlcnR5Q2hhbmdlZEluKGRzLGZhbHNlKTtcclxufVxyXG4gXHJcbmVsc2UgaWYoZHMuQ2xhc3MgPT0gXCJxd2NUYWJDb250cm9sRmxhdEJ1dHRvbnNfRGF0YVwiKSB7XHJcbnF3Y1RhYkNvbnRyb2xGbGF0QnV0dG9uc19EYXRhIGRib2JqODggPSAocXdjVGFiQ29udHJvbEZsYXRCdXR0b25zX0RhdGEpIEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgdGhpcyk7XHJcbmlmIChudWxsICE9IGRib2JqODgpIGRib2JqODguUnVuUHJvcGVydHlDaGFuZ2VkSW4oZHMsZmFsc2UpO1xyXG59XHJcbiBcclxuZWxzZSBpZihkcy5DbGFzcyA9PSBcInF3Y1RhYkNvbnRyb2xUYWJzX0RhdGFcIikge1xyXG5xd2NUYWJDb250cm9sVGFic19EYXRhIGRib2JqODkgPSAocXdjVGFiQ29udHJvbFRhYnNfRGF0YSkgQVBMLkdldEluc3RhbmNlKFwiRGF0YUJpbmRpbmdcIiwgZHMuQ2xhc3MsIGRzLkluc3RhbmNlLCB0aGlzKTtcclxuaWYgKG51bGwgIT0gZGJvYmo4OSkgZGJvYmo4OS5SdW5Qcm9wZXJ0eUNoYW5nZWRJbihkcyxmYWxzZSk7XHJcbn1cclxuIFxyXG5lbHNlIGlmKGRzLkNsYXNzID09IFwicXdjVGV4dF9EYXRhXCIpIHtcclxucXdjVGV4dF9EYXRhIGRib2JqOTAgPSAocXdjVGV4dF9EYXRhKSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBkcy5DbGFzcywgZHMuSW5zdGFuY2UsIHRoaXMpO1xyXG5pZiAobnVsbCAhPSBkYm9iajkwKSBkYm9iajkwLlJ1blByb3BlcnR5Q2hhbmdlZEluKGRzLGZhbHNlKTtcclxufVxyXG4gXHJcbmVsc2UgaWYoZHMuQ2xhc3MgPT0gXCJxd2NUcmVlVmlld19EYXRhXCIpIHtcclxucXdjVHJlZVZpZXdfRGF0YSBkYm9iajkxID0gKHF3Y1RyZWVWaWV3X0RhdGEpIEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgdGhpcyk7XHJcbmlmIChudWxsICE9IGRib2JqOTEpIGRib2JqOTEuUnVuUHJvcGVydHlDaGFuZ2VkSW4oZHMsZmFsc2UpO1xyXG59XHJcbiBcclxuZWxzZSBpZihkcy5DbGFzcyA9PSBcInF3Y1VwbG9hZGVyX0RhdGFcIikge1xyXG5xd2NVcGxvYWRlcl9EYXRhIGRib2JqOTIgPSAocXdjVXBsb2FkZXJfRGF0YSkgQVBMLkdldEluc3RhbmNlKFwiRGF0YUJpbmRpbmdcIiwgZHMuQ2xhc3MsIGRzLkluc3RhbmNlLCB0aGlzKTtcclxuaWYgKG51bGwgIT0gZGJvYmo5MikgZGJvYmo5Mi5SdW5Qcm9wZXJ0eUNoYW5nZWRJbihkcyxmYWxzZSk7XHJcbn1cclxuIFxyXG5lbHNlIGlmKGRzLkNsYXNzID09IFwiV1NJbnRlcm5hbHNcIikge1xyXG5XU0ludGVybmFscyBkYm9iajkzID0gKFdTSW50ZXJuYWxzKSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBkcy5DbGFzcywgZHMuSW5zdGFuY2UsIHRoaXMpO1xyXG5pZiAobnVsbCAhPSBkYm9iajkzKSBkYm9iajkzLlJ1blByb3BlcnR5Q2hhbmdlZEluKGRzLGZhbHNlKTtcclxufVxyXG4gXHJcbn1cclxuc3RyaW5nIE9uQmVmb3JlVW5sb2FkKG9iamVjdCBlKSB7XHJcbnN0cmluZyBtc2cgPSBcIkRvIHlvdSB3YW50IHRvIGxlYXZlIFFXQz9cIjtcclxuSW50ZXJvcC5FeGVjdXRlSmF2YVNjcmlwdChcIiQwLnByZXZlbnREZWZhdWx0KClcIiwgZSk7XHJcbkludGVyb3AuRXhlY3V0ZUphdmFTY3JpcHQoXCIkMC5yZXR1cm5WYWx1ZSA9ICQxXCIsZSxtc2cpO1xyXG5yZXR1cm4gbXNnO1xyXG59IFxyXG5wcml2YXRlIHZvaWQgTWFrZVdpblNpemUocXdjX1Jvb3QgcnQsIFdTSW50ZXJuYWxzIHdpKXtcclxud2kuU2V0VmFsdWUoXCJTdGF0dXNcIiwgXCJXZWJTb2NrZXQgT3BlbmVkXCIpO1xyXG5TaXplIGZzeiA9IG5ldyBTaXplKCk7XHJcbmZzei5XaWR0aCA9IChkb3VibGUpIEludGVyb3AuRXhlY3V0ZUphdmFTY3JpcHQoXCJzY3JlZW4ud2lkdGhcIik7XHJcbmZzei5IZWlnaHQgPSAoZG91YmxlKSBJbnRlcm9wLkV4ZWN1dGVKYXZhU2NyaXB0KFwic2NyZWVuLmhlaWdodFwiKTtcclxuQXBwbGljYXRpb24uQ3VycmVudC5SZXNvdXJjZXNbXCJGdWxsU2NyZWVuSGVpZ2h0XCJdID0gZnN6LkhlaWdodDtcclxuQXBwbGljYXRpb24uQ3VycmVudC5SZXNvdXJjZXNbXCJGdWxsU2NyZWVuV2lkdGhcIl0gPSBmc3ouV2lkdGg7XHJcbnJ0LlNldFZhbHVlKFwiRnVsbFNjcmVlblNpemVcIixmc3opO1xyXG5XaW5kb3cgd2luID0gV2luZG93LkN1cnJlbnQ7XHJcbkFwcGxpY2F0aW9uLkN1cnJlbnQuUmVzb3VyY2VzW1wiU2NyZWVuXCJdID0gd2luO1xyXG5SZWN0IHJlY3QgPSB3aW4uQm91bmRzO1xyXG5BcHBsaWNhdGlvbi5DdXJyZW50LlJlc291cmNlc1tcIlNjcmVlbkhlaWdodFwiXSA9IHJlY3QuSGVpZ2h0O1xyXG5BcHBsaWNhdGlvbi5DdXJyZW50LlJlc291cmNlc1tcIlNjcmVlbldpZHRoXCJdID0gcmVjdC5XaWR0aDtcclxucnQuU2V0VmFsdWUoXCJTY3JlZW5TaXplXCIscmVjdC5TaXplKTtcclxucnQuU2V0VmFsdWUoXCJCcm93c2VyU2NyZWVuU2l6ZVwiLHJlY3QuU2l6ZSk7XHJcbmRvdWJsZSByYXRpbz0oZG91YmxlKSBJbnRlcm9wLkV4ZWN1dGVKYXZhU2NyaXB0KFwid2luZG93LmRldmljZVBpeGVsUmF0aW9cIik7XHJcbmlmIChyYXRpbzwxKSByYXRpbz0xL3JhdGlvO1xyXG5TaXplIGZTaXplPW5ldyBTaXplKChpbnQpIGZzei5XaWR0aCpyYXRpbywgKGludCkgZnN6LkhlaWdodCpyYXRpbyk7XHJcbkFwcGxpY2F0aW9uLkN1cnJlbnQuUmVzb3VyY2VzW1wiRnVsbFNjcmVlbkhlaWdodFwiXSA9IGZTaXplLkhlaWdodDtcclxuQXBwbGljYXRpb24uQ3VycmVudC5SZXNvdXJjZXNbXCJGdWxsU2NyZWVuV2lkdGhcIl0gPSBmU2l6ZS5XaWR0aDtcclxucnQuU2V0VmFsdWUoXCJGdWxsU2NyZWVuU2l6ZVwiLGZTaXplKTtcclxud2luLlNpemVDaGFuZ2VkICs9IChzMSwgZTEpID0+IHtcclxuU2l6ZSBuZXdzeiA9IGUxLlNpemU7XHJcbnF3Y19Sb290IHJvb3QgPSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBcInF3Y19Sb290XCIsIFwicXdjX1Jvb3RcIiwgdGhpcykgYXMgcXdjX1Jvb3Q7XHJcbnJvb3QuU2V0VmFsdWUoXCJTY3JlZW5TaXplXCIsIG5ld3N6KTtcclxucm9vdC5TZXRWYWx1ZShcIkJyb3dzZXJTY3JlZW5TaXplXCIsIG5ld3N6KTtcclxuZG91YmxlIHJhdGlvMT0oZG91YmxlKSBJbnRlcm9wLkV4ZWN1dGVKYXZhU2NyaXB0KFwid2luZG93LmRldmljZVBpeGVsUmF0aW9cIik7XHJcbmlmIChyYXRpbzE8MSkgcmF0aW8xPTEvcmF0aW8xKzAuNTtcclxuU2l6ZSBmU2l6ZTE9bmV3IFNpemUoKGludCkgZnN6LldpZHRoKnJhdGlvMSwgKGludCkgZnN6LkhlaWdodCpyYXRpbzEpO1xyXG5BcHBsaWNhdGlvbi5DdXJyZW50LlJlc291cmNlc1tcIkZ1bGxTY3JlZW5IZWlnaHRcIl0gPSBmU2l6ZTEuSGVpZ2h0O1xyXG5BcHBsaWNhdGlvbi5DdXJyZW50LlJlc291cmNlc1tcIkZ1bGxTY3JlZW5XaWR0aFwiXSA9IGZTaXplMS5XaWR0aDtcclxucm9vdC5TZXRWYWx1ZShcIkZ1bGxTY3JlZW5TaXplXCIsZlNpemUxKTtcclxuQXBwbGljYXRpb24uQ3VycmVudC5SZXNvdXJjZXNbXCJTY3JlZW5IZWlnaHRcIl0gPSBuZXdzei5IZWlnaHQ7XHJcbkFwcGxpY2F0aW9uLkN1cnJlbnQuUmVzb3VyY2VzW1wiU2NyZWVuV2lkdGhcIl0gPSBuZXdzei5XaWR0aDtcclxuQXBwbGljYXRpb24uQ3VycmVudC5SZXNvdXJjZXNbXCJCcm93c2VyU2NyZWVuSGVpZ2h0XCJdID0gbmV3c3ouSGVpZ2h0O1xyXG5BcHBsaWNhdGlvbi5DdXJyZW50LlJlc291cmNlc1tcIkJyb3dzZXJTY3JlZW5XaWR0aFwiXSA9IG5ld3N6LldpZHRoO1xyXG5TdHJpbmcgZm0gPSAoU3RyaW5nKXJvb3QuR2V0VmFsdWUoXCJGdWxsU2NyZWVuSWRcIik7XHJcbmlmICgwICE9IGZtLkxlbmd0aCkge1xyXG5xd2NGb3JtX0RhdGEgZHMgPSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBcInF3Y0Zvcm1fRGF0YVwiLCBmbSwgdGhpcykgYXMgcXdjRm9ybV9EYXRhO1xyXG5pZiAoZm0gIT0gbnVsbCAmJiA0ID09IChpbnQpZHMuR2V0VmFsdWUoXCJTdGF0ZVwiKSkge1xyXG5kcy5Ob3RpZnlQcm9wZXJ0eUNoYW5nZWQoXCJTaXplXCIpO1xyXG59fVxyXG59O31cclxucHJpdmF0ZSB2b2lkIFVwZGF0ZUJpbmRpbmdMb3N0Rm9jdXMob2JqZWN0IHNlbmRlciwgUm91dGVkRXZlbnRBcmdzIGUpXHJcbnsgXHJcblRleHRCb3ggdHggPSAoVGV4dEJveClzZW5kZXI7XHJcbmlmICgwICE9IHR4LlRleHQuTGVuZ3RoKSB7XHJcbkJpbmRpbmdFeHByZXNzaW9uIGV4cCA9IHR4LkdldEJpbmRpbmdFeHByZXNzaW9uKFRleHRCb3guVGV4dFByb3BlcnR5KTtcclxuTUpIX0NvbW1vbkRhdGEgZG9iaiA9IGV4cC5EYXRhSXRlbSBhcyBNSkhfQ29tbW9uRGF0YTtcclxuc3RyaW5nIGluc3RhbmNlID0gZG9iai5NSkhfSW5zdGFuY2U7XHJcblRyYW5zZmVyU3RyaW5nIGRzID0gVEQuVG9UcmFuc2ZlclN0cmluZyhcIlwiKTtcclxuZHMuTmFtZSA9IGV4cC5QYXJlbnRCaW5kaW5nLlBhdGguUGF0aDtcclxuZHMuRGF0YSA9IHR4LlRleHQ7XHJcbmRzLkluc3RhbmNlID0gaW5zdGFuY2U7XHJcbmRzLkNsYXNzID0gQVBMLkdldENsYXNzQnlOYW1lKGRzLkluc3RhbmNlKTtcclxub2JqZWN0IG9iaiA9IEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgdGhpcyk7XHJcbnZhciBhcmd1bWVudHMgPSBuZXcgb2JqZWN0W10ge2RzLCB0cnVlfTsgIC8vIEFzIGlmIGVudGVyZWQgZnJvbSBzY3JlZW5cclxuQXNzZW1ibHkgYXNzZW1ibHkgPSBBUEwuR2V0QXNzZW1ibHkoXCJEYXRhQmluZGluZ1wiLCB0aGlzKTtcclxuVHlwZSB0eXBlID0gYXNzZW1ibHkuR2V0VHlwZShcIkRhdGFCaW5kaW5nXCIgKyBcIi5cIiArIGRzLkNsYXNzKTtcclxuTWV0aG9kSW5mbyBtZXRob2QgPSB0eXBlLkdldE1ldGhvZChcIlJ1blByb3BlcnR5Q2hhbmdlZEluXCIpO1xyXG5tZXRob2QuSW52b2tlKG9iaiwgYXJndW1lbnRzKTtcclxufX1cclxucHJpdmF0ZSB2b2lkIFVwZGF0ZUJpbmRpbmdLZXlEb3duKG9iamVjdCBzZW5kZXIsIEtleVJvdXRlZEV2ZW50QXJncyBlKVxyXG57IFxyXG5pZiAoZS5LZXkgPT0gVmlydHVhbEtleS5FbnRlcilcclxueyBcclxuVGV4dEJveCB0eCA9IChUZXh0Qm94KXNlbmRlcjtcclxuaWYoMCE9dHguVGV4dC5MZW5ndGgpe1xyXG5CaW5kaW5nRXhwcmVzc2lvbiBleHAgPSB0eC5HZXRCaW5kaW5nRXhwcmVzc2lvbihUZXh0Qm94LlRleHRQcm9wZXJ0eSk7XHJcbk1KSF9Db21tb25EYXRhIGRvYmogPSBleHAuRGF0YUl0ZW0gYXMgTUpIX0NvbW1vbkRhdGE7XHJcbnN0cmluZyBpbnN0YW5jZSA9IGRvYmouTUpIX0luc3RhbmNlO1xyXG5UcmFuc2ZlclN0cmluZyBkcyA9IFRELlRvVHJhbnNmZXJTdHJpbmcoXCJcIik7XHJcbmRzLk5hbWUgPSBleHAuUGFyZW50QmluZGluZy5QYXRoLlBhdGg7XHJcbmRzLkRhdGEgPSB0eC5UZXh0O1xyXG5kcy5JbnN0YW5jZSA9IGluc3RhbmNlO1xyXG5kcy5DbGFzcyA9IEFQTC5HZXRDbGFzc0J5TmFtZShkcy5JbnN0YW5jZSk7XHJcbm9iamVjdCBvYmogPSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBkcy5DbGFzcywgZHMuSW5zdGFuY2UsIHRoaXMpO1xyXG52YXIgYXJndW1lbnRzID0gbmV3IG9iamVjdFtdIHtkcywgdHJ1ZX07ICAgIC8vIEFzIGlmIGVudGVyZWQgZnJvbSBzY3JlZW5cclxuQXNzZW1ibHkgYXNzZW1ibHkgPSBBUEwuR2V0QXNzZW1ibHkoXCJEYXRhQmluZGluZ1wiLCB0aGlzKTtcclxuVHlwZSB0eXBlID0gYXNzZW1ibHkuR2V0VHlwZShcIkRhdGFCaW5kaW5nXCIgKyBcIi5cIiArIGRzLkNsYXNzKTtcclxuTWV0aG9kSW5mbyBtZXRob2QgPSB0eXBlLkdldE1ldGhvZChcIlJ1blByb3BlcnR5Q2hhbmdlZEluXCIpO1xyXG5tZXRob2QuSW52b2tlKG9iaiwgYXJndW1lbnRzKTtcclxufX19XHJcbn19XHJcbiIsInVzaW5nIFN5c3RlbTtcclxudXNpbmcgQVBMRXh0ZW5zaW9uO1xyXG51c2luZyBTeXN0ZW0uUmVmbGVjdGlvbjtcclxudXNpbmcgQVBMQ29udHJvbHM7XHJcbnVzaW5nIFN5c3RlbS5Db2xsZWN0aW9ucy5HZW5lcmljO1xyXG51c2luZyBXaW5kb3dzLlVJLlhhbWw7XHJcbnVzaW5nIERhdGFCaW5kaW5nO1xyXG51c2luZyBDU0hUTUw1O1xyXG5cclxubmFtZXNwYWNlIFFXQ1xyXG57XHJcbiAgICBwdWJsaWMgc3RhdGljIGNsYXNzIE5RXHJcbiAgICB7XHJcbiAgICAgICAgcHVibGljIHN0YXRpYyBTdHJpbmcgRG9BZGRWaXN1YWwoVHJhbnNmZXJTdHJpbmcgZHMsIG9iamVjdCBhY3R0aGlzKVxyXG4gICAgICAgIHtcclxuICAgICAgICAgICAgb2JqZWN0IG9iaiA9IEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgYWN0dGhpcyk7XHJcbiAgICAgICAgICAgIHZhciBhcmd1bWVudHMgPSBuZXcgb2JqZWN0W10geyBkcyB9O1xyXG4gICAgICAgICAgICBBc3NlbWJseSBhc3NlbWJseSA9IEFQTC5HZXRBc3NlbWJseShcIkRhdGFCaW5kaW5nXCIsIGFjdHRoaXMpO1xyXG5cclxuICAgICAgICAgICAgc3RyaW5nIGNsID0gQVBMLkdldENsYXNzQnlOYW1lKGRzLkluc3RhbmNlKTtcclxuICAgICAgICAgICAgaWYgKGNsLkNvbnRhaW5zKFwiX0RhdGFcIikpIGNsID0gY2wuU3Vic3RyaW5nKDAsIGNsLkxlbmd0aCAtIDUpO1xyXG4gICAgICAgICAgICBUeXBlIHR5cGUgPSBhc3NlbWJseS5HZXRUeXBlKFwiRGF0YUJpbmRpbmdcIiArIFwiLlwiICsgY2wpO1xyXG5cclxuICAgICAgICAgICAgTWV0aG9kSW5mbyBtZXRob2QgPSB0eXBlLkdldE1ldGhvZChcIkRvQWRkVmlzdWFsXCIpO1xyXG5cclxuICAgICAgICAgICAgaWYgKFV0aWxzLklzU3RhdGljKG1ldGhvZCkpXHJcbiAgICAgICAgICAgICAgICByZXR1cm4gKFN0cmluZyltZXRob2QuSW52b2tlKG51bGwsIGFyZ3VtZW50cyk7XHJcbiAgICAgICAgICAgIGVsc2VcclxuICAgICAgICAgICAgICAgIHJldHVybiAoU3RyaW5nKW1ldGhvZC5JbnZva2UoKChNSkhfQ29tbW9uRGF0YSlvYmopLk1KSF9DbGFzcywgYXJndW1lbnRzKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHB1YmxpYyBzdGF0aWMgU3RyaW5nIERvUnVuRXZlbnQoVHJhbnNmZXJTdHJpbmcgZHMsIG9iamVjdCBhY3R0aGlzKVxyXG4gICAgICAgIHtcclxuICAgICAgICAgICAgb2JqZWN0IG9iaiA9IEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgYWN0dGhpcyk7XHJcbiAgICAgICAgICAgIHZhciBhcmd1bWVudHMgPSBuZXcgb2JqZWN0W10geyBkcyB9O1xyXG4gICAgICAgICAgICBBc3NlbWJseSBhc3NlbWJseSA9IEFQTC5HZXRBc3NlbWJseShcIkRhdGFCaW5kaW5nXCIsIGFjdHRoaXMpO1xyXG5cclxuICAgICAgICAgICAgc3RyaW5nIGNsID0gQVBMLkdldENsYXNzQnlOYW1lKGRzLkluc3RhbmNlKTtcclxuICAgICAgICAgICAgaWYgKGNsLkNvbnRhaW5zKFwiX0RhdGFcIikpIGNsID0gY2wuU3Vic3RyaW5nKDAsIGNsLkxlbmd0aCAtIDUpO1xyXG4gICAgICAgICAgICBUeXBlIHR5cGUgPSBhc3NlbWJseS5HZXRUeXBlKFwiRGF0YUJpbmRpbmdcIiArIFwiLlwiICsgY2wpO1xyXG5cclxuICAgICAgICAgICAgTWV0aG9kSW5mbyBtZXRob2QgPSB0eXBlLkdldE1ldGhvZChcIkRvUnVuRXZlbnRcIik7XHJcblxyXG4gICAgICAgICAgICBzdHJpbmcgcmVzdWx0ID0gXCJcIjtcclxuICAgICAgICAgICAgaWYgKG1ldGhvZCAhPSBudWxsKVxyXG4gICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICBpZiAoVXRpbHMuSXNTdGF0aWMobWV0aG9kKSlcclxuICAgICAgICAgICAgICAgICAgICByZXN1bHQgPSAoU3RyaW5nKW1ldGhvZC5JbnZva2UobnVsbCwgYXJndW1lbnRzKTtcclxuICAgICAgICAgICAgICAgIGVsc2VcclxuICAgICAgICAgICAgICAgICAgICByZXN1bHQgPSAoU3RyaW5nKW1ldGhvZC5JbnZva2UoKChNSkhfQ29tbW9uRGF0YSlvYmopLk1KSF9DbGFzcywgYXJndW1lbnRzKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICByZXR1cm4gcmVzdWx0O1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcHVibGljIHN0YXRpYyBTdHJpbmcgRG9SdW5NZXRob2QoVHJhbnNmZXJTdHJpbmcgZHMsIG9iamVjdCBhY3R0aGlzKVxyXG4gICAgICAgIHtcclxuICAgICAgICAgICAgc3RyaW5nIHJlc3VsdCA9IFwiXCI7XHJcbiAgICAgICAgICAgIG9iamVjdCBvYmogPSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBkcy5DbGFzcywgZHMuSW5zdGFuY2UsIGFjdHRoaXMpO1xyXG4gICAgICAgICAgICB2YXIgYXJndW1lbnRzID0gbmV3IG9iamVjdFtdIHsgZHMgfTtcclxuICAgICAgICAgICAgQXNzZW1ibHkgYXNzZW1ibHkgPSBBUEwuR2V0QXNzZW1ibHkoXCJEYXRhQmluZGluZ1wiLCBhY3R0aGlzKTtcclxuICAgICAgICAgICAgc3RyaW5nIGNsID0gQVBMLkdldENsYXNzQnlOYW1lKGRzLkluc3RhbmNlKTtcclxuXHJcbiAgICAgICAgICAgIGlmIChjbC5Db250YWlucyhcIl9EYXRhXCIpKSBjbCA9IGNsLlN1YnN0cmluZygwLCBjbC5MZW5ndGggLSA1KTtcclxuICAgICAgICAgICAgVHlwZSB0eXBlID0gYXNzZW1ibHkuR2V0VHlwZShcIkRhdGFCaW5kaW5nXCIgKyBcIi5cIiArIGNsKTtcclxuICAgICAgICAgICAgTWV0aG9kSW5mbyBtZXRob2QgPSB0eXBlLkdldE1ldGhvZChcIkRvXCIgKyBkcy5EYXRhKTtcclxuXHJcbiAgICAgICAgICAgIGlmIChtZXRob2QgIT0gbnVsbClcclxuICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgaWYgKFV0aWxzLklzU3RhdGljKG1ldGhvZCkpIHJlc3VsdCA9IChTdHJpbmcpbWV0aG9kLkludm9rZShudWxsLCBhcmd1bWVudHMpO1xyXG4gICAgICAgICAgICAgICAgZWxzZSByZXN1bHQgPSAoU3RyaW5nKW1ldGhvZC5JbnZva2UoKChNSkhfQ29tbW9uRGF0YSlvYmopLk1KSF9DbGFzcywgYXJndW1lbnRzKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICByZXR1cm4gcmVzdWx0O1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcHVibGljIHN0YXRpYyBzdHJpbmcgRG9HZXRTZXJpYWxObyhUcmFuc2ZlclN0cmluZyBkcywgb2JqZWN0IGFjdHRoaXMpXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgICBNSkhfQ29tbW9uRGF0YSBvYmogPSAoTUpIX0NvbW1vbkRhdGEpQVBMLkdldEluc3RhbmNlKFwiRGF0YUJpbmRpbmdcIiwgZHMuQ2xhc3MsIGRzLkluc3RhbmNlLCBhY3R0aGlzKTtcclxuICAgICAgICAgICAgc3RyaW5nIHJlc3VsdCA9IG9iai5NSkhfU2VyaWFsTm87XHJcbiAgICAgICAgICAgIHJldHVybiByZXN1bHQ7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBwcml2YXRlIHN0YXRpYyBvYmplY3QgTG9ja0luc3RhbmNlcyA9IG5ldyBPYmplY3QoKTtcclxuXHJcbiAgICAgICAgcHVibGljIHN0YXRpYyBzdHJpbmcgRG9EZWxldGUoVHJhbnNmZXJTdHJpbmcgZHMsIG9iamVjdCBhY3R0aGlzKVxyXG4gICAgICAgIHtcclxuICAgICAgICAgICAgaWYgKGRzLkNsYXNzID09IFwicXdjX1Jvb3RcIikgcmV0dXJuIChcIlwiKTtcclxuICAgICAgICAgICAgc3RyaW5nIHJlc3VsdCA9IFwiXCI7XHJcblxyXG4gICAgICAgICAgICBvYmplY3Qgb2JqID0gQVBMLkdldEluc3RhbmNlKGRzLlNlcmlhbE5vKTtcclxuICAgICAgICAgICAgdmFyIGFyZ3VtZW50cyA9IG5ldyBvYmplY3RbXSB7IGRzIH07XHJcbiAgICAgICAgICAgIEFzc2VtYmx5IGFzc2VtYmx5ID0gQVBMLkdldEFzc2VtYmx5KFwiRGF0YUJpbmRpbmdcIiwgYWN0dGhpcyk7XHJcbiAgICAgICAgICAgIGlmICgwICE9IGRzLlNlcmlhbE5vLkxlbmd0aClcclxuICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgc3RyaW5nIGNsID0gQVBMLkdldENsYXNzQnlTZXJpYWxObyhkcy5TZXJpYWxObyk7XHJcblx0XHRcdFx0aWYgKDAgIT0gY2wuTGVuZ3RoKSB7XHJcblx0XHRcdFx0XHRpZiAoY2wuQ29udGFpbnMoXCJfRGF0YVwiKSkgY2wgPSBjbC5TdWJzdHJpbmcoMCwgY2wuTGVuZ3RoIC0gNSk7XHJcblx0XHRcdFx0XHRUeXBlIHR5cGUgPSBhc3NlbWJseS5HZXRUeXBlKFwiRGF0YUJpbmRpbmdcIiArIFwiLlwiICsgY2wpO1xyXG5cclxuXHRcdFx0XHRcdE1ldGhvZEluZm8gbWV0aG9kID0gdHlwZS5HZXRNZXRob2QoXCJEb0RlbGV0ZVwiKTtcclxuXHJcblx0XHRcdFx0XHRpZiAobWV0aG9kICE9IG51bGwpXHJcblx0XHRcdFx0XHR7XHJcblx0XHRcdFx0XHRcdGlmIChVdGlscy5Jc1N0YXRpYyhtZXRob2QpKVxyXG5cdFx0XHRcdFx0XHRcdHJlc3VsdCA9IChTdHJpbmcpbWV0aG9kLkludm9rZShudWxsLCBhcmd1bWVudHMpO1xyXG5cdFx0XHRcdFx0XHRlbHNlXHJcblx0XHRcdFx0XHRcdHtcclxuXHRcdFx0XHRcdFx0XHRNSkhfQ29tbW9uRGF0YSBzZWxmID0gKE1KSF9Db21tb25EYXRhKW9iajtcclxuXHRcdFx0XHRcdFx0XHRyZXN1bHQgPSAoU3RyaW5nKW1ldGhvZC5JbnZva2Uoc2VsZi5NSkhfQ2xhc3MsIGFyZ3VtZW50cyk7XHJcblx0XHRcdFx0XHRcdH1cclxuXHRcdFx0XHRcdH1cclxuXHRcdFx0ICAgfVxyXG4gICAgICAgICAgICAgICAgcmV0dXJuIHJlc3VsdDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIHJldHVybiBcIlwiO1xyXG4gICAgICAgIH1cclxuXHRcdHB1YmxpYyBzdGF0aWMgc3RyaW5nIERvU2V0QWNjZWxlcmF0b3IoVHJhbnNmZXJTdHJpbmcgZHMsIG9iamVjdCBhY3R0aGlzKVxyXG4gICAgICAgIHtcclxuICAgICAgICAgICAgaW50IGtleSA9IENvbnZlcnQuVG9JbnQzMihkcy5BcmdzKTtcclxuICAgICAgICAgICAgaWYgKGtleSAhPSAwKVxyXG4gICAgICAgICAgICB7IC8vIEFkZFxyXG4gICAgICAgICAgICAgICAgQWNjZWxlcmF0b3IuQWRkKGtleSwgZHMuSW5zdGFuY2UpO1xyXG4gICAgICAgICAgICB9IGVsc2UgXHJcbiAgICAgICAgICAgIHsgLy8gUmVtb3ZlXHJcbiAgICAgICAgICAgICAgICBBY2NlbGVyYXRvci5SZW1vdmUoa2V5LCBkcy5JbnN0YW5jZSk7XHJcblxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHJldHVybiBcIlwiO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG4iXQp9Cg==

/**
 * @version 1.0.0.0
 * @author MJH Software Services Ltd
 * @copyright MJH @2017
 * @compiler Bridge.NET 17.9.0
 */
Bridge.assembly("QWC", function ($asm, globals) {
    "use strict";

    Bridge.define("\u01c0\u01c0Qwc\u01c0\u01c0Component\u01c0\u01c0App\u01c0\u01c0Xaml\u01c0\u01c0Factory", {
        statics: {
            methods: {
                Instantiate: function () {
                    var type = QWC.App;
                    return Bridge.global.CSHTML5.Internal.TypeInstantiationHelper.Instantiate(type);
                }
            }
        }
    });

    Bridge.define("\u01c0\u01c0Qwc\u01c0\u01c0Component\u01c0\u01c0Mainpage\u01c0\u01c0Xaml\u01c0\u01c0Factory", {
        statics: {
            methods: {
                Instantiate: function () {
                    var type = QWC.MainPage;
                    return Bridge.global.CSHTML5.Internal.TypeInstantiationHelper.Instantiate(type);
                }
            }
        }
    });

    Bridge.define("QWC.App", {
        inherits: [Windows.UI.Xaml.Application],
        main: function Main () {
            new QWC.App();
        },
        fields: {
            d: null,
            _contentLoaded: false
        },
        ctors: {
            ctor: function () {
                this.$initialize();
                Windows.UI.Xaml.Application.ctor.call(this);
                this.InitializeComponent();
                try {
                    var a = new DataBinding.SenderClass();
                    Windows.UI.Xaml.Application.Current.Resources.setItem("SenderClass", a);
                    Windows.UI.Xaml.Application.Current.Resources.setItem("QWC", this);
                } catch ($e1) {
                    $e1 = System.Exception.create($e1);
                }
                var mainPage = new QWC.MainPage();
                if (mjh_filesloaded) mjh_filesloaded['page'] = mainPage;
                Windows.UI.Xaml.Window.Current.Content = mainPage;
            }
        },
        methods: {
            RunClickMin: function (s, args) {
                var dc = Bridge.cast(Bridge.cast(s, Windows.UI.Xaml.Controls.Button).DataContext, DataBinding.qwcForm_Data);
                dc.SendMargin = false;
                dc.State = 1;
                var root = Bridge.as(APLExtension.APL.GetInstance$3("DataBinding", "qwc_Root", "qwc_Root", this), DataBinding.qwc_Root);
                root.FullScreenId = "";
            },
            RunClickMax: function (s, args) {
                var dc = Bridge.cast(Bridge.cast(s, Windows.UI.Xaml.Controls.Button).DataContext, DataBinding.qwcForm_Data);
                dc.SendMargin = false;
                if (2 === dc.State) {
                    dc.State = 0;
                } else {
                    dc.State = 2;
                }
                var root = Bridge.as(APLExtension.APL.GetInstance$3("DataBinding", "qwc_Root", "qwc_Root", this), DataBinding.qwc_Root);
                root.FullScreenId = "";
            },
            RunClickFullScreen: function (s, args) {
                var dc = Bridge.cast(Bridge.cast(s, Windows.UI.Xaml.Controls.Button).DataContext, DataBinding.qwcForm_Data);
                var obj = Bridge.as(dc.MJH_Self, APLControls.APLForm);
                dc.SendMargin = false;
                var elem = CSHTML5.Interop.GetDiv(obj);
                openFullscreen(elem);
                dc.State = 4;
                var root = Bridge.as(APLExtension.APL.GetInstance$3("DataBinding", "qwc_Root", "qwc_Root", this), DataBinding.qwc_Root);
                root.FullScreenId = dc.Name;
            },
            RunClickClose: function (s, args) {
                var dc = Bridge.cast(Bridge.cast(s, Windows.UI.Xaml.Controls.Button).DataContext, DataBinding.qwcForm_Data);
                dc.SendMargin = false;
                var eventname = "ClickClose";
                var obj = Bridge.as(dc.MJH_Self, APLControls.APLForm);
                obj.Close$1();
            },
            InitializeComponent: function () {
                var $t;
                if (this._contentLoaded) {
                    return;
                }
                this._contentLoaded = true;


                if (Bridge.is(this, Windows.UI.Xaml.UIElement)) {
                    Bridge.cast(this, Windows.UI.Xaml.UIElement).XamlSourcePath = "QWC\\App.xaml";
                }


                Bridge.global.CSHTML5.Internal.StartupAssemblyInfo.OutputRootPath = "Output\\";
                Bridge.global.CSHTML5.Internal.StartupAssemblyInfo.OutputAppFilesPath = "app-cshtml5\\app\\";
                Bridge.global.CSHTML5.Internal.StartupAssemblyInfo.OutputLibrariesPath = "app-cshtml5\\libs\\";
                Bridge.global.CSHTML5.Internal.StartupAssemblyInfo.OutputResourcesPath = "app-cshtml5\\res\\";


                var ResourceDictionary_f0f6431f17fe45cfb188b8b226b54cd4 = new Bridge.global.Windows.UI.Xaml.ResourceDictionary();
                this.Resources = ResourceDictionary_f0f6431f17fe45cfb188b8b226b54cd4;
                var IntConverter_0ced125350c44e87a3abeb00c9cc7e71 = new Bridge.global.APLExtension.IntConverter();

                var DecConverter_cbd2974fe389434cb2ae15bb750485ad = new Bridge.global.APLExtension.DecConverter();

                var ToPolyLineConverter_010c4ee2e4a1401daa5a265bff291dca = new Bridge.global.APLExtension.ToPolyLineConverter();

                var ToPointsConverter_cb39497248e34d20b2e28c682e719cbd = new Bridge.global.APLExtension.ToPointsConverter();

                var ToLinesConverter_649241e4ac3a4803ad664d5f0c718548 = new Bridge.global.APLExtension.ToLinesConverter();

                var APLColorConverter_17e61e369a4f46be9d4808056623c82d = new Bridge.global.APLExtension.APLColorConverter();

                var APLColorCSSConverter_f5422057ce2647179fbd8fa449a19eff = new Bridge.global.APLExtension.APLColorCSSConverter();

                var APLMultiColorConverter_6433445fb71f4c6bb1c8e6389f095f8f = new Bridge.global.APLExtension.APLMultiColorConverter();

                var APLMultiColorCSSConverter_b08c25416fa84cdeb21e5d7ae563655c = new Bridge.global.APLExtension.APLMultiColorCSSConverter();

                var IndexInt32Converter_ba2f4d069b0740cb9b396c9fb1dd1e1c = new Bridge.global.APLExtension.IndexInt32Converter();

                var IndexDoubleConverter_53953ccfbd2940e48d229d97ba087659 = new Bridge.global.APLExtension.IndexDoubleConverter();

                var IndexStringConverter_629c1f18785e4fc89e1725adf7f4eab9 = new Bridge.global.APLExtension.IndexStringConverter();

                var IndexAPLColorConverter_f40c7adacf8049afac99a69da7170750 = new Bridge.global.APLExtension.IndexAPLColorConverter();

                var IndexAPLColourConverter_accde457823748449854fe2e33812be0 = new Bridge.global.APLExtension.IndexAPLColourConverter();

                var MathsIConverter_38e1946605fd44c1bd11e1aeec242018 = new Bridge.global.APLExtension.MathsIConverter();

                var MathsDConverter_260170684c4a43bbb3e84c1f00b74cd3 = new Bridge.global.APLExtension.MathsDConverter();

                var MathIConverter_ccdc3835062f454d84dc760560f472da = new Bridge.global.APLExtension.MathIConverter();

                var MathDConverter_754fbf8e1d4b4a65b359d723ec5f1402 = new Bridge.global.APLExtension.MathDConverter();

                var String_31127a7defaf406c8052127e7d6167fe = "\u2395WC Cross Platform";

                var String_c401ba1fda2746f1a326e7fa78b68255 = "MJH Software Services Ltd";

                var String_35c2e9d4af574621b312ddab4e3332a6 = "MJH Software Services Ltd";

                var String_e5eaa9b1f49547568eb87dddc4e87cb6 = "QWC";

                var String_01ce0d3a4ff644368a89fd66acf162ff = "\u2395WC Cross Platform";

                var String_7c2d3149a3704915b16ddab07adf2f95 = "mjh.ico";

                var String_e7967a2244144410b309c737728e29ab = "12345";

                var String_73dedcb310934dad9a36c7ef9486918c = "MainPage";

                var String_3f66494d08714817bd15e38b308a9eb4 = "MainPage:Page";

                var String_e00f22a326bc4581b497b884462964f8 = "Direct";

                var String_53d60dfcf3e141d2b73b8892b3d5a1c0 = "QWC";

                var Style_22a1bded031a475aa15539342ec96021 = new Bridge.global.Windows.UI.Xaml.Style.ctor();
                Style_22a1bded031a475aa15539342ec96021.TargetType = Bridge.global.Windows.UI.Xaml.Controls.ChildWindow;
                var Setter_2811dc1ff9504b64a46ac469c014f277 = new Bridge.global.Windows.UI.Xaml.Setter.ctor();
                Setter_2811dc1ff9504b64a46ac469c014f277.Property = Bridge.global.Windows.UI.Xaml.Controls.ChildWindow.OverlayBrushProperty;
                Setter_2811dc1ff9504b64a46ac469c014f277.Value = new Bridge.global.Windows.UI.Xaml.Media.SolidColorBrush.$ctor1(($t = new Bridge.global.Windows.UI.Color(), $t.A = 0, $t.R = 255, $t.G = 255, $t.B = 255, $t));

                var Setter_798c8a32072149d2b22fa38356ad3594 = new Bridge.global.Windows.UI.Xaml.Setter.ctor();
                Setter_798c8a32072149d2b22fa38356ad3594.Property = Bridge.global.Windows.UI.Xaml.Controls.ChildWindow.OverlayOpacityProperty;
                Setter_798c8a32072149d2b22fa38356ad3594.Value = Bridge.box(1.0, System.Double, System.Double.format, System.Double.getHashCode);

                var Setter_278b714cec6943c2aaebbf328395298f = new Bridge.global.Windows.UI.Xaml.Setter.ctor();
                Setter_278b714cec6943c2aaebbf328395298f.Property = Bridge.global.Windows.UI.Xaml.FrameworkElement.HorizontalAlignmentProperty;
                Setter_278b714cec6943c2aaebbf328395298f.Value = Bridge.box(Bridge.global.Windows.UI.Xaml.HorizontalAlignment.Left, Windows.UI.Xaml.HorizontalAlignment, System.Enum.toStringFn(Windows.UI.Xaml.HorizontalAlignment));

                var Setter_fb8ce065ac4847db9250785683e04d5f = new Bridge.global.Windows.UI.Xaml.Setter.ctor();
                Setter_fb8ce065ac4847db9250785683e04d5f.Property = Bridge.global.Windows.UI.Xaml.FrameworkElement.VerticalAlignmentProperty;
                Setter_fb8ce065ac4847db9250785683e04d5f.Value = Bridge.box(Bridge.global.Windows.UI.Xaml.VerticalAlignment.Top, Windows.UI.Xaml.VerticalAlignment, System.Enum.toStringFn(Windows.UI.Xaml.VerticalAlignment));

                var Setter_8b8b65551218446fbee542489cf91bc9 = new Bridge.global.Windows.UI.Xaml.Setter.ctor();
                Setter_8b8b65551218446fbee542489cf91bc9.Property = Bridge.global.Windows.UI.Xaml.Controls.Control.TemplateProperty;
                var ControlTemplate_feec458e06a54878a69125969583ce03 = new Bridge.global.Windows.UI.Xaml.Controls.ControlTemplate();
                ControlTemplate_feec458e06a54878a69125969583ce03.TargetType = Bridge.global.Windows.UI.Xaml.Controls.ChildWindow;
                ControlTemplate_feec458e06a54878a69125969583ce03.SetMethodToInstantiateFrameworkTemplate(Bridge.fn.bind(this, function (templateOwner_ControlTemplate_feec458e06a54878a69125969583ce03) {
                    var $t1;
                    var templateInstance_5e8fa750918a477197f8e94142c4638e = new Bridge.global.Windows.UI.Xaml.TemplateInstance();
                    templateInstance_5e8fa750918a477197f8e94142c4638e.TemplateOwner = templateOwner_ControlTemplate_feec458e06a54878a69125969583ce03;
                    var VisualState_b94b984e25d14cb1ac91a1c00dec7637 = new Bridge.global.Windows.UI.Xaml.VisualState();
                    var VisualState_0b3f04b214f24a45a26949044703de9e = new Bridge.global.Windows.UI.Xaml.VisualState();
                    var VisualStateGroup_e3999af65a4e4fe6b52e3627c40d7225 = new Bridge.global.Windows.UI.Xaml.VisualStateGroup();
                    var Grid_55eef9b6c41c477fbaecb4183a7c783f = new Bridge.global.Windows.UI.Xaml.Controls.Grid();
                    var Button_c1ae587c6db745fd9170730a13a0455a = new Bridge.global.Windows.UI.Xaml.Controls.Button();
                    var ContentControl_055a52bdf0f9415183ca0008c238ea74 = new Bridge.global.Windows.UI.Xaml.Controls.ContentControl();
                    var Button_ad26a67dabe346da9d83c191d2d5b9d2 = new Bridge.global.Windows.UI.Xaml.Controls.Button();
                    var Button_3529159b5db649ad84f5d03e5167cf61 = new Bridge.global.Windows.UI.Xaml.Controls.Button();
                    var Button_ae8fdd4da3f04193b2a4ee1a83c7ce70 = new Bridge.global.Windows.UI.Xaml.Controls.Button();
                    var Button_6fc5dde4d4ac48688f09a691a3e6208d = new Bridge.global.Windows.UI.Xaml.Controls.Button();
                    var Button_46c225f764ac40fd8cdf9e27a22734ed = new Bridge.global.Windows.UI.Xaml.Controls.Button();
                    var Border_2f8e120ff69f489a973de9b4df3a71f5 = new Bridge.global.Windows.UI.Xaml.Controls.Border();
                    var ContentPresenter_1683e53c0d8741fb9bed9822070fecb3 = new Bridge.global.Windows.UI.Xaml.Controls.ContentPresenter();
                    var Border_bbfc36fd93df4cf4b41465a12f3f1d08 = new Bridge.global.Windows.UI.Xaml.Controls.Border();
                    var Border_e9e635397c194282811c2f10bb5be241 = new Bridge.global.Windows.UI.Xaml.Controls.Border();
                    var Grid_41c84d0a7101482190774acac431a0cd = new Bridge.global.Windows.UI.Xaml.Controls.Grid();
                    templateOwner_ControlTemplate_feec458e06a54878a69125969583ce03.RegisterName("Root", Grid_41c84d0a7101482190774acac431a0cd);
                    Grid_41c84d0a7101482190774acac431a0cd.Name = "Root";
                    Grid_41c84d0a7101482190774acac431a0cd.RenderTransformOrigin = new Bridge.global.Windows.Foundation.Point.$ctor1(0, 0);
                    templateOwner_ControlTemplate_feec458e06a54878a69125969583ce03.RegisterName("ModalStates", VisualStateGroup_e3999af65a4e4fe6b52e3627c40d7225);
                    VisualStateGroup_e3999af65a4e4fe6b52e3627c40d7225.Name = "ModalStates";
                    templateOwner_ControlTemplate_feec458e06a54878a69125969583ce03.RegisterName("NotModal", VisualState_b94b984e25d14cb1ac91a1c00dec7637);
                    VisualState_b94b984e25d14cb1ac91a1c00dec7637.Name = "NotModal";
                    var Storyboard_3a9f1177786e4565b4d15947a2d7ea25 = new Bridge.global.Windows.UI.Xaml.Media.Animation.Storyboard();
                    var ObjectAnimationUsingKeyFrames_dfcf065c2fce482da6bb9a48970adea5 = new Bridge.global.Windows.UI.Xaml.Media.Animation.ObjectAnimationUsingKeyFrames();
                    Bridge.global.Windows.UI.Xaml.Media.Animation.Storyboard.SetTargetName(ObjectAnimationUsingKeyFrames_dfcf065c2fce482da6bb9a48970adea5, "Overlay");
                    var DiscreteObjectKeyFrame_e59a16faf35f47658174440cee46f4fa = new Bridge.global.Windows.UI.Xaml.Media.Animation.DiscreteObjectKeyFrame();
                    var NullExtension_34c899eab2f445e68643f1f3940a3583 = new Bridge.global.System.Windows.Markup.NullExtension();

                    DiscreteObjectKeyFrame_e59a16faf35f47658174440cee46f4fa.Value = null;


                    ObjectAnimationUsingKeyFrames_dfcf065c2fce482da6bb9a48970adea5.KeyFrames.add(DiscreteObjectKeyFrame_e59a16faf35f47658174440cee46f4fa);


                    var ObjectAnimationUsingKeyFrames_afd95400cf9e48f69c699ff652d41374 = new Bridge.global.Windows.UI.Xaml.Media.Animation.ObjectAnimationUsingKeyFrames();
                    Bridge.global.Windows.UI.Xaml.Media.Animation.Storyboard.SetTargetName(ObjectAnimationUsingKeyFrames_afd95400cf9e48f69c699ff652d41374, "Overlay");
                    var DiscreteObjectKeyFrame_43e15e9ca5ae4017aae933234812f5d2 = new Bridge.global.Windows.UI.Xaml.Media.Animation.DiscreteObjectKeyFrame();
                    DiscreteObjectKeyFrame_43e15e9ca5ae4017aae933234812f5d2.Value = "False";

                    ObjectAnimationUsingKeyFrames_afd95400cf9e48f69c699ff652d41374.KeyFrames.add(DiscreteObjectKeyFrame_43e15e9ca5ae4017aae933234812f5d2);


                    Storyboard_3a9f1177786e4565b4d15947a2d7ea25.Children.add(ObjectAnimationUsingKeyFrames_dfcf065c2fce482da6bb9a48970adea5);
                    Storyboard_3a9f1177786e4565b4d15947a2d7ea25.Children.add(ObjectAnimationUsingKeyFrames_afd95400cf9e48f69c699ff652d41374);


                    VisualState_b94b984e25d14cb1ac91a1c00dec7637.Storyboard = Storyboard_3a9f1177786e4565b4d15947a2d7ea25;


                    templateOwner_ControlTemplate_feec458e06a54878a69125969583ce03.RegisterName("Modal", VisualState_0b3f04b214f24a45a26949044703de9e);
                    VisualState_0b3f04b214f24a45a26949044703de9e.Name = "Modal";

                    System.Array.add(VisualStateGroup_e3999af65a4e4fe6b52e3627c40d7225.States, VisualState_b94b984e25d14cb1ac91a1c00dec7637, Object);
                    System.Array.add(VisualStateGroup_e3999af65a4e4fe6b52e3627c40d7225.States, VisualState_0b3f04b214f24a45a26949044703de9e, Object);


                    templateOwner_ControlTemplate_feec458e06a54878a69125969583ce03.INTERNAL_GetVisualStateGroups().add(VisualStateGroup_e3999af65a4e4fe6b52e3627c40d7225);

                    templateOwner_ControlTemplate_feec458e06a54878a69125969583ce03.RegisterName("Overlay", Grid_55eef9b6c41c477fbaecb4183a7c783f);
                    Grid_55eef9b6c41c477fbaecb4183a7c783f.Name = "Overlay";
                    Grid_55eef9b6c41c477fbaecb4183a7c783f.HorizontalAlignment = Bridge.global.Windows.UI.Xaml.HorizontalAlignment.Stretch;
                    Grid_55eef9b6c41c477fbaecb4183a7c783f.VerticalAlignment = Bridge.global.Windows.UI.Xaml.VerticalAlignment.Stretch;
                    Grid_55eef9b6c41c477fbaecb4183a7c783f.Margin = new Bridge.global.Windows.UI.Xaml.Thickness.$ctor1(0);
                    var Binding_908b01cfde1044aebb56c0a83a23136c = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_908b01cfde1044aebb56c0a83a23136c.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("OverlayBrush");
                    var RelativeSource_47f6c36fdfca41a883414c966a38b72b = new Bridge.global.Windows.UI.Xaml.Data.RelativeSource.ctor();
                    RelativeSource_47f6c36fdfca41a883414c966a38b72b.Mode = Bridge.global.Windows.UI.Xaml.Data.RelativeSourceMode.TemplatedParent;

                    Binding_908b01cfde1044aebb56c0a83a23136c.RelativeSource = RelativeSource_47f6c36fdfca41a883414c966a38b72b;


                    Binding_908b01cfde1044aebb56c0a83a23136c.TemplateOwner = templateInstance_5e8fa750918a477197f8e94142c4638e;

                    var Binding_a8489a1eddb14b239eaa4e676f631d33 = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_a8489a1eddb14b239eaa4e676f631d33.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("OverlayOpacity");
                    var RelativeSource_c66363699f5f40118bb764099d03a963 = new Bridge.global.Windows.UI.Xaml.Data.RelativeSource.ctor();
                    RelativeSource_c66363699f5f40118bb764099d03a963.Mode = Bridge.global.Windows.UI.Xaml.Data.RelativeSourceMode.TemplatedParent;

                    Binding_a8489a1eddb14b239eaa4e676f631d33.RelativeSource = RelativeSource_c66363699f5f40118bb764099d03a963;


                    Binding_a8489a1eddb14b239eaa4e676f631d33.TemplateOwner = templateInstance_5e8fa750918a477197f8e94142c4638e;


                    templateOwner_ControlTemplate_feec458e06a54878a69125969583ce03.RegisterName("ContentRoot", Border_e9e635397c194282811c2f10bb5be241);
                    Border_e9e635397c194282811c2f10bb5be241.Name = "ContentRoot";
                    templateOwner_ControlTemplate_feec458e06a54878a69125969583ce03.RegisterName("ContentContainer", Border_bbfc36fd93df4cf4b41465a12f3f1d08);
                    Border_bbfc36fd93df4cf4b41465a12f3f1d08.Name = "ContentContainer";
                    Border_bbfc36fd93df4cf4b41465a12f3f1d08.Background = new Bridge.global.Windows.UI.Xaml.Media.SolidColorBrush.$ctor1(($t1 = new Bridge.global.Windows.UI.Color(), $t1.A = 255, $t1.R = 246, $t1.G = 246, $t1.B = 246, $t1));
                    Border_bbfc36fd93df4cf4b41465a12f3f1d08.CornerRadius = new Bridge.global.Windows.UI.Xaml.CornerRadius.$ctor1(2);
                    var Grid_be55346c5e754e6cb362f1a963f59338 = new Bridge.global.Windows.UI.Xaml.Controls.Grid();
                    var RowDefinition_77fcc0742f9c4e9ab1a7387ed4575bae = new Bridge.global.Windows.UI.Xaml.Controls.RowDefinition();
                    RowDefinition_77fcc0742f9c4e9ab1a7387ed4575bae.Height = new Bridge.global.Windows.UI.Xaml.GridLength.$ctor2(1.0, Bridge.global.Windows.UI.Xaml.GridUnitType.Auto);

                    var RowDefinition_126e6bacda5d4398a144e86fefdecf00 = new Bridge.global.Windows.UI.Xaml.Controls.RowDefinition();
                    RowDefinition_126e6bacda5d4398a144e86fefdecf00.Height = new Bridge.global.Windows.UI.Xaml.GridLength.$ctor2(1.0, Bridge.global.Windows.UI.Xaml.GridUnitType.Star);

                    Grid_be55346c5e754e6cb362f1a963f59338.RowDefinitions.add(RowDefinition_77fcc0742f9c4e9ab1a7387ed4575bae);
                    Grid_be55346c5e754e6cb362f1a963f59338.RowDefinitions.add(RowDefinition_126e6bacda5d4398a144e86fefdecf00);

                    templateOwner_ControlTemplate_feec458e06a54878a69125969583ce03.RegisterName("Chrome", Border_2f8e120ff69f489a973de9b4df3a71f5);
                    Border_2f8e120ff69f489a973de9b4df3a71f5.Name = "Chrome";
                    Border_2f8e120ff69f489a973de9b4df3a71f5.Width = Number.NaN;
                    Border_2f8e120ff69f489a973de9b4df3a71f5.BorderBrush = new Bridge.global.Windows.UI.Xaml.Media.SolidColorBrush.$ctor1(($t1 = new Bridge.global.Windows.UI.Color(), $t1.A = 255, $t1.R = 255, $t1.G = 255, $t1.B = 255, $t1));
                    Border_2f8e120ff69f489a973de9b4df3a71f5.BorderThickness = new Bridge.global.Windows.UI.Xaml.Thickness.$ctor2(0, 0, 0, 0);
                    Border_2f8e120ff69f489a973de9b4df3a71f5.Background = new Bridge.global.Windows.UI.Xaml.Media.SolidColorBrush.$ctor1(($t1 = new Bridge.global.Windows.UI.Color(), $t1.A = 255, $t1.R = 238, $t1.G = 238, $t1.B = 238, $t1));
                    var Grid_46ebfad6d5794fbd9be30d39002cc305 = new Bridge.global.Windows.UI.Xaml.Controls.Grid();
                    var ColumnDefinition_29af681c0dfb43ff96ab2408bdef3e7f = new Bridge.global.Windows.UI.Xaml.Controls.ColumnDefinition();
                    ColumnDefinition_29af681c0dfb43ff96ab2408bdef3e7f.Width = new Bridge.global.Windows.UI.Xaml.GridLength.$ctor2(1.0, Bridge.global.Windows.UI.Xaml.GridUnitType.Auto);

                    var ColumnDefinition_cc0c939f2cb1441fb26a1aab84ea4e64 = new Bridge.global.Windows.UI.Xaml.Controls.ColumnDefinition();
                    ColumnDefinition_cc0c939f2cb1441fb26a1aab84ea4e64.Width = new Bridge.global.Windows.UI.Xaml.GridLength.$ctor2(1.0, Bridge.global.Windows.UI.Xaml.GridUnitType.Star);

                    var ColumnDefinition_cc2202fc8f7343d2b1355178b87fa0b1 = new Bridge.global.Windows.UI.Xaml.Controls.ColumnDefinition();
                    ColumnDefinition_cc2202fc8f7343d2b1355178b87fa0b1.Width = new Bridge.global.Windows.UI.Xaml.GridLength.$ctor2(1.0, Bridge.global.Windows.UI.Xaml.GridUnitType.Auto);

                    var ColumnDefinition_513c313d736b449eaf8f5282178bb635 = new Bridge.global.Windows.UI.Xaml.Controls.ColumnDefinition();
                    ColumnDefinition_513c313d736b449eaf8f5282178bb635.Width = new Bridge.global.Windows.UI.Xaml.GridLength.$ctor2(1.0, Bridge.global.Windows.UI.Xaml.GridUnitType.Auto);

                    var ColumnDefinition_d8c14e2cdfd54f3bbe74b6aa643ba328 = new Bridge.global.Windows.UI.Xaml.Controls.ColumnDefinition();
                    ColumnDefinition_d8c14e2cdfd54f3bbe74b6aa643ba328.Width = new Bridge.global.Windows.UI.Xaml.GridLength.$ctor2(1.0, Bridge.global.Windows.UI.Xaml.GridUnitType.Auto);

                    var ColumnDefinition_35fe28d67a76409c823c84fae6a30006 = new Bridge.global.Windows.UI.Xaml.Controls.ColumnDefinition();
                    ColumnDefinition_35fe28d67a76409c823c84fae6a30006.Width = new Bridge.global.Windows.UI.Xaml.GridLength.$ctor2(1.0, Bridge.global.Windows.UI.Xaml.GridUnitType.Auto);

                    var ColumnDefinition_38b54c0e155f4babade01e0984efb2f6 = new Bridge.global.Windows.UI.Xaml.Controls.ColumnDefinition();
                    ColumnDefinition_38b54c0e155f4babade01e0984efb2f6.Width = new Bridge.global.Windows.UI.Xaml.GridLength.$ctor2(1.0, Bridge.global.Windows.UI.Xaml.GridUnitType.Auto);

                    Grid_46ebfad6d5794fbd9be30d39002cc305.ColumnDefinitions.add(ColumnDefinition_29af681c0dfb43ff96ab2408bdef3e7f);
                    Grid_46ebfad6d5794fbd9be30d39002cc305.ColumnDefinitions.add(ColumnDefinition_cc0c939f2cb1441fb26a1aab84ea4e64);
                    Grid_46ebfad6d5794fbd9be30d39002cc305.ColumnDefinitions.add(ColumnDefinition_cc2202fc8f7343d2b1355178b87fa0b1);
                    Grid_46ebfad6d5794fbd9be30d39002cc305.ColumnDefinitions.add(ColumnDefinition_513c313d736b449eaf8f5282178bb635);
                    Grid_46ebfad6d5794fbd9be30d39002cc305.ColumnDefinitions.add(ColumnDefinition_d8c14e2cdfd54f3bbe74b6aa643ba328);
                    Grid_46ebfad6d5794fbd9be30d39002cc305.ColumnDefinitions.add(ColumnDefinition_35fe28d67a76409c823c84fae6a30006);
                    Grid_46ebfad6d5794fbd9be30d39002cc305.ColumnDefinitions.add(ColumnDefinition_38b54c0e155f4babade01e0984efb2f6);

                    templateOwner_ControlTemplate_feec458e06a54878a69125969583ce03.RegisterName("IconButton", Button_c1ae587c6db745fd9170730a13a0455a);
                    Button_c1ae587c6db745fd9170730a13a0455a.Name = "IconButton";
                    Button_c1ae587c6db745fd9170730a13a0455a.HorizontalAlignment = Bridge.global.Windows.UI.Xaml.HorizontalAlignment.Left;
                    Button_c1ae587c6db745fd9170730a13a0455a.VerticalAlignment = Bridge.global.Windows.UI.Xaml.VerticalAlignment.Center;
                    Button_c1ae587c6db745fd9170730a13a0455a.HorizontalContentAlignment = Bridge.global.Windows.UI.Xaml.HorizontalAlignment.Center;
                    Button_c1ae587c6db745fd9170730a13a0455a.VerticalContentAlignment = Bridge.global.Windows.UI.Xaml.VerticalAlignment.Center;
                    Button_c1ae587c6db745fd9170730a13a0455a.Width = 20.0;
                    Button_c1ae587c6db745fd9170730a13a0455a.Padding = new Bridge.global.Windows.UI.Xaml.Thickness.$ctor1(0);
                    var Image_30651c3a12c94c9eb3334e73f31439ea = new Bridge.global.Windows.UI.Xaml.Controls.Image();
                    var Binding_586c2745c7b34d85b38db8bdca619bd2 = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_586c2745c7b34d85b38db8bdca619bd2.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("Icon");



                    Button_c1ae587c6db745fd9170730a13a0455a.Content = Image_30651c3a12c94c9eb3334e73f31439ea;

                    var Binding_040ac5a853ec4f2faffe405a04d32a06 = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_040ac5a853ec4f2faffe405a04d32a06.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("IconVisibility");



                    templateOwner_ControlTemplate_feec458e06a54878a69125969583ce03.RegisterName("Title", ContentControl_055a52bdf0f9415183ca0008c238ea74);
                    ContentControl_055a52bdf0f9415183ca0008c238ea74.Name = "Title";
                    Bridge.global.Windows.UI.Xaml.Controls.Grid.SetColumn(ContentControl_055a52bdf0f9415183ca0008c238ea74, 1);
                    ContentControl_055a52bdf0f9415183ca0008c238ea74.HorizontalAlignment = Bridge.global.Windows.UI.Xaml.HorizontalAlignment.Left;
                    ContentControl_055a52bdf0f9415183ca0008c238ea74.VerticalAlignment = Bridge.global.Windows.UI.Xaml.VerticalAlignment.Center;
                    ContentControl_055a52bdf0f9415183ca0008c238ea74.Margin = new Bridge.global.Windows.UI.Xaml.Thickness.$ctor2(6, 0, 6, 0);
                    var Binding_f93b8ac6f5e64d0cbe3fc3e75c6f5205 = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_f93b8ac6f5e64d0cbe3fc3e75c6f5205.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("Title");
                    var RelativeSource_d5d801913b9d40a1b63cdcda7e70b7d5 = new Bridge.global.Windows.UI.Xaml.Data.RelativeSource.ctor();
                    RelativeSource_d5d801913b9d40a1b63cdcda7e70b7d5.Mode = Bridge.global.Windows.UI.Xaml.Data.RelativeSourceMode.TemplatedParent;

                    Binding_f93b8ac6f5e64d0cbe3fc3e75c6f5205.RelativeSource = RelativeSource_d5d801913b9d40a1b63cdcda7e70b7d5;


                    Binding_f93b8ac6f5e64d0cbe3fc3e75c6f5205.TemplateOwner = templateInstance_5e8fa750918a477197f8e94142c4638e;


                    templateOwner_ControlTemplate_feec458e06a54878a69125969583ce03.RegisterName("HelpButton", Button_ad26a67dabe346da9d83c191d2d5b9d2);
                    Button_ad26a67dabe346da9d83c191d2d5b9d2.Name = "HelpButton";
                    Button_ad26a67dabe346da9d83c191d2d5b9d2.HorizontalAlignment = Bridge.global.Windows.UI.Xaml.HorizontalAlignment.Right;
                    Button_ad26a67dabe346da9d83c191d2d5b9d2.VerticalAlignment = Bridge.global.Windows.UI.Xaml.VerticalAlignment.Center;
                    Bridge.global.Windows.UI.Xaml.Controls.Grid.SetColumn(Button_ad26a67dabe346da9d83c191d2d5b9d2, 2);
                    Button_ad26a67dabe346da9d83c191d2d5b9d2.HorizontalContentAlignment = Bridge.global.Windows.UI.Xaml.HorizontalAlignment.Center;
                    Button_ad26a67dabe346da9d83c191d2d5b9d2.VerticalContentAlignment = Bridge.global.Windows.UI.Xaml.VerticalAlignment.Center;
                    Button_ad26a67dabe346da9d83c191d2d5b9d2.Width = 20.0;
                    Button_ad26a67dabe346da9d83c191d2d5b9d2.Padding = new Bridge.global.Windows.UI.Xaml.Thickness.$ctor1(0);
                    var Image_6b87e028f4ef44a381ab2ce847f2233b = new Bridge.global.Windows.UI.Xaml.Controls.Image();
                    var Binding_4df28a024bb14561aeb2b4d3c7b0ba80 = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_4df28a024bb14561aeb2b4d3c7b0ba80.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("HelpIcon");



                    Button_ad26a67dabe346da9d83c191d2d5b9d2.Content = Image_6b87e028f4ef44a381ab2ce847f2233b;

                    var Binding_2e916d3272a84f3bb2292dd974975c0e = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_2e916d3272a84f3bb2292dd974975c0e.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("HelpVisibility");



                    templateOwner_ControlTemplate_feec458e06a54878a69125969583ce03.RegisterName("MinButton", Button_3529159b5db649ad84f5d03e5167cf61);
                    Button_3529159b5db649ad84f5d03e5167cf61.Name = "MinButton";
                    Button_3529159b5db649ad84f5d03e5167cf61.HorizontalAlignment = Bridge.global.Windows.UI.Xaml.HorizontalAlignment.Right;
                    Button_3529159b5db649ad84f5d03e5167cf61.VerticalAlignment = Bridge.global.Windows.UI.Xaml.VerticalAlignment.Center;
                    Bridge.global.Windows.UI.Xaml.Controls.Grid.SetColumn(Button_3529159b5db649ad84f5d03e5167cf61, 3);
                    Button_3529159b5db649ad84f5d03e5167cf61.HorizontalContentAlignment = Bridge.global.Windows.UI.Xaml.HorizontalAlignment.Center;
                    Button_3529159b5db649ad84f5d03e5167cf61.VerticalContentAlignment = Bridge.global.Windows.UI.Xaml.VerticalAlignment.Center;
                    Button_3529159b5db649ad84f5d03e5167cf61.Width = 20.0;
                    Button_3529159b5db649ad84f5d03e5167cf61.Padding = new Bridge.global.Windows.UI.Xaml.Thickness.$ctor1(0);
                    Button_3529159b5db649ad84f5d03e5167cf61.addClick(Bridge.fn.cacheBind(this, this.RunClickMin));
                    var Image_dbad6302446d4246817a948e3d37c195 = new Bridge.global.Windows.UI.Xaml.Controls.Image();
                    var Binding_8fbfee82ef8f4259a164022d1fa811fb = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_8fbfee82ef8f4259a164022d1fa811fb.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("MinResIcon");



                    Button_3529159b5db649ad84f5d03e5167cf61.Content = Image_dbad6302446d4246817a948e3d37c195;

                    var Binding_f2aaaa448ffd4cc5a3563fafb8ea1097 = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_f2aaaa448ffd4cc5a3563fafb8ea1097.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("MinVisibility");



                    templateOwner_ControlTemplate_feec458e06a54878a69125969583ce03.RegisterName("MaxButton", Button_ae8fdd4da3f04193b2a4ee1a83c7ce70);
                    Button_ae8fdd4da3f04193b2a4ee1a83c7ce70.Name = "MaxButton";
                    Button_ae8fdd4da3f04193b2a4ee1a83c7ce70.HorizontalAlignment = Bridge.global.Windows.UI.Xaml.HorizontalAlignment.Right;
                    Button_ae8fdd4da3f04193b2a4ee1a83c7ce70.VerticalAlignment = Bridge.global.Windows.UI.Xaml.VerticalAlignment.Center;
                    Bridge.global.Windows.UI.Xaml.Controls.Grid.SetColumn(Button_ae8fdd4da3f04193b2a4ee1a83c7ce70, 4);
                    Button_ae8fdd4da3f04193b2a4ee1a83c7ce70.HorizontalContentAlignment = Bridge.global.Windows.UI.Xaml.HorizontalAlignment.Center;
                    Button_ae8fdd4da3f04193b2a4ee1a83c7ce70.VerticalContentAlignment = Bridge.global.Windows.UI.Xaml.VerticalAlignment.Center;
                    Button_ae8fdd4da3f04193b2a4ee1a83c7ce70.Width = 20.0;
                    Button_ae8fdd4da3f04193b2a4ee1a83c7ce70.Padding = new Bridge.global.Windows.UI.Xaml.Thickness.$ctor1(0);
                    Button_ae8fdd4da3f04193b2a4ee1a83c7ce70.addClick(Bridge.fn.cacheBind(this, this.RunClickMax));
                    var Image_352491b741c94712a75d6cd0f684138c = new Bridge.global.Windows.UI.Xaml.Controls.Image();
                    var Binding_abae329e4b9345c58a67ca4c195b0465 = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_abae329e4b9345c58a67ca4c195b0465.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("MaxResIcon");



                    Button_ae8fdd4da3f04193b2a4ee1a83c7ce70.Content = Image_352491b741c94712a75d6cd0f684138c;

                    var Binding_f8e86f8711c340b0b50ddf0d20eac539 = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_f8e86f8711c340b0b50ddf0d20eac539.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("MaxVisibility");



                    templateOwner_ControlTemplate_feec458e06a54878a69125969583ce03.RegisterName("FullScreenButton", Button_6fc5dde4d4ac48688f09a691a3e6208d);
                    Button_6fc5dde4d4ac48688f09a691a3e6208d.Name = "FullScreenButton";
                    Button_6fc5dde4d4ac48688f09a691a3e6208d.HorizontalAlignment = Bridge.global.Windows.UI.Xaml.HorizontalAlignment.Right;
                    Button_6fc5dde4d4ac48688f09a691a3e6208d.VerticalAlignment = Bridge.global.Windows.UI.Xaml.VerticalAlignment.Center;
                    Bridge.global.Windows.UI.Xaml.Controls.Grid.SetColumn(Button_6fc5dde4d4ac48688f09a691a3e6208d, 5);
                    Button_6fc5dde4d4ac48688f09a691a3e6208d.HorizontalContentAlignment = Bridge.global.Windows.UI.Xaml.HorizontalAlignment.Center;
                    Button_6fc5dde4d4ac48688f09a691a3e6208d.VerticalContentAlignment = Bridge.global.Windows.UI.Xaml.VerticalAlignment.Center;
                    Button_6fc5dde4d4ac48688f09a691a3e6208d.Width = 20.0;
                    Button_6fc5dde4d4ac48688f09a691a3e6208d.Padding = new Bridge.global.Windows.UI.Xaml.Thickness.$ctor1(0);
                    Button_6fc5dde4d4ac48688f09a691a3e6208d.addClick(Bridge.fn.cacheBind(this, this.RunClickFullScreen));
                    var Image_88e1892b94004cf3b79cf24d984d8096 = new Bridge.global.Windows.UI.Xaml.Controls.Image();
                    var Binding_ece66c05f03d417d9cf81f84349f6ad7 = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_ece66c05f03d417d9cf81f84349f6ad7.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("FullScreenIcon");



                    Button_6fc5dde4d4ac48688f09a691a3e6208d.Content = Image_88e1892b94004cf3b79cf24d984d8096;

                    var Binding_8d97a547a3a54678ac9f386aa609829a = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_8d97a547a3a54678ac9f386aa609829a.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("FullScreenVisibility");



                    templateOwner_ControlTemplate_feec458e06a54878a69125969583ce03.RegisterName("CloseButton", Button_46c225f764ac40fd8cdf9e27a22734ed);
                    Button_46c225f764ac40fd8cdf9e27a22734ed.Name = "CloseButton";
                    Button_46c225f764ac40fd8cdf9e27a22734ed.HorizontalAlignment = Bridge.global.Windows.UI.Xaml.HorizontalAlignment.Right;
                    Button_46c225f764ac40fd8cdf9e27a22734ed.VerticalAlignment = Bridge.global.Windows.UI.Xaml.VerticalAlignment.Center;
                    Bridge.global.Windows.UI.Xaml.Controls.Grid.SetColumn(Button_46c225f764ac40fd8cdf9e27a22734ed, 6);
                    Button_46c225f764ac40fd8cdf9e27a22734ed.HorizontalContentAlignment = Bridge.global.Windows.UI.Xaml.HorizontalAlignment.Center;
                    Button_46c225f764ac40fd8cdf9e27a22734ed.VerticalContentAlignment = Bridge.global.Windows.UI.Xaml.VerticalAlignment.Center;
                    Button_46c225f764ac40fd8cdf9e27a22734ed.Width = 20.0;
                    Button_46c225f764ac40fd8cdf9e27a22734ed.Padding = new Bridge.global.Windows.UI.Xaml.Thickness.$ctor1(0);
                    Button_46c225f764ac40fd8cdf9e27a22734ed.addClick(Bridge.fn.cacheBind(this, this.RunClickClose));
                    var Image_4f8d93a8509140e6bd198b87bfe7c937 = new Bridge.global.Windows.UI.Xaml.Controls.Image();
                    var Binding_adcc045f02934937bfb5939cc8e63c47 = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_adcc045f02934937bfb5939cc8e63c47.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("CloseIcon");



                    Button_46c225f764ac40fd8cdf9e27a22734ed.Content = Image_4f8d93a8509140e6bd198b87bfe7c937;

                    var Binding_234e644b8f914e91a55a86008540bf5e = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_234e644b8f914e91a55a86008540bf5e.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("CloseVisibility");



                    Grid_46ebfad6d5794fbd9be30d39002cc305.Children.add(Button_c1ae587c6db745fd9170730a13a0455a);
                    Grid_46ebfad6d5794fbd9be30d39002cc305.Children.add(ContentControl_055a52bdf0f9415183ca0008c238ea74);
                    Grid_46ebfad6d5794fbd9be30d39002cc305.Children.add(Button_ad26a67dabe346da9d83c191d2d5b9d2);
                    Grid_46ebfad6d5794fbd9be30d39002cc305.Children.add(Button_3529159b5db649ad84f5d03e5167cf61);
                    Grid_46ebfad6d5794fbd9be30d39002cc305.Children.add(Button_ae8fdd4da3f04193b2a4ee1a83c7ce70);
                    Grid_46ebfad6d5794fbd9be30d39002cc305.Children.add(Button_6fc5dde4d4ac48688f09a691a3e6208d);
                    Grid_46ebfad6d5794fbd9be30d39002cc305.Children.add(Button_46c225f764ac40fd8cdf9e27a22734ed);


                    Border_2f8e120ff69f489a973de9b4df3a71f5.Child = Grid_46ebfad6d5794fbd9be30d39002cc305;

                    var Binding_2a6a747d5462426b94ec1227889fc4bf = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_2a6a747d5462426b94ec1227889fc4bf.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("TitleVisibility");



                    var Border_478633f68f2b46f9a46a627de9c24b99 = new Bridge.global.Windows.UI.Xaml.Controls.Border();
                    Bridge.global.Windows.UI.Xaml.Controls.Grid.SetRow(Border_478633f68f2b46f9a46a627de9c24b99, 1);
                    Border_478633f68f2b46f9a46a627de9c24b99.BorderThickness = new Bridge.global.Windows.UI.Xaml.Thickness.$ctor2(0, 0, 0, 0);
                    templateOwner_ControlTemplate_feec458e06a54878a69125969583ce03.RegisterName("FormContentPresenter", ContentPresenter_1683e53c0d8741fb9bed9822070fecb3);
                    ContentPresenter_1683e53c0d8741fb9bed9822070fecb3.Name = "FormContentPresenter";
                    ContentPresenter_1683e53c0d8741fb9bed9822070fecb3.ClipToBounds = true;
                    var Binding_5866a6e8f1c742d9b4eb459a412ada24 = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_5866a6e8f1c742d9b4eb459a412ada24.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("Content");
                    var RelativeSource_471d19d0a75446d08e05f837d4b8e0f4 = new Bridge.global.Windows.UI.Xaml.Data.RelativeSource.ctor();
                    RelativeSource_471d19d0a75446d08e05f837d4b8e0f4.Mode = Bridge.global.Windows.UI.Xaml.Data.RelativeSourceMode.TemplatedParent;

                    Binding_5866a6e8f1c742d9b4eb459a412ada24.RelativeSource = RelativeSource_471d19d0a75446d08e05f837d4b8e0f4;


                    Binding_5866a6e8f1c742d9b4eb459a412ada24.TemplateOwner = templateInstance_5e8fa750918a477197f8e94142c4638e;

                    var Binding_df2067cd48a0482ca2f789aef67e34b1 = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_df2067cd48a0482ca2f789aef67e34b1.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("ContentTemplate");
                    var RelativeSource_59a2094b7126474a8fac0601b1bb1c3b = new Bridge.global.Windows.UI.Xaml.Data.RelativeSource.ctor();
                    RelativeSource_59a2094b7126474a8fac0601b1bb1c3b.Mode = Bridge.global.Windows.UI.Xaml.Data.RelativeSourceMode.TemplatedParent;

                    Binding_df2067cd48a0482ca2f789aef67e34b1.RelativeSource = RelativeSource_59a2094b7126474a8fac0601b1bb1c3b;


                    Binding_df2067cd48a0482ca2f789aef67e34b1.TemplateOwner = templateInstance_5e8fa750918a477197f8e94142c4638e;

                    var Binding_effc69bbcb964858be71ec0c62b3019b = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_effc69bbcb964858be71ec0c62b3019b.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("ClientWidth");


                    var Binding_a35380129be4486f994f192ef076d813 = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_a35380129be4486f994f192ef076d813.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("ClientHeight");


                    var Binding_92a257f91a194f13b0724b175f7181e2 = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_92a257f91a194f13b0724b175f7181e2.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("HorizontalAlignment");
                    var RelativeSource_3a36c43132814cabb20efcb8435e8d6a = new Bridge.global.Windows.UI.Xaml.Data.RelativeSource.ctor();
                    RelativeSource_3a36c43132814cabb20efcb8435e8d6a.Mode = Bridge.global.Windows.UI.Xaml.Data.RelativeSourceMode.TemplatedParent;

                    Binding_92a257f91a194f13b0724b175f7181e2.RelativeSource = RelativeSource_3a36c43132814cabb20efcb8435e8d6a;


                    Binding_92a257f91a194f13b0724b175f7181e2.TemplateOwner = templateInstance_5e8fa750918a477197f8e94142c4638e;

                    var Binding_8c6f8a86020b4d85b5ab6815c4b888b5 = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_8c6f8a86020b4d85b5ab6815c4b888b5.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("VerticalAlignment");
                    var RelativeSource_86eb41df89f04b2488e8f2a990a7dc87 = new Bridge.global.Windows.UI.Xaml.Data.RelativeSource.ctor();
                    RelativeSource_86eb41df89f04b2488e8f2a990a7dc87.Mode = Bridge.global.Windows.UI.Xaml.Data.RelativeSourceMode.TemplatedParent;

                    Binding_8c6f8a86020b4d85b5ab6815c4b888b5.RelativeSource = RelativeSource_86eb41df89f04b2488e8f2a990a7dc87;


                    Binding_8c6f8a86020b4d85b5ab6815c4b888b5.TemplateOwner = templateInstance_5e8fa750918a477197f8e94142c4638e;


                    Border_478633f68f2b46f9a46a627de9c24b99.Child = ContentPresenter_1683e53c0d8741fb9bed9822070fecb3;

                    var Binding_932a43594e1c4f17b70371705596ddcb = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_932a43594e1c4f17b70371705596ddcb.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("ClientHeight");


                    var Binding_14d99049f9b3418e8f0e2f028fa9857a = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_14d99049f9b3418e8f0e2f028fa9857a.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("ClientWidth");


                    var Binding_bf054d85d45848d0b27783beecfec693 = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_bf054d85d45848d0b27783beecfec693.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("Background");
                    var RelativeSource_c7d32ab5850d4151a9d4f4e2cda8f3c8 = new Bridge.global.Windows.UI.Xaml.Data.RelativeSource.ctor();
                    RelativeSource_c7d32ab5850d4151a9d4f4e2cda8f3c8.Mode = Bridge.global.Windows.UI.Xaml.Data.RelativeSourceMode.TemplatedParent;

                    Binding_bf054d85d45848d0b27783beecfec693.RelativeSource = RelativeSource_c7d32ab5850d4151a9d4f4e2cda8f3c8;


                    Binding_bf054d85d45848d0b27783beecfec693.TemplateOwner = templateInstance_5e8fa750918a477197f8e94142c4638e;

                    var Binding_1142cc449d134a25a98f7db735145600 = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_1142cc449d134a25a98f7db735145600.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("Background");
                    var RelativeSource_22c5f5e5deeb40678bd7c173b0f9b6db = new Bridge.global.Windows.UI.Xaml.Data.RelativeSource.ctor();
                    RelativeSource_22c5f5e5deeb40678bd7c173b0f9b6db.Mode = Bridge.global.Windows.UI.Xaml.Data.RelativeSourceMode.TemplatedParent;

                    Binding_1142cc449d134a25a98f7db735145600.RelativeSource = RelativeSource_22c5f5e5deeb40678bd7c173b0f9b6db;


                    Binding_1142cc449d134a25a98f7db735145600.TemplateOwner = templateInstance_5e8fa750918a477197f8e94142c4638e;


                    Grid_be55346c5e754e6cb362f1a963f59338.Children.add(Border_2f8e120ff69f489a973de9b4df3a71f5);
                    Grid_be55346c5e754e6cb362f1a963f59338.Children.add(Border_478633f68f2b46f9a46a627de9c24b99);


                    Border_bbfc36fd93df4cf4b41465a12f3f1d08.Child = Grid_be55346c5e754e6cb362f1a963f59338;

                    var Binding_9198449b0f5a4945a0c48336b3bdaf79 = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_9198449b0f5a4945a0c48336b3bdaf79.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("BorderThickness");
                    var RelativeSource_197d4a306cc1464aa74cd916463c679e = new Bridge.global.Windows.UI.Xaml.Data.RelativeSource.ctor();
                    RelativeSource_197d4a306cc1464aa74cd916463c679e.Mode = Bridge.global.Windows.UI.Xaml.Data.RelativeSourceMode.TemplatedParent;

                    Binding_9198449b0f5a4945a0c48336b3bdaf79.RelativeSource = RelativeSource_197d4a306cc1464aa74cd916463c679e;


                    Binding_9198449b0f5a4945a0c48336b3bdaf79.TemplateOwner = templateInstance_5e8fa750918a477197f8e94142c4638e;

                    var Binding_33cdeec741794b69b17850ac282aa0d9 = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_33cdeec741794b69b17850ac282aa0d9.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("BorderBrush");
                    var RelativeSource_7c0bdb56dc79475e84c22d1f5f7e3413 = new Bridge.global.Windows.UI.Xaml.Data.RelativeSource.ctor();
                    RelativeSource_7c0bdb56dc79475e84c22d1f5f7e3413.Mode = Bridge.global.Windows.UI.Xaml.Data.RelativeSourceMode.TemplatedParent;

                    Binding_33cdeec741794b69b17850ac282aa0d9.RelativeSource = RelativeSource_7c0bdb56dc79475e84c22d1f5f7e3413;


                    Binding_33cdeec741794b69b17850ac282aa0d9.TemplateOwner = templateInstance_5e8fa750918a477197f8e94142c4638e;


                    Border_e9e635397c194282811c2f10bb5be241.Child = Border_bbfc36fd93df4cf4b41465a12f3f1d08;


                    Grid_41c84d0a7101482190774acac431a0cd.Children.add(Grid_55eef9b6c41c477fbaecb4183a7c783f);
                    Grid_41c84d0a7101482190774acac431a0cd.Children.add(Border_e9e635397c194282811c2f10bb5be241);

                    var Binding_6acdd2df689745a09ddb353b057ffd1d = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_6acdd2df689745a09ddb353b057ffd1d.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("Height");
                    var RelativeSource_31b3f8c4729a4e3e975b06dde33c8d25 = new Bridge.global.Windows.UI.Xaml.Data.RelativeSource.ctor();
                    RelativeSource_31b3f8c4729a4e3e975b06dde33c8d25.Mode = Bridge.global.Windows.UI.Xaml.Data.RelativeSourceMode.TemplatedParent;

                    Binding_6acdd2df689745a09ddb353b057ffd1d.RelativeSource = RelativeSource_31b3f8c4729a4e3e975b06dde33c8d25;


                    Binding_6acdd2df689745a09ddb353b057ffd1d.TemplateOwner = templateInstance_5e8fa750918a477197f8e94142c4638e;

                    var Binding_18e0e4abc7e34a98a17c3e260ab27c21 = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_18e0e4abc7e34a98a17c3e260ab27c21.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("Width");
                    var RelativeSource_b30fba0a0d0d4134800214e9e31aaa1a = new Bridge.global.Windows.UI.Xaml.Data.RelativeSource.ctor();
                    RelativeSource_b30fba0a0d0d4134800214e9e31aaa1a.Mode = Bridge.global.Windows.UI.Xaml.Data.RelativeSourceMode.TemplatedParent;

                    Binding_18e0e4abc7e34a98a17c3e260ab27c21.RelativeSource = RelativeSource_b30fba0a0d0d4134800214e9e31aaa1a;


                    Binding_18e0e4abc7e34a98a17c3e260ab27c21.TemplateOwner = templateInstance_5e8fa750918a477197f8e94142c4638e;

                    var Binding_76f272e0cac34626839c0750cf1080e6 = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_76f272e0cac34626839c0750cf1080e6.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("HorizontalAlignment");
                    var RelativeSource_5e3f20d872eb4640b38e651297ce290e = new Bridge.global.Windows.UI.Xaml.Data.RelativeSource.ctor();
                    RelativeSource_5e3f20d872eb4640b38e651297ce290e.Mode = Bridge.global.Windows.UI.Xaml.Data.RelativeSourceMode.TemplatedParent;

                    Binding_76f272e0cac34626839c0750cf1080e6.RelativeSource = RelativeSource_5e3f20d872eb4640b38e651297ce290e;


                    Binding_76f272e0cac34626839c0750cf1080e6.TemplateOwner = templateInstance_5e8fa750918a477197f8e94142c4638e;

                    var Binding_02474116524a4a11bf358e286e0205bd = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_02474116524a4a11bf358e286e0205bd.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("VerticalAlignment");
                    var RelativeSource_e4c99ef64a864686b9d87605c56980e5 = new Bridge.global.Windows.UI.Xaml.Data.RelativeSource.ctor();
                    RelativeSource_e4c99ef64a864686b9d87605c56980e5.Mode = Bridge.global.Windows.UI.Xaml.Data.RelativeSourceMode.TemplatedParent;

                    Binding_02474116524a4a11bf358e286e0205bd.RelativeSource = RelativeSource_e4c99ef64a864686b9d87605c56980e5;


                    Binding_02474116524a4a11bf358e286e0205bd.TemplateOwner = templateInstance_5e8fa750918a477197f8e94142c4638e;


                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(Grid_55eef9b6c41c477fbaecb4183a7c783f, Bridge.global.Windows.UI.Xaml.Controls.Panel.BackgroundProperty, Binding_908b01cfde1044aebb56c0a83a23136c);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(Grid_55eef9b6c41c477fbaecb4183a7c783f, Bridge.global.Windows.UI.Xaml.UIElement.OpacityProperty, Binding_a8489a1eddb14b239eaa4e676f631d33);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(Image_30651c3a12c94c9eb3334e73f31439ea, Bridge.global.Windows.UI.Xaml.Controls.Image.SourceProperty, Binding_586c2745c7b34d85b38db8bdca619bd2);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(Button_c1ae587c6db745fd9170730a13a0455a, Bridge.global.Windows.UI.Xaml.UIElement.VisibilityProperty, Binding_040ac5a853ec4f2faffe405a04d32a06);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(ContentControl_055a52bdf0f9415183ca0008c238ea74, Bridge.global.Windows.UI.Xaml.Controls.ContentControl.ContentProperty, Binding_f93b8ac6f5e64d0cbe3fc3e75c6f5205);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(Image_6b87e028f4ef44a381ab2ce847f2233b, Bridge.global.Windows.UI.Xaml.Controls.Image.SourceProperty, Binding_4df28a024bb14561aeb2b4d3c7b0ba80);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(Button_ad26a67dabe346da9d83c191d2d5b9d2, Bridge.global.Windows.UI.Xaml.UIElement.VisibilityProperty, Binding_2e916d3272a84f3bb2292dd974975c0e);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(Image_dbad6302446d4246817a948e3d37c195, Bridge.global.Windows.UI.Xaml.Controls.Image.SourceProperty, Binding_8fbfee82ef8f4259a164022d1fa811fb);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(Button_3529159b5db649ad84f5d03e5167cf61, Bridge.global.Windows.UI.Xaml.UIElement.VisibilityProperty, Binding_f2aaaa448ffd4cc5a3563fafb8ea1097);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(Image_352491b741c94712a75d6cd0f684138c, Bridge.global.Windows.UI.Xaml.Controls.Image.SourceProperty, Binding_abae329e4b9345c58a67ca4c195b0465);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(Button_ae8fdd4da3f04193b2a4ee1a83c7ce70, Bridge.global.Windows.UI.Xaml.UIElement.VisibilityProperty, Binding_f8e86f8711c340b0b50ddf0d20eac539);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(Image_88e1892b94004cf3b79cf24d984d8096, Bridge.global.Windows.UI.Xaml.Controls.Image.SourceProperty, Binding_ece66c05f03d417d9cf81f84349f6ad7);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(Button_6fc5dde4d4ac48688f09a691a3e6208d, Bridge.global.Windows.UI.Xaml.UIElement.VisibilityProperty, Binding_8d97a547a3a54678ac9f386aa609829a);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(Image_4f8d93a8509140e6bd198b87bfe7c937, Bridge.global.Windows.UI.Xaml.Controls.Image.SourceProperty, Binding_adcc045f02934937bfb5939cc8e63c47);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(Button_46c225f764ac40fd8cdf9e27a22734ed, Bridge.global.Windows.UI.Xaml.UIElement.VisibilityProperty, Binding_234e644b8f914e91a55a86008540bf5e);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(Border_2f8e120ff69f489a973de9b4df3a71f5, Bridge.global.Windows.UI.Xaml.UIElement.VisibilityProperty, Binding_2a6a747d5462426b94ec1227889fc4bf);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(ContentPresenter_1683e53c0d8741fb9bed9822070fecb3, Bridge.global.Windows.UI.Xaml.Controls.ContentControl.ContentProperty, Binding_5866a6e8f1c742d9b4eb459a412ada24);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(ContentPresenter_1683e53c0d8741fb9bed9822070fecb3, Bridge.global.Windows.UI.Xaml.Controls.ContentControl.ContentTemplateProperty, Binding_df2067cd48a0482ca2f789aef67e34b1);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(ContentPresenter_1683e53c0d8741fb9bed9822070fecb3, Bridge.global.Windows.UI.Xaml.FrameworkElement.WidthProperty, Binding_effc69bbcb964858be71ec0c62b3019b);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(ContentPresenter_1683e53c0d8741fb9bed9822070fecb3, Bridge.global.Windows.UI.Xaml.FrameworkElement.HeightProperty, Binding_a35380129be4486f994f192ef076d813);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(ContentPresenter_1683e53c0d8741fb9bed9822070fecb3, Bridge.global.Windows.UI.Xaml.FrameworkElement.HorizontalAlignmentProperty, Binding_92a257f91a194f13b0724b175f7181e2);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(ContentPresenter_1683e53c0d8741fb9bed9822070fecb3, Bridge.global.Windows.UI.Xaml.FrameworkElement.VerticalAlignmentProperty, Binding_8c6f8a86020b4d85b5ab6815c4b888b5);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(Border_478633f68f2b46f9a46a627de9c24b99, Bridge.global.Windows.UI.Xaml.FrameworkElement.HeightProperty, Binding_932a43594e1c4f17b70371705596ddcb);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(Border_478633f68f2b46f9a46a627de9c24b99, Bridge.global.Windows.UI.Xaml.FrameworkElement.WidthProperty, Binding_14d99049f9b3418e8f0e2f028fa9857a);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(Border_478633f68f2b46f9a46a627de9c24b99, Bridge.global.Windows.UI.Xaml.Controls.Border.BackgroundProperty, Binding_bf054d85d45848d0b27783beecfec693);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(Border_478633f68f2b46f9a46a627de9c24b99, Bridge.global.Windows.UI.Xaml.Controls.Border.BorderBrushProperty, Binding_1142cc449d134a25a98f7db735145600);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(Border_bbfc36fd93df4cf4b41465a12f3f1d08, Bridge.global.Windows.UI.Xaml.Controls.Border.BorderThicknessProperty, Binding_9198449b0f5a4945a0c48336b3bdaf79);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(Border_bbfc36fd93df4cf4b41465a12f3f1d08, Bridge.global.Windows.UI.Xaml.Controls.Border.BorderBrushProperty, Binding_33cdeec741794b69b17850ac282aa0d9);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(Grid_41c84d0a7101482190774acac431a0cd, Bridge.global.Windows.UI.Xaml.FrameworkElement.HeightProperty, Binding_6acdd2df689745a09ddb353b057ffd1d);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(Grid_41c84d0a7101482190774acac431a0cd, Bridge.global.Windows.UI.Xaml.FrameworkElement.WidthProperty, Binding_18e0e4abc7e34a98a17c3e260ab27c21);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(Grid_41c84d0a7101482190774acac431a0cd, Bridge.global.Windows.UI.Xaml.FrameworkElement.HorizontalAlignmentProperty, Binding_76f272e0cac34626839c0750cf1080e6);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(Grid_41c84d0a7101482190774acac431a0cd, Bridge.global.Windows.UI.Xaml.FrameworkElement.VerticalAlignmentProperty, Binding_02474116524a4a11bf358e286e0205bd);

                    Bridge.global.Windows.UI.Xaml.Media.Animation.Storyboard.SetTargetProperty(ObjectAnimationUsingKeyFrames_dfcf065c2fce482da6bb9a48970adea5, new Bridge.global.Windows.UI.Xaml.PropertyPath.$ctor2("Background", "Background", Bridge.fn.cacheBind(this, this.accessVisualStateProperty_102b70d6f91b4503ac2189d2296baa61), Bridge.fn.cacheBind(this, this.setVisualStateProperty_102b70d6f91b4503ac2189d2296baa61), Bridge.fn.cacheBind(this, this.setAnimationVisualStateProperty_102b70d6f91b4503ac2189d2296baa61), Bridge.fn.cacheBind(this, this.setLocalVisualStateProperty_102b70d6f91b4503ac2189d2296baa61), Bridge.fn.cacheBind(this, this.getVisualStateProperty_102b70d6f91b4503ac2189d2296baa61)));
                    Bridge.global.Windows.UI.Xaml.Media.Animation.Storyboard.SetTarget(ObjectAnimationUsingKeyFrames_dfcf065c2fce482da6bb9a48970adea5, Grid_55eef9b6c41c477fbaecb4183a7c783f);


                    Bridge.global.Windows.UI.Xaml.Media.Animation.Storyboard.SetTargetProperty(ObjectAnimationUsingKeyFrames_afd95400cf9e48f69c699ff652d41374, new Bridge.global.Windows.UI.Xaml.PropertyPath.$ctor2("IsHitTestVisible", "IsHitTestVisible", Bridge.fn.cacheBind(this, this.accessVisualStateProperty_aedcb8f5e792431c8f34691afcc4b62c), Bridge.fn.cacheBind(this, this.setVisualStateProperty_aedcb8f5e792431c8f34691afcc4b62c), Bridge.fn.cacheBind(this, this.setAnimationVisualStateProperty_aedcb8f5e792431c8f34691afcc4b62c), Bridge.fn.cacheBind(this, this.setLocalVisualStateProperty_aedcb8f5e792431c8f34691afcc4b62c), Bridge.fn.cacheBind(this, this.getVisualStateProperty_aedcb8f5e792431c8f34691afcc4b62c)));
                    Bridge.global.Windows.UI.Xaml.Media.Animation.Storyboard.SetTarget(ObjectAnimationUsingKeyFrames_afd95400cf9e48f69c699ff652d41374, Grid_55eef9b6c41c477fbaecb4183a7c783f);

                    templateInstance_5e8fa750918a477197f8e94142c4638e.TemplateContent = Grid_41c84d0a7101482190774acac431a0cd;
                    return templateInstance_5e8fa750918a477197f8e94142c4638e;
                }));

                Setter_8b8b65551218446fbee542489cf91bc9.Value = ControlTemplate_feec458e06a54878a69125969583ce03;


                Style_22a1bded031a475aa15539342ec96021.Setters.add(Setter_2811dc1ff9504b64a46ac469c014f277);
                Style_22a1bded031a475aa15539342ec96021.Setters.add(Setter_798c8a32072149d2b22fa38356ad3594);
                Style_22a1bded031a475aa15539342ec96021.Setters.add(Setter_278b714cec6943c2aaebbf328395298f);
                Style_22a1bded031a475aa15539342ec96021.Setters.add(Setter_fb8ce065ac4847db9250785683e04d5f);
                Style_22a1bded031a475aa15539342ec96021.Setters.add(Setter_8b8b65551218446fbee542489cf91bc9);


                var Style_fa0e517d37804d5190953e5380c27e2f = new Bridge.global.Windows.UI.Xaml.Style.ctor();
                Style_fa0e517d37804d5190953e5380c27e2f.TargetType = Bridge.global.Windows.UI.Xaml.Controls.Button;
                var Setter_2ddf5100cdac48fa9e0c3065007398ca = new Bridge.global.Windows.UI.Xaml.Setter.ctor();
                Setter_2ddf5100cdac48fa9e0c3065007398ca.Property = Bridge.global.Windows.UI.Xaml.Controls.Control.BackgroundProperty;
                Setter_2ddf5100cdac48fa9e0c3065007398ca.Value = new Bridge.global.Windows.UI.Xaml.Media.SolidColorBrush.$ctor1(($t = new Bridge.global.Windows.UI.Color(), $t.A = 255, $t.R = 226, $t.G = 226, $t.B = 226, $t));

                var Setter_aea9e49a02144474b4662ed884843c61 = new Bridge.global.Windows.UI.Xaml.Setter.ctor();
                Setter_aea9e49a02144474b4662ed884843c61.Property = Bridge.global.Windows.UI.Xaml.Controls.Control.ForegroundProperty;
                Setter_aea9e49a02144474b4662ed884843c61.Value = new Bridge.global.Windows.UI.Xaml.Media.SolidColorBrush.$ctor1(($t = new Bridge.global.Windows.UI.Color(), $t.A = 255, $t.R = 0, $t.G = 0, $t.B = 0, $t));

                var Setter_d6bf888fea0743ca965419fb1d8e32bd = new Bridge.global.Windows.UI.Xaml.Setter.ctor();
                Setter_d6bf888fea0743ca965419fb1d8e32bd.Property = Bridge.global.Windows.UI.Xaml.Controls.Control.BorderThicknessProperty;
                Setter_d6bf888fea0743ca965419fb1d8e32bd.Value = new Bridge.global.Windows.UI.Xaml.Thickness.$ctor1(0).$clone();

                var Setter_d794a7ac2bd34d90a34c87ea46359fb5 = new Bridge.global.Windows.UI.Xaml.Setter.ctor();
                Setter_d794a7ac2bd34d90a34c87ea46359fb5.Property = Bridge.global.Windows.UI.Xaml.Controls.Control.PaddingProperty;
                Setter_d794a7ac2bd34d90a34c87ea46359fb5.Value = new Bridge.global.Windows.UI.Xaml.Thickness.$ctor2(12, 4, 12, 4).$clone();

                var Setter_1a579a2dda284b3b94cf2a3e229adf87 = new Bridge.global.Windows.UI.Xaml.Setter.ctor();
                Setter_1a579a2dda284b3b94cf2a3e229adf87.Property = Bridge.global.Windows.UI.Xaml.FrameworkElement.CursorProperty;
                Setter_1a579a2dda284b3b94cf2a3e229adf87.Value = Bridge.global.System.Windows.Input.Cursors.Hand;

                var Setter_2b0d25adbe054057bcbf25e38f8803cd = new Bridge.global.Windows.UI.Xaml.Setter.ctor();
                Setter_2b0d25adbe054057bcbf25e38f8803cd.Property = Bridge.global.Windows.UI.Xaml.Controls.Control.HorizontalContentAlignmentProperty;
                Setter_2b0d25adbe054057bcbf25e38f8803cd.Value = Bridge.box(Bridge.global.Windows.UI.Xaml.HorizontalAlignment.Center, Windows.UI.Xaml.HorizontalAlignment, System.Enum.toStringFn(Windows.UI.Xaml.HorizontalAlignment));

                var Setter_b5f54b29a41d4d8cbcbdb92d2fed3dcc = new Bridge.global.Windows.UI.Xaml.Setter.ctor();
                Setter_b5f54b29a41d4d8cbcbdb92d2fed3dcc.Property = Bridge.global.Windows.UI.Xaml.Controls.Control.VerticalContentAlignmentProperty;
                Setter_b5f54b29a41d4d8cbcbdb92d2fed3dcc.Value = Bridge.box(Bridge.global.Windows.UI.Xaml.VerticalAlignment.Center, Windows.UI.Xaml.VerticalAlignment, System.Enum.toStringFn(Windows.UI.Xaml.VerticalAlignment));

                var Setter_8e60114318314fe88e1a0e34b31cad87 = new Bridge.global.Windows.UI.Xaml.Setter.ctor();
                Setter_8e60114318314fe88e1a0e34b31cad87.Property = Bridge.global.Windows.UI.Xaml.Controls.Control.TemplateProperty;
                var ControlTemplate_b5218792e0e647e39fc9127de57db2e8 = new Bridge.global.Windows.UI.Xaml.Controls.ControlTemplate();
                ControlTemplate_b5218792e0e647e39fc9127de57db2e8.TargetType = Bridge.global.Windows.UI.Xaml.Controls.Button;
                ControlTemplate_b5218792e0e647e39fc9127de57db2e8.SetMethodToInstantiateFrameworkTemplate(Bridge.fn.bind(this, function (templateOwner_ControlTemplate_b5218792e0e647e39fc9127de57db2e8) {
                    var templateInstance_2ef16e0a12a149cc9f25923250480508 = new Bridge.global.Windows.UI.Xaml.TemplateInstance();
                    templateInstance_2ef16e0a12a149cc9f25923250480508.TemplateOwner = templateOwner_ControlTemplate_b5218792e0e647e39fc9127de57db2e8;
                    var VisualState_fccfb2d9aa8b4cdf8332d28bd6f05f4e = new Bridge.global.Windows.UI.Xaml.VisualState();
                    var VisualState_c9b4f1b5fbba473b9dbe331c8eedaf10 = new Bridge.global.Windows.UI.Xaml.VisualState();
                    var VisualState_a0d1b6f378df4271aee89042514f8c4d = new Bridge.global.Windows.UI.Xaml.VisualState();
                    var VisualState_255be8eae2414a8da8974fe31e48e9f0 = new Bridge.global.Windows.UI.Xaml.VisualState();
                    var VisualStateGroup_81a9c0758b5b4658bafa4728ca25f372 = new Bridge.global.Windows.UI.Xaml.VisualStateGroup();
                    var ContentPresenter_ddbf6d8c5504469db20966dacd51622c = new Bridge.global.Windows.UI.Xaml.Controls.ContentPresenter();
                    var Border_fa43d1c3002c41818de067976eaf9969 = new Bridge.global.Windows.UI.Xaml.Controls.Border();
                    var Border_bbcbbf54c193472da82412c63e4f36ba = new Bridge.global.Windows.UI.Xaml.Controls.Border();
                    templateOwner_ControlTemplate_b5218792e0e647e39fc9127de57db2e8.RegisterName("OuterBorder", Border_bbcbbf54c193472da82412c63e4f36ba);
                    Border_bbcbbf54c193472da82412c63e4f36ba.Name = "OuterBorder";
                    templateOwner_ControlTemplate_b5218792e0e647e39fc9127de57db2e8.RegisterName("CommonStates", VisualStateGroup_81a9c0758b5b4658bafa4728ca25f372);
                    VisualStateGroup_81a9c0758b5b4658bafa4728ca25f372.Name = "CommonStates";
                    templateOwner_ControlTemplate_b5218792e0e647e39fc9127de57db2e8.RegisterName("Normal", VisualState_fccfb2d9aa8b4cdf8332d28bd6f05f4e);
                    VisualState_fccfb2d9aa8b4cdf8332d28bd6f05f4e.Name = "Normal";

                    templateOwner_ControlTemplate_b5218792e0e647e39fc9127de57db2e8.RegisterName("PointerOver", VisualState_c9b4f1b5fbba473b9dbe331c8eedaf10);
                    VisualState_c9b4f1b5fbba473b9dbe331c8eedaf10.Name = "PointerOver";
                    var Storyboard_809f9a74885949f2ba1789ee3146094f = new Bridge.global.Windows.UI.Xaml.Media.Animation.Storyboard();
                    var ObjectAnimationUsingKeyFrames_07d755ef8ffa464fadb819f4b2b70d3c = new Bridge.global.Windows.UI.Xaml.Media.Animation.ObjectAnimationUsingKeyFrames();
                    Bridge.global.Windows.UI.Xaml.Media.Animation.Storyboard.SetTargetName(ObjectAnimationUsingKeyFrames_07d755ef8ffa464fadb819f4b2b70d3c, "InnerBorder");
                    var DiscreteObjectKeyFrame_61487b876a3648d88e6785290134586d = new Bridge.global.Windows.UI.Xaml.Media.Animation.DiscreteObjectKeyFrame();
                    DiscreteObjectKeyFrame_61487b876a3648d88e6785290134586d.KeyTime = Bridge.global.Windows.UI.Xaml.Media.Animation.KeyTime.FromTimeSpan(new Bridge.global.System.TimeSpan(System.Int64(0)));
                    DiscreteObjectKeyFrame_61487b876a3648d88e6785290134586d.Value = "#11000000";

                    ObjectAnimationUsingKeyFrames_07d755ef8ffa464fadb819f4b2b70d3c.KeyFrames.add(DiscreteObjectKeyFrame_61487b876a3648d88e6785290134586d);


                    Storyboard_809f9a74885949f2ba1789ee3146094f.Children.add(ObjectAnimationUsingKeyFrames_07d755ef8ffa464fadb819f4b2b70d3c);


                    VisualState_c9b4f1b5fbba473b9dbe331c8eedaf10.Storyboard = Storyboard_809f9a74885949f2ba1789ee3146094f;


                    templateOwner_ControlTemplate_b5218792e0e647e39fc9127de57db2e8.RegisterName("Pressed", VisualState_a0d1b6f378df4271aee89042514f8c4d);
                    VisualState_a0d1b6f378df4271aee89042514f8c4d.Name = "Pressed";
                    var Storyboard_eba6146107fb420297a28cadc0dd3a76 = new Bridge.global.Windows.UI.Xaml.Media.Animation.Storyboard();
                    var ObjectAnimationUsingKeyFrames_e7aa6b678c484cc9ae375dbfb1f04788 = new Bridge.global.Windows.UI.Xaml.Media.Animation.ObjectAnimationUsingKeyFrames();
                    Bridge.global.Windows.UI.Xaml.Media.Animation.Storyboard.SetTargetName(ObjectAnimationUsingKeyFrames_e7aa6b678c484cc9ae375dbfb1f04788, "InnerBorder");
                    var DiscreteObjectKeyFrame_10302606ddeb4fbdab7cfa78c5ce5532 = new Bridge.global.Windows.UI.Xaml.Media.Animation.DiscreteObjectKeyFrame();
                    DiscreteObjectKeyFrame_10302606ddeb4fbdab7cfa78c5ce5532.KeyTime = Bridge.global.Windows.UI.Xaml.Media.Animation.KeyTime.FromTimeSpan(new Bridge.global.System.TimeSpan(System.Int64(0)));
                    DiscreteObjectKeyFrame_10302606ddeb4fbdab7cfa78c5ce5532.Value = "#22000000";

                    ObjectAnimationUsingKeyFrames_e7aa6b678c484cc9ae375dbfb1f04788.KeyFrames.add(DiscreteObjectKeyFrame_10302606ddeb4fbdab7cfa78c5ce5532);


                    Storyboard_eba6146107fb420297a28cadc0dd3a76.Children.add(ObjectAnimationUsingKeyFrames_e7aa6b678c484cc9ae375dbfb1f04788);


                    VisualState_a0d1b6f378df4271aee89042514f8c4d.Storyboard = Storyboard_eba6146107fb420297a28cadc0dd3a76;


                    templateOwner_ControlTemplate_b5218792e0e647e39fc9127de57db2e8.RegisterName("Disabled", VisualState_255be8eae2414a8da8974fe31e48e9f0);
                    VisualState_255be8eae2414a8da8974fe31e48e9f0.Name = "Disabled";
                    var Storyboard_2ef76e9ba6ef46e390dc8a6084253c9a = new Bridge.global.Windows.UI.Xaml.Media.Animation.Storyboard();
                    var ObjectAnimationUsingKeyFrames_cf7e4002e3054a6591af257bc122e9b0 = new Bridge.global.Windows.UI.Xaml.Media.Animation.ObjectAnimationUsingKeyFrames();
                    Bridge.global.Windows.UI.Xaml.Media.Animation.Storyboard.SetTargetName(ObjectAnimationUsingKeyFrames_cf7e4002e3054a6591af257bc122e9b0, "InnerBorder");
                    var DiscreteObjectKeyFrame_d11c314362d347e08e93d4640b5b184d = new Bridge.global.Windows.UI.Xaml.Media.Animation.DiscreteObjectKeyFrame();
                    DiscreteObjectKeyFrame_d11c314362d347e08e93d4640b5b184d.KeyTime = Bridge.global.Windows.UI.Xaml.Media.Animation.KeyTime.FromTimeSpan(new Bridge.global.System.TimeSpan(System.Int64(0)));
                    DiscreteObjectKeyFrame_d11c314362d347e08e93d4640b5b184d.Value = "#33FFFFFF";

                    ObjectAnimationUsingKeyFrames_cf7e4002e3054a6591af257bc122e9b0.KeyFrames.add(DiscreteObjectKeyFrame_d11c314362d347e08e93d4640b5b184d);


                    Storyboard_2ef76e9ba6ef46e390dc8a6084253c9a.Children.add(ObjectAnimationUsingKeyFrames_cf7e4002e3054a6591af257bc122e9b0);


                    VisualState_255be8eae2414a8da8974fe31e48e9f0.Storyboard = Storyboard_2ef76e9ba6ef46e390dc8a6084253c9a;


                    System.Array.add(VisualStateGroup_81a9c0758b5b4658bafa4728ca25f372.States, VisualState_fccfb2d9aa8b4cdf8332d28bd6f05f4e, Object);
                    System.Array.add(VisualStateGroup_81a9c0758b5b4658bafa4728ca25f372.States, VisualState_c9b4f1b5fbba473b9dbe331c8eedaf10, Object);
                    System.Array.add(VisualStateGroup_81a9c0758b5b4658bafa4728ca25f372.States, VisualState_a0d1b6f378df4271aee89042514f8c4d, Object);
                    System.Array.add(VisualStateGroup_81a9c0758b5b4658bafa4728ca25f372.States, VisualState_255be8eae2414a8da8974fe31e48e9f0, Object);


                    templateOwner_ControlTemplate_b5218792e0e647e39fc9127de57db2e8.INTERNAL_GetVisualStateGroups().add(VisualStateGroup_81a9c0758b5b4658bafa4728ca25f372);

                    templateOwner_ControlTemplate_b5218792e0e647e39fc9127de57db2e8.RegisterName("InnerBorder", Border_fa43d1c3002c41818de067976eaf9969);
                    Border_fa43d1c3002c41818de067976eaf9969.Name = "InnerBorder";
                    templateOwner_ControlTemplate_b5218792e0e647e39fc9127de57db2e8.RegisterName("ContentPresenter", ContentPresenter_ddbf6d8c5504469db20966dacd51622c);
                    ContentPresenter_ddbf6d8c5504469db20966dacd51622c.Name = "ContentPresenter";
                    var Binding_7cca7d7a420f4a6fbfba8440212af700 = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_7cca7d7a420f4a6fbfba8440212af700.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("ContentTemplate");
                    var RelativeSource_4949e68dcfb84476bd24ee02ae67a412 = new Bridge.global.Windows.UI.Xaml.Data.RelativeSource.ctor();
                    RelativeSource_4949e68dcfb84476bd24ee02ae67a412.Mode = Bridge.global.Windows.UI.Xaml.Data.RelativeSourceMode.TemplatedParent;

                    Binding_7cca7d7a420f4a6fbfba8440212af700.RelativeSource = RelativeSource_4949e68dcfb84476bd24ee02ae67a412;


                    Binding_7cca7d7a420f4a6fbfba8440212af700.TemplateOwner = templateInstance_2ef16e0a12a149cc9f25923250480508;

                    var Binding_084289f1b2754a3a975fd894a03dd618 = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_084289f1b2754a3a975fd894a03dd618.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("Content");
                    var RelativeSource_2797083fbe3e49ea8d22a5502e27170a = new Bridge.global.Windows.UI.Xaml.Data.RelativeSource.ctor();
                    RelativeSource_2797083fbe3e49ea8d22a5502e27170a.Mode = Bridge.global.Windows.UI.Xaml.Data.RelativeSourceMode.TemplatedParent;

                    Binding_084289f1b2754a3a975fd894a03dd618.RelativeSource = RelativeSource_2797083fbe3e49ea8d22a5502e27170a;


                    Binding_084289f1b2754a3a975fd894a03dd618.TemplateOwner = templateInstance_2ef16e0a12a149cc9f25923250480508;

                    var Binding_4a1b934b647140cfb4c9aaf32c3c40f8 = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_4a1b934b647140cfb4c9aaf32c3c40f8.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("Height");
                    var RelativeSource_6eb8b617774a4a04b581b7d0b2f2295e = new Bridge.global.Windows.UI.Xaml.Data.RelativeSource.ctor();
                    RelativeSource_6eb8b617774a4a04b581b7d0b2f2295e.Mode = Bridge.global.Windows.UI.Xaml.Data.RelativeSourceMode.TemplatedParent;

                    Binding_4a1b934b647140cfb4c9aaf32c3c40f8.RelativeSource = RelativeSource_6eb8b617774a4a04b581b7d0b2f2295e;


                    Binding_4a1b934b647140cfb4c9aaf32c3c40f8.TemplateOwner = templateInstance_2ef16e0a12a149cc9f25923250480508;

                    var Binding_77519d5dcd704991adf6626a74838ce1 = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_77519d5dcd704991adf6626a74838ce1.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("Width");
                    var RelativeSource_11692f688cdb4d28ae4bcbf05cd82d5d = new Bridge.global.Windows.UI.Xaml.Data.RelativeSource.ctor();
                    RelativeSource_11692f688cdb4d28ae4bcbf05cd82d5d.Mode = Bridge.global.Windows.UI.Xaml.Data.RelativeSourceMode.TemplatedParent;

                    Binding_77519d5dcd704991adf6626a74838ce1.RelativeSource = RelativeSource_11692f688cdb4d28ae4bcbf05cd82d5d;


                    Binding_77519d5dcd704991adf6626a74838ce1.TemplateOwner = templateInstance_2ef16e0a12a149cc9f25923250480508;

                    var Binding_530389b27e60405abd06cbf6e23ae849 = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_530389b27e60405abd06cbf6e23ae849.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("Padding");
                    var RelativeSource_480dcd99e1494422bbd3b380db855546 = new Bridge.global.Windows.UI.Xaml.Data.RelativeSource.ctor();
                    RelativeSource_480dcd99e1494422bbd3b380db855546.Mode = Bridge.global.Windows.UI.Xaml.Data.RelativeSourceMode.TemplatedParent;

                    Binding_530389b27e60405abd06cbf6e23ae849.RelativeSource = RelativeSource_480dcd99e1494422bbd3b380db855546;


                    Binding_530389b27e60405abd06cbf6e23ae849.TemplateOwner = templateInstance_2ef16e0a12a149cc9f25923250480508;

                    var Binding_c9b3ac70d682443ba6310708347a7d83 = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_c9b3ac70d682443ba6310708347a7d83.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("HorizontalContentAlignment");
                    var RelativeSource_4c0ee95b7e504a86aa132fac5d135e10 = new Bridge.global.Windows.UI.Xaml.Data.RelativeSource.ctor();
                    RelativeSource_4c0ee95b7e504a86aa132fac5d135e10.Mode = Bridge.global.Windows.UI.Xaml.Data.RelativeSourceMode.TemplatedParent;

                    Binding_c9b3ac70d682443ba6310708347a7d83.RelativeSource = RelativeSource_4c0ee95b7e504a86aa132fac5d135e10;


                    Binding_c9b3ac70d682443ba6310708347a7d83.TemplateOwner = templateInstance_2ef16e0a12a149cc9f25923250480508;

                    var Binding_c755757a78b043758f2e14c9a5be1a6c = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_c755757a78b043758f2e14c9a5be1a6c.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("VerticalContentAlignment");
                    var RelativeSource_bed54c093e714b50a3dfde8f22d9eac7 = new Bridge.global.Windows.UI.Xaml.Data.RelativeSource.ctor();
                    RelativeSource_bed54c093e714b50a3dfde8f22d9eac7.Mode = Bridge.global.Windows.UI.Xaml.Data.RelativeSourceMode.TemplatedParent;

                    Binding_c755757a78b043758f2e14c9a5be1a6c.RelativeSource = RelativeSource_bed54c093e714b50a3dfde8f22d9eac7;


                    Binding_c755757a78b043758f2e14c9a5be1a6c.TemplateOwner = templateInstance_2ef16e0a12a149cc9f25923250480508;

                    var Binding_3c03f87146744d5fa6d5523791b76246 = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_3c03f87146744d5fa6d5523791b76246.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("Visibility");



                    Border_fa43d1c3002c41818de067976eaf9969.Child = ContentPresenter_ddbf6d8c5504469db20966dacd51622c;

                    var Binding_9293c9929e424576891fbf38be474e35 = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_9293c9929e424576891fbf38be474e35.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("Background");
                    var RelativeSource_0cae9bb289c74adaa534895d67586932 = new Bridge.global.Windows.UI.Xaml.Data.RelativeSource.ctor();
                    RelativeSource_0cae9bb289c74adaa534895d67586932.Mode = Bridge.global.Windows.UI.Xaml.Data.RelativeSourceMode.TemplatedParent;

                    Binding_9293c9929e424576891fbf38be474e35.RelativeSource = RelativeSource_0cae9bb289c74adaa534895d67586932;


                    Binding_9293c9929e424576891fbf38be474e35.TemplateOwner = templateInstance_2ef16e0a12a149cc9f25923250480508;


                    Border_bbcbbf54c193472da82412c63e4f36ba.Child = Border_fa43d1c3002c41818de067976eaf9969;

                    var Binding_a89faad48b644673b9cffb416797962f = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_a89faad48b644673b9cffb416797962f.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("Background");
                    var RelativeSource_c8484b3335114ee2b63ec565f1e895cb = new Bridge.global.Windows.UI.Xaml.Data.RelativeSource.ctor();
                    RelativeSource_c8484b3335114ee2b63ec565f1e895cb.Mode = Bridge.global.Windows.UI.Xaml.Data.RelativeSourceMode.TemplatedParent;

                    Binding_a89faad48b644673b9cffb416797962f.RelativeSource = RelativeSource_c8484b3335114ee2b63ec565f1e895cb;


                    Binding_a89faad48b644673b9cffb416797962f.TemplateOwner = templateInstance_2ef16e0a12a149cc9f25923250480508;

                    var Binding_7bdec608316d4d619fd48e312765ed99 = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_7bdec608316d4d619fd48e312765ed99.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("BorderBrush");
                    var RelativeSource_e1a54a1046a8458cb2e68796464b4844 = new Bridge.global.Windows.UI.Xaml.Data.RelativeSource.ctor();
                    RelativeSource_e1a54a1046a8458cb2e68796464b4844.Mode = Bridge.global.Windows.UI.Xaml.Data.RelativeSourceMode.TemplatedParent;

                    Binding_7bdec608316d4d619fd48e312765ed99.RelativeSource = RelativeSource_e1a54a1046a8458cb2e68796464b4844;


                    Binding_7bdec608316d4d619fd48e312765ed99.TemplateOwner = templateInstance_2ef16e0a12a149cc9f25923250480508;

                    var Binding_70cfe35905754e3d9ff9c5c5908d25d1 = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_70cfe35905754e3d9ff9c5c5908d25d1.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("BorderThickness");
                    var RelativeSource_acc688b255eb45ff97223d149e70487f = new Bridge.global.Windows.UI.Xaml.Data.RelativeSource.ctor();
                    RelativeSource_acc688b255eb45ff97223d149e70487f.Mode = Bridge.global.Windows.UI.Xaml.Data.RelativeSourceMode.TemplatedParent;

                    Binding_70cfe35905754e3d9ff9c5c5908d25d1.RelativeSource = RelativeSource_acc688b255eb45ff97223d149e70487f;


                    Binding_70cfe35905754e3d9ff9c5c5908d25d1.TemplateOwner = templateInstance_2ef16e0a12a149cc9f25923250480508;

                    var Binding_a55176bbfe844ec6bf72bbb16d2bb54f = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_a55176bbfe844ec6bf72bbb16d2bb54f.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("Margin");
                    var RelativeSource_fc4f888df0294909b59063cb30fe5c54 = new Bridge.global.Windows.UI.Xaml.Data.RelativeSource.ctor();
                    RelativeSource_fc4f888df0294909b59063cb30fe5c54.Mode = Bridge.global.Windows.UI.Xaml.Data.RelativeSourceMode.TemplatedParent;

                    Binding_a55176bbfe844ec6bf72bbb16d2bb54f.RelativeSource = RelativeSource_fc4f888df0294909b59063cb30fe5c54;


                    Binding_a55176bbfe844ec6bf72bbb16d2bb54f.TemplateOwner = templateInstance_2ef16e0a12a149cc9f25923250480508;

                    var Binding_13b617237386481e88f0e30c027b28d8 = new Bridge.global.Windows.UI.Xaml.Data.Binding.ctor();
                    Binding_13b617237386481e88f0e30c027b28d8.Path = new Bridge.global.Windows.UI.Xaml.PropertyPath.ctor("Visibility");



                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(ContentPresenter_ddbf6d8c5504469db20966dacd51622c, Bridge.global.Windows.UI.Xaml.Controls.ContentControl.ContentTemplateProperty, Binding_7cca7d7a420f4a6fbfba8440212af700);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(ContentPresenter_ddbf6d8c5504469db20966dacd51622c, Bridge.global.Windows.UI.Xaml.Controls.ContentControl.ContentProperty, Binding_084289f1b2754a3a975fd894a03dd618);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(ContentPresenter_ddbf6d8c5504469db20966dacd51622c, Bridge.global.Windows.UI.Xaml.FrameworkElement.HeightProperty, Binding_4a1b934b647140cfb4c9aaf32c3c40f8);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(ContentPresenter_ddbf6d8c5504469db20966dacd51622c, Bridge.global.Windows.UI.Xaml.FrameworkElement.WidthProperty, Binding_77519d5dcd704991adf6626a74838ce1);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(ContentPresenter_ddbf6d8c5504469db20966dacd51622c, Bridge.global.Windows.UI.Xaml.FrameworkElement.MarginProperty, Binding_530389b27e60405abd06cbf6e23ae849);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(ContentPresenter_ddbf6d8c5504469db20966dacd51622c, Bridge.global.Windows.UI.Xaml.FrameworkElement.HorizontalAlignmentProperty, Binding_c9b3ac70d682443ba6310708347a7d83);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(ContentPresenter_ddbf6d8c5504469db20966dacd51622c, Bridge.global.Windows.UI.Xaml.FrameworkElement.VerticalAlignmentProperty, Binding_c755757a78b043758f2e14c9a5be1a6c);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(ContentPresenter_ddbf6d8c5504469db20966dacd51622c, Bridge.global.Windows.UI.Xaml.UIElement.VisibilityProperty, Binding_3c03f87146744d5fa6d5523791b76246);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(Border_fa43d1c3002c41818de067976eaf9969, Bridge.global.Windows.UI.Xaml.Controls.Border.BackgroundProperty, Binding_9293c9929e424576891fbf38be474e35);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(Border_bbcbbf54c193472da82412c63e4f36ba, Bridge.global.Windows.UI.Xaml.Controls.Border.BackgroundProperty, Binding_a89faad48b644673b9cffb416797962f);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(Border_bbcbbf54c193472da82412c63e4f36ba, Bridge.global.Windows.UI.Xaml.Controls.Border.BorderBrushProperty, Binding_7bdec608316d4d619fd48e312765ed99);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(Border_bbcbbf54c193472da82412c63e4f36ba, Bridge.global.Windows.UI.Xaml.Controls.Border.BorderThicknessProperty, Binding_70cfe35905754e3d9ff9c5c5908d25d1);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(Border_bbcbbf54c193472da82412c63e4f36ba, Bridge.global.Windows.UI.Xaml.FrameworkElement.MarginProperty, Binding_a55176bbfe844ec6bf72bbb16d2bb54f);
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(Border_bbcbbf54c193472da82412c63e4f36ba, Bridge.global.Windows.UI.Xaml.UIElement.VisibilityProperty, Binding_13b617237386481e88f0e30c027b28d8);

                    Bridge.global.Windows.UI.Xaml.Media.Animation.Storyboard.SetTargetProperty(ObjectAnimationUsingKeyFrames_07d755ef8ffa464fadb819f4b2b70d3c, new Bridge.global.Windows.UI.Xaml.PropertyPath.$ctor2("Background", "Background", Bridge.fn.cacheBind(this, this.accessVisualStateProperty_994e2cce58bd44938e7e313f9a9e1fc7), Bridge.fn.cacheBind(this, this.setVisualStateProperty_994e2cce58bd44938e7e313f9a9e1fc7), Bridge.fn.cacheBind(this, this.setAnimationVisualStateProperty_994e2cce58bd44938e7e313f9a9e1fc7), Bridge.fn.cacheBind(this, this.setLocalVisualStateProperty_994e2cce58bd44938e7e313f9a9e1fc7), Bridge.fn.cacheBind(this, this.getVisualStateProperty_994e2cce58bd44938e7e313f9a9e1fc7)));
                    Bridge.global.Windows.UI.Xaml.Media.Animation.Storyboard.SetTarget(ObjectAnimationUsingKeyFrames_07d755ef8ffa464fadb819f4b2b70d3c, Border_fa43d1c3002c41818de067976eaf9969);


                    Bridge.global.Windows.UI.Xaml.Media.Animation.Storyboard.SetTargetProperty(ObjectAnimationUsingKeyFrames_e7aa6b678c484cc9ae375dbfb1f04788, new Bridge.global.Windows.UI.Xaml.PropertyPath.$ctor2("Background", "Background", Bridge.fn.cacheBind(this, this.accessVisualStateProperty_c6146117f82745129e1aa381d80f5a59), Bridge.fn.cacheBind(this, this.setVisualStateProperty_c6146117f82745129e1aa381d80f5a59), Bridge.fn.cacheBind(this, this.setAnimationVisualStateProperty_c6146117f82745129e1aa381d80f5a59), Bridge.fn.cacheBind(this, this.setLocalVisualStateProperty_c6146117f82745129e1aa381d80f5a59), Bridge.fn.cacheBind(this, this.getVisualStateProperty_c6146117f82745129e1aa381d80f5a59)));
                    Bridge.global.Windows.UI.Xaml.Media.Animation.Storyboard.SetTarget(ObjectAnimationUsingKeyFrames_e7aa6b678c484cc9ae375dbfb1f04788, Border_fa43d1c3002c41818de067976eaf9969);


                    Bridge.global.Windows.UI.Xaml.Media.Animation.Storyboard.SetTargetProperty(ObjectAnimationUsingKeyFrames_cf7e4002e3054a6591af257bc122e9b0, new Bridge.global.Windows.UI.Xaml.PropertyPath.$ctor2("Background", "Background", Bridge.fn.cacheBind(this, this.accessVisualStateProperty_c372948182bb40bd83c5430b57a77e75), Bridge.fn.cacheBind(this, this.setVisualStateProperty_c372948182bb40bd83c5430b57a77e75), Bridge.fn.cacheBind(this, this.setAnimationVisualStateProperty_c372948182bb40bd83c5430b57a77e75), Bridge.fn.cacheBind(this, this.setLocalVisualStateProperty_c372948182bb40bd83c5430b57a77e75), Bridge.fn.cacheBind(this, this.getVisualStateProperty_c372948182bb40bd83c5430b57a77e75)));
                    Bridge.global.Windows.UI.Xaml.Media.Animation.Storyboard.SetTarget(ObjectAnimationUsingKeyFrames_cf7e4002e3054a6591af257bc122e9b0, Border_fa43d1c3002c41818de067976eaf9969);

                    templateInstance_2ef16e0a12a149cc9f25923250480508.TemplateContent = Border_bbcbbf54c193472da82412c63e4f36ba;
                    return templateInstance_2ef16e0a12a149cc9f25923250480508;
                }));

                Setter_8e60114318314fe88e1a0e34b31cad87.Value = ControlTemplate_b5218792e0e647e39fc9127de57db2e8;


                Style_fa0e517d37804d5190953e5380c27e2f.Setters.add(Setter_2ddf5100cdac48fa9e0c3065007398ca);
                Style_fa0e517d37804d5190953e5380c27e2f.Setters.add(Setter_aea9e49a02144474b4662ed884843c61);
                Style_fa0e517d37804d5190953e5380c27e2f.Setters.add(Setter_d6bf888fea0743ca965419fb1d8e32bd);
                Style_fa0e517d37804d5190953e5380c27e2f.Setters.add(Setter_d794a7ac2bd34d90a34c87ea46359fb5);
                Style_fa0e517d37804d5190953e5380c27e2f.Setters.add(Setter_1a579a2dda284b3b94cf2a3e229adf87);
                Style_fa0e517d37804d5190953e5380c27e2f.Setters.add(Setter_2b0d25adbe054057bcbf25e38f8803cd);
                Style_fa0e517d37804d5190953e5380c27e2f.Setters.add(Setter_b5f54b29a41d4d8cbcbdb92d2fed3dcc);
                Style_fa0e517d37804d5190953e5380c27e2f.Setters.add(Setter_8e60114318314fe88e1a0e34b31cad87);


                ResourceDictionary_f0f6431f17fe45cfb188b8b226b54cd4.setItem("IntConverter", IntConverter_0ced125350c44e87a3abeb00c9cc7e71);
                ResourceDictionary_f0f6431f17fe45cfb188b8b226b54cd4.setItem("DecConverter", DecConverter_cbd2974fe389434cb2ae15bb750485ad);
                ResourceDictionary_f0f6431f17fe45cfb188b8b226b54cd4.setItem("ToPolyLineConverter", ToPolyLineConverter_010c4ee2e4a1401daa5a265bff291dca);
                ResourceDictionary_f0f6431f17fe45cfb188b8b226b54cd4.setItem("ToPointsConverter", ToPointsConverter_cb39497248e34d20b2e28c682e719cbd);
                ResourceDictionary_f0f6431f17fe45cfb188b8b226b54cd4.setItem("ToLinesConverter", ToLinesConverter_649241e4ac3a4803ad664d5f0c718548);
                ResourceDictionary_f0f6431f17fe45cfb188b8b226b54cd4.setItem("APLColorConverter", APLColorConverter_17e61e369a4f46be9d4808056623c82d);
                ResourceDictionary_f0f6431f17fe45cfb188b8b226b54cd4.setItem("APLColorCSSConverter", APLColorCSSConverter_f5422057ce2647179fbd8fa449a19eff);
                ResourceDictionary_f0f6431f17fe45cfb188b8b226b54cd4.setItem("APLMultiColorConverter", APLMultiColorConverter_6433445fb71f4c6bb1c8e6389f095f8f);
                ResourceDictionary_f0f6431f17fe45cfb188b8b226b54cd4.setItem("APLMultiColorCSSConverter", APLMultiColorCSSConverter_b08c25416fa84cdeb21e5d7ae563655c);
                ResourceDictionary_f0f6431f17fe45cfb188b8b226b54cd4.setItem("IndexInt32Converter", IndexInt32Converter_ba2f4d069b0740cb9b396c9fb1dd1e1c);
                ResourceDictionary_f0f6431f17fe45cfb188b8b226b54cd4.setItem("IndexDoubleConverter", IndexDoubleConverter_53953ccfbd2940e48d229d97ba087659);
                ResourceDictionary_f0f6431f17fe45cfb188b8b226b54cd4.setItem("IndexStringConverter", IndexStringConverter_629c1f18785e4fc89e1725adf7f4eab9);
                ResourceDictionary_f0f6431f17fe45cfb188b8b226b54cd4.setItem("IndexAPLColorConverter", IndexAPLColorConverter_f40c7adacf8049afac99a69da7170750);
                ResourceDictionary_f0f6431f17fe45cfb188b8b226b54cd4.setItem("IndexAPLColourConverter", IndexAPLColourConverter_accde457823748449854fe2e33812be0);
                ResourceDictionary_f0f6431f17fe45cfb188b8b226b54cd4.setItem("MathsIConverter", MathsIConverter_38e1946605fd44c1bd11e1aeec242018);
                ResourceDictionary_f0f6431f17fe45cfb188b8b226b54cd4.setItem("MathsDConverter", MathsDConverter_260170684c4a43bbb3e84c1f00b74cd3);
                ResourceDictionary_f0f6431f17fe45cfb188b8b226b54cd4.setItem("MathIConverter", MathIConverter_ccdc3835062f454d84dc760560f472da);
                ResourceDictionary_f0f6431f17fe45cfb188b8b226b54cd4.setItem("MathDConverter", MathDConverter_754fbf8e1d4b4a65b359d723ec5f1402);
                ResourceDictionary_f0f6431f17fe45cfb188b8b226b54cd4.setItem("Application", String_31127a7defaf406c8052127e7d6167fe);
                ResourceDictionary_f0f6431f17fe45cfb188b8b226b54cd4.setItem("Owner", String_c401ba1fda2746f1a326e7fa78b68255);
                ResourceDictionary_f0f6431f17fe45cfb188b8b226b54cd4.setItem("Company", String_35c2e9d4af574621b312ddab4e3332a6);
                ResourceDictionary_f0f6431f17fe45cfb188b8b226b54cd4.setItem("Name", String_e5eaa9b1f49547568eb87dddc4e87cb6);
                ResourceDictionary_f0f6431f17fe45cfb188b8b226b54cd4.setItem("Title", String_01ce0d3a4ff644368a89fd66acf162ff);
                ResourceDictionary_f0f6431f17fe45cfb188b8b226b54cd4.setItem("FavIcon", String_7c2d3149a3704915b16ddab07adf2f95);
                ResourceDictionary_f0f6431f17fe45cfb188b8b226b54cd4.setItem("Port", String_e7967a2244144410b309c737728e29ab);
                ResourceDictionary_f0f6431f17fe45cfb188b8b226b54cd4.setItem("Main", String_73dedcb310934dad9a36c7ef9486918c);
                ResourceDictionary_f0f6431f17fe45cfb188b8b226b54cd4.setItem("Base", String_3f66494d08714817bd15e38b308a9eb4);
                ResourceDictionary_f0f6431f17fe45cfb188b8b226b54cd4.setItem("ConnectionType", String_e00f22a326bc4581b497b884462964f8);
                ResourceDictionary_f0f6431f17fe45cfb188b8b226b54cd4.setItem("Namespace", String_53d60dfcf3e141d2b73b8892b3d5a1c0);
                ResourceDictionary_f0f6431f17fe45cfb188b8b226b54cd4.setItem("APLFormStyle", Style_22a1bded031a475aa15539342ec96021);
                ResourceDictionary_f0f6431f17fe45cfb188b8b226b54cd4.setItem("ButtonStyle1", Style_fa0e517d37804d5190953e5380c27e2f);

                this.Resources = ResourceDictionary_f0f6431f17fe45cfb188b8b226b54cd4;







            },
            accessVisualStateProperty_102b70d6f91b4503ac2189d2296baa61: function (rootTargetObjectInstance) {
                return new (Bridge.GeneratorEnumerable$1(System.Tuple$3(Windows.UI.Xaml.DependencyObject,Windows.UI.Xaml.DependencyProperty,System.Nullable$1(System.Int32))))(Bridge.fn.bind(this, function (rootTargetObjectInstance) {
                    var $step = 0,
                        $jumpFromFinally,
                        $returnValue,
                        $async_e;

                    var $enumerator = new (Bridge.GeneratorEnumerator$1(System.Tuple$3(Windows.UI.Xaml.DependencyObject,Windows.UI.Xaml.DependencyProperty,System.Nullable$1(System.Int32))))(Bridge.fn.bind(this, function () {
                        try {
                            for (;;) {
                                switch ($step) {
                                    case 0: {
                                        return false;
                                    }
                                    default: {
                                        return false;
                                    }
                                }
                            }
                        } catch($async_e1) {
                            $async_e = System.Exception.create($async_e1);
                            throw $async_e;
                        }
                    }));
                    return $enumerator;
                }, arguments));
            },
            setVisualStateProperty_102b70d6f91b4503ac2189d2296baa61: function (finalTargetInstance, value) {

                var finalTargetInstanceType = Bridge.getType(finalTargetInstance);
                var propertyDeclaringType = Bridge.Reflection.getMembers(finalTargetInstanceType, 16, 284, "Background").td;
                var propertyField = Bridge.Reflection.getMembers(propertyDeclaringType, 4, 284, "BackgroundProperty");
                var property = Bridge.cast(Bridge.Reflection.fieldAccess(propertyField, null), Windows.UI.Xaml.DependencyProperty);

                (finalTargetInstance).SetVisualStateValue(property, value);
            },
            setAnimationVisualStateProperty_102b70d6f91b4503ac2189d2296baa61: function (finalTargetInstance, value) {

                var finalTargetInstanceType = Bridge.getType(finalTargetInstance);
                var propertyDeclaringType = Bridge.Reflection.getMembers(finalTargetInstanceType, 16, 284, "Background").td;
                var propertyField = Bridge.Reflection.getMembers(propertyDeclaringType, 4, 284, "BackgroundProperty");
                var property = Bridge.cast(Bridge.Reflection.fieldAccess(propertyField, null), Windows.UI.Xaml.DependencyProperty);

                (finalTargetInstance).SetAnimationValue(property, value);
            },
            setLocalVisualStateProperty_102b70d6f91b4503ac2189d2296baa61: function (finalTargetInstance, value) {

                var finalTargetInstanceType = Bridge.getType(finalTargetInstance);
                var propertyDeclaringType = Bridge.Reflection.getMembers(finalTargetInstanceType, 16, 284, "Background").td;
                var propertyField = Bridge.Reflection.getMembers(propertyDeclaringType, 4, 284, "BackgroundProperty");
                var property = Bridge.cast(Bridge.Reflection.fieldAccess(propertyField, null), Windows.UI.Xaml.DependencyProperty);

                (finalTargetInstance).SetCurrentValue(property, value);
            },
            getVisualStateProperty_102b70d6f91b4503ac2189d2296baa61: function (finalTargetInstance) {

                var finalTargetInstanceType = Bridge.getType(finalTargetInstance);
                var propertyDeclaringType = Bridge.Reflection.getMembers(finalTargetInstanceType, 16, 284, "Background").td;
                var propertyField = Bridge.Reflection.getMembers(propertyDeclaringType, 4, 284, "BackgroundProperty");
                var property = Bridge.cast(Bridge.Reflection.fieldAccess(propertyField, null), Windows.UI.Xaml.DependencyProperty);

                return finalTargetInstance.GetVisualStateValue(property);
            },
            accessVisualStateProperty_aedcb8f5e792431c8f34691afcc4b62c: function (rootTargetObjectInstance) {
                return new (Bridge.GeneratorEnumerable$1(System.Tuple$3(Windows.UI.Xaml.DependencyObject,Windows.UI.Xaml.DependencyProperty,System.Nullable$1(System.Int32))))(Bridge.fn.bind(this, function (rootTargetObjectInstance) {
                    var $step = 0,
                        $jumpFromFinally,
                        $returnValue,
                        $async_e;

                    var $enumerator = new (Bridge.GeneratorEnumerator$1(System.Tuple$3(Windows.UI.Xaml.DependencyObject,Windows.UI.Xaml.DependencyProperty,System.Nullable$1(System.Int32))))(Bridge.fn.bind(this, function () {
                        try {
                            for (;;) {
                                switch ($step) {
                                    case 0: {
                                        return false;
                                    }
                                    default: {
                                        return false;
                                    }
                                }
                            }
                        } catch($async_e1) {
                            $async_e = System.Exception.create($async_e1);
                            throw $async_e;
                        }
                    }));
                    return $enumerator;
                }, arguments));
            },
            setVisualStateProperty_aedcb8f5e792431c8f34691afcc4b62c: function (finalTargetInstance, value) {

                var finalTargetInstanceType = Bridge.getType(finalTargetInstance);
                var propertyDeclaringType = Bridge.Reflection.getMembers(finalTargetInstanceType, 16, 284, "IsHitTestVisible").td;
                var propertyField = Bridge.Reflection.getMembers(propertyDeclaringType, 4, 284, "IsHitTestVisibleProperty");
                var property = Bridge.cast(Bridge.Reflection.fieldAccess(propertyField, null), Windows.UI.Xaml.DependencyProperty);

                (finalTargetInstance).SetVisualStateValue(property, value);
            },
            setAnimationVisualStateProperty_aedcb8f5e792431c8f34691afcc4b62c: function (finalTargetInstance, value) {

                var finalTargetInstanceType = Bridge.getType(finalTargetInstance);
                var propertyDeclaringType = Bridge.Reflection.getMembers(finalTargetInstanceType, 16, 284, "IsHitTestVisible").td;
                var propertyField = Bridge.Reflection.getMembers(propertyDeclaringType, 4, 284, "IsHitTestVisibleProperty");
                var property = Bridge.cast(Bridge.Reflection.fieldAccess(propertyField, null), Windows.UI.Xaml.DependencyProperty);

                (finalTargetInstance).SetAnimationValue(property, value);
            },
            setLocalVisualStateProperty_aedcb8f5e792431c8f34691afcc4b62c: function (finalTargetInstance, value) {

                var finalTargetInstanceType = Bridge.getType(finalTargetInstance);
                var propertyDeclaringType = Bridge.Reflection.getMembers(finalTargetInstanceType, 16, 284, "IsHitTestVisible").td;
                var propertyField = Bridge.Reflection.getMembers(propertyDeclaringType, 4, 284, "IsHitTestVisibleProperty");
                var property = Bridge.cast(Bridge.Reflection.fieldAccess(propertyField, null), Windows.UI.Xaml.DependencyProperty);

                (finalTargetInstance).SetCurrentValue(property, value);
            },
            getVisualStateProperty_aedcb8f5e792431c8f34691afcc4b62c: function (finalTargetInstance) {

                var finalTargetInstanceType = Bridge.getType(finalTargetInstance);
                var propertyDeclaringType = Bridge.Reflection.getMembers(finalTargetInstanceType, 16, 284, "IsHitTestVisible").td;
                var propertyField = Bridge.Reflection.getMembers(propertyDeclaringType, 4, 284, "IsHitTestVisibleProperty");
                var property = Bridge.cast(Bridge.Reflection.fieldAccess(propertyField, null), Windows.UI.Xaml.DependencyProperty);

                return finalTargetInstance.GetVisualStateValue(property);
            },
            accessVisualStateProperty_994e2cce58bd44938e7e313f9a9e1fc7: function (rootTargetObjectInstance) {
                return new (Bridge.GeneratorEnumerable$1(System.Tuple$3(Windows.UI.Xaml.DependencyObject,Windows.UI.Xaml.DependencyProperty,System.Nullable$1(System.Int32))))(Bridge.fn.bind(this, function (rootTargetObjectInstance) {
                    var $step = 0,
                        $jumpFromFinally,
                        $returnValue,
                        $async_e;

                    var $enumerator = new (Bridge.GeneratorEnumerator$1(System.Tuple$3(Windows.UI.Xaml.DependencyObject,Windows.UI.Xaml.DependencyProperty,System.Nullable$1(System.Int32))))(Bridge.fn.bind(this, function () {
                        try {
                            for (;;) {
                                switch ($step) {
                                    case 0: {
                                        return false;
                                    }
                                    default: {
                                        return false;
                                    }
                                }
                            }
                        } catch($async_e1) {
                            $async_e = System.Exception.create($async_e1);
                            throw $async_e;
                        }
                    }));
                    return $enumerator;
                }, arguments));
            },
            setVisualStateProperty_994e2cce58bd44938e7e313f9a9e1fc7: function (finalTargetInstance, value) {

                var finalTargetInstanceType = Bridge.getType(finalTargetInstance);
                var propertyDeclaringType = Bridge.Reflection.getMembers(finalTargetInstanceType, 16, 284, "Background").td;
                var propertyField = Bridge.Reflection.getMembers(propertyDeclaringType, 4, 284, "BackgroundProperty");
                var property = Bridge.cast(Bridge.Reflection.fieldAccess(propertyField, null), Windows.UI.Xaml.DependencyProperty);

                (finalTargetInstance).SetVisualStateValue(property, value);
            },
            setAnimationVisualStateProperty_994e2cce58bd44938e7e313f9a9e1fc7: function (finalTargetInstance, value) {

                var finalTargetInstanceType = Bridge.getType(finalTargetInstance);
                var propertyDeclaringType = Bridge.Reflection.getMembers(finalTargetInstanceType, 16, 284, "Background").td;
                var propertyField = Bridge.Reflection.getMembers(propertyDeclaringType, 4, 284, "BackgroundProperty");
                var property = Bridge.cast(Bridge.Reflection.fieldAccess(propertyField, null), Windows.UI.Xaml.DependencyProperty);

                (finalTargetInstance).SetAnimationValue(property, value);
            },
            setLocalVisualStateProperty_994e2cce58bd44938e7e313f9a9e1fc7: function (finalTargetInstance, value) {

                var finalTargetInstanceType = Bridge.getType(finalTargetInstance);
                var propertyDeclaringType = Bridge.Reflection.getMembers(finalTargetInstanceType, 16, 284, "Background").td;
                var propertyField = Bridge.Reflection.getMembers(propertyDeclaringType, 4, 284, "BackgroundProperty");
                var property = Bridge.cast(Bridge.Reflection.fieldAccess(propertyField, null), Windows.UI.Xaml.DependencyProperty);

                (finalTargetInstance).SetCurrentValue(property, value);
            },
            getVisualStateProperty_994e2cce58bd44938e7e313f9a9e1fc7: function (finalTargetInstance) {

                var finalTargetInstanceType = Bridge.getType(finalTargetInstance);
                var propertyDeclaringType = Bridge.Reflection.getMembers(finalTargetInstanceType, 16, 284, "Background").td;
                var propertyField = Bridge.Reflection.getMembers(propertyDeclaringType, 4, 284, "BackgroundProperty");
                var property = Bridge.cast(Bridge.Reflection.fieldAccess(propertyField, null), Windows.UI.Xaml.DependencyProperty);

                return finalTargetInstance.GetVisualStateValue(property);
            },
            accessVisualStateProperty_c6146117f82745129e1aa381d80f5a59: function (rootTargetObjectInstance) {
                return new (Bridge.GeneratorEnumerable$1(System.Tuple$3(Windows.UI.Xaml.DependencyObject,Windows.UI.Xaml.DependencyProperty,System.Nullable$1(System.Int32))))(Bridge.fn.bind(this, function (rootTargetObjectInstance) {
                    var $step = 0,
                        $jumpFromFinally,
                        $returnValue,
                        $async_e;

                    var $enumerator = new (Bridge.GeneratorEnumerator$1(System.Tuple$3(Windows.UI.Xaml.DependencyObject,Windows.UI.Xaml.DependencyProperty,System.Nullable$1(System.Int32))))(Bridge.fn.bind(this, function () {
                        try {
                            for (;;) {
                                switch ($step) {
                                    case 0: {
                                        return false;
                                    }
                                    default: {
                                        return false;
                                    }
                                }
                            }
                        } catch($async_e1) {
                            $async_e = System.Exception.create($async_e1);
                            throw $async_e;
                        }
                    }));
                    return $enumerator;
                }, arguments));
            },
            setVisualStateProperty_c6146117f82745129e1aa381d80f5a59: function (finalTargetInstance, value) {

                var finalTargetInstanceType = Bridge.getType(finalTargetInstance);
                var propertyDeclaringType = Bridge.Reflection.getMembers(finalTargetInstanceType, 16, 284, "Background").td;
                var propertyField = Bridge.Reflection.getMembers(propertyDeclaringType, 4, 284, "BackgroundProperty");
                var property = Bridge.cast(Bridge.Reflection.fieldAccess(propertyField, null), Windows.UI.Xaml.DependencyProperty);

                (finalTargetInstance).SetVisualStateValue(property, value);
            },
            setAnimationVisualStateProperty_c6146117f82745129e1aa381d80f5a59: function (finalTargetInstance, value) {

                var finalTargetInstanceType = Bridge.getType(finalTargetInstance);
                var propertyDeclaringType = Bridge.Reflection.getMembers(finalTargetInstanceType, 16, 284, "Background").td;
                var propertyField = Bridge.Reflection.getMembers(propertyDeclaringType, 4, 284, "BackgroundProperty");
                var property = Bridge.cast(Bridge.Reflection.fieldAccess(propertyField, null), Windows.UI.Xaml.DependencyProperty);

                (finalTargetInstance).SetAnimationValue(property, value);
            },
            setLocalVisualStateProperty_c6146117f82745129e1aa381d80f5a59: function (finalTargetInstance, value) {

                var finalTargetInstanceType = Bridge.getType(finalTargetInstance);
                var propertyDeclaringType = Bridge.Reflection.getMembers(finalTargetInstanceType, 16, 284, "Background").td;
                var propertyField = Bridge.Reflection.getMembers(propertyDeclaringType, 4, 284, "BackgroundProperty");
                var property = Bridge.cast(Bridge.Reflection.fieldAccess(propertyField, null), Windows.UI.Xaml.DependencyProperty);

                (finalTargetInstance).SetCurrentValue(property, value);
            },
            getVisualStateProperty_c6146117f82745129e1aa381d80f5a59: function (finalTargetInstance) {

                var finalTargetInstanceType = Bridge.getType(finalTargetInstance);
                var propertyDeclaringType = Bridge.Reflection.getMembers(finalTargetInstanceType, 16, 284, "Background").td;
                var propertyField = Bridge.Reflection.getMembers(propertyDeclaringType, 4, 284, "BackgroundProperty");
                var property = Bridge.cast(Bridge.Reflection.fieldAccess(propertyField, null), Windows.UI.Xaml.DependencyProperty);

                return finalTargetInstance.GetVisualStateValue(property);
            },
            accessVisualStateProperty_c372948182bb40bd83c5430b57a77e75: function (rootTargetObjectInstance) {
                return new (Bridge.GeneratorEnumerable$1(System.Tuple$3(Windows.UI.Xaml.DependencyObject,Windows.UI.Xaml.DependencyProperty,System.Nullable$1(System.Int32))))(Bridge.fn.bind(this, function (rootTargetObjectInstance) {
                    var $step = 0,
                        $jumpFromFinally,
                        $returnValue,
                        $async_e;

                    var $enumerator = new (Bridge.GeneratorEnumerator$1(System.Tuple$3(Windows.UI.Xaml.DependencyObject,Windows.UI.Xaml.DependencyProperty,System.Nullable$1(System.Int32))))(Bridge.fn.bind(this, function () {
                        try {
                            for (;;) {
                                switch ($step) {
                                    case 0: {
                                        return false;
                                    }
                                    default: {
                                        return false;
                                    }
                                }
                            }
                        } catch($async_e1) {
                            $async_e = System.Exception.create($async_e1);
                            throw $async_e;
                        }
                    }));
                    return $enumerator;
                }, arguments));
            },
            setVisualStateProperty_c372948182bb40bd83c5430b57a77e75: function (finalTargetInstance, value) {

                var finalTargetInstanceType = Bridge.getType(finalTargetInstance);
                var propertyDeclaringType = Bridge.Reflection.getMembers(finalTargetInstanceType, 16, 284, "Background").td;
                var propertyField = Bridge.Reflection.getMembers(propertyDeclaringType, 4, 284, "BackgroundProperty");
                var property = Bridge.cast(Bridge.Reflection.fieldAccess(propertyField, null), Windows.UI.Xaml.DependencyProperty);

                (finalTargetInstance).SetVisualStateValue(property, value);
            },
            setAnimationVisualStateProperty_c372948182bb40bd83c5430b57a77e75: function (finalTargetInstance, value) {

                var finalTargetInstanceType = Bridge.getType(finalTargetInstance);
                var propertyDeclaringType = Bridge.Reflection.getMembers(finalTargetInstanceType, 16, 284, "Background").td;
                var propertyField = Bridge.Reflection.getMembers(propertyDeclaringType, 4, 284, "BackgroundProperty");
                var property = Bridge.cast(Bridge.Reflection.fieldAccess(propertyField, null), Windows.UI.Xaml.DependencyProperty);

                (finalTargetInstance).SetAnimationValue(property, value);
            },
            setLocalVisualStateProperty_c372948182bb40bd83c5430b57a77e75: function (finalTargetInstance, value) {

                var finalTargetInstanceType = Bridge.getType(finalTargetInstance);
                var propertyDeclaringType = Bridge.Reflection.getMembers(finalTargetInstanceType, 16, 284, "Background").td;
                var propertyField = Bridge.Reflection.getMembers(propertyDeclaringType, 4, 284, "BackgroundProperty");
                var property = Bridge.cast(Bridge.Reflection.fieldAccess(propertyField, null), Windows.UI.Xaml.DependencyProperty);

                (finalTargetInstance).SetCurrentValue(property, value);
            },
            getVisualStateProperty_c372948182bb40bd83c5430b57a77e75: function (finalTargetInstance) {

                var finalTargetInstanceType = Bridge.getType(finalTargetInstance);
                var propertyDeclaringType = Bridge.Reflection.getMembers(finalTargetInstanceType, 16, 284, "Background").td;
                var propertyField = Bridge.Reflection.getMembers(propertyDeclaringType, 4, 284, "BackgroundProperty");
                var property = Bridge.cast(Bridge.Reflection.fieldAccess(propertyField, null), Windows.UI.Xaml.DependencyProperty);

                return finalTargetInstance.GetVisualStateValue(property);
            }
        }
    });

    Bridge.define("QWC.MainPage", {
        inherits: [Windows.UI.Xaml.Controls.Page],
        fields: {
            filesReady: null,
            webSocketReady: null,
            webSocket: null,
            directwebSocket: null,
            connection: null,
            connectionport: null,
            AllReady: false,
            SetupCompleteRun: false,
            QWCGrid: null,
            QWCIcons: null,
            QWCHidden: null,
            QWCSideBars: null,
            Top: null,
            _contentLoaded: false
        },
        props: {
            FilesReady: {
                get: function () {
                    return this.filesReady.task;
                }
            },
            WebSocketReady: {
                get: function () {
                    return this.webSocketReady.task;
                }
            }
        },
        ctors: {
            init: function () {
                this.filesReady = new System.Threading.Tasks.TaskCompletionSource();
                this.webSocketReady = new System.Threading.Tasks.TaskCompletionSource();
                this.connection = "";
                this.connectionport = "";
                this.AllReady = false;
                this.SetupCompleteRun = false;
            },
            ctor: function () {
                this.$initialize();
                Windows.UI.Xaml.Controls.Page.ctor.call(this);
                this.RunRestMain();
            }
        },
        methods: {
            AddFileLoading: function () {
                mjh_filesloaded.value += 1;
                var FilesLoaded = System.Nullable.getValue(Bridge.cast(Bridge.unbox(mjh_filesloaded.value, System.Int32), System.Int32));
                var TotalFilesToBeLoaded = System.Nullable.getValue(Bridge.cast(Bridge.unbox(mjh_filesloaded.total, System.Int32), System.Int32));
                if (FilesLoaded === TotalFilesToBeLoaded) {
                    var x = this.filesReady.trySetResult(true);
                }
                ;
            },
            CheckFileLoading: function () {
                var FilesLoaded = System.Nullable.getValue(Bridge.cast(Bridge.unbox(mjh_filesloaded.value, System.Int32), System.Int32));
                var TotalFilesToBeLoaded = System.Nullable.getValue(Bridge.cast(Bridge.unbox(mjh_filesloaded.total, System.Int32), System.Int32));
                if (FilesLoaded === TotalFilesToBeLoaded) {
                    var x = this.filesReady.trySetResult(true);
                }
                ;
            },
            EndCustomCSS: function () {
                var runflg = System.Nullable.getValue(Bridge.cast(Bridge.unbox(('undefined' !=typeof ej &&  'undefined' != typeof ej.base), System.Boolean), System.Boolean));
                if (runflg) {
                    ej.base.enableRipple(false);
                }
            },
            RunRestMain: function () {
                window.addEventListener('beforeunload', Bridge.fn.cacheBind(this, this.OnBeforeUnload));
                Windows.UI.Xaml.Application.Current.Resources.setItem("MaxSerialNo", Bridge.box(0, System.Int32));
                Windows.UI.Xaml.Application.Current.Resources.setItem("FrameworkElement", this);
                Windows.UI.Xaml.Application.Current.Resources.setItem("AllReady", Bridge.box(this.AllReady, System.Boolean, System.Boolean.toString));
                var original = System.Windows.Browser.HtmlPage.Document.DocumentUri.getOriginalString();
                Windows.UI.Xaml.Application.Current.Resources.setItem("OriginalURL", original);
                var connection;
                var apps = APLExtension.Utils.GetAppsResource("QWC", "webdetails.html");
                connection = APLExtension.Utils.GetAppResource(apps, "Connection");
                if (0 === connection.length) {
                    connection = Bridge.cast(Windows.UI.Xaml.Application.Current.TryFindResource("Connection"), System.String);
                }
                var connectiontype = APLExtension.Utils.GetAppResource(apps, "ConnectionType");
                if (0 === connectiontype.length) {
                    connectiontype = Bridge.cast(Windows.UI.Xaml.Application.Current.TryFindResource("ConnectionType"), System.String);
                }
                var uploadhost = APLExtension.Utils.GetAppResource(apps, "UploadHost");
                if (null == uploadhost || 0 === uploadhost.length) {
                    uploadhost = Bridge.cast(Windows.UI.Xaml.Application.Current.TryFindResource("UploadHost"), System.String);
                    if (null == uploadhost || 0 === uploadhost.length) {
                        uploadhost = "localhost";
                    }
                }
                Windows.UI.Xaml.Application.Current.Resources.setItem("UploadHost", uploadhost);
                var uploadport = APLExtension.Utils.GetAppResource(apps, "UploadPort");
                if (null == uploadport || 0 === uploadport.length) {
                    uploadport = Bridge.cast(Windows.UI.Xaml.Application.Current.TryFindResource("UploadPort"), System.String);
                    if (null == uploadport || 0 === uploadport.length) {
                        uploadport = "1234";
                    }
                }
                Windows.UI.Xaml.Application.Current.Resources.setItem("UploadPort", uploadport);
                var uploadsecure = APLExtension.Utils.GetAppResource(apps, "UploadSecure");
                if (null == uploadsecure || 0 === uploadsecure.length) {
                    uploadsecure = Bridge.cast(Windows.UI.Xaml.Application.Current.TryFindResource("UploadSecure"), System.String);
                    if (null == uploadsecure || 0 === uploadsecure.length) {
                        uploadsecure = "0";
                    }
                }
                Windows.UI.Xaml.Application.Current.Resources.setItem("UploadSecure", uploadsecure);
                var name = APLExtension.Utils.GetAppResource(apps, "Name");
                if (0 === name.length) {
                    name = Bridge.cast(Windows.UI.Xaml.Application.Current.Resources.getItem("Name"), System.String);
                }
                var WSname = APLExtension.Utils.GetAppResource(apps, "WSName");
                if (0 === WSname.length) {
                    WSname = Bridge.cast(Windows.UI.Xaml.Application.Current.TryFindResource("WSName"), System.String);
                }
                var port = APLExtension.Utils.GetAppResource(apps, "Port");
                if (0 === port.length) {
                    port = Bridge.cast(Windows.UI.Xaml.Application.Current.TryFindResource("Port"), System.String);
                }
                if (null == WSname) {
                    WSname = "WS";
                }
                WSname = WSname.trim();
                if (Bridge.referenceEquals("", WSname)) {
                    WSname = "WS";
                }
                if (Bridge.referenceEquals(WSname.toUpperCase(), "NONE")) {
                    WSname = "";
                }
                if (null == connection) {
                    connection = "";
                }
                connection = connection.trim();
                if (null == connectiontype) {
                    connectiontype = "";
                }
                connectiontype = connectiontype.trim();
                if (Bridge.referenceEquals("", connectiontype)) {
                    connectiontype = "Direct";
                }
                if (Bridge.referenceEquals("", connection)) {
                    if (Bridge.referenceEquals("http", System.Windows.Browser.HtmlPage.Document.DocumentUri.getProtocol())) {
                        connection = System.Windows.Browser.HtmlPage.Document.DocumentUri.getHostName();
                    } else {
                        connection = "localhost";
                    }
                }
                var appname = APLExtension.Utils.GetAppResource(apps, "AppName");
                if (0 === appname.length) {
                    appname = Bridge.cast(Windows.UI.Xaml.Application.Current.TryFindResource("AppName"), System.String);
                }
                if (null == appname) {
                    appname = name;
                }
                if (Bridge.referenceEquals("", appname)) {
                    appname = name;
                }
                Windows.UI.Xaml.Application.Current.Resources.setItem("AppName", appname);
                if (Bridge.referenceEquals("Direct", connectiontype)) {
                    if (null == port) {
                        port = "";
                    }
                    var uri = Bridge.cast(document.location.search, System.String);
                    if (0 !== uri.length) {
                        var p = "";
                        for (var i = 0; i < uri.length; i = (i + 1) | 0) {
                            if (63 !== uri.charCodeAt(i)) {
                                if (48 === uri.charCodeAt(i) || 49 === uri.charCodeAt(i) || 50 === uri.charCodeAt(i) || 51 === uri.charCodeAt(i) || 52 === uri.charCodeAt(i) || 53 === uri.charCodeAt(i) || 54 === uri.charCodeAt(i) || 55 === uri.charCodeAt(i) || 56 === uri.charCodeAt(i) || 57 === uri.charCodeAt(i)) {
                                    p = (p || "") + String.fromCharCode(uri.charCodeAt(i));
                                } else {
                                    break;
                                }
                            }
                        }
                        if (0 !== p.length) {
                            port = p;
                        }
                    }
                    if (Bridge.referenceEquals("", port)) {
                        port = Bridge.toString(System.Windows.Browser.HtmlPage.Document.DocumentUri.getPort());
                    }
                    connection = (connection || "") + ((":" + (port || "") + "/" + (name || "") + "/") || "");
                } else {
                    if (0 !== connection.length) {
                        this.connectionport = APLExtension.Utils.GetAppResource(apps, "ConnectionPort");
                        if (this.connectionport == null || 0 === this.connectionport.length) {
                            this.connectionport = Bridge.cast(Windows.UI.Xaml.Application.Current.TryFindResource("ConnectionPort"), System.String);
                        }
                        if (this.connectionport != null && 0 !== this.connectionport.length) {
                            connection = (connection || "") + ((":" + (this.connectionport || "")) || "");
                        }
                    }
                    connection = (connection || "") + (("/" + (WSname || "")) || "");
                    if (0 !== WSname.length) {
                        connection = (connection || "") + "/";
                    }
                }
                var secureconnection = APLExtension.Utils.GetAppResource(apps, "SecureConnection");
                if (null == secureconnection || 0 === secureconnection.length) {
                    secureconnection = Bridge.cast(Windows.UI.Xaml.Application.Current.TryFindResource("SecureConnection"), System.String);
                    if (null == secureconnection || 0 === secureconnection.length) {
                        secureconnection = "0";
                    }
                }
                Windows.UI.Xaml.Application.Current.Resources.setItem("SecureConnection", secureconnection);
                if (Bridge.referenceEquals(secureconnection, "1")) {
                    connection = "wss://" + (connection || "");
                } else {
                    connection = "ws://" + (connection || "");
                }
                var _WSInternals = Bridge.as(APLExtension.APL.MakeInstance("DataBinding", "WSInternals", "WSInternals", this), DataBinding.WSInternals);
                var _qwc_Root = Bridge.as(APLExtension.APL.MakeInstance("DataBinding", "qwc_Root", "qwc_Root", this), DataBinding.qwc_Root);
                var rnd = new System.Random.ctor();
                var rnds = Bridge.toString(rnd.Next());
                this.webSocket = new CSHTML5.Extensions.WebSockets.WebSocket((connection || "") + "?hash=" + (rnds || ""));
                this.directwebSocket = new CSHTML5.Extensions.WebSockets.WebSocket((connection || "") + "?hash=" + (rnds || ""));
                Windows.UI.Xaml.Application.Current.Resources.setItem("WebSocket", this.webSocket);
                Windows.UI.Xaml.Application.Current.Resources.setItem("DirectWebSocket", this.directwebSocket);
                var xstring;
                var d = "";
                this.webSocket.addOnMessage(Bridge.fn.bind(this, function (s, e) {
                    var $step = 0,
                        $task1, 
                        $taskResult1, 
                        $jumpFromFinally, 
                        data, 
                        ds, 
                        trans, 
                        fullfont, 
                        f, 
                        elem, 
                        cl, 
                        o, 
                        assembly, 
                        type, 
                        ob, 
                        cl1, 
                        obj, 
                        assembly1, 
                        cl2, 
                        obj1, 
                        cla, 
                        method, 
                        $arguments, 
                        assembly2, 
                        cl3, 
                        obj2, 
                        cla1, 
                        method1, 
                        $arguments1, 
                        typecl, 
                        method11, 
                        $arguments2, 
                        NQresult, 
                        obj3, 
                        assembly3, 
                        type1, 
                        method2, 
                        $asyncBody = Bridge.fn.bind(this, function () {
                            for (;;) {
                                $step = System.Array.min([0,1,2,3], $step);
                                switch ($step) {
                                    case 0: {
                                        if (this.SetupCompleteRun) {
                                            $step = 1;
                                            continue;
                                        } 
                                        $step = 3;
                                        continue;
                                    }
                                    case 1: {
                                        this.SetupCompleteRun = false;
                                        this.CheckFileLoading();
                                        $task1 = this.FilesReady;
                                        $step = 2;
                                        if ($task1.isCompleted()) {
                                            continue;
                                        }
                                        $task1.continue($asyncBody);
                                        return;
                                    }
                                    case 2: {
                                        $taskResult1 = $task1.getAwaitedResult();
                                        this.EndCustomCSS();
                                        $step = 3;
                                        continue;
                                    }
                                    case 3: {
                                        data = APLExtension.TD.Split$1(e.Data, APLExtension.TD.delims5);
                                        for (var i1 = 0; i1 < data.length; i1 = (i1 + 1) | 0) {
                                            ds = APLExtension.TD.ToTransferString(data[System.Array.index(i1, data)]);
                                            trans = ds.Trans;
                                            if (Bridge.referenceEquals(ds.Action, "WaitForQueue")) {
                                                this.webSocket.Send(data[System.Array.index(i1, data)]);
                                            } else if (Bridge.referenceEquals(ds.Action, "MJH_CloseServer")) {
                                                this.webSocket.Send(data[System.Array.index(i1, data)]);
                                            } else if (Bridge.referenceEquals(ds.Action, "Ping")) {
                                                this.webSocket.Send(data[System.Array.index(i1, data)]);
                                            } else if (Bridge.referenceEquals(ds.Action, "Loaded")) {
                                                Windows.UI.Xaml.Application.Current.Resources.setItem("Index", ds.Data);
                                                this.webSocketReady.setResult(true);
                                                _WSInternals.Status = "WebSocket Opened ";
                                                this.AllReady = true;
                                                Windows.UI.Xaml.Application.Current.Resources.setItem("AllReady", Bridge.box(this.AllReady, System.Boolean, System.Boolean.toString));
                                                this.InitializeComponent();
                                                this.MakeWinSize(_qwc_Root, _WSInternals);
                                                _qwc_Root.NotifyPropertyChanged("FontList");
                                                _qwc_Root.NotifyPropertyChanged("FontFamily");
                                                _qwc_Root.NotifyPropertyChanged("Caption");
                                                _qwc_Root.NotifyPropertyChanged("URL");
                                                _qwc_Root.NotifyPropertyChanged("URLS");
                                                _qwc_Root.NotifyPropertyChanged("Captions");
                                                loadFont("APL385","app-cshtml5/res/QWC/fonts/apl385-webfont.woff");
                                                fullfont = function (_o1) {
                                                    _o1.add("APL385");
                                                    _o1.add("Andal\u00e9 Mono");
                                                    _o1.add("Arial");
                                                    _o1.add("Arial Black");
                                                    _o1.add("Arial Narrow");
                                                    _o1.add("Arial Rounded MT Bold");
                                                    _o1.add("Baskerville");
                                                    _o1.add("Bodoni 72");
                                                    _o1.add("Bodoni MT");
                                                    _o1.add("Bradley Hand");
                                                    _o1.add("Brush Script MT");
                                                    _o1.add("Calibri");
                                                    _o1.add("Calisto MT");
                                                    _o1.add("Cambria");
                                                    _o1.add("Candara");
                                                    _o1.add("Century Gothic");
                                                    _o1.add("Comic Sans MS");
                                                    _o1.add("Consolas");
                                                    _o1.add("Copperplate Gothic");
                                                    _o1.add("Courier");
                                                    _o1.add("Courier New");
                                                    _o1.add("Dejavu Sans");
                                                    _o1.add("Didot");
                                                    _o1.add("Franklin Gothic");
                                                    _o1.add("Garamond");
                                                    _o1.add("Georgia");
                                                    _o1.add("Gill Sans");
                                                    _o1.add("Goudy Old Style");
                                                    _o1.add("Helvetica");
                                                    _o1.add("Helvetica Neu");
                                                    _o1.add("Impact");
                                                    _o1.add("Lucida");
                                                    _o1.add("Lucida Bright");
                                                    _o1.add("Lucida Handwriting");
                                                    _o1.add("Lucida Sans");
                                                    _o1.add("Luminari");
                                                    _o1.add("Microsoft Sans Serif");
                                                    _o1.add("Monaco");
                                                    _o1.add("Optima");
                                                    _o1.add("Palatino");
                                                    _o1.add("Perpetua");
                                                    _o1.add("Rage");
                                                    _o1.add("Rockwell");
                                                    _o1.add("Script MT");
                                                    _o1.add("Segoe UI");
                                                    _o1.add("Segoe script");
                                                    _o1.add("Snell Roundhand");
                                                    _o1.add("Tahoma");
                                                    _o1.add("Times New Roman");
                                                    _o1.add("Trebuchet MS");
                                                    _o1.add("Verdana");
                                                    return _o1;
                                                }(new (System.Collections.Generic.List$1(System.String)).ctor());
                                                _qwc_Root.MJH_FontList_Shape[System.Array.index(0, _qwc_Root.MJH_FontList_Shape)] = 51;
                                                _qwc_Root.MJH_FontList_Shape[System.Array.index(1, _qwc_Root.MJH_FontList_Shape)] = 8;
                                                _qwc_Root.MJH_FontFamily_Shape = 51;
                                                f = new (System.Collections.Generic.List$1(System.Collections.Generic.List$1(APLExtension.APLItem))).ctor();
                                                for (var r = 0; r < 51; r = (r + 1) | 0) {
                                                    f.add(new (System.Collections.Generic.List$1(APLExtension.APLItem)).ctor());
                                                    f.getItem(r).add(new APLExtension.APLItem.$ctor9(fullfont.getItem(r)));
                                                    f.getItem(r).add(new APLExtension.APLItem.$ctor7(0));
                                                    f.getItem(r).add(new APLExtension.APLItem.$ctor7(0));
                                                    f.getItem(r).add(new APLExtension.APLItem.$ctor7(0));
                                                    f.getItem(r).add(new APLExtension.APLItem.$ctor7(0));
                                                    f.getItem(r).add(new APLExtension.APLItem.$ctor7(0));
                                                    f.getItem(r).add(new APLExtension.APLItem.$ctor7(0));
                                                    f.getItem(r).add(new APLExtension.APLItem.$ctor7(0));
                                                }
                                                _qwc_Root.FontList = f;
                                                _qwc_Root.FontFamily = function (_o2) {
                                                    _o2.add("APL385");
                                                    _o2.add("Andal\u00e9 Mono, monospace");
                                                    _o2.add("Arial, Helvetica Neue, Helvetica, sans-serif");
                                                    _o2.add("Arial Black, Arial Bold, Gadget, sans-serif");
                                                    _o2.add("Arial Narrow, Arial, sans-serif");
                                                    _o2.add("Arial Rounded MT Bold, Helvetica Rounded, Arial, sans-serif");
                                                    _o2.add("Baskerville, Baskerville Old Face, Garamond, Times New Roman, serif");
                                                    _o2.add("Bodoni 72, Bodoni MT, Didot, Didot LT STD, Hoefler Text, Garamond, Times New Roman, serif");
                                                    _o2.add("Bodoni MT, Bodoni 72, Didot, Didot LT STD, Hoefler Text, Garamond, Times New Roman, serif");
                                                    _o2.add("Bradley Hand, cursive");
                                                    _o2.add("Brush Script MT, cursive");
                                                    _o2.add("Calibri, Candara, Segoe, Segoe UI, Optima, Arial, sans-serif");
                                                    _o2.add("Calisto MT, Bookman Old Style, Bookman, Goudy Old Style, Garamond, Hoefler Text, Bitstream Charter, Georgia, serif");
                                                    _o2.add("Cambria, Georgia, serif");
                                                    _o2.add("Candara, Calibri, Segoe, Segoe UI, Optima, Arial, sans-serif");
                                                    _o2.add("Century Gothic, CenturyGothic, AppleGothic, sans-serif");
                                                    _o2.add("Comic Sans MS, cursive");
                                                    _o2.add("Consolas, monaco, monospace");
                                                    _o2.add("Copperplate Gothic, Copperplate Gothic Light, fantasy");
                                                    _o2.add("Courier, monospace");
                                                    _o2.add("Courier New, Courier, Lucida Sans Typewriter, Lucida Typewriter, monospace");
                                                    _o2.add("Dejavu Sans, Arial, Verdana, sans-serif");
                                                    _o2.add("Didot, Didot LT STD, Hoefler Text, Garamond, Calisto MT, Times New Roman, serif");
                                                    _o2.add("Franklin Gothic, Arial Bold, Arial, sans-serif");
                                                    _o2.add("Garamond, Baskerville, Baskerville Old Face, Hoefler Text, Times New Roman, serif");
                                                    _o2.add("Georgia, Times, Times New Roman, serif");
                                                    _o2.add("Gill Sans, Gill Sans MT, Calibri, sans-serif");
                                                    _o2.add("Goudy Old Style, Garamond, Big Caslon, Times New Roman, serif");
                                                    _o2.add("Helvetica, Helvetica Neu, Arial, sans-serif.");
                                                    _o2.add("Helvetica Neu, Helvetica, Arial, sans-serif.");
                                                    _o2.add("Impact, Charcoal, Helvetica Inserat, Bitstream Vera Sans Bold, Arial Black, sans-serif.");
                                                    _o2.add("Lucida, monospace");
                                                    _o2.add("Lucida Bright, Georgia, serif.");
                                                    _o2.add("Lucida Handwriting, cursive");
                                                    _o2.add("Lucida Sans, Helvetica, Arial, sans-serif.");
                                                    _o2.add("Luminari, fantasy");
                                                    _o2.add("Microsoft Sans Serif, sans-serif.");
                                                    _o2.add("Monaco, monospace");
                                                    _o2.add("Optima, Segoe, Segoe UI, Candara, Calibri, Arial, sans-serif.");
                                                    _o2.add("Palatino, Palatino Linotype, Palatino LT STD, Book Antiqua, Georgia, serif.");
                                                    _o2.add("Perpetua, Baskerville, Big Caslon, Palatino Linotype, Palatino, serif.");
                                                    _o2.add("Rage, cursive");
                                                    _o2.add("Rockwell, Courier Bold, Courier, Georgia, Times, Times New Roman, serif.");
                                                    _o2.add("Script MT, cursive");
                                                    _o2.add("Segoe UI, Frutiger, Dejavu Sans, Helvetica Neue, Arial, sans-serif.");
                                                    _o2.add("Segoe script, cursive");
                                                    _o2.add("Snell Roundhand, cursive");
                                                    _o2.add("Tahoma, Verdana, Segoe, sans-serif.");
                                                    _o2.add("Times New Roman, Georgia, serif;");
                                                    _o2.add("Trebuchet MS, Lucida Grande, Lucida Sans Unicode, Lucida Sans, sans-serif.");
                                                    _o2.add("Verdana, Geneva, sans-serif.");
                                                    return _o2;
                                                }(new (System.Collections.Generic.List$1(System.String)).ctor());
                                                _qwc_Root.NotifyPropertyChanged("FontList");
                                                _qwc_Root.NotifyPropertyChanged("FontFamily");
                                                xstring = new APLExtension.TransferString();
                                                xstring.Type = "SetupComplete";
                                                this.SetupCompleteRun = true;
                                                d = APLExtension.TD.FromTransferString(xstring);
                                                this.webSocket.Send(d);
                                                elem = document.getElementById("mjhsplashscreen");
                                                elem.style = "display: none;";
                                            } else if (Bridge.referenceEquals(ds.Action, "Create")) {
                                                this.EndCustomCSS();
                                                ds.Name = "Type";
                                                ds.Data = ds.Class.substr(3);
                                                if (Bridge.referenceEquals(ds.Class, "qwcButton") || Bridge.referenceEquals(ds.Class, "qwcCombo") || Bridge.referenceEquals(ds.Class, "qwcDateTimePicker") || Bridge.referenceEquals(ds.Class, "qwcMsgBox") || Bridge.referenceEquals(ds.Class, "qwcEdit") || Bridge.referenceEquals(ds.Class, "qwcList") || Bridge.referenceEquals(ds.Class, "qwcListViewSingle") || Bridge.referenceEquals(ds.Class, "qwcListViewMulti") || Bridge.referenceEquals(ds.Class, "qwcMenuItem") || Bridge.referenceEquals(ds.Class, "qwcTabControl")) {
                                                    ds.Class = (ds.Class || "") + (ds.Extras || "");
                                                }
                                                cl = (ds.Class || "") + "_Data";
                                                o = APLExtension.APL.MakeInstance("DataBinding", cl, ds.Instance, this);
                                                xstring = new APLExtension.TransferString();
                                                xstring.Trans = trans;
                                                d = APLExtension.TD.FromTransferString(xstring);
                                                this.webSocket.Send(d);
                                            } else if (Bridge.referenceEquals(ds.Action, "EndRunLoaded")) {
                                                this.CreateControl(ds);
                                            } else if (Bridge.referenceEquals(ds.Action, "OldCreate")) {
                                                ds.Name = "Type";
                                                ds.Data = ds.Class.substr(3);
                                                if (Bridge.referenceEquals(ds.Class, "qwcButton") || Bridge.referenceEquals(ds.Class, "qwcCombo") || Bridge.referenceEquals(ds.Class, "qwcDateTimePicker") || Bridge.referenceEquals(ds.Class, "qwcMsgBox") || Bridge.referenceEquals(ds.Class, "qwcEdit") || Bridge.referenceEquals(ds.Class, "qwcList") || Bridge.referenceEquals(ds.Class, "qwcListViewSingle") || Bridge.referenceEquals(ds.Class, "qwcListViewMulti") || Bridge.referenceEquals(ds.Class, "qwcMenuItem") || Bridge.referenceEquals(ds.Class, "qwcTabControl")) {
                                                    ds.Class = (ds.Class || "") + (ds.Extras || "");
                                                }
                                                assembly = APLExtension.APL.GetAssembly("DataBinding", this);
                                                type = Bridge.Reflection.getType("DataBinding." + (ds.Class || ""), assembly);
                                                ob = Bridge.createInstance(type, [ds]);
                                                cl1 = APLExtension.APL.GetClassByName(ds.Instance);
                                                obj = APLExtension.APL.GetInstance$3("DataBinding", cl1, ds.Instance, ob);
                                                xstring = new APLExtension.TransferString();
                                                xstring.Trans = trans;
                                                d = APLExtension.TD.FromTransferString(xstring);
                                                this.webSocket.Send(d);
                                                this.directwebSocket.Send(d);
                                            } else if (Bridge.referenceEquals(ds.Action, "CreateContinue1")) {
                                                if (Bridge.referenceEquals(ds.Class, "qwcButton") || Bridge.referenceEquals(ds.Class, "qwcCombo") || Bridge.referenceEquals(ds.Class, "qwcDateTimePicker") || Bridge.referenceEquals(ds.Class, "qwcMsgBox") || Bridge.referenceEquals(ds.Class, "qwcEdit") || Bridge.referenceEquals(ds.Class, "qwcList") || Bridge.referenceEquals(ds.Class, "qwcListViewSingle") || Bridge.referenceEquals(ds.Class, "qwcListViewMulti") || Bridge.referenceEquals(ds.Class, "qwcMenuItem") || Bridge.referenceEquals(ds.Class, "qwcTabControl")) {
                                                    ds.Class = (ds.Class || "") + (ds.Extras || "");
                                                }
                                                assembly1 = APLExtension.APL.GetAssembly("DataBinding", this);
                                                cl2 = APLExtension.APL.GetClassByName(ds.Instance);
                                                obj1 = APLExtension.APL.GetInstance$3("DataBinding", cl2, ds.Instance, null);
                                                cla = Bridge.Reflection.getType("DataBinding." + (ds.Class || ""), assembly1);
                                                method = Bridge.Reflection.getMembers(cla, 8, 284, "CreateContinue1");
                                                if (method != null) {
                                                    $arguments = System.Array.init([ds], System.Object);
                                                    Bridge.Reflection.midel(method, Bridge.unbox(Bridge.cast(obj1, APLExtension.MJH_CommonData).MJH_Class)).apply(null, Bridge.unbox($arguments));
                                                }
                                                xstring = new APLExtension.TransferString();
                                                xstring.Trans = trans;
                                                d = APLExtension.TD.FromTransferString(xstring);
                                                this.webSocket.Send(d);
                                                this.directwebSocket.Send(d);
                                            } else if (Bridge.referenceEquals(ds.Action, "CreateContinue2")) {
                                                if (Bridge.referenceEquals(ds.Class, "qwcButton") || Bridge.referenceEquals(ds.Class, "qwcCombo") || Bridge.referenceEquals(ds.Class, "qwcDateTimePicker") || Bridge.referenceEquals(ds.Class, "qwcMsgBox") || Bridge.referenceEquals(ds.Class, "qwcEdit") || Bridge.referenceEquals(ds.Class, "qwcList") || Bridge.referenceEquals(ds.Class, "qwcListViewSingle") || Bridge.referenceEquals(ds.Class, "qwcListViewMulti") || Bridge.referenceEquals(ds.Class, "qwcMenuItem") || Bridge.referenceEquals(ds.Class, "qwcTabControl")) {
                                                    ds.Class = (ds.Class || "") + (ds.Extras || "");
                                                }
                                                assembly2 = APLExtension.APL.GetAssembly("DataBinding", this);
                                                cl3 = APLExtension.APL.GetClassByName(ds.Instance);
                                                obj2 = APLExtension.APL.GetInstance$3("DataBinding", cl3, ds.Instance, null);
                                                cla1 = Bridge.Reflection.getType("DataBinding." + (ds.Class || ""), assembly2);
                                                method1 = Bridge.Reflection.getMembers(cla1, 8, 284, "CreateContinue2");
                                                if (method1 != null) {
                                                    $arguments1 = System.Array.init([ds], System.Object);
                                                    Bridge.Reflection.midel(method1, Bridge.unbox(Bridge.cast(obj2, APLExtension.MJH_CommonData).MJH_Class)).apply(null, Bridge.unbox($arguments1));
                                                }
                                                if (0 !== ds.Extras.length) {
                                                    ds.Name = "Style";
                                                    ds.Data = ds.Extras;
                                                    typecl = Bridge.Reflection.getType("DataBinding." + (cl3 || ""), assembly2);
                                                    method11 = Bridge.Reflection.getMembers(typecl, 8, 284, "RunPropertyChangedIn");
                                                    $arguments2 = System.Array.init([ds, Bridge.box(false, System.Boolean, System.Boolean.toString)], System.Object);
                                                    Bridge.Reflection.midel(method11, Bridge.unbox(obj2)).apply(null, Bridge.unbox($arguments2));
                                                }
                                                xstring = new APLExtension.TransferString();
                                                xstring.Trans = trans;
                                                d = APLExtension.TD.FromTransferString(xstring);
                                                this.webSocket.Send(d);
                                                this.directwebSocket.Send(d);
                                            } else if (Bridge.referenceEquals(ds.Action, "EnQueue")) {
                                        ds.Class = APLExtension.APL.GetClassByName(ds.Instance);
                                                if (null != ds.Class) {
                                                    obj3 = APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this);
                                                    $arguments1 = System.Array.init([ds, this], System.Object);
                                                    assembly3 = APLExtension.APL.GetAssembly("QWC", this);
                                                    type1 = Bridge.Reflection.getType("QWC.NQ", assembly3);
                                                    method2 = Bridge.Reflection.getMembers(type1, 8, 284, "Do" + (ds.Name || ""));
                                                    if (APLExtension.Utils.IsStatic(method2)) {
                                                        NQresult = Bridge.cast(Bridge.Reflection.midel(method2, null).apply(null, Bridge.unbox($arguments1)), System.String);
                                                    } else {
                                                        NQresult = Bridge.cast(Bridge.Reflection.midel(method2, Bridge.unbox(obj3)).apply(null, Bridge.unbox($arguments1)), System.String);
                                                    }
                                                } else {
                                                    NQresult = "False";
                                                }
                                                xstring = new APLExtension.TransferString();
                                                xstring.Type = "EnQueue";
                                                xstring.Data = NQresult;
                                                xstring.Trans = trans;
                                                d = APLExtension.TD.FromTransferString(xstring);
                                                this.directwebSocket.Send(d);
                                            } else {
                                                this.RunDataBinding(ds);
                                            }
                                        }
                                        return;
                                    }
                                    default: {
                                        return;
                                    }
                                }
                            }
                        }, arguments);

                    $asyncBody();
                }));
                this.webSocket.addOnError(function (s, e) {
                    _WSInternals.Status = "ERROR : " + (e.Data || "");
                });
                this.webSocket.addOnClose(function (s, e) {
                    _WSInternals.Status = "WebSocket Closed ";
                });
                this.webSocket.addOnOpen(Bridge.fn.bind(this, function (s, e) {
                    xstring = new APLExtension.TransferString();
                    xstring.Type = "SessionStart";
                    xstring.Data = Bridge.cast(Windows.UI.Xaml.Application.Current.Resources.getItem("OriginalURL"), System.String);
                    d = APLExtension.TD.FromTransferString(xstring);
                    this.webSocket.Send(d);
                }));
                this.directwebSocket.addOnOpen(Bridge.fn.bind(this, function (s, e) {
                    var $step = 0,
                        $task1, 
                        $taskResult1, 
                        $jumpFromFinally, 
                        dx, 
                        $asyncBody = Bridge.fn.bind(this, function () {
                            for (;;) {
                                $step = System.Array.min([0,1], $step);
                                switch ($step) {
                                    case 0: {
                                        xstring = new APLExtension.TransferString();
                                        $task1 = this.WebSocketReady;
                                        $step = 1;
                                        if ($task1.isCompleted()) {
                                            continue;
                                        }
                                        $task1.continue($asyncBody);
                                        return;
                                    }
                                    case 1: {
                                        $taskResult1 = $task1.getAwaitedResult();
                                        xstring.Data = Bridge.cast(Windows.UI.Xaml.Application.Current.Resources.getItem("Index"), System.String);
                                        xstring.Type = "Index";
                                        dx = APLExtension.TD.FromTransferString(xstring);
                                        this.directwebSocket.Send(dx);
                                        return;
                                    }
                                    default: {
                                        return;
                                    }
                                }
                            }
                        }, arguments);

                    $asyncBody();
                }));
                this.directwebSocket.addOnMessage(Bridge.fn.bind(this, function (s, e) {
                    var ds = APLExtension.TD.ToTransferString(e.Data);
                    var trans = ds.Trans;
                    if (Bridge.referenceEquals(ds.Action, "MJH_CloseServer")) {
                        this.directwebSocket.Send(e.Data);
                    } else if (Bridge.referenceEquals(ds.Action, "EnQueue")) {
                        var NQresult;
                        ds.Class = APLExtension.APL.GetClassByName(ds.Instance);
                        if (null != ds.Class) {
                            var obj = APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this);
                            var $arguments = System.Array.init([ds, this], System.Object);
                            var assembly = APLExtension.APL.GetAssembly("QWC", this);
                            var type = Bridge.Reflection.getType("QWC.NQ", assembly);
                            var method = Bridge.Reflection.getMembers(type, 8, 284, "Do" + (ds.Name || ""));
                            if (APLExtension.Utils.IsStatic(method)) {
                                NQresult = Bridge.cast(Bridge.Reflection.midel(method, null).apply(null, Bridge.unbox($arguments)), System.String);
                            } else {
                                NQresult = Bridge.cast(Bridge.Reflection.midel(method, Bridge.unbox(obj)).apply(null, Bridge.unbox($arguments)), System.String);
                            }
                        } else {
                            NQresult = "False";
                        }
                        xstring = new APLExtension.TransferString();
                        xstring.Type = "EnQueue";
                        xstring.Data = NQresult;
                        xstring.Trans = trans;
                        d = APLExtension.TD.FromTransferString(xstring);
                        this.directwebSocket.Send(d);
                    } else if (Bridge.referenceEquals(ds.Action, "ReturnEvent")) {
                        APLExtension.APL.RaiseEventReturned(e.Data);
                    }
                }));
            },
            IsEJ1: function (inp) {
                return false;
            },
            IsEJ2: function (inp) {
                if (Bridge.referenceEquals(inp, "qwcAppBar_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcAvatar_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcBadge_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcBarCode_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcBreadCrumb_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcCalendar_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcCard_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcCarousel_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcChart_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcChips_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcCircularGauge_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcColourPicker_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcColorPicker_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcComboDrop_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcComboDropEdit_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcComboSimple_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcContextMenu_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcDashBoard_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcDataGrid_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcDataManager_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcDateTimePickerCombo_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcDiagram_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcMsgBoxMsg_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcMsgBoxInfo_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcMsgBoxQuery_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcMsgBoxWarn_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcMsgBoxError_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcDocumentEditor_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcFileManager_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcGantt_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcGrid_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcImageEditor_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcLinearGauge_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcImage_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcKanban_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcListSingle_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcListMulti_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcListViewSingle_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcListViewMulti_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcMaps_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcMention_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcMenuBar_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcMessage_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcPager_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcPDFViewer_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcPivotTable_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcProgressBar_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcProgressButton_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcQueryBuilder_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcQRCode_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcRating_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcRibbon_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcRichTextEditor_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcSchedule_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcSideBar_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcSignature_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcSkeleton_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcSplitter_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcTabControl_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcText_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcTreeView_Data")) {
                    return true;
                }
                if (Bridge.referenceEquals(inp, "qwcUploader_Data")) {
                    return true;
                }
                return false;
            },
            CreateControl: function (ds) {
                var assembly = APLExtension.APL.GetAssembly("DataBinding", this);
                var type = Bridge.Reflection.getType("DataBinding." + (ds.Class || ""), assembly);
                var cl = (ds.Class || "") + "_Data";
                var isEJ1 = this.IsEJ1(cl);
                var isEJ2 = this.IsEJ2(cl);
                var ob = Bridge.createInstance(type, [ds]);
                var method = Bridge.Reflection.getMembers(type, 8, 284, "CreateContinue1");
                var obj = APLExtension.APL.GetInstance$3("DataBinding", cl, ds.Instance, null);
                if (method != null) {
                    var $arguments = System.Array.init([ds], System.Object);
                    Bridge.Reflection.midel(method, Bridge.unbox(Bridge.cast(obj, APLExtension.MJH_CommonData).MJH_Class)).apply(null, Bridge.unbox($arguments));
                }
                method = Bridge.Reflection.getMembers(type, 8, 284, "CreateContinue2");
                if (method != null) {
                    var $arguments1 = System.Array.init([ds], System.Object);
                    Bridge.Reflection.midel(method, Bridge.unbox(Bridge.cast(obj, APLExtension.MJH_CommonData).MJH_Class)).apply(null, Bridge.unbox($arguments1));
                }
                if (0 !== ds.Extras.length) {
                    ds.Name = "Style";
                    ds.Data = ds.Extras;
                    var typecl = Bridge.Reflection.getType("DataBinding." + (cl || ""), assembly);
                    method = Bridge.Reflection.getMembers(typecl, 8, 284, "RunPropertyChangedIn");
                    var $arguments2 = System.Array.init([ds, Bridge.box(false, System.Boolean, System.Boolean.toString)], System.Object);
                    Bridge.Reflection.midel(method, Bridge.unbox(obj)).apply(null, Bridge.unbox($arguments2));
                }
            },
            RunDataBinding: function (ds) {
                if (Bridge.referenceEquals(ds.Class, "qwc_Root")) {
                    var dbobj1 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwc_Root);
                    if (null != dbobj1) {
                        dbobj1.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "MJH_DQ_Data")) {
                    var dbobj2 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.MJH_DQ_Data);
                    if (null != dbobj2) {
                        dbobj2.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "MJH_MinForm_Data")) {
                    var dbobj3 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.MJH_MinForm_Data);
                    if (null != dbobj3) {
                        dbobj3.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcAppBar_Data")) {
                    var dbobj4 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcAppBar_Data);
                    if (null != dbobj4) {
                        dbobj4.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcAvatar_Data")) {
                    var dbobj5 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcAvatar_Data);
                    if (null != dbobj5) {
                        dbobj5.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcBadge_Data")) {
                    var dbobj6 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcBadge_Data);
                    if (null != dbobj6) {
                        dbobj6.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcBarCode_Data")) {
                    var dbobj7 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcBarCode_Data);
                    if (null != dbobj7) {
                        dbobj7.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcBreadCrumb_Data")) {
                    var dbobj8 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcBreadCrumb_Data);
                    if (null != dbobj8) {
                        dbobj8.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcBridgeScore_Data")) {
                    var dbobj9 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcBridgeScore_Data);
                    if (null != dbobj9) {
                        dbobj9.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcButtonCheck_Data")) {
                    var dbobj10 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcButtonCheck_Data);
                    if (null != dbobj10) {
                        dbobj10.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcButtonCommandLink_Data")) {
                    var dbobj11 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcButtonCommandLink_Data);
                    if (null != dbobj11) {
                        dbobj11.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcButtonPush_Data")) {
                    var dbobj12 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcButtonPush_Data);
                    if (null != dbobj12) {
                        dbobj12.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcButtonRadio_Data")) {
                    var dbobj13 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcButtonRadio_Data);
                    if (null != dbobj13) {
                        dbobj13.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcButtonSplit_Data")) {
                    var dbobj14 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcButtonSplit_Data);
                    if (null != dbobj14) {
                        dbobj14.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcButtonToggle_Data")) {
                    var dbobj15 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcButtonToggle_Data);
                    if (null != dbobj15) {
                        dbobj15.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcCalendar_Data")) {
                    var dbobj16 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcCalendar_Data);
                    if (null != dbobj16) {
                        dbobj16.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcCard_Data")) {
                    var dbobj17 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcCard_Data);
                    if (null != dbobj17) {
                        dbobj17.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcCarousel_Data")) {
                    var dbobj18 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcCarousel_Data);
                    if (null != dbobj18) {
                        dbobj18.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcChart_Data")) {
                    var dbobj19 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcChart_Data);
                    if (null != dbobj19) {
                        dbobj19.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcChips_Data")) {
                    var dbobj20 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcChips_Data);
                    if (null != dbobj20) {
                        dbobj20.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcCircularGauge_Data")) {
                    var dbobj21 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcCircularGauge_Data);
                    if (null != dbobj21) {
                        dbobj21.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcColourPicker_Data")) {
                    var dbobj22 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcColourPicker_Data);
                    if (null != dbobj22) {
                        dbobj22.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcColorPicker_Data")) {
                    var dbobj23 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcColorPicker_Data);
                    if (null != dbobj23) {
                        dbobj23.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcComboDrop_Data")) {
                    var dbobj24 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcComboDrop_Data);
                    if (null != dbobj24) {
                        dbobj24.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcComboDropEdit_Data")) {
                    var dbobj25 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcComboDropEdit_Data);
                    if (null != dbobj25) {
                        dbobj25.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcComboSimple_Data")) {
                    var dbobj26 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcComboSimple_Data);
                    if (null != dbobj26) {
                        dbobj26.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcContextMenu_Data")) {
                    var dbobj27 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcContextMenu_Data);
                    if (null != dbobj27) {
                        dbobj27.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcDashBoard_Data")) {
                    var dbobj28 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcDashBoard_Data);
                    if (null != dbobj28) {
                        dbobj28.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcDataGrid_Data")) {
                    var dbobj29 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcDataGrid_Data);
                    if (null != dbobj29) {
                        dbobj29.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcDataManager_Data")) {
                    var dbobj30 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcDataManager_Data);
                    if (null != dbobj30) {
                        dbobj30.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcDatePicker_Data")) {
                    var dbobj31 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcDatePicker_Data);
                    if (null != dbobj31) {
                        dbobj31.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcDateTimePickerCombo_Data")) {
                    var dbobj32 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcDateTimePickerCombo_Data);
                    if (null != dbobj32) {
                        dbobj32.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcDiagram_Data")) {
                    var dbobj33 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcDiagram_Data);
                    if (null != dbobj33) {
                        dbobj33.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcMsgBoxMsg_Data")) {
                    var dbobj34 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcMsgBoxMsg_Data);
                    if (null != dbobj34) {
                        dbobj34.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcMsgBoxInfo_Data")) {
                    var dbobj35 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcMsgBoxInfo_Data);
                    if (null != dbobj35) {
                        dbobj35.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcMsgBoxQuery_Data")) {
                    var dbobj36 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcMsgBoxQuery_Data);
                    if (null != dbobj36) {
                        dbobj36.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcMsgBoxWarn_Data")) {
                    var dbobj37 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcMsgBoxWarn_Data);
                    if (null != dbobj37) {
                        dbobj37.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcMsgBoxError_Data")) {
                    var dbobj38 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcMsgBoxError_Data);
                    if (null != dbobj38) {
                        dbobj38.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcDocumentEditor_Data")) {
                    var dbobj39 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcDocumentEditor_Data);
                    if (null != dbobj39) {
                        dbobj39.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcEditSingle_Data")) {
                    var dbobj40 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcEditSingle_Data);
                    if (null != dbobj40) {
                        dbobj40.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcEditMulti_Data")) {
                    var dbobj41 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcEditMulti_Data);
                    if (null != dbobj41) {
                        dbobj41.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcExpander_Data")) {
                    var dbobj42 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcExpander_Data);
                    if (null != dbobj42) {
                        dbobj42.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcFileManager_Data")) {
                    var dbobj43 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcFileManager_Data);
                    if (null != dbobj43) {
                        dbobj43.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcFont_Data")) {
                    var dbobj44 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcFont_Data);
                    if (null != dbobj44) {
                        dbobj44.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcForm_Data")) {
                    var dbobj45 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcForm_Data);
                    if (null != dbobj45) {
                        dbobj45.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcGantt_Data")) {
                    var dbobj46 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcGantt_Data);
                    if (null != dbobj46) {
                        dbobj46.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcGrid_Data")) {
                    var dbobj47 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcGrid_Data);
                    if (null != dbobj47) {
                        dbobj47.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcGroup_Data")) {
                    var dbobj48 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcGroup_Data);
                    if (null != dbobj48) {
                        dbobj48.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcImageEditor_Data")) {
                    var dbobj49 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcImageEditor_Data);
                    if (null != dbobj49) {
                        dbobj49.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcKanban_Data")) {
                    var dbobj50 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcKanban_Data);
                    if (null != dbobj50) {
                        dbobj50.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcLabel_Data")) {
                    var dbobj51 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcLabel_Data);
                    if (null != dbobj51) {
                        dbobj51.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcLinearGauge_Data")) {
                    var dbobj52 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcLinearGauge_Data);
                    if (null != dbobj52) {
                        dbobj52.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcImage_Data")) {
                    var dbobj53 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcImage_Data);
                    if (null != dbobj53) {
                        dbobj53.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcImageList_Data")) {
                    var dbobj54 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcImageList_Data);
                    if (null != dbobj54) {
                        dbobj54.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcKanban_Data")) {
                    var dbobj55 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcKanban_Data);
                    if (null != dbobj55) {
                        dbobj55.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcListSingle_Data")) {
                    var dbobj56 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcListSingle_Data);
                    if (null != dbobj56) {
                        dbobj56.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcListMulti_Data")) {
                    var dbobj57 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcListMulti_Data);
                    if (null != dbobj57) {
                        dbobj57.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcListViewSingle_Data")) {
                    var dbobj58 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcListViewSingle_Data);
                    if (null != dbobj58) {
                        dbobj58.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcListViewMulti_Data")) {
                    var dbobj59 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcListViewMulti_Data);
                    if (null != dbobj59) {
                        dbobj59.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcMaps_Data")) {
                    var dbobj60 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcMaps_Data);
                    if (null != dbobj60) {
                        dbobj60.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcMention_Data")) {
                    var dbobj61 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcMention_Data);
                    if (null != dbobj61) {
                        dbobj61.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcMenu_Data")) {
                    var dbobj62 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcMenu_Data);
                    if (null != dbobj62) {
                        dbobj62.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcMenuBar_Data")) {
                    var dbobj63 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcMenuBar_Data);
                    if (null != dbobj63) {
                        dbobj63.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcMenuItemCheck_Data")) {
                    var dbobj64 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcMenuItemCheck_Data);
                    if (null != dbobj64) {
                        dbobj64.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcMenuItemRadio_Data")) {
                    var dbobj65 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcMenuItemRadio_Data);
                    if (null != dbobj65) {
                        dbobj65.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcMessage_Data")) {
                    var dbobj66 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcMessage_Data);
                    if (null != dbobj66) {
                        dbobj66.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcPager_Data")) {
                    var dbobj67 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcPager_Data);
                    if (null != dbobj67) {
                        dbobj67.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcPDFViewer_Data")) {
                    var dbobj68 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcPDFViewer_Data);
                    if (null != dbobj68) {
                        dbobj68.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcPivotTable_Data")) {
                    var dbobj69 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcPivotTable_Data);
                    if (null != dbobj69) {
                        dbobj69.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcProgressBar_Data")) {
                    var dbobj70 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcProgressBar_Data);
                    if (null != dbobj70) {
                        dbobj70.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcProgressButton_Data")) {
                    var dbobj71 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcProgressButton_Data);
                    if (null != dbobj71) {
                        dbobj71.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcQueryBuilder_Data")) {
                    var dbobj72 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcQueryBuilder_Data);
                    if (null != dbobj72) {
                        dbobj72.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcQRCode_Data")) {
                    var dbobj73 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcQRCode_Data);
                    if (null != dbobj73) {
                        dbobj73.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcRating_Data")) {
                    var dbobj74 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcRating_Data);
                    if (null != dbobj74) {
                        dbobj74.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcRibbon_Data")) {
                    var dbobj75 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcRibbon_Data);
                    if (null != dbobj75) {
                        dbobj75.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcRichTextEditor_Data")) {
                    var dbobj76 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcRichTextEditor_Data);
                    if (null != dbobj76) {
                        dbobj76.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcSchedule_Data")) {
                    var dbobj77 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcSchedule_Data);
                    if (null != dbobj77) {
                        dbobj77.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcSeparator_Data")) {
                    var dbobj78 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcSeparator_Data);
                    if (null != dbobj78) {
                        dbobj78.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcSideBar_Data")) {
                    var dbobj79 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcSideBar_Data);
                    if (null != dbobj79) {
                        dbobj79.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcSignature_Data")) {
                    var dbobj80 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcSignature_Data);
                    if (null != dbobj80) {
                        dbobj80.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcSkeleton_Data")) {
                    var dbobj81 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcSkeleton_Data);
                    if (null != dbobj81) {
                        dbobj81.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcSplitter_Data")) {
                    var dbobj82 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcSplitter_Data);
                    if (null != dbobj82) {
                        dbobj82.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcSubForm_Data")) {
                    var dbobj83 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcSubForm_Data);
                    if (null != dbobj83) {
                        dbobj83.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcTabButton_Data")) {
                    var dbobj84 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcTabButton_Data);
                    if (null != dbobj84) {
                        dbobj84.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcTabButton1_Data")) {
                    var dbobj85 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcTabButton1_Data);
                    if (null != dbobj85) {
                        dbobj85.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcTabControl_Data")) {
                    var dbobj86 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcTabControl_Data);
                    if (null != dbobj86) {
                        dbobj86.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcTabControlButtons_Data")) {
                    var dbobj87 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcTabControlButtons_Data);
                    if (null != dbobj87) {
                        dbobj87.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcTabControlFlatButtons_Data")) {
                    var dbobj88 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcTabControlFlatButtons_Data);
                    if (null != dbobj88) {
                        dbobj88.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcTabControlTabs_Data")) {
                    var dbobj89 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcTabControlTabs_Data);
                    if (null != dbobj89) {
                        dbobj89.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcText_Data")) {
                    var dbobj90 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcText_Data);
                    if (null != dbobj90) {
                        dbobj90.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcTreeView_Data")) {
                    var dbobj91 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcTreeView_Data);
                    if (null != dbobj91) {
                        dbobj91.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "qwcUploader_Data")) {
                    var dbobj92 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.qwcUploader_Data);
                    if (null != dbobj92) {
                        dbobj92.RunPropertyChangedIn(ds, false);
                    }
                } else if (Bridge.referenceEquals(ds.Class, "WSInternals")) {
                    var dbobj93 = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this), DataBinding.WSInternals);
                    if (null != dbobj93) {
                        dbobj93.RunPropertyChangedIn(ds, false);
                    }
                }

            },
            OnBeforeUnload: function (e) {
                var msg = "Do you want to leave QWC?";
                e.preventDefault();
                e.returnValue = msg;
                return msg;
            },
            MakeWinSize: function (rt, wi) {
                wi.SetValue("Status", "WebSocket Opened");
                var fsz = new Windows.Foundation.Size.ctor();
                fsz.Width = System.Nullable.getValue(Bridge.cast(Bridge.unbox(screen.width, System.Double), System.Double));
                fsz.Height = System.Nullable.getValue(Bridge.cast(Bridge.unbox(screen.height, System.Double), System.Double));
                Windows.UI.Xaml.Application.Current.Resources.setItem("FullScreenHeight", Bridge.box(fsz.Height, System.Double, System.Double.format, System.Double.getHashCode));
                Windows.UI.Xaml.Application.Current.Resources.setItem("FullScreenWidth", Bridge.box(fsz.Width, System.Double, System.Double.format, System.Double.getHashCode));
                rt.SetValue("FullScreenSize", fsz.$clone());
                var win = Windows.UI.Xaml.Window.Current;
                Windows.UI.Xaml.Application.Current.Resources.setItem("Screen", win);
                var rect = win.Bounds.$clone();
                Windows.UI.Xaml.Application.Current.Resources.setItem("ScreenHeight", Bridge.box(rect.Height, System.Double, System.Double.format, System.Double.getHashCode));
                Windows.UI.Xaml.Application.Current.Resources.setItem("ScreenWidth", Bridge.box(rect.Width, System.Double, System.Double.format, System.Double.getHashCode));
                rt.SetValue("ScreenSize", rect.Size.$clone());
                rt.SetValue("BrowserScreenSize", rect.Size.$clone());
                var ratio = System.Nullable.getValue(Bridge.cast(Bridge.unbox(window.devicePixelRatio, System.Double), System.Double));
                if (ratio < 1) {
                    ratio = 1 / ratio;
                }
                var fSize = new Windows.Foundation.Size.$ctor1(Bridge.Int.clip32(fsz.Width) * ratio, Bridge.Int.clip32(fsz.Height) * ratio);
                Windows.UI.Xaml.Application.Current.Resources.setItem("FullScreenHeight", Bridge.box(fSize.Height, System.Double, System.Double.format, System.Double.getHashCode));
                Windows.UI.Xaml.Application.Current.Resources.setItem("FullScreenWidth", Bridge.box(fSize.Width, System.Double, System.Double.format, System.Double.getHashCode));
                rt.SetValue("FullScreenSize", fSize.$clone());
                win.addSizeChanged$1(Bridge.fn.bind(this, function (s1, e1) {
                    var newsz = e1.Size.$clone();
                    var root = Bridge.as(APLExtension.APL.GetInstance$3("DataBinding", "qwc_Root", "qwc_Root", this), DataBinding.qwc_Root);
                    root.SetValue("ScreenSize", newsz.$clone());
                    root.SetValue("BrowserScreenSize", newsz.$clone());
                    var ratio1 = System.Nullable.getValue(Bridge.cast(Bridge.unbox(window.devicePixelRatio, System.Double), System.Double));
                    if (ratio1 < 1) {
                        ratio1 = 1 / ratio1 + 0.5;
                    }
                    var fSize1 = new Windows.Foundation.Size.$ctor1(Bridge.Int.clip32(fsz.Width) * ratio1, Bridge.Int.clip32(fsz.Height) * ratio1);
                    Windows.UI.Xaml.Application.Current.Resources.setItem("FullScreenHeight", Bridge.box(fSize1.Height, System.Double, System.Double.format, System.Double.getHashCode));
                    Windows.UI.Xaml.Application.Current.Resources.setItem("FullScreenWidth", Bridge.box(fSize1.Width, System.Double, System.Double.format, System.Double.getHashCode));
                    root.SetValue("FullScreenSize", fSize1.$clone());
                    Windows.UI.Xaml.Application.Current.Resources.setItem("ScreenHeight", Bridge.box(newsz.Height, System.Double, System.Double.format, System.Double.getHashCode));
                    Windows.UI.Xaml.Application.Current.Resources.setItem("ScreenWidth", Bridge.box(newsz.Width, System.Double, System.Double.format, System.Double.getHashCode));
                    Windows.UI.Xaml.Application.Current.Resources.setItem("BrowserScreenHeight", Bridge.box(newsz.Height, System.Double, System.Double.format, System.Double.getHashCode));
                    Windows.UI.Xaml.Application.Current.Resources.setItem("BrowserScreenWidth", Bridge.box(newsz.Width, System.Double, System.Double.format, System.Double.getHashCode));
                    var fm = Bridge.cast(root.GetValue("FullScreenId"), System.String);
                    if (0 !== fm.length) {
                        var ds = Bridge.as(APLExtension.APL.GetInstance$3("DataBinding", "qwcForm_Data", fm, this), DataBinding.qwcForm_Data);
                        if (fm != null && 4 === System.Nullable.getValue(Bridge.cast(Bridge.unbox(ds.GetValue("State"), System.Int32), System.Int32))) {
                            ds.NotifyPropertyChanged("Size");
                        }
                    }
                }));
            },
            UpdateBindingLostFocus: function (sender, e) {
                var tx = Bridge.cast(sender, Windows.UI.Xaml.Controls.TextBox);
                if (0 !== tx.Text.length) {
                    var exp = tx.GetBindingExpression(Windows.UI.Xaml.Controls.TextBox.TextProperty);
                    var dobj = Bridge.as(exp.DataItem, APLExtension.MJH_CommonData);
                    var instance = dobj.MJH_Instance;
                    var ds = APLExtension.TD.ToTransferString("");
                    ds.Name = exp.ParentBinding.Path.Path;
                    ds.Data = tx.Text;
                    ds.Instance = instance;
                    ds.Class = APLExtension.APL.GetClassByName(ds.Instance);
                    var obj = APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this);
                    var $arguments = System.Array.init([ds, Bridge.box(true, System.Boolean, System.Boolean.toString)], System.Object);
                    var assembly = APLExtension.APL.GetAssembly("DataBinding", this);
                    var type = Bridge.Reflection.getType("DataBinding." + (ds.Class || ""), assembly);
                    var method = Bridge.Reflection.getMembers(type, 8, 284, "RunPropertyChangedIn");
                    Bridge.Reflection.midel(method, Bridge.unbox(obj)).apply(null, Bridge.unbox($arguments));
                }
            },
            UpdateBindingKeyDown: function (sender, e) {
                if (e.Key === Windows.System.VirtualKey.Enter) {
                    var tx = Bridge.cast(sender, Windows.UI.Xaml.Controls.TextBox);
                    if (0 !== tx.Text.length) {
                        var exp = tx.GetBindingExpression(Windows.UI.Xaml.Controls.TextBox.TextProperty);
                        var dobj = Bridge.as(exp.DataItem, APLExtension.MJH_CommonData);
                        var instance = dobj.MJH_Instance;
                        var ds = APLExtension.TD.ToTransferString("");
                        ds.Name = exp.ParentBinding.Path.Path;
                        ds.Data = tx.Text;
                        ds.Instance = instance;
                        ds.Class = APLExtension.APL.GetClassByName(ds.Instance);
                        var obj = APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, this);
                        var $arguments = System.Array.init([ds, Bridge.box(true, System.Boolean, System.Boolean.toString)], System.Object);
                        var assembly = APLExtension.APL.GetAssembly("DataBinding", this);
                        var type = Bridge.Reflection.getType("DataBinding." + (ds.Class || ""), assembly);
                        var method = Bridge.Reflection.getMembers(type, 8, 284, "RunPropertyChangedIn");
                        Bridge.Reflection.midel(method, Bridge.unbox(obj)).apply(null, Bridge.unbox($arguments));
                    }
                }
            },
            InitializeComponent: function () {
                if (this._contentLoaded) {
                    return;
                }
                this._contentLoaded = true;


                if (Bridge.is(this, Windows.UI.Xaml.UIElement)) {
                    Bridge.cast(this, Windows.UI.Xaml.UIElement).XamlSourcePath = "QWC\\MainPage.xaml";
                }

                var Grid_108fa2dc46b34dca99cd43e2cf8df7e1 = new Bridge.global.Windows.UI.Xaml.Controls.Grid();
                var WrapPanel_cfa0a13881614b0b91d05ddabc3993c3 = new Bridge.global.Windows.UI.Xaml.Controls.WrapPanel();
                var Grid_69a918533a7f46219dd61834cbdf8e96 = new Bridge.global.Windows.UI.Xaml.Controls.Grid();
                var Grid_15fd2b91478f4777bc9374c52f77db59 = new Bridge.global.Windows.UI.Xaml.Controls.Grid();

                this.RegisterName$1("Top", this);
                this.Name = "Top";
                var IntConverter_671bd211db654dcf915643678cf5328a = new Bridge.global.APLExtension.IntConverter();

                var DecConverter_bf28e6387b50493eb45caa8ad22a22e3 = new Bridge.global.APLExtension.DecConverter();

                this.Resources.setItem("IntConverter", IntConverter_671bd211db654dcf915643678cf5328a);
                this.Resources.setItem("DecConverter", DecConverter_bf28e6387b50493eb45caa8ad22a22e3);

                var Grid_f2f0a826a14245a8b7ba93a445f09f1e = new Bridge.global.Windows.UI.Xaml.Controls.Grid();
                var RowDefinition_78a302560857406a984a349877bf39e1 = new Bridge.global.Windows.UI.Xaml.Controls.RowDefinition();
                RowDefinition_78a302560857406a984a349877bf39e1.Height = new Bridge.global.Windows.UI.Xaml.GridLength.$ctor2(1.0, Bridge.global.Windows.UI.Xaml.GridUnitType.Star);

                var RowDefinition_869b7b329c024f55887b3036ffdd87e9 = new Bridge.global.Windows.UI.Xaml.Controls.RowDefinition();
                RowDefinition_869b7b329c024f55887b3036ffdd87e9.Height = new Bridge.global.Windows.UI.Xaml.GridLength.$ctor2(1.0, Bridge.global.Windows.UI.Xaml.GridUnitType.Auto);

                Grid_f2f0a826a14245a8b7ba93a445f09f1e.RowDefinitions.add(RowDefinition_78a302560857406a984a349877bf39e1);
                Grid_f2f0a826a14245a8b7ba93a445f09f1e.RowDefinitions.add(RowDefinition_869b7b329c024f55887b3036ffdd87e9);

                this.RegisterName$1("QWCGrid", Grid_108fa2dc46b34dca99cd43e2cf8df7e1);
                Grid_108fa2dc46b34dca99cd43e2cf8df7e1.Name = "QWCGrid";

                this.RegisterName$1("QWCIcons", WrapPanel_cfa0a13881614b0b91d05ddabc3993c3);
                WrapPanel_cfa0a13881614b0b91d05ddabc3993c3.Name = "QWCIcons";
                Bridge.global.Windows.UI.Xaml.Controls.Grid.SetRow(WrapPanel_cfa0a13881614b0b91d05ddabc3993c3, 1);

                this.RegisterName$1("QWCHidden", Grid_69a918533a7f46219dd61834cbdf8e96);
                Grid_69a918533a7f46219dd61834cbdf8e96.Name = "QWCHidden";
                Bridge.global.Windows.UI.Xaml.Controls.Grid.SetRow(Grid_69a918533a7f46219dd61834cbdf8e96, 1);
                Grid_69a918533a7f46219dd61834cbdf8e96.Visibility = Bridge.global.Windows.UI.Xaml.Visibility.Collapsed;

                this.RegisterName$1("QWCSideBars", Grid_15fd2b91478f4777bc9374c52f77db59);
                Grid_15fd2b91478f4777bc9374c52f77db59.Name = "QWCSideBars";
                Bridge.global.Windows.UI.Xaml.Controls.Grid.SetRow(Grid_15fd2b91478f4777bc9374c52f77db59, 1);
                Grid_15fd2b91478f4777bc9374c52f77db59.Visibility = Bridge.global.Windows.UI.Xaml.Visibility.Collapsed;

                Grid_f2f0a826a14245a8b7ba93a445f09f1e.Children.add(Grid_108fa2dc46b34dca99cd43e2cf8df7e1);
                Grid_f2f0a826a14245a8b7ba93a445f09f1e.Children.add(WrapPanel_cfa0a13881614b0b91d05ddabc3993c3);
                Grid_f2f0a826a14245a8b7ba93a445f09f1e.Children.add(Grid_69a918533a7f46219dd61834cbdf8e96);
                Grid_f2f0a826a14245a8b7ba93a445f09f1e.Children.add(Grid_15fd2b91478f4777bc9374c52f77db59);


                this.Content = Grid_f2f0a826a14245a8b7ba93a445f09f1e;

                var DataContextExtension_abee6280f1724d879dfbb242938b8066 = new Bridge.global.APLExtension.DataContextExtension.ctor();
                DataContextExtension_abee6280f1724d879dfbb242938b8066.Instance = "qwc_Root";
                DataContextExtension_abee6280f1724d879dfbb242938b8066.Class = "qwc_Root";
                DataContextExtension_abee6280f1724d879dfbb242938b8066.NS = "DataBinding";




                this.QWCGrid = Grid_108fa2dc46b34dca99cd43e2cf8df7e1;
                this.QWCIcons = WrapPanel_cfa0a13881614b0b91d05ddabc3993c3;
                this.QWCHidden = Grid_69a918533a7f46219dd61834cbdf8e96;
                this.QWCSideBars = Grid_15fd2b91478f4777bc9374c52f77db59;
                this.Top = this;

                var customMarkupValue_ede7062b3fcd4f84af082a160a03fa7c = DataContextExtension_abee6280f1724d879dfbb242938b8066.ProvideValue(new Bridge.global.System.ServiceProvider.ctor(this, Bridge.global.Windows.UI.Xaml.FrameworkElement.DataContextProperty));
                if (Bridge.is(customMarkupValue_ede7062b3fcd4f84af082a160a03fa7c, Windows.UI.Xaml.Data.Binding)) {
                    Bridge.global.Windows.UI.Xaml.Data.BindingOperations.SetBinding(this, Bridge.global.Windows.UI.Xaml.FrameworkElement.DataContextProperty, Bridge.cast(customMarkupValue_ede7062b3fcd4f84af082a160a03fa7c, Windows.UI.Xaml.Data.Binding));
                } else {
                    this.DataContext = customMarkupValue_ede7062b3fcd4f84af082a160a03fa7c;
                }

            }
        }
    });

    Bridge.define("QWC.NQ", {
        statics: {
            fields: {
                LockInstances: null
            },
            ctors: {
                init: function () {
                    this.LockInstances = { };
                }
            },
            methods: {
                DoAddVisual: function (ds, actthis) {
                    var obj = APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, actthis);
                    var $arguments = System.Array.init([ds], System.Object);
                    var assembly = APLExtension.APL.GetAssembly("DataBinding", actthis);

                    var cl = APLExtension.APL.GetClassByName(ds.Instance);
                    if (System.String.contains(cl,"_Data")) {
                        cl = cl.substr(0, ((cl.length - 5) | 0));
                    }
                    var type = Bridge.Reflection.getType("DataBinding." + (cl || ""), assembly);

                    var method = Bridge.Reflection.getMembers(type, 8, 284, "DoAddVisual");

                    if (APLExtension.Utils.IsStatic(method)) {
                        return Bridge.cast(Bridge.Reflection.midel(method, null).apply(null, Bridge.unbox($arguments)), System.String);
                    } else {
                        return Bridge.cast(Bridge.Reflection.midel(method, Bridge.unbox(Bridge.cast(obj, APLExtension.MJH_CommonData).MJH_Class)).apply(null, Bridge.unbox($arguments)), System.String);
                    }
                },
                DoRunEvent: function (ds, actthis) {
                    var obj = APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, actthis);
                    var $arguments = System.Array.init([ds], System.Object);
                    var assembly = APLExtension.APL.GetAssembly("DataBinding", actthis);

                    var cl = APLExtension.APL.GetClassByName(ds.Instance);
                    if (System.String.contains(cl,"_Data")) {
                        cl = cl.substr(0, ((cl.length - 5) | 0));
                    }
                    var type = Bridge.Reflection.getType("DataBinding." + (cl || ""), assembly);

                    var method = Bridge.Reflection.getMembers(type, 8, 284, "DoRunEvent");

                    var result = "";
                    if (method != null) {
                        if (APLExtension.Utils.IsStatic(method)) {
                            result = Bridge.cast(Bridge.Reflection.midel(method, null).apply(null, Bridge.unbox($arguments)), System.String);
                        } else {
                            result = Bridge.cast(Bridge.Reflection.midel(method, Bridge.unbox(Bridge.cast(obj, APLExtension.MJH_CommonData).MJH_Class)).apply(null, Bridge.unbox($arguments)), System.String);
                        }
                    }
                    return result;
                },
                DoRunMethod: function (ds, actthis) {
                    var result = "";
                    var obj = APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, actthis);
                    var $arguments = System.Array.init([ds], System.Object);
                    var assembly = APLExtension.APL.GetAssembly("DataBinding", actthis);
                    var cl = APLExtension.APL.GetClassByName(ds.Instance);

                    if (System.String.contains(cl,"_Data")) {
                        cl = cl.substr(0, ((cl.length - 5) | 0));
                    }
                    var type = Bridge.Reflection.getType("DataBinding." + (cl || ""), assembly);
                    var method = Bridge.Reflection.getMembers(type, 8, 284, "Do" + (ds.Data || ""));

                    if (method != null) {
                        if (APLExtension.Utils.IsStatic(method)) {
                            result = Bridge.cast(Bridge.Reflection.midel(method, null).apply(null, Bridge.unbox($arguments)), System.String);
                        } else {
                            result = Bridge.cast(Bridge.Reflection.midel(method, Bridge.unbox(Bridge.cast(obj, APLExtension.MJH_CommonData).MJH_Class)).apply(null, Bridge.unbox($arguments)), System.String);
                        }
                    }
                    return result;
                },
                DoGetSerialNo: function (ds, actthis) {
                    var obj = Bridge.cast(APLExtension.APL.GetInstance$3("DataBinding", ds.Class, ds.Instance, actthis), APLExtension.MJH_CommonData);
                    var result = obj.MJH_SerialNo;
                    return result;
                },
                DoDelete: function (ds, actthis) {
                    if (Bridge.referenceEquals(ds.Class, "qwc_Root")) {
                        return ("");
                    }
                    var result = "";

                    var obj = APLExtension.APL.GetInstance(ds.SerialNo);
                    var $arguments = System.Array.init([ds], System.Object);
                    var assembly = APLExtension.APL.GetAssembly("DataBinding", actthis);
                    if (0 !== ds.SerialNo.length) {
                        var cl = APLExtension.APL.GetClassBySerialNo(ds.SerialNo);
                        if (0 !== cl.length) {
                            if (System.String.contains(cl,"_Data")) {
                                cl = cl.substr(0, ((cl.length - 5) | 0));
                            }
                            var type = Bridge.Reflection.getType("DataBinding." + (cl || ""), assembly);

                            var method = Bridge.Reflection.getMembers(type, 8, 284, "DoDelete");

                            if (method != null) {
                                if (APLExtension.Utils.IsStatic(method)) {
                                    result = Bridge.cast(Bridge.Reflection.midel(method, null).apply(null, Bridge.unbox($arguments)), System.String);
                                } else {
                                    var self = Bridge.cast(obj, APLExtension.MJH_CommonData);
                                    result = Bridge.cast(Bridge.Reflection.midel(method, Bridge.unbox(self.MJH_Class)).apply(null, Bridge.unbox($arguments)), System.String);
                                }
                            }
                        }
                        return result;
                    } else {
                        return "";
                    }
                },
                DoSetAccelerator: function (ds, actthis) {
                    var key = System.Convert.toInt32(ds.Args);
                    if (key !== 0) {
                        APLExtension.Accelerator.Add(key, ds.Instance);
                    } else {
                        APLExtension.Accelerator.Remove(key, ds.Instance);

                    }
                    return "";
                }
            }
        }
    });
});

//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAiZmlsZSI6ICJRV0MuanMiLAogICJzb3VyY2VSb290IjogIiIsCiAgInNvdXJjZXMiOiBbIm9iai9EZWJ1Zy9BcHAueGFtbC5nLmNzIiwib2JqL0RlYnVnL01haW5QYWdlLnhhbWwuZy5jcyIsIkFwcC54YW1sLmNzIiwiTWFpblBhZ2UueGFtbC5jcyIsIk1KSF9FbnF1ZXVlLmNzIl0sCiAgIm5hbWVzIjogWyIiXSwKICAibWFwcGluZ3MiOiAiOzs7Ozs7Ozs7Ozs7O29CQVFRQSxXQUEyQkEsQUFBT0E7b0JBQ2xDQSxPQUFPQSxtRUFBNkRBOzs7Ozs7Ozs7O29CQ0RwRUEsV0FBMkJBLEFBQU9BO29CQUNsQ0EsT0FBT0EsbUVBQTZEQTs7Ozs7Ozs7O1lEaXlDeEVBLElBQUlBOzs7Ozs7Ozs7O2dCRXZ4Q0lBO2dCQUVBQTtvQkFFSUEsUUFBNEJBLElBQUlBO29CQUNoQ0EscUVBQStDQTtvQkFDL0NBLDZEQUF1Q0E7Ozs7Z0JBRTNDQSxlQUFlQSxJQUFJQTtnQkFDNUJBLCtDQUErRUE7Z0JBQ3RFQSx5Q0FBeUJBOzs7O21DQUVwQkEsR0FBVUE7Z0JBQzNCQSxTQUFrQkEsWUFBZUEsQUFBQ0EsWUFBU0E7Z0JBQzNDQTtnQkFDQUE7Z0JBQ0FBLFdBQWdCQSxnRkFBdURBO2dCQUN2RUE7O21DQUVpQkEsR0FBVUE7Z0JBQzNCQSxTQUFrQkEsWUFBY0EsQUFBQ0EsWUFBUUE7Z0JBQ3pDQTtnQkFDQUEsSUFBSUEsTUFBS0E7b0JBQVVBOztvQkFDZEE7O2dCQUNMQSxXQUFnQkEsZ0ZBQXVEQTtnQkFDdkVBOzswQ0FFd0JBLEdBQVVBO2dCQUNsQ0EsU0FBa0JBLFlBQWNBLEFBQUNBLFlBQVFBO2dCQUN6Q0EsVUFBY0E7Z0JBQ2RBO2dCQUNBQSxXQUEyQ0EsdUJBQWVBO2dCQUMxREE7Z0JBQ0FBO2dCQUNBQSxXQUFnQkEsZ0ZBQXVEQTtnQkFDdkVBLG9CQUFvQkE7O3FDQUVEQSxHQUFVQTtnQkFDN0JBLFNBQWtCQSxZQUFjQSxBQUFDQSxZQUFRQTtnQkFDekNBO2dCQUNBQTtnQkFDQUEsVUFBY0E7Z0JBQ2RBOzs7O2dCRnBCWUEsSUFBSUE7b0JBQ0FBOztnQkFDSkE7OztnQkFHQUEsSUFBSUE7b0JBRUFBLEFBQUNBLFlBQW1DQSxBQUFRQTs7OztnQkFLNURBO2dCQUNBQTtnQkFDQUE7Z0JBQ0FBOzs7Z0JBR0FBLDBEQUEwREEsSUFBSUE7Z0JBQzlEQSxpQkFBaUJBO2dCQUNqQkEsb0RBQW9EQSxJQUFJQTs7Z0JBRXhEQSxvREFBb0RBLElBQUlBOztnQkFFeERBLDJEQUEyREEsSUFBSUE7O2dCQUUvREEseURBQXlEQSxJQUFJQTs7Z0JBRTdEQSx3REFBd0RBLElBQUlBOztnQkFFNURBLHlEQUF5REEsSUFBSUE7O2dCQUU3REEsNERBQTREQSxJQUFJQTs7Z0JBRWhFQSw4REFBOERBLElBQUlBOztnQkFFbEVBLGlFQUFpRUEsSUFBSUE7O2dCQUVyRUEsMkRBQTJEQSxJQUFJQTs7Z0JBRS9EQSw0REFBNERBLElBQUlBOztnQkFFaEVBLDREQUE0REEsSUFBSUE7O2dCQUVoRUEsOERBQThEQSxJQUFJQTs7Z0JBRWxFQSwrREFBK0RBLElBQUlBOztnQkFFbkVBLHVEQUF1REEsSUFBSUE7O2dCQUUzREEsdURBQXVEQSxJQUFJQTs7Z0JBRTNEQSxzREFBc0RBLElBQUlBOztnQkFFMURBLHNEQUFzREEsSUFBSUE7O2dCQUUxREE7O2dCQUVBQTs7Z0JBRUFBOztnQkFFQUE7O2dCQUVBQTs7Z0JBRUFBOztnQkFFQUE7O2dCQUVBQTs7Z0JBRUFBOztnQkFFQUE7O2dCQUVBQTs7Z0JBRUFBLDZDQUE2Q0EsSUFBSUE7Z0JBQ2pEQSxvREFBb0RBLEFBQU9BO2dCQUMzREEsOENBQThDQSxJQUFJQTtnQkFDbERBLG1EQUFtREE7Z0JBQ25EQSxnREFBZ0RBLElBQUlBLDJEQUE4Q0EsVUFBSUEseUNBQWlDQSxVQUFhQSxZQUFlQSxZQUFlQTs7Z0JBRWxMQSw4Q0FBOENBLElBQUlBO2dCQUNsREEsbURBQW1EQTtnQkFDbkRBOztnQkFFQUEsOENBQThDQSxJQUFJQTtnQkFDbERBLG1EQUFtREE7Z0JBQ25EQSxnREFBZ0RBOztnQkFFaERBLDhDQUE4Q0EsSUFBSUE7Z0JBQ2xEQSxtREFBbURBO2dCQUNuREEsZ0RBQWdEQTs7Z0JBRWhEQSw4Q0FBOENBLElBQUlBO2dCQUNsREEsbURBQW1EQTtnQkFDbkRBLHVEQUF1REEsSUFBSUE7Z0JBQzNEQSw4REFBOERBLEFBQU9BO2dCQUNyRUEseUZBQXlGQSxBQUFpRkE7O29CQUUxS0Esd0RBQXdEQSxJQUFJQTtvQkFDNURBLGtFQUFrRUE7b0JBQ2xFQSxtREFBbURBLElBQUlBO29CQUN2REEsbURBQW1EQSxJQUFJQTtvQkFDdkRBLHdEQUF3REEsSUFBSUE7b0JBQzVEQSw0Q0FBNENBLElBQUlBO29CQUNoREEsOENBQThDQSxJQUFJQTtvQkFDbERBLHNEQUFzREEsSUFBSUE7b0JBQzFEQSw4Q0FBOENBLElBQUlBO29CQUNsREEsOENBQThDQSxJQUFJQTtvQkFDbERBLDhDQUE4Q0EsSUFBSUE7b0JBQ2xEQSw4Q0FBOENBLElBQUlBO29CQUNsREEsOENBQThDQSxJQUFJQTtvQkFDbERBLDhDQUE4Q0EsSUFBSUE7b0JBQ2xEQSx3REFBd0RBLElBQUlBO29CQUM1REEsOENBQThDQSxJQUFJQTtvQkFDbERBLDhDQUE4Q0EsSUFBSUE7b0JBQ2xEQSw0Q0FBNENBLElBQUlBO29CQUNoREEsb0ZBQW9GQTtvQkFDcEZBO29CQUNBQSw4REFBOERBLElBQUlBO29CQUNsRUEsMkZBQTJGQTtvQkFDM0ZBO29CQUNBQSx3RkFBd0ZBO29CQUN4RkE7b0JBQ0FBLGtEQUFrREEsSUFBSUE7b0JBQ3REQSxxRUFBcUVBLElBQUlBO29CQUN6RUEsdUVBQWlFQTtvQkFDakVBLDhEQUE4REEsSUFBSUE7b0JBQ2xFQSxxREFBcURBLElBQUlBOztvQkFFekRBLGdFQUFnRUE7OztvQkFHaEVBLDZFQUE2RUE7OztvQkFHN0VBLHFFQUFxRUEsSUFBSUE7b0JBQ3pFQSx1RUFBaUVBO29CQUNqRUEsOERBQThEQSxJQUFJQTtvQkFDbEVBOztvQkFFQUEsNkVBQTZFQTs7O29CQUc3RUEseURBQXlEQTtvQkFDekRBLHlEQUF5REE7OztvQkFHekRBLDBEQUEwREE7OztvQkFHMURBLHFGQUFxRkE7b0JBQ3JGQTs7b0JBRUFBLDJFQUE2REE7b0JBQzdEQSwyRUFBNkRBOzs7b0JBRzdEQSxtR0FBbUdBOztvQkFFbkdBLHVGQUF1RkE7b0JBQ3ZGQTtvQkFDQUEsNERBQTREQTtvQkFDNURBLDBEQUEwREE7b0JBQzFEQSwrQ0FBK0NBLElBQUlBO29CQUNuREEsK0NBQStDQSxJQUFJQTtvQkFDbkRBLGdEQUFnREEsSUFBSUE7b0JBQ3BEQSxzREFBc0RBLElBQUlBO29CQUMxREEsdURBQXVEQTs7b0JBRXZEQSwwREFBMERBOzs7b0JBRzFEQSx5REFBeURBOztvQkFFekRBLCtDQUErQ0EsSUFBSUE7b0JBQ25EQSxnREFBZ0RBLElBQUlBO29CQUNwREEsc0RBQXNEQSxJQUFJQTtvQkFDMURBLHVEQUF1REE7O29CQUV2REEsMERBQTBEQTs7O29CQUcxREEseURBQXlEQTs7O29CQUd6REEsMkZBQTJGQTtvQkFDM0ZBO29CQUNBQSxnR0FBZ0dBO29CQUNoR0E7b0JBQ0FBLHFEQUFxREEsSUFBSUEsMkRBQThDQSxXQUFJQSwwQ0FBaUNBLGFBQWVBLGFBQWVBLGFBQWVBO29CQUN6TEEsdURBQXVEQSxJQUFJQTtvQkFDM0RBLDRDQUE0Q0EsSUFBSUE7b0JBQ2hEQSxxREFBcURBLElBQUlBO29CQUN6REEsd0RBQXdEQSxJQUFJQSxxREFBd0NBOztvQkFFcEdBLHFEQUFxREEsSUFBSUE7b0JBQ3pEQSx3REFBd0RBLElBQUlBLHFEQUF3Q0E7O29CQUVwR0EseURBQXlEQTtvQkFDekRBLHlEQUF5REE7O29CQUV6REEsc0ZBQXNGQTtvQkFDdEZBO29CQUNBQSxnREFBZ0RBO29CQUNoREEsc0RBQXNEQSxJQUFJQSwyREFBOENBLFdBQUlBLDBDQUFpQ0EsYUFBZUEsYUFBZUEsYUFBZUE7b0JBQzFMQSwwREFBMERBLElBQUlBO29CQUM5REEscURBQXFEQSxJQUFJQSwyREFBOENBLFdBQUlBLDBDQUFpQ0EsYUFBZUEsYUFBZUEsYUFBZUE7b0JBQ3pMQSw0Q0FBNENBLElBQUlBO29CQUNoREEsd0RBQXdEQSxJQUFJQTtvQkFDNURBLDBEQUEwREEsSUFBSUEscURBQXdDQTs7b0JBRXRHQSx3REFBd0RBLElBQUlBO29CQUM1REEsMERBQTBEQSxJQUFJQSxxREFBd0NBOztvQkFFdEdBLHdEQUF3REEsSUFBSUE7b0JBQzVEQSwwREFBMERBLElBQUlBLHFEQUF3Q0E7O29CQUV0R0Esd0RBQXdEQSxJQUFJQTtvQkFDNURBLDBEQUEwREEsSUFBSUEscURBQXdDQTs7b0JBRXRHQSx3REFBd0RBLElBQUlBO29CQUM1REEsMERBQTBEQSxJQUFJQSxxREFBd0NBOztvQkFFdEdBLHdEQUF3REEsSUFBSUE7b0JBQzVEQSwwREFBMERBLElBQUlBLHFEQUF3Q0E7O29CQUV0R0Esd0RBQXdEQSxJQUFJQTtvQkFDNURBLDBEQUEwREEsSUFBSUEscURBQXdDQTs7b0JBRXRHQSw0REFBNERBO29CQUM1REEsNERBQTREQTtvQkFDNURBLDREQUE0REE7b0JBQzVEQSw0REFBNERBO29CQUM1REEsNERBQTREQTtvQkFDNURBLDREQUE0REE7b0JBQzVEQSw0REFBNERBOztvQkFFNURBLDBGQUEwRkE7b0JBQzFGQTtvQkFDQUEsOERBQThEQTtvQkFDOURBLDREQUE0REE7b0JBQzVEQSxxRUFBcUVBO29CQUNyRUEsbUVBQW1FQTtvQkFDbkVBO29CQUNBQSxrREFBa0RBLElBQUlBO29CQUN0REEsNkNBQTZDQSxJQUFJQTtvQkFDakRBLCtDQUErQ0EsSUFBSUE7b0JBQ25EQSxnREFBZ0RBLElBQUlBOzs7O29CQUlwREEsa0RBQWtEQTs7b0JBRWxEQSwrQ0FBK0NBLElBQUlBO29CQUNuREEsZ0RBQWdEQSxJQUFJQTs7OztvQkFJcERBLHFGQUFxRkE7b0JBQ3JGQTtvQkFDQUEsc0RBQWdEQTtvQkFDaERBLHNFQUFzRUE7b0JBQ3RFQSxvRUFBb0VBO29CQUNwRUEseURBQXlEQSxJQUFJQTtvQkFDN0RBLCtDQUErQ0EsSUFBSUE7b0JBQ25EQSxnREFBZ0RBLElBQUlBO29CQUNwREEsc0RBQXNEQSxJQUFJQTtvQkFDMURBLHVEQUF1REE7O29CQUV2REEsMERBQTBEQTs7O29CQUcxREEseURBQXlEQTs7O29CQUd6REEsMEZBQTBGQTtvQkFDMUZBO29CQUNBQSw4REFBOERBO29CQUM5REEsNERBQTREQTtvQkFDNURBLHNEQUFnREE7b0JBQ2hEQSxxRUFBcUVBO29CQUNyRUEsbUVBQW1FQTtvQkFDbkVBO29CQUNBQSxrREFBa0RBLElBQUlBO29CQUN0REEsNkNBQTZDQSxJQUFJQTtvQkFDakRBLCtDQUErQ0EsSUFBSUE7b0JBQ25EQSxnREFBZ0RBLElBQUlBOzs7O29CQUlwREEsa0RBQWtEQTs7b0JBRWxEQSwrQ0FBK0NBLElBQUlBO29CQUNuREEsZ0RBQWdEQSxJQUFJQTs7OztvQkFJcERBLHlGQUF5RkE7b0JBQ3pGQTtvQkFDQUEsOERBQThEQTtvQkFDOURBLDREQUE0REE7b0JBQzVEQSxzREFBZ0RBO29CQUNoREEscUVBQXFFQTtvQkFDckVBLG1FQUFtRUE7b0JBQ25FQTtvQkFDQUEsa0RBQWtEQSxJQUFJQTtvQkFDdERBLGlEQUFpREE7b0JBQ2pEQSw2Q0FBNkNBLElBQUlBO29CQUNqREEsK0NBQStDQSxJQUFJQTtvQkFDbkRBLGdEQUFnREEsSUFBSUE7Ozs7b0JBSXBEQSxrREFBa0RBOztvQkFFbERBLCtDQUErQ0EsSUFBSUE7b0JBQ25EQSxnREFBZ0RBLElBQUlBOzs7O29CQUlwREEseUZBQXlGQTtvQkFDekZBO29CQUNBQSw4REFBOERBO29CQUM5REEsNERBQTREQTtvQkFDNURBLHNEQUFnREE7b0JBQ2hEQSxxRUFBcUVBO29CQUNyRUEsbUVBQW1FQTtvQkFDbkVBO29CQUNBQSxrREFBa0RBLElBQUlBO29CQUN0REEsaURBQWlEQTtvQkFDakRBLDZDQUE2Q0EsSUFBSUE7b0JBQ2pEQSwrQ0FBK0NBLElBQUlBO29CQUNuREEsZ0RBQWdEQSxJQUFJQTs7OztvQkFJcERBLGtEQUFrREE7O29CQUVsREEsK0NBQStDQSxJQUFJQTtvQkFDbkRBLGdEQUFnREEsSUFBSUE7Ozs7b0JBSXBEQSxnR0FBZ0dBO29CQUNoR0E7b0JBQ0FBLDhEQUE4REE7b0JBQzlEQSw0REFBNERBO29CQUM1REEsc0RBQWdEQTtvQkFDaERBLHFFQUFxRUE7b0JBQ3JFQSxtRUFBbUVBO29CQUNuRUE7b0JBQ0FBLGtEQUFrREEsSUFBSUE7b0JBQ3REQSxpREFBaURBO29CQUNqREEsNkNBQTZDQSxJQUFJQTtvQkFDakRBLCtDQUErQ0EsSUFBSUE7b0JBQ25EQSxnREFBZ0RBLElBQUlBOzs7O29CQUlwREEsa0RBQWtEQTs7b0JBRWxEQSwrQ0FBK0NBLElBQUlBO29CQUNuREEsZ0RBQWdEQSxJQUFJQTs7OztvQkFJcERBLDJGQUEyRkE7b0JBQzNGQTtvQkFDQUEsOERBQThEQTtvQkFDOURBLDREQUE0REE7b0JBQzVEQSxzREFBZ0RBO29CQUNoREEscUVBQXFFQTtvQkFDckVBLG1FQUFtRUE7b0JBQ25FQTtvQkFDQUEsa0RBQWtEQSxJQUFJQTtvQkFDdERBLGlEQUFpREE7b0JBQ2pEQSw2Q0FBNkNBLElBQUlBO29CQUNqREEsK0NBQStDQSxJQUFJQTtvQkFDbkRBLGdEQUFnREEsSUFBSUE7Ozs7b0JBSXBEQSxrREFBa0RBOztvQkFFbERBLCtDQUErQ0EsSUFBSUE7b0JBQ25EQSxnREFBZ0RBLElBQUlBOzs7O29CQUlwREEsbURBQW1EQTtvQkFDbkRBLG1EQUFtREE7b0JBQ25EQSxtREFBbURBO29CQUNuREEsbURBQW1EQTtvQkFDbkRBLG1EQUFtREE7b0JBQ25EQSxtREFBbURBO29CQUNuREEsbURBQW1EQTs7O29CQUduREEsZ0RBQWdEQTs7b0JBRWhEQSwrQ0FBK0NBLElBQUlBO29CQUNuREEsZ0RBQWdEQSxJQUFJQTs7OztvQkFJcERBLDhDQUE4Q0EsSUFBSUE7b0JBQ2xEQSxtREFBNkNBO29CQUM3Q0EsMERBQTBEQSxJQUFJQTtvQkFDOURBLG9HQUFvR0E7b0JBQ3BHQTtvQkFDQUE7b0JBQ0FBLCtDQUErQ0EsSUFBSUE7b0JBQ25EQSxnREFBZ0RBLElBQUlBO29CQUNwREEsc0RBQXNEQSxJQUFJQTtvQkFDMURBLHVEQUF1REE7O29CQUV2REEsMERBQTBEQTs7O29CQUcxREEseURBQXlEQTs7b0JBRXpEQSwrQ0FBK0NBLElBQUlBO29CQUNuREEsZ0RBQWdEQSxJQUFJQTtvQkFDcERBLHNEQUFzREEsSUFBSUE7b0JBQzFEQSx1REFBdURBOztvQkFFdkRBLDBEQUEwREE7OztvQkFHMURBLHlEQUF5REE7O29CQUV6REEsK0NBQStDQSxJQUFJQTtvQkFDbkRBLGdEQUFnREEsSUFBSUE7OztvQkFHcERBLCtDQUErQ0EsSUFBSUE7b0JBQ25EQSxnREFBZ0RBLElBQUlBOzs7b0JBR3BEQSwrQ0FBK0NBLElBQUlBO29CQUNuREEsZ0RBQWdEQSxJQUFJQTtvQkFDcERBLHNEQUFzREEsSUFBSUE7b0JBQzFEQSx1REFBdURBOztvQkFFdkRBLDBEQUEwREE7OztvQkFHMURBLHlEQUF5REE7O29CQUV6REEsK0NBQStDQSxJQUFJQTtvQkFDbkRBLGdEQUFnREEsSUFBSUE7b0JBQ3BEQSxzREFBc0RBLElBQUlBO29CQUMxREEsdURBQXVEQTs7b0JBRXZEQSwwREFBMERBOzs7b0JBRzFEQSx5REFBeURBOzs7b0JBR3pEQSxnREFBZ0RBOztvQkFFaERBLCtDQUErQ0EsSUFBSUE7b0JBQ25EQSxnREFBZ0RBLElBQUlBOzs7b0JBR3BEQSwrQ0FBK0NBLElBQUlBO29CQUNuREEsZ0RBQWdEQSxJQUFJQTs7O29CQUdwREEsK0NBQStDQSxJQUFJQTtvQkFDbkRBLGdEQUFnREEsSUFBSUE7b0JBQ3BEQSxzREFBc0RBLElBQUlBO29CQUMxREEsdURBQXVEQTs7b0JBRXZEQSwwREFBMERBOzs7b0JBRzFEQSx5REFBeURBOztvQkFFekRBLCtDQUErQ0EsSUFBSUE7b0JBQ25EQSxnREFBZ0RBLElBQUlBO29CQUNwREEsc0RBQXNEQSxJQUFJQTtvQkFDMURBLHVEQUF1REE7O29CQUV2REEsMERBQTBEQTs7O29CQUcxREEseURBQXlEQTs7O29CQUd6REEsbURBQW1EQTtvQkFDbkRBLG1EQUFtREE7OztvQkFHbkRBLGdEQUFnREE7O29CQUVoREEsK0NBQStDQSxJQUFJQTtvQkFDbkRBLGdEQUFnREEsSUFBSUE7b0JBQ3BEQSxzREFBc0RBLElBQUlBO29CQUMxREEsdURBQXVEQTs7b0JBRXZEQSwwREFBMERBOzs7b0JBRzFEQSx5REFBeURBOztvQkFFekRBLCtDQUErQ0EsSUFBSUE7b0JBQ25EQSxnREFBZ0RBLElBQUlBO29CQUNwREEsc0RBQXNEQSxJQUFJQTtvQkFDMURBLHVEQUF1REE7O29CQUV2REEsMERBQTBEQTs7O29CQUcxREEseURBQXlEQTs7O29CQUd6REEsZ0RBQWdEQTs7O29CQUdoREEsbURBQW1EQTtvQkFDbkRBLG1EQUFtREE7O29CQUVuREEsK0NBQStDQSxJQUFJQTtvQkFDbkRBLGdEQUFnREEsSUFBSUE7b0JBQ3BEQSxzREFBc0RBLElBQUlBO29CQUMxREEsdURBQXVEQTs7b0JBRXZEQSwwREFBMERBOzs7b0JBRzFEQSx5REFBeURBOztvQkFFekRBLCtDQUErQ0EsSUFBSUE7b0JBQ25EQSxnREFBZ0RBLElBQUlBO29CQUNwREEsc0RBQXNEQSxJQUFJQTtvQkFDMURBLHVEQUF1REE7O29CQUV2REEsMERBQTBEQTs7O29CQUcxREEseURBQXlEQTs7b0JBRXpEQSwrQ0FBK0NBLElBQUlBO29CQUNuREEsZ0RBQWdEQSxJQUFJQTtvQkFDcERBLHNEQUFzREEsSUFBSUE7b0JBQzFEQSx1REFBdURBOztvQkFFdkRBLDBEQUEwREE7OztvQkFHMURBLHlEQUF5REE7O29CQUV6REEsK0NBQStDQSxJQUFJQTtvQkFDbkRBLGdEQUFnREEsSUFBSUE7b0JBQ3BEQSxzREFBc0RBLElBQUlBO29CQUMxREEsdURBQXVEQTs7b0JBRXZEQSwwREFBMERBOzs7b0JBRzFEQSx5REFBeURBOzs7b0JBR3pEQSxnRUFBMERBLHVDQUF1Q0EsaUVBQTJEQTtvQkFDNUpBLGdFQUEwREEsdUNBQXVDQSx5REFBbURBO29CQUNwSkEsZ0VBQTBEQSx3Q0FBd0NBLDZEQUF1REE7b0JBQ3pKQSxnRUFBMERBLHlDQUF5Q0EsNERBQXNEQTtvQkFDekpBLGdFQUEwREEsaURBQWlEQSx1RUFBaUVBO29CQUM1S0EsZ0VBQTBEQSx3Q0FBd0NBLDZEQUF1REE7b0JBQ3pKQSxnRUFBMERBLHlDQUF5Q0EsNERBQXNEQTtvQkFDekpBLGdFQUEwREEsd0NBQXdDQSw2REFBdURBO29CQUN6SkEsZ0VBQTBEQSx5Q0FBeUNBLDREQUFzREE7b0JBQ3pKQSxnRUFBMERBLHdDQUF3Q0EsNkRBQXVEQTtvQkFDekpBLGdFQUEwREEseUNBQXlDQSw0REFBc0RBO29CQUN6SkEsZ0VBQTBEQSx3Q0FBd0NBLDZEQUF1REE7b0JBQ3pKQSxnRUFBMERBLHlDQUF5Q0EsNERBQXNEQTtvQkFDekpBLGdFQUEwREEsd0NBQXdDQSw2REFBdURBO29CQUN6SkEsZ0VBQTBEQSx5Q0FBeUNBLDREQUFzREE7b0JBQ3pKQSxnRUFBMERBLHlDQUF5Q0EsNERBQXNEQTtvQkFDekpBLGdFQUEwREEsbURBQW1EQSx1RUFBaUVBO29CQUM5S0EsZ0VBQTBEQSxtREFBbURBLCtFQUF5RUE7b0JBQ3RMQSxnRUFBMERBLG1EQUFtREEsOERBQXdEQTtvQkFDcktBLGdFQUEwREEsbURBQW1EQSwrREFBeURBO29CQUN0S0EsZ0VBQTBEQSxtREFBbURBLDRFQUFzRUE7b0JBQ25MQSxnRUFBMERBLG1EQUFtREEsMEVBQW9FQTtvQkFDakxBLGdFQUEwREEseUNBQXlDQSwrREFBeURBO29CQUM1SkEsZ0VBQTBEQSx5Q0FBeUNBLDhEQUF3REE7b0JBQzNKQSxnRUFBMERBLHlDQUF5Q0Esa0VBQTREQTtvQkFDL0pBLGdFQUEwREEseUNBQXlDQSxtRUFBNkRBO29CQUNoS0EsZ0VBQTBEQSx5Q0FBeUNBLHVFQUFpRUE7b0JBQ3BLQSxnRUFBMERBLHlDQUF5Q0EsbUVBQTZEQTtvQkFDaEtBLGdFQUEwREEsdUNBQXVDQSwrREFBeURBO29CQUMxSkEsZ0VBQTBEQSx1Q0FBdUNBLDhEQUF3REE7b0JBQ3pKQSxnRUFBMERBLHVDQUF1Q0EsNEVBQXNFQTtvQkFDdktBLGdFQUEwREEsdUNBQXVDQSwwRUFBb0VBOztvQkFFcktBLDJFQUFxRUEsZ0VBQ2pFQSxJQUFJQSw4RUFHQUEsNEZBQ0FBLHlGQUNBQSxrR0FDQUEsOEZBQ0FBO29CQUNSQSxtRUFBNkRBLGdFQUFnRUE7OztvQkFHN0hBLDJFQUFxRUEsZ0VBQ2pFQSxJQUFJQSwwRkFHQUEsNEZBQ0FBLHlGQUNBQSxrR0FDQUEsOEZBQ0FBO29CQUNSQSxtRUFBNkRBLGdFQUFnRUE7O29CQUU3SEEsb0VBQW9FQTtvQkFDcEVBLE9BQU9BOzs7Z0JBR1BBLGdEQUFnREE7OztnQkFHaERBLG1EQUFtREE7Z0JBQ25EQSxtREFBbURBO2dCQUNuREEsbURBQW1EQTtnQkFDbkRBLG1EQUFtREE7Z0JBQ25EQSxtREFBbURBOzs7Z0JBR25EQSw2Q0FBNkNBLElBQUlBO2dCQUNqREEsb0RBQW9EQSxBQUFPQTtnQkFDM0RBLDhDQUE4Q0EsSUFBSUE7Z0JBQ2xEQSxtREFBbURBO2dCQUNuREEsZ0RBQWdEQSxJQUFJQSwyREFBOENBLFVBQUlBLHlDQUFpQ0EsWUFBZUEsWUFBZUEsWUFBZUE7O2dCQUVwTEEsOENBQThDQSxJQUFJQTtnQkFDbERBLG1EQUFtREE7Z0JBQ25EQSxnREFBZ0RBLElBQUlBLDJEQUE4Q0EsVUFBSUEseUNBQWlDQSxZQUFlQSxVQUFhQSxVQUFhQTs7Z0JBRWhMQSw4Q0FBOENBLElBQUlBO2dCQUNsREEsbURBQW1EQTtnQkFDbkRBLGdEQUFnREEsSUFBSUE7O2dCQUVwREEsOENBQThDQSxJQUFJQTtnQkFDbERBLG1EQUFtREE7Z0JBQ25EQSxnREFBZ0RBLElBQUlBOztnQkFFcERBLDhDQUE4Q0EsSUFBSUE7Z0JBQ2xEQSxtREFBbURBO2dCQUNuREEsZ0RBQWdEQTs7Z0JBRWhEQSw4Q0FBOENBLElBQUlBO2dCQUNsREEsbURBQW1EQTtnQkFDbkRBLGdEQUFnREE7O2dCQUVoREEsOENBQThDQSxJQUFJQTtnQkFDbERBLG1EQUFtREE7Z0JBQ25EQSxnREFBZ0RBOztnQkFFaERBLDhDQUE4Q0EsSUFBSUE7Z0JBQ2xEQSxtREFBbURBO2dCQUNuREEsdURBQXVEQSxJQUFJQTtnQkFDM0RBLDhEQUE4REEsQUFBT0E7Z0JBQ3JFQSx5RkFBeUZBLEFBQWlGQTtvQkFFMUtBLHdEQUF3REEsSUFBSUE7b0JBQzVEQSxrRUFBa0VBO29CQUNsRUEsbURBQW1EQSxJQUFJQTtvQkFDdkRBLG1EQUFtREEsSUFBSUE7b0JBQ3ZEQSxtREFBbURBLElBQUlBO29CQUN2REEsbURBQW1EQSxJQUFJQTtvQkFDdkRBLHdEQUF3REEsSUFBSUE7b0JBQzVEQSx3REFBd0RBLElBQUlBO29CQUM1REEsOENBQThDQSxJQUFJQTtvQkFDbERBLDhDQUE4Q0EsSUFBSUE7b0JBQ2xEQSwyRkFBMkZBO29CQUMzRkE7b0JBQ0FBLDRGQUE0RkE7b0JBQzVGQTtvQkFDQUEsc0ZBQXNGQTtvQkFDdEZBOztvQkFFQUEsMkZBQTJGQTtvQkFDM0ZBO29CQUNBQSxrREFBa0RBLElBQUlBO29CQUN0REEscUVBQXFFQSxJQUFJQTtvQkFDekVBLHVFQUFpRUE7b0JBQ2pFQSw4REFBOERBLElBQUlBO29CQUNsRUEsa0VBQWtFQSxtRUFBNkRBLElBQUlBO29CQUNuSUE7O29CQUVBQSw2RUFBNkVBOzs7b0JBRzdFQSx5REFBeURBOzs7b0JBR3pEQSwwREFBMERBOzs7b0JBRzFEQSx1RkFBdUZBO29CQUN2RkE7b0JBQ0FBLGtEQUFrREEsSUFBSUE7b0JBQ3REQSxxRUFBcUVBLElBQUlBO29CQUN6RUEsdUVBQWlFQTtvQkFDakVBLDhEQUE4REEsSUFBSUE7b0JBQ2xFQSxrRUFBa0VBLG1FQUE2REEsSUFBSUE7b0JBQ25JQTs7b0JBRUFBLDZFQUE2RUE7OztvQkFHN0VBLHlEQUF5REE7OztvQkFHekRBLDBEQUEwREE7OztvQkFHMURBLHdGQUF3RkE7b0JBQ3hGQTtvQkFDQUEsa0RBQWtEQSxJQUFJQTtvQkFDdERBLHFFQUFxRUEsSUFBSUE7b0JBQ3pFQSx1RUFBaUVBO29CQUNqRUEsOERBQThEQSxJQUFJQTtvQkFDbEVBLGtFQUFrRUEsbUVBQTZEQSxJQUFJQTtvQkFDbklBOztvQkFFQUEsNkVBQTZFQTs7O29CQUc3RUEseURBQXlEQTs7O29CQUd6REEsMERBQTBEQTs7O29CQUcxREEsMkVBQTZEQTtvQkFDN0RBLDJFQUE2REE7b0JBQzdEQSwyRUFBNkRBO29CQUM3REEsMkVBQTZEQTs7O29CQUc3REEsbUdBQW1HQTs7b0JBRW5HQSwyRkFBMkZBO29CQUMzRkE7b0JBQ0FBLGdHQUFnR0E7b0JBQ2hHQTtvQkFDQUEsK0NBQStDQSxJQUFJQTtvQkFDbkRBLGdEQUFnREEsSUFBSUE7b0JBQ3BEQSxzREFBc0RBLElBQUlBO29CQUMxREEsdURBQXVEQTs7b0JBRXZEQSwwREFBMERBOzs7b0JBRzFEQSx5REFBeURBOztvQkFFekRBLCtDQUErQ0EsSUFBSUE7b0JBQ25EQSxnREFBZ0RBLElBQUlBO29CQUNwREEsc0RBQXNEQSxJQUFJQTtvQkFDMURBLHVEQUF1REE7O29CQUV2REEsMERBQTBEQTs7O29CQUcxREEseURBQXlEQTs7b0JBRXpEQSwrQ0FBK0NBLElBQUlBO29CQUNuREEsZ0RBQWdEQSxJQUFJQTtvQkFDcERBLHNEQUFzREEsSUFBSUE7b0JBQzFEQSx1REFBdURBOztvQkFFdkRBLDBEQUEwREE7OztvQkFHMURBLHlEQUF5REE7O29CQUV6REEsK0NBQStDQSxJQUFJQTtvQkFDbkRBLGdEQUFnREEsSUFBSUE7b0JBQ3BEQSxzREFBc0RBLElBQUlBO29CQUMxREEsdURBQXVEQTs7b0JBRXZEQSwwREFBMERBOzs7b0JBRzFEQSx5REFBeURBOztvQkFFekRBLCtDQUErQ0EsSUFBSUE7b0JBQ25EQSxnREFBZ0RBLElBQUlBO29CQUNwREEsc0RBQXNEQSxJQUFJQTtvQkFDMURBLHVEQUF1REE7O29CQUV2REEsMERBQTBEQTs7O29CQUcxREEseURBQXlEQTs7b0JBRXpEQSwrQ0FBK0NBLElBQUlBO29CQUNuREEsZ0RBQWdEQSxJQUFJQTtvQkFDcERBLHNEQUFzREEsSUFBSUE7b0JBQzFEQSx1REFBdURBOztvQkFFdkRBLDBEQUEwREE7OztvQkFHMURBLHlEQUF5REE7O29CQUV6REEsK0NBQStDQSxJQUFJQTtvQkFDbkRBLGdEQUFnREEsSUFBSUE7b0JBQ3BEQSxzREFBc0RBLElBQUlBO29CQUMxREEsdURBQXVEQTs7b0JBRXZEQSwwREFBMERBOzs7b0JBRzFEQSx5REFBeURBOztvQkFFekRBLCtDQUErQ0EsSUFBSUE7b0JBQ25EQSxnREFBZ0RBLElBQUlBOzs7O29CQUlwREEsZ0RBQWdEQTs7b0JBRWhEQSwrQ0FBK0NBLElBQUlBO29CQUNuREEsZ0RBQWdEQSxJQUFJQTtvQkFDcERBLHNEQUFzREEsSUFBSUE7b0JBQzFEQSx1REFBdURBOztvQkFFdkRBLDBEQUEwREE7OztvQkFHMURBLHlEQUF5REE7OztvQkFHekRBLGdEQUFnREE7O29CQUVoREEsK0NBQStDQSxJQUFJQTtvQkFDbkRBLGdEQUFnREEsSUFBSUE7b0JBQ3BEQSxzREFBc0RBLElBQUlBO29CQUMxREEsdURBQXVEQTs7b0JBRXZEQSwwREFBMERBOzs7b0JBRzFEQSx5REFBeURBOztvQkFFekRBLCtDQUErQ0EsSUFBSUE7b0JBQ25EQSxnREFBZ0RBLElBQUlBO29CQUNwREEsc0RBQXNEQSxJQUFJQTtvQkFDMURBLHVEQUF1REE7O29CQUV2REEsMERBQTBEQTs7O29CQUcxREEseURBQXlEQTs7b0JBRXpEQSwrQ0FBK0NBLElBQUlBO29CQUNuREEsZ0RBQWdEQSxJQUFJQTtvQkFDcERBLHNEQUFzREEsSUFBSUE7b0JBQzFEQSx1REFBdURBOztvQkFFdkRBLDBEQUEwREE7OztvQkFHMURBLHlEQUF5REE7O29CQUV6REEsK0NBQStDQSxJQUFJQTtvQkFDbkRBLGdEQUFnREEsSUFBSUE7b0JBQ3BEQSxzREFBc0RBLElBQUlBO29CQUMxREEsdURBQXVEQTs7b0JBRXZEQSwwREFBMERBOzs7b0JBRzFEQSx5REFBeURBOztvQkFFekRBLCtDQUErQ0EsSUFBSUE7b0JBQ25EQSxnREFBZ0RBLElBQUlBOzs7O29CQUlwREEsZ0VBQTBEQSxtREFBbURBLCtFQUF5RUE7b0JBQ3RMQSxnRUFBMERBLG1EQUFtREEsdUVBQWlFQTtvQkFDOUtBLGdFQUEwREEsbURBQW1EQSwrREFBeURBO29CQUN0S0EsZ0VBQTBEQSxtREFBbURBLDhEQUF3REE7b0JBQ3JLQSxnRUFBMERBLG1EQUFtREEsK0RBQXlEQTtvQkFDdEtBLGdFQUEwREEsbURBQW1EQSw0RUFBc0VBO29CQUNuTEEsZ0VBQTBEQSxtREFBbURBLDBFQUFvRUE7b0JBQ2pMQSxnRUFBMERBLG1EQUFtREEsNERBQXNEQTtvQkFDbktBLGdFQUEwREEseUNBQXlDQSxrRUFBNERBO29CQUMvSkEsZ0VBQTBEQSx5Q0FBeUNBLGtFQUE0REE7b0JBQy9KQSxnRUFBMERBLHlDQUF5Q0EsbUVBQTZEQTtvQkFDaEtBLGdFQUEwREEseUNBQXlDQSx1RUFBaUVBO29CQUNwS0EsZ0VBQTBEQSx5Q0FBeUNBLCtEQUF5REE7b0JBQzVKQSxnRUFBMERBLHlDQUF5Q0EsNERBQXNEQTs7b0JBRXpKQSwyRUFBcUVBLGdFQUNqRUEsSUFBSUEsOEVBR0FBLDRGQUNBQSx5RkFDQUEsa0dBQ0FBLDhGQUNBQTtvQkFDUkEsbUVBQTZEQSxnRUFBZ0VBOzs7b0JBRzdIQSwyRUFBcUVBLGdFQUNqRUEsSUFBSUEsOEVBR0FBLDRGQUNBQSx5RkFDQUEsa0dBQ0FBLDhGQUNBQTtvQkFDUkEsbUVBQTZEQSxnRUFBZ0VBOzs7b0JBRzdIQSwyRUFBcUVBLGdFQUNqRUEsSUFBSUEsOEVBR0FBLDRGQUNBQSx5RkFDQUEsa0dBQ0FBLDhGQUNBQTtvQkFDUkEsbUVBQTZEQSxnRUFBZ0VBOztvQkFFN0hBLG9FQUFvRUE7b0JBQ3BFQSxPQUFPQTs7O2dCQUdQQSxnREFBZ0RBOzs7Z0JBR2hEQSxtREFBbURBO2dCQUNuREEsbURBQW1EQTtnQkFDbkRBLG1EQUFtREE7Z0JBQ25EQSxtREFBbURBO2dCQUNuREEsbURBQW1EQTtnQkFDbkRBLG1EQUFtREE7Z0JBQ25EQSxtREFBbURBO2dCQUNuREEsbURBQW1EQTs7O2dCQUduREEsNEVBQXNFQTtnQkFDdEVBLDRFQUFzRUE7Z0JBQ3RFQSxtRkFBNkVBO2dCQUM3RUEsaUZBQTJFQTtnQkFDM0VBLGdGQUEwRUE7Z0JBQzFFQSxpRkFBMkVBO2dCQUMzRUEsb0ZBQThFQTtnQkFDOUVBLHNGQUFnRkE7Z0JBQ2hGQSx5RkFBbUZBO2dCQUNuRkEsbUZBQTZFQTtnQkFDN0VBLG9GQUE4RUE7Z0JBQzlFQSxvRkFBOEVBO2dCQUM5RUEsc0ZBQWdGQTtnQkFDaEZBLHVGQUFpRkE7Z0JBQ2pGQSwrRUFBeUVBO2dCQUN6RUEsK0VBQXlFQTtnQkFDekVBLDhFQUF3RUE7Z0JBQ3hFQSw4RUFBd0VBO2dCQUN4RUEsMkVBQXFFQTtnQkFDckVBLHFFQUErREE7Z0JBQy9EQSx1RUFBaUVBO2dCQUNqRUEsb0VBQThEQTtnQkFDOURBLHFFQUErREE7Z0JBQy9EQSx1RUFBaUVBO2dCQUNqRUEsb0VBQThEQTtnQkFDOURBLG9FQUE4REE7Z0JBQzlEQSxvRUFBOERBO2dCQUM5REEsOEVBQXdFQTtnQkFDeEVBLHlFQUFtRUE7Z0JBQ25FQSw0RUFBc0VBO2dCQUN0RUEsNEVBQXNFQTs7Z0JBRXRFQSxpQkFBaUJBOzs7Ozs7Ozs7a0ZBWW1OQTs7Ozs7Ozs7Ozs7O3dDQUdwT0E7Ozs7Ozs7Ozs7Ozs7OzsrRUFJcUVBLHFCQUE4REE7O2dCQUduSUEsOEJBQThDQTtnQkFDOUNBLDRCQUE0Q0E7Z0JBQzVDQSxvQkFBb0RBO2dCQUNwREEsZUFBc0RBLFlBQTRDQSw2Q0FBdUJBOztnQkFFdkhBLENBQUNBLHlDQUF5Q0EsVUFBVUE7O3dGQUl3QkEscUJBQThEQTs7Z0JBRzVJQSw4QkFBOENBO2dCQUM5Q0EsNEJBQTRDQTtnQkFDNUNBLG9CQUFvREE7Z0JBQ3BEQSxlQUFzREEsWUFBNENBLDZDQUF1QkE7O2dCQUV2SEEsQ0FBQ0EsdUNBQXVDQSxVQUFVQTs7b0ZBSXNCQSxxQkFBOERBOztnQkFHeElBLDhCQUE4Q0E7Z0JBQzlDQSw0QkFBNENBO2dCQUM1Q0Esb0JBQW9EQTtnQkFDcERBLGVBQXNEQSxZQUE0Q0EsNkNBQXVCQTs7Z0JBRXZIQSxDQUFDQSxxQ0FBcUNBLFVBQVVBOzsrRUFJb0NBOztnQkFHdEZBLDhCQUE4Q0E7Z0JBQzlDQSw0QkFBNENBO2dCQUM1Q0Esb0JBQW9EQTtnQkFDcERBLGVBQXNEQSxZQUE0Q0EsNkNBQXVCQTs7Z0JBRXZIQSxPQUFPQSx3Q0FBd0NBOztrRkFJbUxBOzs7Ozs7Ozs7Ozs7d0NBR3BPQTs7Ozs7Ozs7Ozs7Ozs7OytFQUlxRUEscUJBQThEQTs7Z0JBR25JQSw4QkFBOENBO2dCQUM5Q0EsNEJBQTRDQTtnQkFDNUNBLG9CQUFvREE7Z0JBQ3BEQSxlQUFzREEsWUFBNENBLDZDQUF1QkE7O2dCQUV2SEEsQ0FBQ0EseUNBQXlDQSxVQUFVQTs7d0ZBSXdCQSxxQkFBOERBOztnQkFHNUlBLDhCQUE4Q0E7Z0JBQzlDQSw0QkFBNENBO2dCQUM1Q0Esb0JBQW9EQTtnQkFDcERBLGVBQXNEQSxZQUE0Q0EsNkNBQXVCQTs7Z0JBRXZIQSxDQUFDQSx1Q0FBdUNBLFVBQVVBOztvRkFJc0JBLHFCQUE4REE7O2dCQUd4SUEsOEJBQThDQTtnQkFDOUNBLDRCQUE0Q0E7Z0JBQzVDQSxvQkFBb0RBO2dCQUNwREEsZUFBc0RBLFlBQTRDQSw2Q0FBdUJBOztnQkFFdkhBLENBQUNBLHFDQUFxQ0EsVUFBVUE7OytFQUlvQ0E7O2dCQUd0RkEsOEJBQThDQTtnQkFDOUNBLDRCQUE0Q0E7Z0JBQzVDQSxvQkFBb0RBO2dCQUNwREEsZUFBc0RBLFlBQTRDQSw2Q0FBdUJBOztnQkFFdkhBLE9BQU9BLHdDQUF3Q0E7O2tGQUltTEE7Ozs7Ozs7Ozs7Ozt3Q0FHcE9BOzs7Ozs7Ozs7Ozs7Ozs7K0VBSXFFQSxxQkFBOERBOztnQkFHbklBLDhCQUE4Q0E7Z0JBQzlDQSw0QkFBNENBO2dCQUM1Q0Esb0JBQW9EQTtnQkFDcERBLGVBQXNEQSxZQUE0Q0EsNkNBQXVCQTs7Z0JBRXZIQSxDQUFDQSx5Q0FBeUNBLFVBQVVBOzt3RkFJd0JBLHFCQUE4REE7O2dCQUc1SUEsOEJBQThDQTtnQkFDOUNBLDRCQUE0Q0E7Z0JBQzVDQSxvQkFBb0RBO2dCQUNwREEsZUFBc0RBLFlBQTRDQSw2Q0FBdUJBOztnQkFFdkhBLENBQUNBLHVDQUF1Q0EsVUFBVUE7O29GQUlzQkEscUJBQThEQTs7Z0JBR3hJQSw4QkFBOENBO2dCQUM5Q0EsNEJBQTRDQTtnQkFDNUNBLG9CQUFvREE7Z0JBQ3BEQSxlQUFzREEsWUFBNENBLDZDQUF1QkE7O2dCQUV2SEEsQ0FBQ0EscUNBQXFDQSxVQUFVQTs7K0VBSW9DQTs7Z0JBR3RGQSw4QkFBOENBO2dCQUM5Q0EsNEJBQTRDQTtnQkFDNUNBLG9CQUFvREE7Z0JBQ3BEQSxlQUFzREEsWUFBNENBLDZDQUF1QkE7O2dCQUV2SEEsT0FBT0Esd0NBQXdDQTs7a0ZBSW1MQTs7Ozs7Ozs7Ozs7O3dDQUdwT0E7Ozs7Ozs7Ozs7Ozs7OzsrRUFJcUVBLHFCQUE4REE7O2dCQUduSUEsOEJBQThDQTtnQkFDOUNBLDRCQUE0Q0E7Z0JBQzVDQSxvQkFBb0RBO2dCQUNwREEsZUFBc0RBLFlBQTRDQSw2Q0FBdUJBOztnQkFFdkhBLENBQUNBLHlDQUF5Q0EsVUFBVUE7O3dGQUl3QkEscUJBQThEQTs7Z0JBRzVJQSw4QkFBOENBO2dCQUM5Q0EsNEJBQTRDQTtnQkFDNUNBLG9CQUFvREE7Z0JBQ3BEQSxlQUFzREEsWUFBNENBLDZDQUF1QkE7O2dCQUV2SEEsQ0FBQ0EsdUNBQXVDQSxVQUFVQTs7b0ZBSXNCQSxxQkFBOERBOztnQkFHeElBLDhCQUE4Q0E7Z0JBQzlDQSw0QkFBNENBO2dCQUM1Q0Esb0JBQW9EQTtnQkFDcERBLGVBQXNEQSxZQUE0Q0EsNkNBQXVCQTs7Z0JBRXZIQSxDQUFDQSxxQ0FBcUNBLFVBQVVBOzsrRUFJb0NBOztnQkFHdEZBLDhCQUE4Q0E7Z0JBQzlDQSw0QkFBNENBO2dCQUM1Q0Esb0JBQW9EQTtnQkFDcERBLGVBQXNEQSxZQUE0Q0EsNkNBQXVCQTs7Z0JBRXZIQSxPQUFPQSx3Q0FBd0NBOztrRkFJbUxBOzs7Ozs7Ozs7Ozs7d0NBR3BPQTs7Ozs7Ozs7Ozs7Ozs7OytFQUlxRUEscUJBQThEQTs7Z0JBR25JQSw4QkFBOENBO2dCQUM5Q0EsNEJBQTRDQTtnQkFDNUNBLG9CQUFvREE7Z0JBQ3BEQSxlQUFzREEsWUFBNENBLDZDQUF1QkE7O2dCQUV2SEEsQ0FBQ0EseUNBQXlDQSxVQUFVQTs7d0ZBSXdCQSxxQkFBOERBOztnQkFHNUlBLDhCQUE4Q0E7Z0JBQzlDQSw0QkFBNENBO2dCQUM1Q0Esb0JBQW9EQTtnQkFDcERBLGVBQXNEQSxZQUE0Q0EsNkNBQXVCQTs7Z0JBRXZIQSxDQUFDQSx1Q0FBdUNBLFVBQVVBOztvRkFJc0JBLHFCQUE4REE7O2dCQUd4SUEsOEJBQThDQTtnQkFDOUNBLDRCQUE0Q0E7Z0JBQzVDQSxvQkFBb0RBO2dCQUNwREEsZUFBc0RBLFlBQTRDQSw2Q0FBdUJBOztnQkFFdkhBLENBQUNBLHFDQUFxQ0EsVUFBVUE7OytFQUlvQ0E7O2dCQUd0RkEsOEJBQThDQTtnQkFDOUNBLDRCQUE0Q0E7Z0JBQzVDQSxvQkFBb0RBO2dCQUNwREEsZUFBc0RBLFlBQTRDQSw2Q0FBdUJBOztnQkFFdkhBLE9BQU9BLHdDQUF3Q0E7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O29CRzF3Q1pBLE9BQU9BOzs7OztvQkFFSEEsT0FBT0E7Ozs7OztrQ0FIUUEsSUFBSUE7c0NBRVBBLElBQUlBOzs7Ozs7Ozs7Z0JBU3pEQTs7Ozs7Z0JBR0FBO2dCQUNBQSxrQkFBa0JBLHFDQUFNQTtnQkFDeEJBLDJCQUEyQkEscUNBQU1BO2dCQUNqQ0EsSUFBSUEsZ0JBQWVBO29CQUF1QkEsUUFBU0E7O2dCQUErQkE7OztnQkFHbEZBLGtCQUFrQkEscUNBQU1BO2dCQUN4QkEsMkJBQTJCQSxxQ0FBTUE7Z0JBQ2pDQSxJQUFJQSxnQkFBZUE7b0JBQXVCQSxRQUFTQTs7Z0JBQStCQTs7O2dCQUdsRkEsYUFBY0EscUNBQU9BO2dCQUNyQkEsSUFBSUE7b0JBQ0pBOzs7O2dCQUlBQSx3Q0FBeUVBLEFBQXFCQTtnQkFDOUZBO2dCQUNBQSwwRUFBb0RBO2dCQUNwREEsa0VBQTRDQTtnQkFDNUNBLGVBQWtCQTtnQkFDbEJBLHFFQUErQ0E7Z0JBQy9DQTtnQkFDQUEsV0FBaUNBO2dCQUNqQ0EsYUFBYUEsa0NBQXFCQTtnQkFDbENBLElBQUlBLE1BQUtBO29CQUNUQSxhQUFhQSxZQUFRQTs7Z0JBRXJCQSxxQkFBd0JBLGtDQUFxQkE7Z0JBQzdDQSxJQUFJQSxNQUFLQTtvQkFDVEEsaUJBQWlCQSxZQUFRQTs7Z0JBRXpCQSxpQkFBb0JBLGtDQUFxQkE7Z0JBQ3pDQSxJQUFJQSxRQUFRQSxjQUFjQSxNQUFLQTtvQkFDL0JBLGFBQWFBLFlBQVFBO29CQUNyQkEsSUFBSUEsUUFBUUEsY0FBY0EsTUFBS0E7d0JBQW1CQTs7O2dCQUVsREEsb0VBQThDQTtnQkFDOUNBLGlCQUFvQkEsa0NBQXFCQTtnQkFDekNBLElBQUlBLFFBQVFBLGNBQWNBLE1BQUtBO29CQUMvQkEsYUFBYUEsWUFBUUE7b0JBQ3JCQSxJQUFJQSxRQUFRQSxjQUFjQSxNQUFLQTt3QkFBbUJBOzs7Z0JBRWxEQSxvRUFBOENBO2dCQUM5Q0EsbUJBQXNCQSxrQ0FBcUJBO2dCQUMzQ0EsSUFBSUEsUUFBUUEsZ0JBQWdCQSxNQUFLQTtvQkFDakNBLGVBQWVBLFlBQVFBO29CQUN2QkEsSUFBSUEsUUFBUUEsZ0JBQWdCQSxNQUFLQTt3QkFBcUJBOzs7Z0JBRXREQSxzRUFBZ0RBO2dCQUNoREEsV0FBY0Esa0NBQXFCQTtnQkFDbkNBLElBQUlBLE1BQUtBO29CQUNUQSxPQUFPQSxZQUFRQTs7Z0JBRWZBLGFBQWdCQSxrQ0FBcUJBO2dCQUNyQ0EsSUFBSUEsTUFBS0E7b0JBQ1RBLFNBQVNBLFlBQVFBOztnQkFFakJBLFdBQWNBLGtDQUFxQkE7Z0JBQ25DQSxJQUFJQSxNQUFLQTtvQkFDVEEsT0FBT0EsWUFBUUE7O2dCQUVmQSxJQUFJQSxRQUFRQTtvQkFBV0E7O2dCQUN2QkEsU0FBU0E7Z0JBQ1RBLElBQUlBLDJCQUFNQTtvQkFBVUE7O2dCQUNwQkEsSUFBSUE7b0JBQTRCQTs7Z0JBQ2hDQSxJQUFJQSxRQUFRQTtvQkFBY0E7O2dCQUMxQkEsYUFBYUE7Z0JBQ2JBLElBQUlBLFFBQVFBO29CQUFrQkE7O2dCQUM5QkEsaUJBQWlCQTtnQkFDakJBLElBQUlBLDJCQUFNQTtvQkFBa0JBOztnQkFDNUJBLElBQUlBLDJCQUFNQTtvQkFDVkEsSUFBSUEsK0JBQVVBO3dCQUFzQ0EsYUFBYUE7O3dCQUM1REE7OztnQkFFTEEsY0FBaUJBLGtDQUFxQkE7Z0JBQ3RDQSxJQUFJQSxNQUFLQTtvQkFBZ0JBLFVBQVVBLFlBQVFBOztnQkFDM0NBLElBQUlBLFFBQVFBO29CQUFTQSxVQUFVQTs7Z0JBQy9CQSxJQUFJQSwyQkFBTUE7b0JBQVNBLFVBQVVBOztnQkFDN0JBLGlFQUEyQ0E7Z0JBQzNDQSxJQUFJQSxpQ0FBWUE7b0JBQ2hCQSxJQUFJQSxRQUFRQTt3QkFBUUE7O29CQUNwQkEsVUFBYUEsWUFBU0E7b0JBQ3RCQSxJQUFJQSxNQUFLQTt3QkFDVEE7d0JBQ0FBLEtBQUlBLFdBQVNBLElBQUlBLFlBQVlBOzRCQUM3QkEsSUFBSUEsT0FBT0EsZUFBSUE7Z0NBQ2ZBLElBQUlBLE9BQU9BLGVBQUlBLE1BQU1BLE9BQU9BLGVBQUlBLE1BQU1BLE9BQU9BLGVBQUlBLE1BQU1BLE9BQU9BLGVBQUlBLE1BQU1BLE9BQU9BLGVBQUlBLE1BQU1BLE9BQU9BLGVBQUlBLE1BQU1BLE9BQU9BLGVBQUlBLE1BQU1BLE9BQU9BLGVBQUlBLE1BQU1BLE9BQU9BLGVBQUlBLE1BQU1BLE9BQU9BLGVBQUlBO29DQUN4S0Esb0NBQUtBLGVBQUlBOztvQ0FFSkE7Ozs7d0JBR0xBLElBQUlBLE1BQUtBOzRCQUFVQSxPQUFPQTs7O29CQUUxQkEsSUFBSUEsMkJBQU1BO3dCQUFRQSxPQUFPQTs7b0JBQ3pCQSxtQ0FBY0EsUUFBTUEscUJBQWFBOztvQkFFakNBLElBQUlBLE1BQUtBO3dCQUNUQSxzQkFBaUJBLGtDQUFxQkE7d0JBQ3RDQSxJQUFJQSx1QkFBa0JBLFFBQVFBLE1BQUtBOzRCQUF1QkEsc0JBQWlCQSxZQUFRQTs7d0JBQ25GQSxJQUFJQSx1QkFBa0JBLFFBQVFBLE1BQUtBOzRCQUF1QkEsbUNBQWNBLFFBQU1BOzs7b0JBRTlFQSxtQ0FBY0EsUUFBTUE7b0JBQ3BCQSxJQUFJQSxNQUFLQTt3QkFBZUE7OztnQkFFeEJBLHVCQUEwQkEsa0NBQXFCQTtnQkFDL0NBLElBQUlBLFFBQVFBLG9CQUFvQkEsTUFBS0E7b0JBQ3JDQSxtQkFBbUJBLFlBQVFBO29CQUMzQkEsSUFBSUEsUUFBUUEsb0JBQW9CQSxNQUFLQTt3QkFBeUJBOzs7Z0JBRTlEQSwwRUFBb0RBO2dCQUNwREEsSUFBSUE7b0JBQXlCQSxhQUFhQSxZQUFXQTs7b0JBQ2hEQSxhQUFhQSxXQUFVQTs7Z0JBQzVCQSxtQkFBMkJBLHFGQUEyREE7Z0JBQ3RGQSxnQkFBcUJBLCtFQUFxREE7Z0JBRTFFQSxVQUFhQSxJQUFJQTtnQkFDakJBLFdBQWNBO2dCQUNkQSxpQkFBWUEsSUFBSUEsd0NBQXdDQSxpQ0FBd0JBO2dCQUNoRkEsdUJBQWtCQSxJQUFJQSx3Q0FBd0NBLGlDQUF3QkE7Z0JBQ3RGQSxtRUFBNkNBO2dCQUM3Q0EseUVBQW1EQTtnQkFDbkRBO2dCQUNBQTtnQkFDQUEsNEJBQXNCQSwrQkFBT0EsR0FBR0E7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7d0NBQ2hDQSxJQUFJQTs7Ozs7Ozs7d0NBQ0pBO3dDQUNBQTt3Q0FDQUEsU0FBTUE7Ozs7Ozs7Ozs7d0NBQ05BOzs7Ozt3Q0FFQUEsT0FBZ0JBLEFBQVVBLHdCQUFTQSxRQUFRQTt3Q0FDM0NBLEtBQUtBLFlBQVdBLEtBQUlBLGFBQWFBOzRDQUNqQ0EsS0FBa0JBLGlDQUFvQkEsd0JBQUtBLElBQUxBOzRDQUN0Q0EsUUFBZUE7NENBQ2ZBLElBQUlBO2dEQUNKQSxvQkFBZUEsd0JBQUtBLElBQUxBO21EQUNSQSxJQUFJQTtnREFDWEEsb0JBQWVBLHdCQUFLQSxJQUFMQTttREFDUkEsSUFBSUE7Z0RBQ1hBLG9CQUFlQSx3QkFBS0EsSUFBTEE7bURBQ1JBLElBQUlBO2dEQUNYQSwrREFBeUNBO2dEQUN6Q0E7Z0RBQ0FBO2dEQUNBQTtnREFDQUEsa0VBQTRDQTtnREFDNUNBO2dEQUNBQSxpQkFBWUEsV0FBVUE7Z0RBQ3RCQTtnREFDQUE7Z0RBQ0FBO2dEQUNBQTtnREFDQUE7Z0RBQ0FBO2dEQUNBQTtnREFDQUEsV0FBd0JBLEFBQWlEQSxVQUFDQTtvREFBT0E7b0RBQWtCQTtvREFBdUJBO29EQUFpQkE7b0RBQXVCQTtvREFBd0JBO29EQUFpQ0E7b0RBQXVCQTtvREFBcUJBO29EQUFxQkE7b0RBQXdCQTtvREFBMkJBO29EQUFtQkE7b0RBQXNCQTtvREFBbUJBO29EQUFtQkE7b0RBQTBCQTtvREFBeUJBO29EQUFvQkE7b0RBQThCQTtvREFBbUJBO29EQUF1QkE7b0RBQXVCQTtvREFBaUJBO29EQUEyQkE7b0RBQW9CQTtvREFBbUJBO29EQUFxQkE7b0RBQTJCQTtvREFBcUJBO29EQUF5QkE7b0RBQWtCQTtvREFBa0JBO29EQUF5QkE7b0RBQThCQTtvREFBdUJBO29EQUFvQkE7b0RBQWdDQTtvREFBa0JBO29EQUFrQkE7b0RBQW9CQTtvREFBb0JBO29EQUFnQkE7b0RBQW9CQTtvREFBcUJBO29EQUFvQkE7b0RBQXdCQTtvREFBMkJBO29EQUFrQkE7b0RBQTJCQTtvREFBd0JBO29EQUFtQkEsT0FBT0E7a0RBQWhwQ0EsS0FBSUE7Z0RBQzFEQTtnREFDQUE7Z0RBQ0FBO2dEQUNBQSxJQUF3QkEsS0FBSUE7Z0RBQzVCQSxLQUFLQSxXQUFVQSxRQUFNQTtvREFDckJBLE1BQU1BLEtBQUlBO29EQUNWQSxVQUFFQSxPQUFPQSxJQUFJQSw0QkFBUUEsaUJBQVNBO29EQUM5QkEsVUFBRUEsT0FBT0EsSUFBSUE7b0RBQ2JBLFVBQUVBLE9BQU9BLElBQUlBO29EQUNiQSxVQUFFQSxPQUFPQSxJQUFJQTtvREFDYkEsVUFBRUEsT0FBT0EsSUFBSUE7b0RBQ2JBLFVBQUVBLE9BQU9BLElBQUlBO29EQUNiQSxVQUFFQSxPQUFPQSxJQUFJQTtvREFDYkEsVUFBRUEsT0FBT0EsSUFBSUE7O2dEQUViQSxxQkFBcUJBO2dEQUNyQkEsdUJBQXdCQSxBQUFpREEsVUFBQ0E7b0RBQU9BO29EQUFrQkE7b0RBQWtDQTtvREFBd0RBO29EQUF1REE7b0RBQTJDQTtvREFBdUVBO29EQUErRUE7b0RBQXFHQTtvREFBcUdBO29EQUFpQ0E7b0RBQW9DQTtvREFBd0VBO29EQUE4SEE7b0RBQW1DQTtvREFBd0VBO29EQUFrRUE7b0RBQWtDQTtvREFBdUNBO29EQUFpRUE7b0RBQThCQTtvREFBc0ZBO29EQUFtREE7b0RBQTJGQTtvREFBMERBO29EQUE2RkE7b0RBQWtEQTtvREFBd0RBO29EQUF5RUE7b0RBQXdEQTtvREFBd0RBO29EQUFtR0E7b0RBQTZCQTtvREFBMENBO29EQUF1Q0E7b0RBQXNEQTtvREFBNkJBO29EQUE2Q0E7b0RBQTZCQTtvREFBeUVBO29EQUF1RkE7b0RBQWtGQTtvREFBeUJBO29EQUFvRkE7b0RBQThCQTtvREFBK0VBO29EQUFpQ0E7b0RBQW9DQTtvREFBK0NBO29EQUE0Q0E7b0RBQXNGQTtvREFBd0NBLE9BQU9BO2tEQUF0NkZBLEtBQUlBO2dEQUMxREE7Z0RBQ0FBO2dEQUNBQSxVQUFVQSxJQUFJQTtnREFDZEE7Z0RBQ0FBO2dEQUNBQSxJQUFJQSxtQ0FBc0JBO2dEQUMxQkEsb0JBQWVBO2dEQUNmQSxPQUFXQTtnREFDWEEsQUFBNENBO21EQUNyQ0EsSUFBSUE7Z0RBQ1hBO2dEQUNBQTtnREFDQUEsVUFBVUE7Z0RBQ1ZBLElBQUlBLGlEQUEwQkEsZ0RBQXlCQSx5REFBa0NBLGlEQUEwQkEsK0NBQXdCQSwrQ0FBd0JBLHlEQUFrQ0Esd0RBQWlDQSxtREFBNEJBO29EQUNsUUEsK0JBQVlBOztnREFFWkEsS0FBWUE7Z0RBQ1pBLElBQVdBLDZDQUFnQ0EsSUFBSUEsYUFBYUE7Z0RBQzVEQSxVQUFVQSxJQUFJQTtnREFDZEEsZ0JBQWdCQTtnREFDaEJBLElBQUlBLG1DQUFzQkE7Z0RBQzFCQSxvQkFBZUE7bURBQ1JBLElBQUlBO2dEQUNYQSxtQkFBY0E7bURBQ1BBLElBQUlBO2dEQUNYQTtnREFDQUEsVUFBVUE7Z0RBQ1ZBLElBQUlBLGlEQUEwQkEsZ0RBQXlCQSx5REFBa0NBLGlEQUEwQkEsK0NBQXdCQSwrQ0FBd0JBLHlEQUFrQ0Esd0RBQWlDQSxtREFBNEJBO29EQUNsUUEsK0JBQVlBOztnREFFWkEsV0FBb0JBLDRDQUErQkE7Z0RBQ25EQSxPQUFZQSwwQkFBaUJBLGtCQUFzQkE7Z0RBQ25EQSxLQUFTQSxzQkFBeUJBLE9BQUtBO2dEQUN2Q0EsTUFBWUEsZ0NBQW1CQTtnREFDL0JBLE1BQVVBLDhDQUErQkEsS0FBSUEsYUFBY0E7Z0RBQzNEQSxVQUFVQSxJQUFJQTtnREFDZEEsZ0JBQWdCQTtnREFDaEJBLElBQUVBLG1DQUFzQkE7Z0RBQ3hCQSxvQkFBZUE7Z0RBQ2ZBLDBCQUFxQkE7bURBQ2RBLElBQUlBO2dEQUNYQSxJQUFJQSxpREFBMEJBLGdEQUF5QkEseURBQWtDQSxpREFBMEJBLCtDQUF3QkEsK0NBQXdCQSx5REFBa0NBLHdEQUFpQ0EsbURBQTRCQTtvREFDbFFBLCtCQUFZQTs7Z0RBQ1pBLFlBQW9CQSw0Q0FBK0JBO2dEQUNuREEsTUFBWUEsZ0NBQW1CQTtnREFDL0JBLE9BQVVBLDhDQUErQkEsS0FBSUEsYUFBYUE7Z0RBQzFEQSxNQUFXQSwwQkFBaUJBLGtCQUFzQkE7Z0RBQ2xEQSxTQUFvQkE7Z0RBQ3BCQSxJQUFJQSxVQUFVQTtvREFDZEEsYUFBZ0JBLG1CQUFlQTtvREFDL0JBLGdDQUFjQSxhQUFDQSxZQUFnQkEsMkRBQWdCQTs7Z0RBQy9DQSxVQUFVQSxJQUFJQTtnREFDZEEsZ0JBQWdCQTtnREFDaEJBLElBQUlBLG1DQUFzQkE7Z0RBQzFCQSxvQkFBZUE7Z0RBQ2ZBLDBCQUFxQkE7bURBQ2RBLElBQUlBO2dEQUNYQSxJQUFJQSxpREFBMEJBLGdEQUF5QkEseURBQWtDQSxpREFBMEJBLCtDQUF3QkEsK0NBQXdCQSx5REFBa0NBLHdEQUFpQ0EsbURBQTRCQTtvREFDbFFBLCtCQUFZQTs7Z0RBRVpBLFlBQW9CQSw0Q0FBOEJBO2dEQUNsREEsTUFBWUEsZ0NBQW1CQTtnREFDL0JBLE9BQVVBLDhDQUErQkEsS0FBSUEsYUFBWUE7Z0RBQ3pEQSxPQUFXQSwwQkFBaUJBLGtCQUFzQkE7Z0RBQ2xEQSxVQUFvQkE7Z0RBQ3BCQSxJQUFJQSxXQUFVQTtvREFDZEEsY0FBZ0JBLG1CQUFlQTtvREFDL0JBLGlDQUFjQSxhQUFDQSxZQUFpQkEsMkRBQWdCQTs7Z0RBRWhEQSxJQUFJQSxNQUFHQTtvREFDUEE7b0RBQ0FBLFVBQVVBO29EQUNWQSxTQUFjQSwwQkFBaUJBLGtCQUFzQkE7b0RBQ3JEQSxXQUFxQkE7b0RBQ3JCQSxjQUFnQkEsbUJBQWVBO29EQUMvQkEsa0NBQWVBLGdDQUFLQTs7Z0RBRXBCQSxVQUFVQSxJQUFJQTtnREFDZEEsZ0JBQWdCQTtnREFDaEJBLElBQUVBLG1DQUFzQkE7Z0RBQ3hCQSxvQkFBZUE7Z0RBQ2ZBLDBCQUFxQkE7bURBQ2RBLElBQUlBO3dDQUVYQSxXQUFXQSxnQ0FBbUJBO2dEQUM5QkEsSUFBSUEsUUFBUUE7b0RBQ1pBLE9BQWFBLDhDQUErQkEsVUFBVUEsYUFBYUE7b0RBQ25FQSxjQUFnQkEsbUJBQWVBLElBQUlBO29EQUNuQ0EsWUFBb0JBLG9DQUF1QkE7b0RBQzNDQSxRQUFZQSwwQkFBaUJBO29EQUM3QkEsVUFBb0JBLDRDQUFlQSxRQUFPQTtvREFDMUNBLElBQUlBLDRCQUFlQTt3REFDbkJBLFdBQVdBLFlBQVFBLGlDQUFjQSxrQkFBTUE7O3dEQUV2Q0EsV0FBV0EsWUFBUUEsaUNBQWNBLGdDQUFLQTs7O29EQUd0Q0E7O2dEQUVBQSxVQUFVQSxJQUFJQTtnREFDZEE7Z0RBQ0FBLGVBQWVBO2dEQUNmQSxnQkFBZ0JBO2dEQUNoQkEsSUFBSUEsbUNBQXNCQTtnREFDMUJBLDBCQUFxQkE7O2dEQUNkQSxvQkFBZUE7Ozs7Ozs7Ozs7Ozs7O2dCQUV0QkEsMEJBQW1CQSxVQUFDQSxHQUFFQTtvQkFBSUEsc0JBQW9CQSxjQUFhQTs7Z0JBQzNEQSwwQkFBbUJBLFVBQUNBLEdBQUVBO29CQUFJQTs7Z0JBQzFCQSx5QkFBa0JBLCtCQUFDQSxHQUFFQTtvQkFDckJBLFVBQVVBLElBQUlBO29CQUNkQTtvQkFDQUEsZUFBZUEsWUFBU0E7b0JBQ3hCQSxJQUFJQSxtQ0FBc0JBO29CQUMxQkEsb0JBQWVBOztnQkFFZkEsK0JBQTBCQSwrQkFBT0EsR0FBR0E7Ozs7Ozs7Ozs7O3dDQUVwQ0EsVUFBVUEsSUFBSUE7d0NBQ2RBLFNBQU1BOzs7Ozs7Ozs7O3dDQUNOQSxlQUFlQSxZQUFTQTt3Q0FDeEJBO3dDQUNBQSxLQUFZQSxtQ0FBc0JBO3dDQUNsQ0EsMEJBQXFCQTs7Ozs7Ozs7Ozs7O2dCQUVyQkEsa0NBQTZCQSwrQkFBQ0EsR0FBR0E7b0JBQ2pDQSxTQUFvQkEsaUNBQW9CQTtvQkFDeENBLFlBQWVBO29CQUNmQSxJQUFJQTt3QkFDSkEsMEJBQXFCQTsyQkFDZEEsSUFBSUE7d0JBQ1hBO3dCQUNBQSxXQUFXQSxnQ0FBbUJBO3dCQUM5QkEsSUFBSUEsUUFBUUE7NEJBQ1pBLFVBQWFBLDhDQUErQkEsVUFBVUEsYUFBYUE7NEJBQ25FQSxpQkFBZ0JBLG1CQUFlQSxJQUFJQTs0QkFDbkNBLGVBQW9CQSxvQ0FBdUJBOzRCQUMzQ0EsV0FBWUEsMEJBQWlCQTs0QkFDN0JBLGFBQW9CQSwyQ0FBZUEsUUFBT0E7NEJBQzFDQSxJQUFJQSw0QkFBZUE7Z0NBQ25CQSxXQUFXQSxZQUFRQSxnQ0FBY0Esa0JBQU1BOztnQ0FFdkNBLFdBQVdBLFlBQVFBLGdDQUFjQSwrQkFBS0E7Ozs0QkFHdENBOzt3QkFFQUEsVUFBVUEsSUFBSUE7d0JBQ2RBO3dCQUNBQSxlQUFlQTt3QkFDZkEsZ0JBQWdCQTt3QkFDaEJBLElBQUlBLG1DQUFzQkE7d0JBQzFCQSwwQkFBcUJBOzJCQUNkQSxJQUFJQTt3QkFDWEEsb0NBQXVCQTs7Ozs2QkFJWkE7Z0JBQ1hBOzs2QkFFV0E7Z0JBQ1hBLElBQUlBO29CQUF5QkE7O2dCQUM3QkEsSUFBSUE7b0JBQXlCQTs7Z0JBQzdCQSxJQUFJQTtvQkFBd0JBOztnQkFDNUJBLElBQUlBO29CQUEwQkE7O2dCQUM5QkEsSUFBSUE7b0JBQTZCQTs7Z0JBQ2pDQSxJQUFJQTtvQkFBMkJBOztnQkFDL0JBLElBQUlBO29CQUF1QkE7O2dCQUMzQkEsSUFBSUE7b0JBQTJCQTs7Z0JBQy9CQSxJQUFJQTtvQkFBd0JBOztnQkFDNUJBLElBQUlBO29CQUF3QkE7O2dCQUM1QkEsSUFBSUE7b0JBQWdDQTs7Z0JBQ3BDQSxJQUFJQTtvQkFBK0JBOztnQkFDbkNBLElBQUlBO29CQUE4QkE7O2dCQUNsQ0EsSUFBSUE7b0JBQTRCQTs7Z0JBQ2hDQSxJQUFJQTtvQkFBZ0NBOztnQkFDcENBLElBQUlBO29CQUE4QkE7O2dCQUNsQ0EsSUFBSUE7b0JBQThCQTs7Z0JBQ2xDQSxJQUFJQTtvQkFBNEJBOztnQkFDaENBLElBQUlBO29CQUEyQkE7O2dCQUMvQkEsSUFBSUE7b0JBQThCQTs7Z0JBQ2xDQSxJQUFJQTtvQkFBc0NBOztnQkFDMUNBLElBQUlBO29CQUEwQkE7O2dCQUM5QkEsSUFBSUE7b0JBQTRCQTs7Z0JBQ2hDQSxJQUFJQTtvQkFBNkJBOztnQkFDakNBLElBQUlBO29CQUE4QkE7O2dCQUNsQ0EsSUFBSUE7b0JBQTZCQTs7Z0JBQ2pDQSxJQUFJQTtvQkFBOEJBOztnQkFDbENBLElBQUlBO29CQUFpQ0E7O2dCQUNyQ0EsSUFBSUE7b0JBQThCQTs7Z0JBQ2xDQSxJQUFJQTtvQkFBd0JBOztnQkFDNUJBLElBQUlBO29CQUF1QkE7O2dCQUMzQkEsSUFBSUE7b0JBQThCQTs7Z0JBQ2xDQSxJQUFJQTtvQkFBOEJBOztnQkFDbENBLElBQUlBO29CQUF3QkE7O2dCQUM1QkEsSUFBSUE7b0JBQXlCQTs7Z0JBQzdCQSxJQUFJQTtvQkFBNkJBOztnQkFDakNBLElBQUlBO29CQUE0QkE7O2dCQUNoQ0EsSUFBSUE7b0JBQWlDQTs7Z0JBQ3JDQSxJQUFJQTtvQkFBZ0NBOztnQkFDcENBLElBQUlBO29CQUF1QkE7O2dCQUMzQkEsSUFBSUE7b0JBQTBCQTs7Z0JBQzlCQSxJQUFJQTtvQkFBMEJBOztnQkFDOUJBLElBQUlBO29CQUEwQkE7O2dCQUM5QkEsSUFBSUE7b0JBQXdCQTs7Z0JBQzVCQSxJQUFJQTtvQkFBNEJBOztnQkFDaENBLElBQUlBO29CQUE2QkE7O2dCQUNqQ0EsSUFBSUE7b0JBQThCQTs7Z0JBQ2xDQSxJQUFJQTtvQkFBaUNBOztnQkFDckNBLElBQUlBO29CQUErQkE7O2dCQUNuQ0EsSUFBSUE7b0JBQXlCQTs7Z0JBQzdCQSxJQUFJQTtvQkFBeUJBOztnQkFDN0JBLElBQUlBO29CQUF5QkE7O2dCQUM3QkEsSUFBSUE7b0JBQWlDQTs7Z0JBQ3JDQSxJQUFJQTtvQkFBMkJBOztnQkFDL0JBLElBQUlBO29CQUEwQkE7O2dCQUM5QkEsSUFBSUE7b0JBQTRCQTs7Z0JBQ2hDQSxJQUFJQTtvQkFBMkJBOztnQkFDL0JBLElBQUlBO29CQUEyQkE7O2dCQUMvQkEsSUFBSUE7b0JBQTZCQTs7Z0JBQ2pDQSxJQUFJQTtvQkFBdUJBOztnQkFDM0JBLElBQUlBO29CQUEyQkE7O2dCQUMvQkEsSUFBSUE7b0JBQTJCQTs7Z0JBQy9CQTs7cUNBRTJCQTtnQkFDM0JBLGVBQW9CQSw0Q0FBK0JBO2dCQUNuREEsV0FBWUEsMEJBQWlCQSxrQkFBc0JBO2dCQUNuREEsU0FBWUE7Z0JBQ1pBLFlBQWFBLFdBQU1BO2dCQUNuQkEsWUFBYUEsV0FBTUE7Z0JBQ25CQSxTQUFTQSxzQkFBeUJBLE9BQU1BO2dCQUN4Q0EsYUFBb0JBO2dCQUNwQkEsVUFBVUEsOENBQStCQSxJQUFJQSxhQUFhQTtnQkFDMURBLElBQUlBLFVBQVVBO29CQUNkQSxpQkFBZ0JBLG1CQUFlQTtvQkFDL0JBLGdDQUFjQSxhQUFDQSxZQUFnQkEsMERBQWdCQTs7Z0JBRS9DQSxTQUFTQTtnQkFDVEEsSUFBSUEsVUFBVUE7b0JBQ2RBLGtCQUFnQkEsbUJBQWVBO29CQUMvQkEsZ0NBQWNBLGFBQUNBLFlBQWdCQSwwREFBZ0JBOztnQkFFL0NBLElBQUlBLE1BQUtBO29CQUNUQTtvQkFDQUEsVUFBVUE7b0JBQ1ZBLGFBQWNBLDBCQUFpQkEsa0JBQXNCQTtvQkFDckRBLFNBQVNBO29CQUNUQSxrQkFBZ0JBLG1CQUFlQTtvQkFDL0JBLGdDQUFjQSwrQkFBS0E7OztzQ0FFU0E7Z0JBQzVCQSxJQUFHQTtvQkFDSEEsYUFBa0JBLFlBQVdBLDhDQUErQkEsVUFBVUEsYUFBYUE7b0JBQ25GQSxJQUFJQSxRQUFRQTt3QkFBUUEsNEJBQTRCQTs7dUJBRzNDQSxJQUFHQTtvQkFDUkEsYUFBcUJBLFlBQWNBLDhDQUErQkEsVUFBVUEsYUFBYUE7b0JBQ3pGQSxJQUFJQSxRQUFRQTt3QkFBUUEsNEJBQTRCQTs7dUJBRzNDQSxJQUFHQTtvQkFDUkEsYUFBMEJBLFlBQW1CQSw4Q0FBK0JBLFVBQVVBLGFBQWFBO29CQUNuR0EsSUFBSUEsUUFBUUE7d0JBQVFBLDRCQUE0QkE7O3VCQUczQ0EsSUFBR0E7b0JBQ1JBLGFBQXdCQSxZQUFpQkEsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDL0ZBLElBQUlBLFFBQVFBO3dCQUFRQSw0QkFBNEJBOzt1QkFHM0NBLElBQUdBO29CQUNSQSxhQUF3QkEsWUFBaUJBLDhDQUErQkEsVUFBVUEsYUFBYUE7b0JBQy9GQSxJQUFJQSxRQUFRQTt3QkFBUUEsNEJBQTRCQTs7dUJBRzNDQSxJQUFHQTtvQkFDUkEsYUFBdUJBLFlBQWdCQSw4Q0FBK0JBLFVBQVVBLGFBQWFBO29CQUM3RkEsSUFBSUEsUUFBUUE7d0JBQVFBLDRCQUE0QkE7O3VCQUczQ0EsSUFBR0E7b0JBQ1JBLGFBQXlCQSxZQUFrQkEsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDakdBLElBQUlBLFFBQVFBO3dCQUFRQSw0QkFBNEJBOzt1QkFHM0NBLElBQUdBO29CQUNSQSxhQUE0QkEsWUFBcUJBLDhDQUErQkEsVUFBVUEsYUFBYUE7b0JBQ3ZHQSxJQUFJQSxRQUFRQTt3QkFBUUEsNEJBQTRCQTs7dUJBRzNDQSxJQUFHQTtvQkFDUkEsYUFBNkJBLFlBQXNCQSw4Q0FBK0JBLFVBQVVBLGFBQWFBO29CQUN6R0EsSUFBSUEsUUFBUUE7d0JBQVFBLDRCQUE0QkE7O3VCQUczQ0EsSUFBR0E7b0JBQ1JBLGNBQThCQSxZQUFzQkEsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDMUdBLElBQUlBLFFBQVFBO3dCQUFTQSw2QkFBNkJBOzt1QkFHN0NBLElBQUdBO29CQUNSQSxjQUFvQ0EsWUFBNEJBLDhDQUErQkEsVUFBVUEsYUFBYUE7b0JBQ3RIQSxJQUFJQSxRQUFRQTt3QkFBU0EsNkJBQTZCQTs7dUJBRzdDQSxJQUFHQTtvQkFDUkEsY0FBNkJBLFlBQXFCQSw4Q0FBK0JBLFVBQVVBLGFBQWFBO29CQUN4R0EsSUFBSUEsUUFBUUE7d0JBQVNBLDZCQUE2QkE7O3VCQUc3Q0EsSUFBR0E7b0JBQ1JBLGNBQThCQSxZQUFzQkEsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDMUdBLElBQUlBLFFBQVFBO3dCQUFTQSw2QkFBNkJBOzt1QkFHN0NBLElBQUdBO29CQUNSQSxjQUE4QkEsWUFBc0JBLDhDQUErQkEsVUFBVUEsYUFBYUE7b0JBQzFHQSxJQUFJQSxRQUFRQTt3QkFBU0EsNkJBQTZCQTs7dUJBRzdDQSxJQUFHQTtvQkFDUkEsY0FBK0JBLFlBQXVCQSw4Q0FBK0JBLFVBQVVBLGFBQWFBO29CQUM1R0EsSUFBSUEsUUFBUUE7d0JBQVNBLDZCQUE2QkE7O3VCQUc3Q0EsSUFBR0E7b0JBQ1JBLGNBQTJCQSxZQUFtQkEsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDcEdBLElBQUlBLFFBQVFBO3dCQUFTQSw2QkFBNkJBOzt1QkFHN0NBLElBQUdBO29CQUNSQSxjQUF1QkEsWUFBZUEsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDNUZBLElBQUlBLFFBQVFBO3dCQUFTQSw2QkFBNkJBOzt1QkFHN0NBLElBQUdBO29CQUNSQSxjQUEyQkEsWUFBbUJBLDhDQUErQkEsVUFBVUEsYUFBYUE7b0JBQ3BHQSxJQUFJQSxRQUFRQTt3QkFBU0EsNkJBQTZCQTs7dUJBRzdDQSxJQUFHQTtvQkFDUkEsY0FBd0JBLFlBQWdCQSw4Q0FBK0JBLFVBQVVBLGFBQWFBO29CQUM5RkEsSUFBSUEsUUFBUUE7d0JBQVNBLDZCQUE2QkE7O3VCQUc3Q0EsSUFBR0E7b0JBQ1JBLGNBQXdCQSxZQUFnQkEsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDOUZBLElBQUlBLFFBQVFBO3dCQUFTQSw2QkFBNkJBOzt1QkFHN0NBLElBQUdBO29CQUNSQSxjQUFnQ0EsWUFBd0JBLDhDQUErQkEsVUFBVUEsYUFBYUE7b0JBQzlHQSxJQUFJQSxRQUFRQTt3QkFBU0EsNkJBQTZCQTs7dUJBRzdDQSxJQUFHQTtvQkFDUkEsY0FBK0JBLFlBQXVCQSw4Q0FBK0JBLFVBQVVBLGFBQWFBO29CQUM1R0EsSUFBSUEsUUFBUUE7d0JBQVNBLDZCQUE2QkE7O3VCQUc3Q0EsSUFBR0E7b0JBQ1JBLGNBQThCQSxZQUFzQkEsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDMUdBLElBQUlBLFFBQVFBO3dCQUFTQSw2QkFBNkJBOzt1QkFHN0NBLElBQUdBO29CQUNSQSxjQUE0QkEsWUFBb0JBLDhDQUErQkEsVUFBVUEsYUFBYUE7b0JBQ3RHQSxJQUFJQSxRQUFRQTt3QkFBU0EsNkJBQTZCQTs7dUJBRzdDQSxJQUFHQTtvQkFDUkEsY0FBZ0NBLFlBQXdCQSw4Q0FBK0JBLFVBQVVBLGFBQWFBO29CQUM5R0EsSUFBSUEsUUFBUUE7d0JBQVNBLDZCQUE2QkE7O3VCQUc3Q0EsSUFBR0E7b0JBQ1JBLGNBQThCQSxZQUFzQkEsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDMUdBLElBQUlBLFFBQVFBO3dCQUFTQSw2QkFBNkJBOzt1QkFHN0NBLElBQUdBO29CQUNSQSxjQUE4QkEsWUFBc0JBLDhDQUErQkEsVUFBVUEsYUFBYUE7b0JBQzFHQSxJQUFJQSxRQUFRQTt3QkFBU0EsNkJBQTZCQTs7dUJBRzdDQSxJQUFHQTtvQkFDUkEsY0FBNEJBLFlBQW9CQSw4Q0FBK0JBLFVBQVVBLGFBQWFBO29CQUN0R0EsSUFBSUEsUUFBUUE7d0JBQVNBLDZCQUE2QkE7O3VCQUc3Q0EsSUFBR0E7b0JBQ1JBLGNBQTJCQSxZQUFtQkEsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDcEdBLElBQUlBLFFBQVFBO3dCQUFTQSw2QkFBNkJBOzt1QkFHN0NBLElBQUdBO29CQUNSQSxjQUE4QkEsWUFBc0JBLDhDQUErQkEsVUFBVUEsYUFBYUE7b0JBQzFHQSxJQUFJQSxRQUFRQTt3QkFBU0EsNkJBQTZCQTs7dUJBRzdDQSxJQUFHQTtvQkFDUkEsY0FBNkJBLFlBQXFCQSw4Q0FBK0JBLFVBQVVBLGFBQWFBO29CQUN4R0EsSUFBSUEsUUFBUUE7d0JBQVNBLDZCQUE2QkE7O3VCQUc3Q0EsSUFBR0E7b0JBQ1JBLGNBQXNDQSxZQUE4QkEsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDMUhBLElBQUlBLFFBQVFBO3dCQUFTQSw2QkFBNkJBOzt1QkFHN0NBLElBQUdBO29CQUNSQSxjQUEwQkEsWUFBa0JBLDhDQUErQkEsVUFBVUEsYUFBYUE7b0JBQ2xHQSxJQUFJQSxRQUFRQTt3QkFBU0EsNkJBQTZCQTs7dUJBRzdDQSxJQUFHQTtvQkFDUkEsY0FBNEJBLFlBQW9CQSw4Q0FBK0JBLFVBQVVBLGFBQWFBO29CQUN0R0EsSUFBSUEsUUFBUUE7d0JBQVNBLDZCQUE2QkE7O3VCQUc3Q0EsSUFBR0E7b0JBQ1JBLGNBQTZCQSxZQUFxQkEsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDeEdBLElBQUlBLFFBQVFBO3dCQUFTQSw2QkFBNkJBOzt1QkFHN0NBLElBQUdBO29CQUNSQSxjQUE4QkEsWUFBc0JBLDhDQUErQkEsVUFBVUEsYUFBYUE7b0JBQzFHQSxJQUFJQSxRQUFRQTt3QkFBU0EsNkJBQTZCQTs7dUJBRzdDQSxJQUFHQTtvQkFDUkEsY0FBNkJBLFlBQXFCQSw4Q0FBK0JBLFVBQVVBLGFBQWFBO29CQUN4R0EsSUFBSUEsUUFBUUE7d0JBQVNBLDZCQUE2QkE7O3VCQUc3Q0EsSUFBR0E7b0JBQ1JBLGNBQThCQSxZQUFzQkEsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDMUdBLElBQUlBLFFBQVFBO3dCQUFTQSw2QkFBNkJBOzt1QkFHN0NBLElBQUdBO29CQUNSQSxjQUFpQ0EsWUFBeUJBLDhDQUErQkEsVUFBVUEsYUFBYUE7b0JBQ2hIQSxJQUFJQSxRQUFRQTt3QkFBU0EsNkJBQTZCQTs7dUJBRzdDQSxJQUFHQTtvQkFDUkEsY0FBNkJBLFlBQXFCQSw4Q0FBK0JBLFVBQVVBLGFBQWFBO29CQUN4R0EsSUFBSUEsUUFBUUE7d0JBQVNBLDZCQUE2QkE7O3VCQUc3Q0EsSUFBR0E7b0JBQ1JBLGNBQTRCQSxZQUFvQkEsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDdEdBLElBQUlBLFFBQVFBO3dCQUFTQSw2QkFBNkJBOzt1QkFHN0NBLElBQUdBO29CQUNSQSxjQUEyQkEsWUFBbUJBLDhDQUErQkEsVUFBVUEsYUFBYUE7b0JBQ3BHQSxJQUFJQSxRQUFRQTt3QkFBU0EsNkJBQTZCQTs7dUJBRzdDQSxJQUFHQTtvQkFDUkEsY0FBOEJBLFlBQXNCQSw4Q0FBK0JBLFVBQVVBLGFBQWFBO29CQUMxR0EsSUFBSUEsUUFBUUE7d0JBQVNBLDZCQUE2QkE7O3VCQUc3Q0EsSUFBR0E7b0JBQ1JBLGNBQXVCQSxZQUFlQSw4Q0FBK0JBLFVBQVVBLGFBQWFBO29CQUM1RkEsSUFBSUEsUUFBUUE7d0JBQVNBLDZCQUE2QkE7O3VCQUc3Q0EsSUFBR0E7b0JBQ1JBLGNBQXVCQSxZQUFlQSw4Q0FBK0JBLFVBQVVBLGFBQWFBO29CQUM1RkEsSUFBSUEsUUFBUUE7d0JBQVNBLDZCQUE2QkE7O3VCQUc3Q0EsSUFBR0E7b0JBQ1JBLGNBQXdCQSxZQUFnQkEsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDOUZBLElBQUlBLFFBQVFBO3dCQUFTQSw2QkFBNkJBOzt1QkFHN0NBLElBQUdBO29CQUNSQSxjQUF1QkEsWUFBZUEsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDNUZBLElBQUlBLFFBQVFBO3dCQUFTQSw2QkFBNkJBOzt1QkFHN0NBLElBQUdBO29CQUNSQSxjQUF3QkEsWUFBZ0JBLDhDQUErQkEsVUFBVUEsYUFBYUE7b0JBQzlGQSxJQUFJQSxRQUFRQTt3QkFBU0EsNkJBQTZCQTs7dUJBRzdDQSxJQUFHQTtvQkFDUkEsY0FBOEJBLFlBQXNCQSw4Q0FBK0JBLFVBQVVBLGFBQWFBO29CQUMxR0EsSUFBSUEsUUFBUUE7d0JBQVNBLDZCQUE2QkE7O3VCQUc3Q0EsSUFBR0E7b0JBQ1JBLGNBQXlCQSxZQUFpQkEsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDaEdBLElBQUlBLFFBQVFBO3dCQUFTQSw2QkFBNkJBOzt1QkFHN0NBLElBQUdBO29CQUNSQSxjQUF3QkEsWUFBZ0JBLDhDQUErQkEsVUFBVUEsYUFBYUE7b0JBQzlGQSxJQUFJQSxRQUFRQTt3QkFBU0EsNkJBQTZCQTs7dUJBRzdDQSxJQUFHQTtvQkFDUkEsY0FBOEJBLFlBQXNCQSw4Q0FBK0JBLFVBQVVBLGFBQWFBO29CQUMxR0EsSUFBSUEsUUFBUUE7d0JBQVNBLDZCQUE2QkE7O3VCQUc3Q0EsSUFBR0E7b0JBQ1JBLGNBQXdCQSxZQUFnQkEsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDOUZBLElBQUlBLFFBQVFBO3dCQUFTQSw2QkFBNkJBOzt1QkFHN0NBLElBQUdBO29CQUNSQSxjQUE0QkEsWUFBb0JBLDhDQUErQkEsVUFBVUEsYUFBYUE7b0JBQ3RHQSxJQUFJQSxRQUFRQTt3QkFBU0EsNkJBQTZCQTs7dUJBRzdDQSxJQUFHQTtvQkFDUkEsY0FBeUJBLFlBQWlCQSw4Q0FBK0JBLFVBQVVBLGFBQWFBO29CQUNoR0EsSUFBSUEsUUFBUUE7d0JBQVNBLDZCQUE2QkE7O3VCQUc3Q0EsSUFBR0E7b0JBQ1JBLGNBQTZCQSxZQUFxQkEsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDeEdBLElBQUlBLFFBQVFBO3dCQUFTQSw2QkFBNkJBOzt1QkFHN0NBLElBQUdBO29CQUNSQSxjQUE0QkEsWUFBb0JBLDhDQUErQkEsVUFBVUEsYUFBYUE7b0JBQ3RHQSxJQUFJQSxRQUFRQTt3QkFBU0EsNkJBQTZCQTs7dUJBRzdDQSxJQUFHQTtvQkFDUkEsY0FBaUNBLFlBQXlCQSw4Q0FBK0JBLFVBQVVBLGFBQWFBO29CQUNoSEEsSUFBSUEsUUFBUUE7d0JBQVNBLDZCQUE2QkE7O3VCQUc3Q0EsSUFBR0E7b0JBQ1JBLGNBQWdDQSxZQUF3QkEsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDOUdBLElBQUlBLFFBQVFBO3dCQUFTQSw2QkFBNkJBOzt1QkFHN0NBLElBQUdBO29CQUNSQSxjQUF1QkEsWUFBZUEsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDNUZBLElBQUlBLFFBQVFBO3dCQUFTQSw2QkFBNkJBOzt1QkFHN0NBLElBQUdBO29CQUNSQSxjQUEwQkEsWUFBa0JBLDhDQUErQkEsVUFBVUEsYUFBYUE7b0JBQ2xHQSxJQUFJQSxRQUFRQTt3QkFBU0EsNkJBQTZCQTs7dUJBRzdDQSxJQUFHQTtvQkFDUkEsY0FBdUJBLFlBQWVBLDhDQUErQkEsVUFBVUEsYUFBYUE7b0JBQzVGQSxJQUFJQSxRQUFRQTt3QkFBU0EsNkJBQTZCQTs7dUJBRzdDQSxJQUFHQTtvQkFDUkEsY0FBMEJBLFlBQWtCQSw4Q0FBK0JBLFVBQVVBLGFBQWFBO29CQUNsR0EsSUFBSUEsUUFBUUE7d0JBQVNBLDZCQUE2QkE7O3VCQUc3Q0EsSUFBR0E7b0JBQ1JBLGNBQWdDQSxZQUF3QkEsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDOUdBLElBQUlBLFFBQVFBO3dCQUFTQSw2QkFBNkJBOzt1QkFHN0NBLElBQUdBO29CQUNSQSxjQUFnQ0EsWUFBd0JBLDhDQUErQkEsVUFBVUEsYUFBYUE7b0JBQzlHQSxJQUFJQSxRQUFRQTt3QkFBU0EsNkJBQTZCQTs7dUJBRzdDQSxJQUFHQTtvQkFDUkEsY0FBMEJBLFlBQWtCQSw4Q0FBK0JBLFVBQVVBLGFBQWFBO29CQUNsR0EsSUFBSUEsUUFBUUE7d0JBQVNBLDZCQUE2QkE7O3VCQUc3Q0EsSUFBR0E7b0JBQ1JBLGNBQXdCQSxZQUFnQkEsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDOUZBLElBQUlBLFFBQVFBO3dCQUFTQSw2QkFBNkJBOzt1QkFHN0NBLElBQUdBO29CQUNSQSxjQUE0QkEsWUFBb0JBLDhDQUErQkEsVUFBVUEsYUFBYUE7b0JBQ3RHQSxJQUFJQSxRQUFRQTt3QkFBU0EsNkJBQTZCQTs7dUJBRzdDQSxJQUFHQTtvQkFDUkEsY0FBNkJBLFlBQXFCQSw4Q0FBK0JBLFVBQVVBLGFBQWFBO29CQUN4R0EsSUFBSUEsUUFBUUE7d0JBQVNBLDZCQUE2QkE7O3VCQUc3Q0EsSUFBR0E7b0JBQ1JBLGNBQThCQSxZQUFzQkEsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDMUdBLElBQUlBLFFBQVFBO3dCQUFTQSw2QkFBNkJBOzt1QkFHN0NBLElBQUdBO29CQUNSQSxjQUFpQ0EsWUFBeUJBLDhDQUErQkEsVUFBVUEsYUFBYUE7b0JBQ2hIQSxJQUFJQSxRQUFRQTt3QkFBU0EsNkJBQTZCQTs7dUJBRzdDQSxJQUFHQTtvQkFDUkEsY0FBK0JBLFlBQXVCQSw4Q0FBK0JBLFVBQVVBLGFBQWFBO29CQUM1R0EsSUFBSUEsUUFBUUE7d0JBQVNBLDZCQUE2QkE7O3VCQUc3Q0EsSUFBR0E7b0JBQ1JBLGNBQXlCQSxZQUFpQkEsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDaEdBLElBQUlBLFFBQVFBO3dCQUFTQSw2QkFBNkJBOzt1QkFHN0NBLElBQUdBO29CQUNSQSxjQUF5QkEsWUFBaUJBLDhDQUErQkEsVUFBVUEsYUFBYUE7b0JBQ2hHQSxJQUFJQSxRQUFRQTt3QkFBU0EsNkJBQTZCQTs7dUJBRzdDQSxJQUFHQTtvQkFDUkEsY0FBeUJBLFlBQWlCQSw4Q0FBK0JBLFVBQVVBLGFBQWFBO29CQUNoR0EsSUFBSUEsUUFBUUE7d0JBQVNBLDZCQUE2QkE7O3VCQUc3Q0EsSUFBR0E7b0JBQ1JBLGNBQWlDQSxZQUF5QkEsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDaEhBLElBQUlBLFFBQVFBO3dCQUFTQSw2QkFBNkJBOzt1QkFHN0NBLElBQUdBO29CQUNSQSxjQUEyQkEsWUFBbUJBLDhDQUErQkEsVUFBVUEsYUFBYUE7b0JBQ3BHQSxJQUFJQSxRQUFRQTt3QkFBU0EsNkJBQTZCQTs7dUJBRzdDQSxJQUFHQTtvQkFDUkEsY0FBNEJBLFlBQW9CQSw4Q0FBK0JBLFVBQVVBLGFBQWFBO29CQUN0R0EsSUFBSUEsUUFBUUE7d0JBQVNBLDZCQUE2QkE7O3VCQUc3Q0EsSUFBR0E7b0JBQ1JBLGNBQTBCQSxZQUFrQkEsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDbEdBLElBQUlBLFFBQVFBO3dCQUFTQSw2QkFBNkJBOzt1QkFHN0NBLElBQUdBO29CQUNSQSxjQUE0QkEsWUFBb0JBLDhDQUErQkEsVUFBVUEsYUFBYUE7b0JBQ3RHQSxJQUFJQSxRQUFRQTt3QkFBU0EsNkJBQTZCQTs7dUJBRzdDQSxJQUFHQTtvQkFDUkEsY0FBMkJBLFlBQW1CQSw4Q0FBK0JBLFVBQVVBLGFBQWFBO29CQUNwR0EsSUFBSUEsUUFBUUE7d0JBQVNBLDZCQUE2QkE7O3VCQUc3Q0EsSUFBR0E7b0JBQ1JBLGNBQTJCQSxZQUFtQkEsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDcEdBLElBQUlBLFFBQVFBO3dCQUFTQSw2QkFBNkJBOzt1QkFHN0NBLElBQUdBO29CQUNSQSxjQUEwQkEsWUFBa0JBLDhDQUErQkEsVUFBVUEsYUFBYUE7b0JBQ2xHQSxJQUFJQSxRQUFRQTt3QkFBU0EsNkJBQTZCQTs7dUJBRzdDQSxJQUFHQTtvQkFDUkEsY0FBNEJBLFlBQW9CQSw4Q0FBK0JBLFVBQVVBLGFBQWFBO29CQUN0R0EsSUFBSUEsUUFBUUE7d0JBQVNBLDZCQUE2QkE7O3VCQUc3Q0EsSUFBR0E7b0JBQ1JBLGNBQTZCQSxZQUFxQkEsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDeEdBLElBQUlBLFFBQVFBO3dCQUFTQSw2QkFBNkJBOzt1QkFHN0NBLElBQUdBO29CQUNSQSxjQUE2QkEsWUFBcUJBLDhDQUErQkEsVUFBVUEsYUFBYUE7b0JBQ3hHQSxJQUFJQSxRQUFRQTt3QkFBU0EsNkJBQTZCQTs7dUJBRzdDQSxJQUFHQTtvQkFDUkEsY0FBb0NBLFlBQTRCQSw4Q0FBK0JBLFVBQVVBLGFBQWFBO29CQUN0SEEsSUFBSUEsUUFBUUE7d0JBQVNBLDZCQUE2QkE7O3VCQUc3Q0EsSUFBR0E7b0JBQ1JBLGNBQXdDQSxZQUFnQ0EsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDOUhBLElBQUlBLFFBQVFBO3dCQUFTQSw2QkFBNkJBOzt1QkFHN0NBLElBQUdBO29CQUNSQSxjQUFpQ0EsWUFBeUJBLDhDQUErQkEsVUFBVUEsYUFBYUE7b0JBQ2hIQSxJQUFJQSxRQUFRQTt3QkFBU0EsNkJBQTZCQTs7dUJBRzdDQSxJQUFHQTtvQkFDUkEsY0FBdUJBLFlBQWVBLDhDQUErQkEsVUFBVUEsYUFBYUE7b0JBQzVGQSxJQUFJQSxRQUFRQTt3QkFBU0EsNkJBQTZCQTs7dUJBRzdDQSxJQUFHQTtvQkFDUkEsY0FBMkJBLFlBQW1CQSw4Q0FBK0JBLFVBQVVBLGFBQWFBO29CQUNwR0EsSUFBSUEsUUFBUUE7d0JBQVNBLDZCQUE2QkE7O3VCQUc3Q0EsSUFBR0E7b0JBQ1JBLGNBQTJCQSxZQUFtQkEsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDcEdBLElBQUlBLFFBQVFBO3dCQUFTQSw2QkFBNkJBOzt1QkFHN0NBLElBQUdBO29CQUNSQSxjQUFzQkEsWUFBY0EsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDMUZBLElBQUlBLFFBQVFBO3dCQUFTQSw2QkFBNkJBOzs7OztzQ0FJNUJBO2dCQUN0QkE7Z0JBQ0FBLEFBQWlEQTtnQkFDakRBLEFBQWdEQSxnQkFBRUE7Z0JBQ2xEQSxPQUFPQTs7bUNBRWtCQSxJQUFhQTtnQkFDdENBO2dCQUNBQSxVQUFXQSxJQUFJQTtnQkFDZkEsWUFBWUEscUNBQVNBO2dCQUNyQkEsYUFBYUEscUNBQVNBO2dCQUN0QkEsMEVBQW9EQTtnQkFDcERBLHlFQUFtREE7Z0JBQ25EQSw4QkFBNkJBO2dCQUM3QkEsVUFBYUE7Z0JBQ2JBLGdFQUEwQ0E7Z0JBQzFDQSxXQUFZQTtnQkFDWkEsc0VBQWdEQTtnQkFDaERBLHFFQUErQ0E7Z0JBQy9DQSwwQkFBeUJBO2dCQUN6QkEsaUNBQWdDQTtnQkFDaENBLFlBQWFBLHFDQUFTQTtnQkFDdEJBLElBQUlBO29CQUFTQSxRQUFNQSxJQUFFQTs7Z0JBQ3JCQSxZQUFXQSxJQUFJQSwrQkFBS0Esa0JBQU1BLGFBQVVBLE9BQU9BLGtCQUFNQSxjQUFXQTtnQkFDNURBLDBFQUFvREE7Z0JBQ3BEQSx5RUFBbURBO2dCQUNuREEsOEJBQTZCQTtnQkFDN0JBLHFCQUFtQkEsK0JBQUNBLElBQUlBO29CQUN4QkEsWUFBYUE7b0JBQ2JBLFdBQWdCQSxnRkFBdURBO29CQUN2RUEsNEJBQTRCQTtvQkFDNUJBLG1DQUFtQ0E7b0JBQ25DQSxhQUFjQSxxQ0FBU0E7b0JBQ3ZCQSxJQUFJQTt3QkFBVUEsU0FBT0EsSUFBRUE7O29CQUN2QkEsYUFBWUEsSUFBSUEsK0JBQUtBLGtCQUFNQSxhQUFVQSxRQUFRQSxrQkFBTUEsY0FBV0E7b0JBQzlEQSwwRUFBb0RBO29CQUNwREEseUVBQW1EQTtvQkFDbkRBLGdDQUErQkE7b0JBQy9CQSxzRUFBZ0RBO29CQUNoREEscUVBQStDQTtvQkFDL0NBLDZFQUF1REE7b0JBQ3ZEQSw0RUFBc0RBO29CQUN0REEsU0FBWUEsWUFBUUE7b0JBQ3BCQSxJQUFJQSxNQUFLQTt3QkFDVEEsU0FBa0JBLHdFQUErQ0EsSUFBSUE7d0JBQ3JFQSxJQUFJQSxNQUFNQSxRQUFRQSxNQUFLQSxxQ0FBS0E7NEJBQzVCQTs7Ozs7OENBR29DQSxRQUFlQTtnQkFFbkRBLFNBQWFBLFlBQVNBO2dCQUN0QkEsSUFBSUEsTUFBS0E7b0JBQ1RBLFVBQXdCQSx3QkFBd0JBO29CQUNoREEsV0FBc0JBO29CQUN0QkEsZUFBa0JBO29CQUNsQkEsU0FBb0JBO29CQUNwQkEsVUFBVUE7b0JBQ1ZBLFVBQVVBO29CQUNWQSxjQUFjQTtvQkFDZEEsV0FBV0EsZ0NBQW1CQTtvQkFDOUJBLFVBQWFBLDhDQUErQkEsVUFBVUEsYUFBYUE7b0JBQ25FQSxpQkFBZ0JBLG1CQUFjQTtvQkFDOUJBLGVBQW9CQSw0Q0FBK0JBO29CQUNuREEsV0FBWUEsMEJBQWlCQSxrQkFBc0JBO29CQUNuREEsYUFBb0JBO29CQUNwQkEsZ0NBQWNBLCtCQUFLQTs7OzRDQUVlQSxRQUFlQTtnQkFFakRBLElBQUlBLFVBQVNBO29CQUViQSxTQUFhQSxZQUFTQTtvQkFDdEJBLElBQUdBLE1BQUdBO3dCQUNOQSxVQUF3QkEsd0JBQXdCQTt3QkFDaERBLFdBQXNCQTt3QkFDdEJBLGVBQWtCQTt3QkFDbEJBLFNBQW9CQTt3QkFDcEJBLFVBQVVBO3dCQUNWQSxVQUFVQTt3QkFDVkEsY0FBY0E7d0JBQ2RBLFdBQVdBLGdDQUFtQkE7d0JBQzlCQSxVQUFhQSw4Q0FBK0JBLFVBQVVBLGFBQWFBO3dCQUNuRUEsaUJBQWdCQSxtQkFBY0E7d0JBQzlCQSxlQUFvQkEsNENBQStCQTt3QkFDbkRBLFdBQVlBLDBCQUFpQkEsa0JBQXNCQTt3QkFDbkRBLGFBQW9CQTt3QkFDcEJBLGdDQUFjQSwrQkFBS0E7Ozs7O2dCRmg5QlBBLElBQUlBO29CQUNBQTs7Z0JBQ0pBOzs7Z0JBR0FBLElBQUlBO29CQUVBQSxBQUFDQSxZQUFtQ0EsQUFBUUE7OztnQkFJNURBLDRDQUE0Q0EsSUFBSUE7Z0JBQ2hEQSxpREFBaURBLElBQUlBO2dCQUNyREEsNENBQTRDQSxJQUFJQTtnQkFDaERBLDRDQUE0Q0EsSUFBSUE7O2dCQUVoREEsMkJBQXlCQTtnQkFDekJBO2dCQUNBQSxvREFBb0RBLElBQUlBOztnQkFFeERBLG9EQUFvREEsSUFBSUE7O2dCQUV4REEsdUNBQWlDQTtnQkFDakNBLHVDQUFpQ0E7O2dCQUVqQ0EsNENBQTRDQSxJQUFJQTtnQkFDaERBLHFEQUFxREEsSUFBSUE7Z0JBQ3pEQSx3REFBd0RBLElBQUlBLHFEQUF3Q0E7O2dCQUVwR0EscURBQXFEQSxJQUFJQTtnQkFDekRBLHdEQUF3REEsSUFBSUEscURBQXdDQTs7Z0JBRXBHQSx5REFBeURBO2dCQUN6REEseURBQXlEQTs7Z0JBRXpEQSwrQkFBNkJBO2dCQUM3QkE7O2dCQUVBQSxnQ0FBOEJBO2dCQUM5QkE7Z0JBQ0FBLG1EQUE2Q0E7O2dCQUU3Q0EsaUNBQStCQTtnQkFDL0JBO2dCQUNBQSxtREFBNkNBO2dCQUM3Q0EsbURBQW1EQTs7Z0JBRW5EQSxtQ0FBaUNBO2dCQUNqQ0E7Z0JBQ0FBLG1EQUE2Q0E7Z0JBQzdDQSxtREFBbURBOztnQkFFbkRBLG1EQUFtREE7Z0JBQ25EQSxtREFBbURBO2dCQUNuREEsbURBQW1EQTtnQkFDbkRBLG1EQUFtREE7OztnQkFHbkRBLGVBQWVBOztnQkFFZkEsNERBQTREQSxJQUFJQTtnQkFDaEVBO2dCQUNBQTtnQkFDQUE7Ozs7O2dCQUtBQSxlQUFVQTtnQkFDVkEsZ0JBQVdBO2dCQUNYQSxpQkFBWUE7Z0JBQ1pBLG1CQUFjQTtnQkFDZEEsV0FBTUE7O2dCQUVOQSx5REFBeURBLG1FQUFtRUEsSUFBSUEsMENBQStCQSxNQUFNQTtnQkFDcktBLElBQUdBO29CQUVDQSxnRUFBMERBLE1BQU1BLG9FQUE4REEsWUFBOEJBOztvQkFJNUpBLG1CQUFtQkEsQUFBdUJBOzs7Ozs7Ozs7Ozs7Ozt5Q0c3Q0FBOzs7O3VDQXBFTEEsSUFBbUJBO29CQUVoREEsVUFBYUEsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDbkVBLGlCQUFnQkEsbUJBQWVBO29CQUMvQkEsZUFBb0JBLDRDQUErQkE7O29CQUVuREEsU0FBWUEsZ0NBQW1CQTtvQkFDL0JBLElBQUlBO3dCQUFzQkEsS0FBS0EsYUFBZ0JBOztvQkFDL0NBLFdBQVlBLDBCQUFpQkEsa0JBQXNCQTs7b0JBRW5EQSxhQUFvQkE7O29CQUVwQkEsSUFBSUEsNEJBQWVBO3dCQUNmQSxPQUFPQSxZQUFRQSxnQ0FBY0Esa0JBQU1BOzt3QkFFbkNBLE9BQU9BLFlBQVFBLGdDQUFjQSxhQUFDQSxZQUFnQkEsMERBQWdCQTs7O3NDQUd0Q0EsSUFBbUJBO29CQUUvQ0EsVUFBYUEsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDbkVBLGlCQUFnQkEsbUJBQWVBO29CQUMvQkEsZUFBb0JBLDRDQUErQkE7O29CQUVuREEsU0FBWUEsZ0NBQW1CQTtvQkFDL0JBLElBQUlBO3dCQUFzQkEsS0FBS0EsYUFBZ0JBOztvQkFDL0NBLFdBQVlBLDBCQUFpQkEsa0JBQXNCQTs7b0JBRW5EQSxhQUFvQkE7O29CQUVwQkE7b0JBQ0FBLElBQUlBLFVBQVVBO3dCQUVWQSxJQUFJQSw0QkFBZUE7NEJBQ2ZBLFNBQVNBLFlBQVFBLGdDQUFjQSxrQkFBTUE7OzRCQUVyQ0EsU0FBU0EsWUFBUUEsZ0NBQWNBLGFBQUNBLFlBQWdCQSwwREFBZ0JBOzs7b0JBRXhFQSxPQUFPQTs7dUNBR3NCQSxJQUFtQkE7b0JBRWhEQTtvQkFDQUEsVUFBYUEsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDbkVBLGlCQUFnQkEsbUJBQWVBO29CQUMvQkEsZUFBb0JBLDRDQUErQkE7b0JBQ25EQSxTQUFZQSxnQ0FBbUJBOztvQkFFL0JBLElBQUlBO3dCQUFzQkEsS0FBS0EsYUFBZ0JBOztvQkFDL0NBLFdBQVlBLDBCQUFpQkEsa0JBQXNCQTtvQkFDbkRBLGFBQW9CQSwyQ0FBZUEsUUFBT0E7O29CQUUxQ0EsSUFBSUEsVUFBVUE7d0JBRVZBLElBQUlBLDRCQUFlQTs0QkFBU0EsU0FBU0EsWUFBUUEsZ0NBQWNBLGtCQUFNQTs7NEJBQzVEQSxTQUFTQSxZQUFRQSxnQ0FBY0EsYUFBQ0EsWUFBZ0JBLDBEQUFnQkE7OztvQkFFekVBLE9BQU9BOzt5Q0FHd0JBLElBQW1CQTtvQkFFbERBLFVBQXFCQSxZQUFnQkEsOENBQStCQSxVQUFVQSxhQUFhQTtvQkFDM0ZBLGFBQWdCQTtvQkFDaEJBLE9BQU9BOztvQ0FLbUJBLElBQW1CQTtvQkFFN0NBLElBQUlBO3dCQUF3QkEsT0FBT0E7O29CQUNuQ0E7O29CQUVBQSxVQUFhQSw2QkFBZ0JBO29CQUM3QkEsaUJBQWdCQSxtQkFBZUE7b0JBQy9CQSxlQUFvQkEsNENBQStCQTtvQkFDbkRBLElBQUlBLE1BQUtBO3dCQUVMQSxTQUFZQSxvQ0FBdUJBO3dCQUMvQ0EsSUFBSUEsTUFBS0E7NEJBQ1JBLElBQUlBO2dDQUFzQkEsS0FBS0EsYUFBZ0JBOzs0QkFDL0NBLFdBQVlBLDBCQUFpQkEsa0JBQXNCQTs7NEJBRW5EQSxhQUFvQkE7OzRCQUVwQkEsSUFBSUEsVUFBVUE7Z0NBRWJBLElBQUlBLDRCQUFlQTtvQ0FDbEJBLFNBQVNBLFlBQVFBLGdDQUFjQSxrQkFBTUE7O29DQUdyQ0EsV0FBc0JBLFlBQWdCQTtvQ0FDdENBLFNBQVNBLFlBQVFBLGdDQUFjQSwwQ0FBZ0JBOzs7O3dCQUl0Q0EsT0FBT0E7O3dCQUVOQTs7OzRDQUV1QkEsSUFBbUJBO29CQUUvQ0EsVUFBVUEsdUJBQWdCQTtvQkFDMUJBLElBQUlBO3dCQUVBQSw2QkFBZ0JBLEtBQUtBOzt3QkFHckJBLGdDQUFtQkEsS0FBS0E7OztvQkFHNUJBIiwKICAic291cmNlc0NvbnRlbnQiOiBbIi8vIDxDU0hUTUw1PjxYYW1sSGFzaD45MDNEMjFBN0I4RTVGOThGMDRFNTgzNjNFOTIxQjhFRDwvWGFtbEhhc2g+PFBhc3NOdW1iZXI+MjwvUGFzc051bWJlcj48Q29tcGlsYXRpb25EYXRlPjE1LzA5LzIwMjQgMjI6Mjc6MDY8L0NvbXBpbGF0aW9uRGF0ZT48L0NTSFRNTDU+XHJcblxyXG5cclxuXHJcbnB1YmxpYyBzdGF0aWMgY2xhc3Mgx4DHgFF3Y8eAx4BDb21wb25lbnTHgMeAQXBwx4DHgFhhbWzHgMeARmFjdG9yeVxyXG57XHJcbiAgICBwdWJsaWMgc3RhdGljIG9iamVjdCBJbnN0YW50aWF0ZSgpXHJcbiAgICB7XHJcbiAgICAgICAgZ2xvYmFsOjpTeXN0ZW0uVHlwZSB0eXBlID0gdHlwZW9mKFFXQy5BcHApO1xyXG4gICAgICAgIHJldHVybiBnbG9iYWw6OkNTSFRNTDUuSW50ZXJuYWwuVHlwZUluc3RhbnRpYXRpb25IZWxwZXIuSW5zdGFudGlhdGUodHlwZSk7XHJcbiAgICB9XHJcbn1cclxuXHJcbm5hbWVzcGFjZSBRV0Ncclxue1xyXG5cclxuXHJcbi8vLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcbi8vIDxhdXRvLWdlbmVyYXRlZD5cclxuLy8gICAgIFRoaXMgY29kZSB3YXMgYXV0by1nZW5lcmF0ZWQgYnkgXCJDIy9YQU1MIGZvciBIVE1MNVwiXHJcbi8vXHJcbi8vICAgICBDaGFuZ2VzIHRvIHRoaXMgZmlsZSBtYXkgY2F1c2UgaW5jb3JyZWN0IGJlaGF2aW9yIGFuZCB3aWxsIGJlIGxvc3QgaWZcclxuLy8gICAgIHRoZSBjb2RlIGlzIHJlZ2VuZXJhdGVkLlxyXG4vLyA8L2F1dG8tZ2VuZXJhdGVkPlxyXG4vLy0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG5cclxuXHJcblxyXG5wYXJ0aWFsIGNsYXNzIEFwcCA6IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkFwcGxpY2F0aW9uXHJcbntcclxuXHJcbiNwcmFnbWEgd2FybmluZyBkaXNhYmxlIDE2OSwgNjQ5LCAwNjI4IC8vIFByZXZlbnRzIHdhcm5pbmcgQ1MwMTY5ICgnZmllbGQgLi4uIGlzIG5ldmVyIHVzZWQnKSwgQ1MwNjQ5ICgnZmllbGQgLi4uIGlzIG5ldmVyIGFzc2lnbmVkIHRvLCBhbmQgd2lsbCBhbHdheXMgaGF2ZSBpdHMgZGVmYXVsdCB2YWx1ZSBudWxsJyksIGFuZCBDUzA2MjggKCdtZW1iZXIgOiBuZXcgcHJvdGVjdGVkIG1lbWJlciBkZWNsYXJlZCBpbiBzZWFsZWQgY2xhc3MnKVxyXG5cclxuXHJcblxyXG4jcHJhZ21hIHdhcm5pbmcgcmVzdG9yZSAxNjksIDY0OSwgMDYyOFxyXG5cclxuXHJcbiAgICAgICAgcHJpdmF0ZSBib29sIF9jb250ZW50TG9hZGVkO1xyXG4gICAgICAgIHB1YmxpYyB2b2lkIEluaXRpYWxpemVDb21wb25lbnQoKVxyXG4gICAgICAgIHtcclxuICAgICAgICAgICAgaWYgKF9jb250ZW50TG9hZGVkKVxyXG4gICAgICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgICAgICBfY29udGVudExvYWRlZCA9IHRydWU7XHJcblxyXG4jcHJhZ21hIHdhcm5pbmcgZGlzYWJsZSAwMTg0IC8vIFByZXZlbnRzIHdhcm5pbmcgQ1MwMTg0ICgnVGhlIGdpdmVuIGV4cHJlc3Npb24gaXMgbmV2ZXIgb2YgdGhlIHByb3ZpZGVkICgndHlwZScpIHR5cGUnKVxyXG4gICAgICAgICAgICBpZiAodGhpcyBpcyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5VSUVsZW1lbnQpXHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICgoZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuVUlFbGVtZW50KShvYmplY3QpdGhpcykuWGFtbFNvdXJjZVBhdGggPSBAXCJRV0NcXEFwcC54YW1sXCI7XHJcbiAgICAgICAgICAgIH1cclxuI3ByYWdtYSB3YXJuaW5nIHJlc3RvcmUgMDE4NFxyXG5cclxuXHJcbmdsb2JhbDo6Q1NIVE1MNS5JbnRlcm5hbC5TdGFydHVwQXNzZW1ibHlJbmZvLk91dHB1dFJvb3RQYXRoID0gQFwiT3V0cHV0XFxcIjtcclxuZ2xvYmFsOjpDU0hUTUw1LkludGVybmFsLlN0YXJ0dXBBc3NlbWJseUluZm8uT3V0cHV0QXBwRmlsZXNQYXRoID0gQFwiYXBwLWNzaHRtbDVcXGFwcFxcXCI7XHJcbmdsb2JhbDo6Q1NIVE1MNS5JbnRlcm5hbC5TdGFydHVwQXNzZW1ibHlJbmZvLk91dHB1dExpYnJhcmllc1BhdGggPSBAXCJhcHAtY3NodG1sNVxcbGlic1xcXCI7XHJcbmdsb2JhbDo6Q1NIVE1MNS5JbnRlcm5hbC5TdGFydHVwQXNzZW1ibHlJbmZvLk91dHB1dFJlc291cmNlc1BhdGggPSBAXCJhcHAtY3NodG1sNVxccmVzXFxcIjtcclxuXHJcblxyXG52YXIgUmVzb3VyY2VEaWN0aW9uYXJ5X2YwZjY0MzFmMTdmZTQ1Y2ZiMTg4YjhiMjI2YjU0Y2Q0ID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlJlc291cmNlRGljdGlvbmFyeSgpO1xyXG50aGlzLlJlc291cmNlcyA9IFJlc291cmNlRGljdGlvbmFyeV9mMGY2NDMxZjE3ZmU0NWNmYjE4OGI4YjIyNmI1NGNkNDtcclxudmFyIEludENvbnZlcnRlcl8wY2VkMTI1MzUwYzQ0ZTg3YTNhYmViMDBjOWNjN2U3MSA9IG5ldyBnbG9iYWw6OkFQTEV4dGVuc2lvbi5JbnRDb252ZXJ0ZXIoKTtcclxuXHJcbnZhciBEZWNDb252ZXJ0ZXJfY2JkMjk3NGZlMzg5NDM0Y2IyYWUxNWJiNzUwNDg1YWQgPSBuZXcgZ2xvYmFsOjpBUExFeHRlbnNpb24uRGVjQ29udmVydGVyKCk7XHJcblxyXG52YXIgVG9Qb2x5TGluZUNvbnZlcnRlcl8wMTBjNGVlMmU0YTE0MDFkYWE1YTI2NWJmZjI5MWRjYSA9IG5ldyBnbG9iYWw6OkFQTEV4dGVuc2lvbi5Ub1BvbHlMaW5lQ29udmVydGVyKCk7XHJcblxyXG52YXIgVG9Qb2ludHNDb252ZXJ0ZXJfY2IzOTQ5NzI0OGUzNGQyMGIyZTI4YzY4MmU3MTljYmQgPSBuZXcgZ2xvYmFsOjpBUExFeHRlbnNpb24uVG9Qb2ludHNDb252ZXJ0ZXIoKTtcclxuXHJcbnZhciBUb0xpbmVzQ29udmVydGVyXzY0OTI0MWU0YWMzYTQ4MDNhZDY2NGQ1ZjBjNzE4NTQ4ID0gbmV3IGdsb2JhbDo6QVBMRXh0ZW5zaW9uLlRvTGluZXNDb252ZXJ0ZXIoKTtcclxuXHJcbnZhciBBUExDb2xvckNvbnZlcnRlcl8xN2U2MWUzNjlhNGY0NmJlOWQ0ODA4MDU2NjIzYzgyZCA9IG5ldyBnbG9iYWw6OkFQTEV4dGVuc2lvbi5BUExDb2xvckNvbnZlcnRlcigpO1xyXG5cclxudmFyIEFQTENvbG9yQ1NTQ29udmVydGVyX2Y1NDIyMDU3Y2UyNjQ3MTc5ZmJkOGZhNDQ5YTE5ZWZmID0gbmV3IGdsb2JhbDo6QVBMRXh0ZW5zaW9uLkFQTENvbG9yQ1NTQ29udmVydGVyKCk7XHJcblxyXG52YXIgQVBMTXVsdGlDb2xvckNvbnZlcnRlcl82NDMzNDQ1ZmI3MWY0YzZiYjFjOGU2Mzg5ZjA5NWY4ZiA9IG5ldyBnbG9iYWw6OkFQTEV4dGVuc2lvbi5BUExNdWx0aUNvbG9yQ29udmVydGVyKCk7XHJcblxyXG52YXIgQVBMTXVsdGlDb2xvckNTU0NvbnZlcnRlcl9iMDhjMjU0MTZmYTg0Y2RlYjIxZTVkN2FlNTYzNjU1YyA9IG5ldyBnbG9iYWw6OkFQTEV4dGVuc2lvbi5BUExNdWx0aUNvbG9yQ1NTQ29udmVydGVyKCk7XHJcblxyXG52YXIgSW5kZXhJbnQzMkNvbnZlcnRlcl9iYTJmNGQwNjliMDc0MGNiOWIzOTZjOWZiMWRkMWUxYyA9IG5ldyBnbG9iYWw6OkFQTEV4dGVuc2lvbi5JbmRleEludDMyQ29udmVydGVyKCk7XHJcblxyXG52YXIgSW5kZXhEb3VibGVDb252ZXJ0ZXJfNTM5NTNjY2ZiZDI5NDBlNDhkMjI5ZDk3YmEwODc2NTkgPSBuZXcgZ2xvYmFsOjpBUExFeHRlbnNpb24uSW5kZXhEb3VibGVDb252ZXJ0ZXIoKTtcclxuXHJcbnZhciBJbmRleFN0cmluZ0NvbnZlcnRlcl82MjljMWYxODc4NWU0ZmM4OWUxNzI1YWRmN2Y0ZWFiOSA9IG5ldyBnbG9iYWw6OkFQTEV4dGVuc2lvbi5JbmRleFN0cmluZ0NvbnZlcnRlcigpO1xyXG5cclxudmFyIEluZGV4QVBMQ29sb3JDb252ZXJ0ZXJfZjQwYzdhZGFjZjgwNDlhZmFjOTlhNjlkYTcxNzA3NTAgPSBuZXcgZ2xvYmFsOjpBUExFeHRlbnNpb24uSW5kZXhBUExDb2xvckNvbnZlcnRlcigpO1xyXG5cclxudmFyIEluZGV4QVBMQ29sb3VyQ29udmVydGVyX2FjY2RlNDU3ODIzNzQ4NDQ5ODU0ZmUyZTMzODEyYmUwID0gbmV3IGdsb2JhbDo6QVBMRXh0ZW5zaW9uLkluZGV4QVBMQ29sb3VyQ29udmVydGVyKCk7XHJcblxyXG52YXIgTWF0aHNJQ29udmVydGVyXzM4ZTE5NDY2MDVmZDQ0YzFiZDExZTFhZWVjMjQyMDE4ID0gbmV3IGdsb2JhbDo6QVBMRXh0ZW5zaW9uLk1hdGhzSUNvbnZlcnRlcigpO1xyXG5cclxudmFyIE1hdGhzRENvbnZlcnRlcl8yNjAxNzA2ODRjNGE0M2JiYjNlODRjMWYwMGI3NGNkMyA9IG5ldyBnbG9iYWw6OkFQTEV4dGVuc2lvbi5NYXRoc0RDb252ZXJ0ZXIoKTtcclxuXHJcbnZhciBNYXRoSUNvbnZlcnRlcl9jY2RjMzgzNTA2MmY0NTRkODRkYzc2MDU2MGY0NzJkYSA9IG5ldyBnbG9iYWw6OkFQTEV4dGVuc2lvbi5NYXRoSUNvbnZlcnRlcigpO1xyXG5cclxudmFyIE1hdGhEQ29udmVydGVyXzc1NGZiZjhlMWQ0YjRhNjViMzU5ZDcyM2VjNWYxNDAyID0gbmV3IGdsb2JhbDo6QVBMRXh0ZW5zaW9uLk1hdGhEQ29udmVydGVyKCk7XHJcblxyXG5nbG9iYWw6OlN5c3RlbS5TdHJpbmcgU3RyaW5nXzMxMTI3YTdkZWZhZjQwNmM4MDUyMTI3ZTdkNjE2N2ZlID0gQFwi4o6VV0MgQ3Jvc3MgUGxhdGZvcm1cIjtcclxuXHJcbmdsb2JhbDo6U3lzdGVtLlN0cmluZyBTdHJpbmdfYzQwMWJhMWZkYTI3NDZmMWEzMjZlN2ZhNzhiNjgyNTUgPSBAXCJNSkggU29mdHdhcmUgU2VydmljZXMgTHRkXCI7XHJcblxyXG5nbG9iYWw6OlN5c3RlbS5TdHJpbmcgU3RyaW5nXzM1YzJlOWQ0YWY1NzQ2MjFiMzEyZGRhYjRlMzMzMmE2ID0gQFwiTUpIIFNvZnR3YXJlIFNlcnZpY2VzIEx0ZFwiO1xyXG5cclxuZ2xvYmFsOjpTeXN0ZW0uU3RyaW5nIFN0cmluZ19lNWVhYTliMWY0OTU0NzU2OGViODdkZGRjNGU4N2NiNiA9IEBcIlFXQ1wiO1xyXG5cclxuZ2xvYmFsOjpTeXN0ZW0uU3RyaW5nIFN0cmluZ18wMWNlMGQzYTRmZjY0NDM2OGE4OWZkNjZhY2YxNjJmZiA9IEBcIuKOlVdDIENyb3NzIFBsYXRmb3JtXCI7XHJcblxyXG5nbG9iYWw6OlN5c3RlbS5TdHJpbmcgU3RyaW5nXzdjMmQzMTQ5YTM3MDQ5MTViMTZkZGFiMDdhZGYyZjk1ID0gQFwibWpoLmljb1wiO1xyXG5cclxuZ2xvYmFsOjpTeXN0ZW0uU3RyaW5nIFN0cmluZ19lNzk2N2EyMjQ0MTQ0NDEwYjMwOWM3Mzc3MjhlMjlhYiA9IEBcIjEyMzQ1XCI7XHJcblxyXG5nbG9iYWw6OlN5c3RlbS5TdHJpbmcgU3RyaW5nXzczZGVkY2IzMTA5MzRkYWQ5YTM2YzdlZjk0ODY5MThjID0gQFwiTWFpblBhZ2VcIjtcclxuXHJcbmdsb2JhbDo6U3lzdGVtLlN0cmluZyBTdHJpbmdfM2Y2NjQ5NGQwODcxNDgxN2JkMTVlMzhiMzA4YTllYjQgPSBAXCJNYWluUGFnZTpQYWdlXCI7XHJcblxyXG5nbG9iYWw6OlN5c3RlbS5TdHJpbmcgU3RyaW5nX2UwMGYyMmEzMjZiYzQ1ODFiNDk3Yjg4NDQ2Mjk2NGY4ID0gQFwiRGlyZWN0XCI7XHJcblxyXG5nbG9iYWw6OlN5c3RlbS5TdHJpbmcgU3RyaW5nXzUzZDYwZGZjZjNlMTQxZDJiNzNiODg5MmIzZDVhMWMwID0gQFwiUVdDXCI7XHJcblxyXG52YXIgU3R5bGVfMjJhMWJkZWQwMzFhNDc1YWExNTUzOTM0MmVjOTYwMjEgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuU3R5bGUoKTtcclxuU3R5bGVfMjJhMWJkZWQwMzFhNDc1YWExNTUzOTM0MmVjOTYwMjEuVGFyZ2V0VHlwZSA9IHR5cGVvZihnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Db250cm9scy5DaGlsZFdpbmRvdyk7XHJcbnZhciBTZXR0ZXJfMjgxMWRjMWZmOTUwNGI2NGE0NmFjNDY5YzAxNGYyNzcgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuU2V0dGVyKCk7XHJcblNldHRlcl8yODExZGMxZmY5NTA0YjY0YTQ2YWM0NjljMDE0ZjI3Ny5Qcm9wZXJ0eSA9IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkNvbnRyb2xzLkNoaWxkV2luZG93Lk92ZXJsYXlCcnVzaFByb3BlcnR5O1xyXG5TZXR0ZXJfMjgxMWRjMWZmOTUwNGI2NGE0NmFjNDY5YzAxNGYyNzcuVmFsdWUgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuTWVkaWEuU29saWRDb2xvckJydXNoKG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuQ29sb3IoKSB7IEEgPSAoYnl0ZSkwLCBSID0gKGJ5dGUpMjU1LCBHID0gKGJ5dGUpMjU1LCBCID0gKGJ5dGUpMjU1IH0pO1xyXG5cclxudmFyIFNldHRlcl83OThjOGEzMjA3MjE0OWQyYjIyZmEzODM1NmFkMzU5NCA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5TZXR0ZXIoKTtcclxuU2V0dGVyXzc5OGM4YTMyMDcyMTQ5ZDJiMjJmYTM4MzU2YWQzNTk0LlByb3BlcnR5ID0gZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuQ29udHJvbHMuQ2hpbGRXaW5kb3cuT3ZlcmxheU9wYWNpdHlQcm9wZXJ0eTtcclxuU2V0dGVyXzc5OGM4YTMyMDcyMTQ5ZDJiMjJmYTM4MzU2YWQzNTk0LlZhbHVlID0gMUQ7XHJcblxyXG52YXIgU2V0dGVyXzI3OGI3MTRjZWM2OTQzYzJhYWViYmYzMjgzOTUyOThmID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlNldHRlcigpO1xyXG5TZXR0ZXJfMjc4YjcxNGNlYzY5NDNjMmFhZWJiZjMyODM5NTI5OGYuUHJvcGVydHkgPSBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Db250cm9scy5DaGlsZFdpbmRvdy5Ib3Jpem9udGFsQWxpZ25tZW50UHJvcGVydHk7XHJcblNldHRlcl8yNzhiNzE0Y2VjNjk0M2MyYWFlYmJmMzI4Mzk1Mjk4Zi5WYWx1ZSA9IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkhvcml6b250YWxBbGlnbm1lbnQuTGVmdDtcclxuXHJcbnZhciBTZXR0ZXJfZmI4Y2UwNjVhYzQ4NDdkYjkyNTA3ODU2ODNlMDRkNWYgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuU2V0dGVyKCk7XHJcblNldHRlcl9mYjhjZTA2NWFjNDg0N2RiOTI1MDc4NTY4M2UwNGQ1Zi5Qcm9wZXJ0eSA9IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkNvbnRyb2xzLkNoaWxkV2luZG93LlZlcnRpY2FsQWxpZ25tZW50UHJvcGVydHk7XHJcblNldHRlcl9mYjhjZTA2NWFjNDg0N2RiOTI1MDc4NTY4M2UwNGQ1Zi5WYWx1ZSA9IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlZlcnRpY2FsQWxpZ25tZW50LlRvcDtcclxuXHJcbnZhciBTZXR0ZXJfOGI4YjY1NTUxMjE4NDQ2ZmJlZTU0MjQ4OWNmOTFiYzkgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuU2V0dGVyKCk7XHJcblNldHRlcl84YjhiNjU1NTEyMTg0NDZmYmVlNTQyNDg5Y2Y5MWJjOS5Qcm9wZXJ0eSA9IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkNvbnRyb2xzLkNoaWxkV2luZG93LlRlbXBsYXRlUHJvcGVydHk7XHJcbnZhciBDb250cm9sVGVtcGxhdGVfZmVlYzQ1OGUwNmE1NDg3OGE2OTEyNTk2OTU4M2NlMDMgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuQ29udHJvbHMuQ29udHJvbFRlbXBsYXRlKCk7XHJcbkNvbnRyb2xUZW1wbGF0ZV9mZWVjNDU4ZTA2YTU0ODc4YTY5MTI1OTY5NTgzY2UwMy5UYXJnZXRUeXBlID0gdHlwZW9mKGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkNvbnRyb2xzLkNoaWxkV2luZG93KTtcclxuQ29udHJvbFRlbXBsYXRlX2ZlZWM0NThlMDZhNTQ4NzhhNjkxMjU5Njk1ODNjZTAzLlNldE1ldGhvZFRvSW5zdGFudGlhdGVGcmFtZXdvcmtUZW1wbGF0ZSgoU3lzdGVtLkZ1bmM8V2luZG93cy5VSS5YYW1sLkNvbnRyb2xzLkNvbnRyb2wsV2luZG93cy5VSS5YYW1sLlRlbXBsYXRlSW5zdGFuY2U+KSh0ZW1wbGF0ZU93bmVyX0NvbnRyb2xUZW1wbGF0ZV9mZWVjNDU4ZTA2YTU0ODc4YTY5MTI1OTY5NTgzY2UwMyA9PiBcclxue1xyXG52YXIgdGVtcGxhdGVJbnN0YW5jZV81ZThmYTc1MDkxOGE0NzcxOTdmOGU5NDE0MmM0NjM4ZSA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5UZW1wbGF0ZUluc3RhbmNlKCk7XHJcbnRlbXBsYXRlSW5zdGFuY2VfNWU4ZmE3NTA5MThhNDc3MTk3ZjhlOTQxNDJjNDYzOGUuVGVtcGxhdGVPd25lciA9IHRlbXBsYXRlT3duZXJfQ29udHJvbFRlbXBsYXRlX2ZlZWM0NThlMDZhNTQ4NzhhNjkxMjU5Njk1ODNjZTAzO1xyXG52YXIgVmlzdWFsU3RhdGVfYjk0Yjk4NGUyNWQxNGNiMWFjOTFhMWMwMGRlYzc2MzcgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuVmlzdWFsU3RhdGUoKTtcclxudmFyIFZpc3VhbFN0YXRlXzBiM2YwNGIyMTRmMjRhNDVhMjY5NDkwNDQ3MDNkZTllID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlZpc3VhbFN0YXRlKCk7XHJcbnZhciBWaXN1YWxTdGF0ZUdyb3VwX2UzOTk5YWY2NWE0ZTRmZTZiNTJlMzYyN2M0MGQ3MjI1ID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlZpc3VhbFN0YXRlR3JvdXAoKTtcclxudmFyIEdyaWRfNTVlZWY5YjZjNDFjNDc3ZmJhZWNiNDE4M2E3Yzc4M2YgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuQ29udHJvbHMuR3JpZCgpO1xyXG52YXIgQnV0dG9uX2MxYWU1ODdjNmRiNzQ1ZmQ5MTcwNzMwYTEzYTA0NTVhID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkNvbnRyb2xzLkJ1dHRvbigpO1xyXG52YXIgQ29udGVudENvbnRyb2xfMDU1YTUyYmRmMGY5NDE1MTgzY2EwMDA4YzIzOGVhNzQgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuQ29udHJvbHMuQ29udGVudENvbnRyb2woKTtcclxudmFyIEJ1dHRvbl9hZDI2YTY3ZGFiZTM0NmRhOWQ4M2MxOTFkMmQ1YjlkMiA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Db250cm9scy5CdXR0b24oKTtcclxudmFyIEJ1dHRvbl8zNTI5MTU5YjVkYjY0OWFkODRmNWQwM2U1MTY3Y2Y2MSA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Db250cm9scy5CdXR0b24oKTtcclxudmFyIEJ1dHRvbl9hZThmZGQ0ZGEzZjA0MTkzYjJhNGVlMWE4M2M3Y2U3MCA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Db250cm9scy5CdXR0b24oKTtcclxudmFyIEJ1dHRvbl82ZmM1ZGRlNGQ0YWM0ODY4OGYwOWE2OTFhM2U2MjA4ZCA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Db250cm9scy5CdXR0b24oKTtcclxudmFyIEJ1dHRvbl80NmMyMjVmNzY0YWM0MGZkOGNkZjllMjdhMjI3MzRlZCA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Db250cm9scy5CdXR0b24oKTtcclxudmFyIEJvcmRlcl8yZjhlMTIwZmY2OWY0ODlhOTczZGU5YjRkZjNhNzFmNSA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Db250cm9scy5Cb3JkZXIoKTtcclxudmFyIENvbnRlbnRQcmVzZW50ZXJfMTY4M2U1M2MwZDg3NDFmYjliZWQ5ODIyMDcwZmVjYjMgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuQ29udHJvbHMuQ29udGVudFByZXNlbnRlcigpO1xyXG52YXIgQm9yZGVyX2JiZmMzNmZkOTNkZjRjZjRiNDE0NjVhMTJmM2YxZDA4ID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkNvbnRyb2xzLkJvcmRlcigpO1xyXG52YXIgQm9yZGVyX2U5ZTYzNTM5N2MxOTQyODI4MTFjMmYxMGJiNWJlMjQxID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkNvbnRyb2xzLkJvcmRlcigpO1xyXG52YXIgR3JpZF80MWM4NGQwYTcxMDE0ODIxOTA3NzRhY2FjNDMxYTBjZCA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Db250cm9scy5HcmlkKCk7XHJcbnRlbXBsYXRlT3duZXJfQ29udHJvbFRlbXBsYXRlX2ZlZWM0NThlMDZhNTQ4NzhhNjkxMjU5Njk1ODNjZTAzLlJlZ2lzdGVyTmFtZShcIlJvb3RcIiwgR3JpZF80MWM4NGQwYTcxMDE0ODIxOTA3NzRhY2FjNDMxYTBjZCk7XHJcbkdyaWRfNDFjODRkMGE3MTAxNDgyMTkwNzc0YWNhYzQzMWEwY2QuTmFtZSA9IFwiUm9vdFwiO1xyXG5HcmlkXzQxYzg0ZDBhNzEwMTQ4MjE5MDc3NGFjYWM0MzFhMGNkLlJlbmRlclRyYW5zZm9ybU9yaWdpbiA9IG5ldyBnbG9iYWw6OldpbmRvd3MuRm91bmRhdGlvbi5Qb2ludCgwLCAwKTtcclxudGVtcGxhdGVPd25lcl9Db250cm9sVGVtcGxhdGVfZmVlYzQ1OGUwNmE1NDg3OGE2OTEyNTk2OTU4M2NlMDMuUmVnaXN0ZXJOYW1lKFwiTW9kYWxTdGF0ZXNcIiwgVmlzdWFsU3RhdGVHcm91cF9lMzk5OWFmNjVhNGU0ZmU2YjUyZTM2MjdjNDBkNzIyNSk7XHJcblZpc3VhbFN0YXRlR3JvdXBfZTM5OTlhZjY1YTRlNGZlNmI1MmUzNjI3YzQwZDcyMjUuTmFtZSA9IFwiTW9kYWxTdGF0ZXNcIjtcclxudGVtcGxhdGVPd25lcl9Db250cm9sVGVtcGxhdGVfZmVlYzQ1OGUwNmE1NDg3OGE2OTEyNTk2OTU4M2NlMDMuUmVnaXN0ZXJOYW1lKFwiTm90TW9kYWxcIiwgVmlzdWFsU3RhdGVfYjk0Yjk4NGUyNWQxNGNiMWFjOTFhMWMwMGRlYzc2MzcpO1xyXG5WaXN1YWxTdGF0ZV9iOTRiOTg0ZTI1ZDE0Y2IxYWM5MWExYzAwZGVjNzYzNy5OYW1lID0gXCJOb3RNb2RhbFwiO1xyXG52YXIgU3Rvcnlib2FyZF8zYTlmMTE3Nzc4NmU0NTY1YjRkMTU5NDdhMmQ3ZWEyNSA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5NZWRpYS5BbmltYXRpb24uU3Rvcnlib2FyZCgpO1xyXG52YXIgT2JqZWN0QW5pbWF0aW9uVXNpbmdLZXlGcmFtZXNfZGZjZjA2NWMyZmNlNDgyZGE2YmI5YTQ4OTcwYWRlYTUgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuTWVkaWEuQW5pbWF0aW9uLk9iamVjdEFuaW1hdGlvblVzaW5nS2V5RnJhbWVzKCk7XHJcbmdsb2JhbDo6V2luZG93cy5VSS5YYW1sLk1lZGlhLkFuaW1hdGlvbi5TdG9yeWJvYXJkLlNldFRhcmdldE5hbWUoT2JqZWN0QW5pbWF0aW9uVXNpbmdLZXlGcmFtZXNfZGZjZjA2NWMyZmNlNDgyZGE2YmI5YTQ4OTcwYWRlYTUsQFwiT3ZlcmxheVwiKTtcclxudmFyIERpc2NyZXRlT2JqZWN0S2V5RnJhbWVfZTU5YTE2ZmFmMzVmNDc2NTgxNzQ0NDBjZWU0NmY0ZmEgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuTWVkaWEuQW5pbWF0aW9uLkRpc2NyZXRlT2JqZWN0S2V5RnJhbWUoKTtcclxudmFyIE51bGxFeHRlbnNpb25fMzRjODk5ZWFiMmY0NDVlNjg2NDNmMWYzOTQwYTM1ODMgPSBuZXcgZ2xvYmFsOjpTeXN0ZW0uV2luZG93cy5NYXJrdXAuTnVsbEV4dGVuc2lvbigpO1xyXG5cclxuRGlzY3JldGVPYmplY3RLZXlGcmFtZV9lNTlhMTZmYWYzNWY0NzY1ODE3NDQ0MGNlZTQ2ZjRmYS5WYWx1ZSA9IG51bGw7XHJcblxyXG5cclxuT2JqZWN0QW5pbWF0aW9uVXNpbmdLZXlGcmFtZXNfZGZjZjA2NWMyZmNlNDgyZGE2YmI5YTQ4OTcwYWRlYTUuS2V5RnJhbWVzLkFkZChEaXNjcmV0ZU9iamVjdEtleUZyYW1lX2U1OWExNmZhZjM1ZjQ3NjU4MTc0NDQwY2VlNDZmNGZhKTtcclxuXHJcblxyXG52YXIgT2JqZWN0QW5pbWF0aW9uVXNpbmdLZXlGcmFtZXNfYWZkOTU0MDBjZjllNDhmNjljNjk5ZmY2NTJkNDEzNzQgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuTWVkaWEuQW5pbWF0aW9uLk9iamVjdEFuaW1hdGlvblVzaW5nS2V5RnJhbWVzKCk7XHJcbmdsb2JhbDo6V2luZG93cy5VSS5YYW1sLk1lZGlhLkFuaW1hdGlvbi5TdG9yeWJvYXJkLlNldFRhcmdldE5hbWUoT2JqZWN0QW5pbWF0aW9uVXNpbmdLZXlGcmFtZXNfYWZkOTU0MDBjZjllNDhmNjljNjk5ZmY2NTJkNDEzNzQsQFwiT3ZlcmxheVwiKTtcclxudmFyIERpc2NyZXRlT2JqZWN0S2V5RnJhbWVfNDNlMTVlOWNhNWFlNDAxN2FhZTkzMzIzNDgxMmY1ZDIgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuTWVkaWEuQW5pbWF0aW9uLkRpc2NyZXRlT2JqZWN0S2V5RnJhbWUoKTtcclxuRGlzY3JldGVPYmplY3RLZXlGcmFtZV80M2UxNWU5Y2E1YWU0MDE3YWFlOTMzMjM0ODEyZjVkMi5WYWx1ZSA9IEBcIkZhbHNlXCI7XHJcblxyXG5PYmplY3RBbmltYXRpb25Vc2luZ0tleUZyYW1lc19hZmQ5NTQwMGNmOWU0OGY2OWM2OTlmZjY1MmQ0MTM3NC5LZXlGcmFtZXMuQWRkKERpc2NyZXRlT2JqZWN0S2V5RnJhbWVfNDNlMTVlOWNhNWFlNDAxN2FhZTkzMzIzNDgxMmY1ZDIpO1xyXG5cclxuXHJcblN0b3J5Ym9hcmRfM2E5ZjExNzc3ODZlNDU2NWI0ZDE1OTQ3YTJkN2VhMjUuQ2hpbGRyZW4uQWRkKE9iamVjdEFuaW1hdGlvblVzaW5nS2V5RnJhbWVzX2RmY2YwNjVjMmZjZTQ4MmRhNmJiOWE0ODk3MGFkZWE1KTtcclxuU3Rvcnlib2FyZF8zYTlmMTE3Nzc4NmU0NTY1YjRkMTU5NDdhMmQ3ZWEyNS5DaGlsZHJlbi5BZGQoT2JqZWN0QW5pbWF0aW9uVXNpbmdLZXlGcmFtZXNfYWZkOTU0MDBjZjllNDhmNjljNjk5ZmY2NTJkNDEzNzQpO1xyXG5cclxuXHJcblZpc3VhbFN0YXRlX2I5NGI5ODRlMjVkMTRjYjFhYzkxYTFjMDBkZWM3NjM3LlN0b3J5Ym9hcmQgPSBTdG9yeWJvYXJkXzNhOWYxMTc3Nzg2ZTQ1NjViNGQxNTk0N2EyZDdlYTI1O1xyXG5cclxuXHJcbnRlbXBsYXRlT3duZXJfQ29udHJvbFRlbXBsYXRlX2ZlZWM0NThlMDZhNTQ4NzhhNjkxMjU5Njk1ODNjZTAzLlJlZ2lzdGVyTmFtZShcIk1vZGFsXCIsIFZpc3VhbFN0YXRlXzBiM2YwNGIyMTRmMjRhNDVhMjY5NDkwNDQ3MDNkZTllKTtcclxuVmlzdWFsU3RhdGVfMGIzZjA0YjIxNGYyNGE0NWEyNjk0OTA0NDcwM2RlOWUuTmFtZSA9IFwiTW9kYWxcIjtcclxuXHJcblZpc3VhbFN0YXRlR3JvdXBfZTM5OTlhZjY1YTRlNGZlNmI1MmUzNjI3YzQwZDcyMjUuU3RhdGVzLkFkZChWaXN1YWxTdGF0ZV9iOTRiOTg0ZTI1ZDE0Y2IxYWM5MWExYzAwZGVjNzYzNyk7XHJcblZpc3VhbFN0YXRlR3JvdXBfZTM5OTlhZjY1YTRlNGZlNmI1MmUzNjI3YzQwZDcyMjUuU3RhdGVzLkFkZChWaXN1YWxTdGF0ZV8wYjNmMDRiMjE0ZjI0YTQ1YTI2OTQ5MDQ0NzAzZGU5ZSk7XHJcblxyXG5cclxudGVtcGxhdGVPd25lcl9Db250cm9sVGVtcGxhdGVfZmVlYzQ1OGUwNmE1NDg3OGE2OTEyNTk2OTU4M2NlMDMuSU5URVJOQUxfR2V0VmlzdWFsU3RhdGVHcm91cHMoKS5BZGQoVmlzdWFsU3RhdGVHcm91cF9lMzk5OWFmNjVhNGU0ZmU2YjUyZTM2MjdjNDBkNzIyNSk7XHJcblxyXG50ZW1wbGF0ZU93bmVyX0NvbnRyb2xUZW1wbGF0ZV9mZWVjNDU4ZTA2YTU0ODc4YTY5MTI1OTY5NTgzY2UwMy5SZWdpc3Rlck5hbWUoXCJPdmVybGF5XCIsIEdyaWRfNTVlZWY5YjZjNDFjNDc3ZmJhZWNiNDE4M2E3Yzc4M2YpO1xyXG5HcmlkXzU1ZWVmOWI2YzQxYzQ3N2ZiYWVjYjQxODNhN2M3ODNmLk5hbWUgPSBcIk92ZXJsYXlcIjtcclxuR3JpZF81NWVlZjliNmM0MWM0NzdmYmFlY2I0MTgzYTdjNzgzZi5Ib3Jpem9udGFsQWxpZ25tZW50ID0gZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuSG9yaXpvbnRhbEFsaWdubWVudC5TdHJldGNoO1xyXG5HcmlkXzU1ZWVmOWI2YzQxYzQ3N2ZiYWVjYjQxODNhN2M3ODNmLlZlcnRpY2FsQWxpZ25tZW50ID0gZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuVmVydGljYWxBbGlnbm1lbnQuU3RyZXRjaDtcclxuR3JpZF81NWVlZjliNmM0MWM0NzdmYmFlY2I0MTgzYTdjNzgzZi5NYXJnaW4gPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuVGhpY2tuZXNzKDApO1xyXG52YXIgQmluZGluZ185MDhiMDFjZmRlMTA0NGFlYmI1NmMwYTgzYTIzMTM2YyA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmcoKTtcclxuQmluZGluZ185MDhiMDFjZmRlMTA0NGFlYmI1NmMwYTgzYTIzMTM2Yy5QYXRoID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlByb3BlcnR5UGF0aChAXCJPdmVybGF5QnJ1c2hcIik7XHJcbnZhciBSZWxhdGl2ZVNvdXJjZV80N2Y2YzM2ZmRmY2E0MWE4ODM0MTRjOTY2YTM4YjcyYiA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLlJlbGF0aXZlU291cmNlKCk7XHJcblJlbGF0aXZlU291cmNlXzQ3ZjZjMzZmZGZjYTQxYTg4MzQxNGM5NjZhMzhiNzJiLk1vZGUgPSBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLlJlbGF0aXZlU291cmNlTW9kZS5UZW1wbGF0ZWRQYXJlbnQ7XHJcblxyXG5CaW5kaW5nXzkwOGIwMWNmZGUxMDQ0YWViYjU2YzBhODNhMjMxMzZjLlJlbGF0aXZlU291cmNlID0gUmVsYXRpdmVTb3VyY2VfNDdmNmMzNmZkZmNhNDFhODgzNDE0Yzk2NmEzOGI3MmI7XHJcblxyXG5cclxuQmluZGluZ185MDhiMDFjZmRlMTA0NGFlYmI1NmMwYTgzYTIzMTM2Yy5UZW1wbGF0ZU93bmVyID0gdGVtcGxhdGVJbnN0YW5jZV81ZThmYTc1MDkxOGE0NzcxOTdmOGU5NDE0MmM0NjM4ZTtcclxuXHJcbnZhciBCaW5kaW5nX2E4NDg5YTFlZGRiMTRiMjM5ZWFhNGU2NzZmNjMxZDMzID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuQmluZGluZygpO1xyXG5CaW5kaW5nX2E4NDg5YTFlZGRiMTRiMjM5ZWFhNGU2NzZmNjMxZDMzLlBhdGggPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuUHJvcGVydHlQYXRoKEBcIk92ZXJsYXlPcGFjaXR5XCIpO1xyXG52YXIgUmVsYXRpdmVTb3VyY2VfYzY2MzYzNjk5ZjVmNDAxMThiYjc2NDA5OWQwM2E5NjMgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5SZWxhdGl2ZVNvdXJjZSgpO1xyXG5SZWxhdGl2ZVNvdXJjZV9jNjYzNjM2OTlmNWY0MDExOGJiNzY0MDk5ZDAzYTk2My5Nb2RlID0gZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5SZWxhdGl2ZVNvdXJjZU1vZGUuVGVtcGxhdGVkUGFyZW50O1xyXG5cclxuQmluZGluZ19hODQ4OWExZWRkYjE0YjIzOWVhYTRlNjc2ZjYzMWQzMy5SZWxhdGl2ZVNvdXJjZSA9IFJlbGF0aXZlU291cmNlX2M2NjM2MzY5OWY1ZjQwMTE4YmI3NjQwOTlkMDNhOTYzO1xyXG5cclxuXHJcbkJpbmRpbmdfYTg0ODlhMWVkZGIxNGIyMzllYWE0ZTY3NmY2MzFkMzMuVGVtcGxhdGVPd25lciA9IHRlbXBsYXRlSW5zdGFuY2VfNWU4ZmE3NTA5MThhNDc3MTk3ZjhlOTQxNDJjNDYzOGU7XHJcblxyXG5cclxudGVtcGxhdGVPd25lcl9Db250cm9sVGVtcGxhdGVfZmVlYzQ1OGUwNmE1NDg3OGE2OTEyNTk2OTU4M2NlMDMuUmVnaXN0ZXJOYW1lKFwiQ29udGVudFJvb3RcIiwgQm9yZGVyX2U5ZTYzNTM5N2MxOTQyODI4MTFjMmYxMGJiNWJlMjQxKTtcclxuQm9yZGVyX2U5ZTYzNTM5N2MxOTQyODI4MTFjMmYxMGJiNWJlMjQxLk5hbWUgPSBcIkNvbnRlbnRSb290XCI7XHJcbnRlbXBsYXRlT3duZXJfQ29udHJvbFRlbXBsYXRlX2ZlZWM0NThlMDZhNTQ4NzhhNjkxMjU5Njk1ODNjZTAzLlJlZ2lzdGVyTmFtZShcIkNvbnRlbnRDb250YWluZXJcIiwgQm9yZGVyX2JiZmMzNmZkOTNkZjRjZjRiNDE0NjVhMTJmM2YxZDA4KTtcclxuQm9yZGVyX2JiZmMzNmZkOTNkZjRjZjRiNDE0NjVhMTJmM2YxZDA4Lk5hbWUgPSBcIkNvbnRlbnRDb250YWluZXJcIjtcclxuQm9yZGVyX2JiZmMzNmZkOTNkZjRjZjRiNDE0NjVhMTJmM2YxZDA4LkJhY2tncm91bmQgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuTWVkaWEuU29saWRDb2xvckJydXNoKG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuQ29sb3IoKSB7IEEgPSAoYnl0ZSkyNTUsIFIgPSAoYnl0ZSkyNDYsIEcgPSAoYnl0ZSkyNDYsIEIgPSAoYnl0ZSkyNDYgfSk7XHJcbkJvcmRlcl9iYmZjMzZmZDkzZGY0Y2Y0YjQxNDY1YTEyZjNmMWQwOC5Db3JuZXJSYWRpdXMgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuQ29ybmVyUmFkaXVzKDIpO1xyXG52YXIgR3JpZF9iZTU1MzQ2YzVlNzU0ZTZjYjM2MmYxYTk2M2Y1OTMzOCA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Db250cm9scy5HcmlkKCk7XHJcbnZhciBSb3dEZWZpbml0aW9uXzc3ZmNjMDc0MmY5YzRlOWFiMWE3Mzg3ZWQ0NTc1YmFlID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkNvbnRyb2xzLlJvd0RlZmluaXRpb24oKTtcclxuUm93RGVmaW5pdGlvbl83N2ZjYzA3NDJmOWM0ZTlhYjFhNzM4N2VkNDU3NWJhZS5IZWlnaHQgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuR3JpZExlbmd0aCgxLjAsIGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkdyaWRVbml0VHlwZS5BdXRvKTtcclxuXHJcbnZhciBSb3dEZWZpbml0aW9uXzEyNmU2YmFjZGE1ZDQzOThhMTQ0ZTg2ZmVmZGVjZjAwID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkNvbnRyb2xzLlJvd0RlZmluaXRpb24oKTtcclxuUm93RGVmaW5pdGlvbl8xMjZlNmJhY2RhNWQ0Mzk4YTE0NGU4NmZlZmRlY2YwMC5IZWlnaHQgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuR3JpZExlbmd0aCgxLjAsIGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkdyaWRVbml0VHlwZS5TdGFyKTtcclxuXHJcbkdyaWRfYmU1NTM0NmM1ZTc1NGU2Y2IzNjJmMWE5NjNmNTkzMzguUm93RGVmaW5pdGlvbnMuQWRkKFJvd0RlZmluaXRpb25fNzdmY2MwNzQyZjljNGU5YWIxYTczODdlZDQ1NzViYWUpO1xyXG5HcmlkX2JlNTUzNDZjNWU3NTRlNmNiMzYyZjFhOTYzZjU5MzM4LlJvd0RlZmluaXRpb25zLkFkZChSb3dEZWZpbml0aW9uXzEyNmU2YmFjZGE1ZDQzOThhMTQ0ZTg2ZmVmZGVjZjAwKTtcclxuXHJcbnRlbXBsYXRlT3duZXJfQ29udHJvbFRlbXBsYXRlX2ZlZWM0NThlMDZhNTQ4NzhhNjkxMjU5Njk1ODNjZTAzLlJlZ2lzdGVyTmFtZShcIkNocm9tZVwiLCBCb3JkZXJfMmY4ZTEyMGZmNjlmNDg5YTk3M2RlOWI0ZGYzYTcxZjUpO1xyXG5Cb3JkZXJfMmY4ZTEyMGZmNjlmNDg5YTk3M2RlOWI0ZGYzYTcxZjUuTmFtZSA9IFwiQ2hyb21lXCI7XHJcbkJvcmRlcl8yZjhlMTIwZmY2OWY0ODlhOTczZGU5YjRkZjNhNzFmNS5XaWR0aCA9IGdsb2JhbDo6U3lzdGVtLkRvdWJsZS5OYU47XHJcbkJvcmRlcl8yZjhlMTIwZmY2OWY0ODlhOTczZGU5YjRkZjNhNzFmNS5Cb3JkZXJCcnVzaCA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5NZWRpYS5Tb2xpZENvbG9yQnJ1c2gobmV3IGdsb2JhbDo6V2luZG93cy5VSS5Db2xvcigpIHsgQSA9IChieXRlKTI1NSwgUiA9IChieXRlKTI1NSwgRyA9IChieXRlKTI1NSwgQiA9IChieXRlKTI1NSB9KTtcclxuQm9yZGVyXzJmOGUxMjBmZjY5ZjQ4OWE5NzNkZTliNGRmM2E3MWY1LkJvcmRlclRoaWNrbmVzcyA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5UaGlja25lc3MoMCwgMCwgMCwgMCk7XHJcbkJvcmRlcl8yZjhlMTIwZmY2OWY0ODlhOTczZGU5YjRkZjNhNzFmNS5CYWNrZ3JvdW5kID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLk1lZGlhLlNvbGlkQ29sb3JCcnVzaChuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLkNvbG9yKCkgeyBBID0gKGJ5dGUpMjU1LCBSID0gKGJ5dGUpMjM4LCBHID0gKGJ5dGUpMjM4LCBCID0gKGJ5dGUpMjM4IH0pO1xyXG52YXIgR3JpZF80NmViZmFkNmQ1Nzk0ZmJkOWJlMzBkMzkwMDJjYzMwNSA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Db250cm9scy5HcmlkKCk7XHJcbnZhciBDb2x1bW5EZWZpbml0aW9uXzI5YWY2ODFjMGRmYjQzZmY5NmFiMjQwOGJkZWYzZTdmID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkNvbnRyb2xzLkNvbHVtbkRlZmluaXRpb24oKTtcclxuQ29sdW1uRGVmaW5pdGlvbl8yOWFmNjgxYzBkZmI0M2ZmOTZhYjI0MDhiZGVmM2U3Zi5XaWR0aCA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5HcmlkTGVuZ3RoKDEuMCwgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuR3JpZFVuaXRUeXBlLkF1dG8pO1xyXG5cclxudmFyIENvbHVtbkRlZmluaXRpb25fY2MwYzkzOWYyY2IxNDQxZmIyNmExYWFiODRlYTRlNjQgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuQ29udHJvbHMuQ29sdW1uRGVmaW5pdGlvbigpO1xyXG5Db2x1bW5EZWZpbml0aW9uX2NjMGM5MzlmMmNiMTQ0MWZiMjZhMWFhYjg0ZWE0ZTY0LldpZHRoID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkdyaWRMZW5ndGgoMS4wLCBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5HcmlkVW5pdFR5cGUuU3Rhcik7XHJcblxyXG52YXIgQ29sdW1uRGVmaW5pdGlvbl9jYzIyMDJmYzhmNzM0M2QyYjEzNTUxNzhiODdmYTBiMSA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Db250cm9scy5Db2x1bW5EZWZpbml0aW9uKCk7XHJcbkNvbHVtbkRlZmluaXRpb25fY2MyMjAyZmM4ZjczNDNkMmIxMzU1MTc4Yjg3ZmEwYjEuV2lkdGggPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuR3JpZExlbmd0aCgxLjAsIGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkdyaWRVbml0VHlwZS5BdXRvKTtcclxuXHJcbnZhciBDb2x1bW5EZWZpbml0aW9uXzUxM2MzMTNkNzM2YjQ0OWVhZjhmNTI4MjE3OGJiNjM1ID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkNvbnRyb2xzLkNvbHVtbkRlZmluaXRpb24oKTtcclxuQ29sdW1uRGVmaW5pdGlvbl81MTNjMzEzZDczNmI0NDllYWY4ZjUyODIxNzhiYjYzNS5XaWR0aCA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5HcmlkTGVuZ3RoKDEuMCwgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuR3JpZFVuaXRUeXBlLkF1dG8pO1xyXG5cclxudmFyIENvbHVtbkRlZmluaXRpb25fZDhjMTRlMmNkZmQ1NGYzYmJlNzRiNmFhNjQzYmEzMjggPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuQ29udHJvbHMuQ29sdW1uRGVmaW5pdGlvbigpO1xyXG5Db2x1bW5EZWZpbml0aW9uX2Q4YzE0ZTJjZGZkNTRmM2JiZTc0YjZhYTY0M2JhMzI4LldpZHRoID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkdyaWRMZW5ndGgoMS4wLCBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5HcmlkVW5pdFR5cGUuQXV0byk7XHJcblxyXG52YXIgQ29sdW1uRGVmaW5pdGlvbl8zNWZlMjhkNjdhNzY0MDljODIzYzg0ZmFlNmEzMDAwNiA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Db250cm9scy5Db2x1bW5EZWZpbml0aW9uKCk7XHJcbkNvbHVtbkRlZmluaXRpb25fMzVmZTI4ZDY3YTc2NDA5YzgyM2M4NGZhZTZhMzAwMDYuV2lkdGggPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuR3JpZExlbmd0aCgxLjAsIGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkdyaWRVbml0VHlwZS5BdXRvKTtcclxuXHJcbnZhciBDb2x1bW5EZWZpbml0aW9uXzM4YjU0YzBlMTU1ZjRiYWJhZGUwMWUwOTg0ZWZiMmY2ID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkNvbnRyb2xzLkNvbHVtbkRlZmluaXRpb24oKTtcclxuQ29sdW1uRGVmaW5pdGlvbl8zOGI1NGMwZTE1NWY0YmFiYWRlMDFlMDk4NGVmYjJmNi5XaWR0aCA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5HcmlkTGVuZ3RoKDEuMCwgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuR3JpZFVuaXRUeXBlLkF1dG8pO1xyXG5cclxuR3JpZF80NmViZmFkNmQ1Nzk0ZmJkOWJlMzBkMzkwMDJjYzMwNS5Db2x1bW5EZWZpbml0aW9ucy5BZGQoQ29sdW1uRGVmaW5pdGlvbl8yOWFmNjgxYzBkZmI0M2ZmOTZhYjI0MDhiZGVmM2U3Zik7XHJcbkdyaWRfNDZlYmZhZDZkNTc5NGZiZDliZTMwZDM5MDAyY2MzMDUuQ29sdW1uRGVmaW5pdGlvbnMuQWRkKENvbHVtbkRlZmluaXRpb25fY2MwYzkzOWYyY2IxNDQxZmIyNmExYWFiODRlYTRlNjQpO1xyXG5HcmlkXzQ2ZWJmYWQ2ZDU3OTRmYmQ5YmUzMGQzOTAwMmNjMzA1LkNvbHVtbkRlZmluaXRpb25zLkFkZChDb2x1bW5EZWZpbml0aW9uX2NjMjIwMmZjOGY3MzQzZDJiMTM1NTE3OGI4N2ZhMGIxKTtcclxuR3JpZF80NmViZmFkNmQ1Nzk0ZmJkOWJlMzBkMzkwMDJjYzMwNS5Db2x1bW5EZWZpbml0aW9ucy5BZGQoQ29sdW1uRGVmaW5pdGlvbl81MTNjMzEzZDczNmI0NDllYWY4ZjUyODIxNzhiYjYzNSk7XHJcbkdyaWRfNDZlYmZhZDZkNTc5NGZiZDliZTMwZDM5MDAyY2MzMDUuQ29sdW1uRGVmaW5pdGlvbnMuQWRkKENvbHVtbkRlZmluaXRpb25fZDhjMTRlMmNkZmQ1NGYzYmJlNzRiNmFhNjQzYmEzMjgpO1xyXG5HcmlkXzQ2ZWJmYWQ2ZDU3OTRmYmQ5YmUzMGQzOTAwMmNjMzA1LkNvbHVtbkRlZmluaXRpb25zLkFkZChDb2x1bW5EZWZpbml0aW9uXzM1ZmUyOGQ2N2E3NjQwOWM4MjNjODRmYWU2YTMwMDA2KTtcclxuR3JpZF80NmViZmFkNmQ1Nzk0ZmJkOWJlMzBkMzkwMDJjYzMwNS5Db2x1bW5EZWZpbml0aW9ucy5BZGQoQ29sdW1uRGVmaW5pdGlvbl8zOGI1NGMwZTE1NWY0YmFiYWRlMDFlMDk4NGVmYjJmNik7XHJcblxyXG50ZW1wbGF0ZU93bmVyX0NvbnRyb2xUZW1wbGF0ZV9mZWVjNDU4ZTA2YTU0ODc4YTY5MTI1OTY5NTgzY2UwMy5SZWdpc3Rlck5hbWUoXCJJY29uQnV0dG9uXCIsIEJ1dHRvbl9jMWFlNTg3YzZkYjc0NWZkOTE3MDczMGExM2EwNDU1YSk7XHJcbkJ1dHRvbl9jMWFlNTg3YzZkYjc0NWZkOTE3MDczMGExM2EwNDU1YS5OYW1lID0gXCJJY29uQnV0dG9uXCI7XHJcbkJ1dHRvbl9jMWFlNTg3YzZkYjc0NWZkOTE3MDczMGExM2EwNDU1YS5Ib3Jpem9udGFsQWxpZ25tZW50ID0gZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuSG9yaXpvbnRhbEFsaWdubWVudC5MZWZ0O1xyXG5CdXR0b25fYzFhZTU4N2M2ZGI3NDVmZDkxNzA3MzBhMTNhMDQ1NWEuVmVydGljYWxBbGlnbm1lbnQgPSBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5WZXJ0aWNhbEFsaWdubWVudC5DZW50ZXI7XHJcbkJ1dHRvbl9jMWFlNTg3YzZkYjc0NWZkOTE3MDczMGExM2EwNDU1YS5Ib3Jpem9udGFsQ29udGVudEFsaWdubWVudCA9IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkhvcml6b250YWxBbGlnbm1lbnQuQ2VudGVyO1xyXG5CdXR0b25fYzFhZTU4N2M2ZGI3NDVmZDkxNzA3MzBhMTNhMDQ1NWEuVmVydGljYWxDb250ZW50QWxpZ25tZW50ID0gZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuVmVydGljYWxBbGlnbm1lbnQuQ2VudGVyO1xyXG5CdXR0b25fYzFhZTU4N2M2ZGI3NDVmZDkxNzA3MzBhMTNhMDQ1NWEuV2lkdGggPSAyMEQ7XHJcbkJ1dHRvbl9jMWFlNTg3YzZkYjc0NWZkOTE3MDczMGExM2EwNDU1YS5QYWRkaW5nID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlRoaWNrbmVzcygwKTtcclxudmFyIEltYWdlXzMwNjUxYzNhMTJjOTRjOWViMzMzNGU3M2YzMTQzOWVhID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkNvbnRyb2xzLkltYWdlKCk7XHJcbnZhciBCaW5kaW5nXzU4NmMyNzQ1YzdiMzRkODViMzhkYjhiZGNhNjE5YmQyID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuQmluZGluZygpO1xyXG5CaW5kaW5nXzU4NmMyNzQ1YzdiMzRkODViMzhkYjhiZGNhNjE5YmQyLlBhdGggPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuUHJvcGVydHlQYXRoKEBcIkljb25cIik7XHJcblxyXG5cclxuXHJcbkJ1dHRvbl9jMWFlNTg3YzZkYjc0NWZkOTE3MDczMGExM2EwNDU1YS5Db250ZW50ID0gSW1hZ2VfMzA2NTFjM2ExMmM5NGM5ZWIzMzM0ZTczZjMxNDM5ZWE7XHJcblxyXG52YXIgQmluZGluZ18wNDBhYzVhODUzZWM0ZjJmYWZmZTQwNWEwNGQzMmEwNiA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmcoKTtcclxuQmluZGluZ18wNDBhYzVhODUzZWM0ZjJmYWZmZTQwNWEwNGQzMmEwNi5QYXRoID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlByb3BlcnR5UGF0aChAXCJJY29uVmlzaWJpbGl0eVwiKTtcclxuXHJcblxyXG5cclxudGVtcGxhdGVPd25lcl9Db250cm9sVGVtcGxhdGVfZmVlYzQ1OGUwNmE1NDg3OGE2OTEyNTk2OTU4M2NlMDMuUmVnaXN0ZXJOYW1lKFwiVGl0bGVcIiwgQ29udGVudENvbnRyb2xfMDU1YTUyYmRmMGY5NDE1MTgzY2EwMDA4YzIzOGVhNzQpO1xyXG5Db250ZW50Q29udHJvbF8wNTVhNTJiZGYwZjk0MTUxODNjYTAwMDhjMjM4ZWE3NC5OYW1lID0gXCJUaXRsZVwiO1xyXG5nbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Db250cm9scy5HcmlkLlNldENvbHVtbihDb250ZW50Q29udHJvbF8wNTVhNTJiZGYwZjk0MTUxODNjYTAwMDhjMjM4ZWE3NCwxKTtcclxuQ29udGVudENvbnRyb2xfMDU1YTUyYmRmMGY5NDE1MTgzY2EwMDA4YzIzOGVhNzQuSG9yaXpvbnRhbEFsaWdubWVudCA9IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkhvcml6b250YWxBbGlnbm1lbnQuTGVmdDtcclxuQ29udGVudENvbnRyb2xfMDU1YTUyYmRmMGY5NDE1MTgzY2EwMDA4YzIzOGVhNzQuVmVydGljYWxBbGlnbm1lbnQgPSBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5WZXJ0aWNhbEFsaWdubWVudC5DZW50ZXI7XHJcbkNvbnRlbnRDb250cm9sXzA1NWE1MmJkZjBmOTQxNTE4M2NhMDAwOGMyMzhlYTc0Lk1hcmdpbiA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5UaGlja25lc3MoNiwgMCwgNiwgMCk7XHJcbnZhciBCaW5kaW5nX2Y5M2I4YWM2ZjVlNjRkMGNiZTNmYzNlNzVjNmY1MjA1ID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuQmluZGluZygpO1xyXG5CaW5kaW5nX2Y5M2I4YWM2ZjVlNjRkMGNiZTNmYzNlNzVjNmY1MjA1LlBhdGggPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuUHJvcGVydHlQYXRoKEBcIlRpdGxlXCIpO1xyXG52YXIgUmVsYXRpdmVTb3VyY2VfZDVkODAxOTEzYjlkNDBhMWI2M2NkY2RhN2U3MGI3ZDUgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5SZWxhdGl2ZVNvdXJjZSgpO1xyXG5SZWxhdGl2ZVNvdXJjZV9kNWQ4MDE5MTNiOWQ0MGExYjYzY2RjZGE3ZTcwYjdkNS5Nb2RlID0gZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5SZWxhdGl2ZVNvdXJjZU1vZGUuVGVtcGxhdGVkUGFyZW50O1xyXG5cclxuQmluZGluZ19mOTNiOGFjNmY1ZTY0ZDBjYmUzZmMzZTc1YzZmNTIwNS5SZWxhdGl2ZVNvdXJjZSA9IFJlbGF0aXZlU291cmNlX2Q1ZDgwMTkxM2I5ZDQwYTFiNjNjZGNkYTdlNzBiN2Q1O1xyXG5cclxuXHJcbkJpbmRpbmdfZjkzYjhhYzZmNWU2NGQwY2JlM2ZjM2U3NWM2ZjUyMDUuVGVtcGxhdGVPd25lciA9IHRlbXBsYXRlSW5zdGFuY2VfNWU4ZmE3NTA5MThhNDc3MTk3ZjhlOTQxNDJjNDYzOGU7XHJcblxyXG5cclxudGVtcGxhdGVPd25lcl9Db250cm9sVGVtcGxhdGVfZmVlYzQ1OGUwNmE1NDg3OGE2OTEyNTk2OTU4M2NlMDMuUmVnaXN0ZXJOYW1lKFwiSGVscEJ1dHRvblwiLCBCdXR0b25fYWQyNmE2N2RhYmUzNDZkYTlkODNjMTkxZDJkNWI5ZDIpO1xyXG5CdXR0b25fYWQyNmE2N2RhYmUzNDZkYTlkODNjMTkxZDJkNWI5ZDIuTmFtZSA9IFwiSGVscEJ1dHRvblwiO1xyXG5CdXR0b25fYWQyNmE2N2RhYmUzNDZkYTlkODNjMTkxZDJkNWI5ZDIuSG9yaXpvbnRhbEFsaWdubWVudCA9IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkhvcml6b250YWxBbGlnbm1lbnQuUmlnaHQ7XHJcbkJ1dHRvbl9hZDI2YTY3ZGFiZTM0NmRhOWQ4M2MxOTFkMmQ1YjlkMi5WZXJ0aWNhbEFsaWdubWVudCA9IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlZlcnRpY2FsQWxpZ25tZW50LkNlbnRlcjtcclxuZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuQ29udHJvbHMuR3JpZC5TZXRDb2x1bW4oQnV0dG9uX2FkMjZhNjdkYWJlMzQ2ZGE5ZDgzYzE5MWQyZDViOWQyLDIpO1xyXG5CdXR0b25fYWQyNmE2N2RhYmUzNDZkYTlkODNjMTkxZDJkNWI5ZDIuSG9yaXpvbnRhbENvbnRlbnRBbGlnbm1lbnQgPSBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Ib3Jpem9udGFsQWxpZ25tZW50LkNlbnRlcjtcclxuQnV0dG9uX2FkMjZhNjdkYWJlMzQ2ZGE5ZDgzYzE5MWQyZDViOWQyLlZlcnRpY2FsQ29udGVudEFsaWdubWVudCA9IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlZlcnRpY2FsQWxpZ25tZW50LkNlbnRlcjtcclxuQnV0dG9uX2FkMjZhNjdkYWJlMzQ2ZGE5ZDgzYzE5MWQyZDViOWQyLldpZHRoID0gMjBEO1xyXG5CdXR0b25fYWQyNmE2N2RhYmUzNDZkYTlkODNjMTkxZDJkNWI5ZDIuUGFkZGluZyA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5UaGlja25lc3MoMCk7XHJcbnZhciBJbWFnZV82Yjg3ZTAyOGY0ZWY0NGEzODFhYjJjZTg0N2YyMjMzYiA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Db250cm9scy5JbWFnZSgpO1xyXG52YXIgQmluZGluZ180ZGYyOGEwMjRiYjE0NTYxYWViMmI0ZDNjN2IwYmE4MCA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmcoKTtcclxuQmluZGluZ180ZGYyOGEwMjRiYjE0NTYxYWViMmI0ZDNjN2IwYmE4MC5QYXRoID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlByb3BlcnR5UGF0aChAXCJIZWxwSWNvblwiKTtcclxuXHJcblxyXG5cclxuQnV0dG9uX2FkMjZhNjdkYWJlMzQ2ZGE5ZDgzYzE5MWQyZDViOWQyLkNvbnRlbnQgPSBJbWFnZV82Yjg3ZTAyOGY0ZWY0NGEzODFhYjJjZTg0N2YyMjMzYjtcclxuXHJcbnZhciBCaW5kaW5nXzJlOTE2ZDMyNzJhODRmM2JiMjI5MmRkOTc0OTc1YzBlID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuQmluZGluZygpO1xyXG5CaW5kaW5nXzJlOTE2ZDMyNzJhODRmM2JiMjI5MmRkOTc0OTc1YzBlLlBhdGggPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuUHJvcGVydHlQYXRoKEBcIkhlbHBWaXNpYmlsaXR5XCIpO1xyXG5cclxuXHJcblxyXG50ZW1wbGF0ZU93bmVyX0NvbnRyb2xUZW1wbGF0ZV9mZWVjNDU4ZTA2YTU0ODc4YTY5MTI1OTY5NTgzY2UwMy5SZWdpc3Rlck5hbWUoXCJNaW5CdXR0b25cIiwgQnV0dG9uXzM1MjkxNTliNWRiNjQ5YWQ4NGY1ZDAzZTUxNjdjZjYxKTtcclxuQnV0dG9uXzM1MjkxNTliNWRiNjQ5YWQ4NGY1ZDAzZTUxNjdjZjYxLk5hbWUgPSBcIk1pbkJ1dHRvblwiO1xyXG5CdXR0b25fMzUyOTE1OWI1ZGI2NDlhZDg0ZjVkMDNlNTE2N2NmNjEuSG9yaXpvbnRhbEFsaWdubWVudCA9IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkhvcml6b250YWxBbGlnbm1lbnQuUmlnaHQ7XHJcbkJ1dHRvbl8zNTI5MTU5YjVkYjY0OWFkODRmNWQwM2U1MTY3Y2Y2MS5WZXJ0aWNhbEFsaWdubWVudCA9IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlZlcnRpY2FsQWxpZ25tZW50LkNlbnRlcjtcclxuZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuQ29udHJvbHMuR3JpZC5TZXRDb2x1bW4oQnV0dG9uXzM1MjkxNTliNWRiNjQ5YWQ4NGY1ZDAzZTUxNjdjZjYxLDMpO1xyXG5CdXR0b25fMzUyOTE1OWI1ZGI2NDlhZDg0ZjVkMDNlNTE2N2NmNjEuSG9yaXpvbnRhbENvbnRlbnRBbGlnbm1lbnQgPSBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Ib3Jpem9udGFsQWxpZ25tZW50LkNlbnRlcjtcclxuQnV0dG9uXzM1MjkxNTliNWRiNjQ5YWQ4NGY1ZDAzZTUxNjdjZjYxLlZlcnRpY2FsQ29udGVudEFsaWdubWVudCA9IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlZlcnRpY2FsQWxpZ25tZW50LkNlbnRlcjtcclxuQnV0dG9uXzM1MjkxNTliNWRiNjQ5YWQ4NGY1ZDAzZTUxNjdjZjYxLldpZHRoID0gMjBEO1xyXG5CdXR0b25fMzUyOTE1OWI1ZGI2NDlhZDg0ZjVkMDNlNTE2N2NmNjEuUGFkZGluZyA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5UaGlja25lc3MoMCk7XHJcbkJ1dHRvbl8zNTI5MTU5YjVkYjY0OWFkODRmNWQwM2U1MTY3Y2Y2MS5DbGljayArPSBSdW5DbGlja01pbjtcclxudmFyIEltYWdlX2RiYWQ2MzAyNDQ2ZDQyNDY4MTdhOTQ4ZTNkMzdjMTk1ID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkNvbnRyb2xzLkltYWdlKCk7XHJcbnZhciBCaW5kaW5nXzhmYmZlZTgyZWY4ZjQyNTlhMTY0MDIyZDFmYTgxMWZiID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuQmluZGluZygpO1xyXG5CaW5kaW5nXzhmYmZlZTgyZWY4ZjQyNTlhMTY0MDIyZDFmYTgxMWZiLlBhdGggPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuUHJvcGVydHlQYXRoKEBcIk1pblJlc0ljb25cIik7XHJcblxyXG5cclxuXHJcbkJ1dHRvbl8zNTI5MTU5YjVkYjY0OWFkODRmNWQwM2U1MTY3Y2Y2MS5Db250ZW50ID0gSW1hZ2VfZGJhZDYzMDI0NDZkNDI0NjgxN2E5NDhlM2QzN2MxOTU7XHJcblxyXG52YXIgQmluZGluZ19mMmFhYWE0NDhmZmQ0Y2M1YTM1NjNmYWZiOGVhMTA5NyA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmcoKTtcclxuQmluZGluZ19mMmFhYWE0NDhmZmQ0Y2M1YTM1NjNmYWZiOGVhMTA5Ny5QYXRoID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlByb3BlcnR5UGF0aChAXCJNaW5WaXNpYmlsaXR5XCIpO1xyXG5cclxuXHJcblxyXG50ZW1wbGF0ZU93bmVyX0NvbnRyb2xUZW1wbGF0ZV9mZWVjNDU4ZTA2YTU0ODc4YTY5MTI1OTY5NTgzY2UwMy5SZWdpc3Rlck5hbWUoXCJNYXhCdXR0b25cIiwgQnV0dG9uX2FlOGZkZDRkYTNmMDQxOTNiMmE0ZWUxYTgzYzdjZTcwKTtcclxuQnV0dG9uX2FlOGZkZDRkYTNmMDQxOTNiMmE0ZWUxYTgzYzdjZTcwLk5hbWUgPSBcIk1heEJ1dHRvblwiO1xyXG5CdXR0b25fYWU4ZmRkNGRhM2YwNDE5M2IyYTRlZTFhODNjN2NlNzAuSG9yaXpvbnRhbEFsaWdubWVudCA9IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkhvcml6b250YWxBbGlnbm1lbnQuUmlnaHQ7XHJcbkJ1dHRvbl9hZThmZGQ0ZGEzZjA0MTkzYjJhNGVlMWE4M2M3Y2U3MC5WZXJ0aWNhbEFsaWdubWVudCA9IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlZlcnRpY2FsQWxpZ25tZW50LkNlbnRlcjtcclxuZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuQ29udHJvbHMuR3JpZC5TZXRDb2x1bW4oQnV0dG9uX2FlOGZkZDRkYTNmMDQxOTNiMmE0ZWUxYTgzYzdjZTcwLDQpO1xyXG5CdXR0b25fYWU4ZmRkNGRhM2YwNDE5M2IyYTRlZTFhODNjN2NlNzAuSG9yaXpvbnRhbENvbnRlbnRBbGlnbm1lbnQgPSBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Ib3Jpem9udGFsQWxpZ25tZW50LkNlbnRlcjtcclxuQnV0dG9uX2FlOGZkZDRkYTNmMDQxOTNiMmE0ZWUxYTgzYzdjZTcwLlZlcnRpY2FsQ29udGVudEFsaWdubWVudCA9IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlZlcnRpY2FsQWxpZ25tZW50LkNlbnRlcjtcclxuQnV0dG9uX2FlOGZkZDRkYTNmMDQxOTNiMmE0ZWUxYTgzYzdjZTcwLldpZHRoID0gMjBEO1xyXG5CdXR0b25fYWU4ZmRkNGRhM2YwNDE5M2IyYTRlZTFhODNjN2NlNzAuUGFkZGluZyA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5UaGlja25lc3MoMCk7XHJcbkJ1dHRvbl9hZThmZGQ0ZGEzZjA0MTkzYjJhNGVlMWE4M2M3Y2U3MC5DbGljayArPSBSdW5DbGlja01heDtcclxudmFyIEltYWdlXzM1MjQ5MWI3NDFjOTQ3MTJhNzVkNmNkMGY2ODQxMzhjID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkNvbnRyb2xzLkltYWdlKCk7XHJcbnZhciBCaW5kaW5nX2FiYWUzMjllNGI5MzQ1YzU4YTY3Y2E0YzE5NWIwNDY1ID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuQmluZGluZygpO1xyXG5CaW5kaW5nX2FiYWUzMjllNGI5MzQ1YzU4YTY3Y2E0YzE5NWIwNDY1LlBhdGggPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuUHJvcGVydHlQYXRoKEBcIk1heFJlc0ljb25cIik7XHJcblxyXG5cclxuXHJcbkJ1dHRvbl9hZThmZGQ0ZGEzZjA0MTkzYjJhNGVlMWE4M2M3Y2U3MC5Db250ZW50ID0gSW1hZ2VfMzUyNDkxYjc0MWM5NDcxMmE3NWQ2Y2QwZjY4NDEzOGM7XHJcblxyXG52YXIgQmluZGluZ19mOGU4NmY4NzExYzM0MGIwYjUwZGRmMGQyMGVhYzUzOSA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmcoKTtcclxuQmluZGluZ19mOGU4NmY4NzExYzM0MGIwYjUwZGRmMGQyMGVhYzUzOS5QYXRoID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlByb3BlcnR5UGF0aChAXCJNYXhWaXNpYmlsaXR5XCIpO1xyXG5cclxuXHJcblxyXG50ZW1wbGF0ZU93bmVyX0NvbnRyb2xUZW1wbGF0ZV9mZWVjNDU4ZTA2YTU0ODc4YTY5MTI1OTY5NTgzY2UwMy5SZWdpc3Rlck5hbWUoXCJGdWxsU2NyZWVuQnV0dG9uXCIsIEJ1dHRvbl82ZmM1ZGRlNGQ0YWM0ODY4OGYwOWE2OTFhM2U2MjA4ZCk7XHJcbkJ1dHRvbl82ZmM1ZGRlNGQ0YWM0ODY4OGYwOWE2OTFhM2U2MjA4ZC5OYW1lID0gXCJGdWxsU2NyZWVuQnV0dG9uXCI7XHJcbkJ1dHRvbl82ZmM1ZGRlNGQ0YWM0ODY4OGYwOWE2OTFhM2U2MjA4ZC5Ib3Jpem9udGFsQWxpZ25tZW50ID0gZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuSG9yaXpvbnRhbEFsaWdubWVudC5SaWdodDtcclxuQnV0dG9uXzZmYzVkZGU0ZDRhYzQ4Njg4ZjA5YTY5MWEzZTYyMDhkLlZlcnRpY2FsQWxpZ25tZW50ID0gZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuVmVydGljYWxBbGlnbm1lbnQuQ2VudGVyO1xyXG5nbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Db250cm9scy5HcmlkLlNldENvbHVtbihCdXR0b25fNmZjNWRkZTRkNGFjNDg2ODhmMDlhNjkxYTNlNjIwOGQsNSk7XHJcbkJ1dHRvbl82ZmM1ZGRlNGQ0YWM0ODY4OGYwOWE2OTFhM2U2MjA4ZC5Ib3Jpem9udGFsQ29udGVudEFsaWdubWVudCA9IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkhvcml6b250YWxBbGlnbm1lbnQuQ2VudGVyO1xyXG5CdXR0b25fNmZjNWRkZTRkNGFjNDg2ODhmMDlhNjkxYTNlNjIwOGQuVmVydGljYWxDb250ZW50QWxpZ25tZW50ID0gZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuVmVydGljYWxBbGlnbm1lbnQuQ2VudGVyO1xyXG5CdXR0b25fNmZjNWRkZTRkNGFjNDg2ODhmMDlhNjkxYTNlNjIwOGQuV2lkdGggPSAyMEQ7XHJcbkJ1dHRvbl82ZmM1ZGRlNGQ0YWM0ODY4OGYwOWE2OTFhM2U2MjA4ZC5QYWRkaW5nID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlRoaWNrbmVzcygwKTtcclxuQnV0dG9uXzZmYzVkZGU0ZDRhYzQ4Njg4ZjA5YTY5MWEzZTYyMDhkLkNsaWNrICs9IFJ1bkNsaWNrRnVsbFNjcmVlbjtcclxudmFyIEltYWdlXzg4ZTE4OTJiOTQwMDRjZjNiNzljZjI0ZDk4NGQ4MDk2ID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkNvbnRyb2xzLkltYWdlKCk7XHJcbnZhciBCaW5kaW5nX2VjZTY2YzA1ZjAzZDQxN2Q5Y2Y4MWY4NDM0OWY2YWQ3ID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuQmluZGluZygpO1xyXG5CaW5kaW5nX2VjZTY2YzA1ZjAzZDQxN2Q5Y2Y4MWY4NDM0OWY2YWQ3LlBhdGggPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuUHJvcGVydHlQYXRoKEBcIkZ1bGxTY3JlZW5JY29uXCIpO1xyXG5cclxuXHJcblxyXG5CdXR0b25fNmZjNWRkZTRkNGFjNDg2ODhmMDlhNjkxYTNlNjIwOGQuQ29udGVudCA9IEltYWdlXzg4ZTE4OTJiOTQwMDRjZjNiNzljZjI0ZDk4NGQ4MDk2O1xyXG5cclxudmFyIEJpbmRpbmdfOGQ5N2E1NDdhM2E1NDY3OGFjOWYzODZhYTYwOTgyOWEgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5CaW5kaW5nKCk7XHJcbkJpbmRpbmdfOGQ5N2E1NDdhM2E1NDY3OGFjOWYzODZhYTYwOTgyOWEuUGF0aCA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Qcm9wZXJ0eVBhdGgoQFwiRnVsbFNjcmVlblZpc2liaWxpdHlcIik7XHJcblxyXG5cclxuXHJcbnRlbXBsYXRlT3duZXJfQ29udHJvbFRlbXBsYXRlX2ZlZWM0NThlMDZhNTQ4NzhhNjkxMjU5Njk1ODNjZTAzLlJlZ2lzdGVyTmFtZShcIkNsb3NlQnV0dG9uXCIsIEJ1dHRvbl80NmMyMjVmNzY0YWM0MGZkOGNkZjllMjdhMjI3MzRlZCk7XHJcbkJ1dHRvbl80NmMyMjVmNzY0YWM0MGZkOGNkZjllMjdhMjI3MzRlZC5OYW1lID0gXCJDbG9zZUJ1dHRvblwiO1xyXG5CdXR0b25fNDZjMjI1Zjc2NGFjNDBmZDhjZGY5ZTI3YTIyNzM0ZWQuSG9yaXpvbnRhbEFsaWdubWVudCA9IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkhvcml6b250YWxBbGlnbm1lbnQuUmlnaHQ7XHJcbkJ1dHRvbl80NmMyMjVmNzY0YWM0MGZkOGNkZjllMjdhMjI3MzRlZC5WZXJ0aWNhbEFsaWdubWVudCA9IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlZlcnRpY2FsQWxpZ25tZW50LkNlbnRlcjtcclxuZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuQ29udHJvbHMuR3JpZC5TZXRDb2x1bW4oQnV0dG9uXzQ2YzIyNWY3NjRhYzQwZmQ4Y2RmOWUyN2EyMjczNGVkLDYpO1xyXG5CdXR0b25fNDZjMjI1Zjc2NGFjNDBmZDhjZGY5ZTI3YTIyNzM0ZWQuSG9yaXpvbnRhbENvbnRlbnRBbGlnbm1lbnQgPSBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Ib3Jpem9udGFsQWxpZ25tZW50LkNlbnRlcjtcclxuQnV0dG9uXzQ2YzIyNWY3NjRhYzQwZmQ4Y2RmOWUyN2EyMjczNGVkLlZlcnRpY2FsQ29udGVudEFsaWdubWVudCA9IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlZlcnRpY2FsQWxpZ25tZW50LkNlbnRlcjtcclxuQnV0dG9uXzQ2YzIyNWY3NjRhYzQwZmQ4Y2RmOWUyN2EyMjczNGVkLldpZHRoID0gMjBEO1xyXG5CdXR0b25fNDZjMjI1Zjc2NGFjNDBmZDhjZGY5ZTI3YTIyNzM0ZWQuUGFkZGluZyA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5UaGlja25lc3MoMCk7XHJcbkJ1dHRvbl80NmMyMjVmNzY0YWM0MGZkOGNkZjllMjdhMjI3MzRlZC5DbGljayArPSBSdW5DbGlja0Nsb3NlO1xyXG52YXIgSW1hZ2VfNGY4ZDkzYTg1MDkxNDBlNmJkMTk4Yjg3YmZlN2M5MzcgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuQ29udHJvbHMuSW1hZ2UoKTtcclxudmFyIEJpbmRpbmdfYWRjYzA0NWYwMjkzNDkzN2JmYjU5MzljYzhlNjNjNDcgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5CaW5kaW5nKCk7XHJcbkJpbmRpbmdfYWRjYzA0NWYwMjkzNDkzN2JmYjU5MzljYzhlNjNjNDcuUGF0aCA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Qcm9wZXJ0eVBhdGgoQFwiQ2xvc2VJY29uXCIpO1xyXG5cclxuXHJcblxyXG5CdXR0b25fNDZjMjI1Zjc2NGFjNDBmZDhjZGY5ZTI3YTIyNzM0ZWQuQ29udGVudCA9IEltYWdlXzRmOGQ5M2E4NTA5MTQwZTZiZDE5OGI4N2JmZTdjOTM3O1xyXG5cclxudmFyIEJpbmRpbmdfMjM0ZTY0NGI4ZjkxNGU5MWE1NWE4NjAwODU0MGJmNWUgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5CaW5kaW5nKCk7XHJcbkJpbmRpbmdfMjM0ZTY0NGI4ZjkxNGU5MWE1NWE4NjAwODU0MGJmNWUuUGF0aCA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Qcm9wZXJ0eVBhdGgoQFwiQ2xvc2VWaXNpYmlsaXR5XCIpO1xyXG5cclxuXHJcblxyXG5HcmlkXzQ2ZWJmYWQ2ZDU3OTRmYmQ5YmUzMGQzOTAwMmNjMzA1LkNoaWxkcmVuLkFkZChCdXR0b25fYzFhZTU4N2M2ZGI3NDVmZDkxNzA3MzBhMTNhMDQ1NWEpO1xyXG5HcmlkXzQ2ZWJmYWQ2ZDU3OTRmYmQ5YmUzMGQzOTAwMmNjMzA1LkNoaWxkcmVuLkFkZChDb250ZW50Q29udHJvbF8wNTVhNTJiZGYwZjk0MTUxODNjYTAwMDhjMjM4ZWE3NCk7XHJcbkdyaWRfNDZlYmZhZDZkNTc5NGZiZDliZTMwZDM5MDAyY2MzMDUuQ2hpbGRyZW4uQWRkKEJ1dHRvbl9hZDI2YTY3ZGFiZTM0NmRhOWQ4M2MxOTFkMmQ1YjlkMik7XHJcbkdyaWRfNDZlYmZhZDZkNTc5NGZiZDliZTMwZDM5MDAyY2MzMDUuQ2hpbGRyZW4uQWRkKEJ1dHRvbl8zNTI5MTU5YjVkYjY0OWFkODRmNWQwM2U1MTY3Y2Y2MSk7XHJcbkdyaWRfNDZlYmZhZDZkNTc5NGZiZDliZTMwZDM5MDAyY2MzMDUuQ2hpbGRyZW4uQWRkKEJ1dHRvbl9hZThmZGQ0ZGEzZjA0MTkzYjJhNGVlMWE4M2M3Y2U3MCk7XHJcbkdyaWRfNDZlYmZhZDZkNTc5NGZiZDliZTMwZDM5MDAyY2MzMDUuQ2hpbGRyZW4uQWRkKEJ1dHRvbl82ZmM1ZGRlNGQ0YWM0ODY4OGYwOWE2OTFhM2U2MjA4ZCk7XHJcbkdyaWRfNDZlYmZhZDZkNTc5NGZiZDliZTMwZDM5MDAyY2MzMDUuQ2hpbGRyZW4uQWRkKEJ1dHRvbl80NmMyMjVmNzY0YWM0MGZkOGNkZjllMjdhMjI3MzRlZCk7XHJcblxyXG5cclxuQm9yZGVyXzJmOGUxMjBmZjY5ZjQ4OWE5NzNkZTliNGRmM2E3MWY1LkNoaWxkID0gR3JpZF80NmViZmFkNmQ1Nzk0ZmJkOWJlMzBkMzkwMDJjYzMwNTtcclxuXHJcbnZhciBCaW5kaW5nXzJhNmE3NDdkNTQ2MjQyNmI5NGVjMTIyNzg4OWZjNGJmID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuQmluZGluZygpO1xyXG5CaW5kaW5nXzJhNmE3NDdkNTQ2MjQyNmI5NGVjMTIyNzg4OWZjNGJmLlBhdGggPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuUHJvcGVydHlQYXRoKEBcIlRpdGxlVmlzaWJpbGl0eVwiKTtcclxuXHJcblxyXG5cclxudmFyIEJvcmRlcl80Nzg2MzNmNjhmMmI0NmY5YTQ2YTYyN2RlOWMyNGI5OSA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Db250cm9scy5Cb3JkZXIoKTtcclxuZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuQ29udHJvbHMuR3JpZC5TZXRSb3coQm9yZGVyXzQ3ODYzM2Y2OGYyYjQ2ZjlhNDZhNjI3ZGU5YzI0Yjk5LDEpO1xyXG5Cb3JkZXJfNDc4NjMzZjY4ZjJiNDZmOWE0NmE2MjdkZTljMjRiOTkuQm9yZGVyVGhpY2tuZXNzID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlRoaWNrbmVzcygwLCAwLCAwLCAwKTtcclxudGVtcGxhdGVPd25lcl9Db250cm9sVGVtcGxhdGVfZmVlYzQ1OGUwNmE1NDg3OGE2OTEyNTk2OTU4M2NlMDMuUmVnaXN0ZXJOYW1lKFwiRm9ybUNvbnRlbnRQcmVzZW50ZXJcIiwgQ29udGVudFByZXNlbnRlcl8xNjgzZTUzYzBkODc0MWZiOWJlZDk4MjIwNzBmZWNiMyk7XHJcbkNvbnRlbnRQcmVzZW50ZXJfMTY4M2U1M2MwZDg3NDFmYjliZWQ5ODIyMDcwZmVjYjMuTmFtZSA9IFwiRm9ybUNvbnRlbnRQcmVzZW50ZXJcIjtcclxuQ29udGVudFByZXNlbnRlcl8xNjgzZTUzYzBkODc0MWZiOWJlZDk4MjIwNzBmZWNiMy5DbGlwVG9Cb3VuZHMgPSB0cnVlO1xyXG52YXIgQmluZGluZ181ODY2YTZlOGYxYzc0MmQ5YjRlYjQ1OWE0MTJhZGEyNCA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmcoKTtcclxuQmluZGluZ181ODY2YTZlOGYxYzc0MmQ5YjRlYjQ1OWE0MTJhZGEyNC5QYXRoID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlByb3BlcnR5UGF0aChAXCJDb250ZW50XCIpO1xyXG52YXIgUmVsYXRpdmVTb3VyY2VfNDcxZDE5ZDBhNzU0NDZkMDhlMDVmODM3ZDRiOGUwZjQgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5SZWxhdGl2ZVNvdXJjZSgpO1xyXG5SZWxhdGl2ZVNvdXJjZV80NzFkMTlkMGE3NTQ0NmQwOGUwNWY4MzdkNGI4ZTBmNC5Nb2RlID0gZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5SZWxhdGl2ZVNvdXJjZU1vZGUuVGVtcGxhdGVkUGFyZW50O1xyXG5cclxuQmluZGluZ181ODY2YTZlOGYxYzc0MmQ5YjRlYjQ1OWE0MTJhZGEyNC5SZWxhdGl2ZVNvdXJjZSA9IFJlbGF0aXZlU291cmNlXzQ3MWQxOWQwYTc1NDQ2ZDA4ZTA1ZjgzN2Q0YjhlMGY0O1xyXG5cclxuXHJcbkJpbmRpbmdfNTg2NmE2ZThmMWM3NDJkOWI0ZWI0NTlhNDEyYWRhMjQuVGVtcGxhdGVPd25lciA9IHRlbXBsYXRlSW5zdGFuY2VfNWU4ZmE3NTA5MThhNDc3MTk3ZjhlOTQxNDJjNDYzOGU7XHJcblxyXG52YXIgQmluZGluZ19kZjIwNjdjZDQ4YTA0ODJjYTJmNzg5YWVmNjdlMzRiMSA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmcoKTtcclxuQmluZGluZ19kZjIwNjdjZDQ4YTA0ODJjYTJmNzg5YWVmNjdlMzRiMS5QYXRoID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlByb3BlcnR5UGF0aChAXCJDb250ZW50VGVtcGxhdGVcIik7XHJcbnZhciBSZWxhdGl2ZVNvdXJjZV81OWEyMDk0YjcxMjY0NzRhOGZhYzA2MDFiMWJiMWMzYiA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLlJlbGF0aXZlU291cmNlKCk7XHJcblJlbGF0aXZlU291cmNlXzU5YTIwOTRiNzEyNjQ3NGE4ZmFjMDYwMWIxYmIxYzNiLk1vZGUgPSBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLlJlbGF0aXZlU291cmNlTW9kZS5UZW1wbGF0ZWRQYXJlbnQ7XHJcblxyXG5CaW5kaW5nX2RmMjA2N2NkNDhhMDQ4MmNhMmY3ODlhZWY2N2UzNGIxLlJlbGF0aXZlU291cmNlID0gUmVsYXRpdmVTb3VyY2VfNTlhMjA5NGI3MTI2NDc0YThmYWMwNjAxYjFiYjFjM2I7XHJcblxyXG5cclxuQmluZGluZ19kZjIwNjdjZDQ4YTA0ODJjYTJmNzg5YWVmNjdlMzRiMS5UZW1wbGF0ZU93bmVyID0gdGVtcGxhdGVJbnN0YW5jZV81ZThmYTc1MDkxOGE0NzcxOTdmOGU5NDE0MmM0NjM4ZTtcclxuXHJcbnZhciBCaW5kaW5nX2VmZmM2OWJiY2I5NjQ4NThiZTcxZWMwYzYyYjMwMTliID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuQmluZGluZygpO1xyXG5CaW5kaW5nX2VmZmM2OWJiY2I5NjQ4NThiZTcxZWMwYzYyYjMwMTliLlBhdGggPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuUHJvcGVydHlQYXRoKEBcIkNsaWVudFdpZHRoXCIpO1xyXG5cclxuXHJcbnZhciBCaW5kaW5nX2EzNTM4MDEyOWJlNDQ4NmY5OTRmMTkyZWYwNzZkODEzID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuQmluZGluZygpO1xyXG5CaW5kaW5nX2EzNTM4MDEyOWJlNDQ4NmY5OTRmMTkyZWYwNzZkODEzLlBhdGggPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuUHJvcGVydHlQYXRoKEBcIkNsaWVudEhlaWdodFwiKTtcclxuXHJcblxyXG52YXIgQmluZGluZ185MmEyNTdmOTFhMTk0ZjEzYjA3MjRiMTc1ZjcxODFlMiA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmcoKTtcclxuQmluZGluZ185MmEyNTdmOTFhMTk0ZjEzYjA3MjRiMTc1ZjcxODFlMi5QYXRoID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlByb3BlcnR5UGF0aChAXCJIb3Jpem9udGFsQWxpZ25tZW50XCIpO1xyXG52YXIgUmVsYXRpdmVTb3VyY2VfM2EzNmM0MzEzMjgxNGNhYmIyMGVmY2I4NDM1ZThkNmEgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5SZWxhdGl2ZVNvdXJjZSgpO1xyXG5SZWxhdGl2ZVNvdXJjZV8zYTM2YzQzMTMyODE0Y2FiYjIwZWZjYjg0MzVlOGQ2YS5Nb2RlID0gZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5SZWxhdGl2ZVNvdXJjZU1vZGUuVGVtcGxhdGVkUGFyZW50O1xyXG5cclxuQmluZGluZ185MmEyNTdmOTFhMTk0ZjEzYjA3MjRiMTc1ZjcxODFlMi5SZWxhdGl2ZVNvdXJjZSA9IFJlbGF0aXZlU291cmNlXzNhMzZjNDMxMzI4MTRjYWJiMjBlZmNiODQzNWU4ZDZhO1xyXG5cclxuXHJcbkJpbmRpbmdfOTJhMjU3ZjkxYTE5NGYxM2IwNzI0YjE3NWY3MTgxZTIuVGVtcGxhdGVPd25lciA9IHRlbXBsYXRlSW5zdGFuY2VfNWU4ZmE3NTA5MThhNDc3MTk3ZjhlOTQxNDJjNDYzOGU7XHJcblxyXG52YXIgQmluZGluZ184YzZmOGE4NjAyMGI0ZDg1YjVhYjY4MTVjNGI4ODhiNSA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmcoKTtcclxuQmluZGluZ184YzZmOGE4NjAyMGI0ZDg1YjVhYjY4MTVjNGI4ODhiNS5QYXRoID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlByb3BlcnR5UGF0aChAXCJWZXJ0aWNhbEFsaWdubWVudFwiKTtcclxudmFyIFJlbGF0aXZlU291cmNlXzg2ZWI0MWRmODlmMDRiMjQ4OGU4ZjJhOTkwYTdkYzg3ID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuUmVsYXRpdmVTb3VyY2UoKTtcclxuUmVsYXRpdmVTb3VyY2VfODZlYjQxZGY4OWYwNGIyNDg4ZThmMmE5OTBhN2RjODcuTW9kZSA9IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuUmVsYXRpdmVTb3VyY2VNb2RlLlRlbXBsYXRlZFBhcmVudDtcclxuXHJcbkJpbmRpbmdfOGM2ZjhhODYwMjBiNGQ4NWI1YWI2ODE1YzRiODg4YjUuUmVsYXRpdmVTb3VyY2UgPSBSZWxhdGl2ZVNvdXJjZV84NmViNDFkZjg5ZjA0YjI0ODhlOGYyYTk5MGE3ZGM4NztcclxuXHJcblxyXG5CaW5kaW5nXzhjNmY4YTg2MDIwYjRkODViNWFiNjgxNWM0Yjg4OGI1LlRlbXBsYXRlT3duZXIgPSB0ZW1wbGF0ZUluc3RhbmNlXzVlOGZhNzUwOTE4YTQ3NzE5N2Y4ZTk0MTQyYzQ2MzhlO1xyXG5cclxuXHJcbkJvcmRlcl80Nzg2MzNmNjhmMmI0NmY5YTQ2YTYyN2RlOWMyNGI5OS5DaGlsZCA9IENvbnRlbnRQcmVzZW50ZXJfMTY4M2U1M2MwZDg3NDFmYjliZWQ5ODIyMDcwZmVjYjM7XHJcblxyXG52YXIgQmluZGluZ185MzJhNDM1OTRlMWM0ZjE3YjcwMzcxNzA1NTk2ZGRjYiA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmcoKTtcclxuQmluZGluZ185MzJhNDM1OTRlMWM0ZjE3YjcwMzcxNzA1NTk2ZGRjYi5QYXRoID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlByb3BlcnR5UGF0aChAXCJDbGllbnRIZWlnaHRcIik7XHJcblxyXG5cclxudmFyIEJpbmRpbmdfMTRkOTkwNDlmOWIzNDE4ZThmMGUyZjAyOGZhOTg1N2EgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5CaW5kaW5nKCk7XHJcbkJpbmRpbmdfMTRkOTkwNDlmOWIzNDE4ZThmMGUyZjAyOGZhOTg1N2EuUGF0aCA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Qcm9wZXJ0eVBhdGgoQFwiQ2xpZW50V2lkdGhcIik7XHJcblxyXG5cclxudmFyIEJpbmRpbmdfYmYwNTRkODVkNDU4NDhkMGIyNzc4M2JlZWNmZWM2OTMgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5CaW5kaW5nKCk7XHJcbkJpbmRpbmdfYmYwNTRkODVkNDU4NDhkMGIyNzc4M2JlZWNmZWM2OTMuUGF0aCA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Qcm9wZXJ0eVBhdGgoQFwiQmFja2dyb3VuZFwiKTtcclxudmFyIFJlbGF0aXZlU291cmNlX2M3ZDMyYWI1ODUwZDQxNTFhOWQ0ZjRlMmNkYThmM2M4ID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuUmVsYXRpdmVTb3VyY2UoKTtcclxuUmVsYXRpdmVTb3VyY2VfYzdkMzJhYjU4NTBkNDE1MWE5ZDRmNGUyY2RhOGYzYzguTW9kZSA9IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuUmVsYXRpdmVTb3VyY2VNb2RlLlRlbXBsYXRlZFBhcmVudDtcclxuXHJcbkJpbmRpbmdfYmYwNTRkODVkNDU4NDhkMGIyNzc4M2JlZWNmZWM2OTMuUmVsYXRpdmVTb3VyY2UgPSBSZWxhdGl2ZVNvdXJjZV9jN2QzMmFiNTg1MGQ0MTUxYTlkNGY0ZTJjZGE4ZjNjODtcclxuXHJcblxyXG5CaW5kaW5nX2JmMDU0ZDg1ZDQ1ODQ4ZDBiMjc3ODNiZWVjZmVjNjkzLlRlbXBsYXRlT3duZXIgPSB0ZW1wbGF0ZUluc3RhbmNlXzVlOGZhNzUwOTE4YTQ3NzE5N2Y4ZTk0MTQyYzQ2MzhlO1xyXG5cclxudmFyIEJpbmRpbmdfMTE0MmNjNDQ5ZDEzNGEyNWE5OGY3ZGI3MzUxNDU2MDAgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5CaW5kaW5nKCk7XHJcbkJpbmRpbmdfMTE0MmNjNDQ5ZDEzNGEyNWE5OGY3ZGI3MzUxNDU2MDAuUGF0aCA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Qcm9wZXJ0eVBhdGgoQFwiQmFja2dyb3VuZFwiKTtcclxudmFyIFJlbGF0aXZlU291cmNlXzIyYzVmNWU1ZGVlYjQwNjc4YmQ3YzE3M2IwZjliNmRiID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuUmVsYXRpdmVTb3VyY2UoKTtcclxuUmVsYXRpdmVTb3VyY2VfMjJjNWY1ZTVkZWViNDA2NzhiZDdjMTczYjBmOWI2ZGIuTW9kZSA9IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuUmVsYXRpdmVTb3VyY2VNb2RlLlRlbXBsYXRlZFBhcmVudDtcclxuXHJcbkJpbmRpbmdfMTE0MmNjNDQ5ZDEzNGEyNWE5OGY3ZGI3MzUxNDU2MDAuUmVsYXRpdmVTb3VyY2UgPSBSZWxhdGl2ZVNvdXJjZV8yMmM1ZjVlNWRlZWI0MDY3OGJkN2MxNzNiMGY5YjZkYjtcclxuXHJcblxyXG5CaW5kaW5nXzExNDJjYzQ0OWQxMzRhMjVhOThmN2RiNzM1MTQ1NjAwLlRlbXBsYXRlT3duZXIgPSB0ZW1wbGF0ZUluc3RhbmNlXzVlOGZhNzUwOTE4YTQ3NzE5N2Y4ZTk0MTQyYzQ2MzhlO1xyXG5cclxuXHJcbkdyaWRfYmU1NTM0NmM1ZTc1NGU2Y2IzNjJmMWE5NjNmNTkzMzguQ2hpbGRyZW4uQWRkKEJvcmRlcl8yZjhlMTIwZmY2OWY0ODlhOTczZGU5YjRkZjNhNzFmNSk7XHJcbkdyaWRfYmU1NTM0NmM1ZTc1NGU2Y2IzNjJmMWE5NjNmNTkzMzguQ2hpbGRyZW4uQWRkKEJvcmRlcl80Nzg2MzNmNjhmMmI0NmY5YTQ2YTYyN2RlOWMyNGI5OSk7XHJcblxyXG5cclxuQm9yZGVyX2JiZmMzNmZkOTNkZjRjZjRiNDE0NjVhMTJmM2YxZDA4LkNoaWxkID0gR3JpZF9iZTU1MzQ2YzVlNzU0ZTZjYjM2MmYxYTk2M2Y1OTMzODtcclxuXHJcbnZhciBCaW5kaW5nXzkxOTg0NDliMGY1YTQ5NDVhMGM0ODMzNmIzYmRhZjc5ID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuQmluZGluZygpO1xyXG5CaW5kaW5nXzkxOTg0NDliMGY1YTQ5NDVhMGM0ODMzNmIzYmRhZjc5LlBhdGggPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuUHJvcGVydHlQYXRoKEBcIkJvcmRlclRoaWNrbmVzc1wiKTtcclxudmFyIFJlbGF0aXZlU291cmNlXzE5N2Q0YTMwNmNjMTQ2NGFhNzRjZDkxNjQ2M2M2NzllID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuUmVsYXRpdmVTb3VyY2UoKTtcclxuUmVsYXRpdmVTb3VyY2VfMTk3ZDRhMzA2Y2MxNDY0YWE3NGNkOTE2NDYzYzY3OWUuTW9kZSA9IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuUmVsYXRpdmVTb3VyY2VNb2RlLlRlbXBsYXRlZFBhcmVudDtcclxuXHJcbkJpbmRpbmdfOTE5ODQ0OWIwZjVhNDk0NWEwYzQ4MzM2YjNiZGFmNzkuUmVsYXRpdmVTb3VyY2UgPSBSZWxhdGl2ZVNvdXJjZV8xOTdkNGEzMDZjYzE0NjRhYTc0Y2Q5MTY0NjNjNjc5ZTtcclxuXHJcblxyXG5CaW5kaW5nXzkxOTg0NDliMGY1YTQ5NDVhMGM0ODMzNmIzYmRhZjc5LlRlbXBsYXRlT3duZXIgPSB0ZW1wbGF0ZUluc3RhbmNlXzVlOGZhNzUwOTE4YTQ3NzE5N2Y4ZTk0MTQyYzQ2MzhlO1xyXG5cclxudmFyIEJpbmRpbmdfMzNjZGVlYzc0MTc5NGI2OWIxNzg1MGFjMjgyYWEwZDkgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5CaW5kaW5nKCk7XHJcbkJpbmRpbmdfMzNjZGVlYzc0MTc5NGI2OWIxNzg1MGFjMjgyYWEwZDkuUGF0aCA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Qcm9wZXJ0eVBhdGgoQFwiQm9yZGVyQnJ1c2hcIik7XHJcbnZhciBSZWxhdGl2ZVNvdXJjZV83YzBiZGI1NmRjNzk0NzVlODRjMjJkMWY1ZjdlMzQxMyA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLlJlbGF0aXZlU291cmNlKCk7XHJcblJlbGF0aXZlU291cmNlXzdjMGJkYjU2ZGM3OTQ3NWU4NGMyMmQxZjVmN2UzNDEzLk1vZGUgPSBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLlJlbGF0aXZlU291cmNlTW9kZS5UZW1wbGF0ZWRQYXJlbnQ7XHJcblxyXG5CaW5kaW5nXzMzY2RlZWM3NDE3OTRiNjliMTc4NTBhYzI4MmFhMGQ5LlJlbGF0aXZlU291cmNlID0gUmVsYXRpdmVTb3VyY2VfN2MwYmRiNTZkYzc5NDc1ZTg0YzIyZDFmNWY3ZTM0MTM7XHJcblxyXG5cclxuQmluZGluZ18zM2NkZWVjNzQxNzk0YjY5YjE3ODUwYWMyODJhYTBkOS5UZW1wbGF0ZU93bmVyID0gdGVtcGxhdGVJbnN0YW5jZV81ZThmYTc1MDkxOGE0NzcxOTdmOGU5NDE0MmM0NjM4ZTtcclxuXHJcblxyXG5Cb3JkZXJfZTllNjM1Mzk3YzE5NDI4MjgxMWMyZjEwYmI1YmUyNDEuQ2hpbGQgPSBCb3JkZXJfYmJmYzM2ZmQ5M2RmNGNmNGI0MTQ2NWExMmYzZjFkMDg7XHJcblxyXG5cclxuR3JpZF80MWM4NGQwYTcxMDE0ODIxOTA3NzRhY2FjNDMxYTBjZC5DaGlsZHJlbi5BZGQoR3JpZF81NWVlZjliNmM0MWM0NzdmYmFlY2I0MTgzYTdjNzgzZik7XHJcbkdyaWRfNDFjODRkMGE3MTAxNDgyMTkwNzc0YWNhYzQzMWEwY2QuQ2hpbGRyZW4uQWRkKEJvcmRlcl9lOWU2MzUzOTdjMTk0MjgyODExYzJmMTBiYjViZTI0MSk7XHJcblxyXG52YXIgQmluZGluZ182YWNkZDJkZjY4OTc0NWEwOWRkYjM1M2IwNTdmZmQxZCA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmcoKTtcclxuQmluZGluZ182YWNkZDJkZjY4OTc0NWEwOWRkYjM1M2IwNTdmZmQxZC5QYXRoID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlByb3BlcnR5UGF0aChAXCJIZWlnaHRcIik7XHJcbnZhciBSZWxhdGl2ZVNvdXJjZV8zMWIzZjhjNDcyOWE0ZTNlOTc1YjA2ZGRlMzNjOGQyNSA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLlJlbGF0aXZlU291cmNlKCk7XHJcblJlbGF0aXZlU291cmNlXzMxYjNmOGM0NzI5YTRlM2U5NzViMDZkZGUzM2M4ZDI1Lk1vZGUgPSBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLlJlbGF0aXZlU291cmNlTW9kZS5UZW1wbGF0ZWRQYXJlbnQ7XHJcblxyXG5CaW5kaW5nXzZhY2RkMmRmNjg5NzQ1YTA5ZGRiMzUzYjA1N2ZmZDFkLlJlbGF0aXZlU291cmNlID0gUmVsYXRpdmVTb3VyY2VfMzFiM2Y4YzQ3MjlhNGUzZTk3NWIwNmRkZTMzYzhkMjU7XHJcblxyXG5cclxuQmluZGluZ182YWNkZDJkZjY4OTc0NWEwOWRkYjM1M2IwNTdmZmQxZC5UZW1wbGF0ZU93bmVyID0gdGVtcGxhdGVJbnN0YW5jZV81ZThmYTc1MDkxOGE0NzcxOTdmOGU5NDE0MmM0NjM4ZTtcclxuXHJcbnZhciBCaW5kaW5nXzE4ZTBlNGFiYzdlMzRhOThhMTdjM2UyNjBhYjI3YzIxID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuQmluZGluZygpO1xyXG5CaW5kaW5nXzE4ZTBlNGFiYzdlMzRhOThhMTdjM2UyNjBhYjI3YzIxLlBhdGggPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuUHJvcGVydHlQYXRoKEBcIldpZHRoXCIpO1xyXG52YXIgUmVsYXRpdmVTb3VyY2VfYjMwZmJhMGEwZDBkNDEzNDgwMDIxNGU5ZTMxYWFhMWEgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5SZWxhdGl2ZVNvdXJjZSgpO1xyXG5SZWxhdGl2ZVNvdXJjZV9iMzBmYmEwYTBkMGQ0MTM0ODAwMjE0ZTllMzFhYWExYS5Nb2RlID0gZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5SZWxhdGl2ZVNvdXJjZU1vZGUuVGVtcGxhdGVkUGFyZW50O1xyXG5cclxuQmluZGluZ18xOGUwZTRhYmM3ZTM0YTk4YTE3YzNlMjYwYWIyN2MyMS5SZWxhdGl2ZVNvdXJjZSA9IFJlbGF0aXZlU291cmNlX2IzMGZiYTBhMGQwZDQxMzQ4MDAyMTRlOWUzMWFhYTFhO1xyXG5cclxuXHJcbkJpbmRpbmdfMThlMGU0YWJjN2UzNGE5OGExN2MzZTI2MGFiMjdjMjEuVGVtcGxhdGVPd25lciA9IHRlbXBsYXRlSW5zdGFuY2VfNWU4ZmE3NTA5MThhNDc3MTk3ZjhlOTQxNDJjNDYzOGU7XHJcblxyXG52YXIgQmluZGluZ183NmYyNzJlMGNhYzM0NjI2ODM5YzA3NTBjZjEwODBlNiA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmcoKTtcclxuQmluZGluZ183NmYyNzJlMGNhYzM0NjI2ODM5YzA3NTBjZjEwODBlNi5QYXRoID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlByb3BlcnR5UGF0aChAXCJIb3Jpem9udGFsQWxpZ25tZW50XCIpO1xyXG52YXIgUmVsYXRpdmVTb3VyY2VfNWUzZjIwZDg3MmViNDY0MGIzOGU2NTEyOTdjZTI5MGUgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5SZWxhdGl2ZVNvdXJjZSgpO1xyXG5SZWxhdGl2ZVNvdXJjZV81ZTNmMjBkODcyZWI0NjQwYjM4ZTY1MTI5N2NlMjkwZS5Nb2RlID0gZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5SZWxhdGl2ZVNvdXJjZU1vZGUuVGVtcGxhdGVkUGFyZW50O1xyXG5cclxuQmluZGluZ183NmYyNzJlMGNhYzM0NjI2ODM5YzA3NTBjZjEwODBlNi5SZWxhdGl2ZVNvdXJjZSA9IFJlbGF0aXZlU291cmNlXzVlM2YyMGQ4NzJlYjQ2NDBiMzhlNjUxMjk3Y2UyOTBlO1xyXG5cclxuXHJcbkJpbmRpbmdfNzZmMjcyZTBjYWMzNDYyNjgzOWMwNzUwY2YxMDgwZTYuVGVtcGxhdGVPd25lciA9IHRlbXBsYXRlSW5zdGFuY2VfNWU4ZmE3NTA5MThhNDc3MTk3ZjhlOTQxNDJjNDYzOGU7XHJcblxyXG52YXIgQmluZGluZ18wMjQ3NDExNjUyNGE0YTExYmYzNThlMjg2ZTAyMDViZCA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmcoKTtcclxuQmluZGluZ18wMjQ3NDExNjUyNGE0YTExYmYzNThlMjg2ZTAyMDViZC5QYXRoID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlByb3BlcnR5UGF0aChAXCJWZXJ0aWNhbEFsaWdubWVudFwiKTtcclxudmFyIFJlbGF0aXZlU291cmNlX2U0Yzk5ZWY2NGE4NjQ2ODZiOWQ4NzYwNWM1Njk4MGU1ID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuUmVsYXRpdmVTb3VyY2UoKTtcclxuUmVsYXRpdmVTb3VyY2VfZTRjOTllZjY0YTg2NDY4NmI5ZDg3NjA1YzU2OTgwZTUuTW9kZSA9IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuUmVsYXRpdmVTb3VyY2VNb2RlLlRlbXBsYXRlZFBhcmVudDtcclxuXHJcbkJpbmRpbmdfMDI0NzQxMTY1MjRhNGExMWJmMzU4ZTI4NmUwMjA1YmQuUmVsYXRpdmVTb3VyY2UgPSBSZWxhdGl2ZVNvdXJjZV9lNGM5OWVmNjRhODY0Njg2YjlkODc2MDVjNTY5ODBlNTtcclxuXHJcblxyXG5CaW5kaW5nXzAyNDc0MTE2NTI0YTRhMTFiZjM1OGUyODZlMDIwNWJkLlRlbXBsYXRlT3duZXIgPSB0ZW1wbGF0ZUluc3RhbmNlXzVlOGZhNzUwOTE4YTQ3NzE5N2Y4ZTk0MTQyYzQ2MzhlO1xyXG5cclxuXHJcbmdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuQmluZGluZ09wZXJhdGlvbnMuU2V0QmluZGluZyhHcmlkXzU1ZWVmOWI2YzQxYzQ3N2ZiYWVjYjQxODNhN2M3ODNmLCBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Db250cm9scy5QYW5lbC5CYWNrZ3JvdW5kUHJvcGVydHksIEJpbmRpbmdfOTA4YjAxY2ZkZTEwNDRhZWJiNTZjMGE4M2EyMzEzNmMpO1xyXG5nbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmdPcGVyYXRpb25zLlNldEJpbmRpbmcoR3JpZF81NWVlZjliNmM0MWM0NzdmYmFlY2I0MTgzYTdjNzgzZiwgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuVUlFbGVtZW50Lk9wYWNpdHlQcm9wZXJ0eSwgQmluZGluZ19hODQ4OWExZWRkYjE0YjIzOWVhYTRlNjc2ZjYzMWQzMyk7XHJcbmdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuQmluZGluZ09wZXJhdGlvbnMuU2V0QmluZGluZyhJbWFnZV8zMDY1MWMzYTEyYzk0YzllYjMzMzRlNzNmMzE0MzllYSwgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuQ29udHJvbHMuSW1hZ2UuU291cmNlUHJvcGVydHksIEJpbmRpbmdfNTg2YzI3NDVjN2IzNGQ4NWIzOGRiOGJkY2E2MTliZDIpO1xyXG5nbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmdPcGVyYXRpb25zLlNldEJpbmRpbmcoQnV0dG9uX2MxYWU1ODdjNmRiNzQ1ZmQ5MTcwNzMwYTEzYTA0NTVhLCBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5VSUVsZW1lbnQuVmlzaWJpbGl0eVByb3BlcnR5LCBCaW5kaW5nXzA0MGFjNWE4NTNlYzRmMmZhZmZlNDA1YTA0ZDMyYTA2KTtcclxuZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5CaW5kaW5nT3BlcmF0aW9ucy5TZXRCaW5kaW5nKENvbnRlbnRDb250cm9sXzA1NWE1MmJkZjBmOTQxNTE4M2NhMDAwOGMyMzhlYTc0LCBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Db250cm9scy5Db250ZW50Q29udHJvbC5Db250ZW50UHJvcGVydHksIEJpbmRpbmdfZjkzYjhhYzZmNWU2NGQwY2JlM2ZjM2U3NWM2ZjUyMDUpO1xyXG5nbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmdPcGVyYXRpb25zLlNldEJpbmRpbmcoSW1hZ2VfNmI4N2UwMjhmNGVmNDRhMzgxYWIyY2U4NDdmMjIzM2IsIGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkNvbnRyb2xzLkltYWdlLlNvdXJjZVByb3BlcnR5LCBCaW5kaW5nXzRkZjI4YTAyNGJiMTQ1NjFhZWIyYjRkM2M3YjBiYTgwKTtcclxuZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5CaW5kaW5nT3BlcmF0aW9ucy5TZXRCaW5kaW5nKEJ1dHRvbl9hZDI2YTY3ZGFiZTM0NmRhOWQ4M2MxOTFkMmQ1YjlkMiwgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuVUlFbGVtZW50LlZpc2liaWxpdHlQcm9wZXJ0eSwgQmluZGluZ18yZTkxNmQzMjcyYTg0ZjNiYjIyOTJkZDk3NDk3NWMwZSk7XHJcbmdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuQmluZGluZ09wZXJhdGlvbnMuU2V0QmluZGluZyhJbWFnZV9kYmFkNjMwMjQ0NmQ0MjQ2ODE3YTk0OGUzZDM3YzE5NSwgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuQ29udHJvbHMuSW1hZ2UuU291cmNlUHJvcGVydHksIEJpbmRpbmdfOGZiZmVlODJlZjhmNDI1OWExNjQwMjJkMWZhODExZmIpO1xyXG5nbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmdPcGVyYXRpb25zLlNldEJpbmRpbmcoQnV0dG9uXzM1MjkxNTliNWRiNjQ5YWQ4NGY1ZDAzZTUxNjdjZjYxLCBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5VSUVsZW1lbnQuVmlzaWJpbGl0eVByb3BlcnR5LCBCaW5kaW5nX2YyYWFhYTQ0OGZmZDRjYzVhMzU2M2ZhZmI4ZWExMDk3KTtcclxuZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5CaW5kaW5nT3BlcmF0aW9ucy5TZXRCaW5kaW5nKEltYWdlXzM1MjQ5MWI3NDFjOTQ3MTJhNzVkNmNkMGY2ODQxMzhjLCBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Db250cm9scy5JbWFnZS5Tb3VyY2VQcm9wZXJ0eSwgQmluZGluZ19hYmFlMzI5ZTRiOTM0NWM1OGE2N2NhNGMxOTViMDQ2NSk7XHJcbmdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuQmluZGluZ09wZXJhdGlvbnMuU2V0QmluZGluZyhCdXR0b25fYWU4ZmRkNGRhM2YwNDE5M2IyYTRlZTFhODNjN2NlNzAsIGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlVJRWxlbWVudC5WaXNpYmlsaXR5UHJvcGVydHksIEJpbmRpbmdfZjhlODZmODcxMWMzNDBiMGI1MGRkZjBkMjBlYWM1MzkpO1xyXG5nbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmdPcGVyYXRpb25zLlNldEJpbmRpbmcoSW1hZ2VfODhlMTg5MmI5NDAwNGNmM2I3OWNmMjRkOTg0ZDgwOTYsIGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkNvbnRyb2xzLkltYWdlLlNvdXJjZVByb3BlcnR5LCBCaW5kaW5nX2VjZTY2YzA1ZjAzZDQxN2Q5Y2Y4MWY4NDM0OWY2YWQ3KTtcclxuZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5CaW5kaW5nT3BlcmF0aW9ucy5TZXRCaW5kaW5nKEJ1dHRvbl82ZmM1ZGRlNGQ0YWM0ODY4OGYwOWE2OTFhM2U2MjA4ZCwgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuVUlFbGVtZW50LlZpc2liaWxpdHlQcm9wZXJ0eSwgQmluZGluZ184ZDk3YTU0N2EzYTU0Njc4YWM5ZjM4NmFhNjA5ODI5YSk7XHJcbmdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuQmluZGluZ09wZXJhdGlvbnMuU2V0QmluZGluZyhJbWFnZV80ZjhkOTNhODUwOTE0MGU2YmQxOThiODdiZmU3YzkzNywgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuQ29udHJvbHMuSW1hZ2UuU291cmNlUHJvcGVydHksIEJpbmRpbmdfYWRjYzA0NWYwMjkzNDkzN2JmYjU5MzljYzhlNjNjNDcpO1xyXG5nbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmdPcGVyYXRpb25zLlNldEJpbmRpbmcoQnV0dG9uXzQ2YzIyNWY3NjRhYzQwZmQ4Y2RmOWUyN2EyMjczNGVkLCBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5VSUVsZW1lbnQuVmlzaWJpbGl0eVByb3BlcnR5LCBCaW5kaW5nXzIzNGU2NDRiOGY5MTRlOTFhNTVhODYwMDg1NDBiZjVlKTtcclxuZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5CaW5kaW5nT3BlcmF0aW9ucy5TZXRCaW5kaW5nKEJvcmRlcl8yZjhlMTIwZmY2OWY0ODlhOTczZGU5YjRkZjNhNzFmNSwgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuVUlFbGVtZW50LlZpc2liaWxpdHlQcm9wZXJ0eSwgQmluZGluZ18yYTZhNzQ3ZDU0NjI0MjZiOTRlYzEyMjc4ODlmYzRiZik7XHJcbmdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuQmluZGluZ09wZXJhdGlvbnMuU2V0QmluZGluZyhDb250ZW50UHJlc2VudGVyXzE2ODNlNTNjMGQ4NzQxZmI5YmVkOTgyMjA3MGZlY2IzLCBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Db250cm9scy5Db250ZW50Q29udHJvbC5Db250ZW50UHJvcGVydHksIEJpbmRpbmdfNTg2NmE2ZThmMWM3NDJkOWI0ZWI0NTlhNDEyYWRhMjQpO1xyXG5nbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmdPcGVyYXRpb25zLlNldEJpbmRpbmcoQ29udGVudFByZXNlbnRlcl8xNjgzZTUzYzBkODc0MWZiOWJlZDk4MjIwNzBmZWNiMywgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuQ29udHJvbHMuQ29udGVudENvbnRyb2wuQ29udGVudFRlbXBsYXRlUHJvcGVydHksIEJpbmRpbmdfZGYyMDY3Y2Q0OGEwNDgyY2EyZjc4OWFlZjY3ZTM0YjEpO1xyXG5nbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmdPcGVyYXRpb25zLlNldEJpbmRpbmcoQ29udGVudFByZXNlbnRlcl8xNjgzZTUzYzBkODc0MWZiOWJlZDk4MjIwNzBmZWNiMywgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRnJhbWV3b3JrRWxlbWVudC5XaWR0aFByb3BlcnR5LCBCaW5kaW5nX2VmZmM2OWJiY2I5NjQ4NThiZTcxZWMwYzYyYjMwMTliKTtcclxuZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5CaW5kaW5nT3BlcmF0aW9ucy5TZXRCaW5kaW5nKENvbnRlbnRQcmVzZW50ZXJfMTY4M2U1M2MwZDg3NDFmYjliZWQ5ODIyMDcwZmVjYjMsIGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkZyYW1ld29ya0VsZW1lbnQuSGVpZ2h0UHJvcGVydHksIEJpbmRpbmdfYTM1MzgwMTI5YmU0NDg2Zjk5NGYxOTJlZjA3NmQ4MTMpO1xyXG5nbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmdPcGVyYXRpb25zLlNldEJpbmRpbmcoQ29udGVudFByZXNlbnRlcl8xNjgzZTUzYzBkODc0MWZiOWJlZDk4MjIwNzBmZWNiMywgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRnJhbWV3b3JrRWxlbWVudC5Ib3Jpem9udGFsQWxpZ25tZW50UHJvcGVydHksIEJpbmRpbmdfOTJhMjU3ZjkxYTE5NGYxM2IwNzI0YjE3NWY3MTgxZTIpO1xyXG5nbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmdPcGVyYXRpb25zLlNldEJpbmRpbmcoQ29udGVudFByZXNlbnRlcl8xNjgzZTUzYzBkODc0MWZiOWJlZDk4MjIwNzBmZWNiMywgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRnJhbWV3b3JrRWxlbWVudC5WZXJ0aWNhbEFsaWdubWVudFByb3BlcnR5LCBCaW5kaW5nXzhjNmY4YTg2MDIwYjRkODViNWFiNjgxNWM0Yjg4OGI1KTtcclxuZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5CaW5kaW5nT3BlcmF0aW9ucy5TZXRCaW5kaW5nKEJvcmRlcl80Nzg2MzNmNjhmMmI0NmY5YTQ2YTYyN2RlOWMyNGI5OSwgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRnJhbWV3b3JrRWxlbWVudC5IZWlnaHRQcm9wZXJ0eSwgQmluZGluZ185MzJhNDM1OTRlMWM0ZjE3YjcwMzcxNzA1NTk2ZGRjYik7XHJcbmdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuQmluZGluZ09wZXJhdGlvbnMuU2V0QmluZGluZyhCb3JkZXJfNDc4NjMzZjY4ZjJiNDZmOWE0NmE2MjdkZTljMjRiOTksIGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkZyYW1ld29ya0VsZW1lbnQuV2lkdGhQcm9wZXJ0eSwgQmluZGluZ18xNGQ5OTA0OWY5YjM0MThlOGYwZTJmMDI4ZmE5ODU3YSk7XHJcbmdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuQmluZGluZ09wZXJhdGlvbnMuU2V0QmluZGluZyhCb3JkZXJfNDc4NjMzZjY4ZjJiNDZmOWE0NmE2MjdkZTljMjRiOTksIGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkNvbnRyb2xzLkJvcmRlci5CYWNrZ3JvdW5kUHJvcGVydHksIEJpbmRpbmdfYmYwNTRkODVkNDU4NDhkMGIyNzc4M2JlZWNmZWM2OTMpO1xyXG5nbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmdPcGVyYXRpb25zLlNldEJpbmRpbmcoQm9yZGVyXzQ3ODYzM2Y2OGYyYjQ2ZjlhNDZhNjI3ZGU5YzI0Yjk5LCBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Db250cm9scy5Cb3JkZXIuQm9yZGVyQnJ1c2hQcm9wZXJ0eSwgQmluZGluZ18xMTQyY2M0NDlkMTM0YTI1YTk4ZjdkYjczNTE0NTYwMCk7XHJcbmdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuQmluZGluZ09wZXJhdGlvbnMuU2V0QmluZGluZyhCb3JkZXJfYmJmYzM2ZmQ5M2RmNGNmNGI0MTQ2NWExMmYzZjFkMDgsIGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkNvbnRyb2xzLkJvcmRlci5Cb3JkZXJUaGlja25lc3NQcm9wZXJ0eSwgQmluZGluZ185MTk4NDQ5YjBmNWE0OTQ1YTBjNDgzMzZiM2JkYWY3OSk7XHJcbmdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuQmluZGluZ09wZXJhdGlvbnMuU2V0QmluZGluZyhCb3JkZXJfYmJmYzM2ZmQ5M2RmNGNmNGI0MTQ2NWExMmYzZjFkMDgsIGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkNvbnRyb2xzLkJvcmRlci5Cb3JkZXJCcnVzaFByb3BlcnR5LCBCaW5kaW5nXzMzY2RlZWM3NDE3OTRiNjliMTc4NTBhYzI4MmFhMGQ5KTtcclxuZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5CaW5kaW5nT3BlcmF0aW9ucy5TZXRCaW5kaW5nKEdyaWRfNDFjODRkMGE3MTAxNDgyMTkwNzc0YWNhYzQzMWEwY2QsIGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkZyYW1ld29ya0VsZW1lbnQuSGVpZ2h0UHJvcGVydHksIEJpbmRpbmdfNmFjZGQyZGY2ODk3NDVhMDlkZGIzNTNiMDU3ZmZkMWQpO1xyXG5nbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmdPcGVyYXRpb25zLlNldEJpbmRpbmcoR3JpZF80MWM4NGQwYTcxMDE0ODIxOTA3NzRhY2FjNDMxYTBjZCwgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRnJhbWV3b3JrRWxlbWVudC5XaWR0aFByb3BlcnR5LCBCaW5kaW5nXzE4ZTBlNGFiYzdlMzRhOThhMTdjM2UyNjBhYjI3YzIxKTtcclxuZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5CaW5kaW5nT3BlcmF0aW9ucy5TZXRCaW5kaW5nKEdyaWRfNDFjODRkMGE3MTAxNDgyMTkwNzc0YWNhYzQzMWEwY2QsIGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkZyYW1ld29ya0VsZW1lbnQuSG9yaXpvbnRhbEFsaWdubWVudFByb3BlcnR5LCBCaW5kaW5nXzc2ZjI3MmUwY2FjMzQ2MjY4MzljMDc1MGNmMTA4MGU2KTtcclxuZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5CaW5kaW5nT3BlcmF0aW9ucy5TZXRCaW5kaW5nKEdyaWRfNDFjODRkMGE3MTAxNDgyMTkwNzc0YWNhYzQzMWEwY2QsIGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkZyYW1ld29ya0VsZW1lbnQuVmVydGljYWxBbGlnbm1lbnRQcm9wZXJ0eSwgQmluZGluZ18wMjQ3NDExNjUyNGE0YTExYmYzNThlMjg2ZTAyMDViZCk7XHJcblxyXG5nbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5NZWRpYS5BbmltYXRpb24uU3Rvcnlib2FyZC5TZXRUYXJnZXRQcm9wZXJ0eShPYmplY3RBbmltYXRpb25Vc2luZ0tleUZyYW1lc19kZmNmMDY1YzJmY2U0ODJkYTZiYjlhNDg5NzBhZGVhNSxcclxuICAgIG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Qcm9wZXJ0eVBhdGgoXHJcbiAgICAgICAgXCJCYWNrZ3JvdW5kXCIsXHJcbiAgICAgICAgXCJCYWNrZ3JvdW5kXCIsXHJcbiAgICAgICAgYWNjZXNzVmlzdWFsU3RhdGVQcm9wZXJ0eV8xMDJiNzBkNmY5MWI0NTAzYWMyMTg5ZDIyOTZiYWE2MSxcclxuICAgICAgICBzZXRWaXN1YWxTdGF0ZVByb3BlcnR5XzEwMmI3MGQ2ZjkxYjQ1MDNhYzIxODlkMjI5NmJhYTYxLFxyXG4gICAgICAgIHNldEFuaW1hdGlvblZpc3VhbFN0YXRlUHJvcGVydHlfMTAyYjcwZDZmOTFiNDUwM2FjMjE4OWQyMjk2YmFhNjEsICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgIHNldExvY2FsVmlzdWFsU3RhdGVQcm9wZXJ0eV8xMDJiNzBkNmY5MWI0NTAzYWMyMTg5ZDIyOTZiYWE2MSxcclxuICAgICAgICBnZXRWaXN1YWxTdGF0ZVByb3BlcnR5XzEwMmI3MGQ2ZjkxYjQ1MDNhYzIxODlkMjI5NmJhYTYxKSk7XHJcbmdsb2JhbDo6V2luZG93cy5VSS5YYW1sLk1lZGlhLkFuaW1hdGlvbi5TdG9yeWJvYXJkLlNldFRhcmdldChPYmplY3RBbmltYXRpb25Vc2luZ0tleUZyYW1lc19kZmNmMDY1YzJmY2U0ODJkYTZiYjlhNDg5NzBhZGVhNSwgR3JpZF81NWVlZjliNmM0MWM0NzdmYmFlY2I0MTgzYTdjNzgzZik7XHJcblxyXG5cclxuZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuTWVkaWEuQW5pbWF0aW9uLlN0b3J5Ym9hcmQuU2V0VGFyZ2V0UHJvcGVydHkoT2JqZWN0QW5pbWF0aW9uVXNpbmdLZXlGcmFtZXNfYWZkOTU0MDBjZjllNDhmNjljNjk5ZmY2NTJkNDEzNzQsXHJcbiAgICBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuUHJvcGVydHlQYXRoKFxyXG4gICAgICAgIFwiSXNIaXRUZXN0VmlzaWJsZVwiLFxyXG4gICAgICAgIFwiSXNIaXRUZXN0VmlzaWJsZVwiLFxyXG4gICAgICAgIGFjY2Vzc1Zpc3VhbFN0YXRlUHJvcGVydHlfYWVkY2I4ZjVlNzkyNDMxYzhmMzQ2OTFhZmNjNGI2MmMsXHJcbiAgICAgICAgc2V0VmlzdWFsU3RhdGVQcm9wZXJ0eV9hZWRjYjhmNWU3OTI0MzFjOGYzNDY5MWFmY2M0YjYyYyxcclxuICAgICAgICBzZXRBbmltYXRpb25WaXN1YWxTdGF0ZVByb3BlcnR5X2FlZGNiOGY1ZTc5MjQzMWM4ZjM0NjkxYWZjYzRiNjJjLCAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICBzZXRMb2NhbFZpc3VhbFN0YXRlUHJvcGVydHlfYWVkY2I4ZjVlNzkyNDMxYzhmMzQ2OTFhZmNjNGI2MmMsXHJcbiAgICAgICAgZ2V0VmlzdWFsU3RhdGVQcm9wZXJ0eV9hZWRjYjhmNWU3OTI0MzFjOGYzNDY5MWFmY2M0YjYyYykpO1xyXG5nbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5NZWRpYS5BbmltYXRpb24uU3Rvcnlib2FyZC5TZXRUYXJnZXQoT2JqZWN0QW5pbWF0aW9uVXNpbmdLZXlGcmFtZXNfYWZkOTU0MDBjZjllNDhmNjljNjk5ZmY2NTJkNDEzNzQsIEdyaWRfNTVlZWY5YjZjNDFjNDc3ZmJhZWNiNDE4M2E3Yzc4M2YpO1xyXG5cclxudGVtcGxhdGVJbnN0YW5jZV81ZThmYTc1MDkxOGE0NzcxOTdmOGU5NDE0MmM0NjM4ZS5UZW1wbGF0ZUNvbnRlbnQgPSBHcmlkXzQxYzg0ZDBhNzEwMTQ4MjE5MDc3NGFjYWM0MzFhMGNkO1xyXG5yZXR1cm4gdGVtcGxhdGVJbnN0YW5jZV81ZThmYTc1MDkxOGE0NzcxOTdmOGU5NDE0MmM0NjM4ZTtcclxufSkpO1xyXG5cclxuU2V0dGVyXzhiOGI2NTU1MTIxODQ0NmZiZWU1NDI0ODljZjkxYmM5LlZhbHVlID0gQ29udHJvbFRlbXBsYXRlX2ZlZWM0NThlMDZhNTQ4NzhhNjkxMjU5Njk1ODNjZTAzO1xyXG5cclxuXHJcblN0eWxlXzIyYTFiZGVkMDMxYTQ3NWFhMTU1MzkzNDJlYzk2MDIxLlNldHRlcnMuQWRkKFNldHRlcl8yODExZGMxZmY5NTA0YjY0YTQ2YWM0NjljMDE0ZjI3Nyk7XHJcblN0eWxlXzIyYTFiZGVkMDMxYTQ3NWFhMTU1MzkzNDJlYzk2MDIxLlNldHRlcnMuQWRkKFNldHRlcl83OThjOGEzMjA3MjE0OWQyYjIyZmEzODM1NmFkMzU5NCk7XHJcblN0eWxlXzIyYTFiZGVkMDMxYTQ3NWFhMTU1MzkzNDJlYzk2MDIxLlNldHRlcnMuQWRkKFNldHRlcl8yNzhiNzE0Y2VjNjk0M2MyYWFlYmJmMzI4Mzk1Mjk4Zik7XHJcblN0eWxlXzIyYTFiZGVkMDMxYTQ3NWFhMTU1MzkzNDJlYzk2MDIxLlNldHRlcnMuQWRkKFNldHRlcl9mYjhjZTA2NWFjNDg0N2RiOTI1MDc4NTY4M2UwNGQ1Zik7XHJcblN0eWxlXzIyYTFiZGVkMDMxYTQ3NWFhMTU1MzkzNDJlYzk2MDIxLlNldHRlcnMuQWRkKFNldHRlcl84YjhiNjU1NTEyMTg0NDZmYmVlNTQyNDg5Y2Y5MWJjOSk7XHJcblxyXG5cclxudmFyIFN0eWxlX2ZhMGU1MTdkMzc4MDRkNTE5MDk1M2U1MzgwYzI3ZTJmID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlN0eWxlKCk7XHJcblN0eWxlX2ZhMGU1MTdkMzc4MDRkNTE5MDk1M2U1MzgwYzI3ZTJmLlRhcmdldFR5cGUgPSB0eXBlb2YoZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuQ29udHJvbHMuQnV0dG9uKTtcclxudmFyIFNldHRlcl8yZGRmNTEwMGNkYWM0OGZhOWUwYzMwNjUwMDczOThjYSA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5TZXR0ZXIoKTtcclxuU2V0dGVyXzJkZGY1MTAwY2RhYzQ4ZmE5ZTBjMzA2NTAwNzM5OGNhLlByb3BlcnR5ID0gZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuQ29udHJvbHMuQnV0dG9uLkJhY2tncm91bmRQcm9wZXJ0eTtcclxuU2V0dGVyXzJkZGY1MTAwY2RhYzQ4ZmE5ZTBjMzA2NTAwNzM5OGNhLlZhbHVlID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLk1lZGlhLlNvbGlkQ29sb3JCcnVzaChuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLkNvbG9yKCkgeyBBID0gKGJ5dGUpMjU1LCBSID0gKGJ5dGUpMjI2LCBHID0gKGJ5dGUpMjI2LCBCID0gKGJ5dGUpMjI2IH0pO1xyXG5cclxudmFyIFNldHRlcl9hZWE5ZTQ5YTAyMTQ0NDc0YjQ2NjJlZDg4NDg0M2M2MSA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5TZXR0ZXIoKTtcclxuU2V0dGVyX2FlYTllNDlhMDIxNDQ0NzRiNDY2MmVkODg0ODQzYzYxLlByb3BlcnR5ID0gZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuQ29udHJvbHMuQnV0dG9uLkZvcmVncm91bmRQcm9wZXJ0eTtcclxuU2V0dGVyX2FlYTllNDlhMDIxNDQ0NzRiNDY2MmVkODg0ODQzYzYxLlZhbHVlID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLk1lZGlhLlNvbGlkQ29sb3JCcnVzaChuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLkNvbG9yKCkgeyBBID0gKGJ5dGUpMjU1LCBSID0gKGJ5dGUpMCwgRyA9IChieXRlKTAsIEIgPSAoYnl0ZSkwIH0pO1xyXG5cclxudmFyIFNldHRlcl9kNmJmODg4ZmVhMDc0M2NhOTY1NDE5ZmIxZDhlMzJiZCA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5TZXR0ZXIoKTtcclxuU2V0dGVyX2Q2YmY4ODhmZWEwNzQzY2E5NjU0MTlmYjFkOGUzMmJkLlByb3BlcnR5ID0gZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuQ29udHJvbHMuQnV0dG9uLkJvcmRlclRoaWNrbmVzc1Byb3BlcnR5O1xyXG5TZXR0ZXJfZDZiZjg4OGZlYTA3NDNjYTk2NTQxOWZiMWQ4ZTMyYmQuVmFsdWUgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuVGhpY2tuZXNzKDApO1xyXG5cclxudmFyIFNldHRlcl9kNzk0YTdhYzJiZDM0ZDkwYTM0Yzg3ZWE0NjM1OWZiNSA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5TZXR0ZXIoKTtcclxuU2V0dGVyX2Q3OTRhN2FjMmJkMzRkOTBhMzRjODdlYTQ2MzU5ZmI1LlByb3BlcnR5ID0gZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuQ29udHJvbHMuQnV0dG9uLlBhZGRpbmdQcm9wZXJ0eTtcclxuU2V0dGVyX2Q3OTRhN2FjMmJkMzRkOTBhMzRjODdlYTQ2MzU5ZmI1LlZhbHVlID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlRoaWNrbmVzcygxMiwgNCwgMTIsIDQpO1xyXG5cclxudmFyIFNldHRlcl8xYTU3OWEyZGRhMjg0YjNiOTRjZjJhM2UyMjlhZGY4NyA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5TZXR0ZXIoKTtcclxuU2V0dGVyXzFhNTc5YTJkZGEyODRiM2I5NGNmMmEzZTIyOWFkZjg3LlByb3BlcnR5ID0gZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuQ29udHJvbHMuQnV0dG9uLkN1cnNvclByb3BlcnR5O1xyXG5TZXR0ZXJfMWE1NzlhMmRkYTI4NGIzYjk0Y2YyYTNlMjI5YWRmODcuVmFsdWUgPSBnbG9iYWw6OlN5c3RlbS5XaW5kb3dzLklucHV0LkN1cnNvcnMuSGFuZDtcclxuXHJcbnZhciBTZXR0ZXJfMmIwZDI1YWRiZTA1NDA1N2JjYmYyNWUzOGY4ODAzY2QgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuU2V0dGVyKCk7XHJcblNldHRlcl8yYjBkMjVhZGJlMDU0MDU3YmNiZjI1ZTM4Zjg4MDNjZC5Qcm9wZXJ0eSA9IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkNvbnRyb2xzLkJ1dHRvbi5Ib3Jpem9udGFsQ29udGVudEFsaWdubWVudFByb3BlcnR5O1xyXG5TZXR0ZXJfMmIwZDI1YWRiZTA1NDA1N2JjYmYyNWUzOGY4ODAzY2QuVmFsdWUgPSBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Ib3Jpem9udGFsQWxpZ25tZW50LkNlbnRlcjtcclxuXHJcbnZhciBTZXR0ZXJfYjVmNTRiMjlhNDFkNGQ4Y2JjYmRiOTJkMmZlZDNkY2MgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuU2V0dGVyKCk7XHJcblNldHRlcl9iNWY1NGIyOWE0MWQ0ZDhjYmNiZGI5MmQyZmVkM2RjYy5Qcm9wZXJ0eSA9IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkNvbnRyb2xzLkJ1dHRvbi5WZXJ0aWNhbENvbnRlbnRBbGlnbm1lbnRQcm9wZXJ0eTtcclxuU2V0dGVyX2I1ZjU0YjI5YTQxZDRkOGNiY2JkYjkyZDJmZWQzZGNjLlZhbHVlID0gZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuVmVydGljYWxBbGlnbm1lbnQuQ2VudGVyO1xyXG5cclxudmFyIFNldHRlcl84ZTYwMTE0MzE4MzE0ZmU4OGUxYTBlMzRiMzFjYWQ4NyA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5TZXR0ZXIoKTtcclxuU2V0dGVyXzhlNjAxMTQzMTgzMTRmZTg4ZTFhMGUzNGIzMWNhZDg3LlByb3BlcnR5ID0gZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuQ29udHJvbHMuQnV0dG9uLlRlbXBsYXRlUHJvcGVydHk7XHJcbnZhciBDb250cm9sVGVtcGxhdGVfYjUyMTg3OTJlMGU2NDdlMzlmYzkxMjdkZTU3ZGIyZTggPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuQ29udHJvbHMuQ29udHJvbFRlbXBsYXRlKCk7XHJcbkNvbnRyb2xUZW1wbGF0ZV9iNTIxODc5MmUwZTY0N2UzOWZjOTEyN2RlNTdkYjJlOC5UYXJnZXRUeXBlID0gdHlwZW9mKGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkNvbnRyb2xzLkJ1dHRvbik7XHJcbkNvbnRyb2xUZW1wbGF0ZV9iNTIxODc5MmUwZTY0N2UzOWZjOTEyN2RlNTdkYjJlOC5TZXRNZXRob2RUb0luc3RhbnRpYXRlRnJhbWV3b3JrVGVtcGxhdGUoKFN5c3RlbS5GdW5jPFdpbmRvd3MuVUkuWGFtbC5Db250cm9scy5Db250cm9sLFdpbmRvd3MuVUkuWGFtbC5UZW1wbGF0ZUluc3RhbmNlPikodGVtcGxhdGVPd25lcl9Db250cm9sVGVtcGxhdGVfYjUyMTg3OTJlMGU2NDdlMzlmYzkxMjdkZTU3ZGIyZTggPT4gXHJcbntcclxudmFyIHRlbXBsYXRlSW5zdGFuY2VfMmVmMTZlMGExMmExNDljYzlmMjU5MjMyNTA0ODA1MDggPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuVGVtcGxhdGVJbnN0YW5jZSgpO1xyXG50ZW1wbGF0ZUluc3RhbmNlXzJlZjE2ZTBhMTJhMTQ5Y2M5ZjI1OTIzMjUwNDgwNTA4LlRlbXBsYXRlT3duZXIgPSB0ZW1wbGF0ZU93bmVyX0NvbnRyb2xUZW1wbGF0ZV9iNTIxODc5MmUwZTY0N2UzOWZjOTEyN2RlNTdkYjJlODtcclxudmFyIFZpc3VhbFN0YXRlX2ZjY2ZiMmQ5YWE4YjRjZGY4MzMyZDI4YmQ2ZjA1ZjRlID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlZpc3VhbFN0YXRlKCk7XHJcbnZhciBWaXN1YWxTdGF0ZV9jOWI0ZjFiNWZiYmE0NzNiOWRiZTMzMWM4ZWVkYWYxMCA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5WaXN1YWxTdGF0ZSgpO1xyXG52YXIgVmlzdWFsU3RhdGVfYTBkMWI2ZjM3OGRmNDI3MWFlZTg5MDQyNTE0ZjhjNGQgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuVmlzdWFsU3RhdGUoKTtcclxudmFyIFZpc3VhbFN0YXRlXzI1NWJlOGVhZTI0MTRhOGRhODk3NGZlMzFlNDhlOWYwID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlZpc3VhbFN0YXRlKCk7XHJcbnZhciBWaXN1YWxTdGF0ZUdyb3VwXzgxYTljMDc1OGI1YjQ2NThiYWZhNDcyOGNhMjVmMzcyID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlZpc3VhbFN0YXRlR3JvdXAoKTtcclxudmFyIENvbnRlbnRQcmVzZW50ZXJfZGRiZjZkOGM1NTA0NDY5ZGIyMDk2NmRhY2Q1MTYyMmMgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuQ29udHJvbHMuQ29udGVudFByZXNlbnRlcigpO1xyXG52YXIgQm9yZGVyX2ZhNDNkMWMzMDAyYzQxODE4ZGUwNjc5NzZlYWY5OTY5ID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkNvbnRyb2xzLkJvcmRlcigpO1xyXG52YXIgQm9yZGVyX2JiY2JiZjU0YzE5MzQ3MmRhODI0MTJjNjNlNGYzNmJhID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkNvbnRyb2xzLkJvcmRlcigpO1xyXG50ZW1wbGF0ZU93bmVyX0NvbnRyb2xUZW1wbGF0ZV9iNTIxODc5MmUwZTY0N2UzOWZjOTEyN2RlNTdkYjJlOC5SZWdpc3Rlck5hbWUoXCJPdXRlckJvcmRlclwiLCBCb3JkZXJfYmJjYmJmNTRjMTkzNDcyZGE4MjQxMmM2M2U0ZjM2YmEpO1xyXG5Cb3JkZXJfYmJjYmJmNTRjMTkzNDcyZGE4MjQxMmM2M2U0ZjM2YmEuTmFtZSA9IFwiT3V0ZXJCb3JkZXJcIjtcclxudGVtcGxhdGVPd25lcl9Db250cm9sVGVtcGxhdGVfYjUyMTg3OTJlMGU2NDdlMzlmYzkxMjdkZTU3ZGIyZTguUmVnaXN0ZXJOYW1lKFwiQ29tbW9uU3RhdGVzXCIsIFZpc3VhbFN0YXRlR3JvdXBfODFhOWMwNzU4YjViNDY1OGJhZmE0NzI4Y2EyNWYzNzIpO1xyXG5WaXN1YWxTdGF0ZUdyb3VwXzgxYTljMDc1OGI1YjQ2NThiYWZhNDcyOGNhMjVmMzcyLk5hbWUgPSBcIkNvbW1vblN0YXRlc1wiO1xyXG50ZW1wbGF0ZU93bmVyX0NvbnRyb2xUZW1wbGF0ZV9iNTIxODc5MmUwZTY0N2UzOWZjOTEyN2RlNTdkYjJlOC5SZWdpc3Rlck5hbWUoXCJOb3JtYWxcIiwgVmlzdWFsU3RhdGVfZmNjZmIyZDlhYThiNGNkZjgzMzJkMjhiZDZmMDVmNGUpO1xyXG5WaXN1YWxTdGF0ZV9mY2NmYjJkOWFhOGI0Y2RmODMzMmQyOGJkNmYwNWY0ZS5OYW1lID0gXCJOb3JtYWxcIjtcclxuXHJcbnRlbXBsYXRlT3duZXJfQ29udHJvbFRlbXBsYXRlX2I1MjE4NzkyZTBlNjQ3ZTM5ZmM5MTI3ZGU1N2RiMmU4LlJlZ2lzdGVyTmFtZShcIlBvaW50ZXJPdmVyXCIsIFZpc3VhbFN0YXRlX2M5YjRmMWI1ZmJiYTQ3M2I5ZGJlMzMxYzhlZWRhZjEwKTtcclxuVmlzdWFsU3RhdGVfYzliNGYxYjVmYmJhNDczYjlkYmUzMzFjOGVlZGFmMTAuTmFtZSA9IFwiUG9pbnRlck92ZXJcIjtcclxudmFyIFN0b3J5Ym9hcmRfODA5ZjlhNzQ4ODU5NDlmMmJhMTc4OWVlMzE0NjA5NGYgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuTWVkaWEuQW5pbWF0aW9uLlN0b3J5Ym9hcmQoKTtcclxudmFyIE9iamVjdEFuaW1hdGlvblVzaW5nS2V5RnJhbWVzXzA3ZDc1NWVmOGZmYTQ2NGZhZGI4MTlmNGIyYjcwZDNjID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLk1lZGlhLkFuaW1hdGlvbi5PYmplY3RBbmltYXRpb25Vc2luZ0tleUZyYW1lcygpO1xyXG5nbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5NZWRpYS5BbmltYXRpb24uU3Rvcnlib2FyZC5TZXRUYXJnZXROYW1lKE9iamVjdEFuaW1hdGlvblVzaW5nS2V5RnJhbWVzXzA3ZDc1NWVmOGZmYTQ2NGZhZGI4MTlmNGIyYjcwZDNjLEBcIklubmVyQm9yZGVyXCIpO1xyXG52YXIgRGlzY3JldGVPYmplY3RLZXlGcmFtZV82MTQ4N2I4NzZhMzY0OGQ4OGU2Nzg1MjkwMTM0NTg2ZCA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5NZWRpYS5BbmltYXRpb24uRGlzY3JldGVPYmplY3RLZXlGcmFtZSgpO1xyXG5EaXNjcmV0ZU9iamVjdEtleUZyYW1lXzYxNDg3Yjg3NmEzNjQ4ZDg4ZTY3ODUyOTAxMzQ1ODZkLktleVRpbWUgPSBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5NZWRpYS5BbmltYXRpb24uS2V5VGltZS5Gcm9tVGltZVNwYW4obmV3IGdsb2JhbDo6U3lzdGVtLlRpbWVTcGFuKDBMKSk7XHJcbkRpc2NyZXRlT2JqZWN0S2V5RnJhbWVfNjE0ODdiODc2YTM2NDhkODhlNjc4NTI5MDEzNDU4NmQuVmFsdWUgPSBAXCIjMTEwMDAwMDBcIjtcclxuXHJcbk9iamVjdEFuaW1hdGlvblVzaW5nS2V5RnJhbWVzXzA3ZDc1NWVmOGZmYTQ2NGZhZGI4MTlmNGIyYjcwZDNjLktleUZyYW1lcy5BZGQoRGlzY3JldGVPYmplY3RLZXlGcmFtZV82MTQ4N2I4NzZhMzY0OGQ4OGU2Nzg1MjkwMTM0NTg2ZCk7XHJcblxyXG5cclxuU3Rvcnlib2FyZF84MDlmOWE3NDg4NTk0OWYyYmExNzg5ZWUzMTQ2MDk0Zi5DaGlsZHJlbi5BZGQoT2JqZWN0QW5pbWF0aW9uVXNpbmdLZXlGcmFtZXNfMDdkNzU1ZWY4ZmZhNDY0ZmFkYjgxOWY0YjJiNzBkM2MpO1xyXG5cclxuXHJcblZpc3VhbFN0YXRlX2M5YjRmMWI1ZmJiYTQ3M2I5ZGJlMzMxYzhlZWRhZjEwLlN0b3J5Ym9hcmQgPSBTdG9yeWJvYXJkXzgwOWY5YTc0ODg1OTQ5ZjJiYTE3ODllZTMxNDYwOTRmO1xyXG5cclxuXHJcbnRlbXBsYXRlT3duZXJfQ29udHJvbFRlbXBsYXRlX2I1MjE4NzkyZTBlNjQ3ZTM5ZmM5MTI3ZGU1N2RiMmU4LlJlZ2lzdGVyTmFtZShcIlByZXNzZWRcIiwgVmlzdWFsU3RhdGVfYTBkMWI2ZjM3OGRmNDI3MWFlZTg5MDQyNTE0ZjhjNGQpO1xyXG5WaXN1YWxTdGF0ZV9hMGQxYjZmMzc4ZGY0MjcxYWVlODkwNDI1MTRmOGM0ZC5OYW1lID0gXCJQcmVzc2VkXCI7XHJcbnZhciBTdG9yeWJvYXJkX2ViYTYxNDYxMDdmYjQyMDI5N2EyOGNhZGMwZGQzYTc2ID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLk1lZGlhLkFuaW1hdGlvbi5TdG9yeWJvYXJkKCk7XHJcbnZhciBPYmplY3RBbmltYXRpb25Vc2luZ0tleUZyYW1lc19lN2FhNmI2NzhjNDg0Y2M5YWUzNzVkYmZiMWYwNDc4OCA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5NZWRpYS5BbmltYXRpb24uT2JqZWN0QW5pbWF0aW9uVXNpbmdLZXlGcmFtZXMoKTtcclxuZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuTWVkaWEuQW5pbWF0aW9uLlN0b3J5Ym9hcmQuU2V0VGFyZ2V0TmFtZShPYmplY3RBbmltYXRpb25Vc2luZ0tleUZyYW1lc19lN2FhNmI2NzhjNDg0Y2M5YWUzNzVkYmZiMWYwNDc4OCxAXCJJbm5lckJvcmRlclwiKTtcclxudmFyIERpc2NyZXRlT2JqZWN0S2V5RnJhbWVfMTAzMDI2MDZkZGViNGZiZGFiN2NmYTc4YzVjZTU1MzIgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuTWVkaWEuQW5pbWF0aW9uLkRpc2NyZXRlT2JqZWN0S2V5RnJhbWUoKTtcclxuRGlzY3JldGVPYmplY3RLZXlGcmFtZV8xMDMwMjYwNmRkZWI0ZmJkYWI3Y2ZhNzhjNWNlNTUzMi5LZXlUaW1lID0gZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuTWVkaWEuQW5pbWF0aW9uLktleVRpbWUuRnJvbVRpbWVTcGFuKG5ldyBnbG9iYWw6OlN5c3RlbS5UaW1lU3BhbigwTCkpO1xyXG5EaXNjcmV0ZU9iamVjdEtleUZyYW1lXzEwMzAyNjA2ZGRlYjRmYmRhYjdjZmE3OGM1Y2U1NTMyLlZhbHVlID0gQFwiIzIyMDAwMDAwXCI7XHJcblxyXG5PYmplY3RBbmltYXRpb25Vc2luZ0tleUZyYW1lc19lN2FhNmI2NzhjNDg0Y2M5YWUzNzVkYmZiMWYwNDc4OC5LZXlGcmFtZXMuQWRkKERpc2NyZXRlT2JqZWN0S2V5RnJhbWVfMTAzMDI2MDZkZGViNGZiZGFiN2NmYTc4YzVjZTU1MzIpO1xyXG5cclxuXHJcblN0b3J5Ym9hcmRfZWJhNjE0NjEwN2ZiNDIwMjk3YTI4Y2FkYzBkZDNhNzYuQ2hpbGRyZW4uQWRkKE9iamVjdEFuaW1hdGlvblVzaW5nS2V5RnJhbWVzX2U3YWE2YjY3OGM0ODRjYzlhZTM3NWRiZmIxZjA0Nzg4KTtcclxuXHJcblxyXG5WaXN1YWxTdGF0ZV9hMGQxYjZmMzc4ZGY0MjcxYWVlODkwNDI1MTRmOGM0ZC5TdG9yeWJvYXJkID0gU3Rvcnlib2FyZF9lYmE2MTQ2MTA3ZmI0MjAyOTdhMjhjYWRjMGRkM2E3NjtcclxuXHJcblxyXG50ZW1wbGF0ZU93bmVyX0NvbnRyb2xUZW1wbGF0ZV9iNTIxODc5MmUwZTY0N2UzOWZjOTEyN2RlNTdkYjJlOC5SZWdpc3Rlck5hbWUoXCJEaXNhYmxlZFwiLCBWaXN1YWxTdGF0ZV8yNTViZThlYWUyNDE0YThkYTg5NzRmZTMxZTQ4ZTlmMCk7XHJcblZpc3VhbFN0YXRlXzI1NWJlOGVhZTI0MTRhOGRhODk3NGZlMzFlNDhlOWYwLk5hbWUgPSBcIkRpc2FibGVkXCI7XHJcbnZhciBTdG9yeWJvYXJkXzJlZjc2ZTliYTZlZjQ2ZTM5MGRjOGE2MDg0MjUzYzlhID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLk1lZGlhLkFuaW1hdGlvbi5TdG9yeWJvYXJkKCk7XHJcbnZhciBPYmplY3RBbmltYXRpb25Vc2luZ0tleUZyYW1lc19jZjdlNDAwMmUzMDU0YTY1OTFhZjI1N2JjMTIyZTliMCA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5NZWRpYS5BbmltYXRpb24uT2JqZWN0QW5pbWF0aW9uVXNpbmdLZXlGcmFtZXMoKTtcclxuZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuTWVkaWEuQW5pbWF0aW9uLlN0b3J5Ym9hcmQuU2V0VGFyZ2V0TmFtZShPYmplY3RBbmltYXRpb25Vc2luZ0tleUZyYW1lc19jZjdlNDAwMmUzMDU0YTY1OTFhZjI1N2JjMTIyZTliMCxAXCJJbm5lckJvcmRlclwiKTtcclxudmFyIERpc2NyZXRlT2JqZWN0S2V5RnJhbWVfZDExYzMxNDM2MmQzNDdlMDhlOTNkNDY0MGI1YjE4NGQgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuTWVkaWEuQW5pbWF0aW9uLkRpc2NyZXRlT2JqZWN0S2V5RnJhbWUoKTtcclxuRGlzY3JldGVPYmplY3RLZXlGcmFtZV9kMTFjMzE0MzYyZDM0N2UwOGU5M2Q0NjQwYjViMTg0ZC5LZXlUaW1lID0gZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuTWVkaWEuQW5pbWF0aW9uLktleVRpbWUuRnJvbVRpbWVTcGFuKG5ldyBnbG9iYWw6OlN5c3RlbS5UaW1lU3BhbigwTCkpO1xyXG5EaXNjcmV0ZU9iamVjdEtleUZyYW1lX2QxMWMzMTQzNjJkMzQ3ZTA4ZTkzZDQ2NDBiNWIxODRkLlZhbHVlID0gQFwiIzMzRkZGRkZGXCI7XHJcblxyXG5PYmplY3RBbmltYXRpb25Vc2luZ0tleUZyYW1lc19jZjdlNDAwMmUzMDU0YTY1OTFhZjI1N2JjMTIyZTliMC5LZXlGcmFtZXMuQWRkKERpc2NyZXRlT2JqZWN0S2V5RnJhbWVfZDExYzMxNDM2MmQzNDdlMDhlOTNkNDY0MGI1YjE4NGQpO1xyXG5cclxuXHJcblN0b3J5Ym9hcmRfMmVmNzZlOWJhNmVmNDZlMzkwZGM4YTYwODQyNTNjOWEuQ2hpbGRyZW4uQWRkKE9iamVjdEFuaW1hdGlvblVzaW5nS2V5RnJhbWVzX2NmN2U0MDAyZTMwNTRhNjU5MWFmMjU3YmMxMjJlOWIwKTtcclxuXHJcblxyXG5WaXN1YWxTdGF0ZV8yNTViZThlYWUyNDE0YThkYTg5NzRmZTMxZTQ4ZTlmMC5TdG9yeWJvYXJkID0gU3Rvcnlib2FyZF8yZWY3NmU5YmE2ZWY0NmUzOTBkYzhhNjA4NDI1M2M5YTtcclxuXHJcblxyXG5WaXN1YWxTdGF0ZUdyb3VwXzgxYTljMDc1OGI1YjQ2NThiYWZhNDcyOGNhMjVmMzcyLlN0YXRlcy5BZGQoVmlzdWFsU3RhdGVfZmNjZmIyZDlhYThiNGNkZjgzMzJkMjhiZDZmMDVmNGUpO1xyXG5WaXN1YWxTdGF0ZUdyb3VwXzgxYTljMDc1OGI1YjQ2NThiYWZhNDcyOGNhMjVmMzcyLlN0YXRlcy5BZGQoVmlzdWFsU3RhdGVfYzliNGYxYjVmYmJhNDczYjlkYmUzMzFjOGVlZGFmMTApO1xyXG5WaXN1YWxTdGF0ZUdyb3VwXzgxYTljMDc1OGI1YjQ2NThiYWZhNDcyOGNhMjVmMzcyLlN0YXRlcy5BZGQoVmlzdWFsU3RhdGVfYTBkMWI2ZjM3OGRmNDI3MWFlZTg5MDQyNTE0ZjhjNGQpO1xyXG5WaXN1YWxTdGF0ZUdyb3VwXzgxYTljMDc1OGI1YjQ2NThiYWZhNDcyOGNhMjVmMzcyLlN0YXRlcy5BZGQoVmlzdWFsU3RhdGVfMjU1YmU4ZWFlMjQxNGE4ZGE4OTc0ZmUzMWU0OGU5ZjApO1xyXG5cclxuXHJcbnRlbXBsYXRlT3duZXJfQ29udHJvbFRlbXBsYXRlX2I1MjE4NzkyZTBlNjQ3ZTM5ZmM5MTI3ZGU1N2RiMmU4LklOVEVSTkFMX0dldFZpc3VhbFN0YXRlR3JvdXBzKCkuQWRkKFZpc3VhbFN0YXRlR3JvdXBfODFhOWMwNzU4YjViNDY1OGJhZmE0NzI4Y2EyNWYzNzIpO1xyXG5cclxudGVtcGxhdGVPd25lcl9Db250cm9sVGVtcGxhdGVfYjUyMTg3OTJlMGU2NDdlMzlmYzkxMjdkZTU3ZGIyZTguUmVnaXN0ZXJOYW1lKFwiSW5uZXJCb3JkZXJcIiwgQm9yZGVyX2ZhNDNkMWMzMDAyYzQxODE4ZGUwNjc5NzZlYWY5OTY5KTtcclxuQm9yZGVyX2ZhNDNkMWMzMDAyYzQxODE4ZGUwNjc5NzZlYWY5OTY5Lk5hbWUgPSBcIklubmVyQm9yZGVyXCI7XHJcbnRlbXBsYXRlT3duZXJfQ29udHJvbFRlbXBsYXRlX2I1MjE4NzkyZTBlNjQ3ZTM5ZmM5MTI3ZGU1N2RiMmU4LlJlZ2lzdGVyTmFtZShcIkNvbnRlbnRQcmVzZW50ZXJcIiwgQ29udGVudFByZXNlbnRlcl9kZGJmNmQ4YzU1MDQ0NjlkYjIwOTY2ZGFjZDUxNjIyYyk7XHJcbkNvbnRlbnRQcmVzZW50ZXJfZGRiZjZkOGM1NTA0NDY5ZGIyMDk2NmRhY2Q1MTYyMmMuTmFtZSA9IFwiQ29udGVudFByZXNlbnRlclwiO1xyXG52YXIgQmluZGluZ183Y2NhN2Q3YTQyMGY0YTZmYmZiYTg0NDAyMTJhZjcwMCA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmcoKTtcclxuQmluZGluZ183Y2NhN2Q3YTQyMGY0YTZmYmZiYTg0NDAyMTJhZjcwMC5QYXRoID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlByb3BlcnR5UGF0aChAXCJDb250ZW50VGVtcGxhdGVcIik7XHJcbnZhciBSZWxhdGl2ZVNvdXJjZV80OTQ5ZTY4ZGNmYjg0NDc2YmQyNGVlMDJhZTY3YTQxMiA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLlJlbGF0aXZlU291cmNlKCk7XHJcblJlbGF0aXZlU291cmNlXzQ5NDllNjhkY2ZiODQ0NzZiZDI0ZWUwMmFlNjdhNDEyLk1vZGUgPSBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLlJlbGF0aXZlU291cmNlTW9kZS5UZW1wbGF0ZWRQYXJlbnQ7XHJcblxyXG5CaW5kaW5nXzdjY2E3ZDdhNDIwZjRhNmZiZmJhODQ0MDIxMmFmNzAwLlJlbGF0aXZlU291cmNlID0gUmVsYXRpdmVTb3VyY2VfNDk0OWU2OGRjZmI4NDQ3NmJkMjRlZTAyYWU2N2E0MTI7XHJcblxyXG5cclxuQmluZGluZ183Y2NhN2Q3YTQyMGY0YTZmYmZiYTg0NDAyMTJhZjcwMC5UZW1wbGF0ZU93bmVyID0gdGVtcGxhdGVJbnN0YW5jZV8yZWYxNmUwYTEyYTE0OWNjOWYyNTkyMzI1MDQ4MDUwODtcclxuXHJcbnZhciBCaW5kaW5nXzA4NDI4OWYxYjI3NTRhM2E5NzVmZDg5NGEwM2RkNjE4ID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuQmluZGluZygpO1xyXG5CaW5kaW5nXzA4NDI4OWYxYjI3NTRhM2E5NzVmZDg5NGEwM2RkNjE4LlBhdGggPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuUHJvcGVydHlQYXRoKEBcIkNvbnRlbnRcIik7XHJcbnZhciBSZWxhdGl2ZVNvdXJjZV8yNzk3MDgzZmJlM2U0OWVhOGQyMmE1NTAyZTI3MTcwYSA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLlJlbGF0aXZlU291cmNlKCk7XHJcblJlbGF0aXZlU291cmNlXzI3OTcwODNmYmUzZTQ5ZWE4ZDIyYTU1MDJlMjcxNzBhLk1vZGUgPSBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLlJlbGF0aXZlU291cmNlTW9kZS5UZW1wbGF0ZWRQYXJlbnQ7XHJcblxyXG5CaW5kaW5nXzA4NDI4OWYxYjI3NTRhM2E5NzVmZDg5NGEwM2RkNjE4LlJlbGF0aXZlU291cmNlID0gUmVsYXRpdmVTb3VyY2VfMjc5NzA4M2ZiZTNlNDllYThkMjJhNTUwMmUyNzE3MGE7XHJcblxyXG5cclxuQmluZGluZ18wODQyODlmMWIyNzU0YTNhOTc1ZmQ4OTRhMDNkZDYxOC5UZW1wbGF0ZU93bmVyID0gdGVtcGxhdGVJbnN0YW5jZV8yZWYxNmUwYTEyYTE0OWNjOWYyNTkyMzI1MDQ4MDUwODtcclxuXHJcbnZhciBCaW5kaW5nXzRhMWI5MzRiNjQ3MTQwY2ZiNGM5YWFmMzJjM2M0MGY4ID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuQmluZGluZygpO1xyXG5CaW5kaW5nXzRhMWI5MzRiNjQ3MTQwY2ZiNGM5YWFmMzJjM2M0MGY4LlBhdGggPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuUHJvcGVydHlQYXRoKEBcIkhlaWdodFwiKTtcclxudmFyIFJlbGF0aXZlU291cmNlXzZlYjhiNjE3Nzc0YTRhMDRiNTgxYjdkMGIyZjIyOTVlID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuUmVsYXRpdmVTb3VyY2UoKTtcclxuUmVsYXRpdmVTb3VyY2VfNmViOGI2MTc3NzRhNGEwNGI1ODFiN2QwYjJmMjI5NWUuTW9kZSA9IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuUmVsYXRpdmVTb3VyY2VNb2RlLlRlbXBsYXRlZFBhcmVudDtcclxuXHJcbkJpbmRpbmdfNGExYjkzNGI2NDcxNDBjZmI0YzlhYWYzMmMzYzQwZjguUmVsYXRpdmVTb3VyY2UgPSBSZWxhdGl2ZVNvdXJjZV82ZWI4YjYxNzc3NGE0YTA0YjU4MWI3ZDBiMmYyMjk1ZTtcclxuXHJcblxyXG5CaW5kaW5nXzRhMWI5MzRiNjQ3MTQwY2ZiNGM5YWFmMzJjM2M0MGY4LlRlbXBsYXRlT3duZXIgPSB0ZW1wbGF0ZUluc3RhbmNlXzJlZjE2ZTBhMTJhMTQ5Y2M5ZjI1OTIzMjUwNDgwNTA4O1xyXG5cclxudmFyIEJpbmRpbmdfNzc1MTlkNWRjZDcwNDk5MWFkZjY2MjZhNzQ4MzhjZTEgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5CaW5kaW5nKCk7XHJcbkJpbmRpbmdfNzc1MTlkNWRjZDcwNDk5MWFkZjY2MjZhNzQ4MzhjZTEuUGF0aCA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Qcm9wZXJ0eVBhdGgoQFwiV2lkdGhcIik7XHJcbnZhciBSZWxhdGl2ZVNvdXJjZV8xMTY5MmY2ODhjZGI0ZDI4YWU0YmNiZjA1Y2Q4MmQ1ZCA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLlJlbGF0aXZlU291cmNlKCk7XHJcblJlbGF0aXZlU291cmNlXzExNjkyZjY4OGNkYjRkMjhhZTRiY2JmMDVjZDgyZDVkLk1vZGUgPSBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLlJlbGF0aXZlU291cmNlTW9kZS5UZW1wbGF0ZWRQYXJlbnQ7XHJcblxyXG5CaW5kaW5nXzc3NTE5ZDVkY2Q3MDQ5OTFhZGY2NjI2YTc0ODM4Y2UxLlJlbGF0aXZlU291cmNlID0gUmVsYXRpdmVTb3VyY2VfMTE2OTJmNjg4Y2RiNGQyOGFlNGJjYmYwNWNkODJkNWQ7XHJcblxyXG5cclxuQmluZGluZ183NzUxOWQ1ZGNkNzA0OTkxYWRmNjYyNmE3NDgzOGNlMS5UZW1wbGF0ZU93bmVyID0gdGVtcGxhdGVJbnN0YW5jZV8yZWYxNmUwYTEyYTE0OWNjOWYyNTkyMzI1MDQ4MDUwODtcclxuXHJcbnZhciBCaW5kaW5nXzUzMDM4OWIyN2U2MDQwNWFiZDA2Y2JmNmUyM2FlODQ5ID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuQmluZGluZygpO1xyXG5CaW5kaW5nXzUzMDM4OWIyN2U2MDQwNWFiZDA2Y2JmNmUyM2FlODQ5LlBhdGggPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuUHJvcGVydHlQYXRoKEBcIlBhZGRpbmdcIik7XHJcbnZhciBSZWxhdGl2ZVNvdXJjZV80ODBkY2Q5OWUxNDk0NDIyYmJkM2IzODBkYjg1NTU0NiA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLlJlbGF0aXZlU291cmNlKCk7XHJcblJlbGF0aXZlU291cmNlXzQ4MGRjZDk5ZTE0OTQ0MjJiYmQzYjM4MGRiODU1NTQ2Lk1vZGUgPSBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLlJlbGF0aXZlU291cmNlTW9kZS5UZW1wbGF0ZWRQYXJlbnQ7XHJcblxyXG5CaW5kaW5nXzUzMDM4OWIyN2U2MDQwNWFiZDA2Y2JmNmUyM2FlODQ5LlJlbGF0aXZlU291cmNlID0gUmVsYXRpdmVTb3VyY2VfNDgwZGNkOTllMTQ5NDQyMmJiZDNiMzgwZGI4NTU1NDY7XHJcblxyXG5cclxuQmluZGluZ181MzAzODliMjdlNjA0MDVhYmQwNmNiZjZlMjNhZTg0OS5UZW1wbGF0ZU93bmVyID0gdGVtcGxhdGVJbnN0YW5jZV8yZWYxNmUwYTEyYTE0OWNjOWYyNTkyMzI1MDQ4MDUwODtcclxuXHJcbnZhciBCaW5kaW5nX2M5YjNhYzcwZDY4MjQ0M2JhNjMxMDcwODM0N2E3ZDgzID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuQmluZGluZygpO1xyXG5CaW5kaW5nX2M5YjNhYzcwZDY4MjQ0M2JhNjMxMDcwODM0N2E3ZDgzLlBhdGggPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuUHJvcGVydHlQYXRoKEBcIkhvcml6b250YWxDb250ZW50QWxpZ25tZW50XCIpO1xyXG52YXIgUmVsYXRpdmVTb3VyY2VfNGMwZWU5NWI3ZTUwNGE4NmFhMTMyZmFjNWQxMzVlMTAgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5SZWxhdGl2ZVNvdXJjZSgpO1xyXG5SZWxhdGl2ZVNvdXJjZV80YzBlZTk1YjdlNTA0YTg2YWExMzJmYWM1ZDEzNWUxMC5Nb2RlID0gZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5SZWxhdGl2ZVNvdXJjZU1vZGUuVGVtcGxhdGVkUGFyZW50O1xyXG5cclxuQmluZGluZ19jOWIzYWM3MGQ2ODI0NDNiYTYzMTA3MDgzNDdhN2Q4My5SZWxhdGl2ZVNvdXJjZSA9IFJlbGF0aXZlU291cmNlXzRjMGVlOTViN2U1MDRhODZhYTEzMmZhYzVkMTM1ZTEwO1xyXG5cclxuXHJcbkJpbmRpbmdfYzliM2FjNzBkNjgyNDQzYmE2MzEwNzA4MzQ3YTdkODMuVGVtcGxhdGVPd25lciA9IHRlbXBsYXRlSW5zdGFuY2VfMmVmMTZlMGExMmExNDljYzlmMjU5MjMyNTA0ODA1MDg7XHJcblxyXG52YXIgQmluZGluZ19jNzU1NzU3YTc4YjA0Mzc1OGYyZTE0YzlhNWJlMWE2YyA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmcoKTtcclxuQmluZGluZ19jNzU1NzU3YTc4YjA0Mzc1OGYyZTE0YzlhNWJlMWE2Yy5QYXRoID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlByb3BlcnR5UGF0aChAXCJWZXJ0aWNhbENvbnRlbnRBbGlnbm1lbnRcIik7XHJcbnZhciBSZWxhdGl2ZVNvdXJjZV9iZWQ1NGMwOTNlNzE0YjUwYTNkZmRlOGYyMmQ5ZWFjNyA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLlJlbGF0aXZlU291cmNlKCk7XHJcblJlbGF0aXZlU291cmNlX2JlZDU0YzA5M2U3MTRiNTBhM2RmZGU4ZjIyZDllYWM3Lk1vZGUgPSBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLlJlbGF0aXZlU291cmNlTW9kZS5UZW1wbGF0ZWRQYXJlbnQ7XHJcblxyXG5CaW5kaW5nX2M3NTU3NTdhNzhiMDQzNzU4ZjJlMTRjOWE1YmUxYTZjLlJlbGF0aXZlU291cmNlID0gUmVsYXRpdmVTb3VyY2VfYmVkNTRjMDkzZTcxNGI1MGEzZGZkZThmMjJkOWVhYzc7XHJcblxyXG5cclxuQmluZGluZ19jNzU1NzU3YTc4YjA0Mzc1OGYyZTE0YzlhNWJlMWE2Yy5UZW1wbGF0ZU93bmVyID0gdGVtcGxhdGVJbnN0YW5jZV8yZWYxNmUwYTEyYTE0OWNjOWYyNTkyMzI1MDQ4MDUwODtcclxuXHJcbnZhciBCaW5kaW5nXzNjMDNmODcxNDY3NDRkNWZhNmQ1NTIzNzkxYjc2MjQ2ID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuQmluZGluZygpO1xyXG5CaW5kaW5nXzNjMDNmODcxNDY3NDRkNWZhNmQ1NTIzNzkxYjc2MjQ2LlBhdGggPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuUHJvcGVydHlQYXRoKEBcIlZpc2liaWxpdHlcIik7XHJcblxyXG5cclxuXHJcbkJvcmRlcl9mYTQzZDFjMzAwMmM0MTgxOGRlMDY3OTc2ZWFmOTk2OS5DaGlsZCA9IENvbnRlbnRQcmVzZW50ZXJfZGRiZjZkOGM1NTA0NDY5ZGIyMDk2NmRhY2Q1MTYyMmM7XHJcblxyXG52YXIgQmluZGluZ185MjkzYzk5MjllNDI0NTc2ODkxZmJmMzhiZTQ3NGUzNSA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmcoKTtcclxuQmluZGluZ185MjkzYzk5MjllNDI0NTc2ODkxZmJmMzhiZTQ3NGUzNS5QYXRoID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlByb3BlcnR5UGF0aChAXCJCYWNrZ3JvdW5kXCIpO1xyXG52YXIgUmVsYXRpdmVTb3VyY2VfMGNhZTliYjI4OWM3NGFkYWE1MzQ4OTVkNjc1ODY5MzIgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5SZWxhdGl2ZVNvdXJjZSgpO1xyXG5SZWxhdGl2ZVNvdXJjZV8wY2FlOWJiMjg5Yzc0YWRhYTUzNDg5NWQ2NzU4NjkzMi5Nb2RlID0gZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5SZWxhdGl2ZVNvdXJjZU1vZGUuVGVtcGxhdGVkUGFyZW50O1xyXG5cclxuQmluZGluZ185MjkzYzk5MjllNDI0NTc2ODkxZmJmMzhiZTQ3NGUzNS5SZWxhdGl2ZVNvdXJjZSA9IFJlbGF0aXZlU291cmNlXzBjYWU5YmIyODljNzRhZGFhNTM0ODk1ZDY3NTg2OTMyO1xyXG5cclxuXHJcbkJpbmRpbmdfOTI5M2M5OTI5ZTQyNDU3Njg5MWZiZjM4YmU0NzRlMzUuVGVtcGxhdGVPd25lciA9IHRlbXBsYXRlSW5zdGFuY2VfMmVmMTZlMGExMmExNDljYzlmMjU5MjMyNTA0ODA1MDg7XHJcblxyXG5cclxuQm9yZGVyX2JiY2JiZjU0YzE5MzQ3MmRhODI0MTJjNjNlNGYzNmJhLkNoaWxkID0gQm9yZGVyX2ZhNDNkMWMzMDAyYzQxODE4ZGUwNjc5NzZlYWY5OTY5O1xyXG5cclxudmFyIEJpbmRpbmdfYTg5ZmFhZDQ4YjY0NDY3M2I5Y2ZmYjQxNjc5Nzk2MmYgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5CaW5kaW5nKCk7XHJcbkJpbmRpbmdfYTg5ZmFhZDQ4YjY0NDY3M2I5Y2ZmYjQxNjc5Nzk2MmYuUGF0aCA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Qcm9wZXJ0eVBhdGgoQFwiQmFja2dyb3VuZFwiKTtcclxudmFyIFJlbGF0aXZlU291cmNlX2M4NDg0YjMzMzUxMTRlZTJiNjNlYzU2NWYxZTg5NWNiID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuUmVsYXRpdmVTb3VyY2UoKTtcclxuUmVsYXRpdmVTb3VyY2VfYzg0ODRiMzMzNTExNGVlMmI2M2VjNTY1ZjFlODk1Y2IuTW9kZSA9IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuUmVsYXRpdmVTb3VyY2VNb2RlLlRlbXBsYXRlZFBhcmVudDtcclxuXHJcbkJpbmRpbmdfYTg5ZmFhZDQ4YjY0NDY3M2I5Y2ZmYjQxNjc5Nzk2MmYuUmVsYXRpdmVTb3VyY2UgPSBSZWxhdGl2ZVNvdXJjZV9jODQ4NGIzMzM1MTE0ZWUyYjYzZWM1NjVmMWU4OTVjYjtcclxuXHJcblxyXG5CaW5kaW5nX2E4OWZhYWQ0OGI2NDQ2NzNiOWNmZmI0MTY3OTc5NjJmLlRlbXBsYXRlT3duZXIgPSB0ZW1wbGF0ZUluc3RhbmNlXzJlZjE2ZTBhMTJhMTQ5Y2M5ZjI1OTIzMjUwNDgwNTA4O1xyXG5cclxudmFyIEJpbmRpbmdfN2JkZWM2MDgzMTZkNGQ2MTlmZDQ4ZTMxMjc2NWVkOTkgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5CaW5kaW5nKCk7XHJcbkJpbmRpbmdfN2JkZWM2MDgzMTZkNGQ2MTlmZDQ4ZTMxMjc2NWVkOTkuUGF0aCA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Qcm9wZXJ0eVBhdGgoQFwiQm9yZGVyQnJ1c2hcIik7XHJcbnZhciBSZWxhdGl2ZVNvdXJjZV9lMWE1NGExMDQ2YTg0NThjYjJlNjg3OTY0NjRiNDg0NCA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLlJlbGF0aXZlU291cmNlKCk7XHJcblJlbGF0aXZlU291cmNlX2UxYTU0YTEwNDZhODQ1OGNiMmU2ODc5NjQ2NGI0ODQ0Lk1vZGUgPSBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLlJlbGF0aXZlU291cmNlTW9kZS5UZW1wbGF0ZWRQYXJlbnQ7XHJcblxyXG5CaW5kaW5nXzdiZGVjNjA4MzE2ZDRkNjE5ZmQ0OGUzMTI3NjVlZDk5LlJlbGF0aXZlU291cmNlID0gUmVsYXRpdmVTb3VyY2VfZTFhNTRhMTA0NmE4NDU4Y2IyZTY4Nzk2NDY0YjQ4NDQ7XHJcblxyXG5cclxuQmluZGluZ183YmRlYzYwODMxNmQ0ZDYxOWZkNDhlMzEyNzY1ZWQ5OS5UZW1wbGF0ZU93bmVyID0gdGVtcGxhdGVJbnN0YW5jZV8yZWYxNmUwYTEyYTE0OWNjOWYyNTkyMzI1MDQ4MDUwODtcclxuXHJcbnZhciBCaW5kaW5nXzcwY2ZlMzU5MDU3NTRlM2Q5ZmY5YzVjNTkwOGQyNWQxID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuQmluZGluZygpO1xyXG5CaW5kaW5nXzcwY2ZlMzU5MDU3NTRlM2Q5ZmY5YzVjNTkwOGQyNWQxLlBhdGggPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuUHJvcGVydHlQYXRoKEBcIkJvcmRlclRoaWNrbmVzc1wiKTtcclxudmFyIFJlbGF0aXZlU291cmNlX2FjYzY4OGIyNTVlYjQ1ZmY5NzIyM2QxNDllNzA0ODdmID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuUmVsYXRpdmVTb3VyY2UoKTtcclxuUmVsYXRpdmVTb3VyY2VfYWNjNjg4YjI1NWViNDVmZjk3MjIzZDE0OWU3MDQ4N2YuTW9kZSA9IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuUmVsYXRpdmVTb3VyY2VNb2RlLlRlbXBsYXRlZFBhcmVudDtcclxuXHJcbkJpbmRpbmdfNzBjZmUzNTkwNTc1NGUzZDlmZjljNWM1OTA4ZDI1ZDEuUmVsYXRpdmVTb3VyY2UgPSBSZWxhdGl2ZVNvdXJjZV9hY2M2ODhiMjU1ZWI0NWZmOTcyMjNkMTQ5ZTcwNDg3ZjtcclxuXHJcblxyXG5CaW5kaW5nXzcwY2ZlMzU5MDU3NTRlM2Q5ZmY5YzVjNTkwOGQyNWQxLlRlbXBsYXRlT3duZXIgPSB0ZW1wbGF0ZUluc3RhbmNlXzJlZjE2ZTBhMTJhMTQ5Y2M5ZjI1OTIzMjUwNDgwNTA4O1xyXG5cclxudmFyIEJpbmRpbmdfYTU1MTc2YmJmZTg0NGVjNmJmNzJiYmIxNmQyYmI1NGYgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5CaW5kaW5nKCk7XHJcbkJpbmRpbmdfYTU1MTc2YmJmZTg0NGVjNmJmNzJiYmIxNmQyYmI1NGYuUGF0aCA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Qcm9wZXJ0eVBhdGgoQFwiTWFyZ2luXCIpO1xyXG52YXIgUmVsYXRpdmVTb3VyY2VfZmM0Zjg4OGRmMDI5NDkwOWI1OTA2M2NiMzBmZTVjNTQgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5SZWxhdGl2ZVNvdXJjZSgpO1xyXG5SZWxhdGl2ZVNvdXJjZV9mYzRmODg4ZGYwMjk0OTA5YjU5MDYzY2IzMGZlNWM1NC5Nb2RlID0gZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5SZWxhdGl2ZVNvdXJjZU1vZGUuVGVtcGxhdGVkUGFyZW50O1xyXG5cclxuQmluZGluZ19hNTUxNzZiYmZlODQ0ZWM2YmY3MmJiYjE2ZDJiYjU0Zi5SZWxhdGl2ZVNvdXJjZSA9IFJlbGF0aXZlU291cmNlX2ZjNGY4ODhkZjAyOTQ5MDliNTkwNjNjYjMwZmU1YzU0O1xyXG5cclxuXHJcbkJpbmRpbmdfYTU1MTc2YmJmZTg0NGVjNmJmNzJiYmIxNmQyYmI1NGYuVGVtcGxhdGVPd25lciA9IHRlbXBsYXRlSW5zdGFuY2VfMmVmMTZlMGExMmExNDljYzlmMjU5MjMyNTA0ODA1MDg7XHJcblxyXG52YXIgQmluZGluZ18xM2I2MTcyMzczODY0ODFlODhmMGUzMGMwMjdiMjhkOCA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmcoKTtcclxuQmluZGluZ18xM2I2MTcyMzczODY0ODFlODhmMGUzMGMwMjdiMjhkOC5QYXRoID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlByb3BlcnR5UGF0aChAXCJWaXNpYmlsaXR5XCIpO1xyXG5cclxuXHJcblxyXG5nbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmdPcGVyYXRpb25zLlNldEJpbmRpbmcoQ29udGVudFByZXNlbnRlcl9kZGJmNmQ4YzU1MDQ0NjlkYjIwOTY2ZGFjZDUxNjIyYywgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuQ29udHJvbHMuQ29udGVudENvbnRyb2wuQ29udGVudFRlbXBsYXRlUHJvcGVydHksIEJpbmRpbmdfN2NjYTdkN2E0MjBmNGE2ZmJmYmE4NDQwMjEyYWY3MDApO1xyXG5nbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmdPcGVyYXRpb25zLlNldEJpbmRpbmcoQ29udGVudFByZXNlbnRlcl9kZGJmNmQ4YzU1MDQ0NjlkYjIwOTY2ZGFjZDUxNjIyYywgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuQ29udHJvbHMuQ29udGVudENvbnRyb2wuQ29udGVudFByb3BlcnR5LCBCaW5kaW5nXzA4NDI4OWYxYjI3NTRhM2E5NzVmZDg5NGEwM2RkNjE4KTtcclxuZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5CaW5kaW5nT3BlcmF0aW9ucy5TZXRCaW5kaW5nKENvbnRlbnRQcmVzZW50ZXJfZGRiZjZkOGM1NTA0NDY5ZGIyMDk2NmRhY2Q1MTYyMmMsIGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkZyYW1ld29ya0VsZW1lbnQuSGVpZ2h0UHJvcGVydHksIEJpbmRpbmdfNGExYjkzNGI2NDcxNDBjZmI0YzlhYWYzMmMzYzQwZjgpO1xyXG5nbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmdPcGVyYXRpb25zLlNldEJpbmRpbmcoQ29udGVudFByZXNlbnRlcl9kZGJmNmQ4YzU1MDQ0NjlkYjIwOTY2ZGFjZDUxNjIyYywgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRnJhbWV3b3JrRWxlbWVudC5XaWR0aFByb3BlcnR5LCBCaW5kaW5nXzc3NTE5ZDVkY2Q3MDQ5OTFhZGY2NjI2YTc0ODM4Y2UxKTtcclxuZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5CaW5kaW5nT3BlcmF0aW9ucy5TZXRCaW5kaW5nKENvbnRlbnRQcmVzZW50ZXJfZGRiZjZkOGM1NTA0NDY5ZGIyMDk2NmRhY2Q1MTYyMmMsIGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkZyYW1ld29ya0VsZW1lbnQuTWFyZ2luUHJvcGVydHksIEJpbmRpbmdfNTMwMzg5YjI3ZTYwNDA1YWJkMDZjYmY2ZTIzYWU4NDkpO1xyXG5nbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmdPcGVyYXRpb25zLlNldEJpbmRpbmcoQ29udGVudFByZXNlbnRlcl9kZGJmNmQ4YzU1MDQ0NjlkYjIwOTY2ZGFjZDUxNjIyYywgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRnJhbWV3b3JrRWxlbWVudC5Ib3Jpem9udGFsQWxpZ25tZW50UHJvcGVydHksIEJpbmRpbmdfYzliM2FjNzBkNjgyNDQzYmE2MzEwNzA4MzQ3YTdkODMpO1xyXG5nbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmdPcGVyYXRpb25zLlNldEJpbmRpbmcoQ29udGVudFByZXNlbnRlcl9kZGJmNmQ4YzU1MDQ0NjlkYjIwOTY2ZGFjZDUxNjIyYywgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRnJhbWV3b3JrRWxlbWVudC5WZXJ0aWNhbEFsaWdubWVudFByb3BlcnR5LCBCaW5kaW5nX2M3NTU3NTdhNzhiMDQzNzU4ZjJlMTRjOWE1YmUxYTZjKTtcclxuZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5CaW5kaW5nT3BlcmF0aW9ucy5TZXRCaW5kaW5nKENvbnRlbnRQcmVzZW50ZXJfZGRiZjZkOGM1NTA0NDY5ZGIyMDk2NmRhY2Q1MTYyMmMsIGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlVJRWxlbWVudC5WaXNpYmlsaXR5UHJvcGVydHksIEJpbmRpbmdfM2MwM2Y4NzE0Njc0NGQ1ZmE2ZDU1MjM3OTFiNzYyNDYpO1xyXG5nbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmdPcGVyYXRpb25zLlNldEJpbmRpbmcoQm9yZGVyX2ZhNDNkMWMzMDAyYzQxODE4ZGUwNjc5NzZlYWY5OTY5LCBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Db250cm9scy5Cb3JkZXIuQmFja2dyb3VuZFByb3BlcnR5LCBCaW5kaW5nXzkyOTNjOTkyOWU0MjQ1NzY4OTFmYmYzOGJlNDc0ZTM1KTtcclxuZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5CaW5kaW5nT3BlcmF0aW9ucy5TZXRCaW5kaW5nKEJvcmRlcl9iYmNiYmY1NGMxOTM0NzJkYTgyNDEyYzYzZTRmMzZiYSwgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuQ29udHJvbHMuQm9yZGVyLkJhY2tncm91bmRQcm9wZXJ0eSwgQmluZGluZ19hODlmYWFkNDhiNjQ0NjczYjljZmZiNDE2Nzk3OTYyZik7XHJcbmdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuQmluZGluZ09wZXJhdGlvbnMuU2V0QmluZGluZyhCb3JkZXJfYmJjYmJmNTRjMTkzNDcyZGE4MjQxMmM2M2U0ZjM2YmEsIGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkNvbnRyb2xzLkJvcmRlci5Cb3JkZXJCcnVzaFByb3BlcnR5LCBCaW5kaW5nXzdiZGVjNjA4MzE2ZDRkNjE5ZmQ0OGUzMTI3NjVlZDk5KTtcclxuZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5CaW5kaW5nT3BlcmF0aW9ucy5TZXRCaW5kaW5nKEJvcmRlcl9iYmNiYmY1NGMxOTM0NzJkYTgyNDEyYzYzZTRmMzZiYSwgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuQ29udHJvbHMuQm9yZGVyLkJvcmRlclRoaWNrbmVzc1Byb3BlcnR5LCBCaW5kaW5nXzcwY2ZlMzU5MDU3NTRlM2Q5ZmY5YzVjNTkwOGQyNWQxKTtcclxuZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5CaW5kaW5nT3BlcmF0aW9ucy5TZXRCaW5kaW5nKEJvcmRlcl9iYmNiYmY1NGMxOTM0NzJkYTgyNDEyYzYzZTRmMzZiYSwgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRnJhbWV3b3JrRWxlbWVudC5NYXJnaW5Qcm9wZXJ0eSwgQmluZGluZ19hNTUxNzZiYmZlODQ0ZWM2YmY3MmJiYjE2ZDJiYjU0Zik7XHJcbmdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRhdGEuQmluZGluZ09wZXJhdGlvbnMuU2V0QmluZGluZyhCb3JkZXJfYmJjYmJmNTRjMTkzNDcyZGE4MjQxMmM2M2U0ZjM2YmEsIGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlVJRWxlbWVudC5WaXNpYmlsaXR5UHJvcGVydHksIEJpbmRpbmdfMTNiNjE3MjM3Mzg2NDgxZTg4ZjBlMzBjMDI3YjI4ZDgpO1xyXG5cclxuZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuTWVkaWEuQW5pbWF0aW9uLlN0b3J5Ym9hcmQuU2V0VGFyZ2V0UHJvcGVydHkoT2JqZWN0QW5pbWF0aW9uVXNpbmdLZXlGcmFtZXNfMDdkNzU1ZWY4ZmZhNDY0ZmFkYjgxOWY0YjJiNzBkM2MsXHJcbiAgICBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuUHJvcGVydHlQYXRoKFxyXG4gICAgICAgIFwiQmFja2dyb3VuZFwiLFxyXG4gICAgICAgIFwiQmFja2dyb3VuZFwiLFxyXG4gICAgICAgIGFjY2Vzc1Zpc3VhbFN0YXRlUHJvcGVydHlfOTk0ZTJjY2U1OGJkNDQ5MzhlN2UzMTNmOWE5ZTFmYzcsXHJcbiAgICAgICAgc2V0VmlzdWFsU3RhdGVQcm9wZXJ0eV85OTRlMmNjZTU4YmQ0NDkzOGU3ZTMxM2Y5YTllMWZjNyxcclxuICAgICAgICBzZXRBbmltYXRpb25WaXN1YWxTdGF0ZVByb3BlcnR5Xzk5NGUyY2NlNThiZDQ0OTM4ZTdlMzEzZjlhOWUxZmM3LCAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICBzZXRMb2NhbFZpc3VhbFN0YXRlUHJvcGVydHlfOTk0ZTJjY2U1OGJkNDQ5MzhlN2UzMTNmOWE5ZTFmYzcsXHJcbiAgICAgICAgZ2V0VmlzdWFsU3RhdGVQcm9wZXJ0eV85OTRlMmNjZTU4YmQ0NDkzOGU3ZTMxM2Y5YTllMWZjNykpO1xyXG5nbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5NZWRpYS5BbmltYXRpb24uU3Rvcnlib2FyZC5TZXRUYXJnZXQoT2JqZWN0QW5pbWF0aW9uVXNpbmdLZXlGcmFtZXNfMDdkNzU1ZWY4ZmZhNDY0ZmFkYjgxOWY0YjJiNzBkM2MsIEJvcmRlcl9mYTQzZDFjMzAwMmM0MTgxOGRlMDY3OTc2ZWFmOTk2OSk7XHJcblxyXG5cclxuZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuTWVkaWEuQW5pbWF0aW9uLlN0b3J5Ym9hcmQuU2V0VGFyZ2V0UHJvcGVydHkoT2JqZWN0QW5pbWF0aW9uVXNpbmdLZXlGcmFtZXNfZTdhYTZiNjc4YzQ4NGNjOWFlMzc1ZGJmYjFmMDQ3ODgsXHJcbiAgICBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuUHJvcGVydHlQYXRoKFxyXG4gICAgICAgIFwiQmFja2dyb3VuZFwiLFxyXG4gICAgICAgIFwiQmFja2dyb3VuZFwiLFxyXG4gICAgICAgIGFjY2Vzc1Zpc3VhbFN0YXRlUHJvcGVydHlfYzYxNDYxMTdmODI3NDUxMjllMWFhMzgxZDgwZjVhNTksXHJcbiAgICAgICAgc2V0VmlzdWFsU3RhdGVQcm9wZXJ0eV9jNjE0NjExN2Y4Mjc0NTEyOWUxYWEzODFkODBmNWE1OSxcclxuICAgICAgICBzZXRBbmltYXRpb25WaXN1YWxTdGF0ZVByb3BlcnR5X2M2MTQ2MTE3ZjgyNzQ1MTI5ZTFhYTM4MWQ4MGY1YTU5LCAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICBzZXRMb2NhbFZpc3VhbFN0YXRlUHJvcGVydHlfYzYxNDYxMTdmODI3NDUxMjllMWFhMzgxZDgwZjVhNTksXHJcbiAgICAgICAgZ2V0VmlzdWFsU3RhdGVQcm9wZXJ0eV9jNjE0NjExN2Y4Mjc0NTEyOWUxYWEzODFkODBmNWE1OSkpO1xyXG5nbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5NZWRpYS5BbmltYXRpb24uU3Rvcnlib2FyZC5TZXRUYXJnZXQoT2JqZWN0QW5pbWF0aW9uVXNpbmdLZXlGcmFtZXNfZTdhYTZiNjc4YzQ4NGNjOWFlMzc1ZGJmYjFmMDQ3ODgsIEJvcmRlcl9mYTQzZDFjMzAwMmM0MTgxOGRlMDY3OTc2ZWFmOTk2OSk7XHJcblxyXG5cclxuZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuTWVkaWEuQW5pbWF0aW9uLlN0b3J5Ym9hcmQuU2V0VGFyZ2V0UHJvcGVydHkoT2JqZWN0QW5pbWF0aW9uVXNpbmdLZXlGcmFtZXNfY2Y3ZTQwMDJlMzA1NGE2NTkxYWYyNTdiYzEyMmU5YjAsXHJcbiAgICBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuUHJvcGVydHlQYXRoKFxyXG4gICAgICAgIFwiQmFja2dyb3VuZFwiLFxyXG4gICAgICAgIFwiQmFja2dyb3VuZFwiLFxyXG4gICAgICAgIGFjY2Vzc1Zpc3VhbFN0YXRlUHJvcGVydHlfYzM3Mjk0ODE4MmJiNDBiZDgzYzU0MzBiNTdhNzdlNzUsXHJcbiAgICAgICAgc2V0VmlzdWFsU3RhdGVQcm9wZXJ0eV9jMzcyOTQ4MTgyYmI0MGJkODNjNTQzMGI1N2E3N2U3NSxcclxuICAgICAgICBzZXRBbmltYXRpb25WaXN1YWxTdGF0ZVByb3BlcnR5X2MzNzI5NDgxODJiYjQwYmQ4M2M1NDMwYjU3YTc3ZTc1LCAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICBzZXRMb2NhbFZpc3VhbFN0YXRlUHJvcGVydHlfYzM3Mjk0ODE4MmJiNDBiZDgzYzU0MzBiNTdhNzdlNzUsXHJcbiAgICAgICAgZ2V0VmlzdWFsU3RhdGVQcm9wZXJ0eV9jMzcyOTQ4MTgyYmI0MGJkODNjNTQzMGI1N2E3N2U3NSkpO1xyXG5nbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5NZWRpYS5BbmltYXRpb24uU3Rvcnlib2FyZC5TZXRUYXJnZXQoT2JqZWN0QW5pbWF0aW9uVXNpbmdLZXlGcmFtZXNfY2Y3ZTQwMDJlMzA1NGE2NTkxYWYyNTdiYzEyMmU5YjAsIEJvcmRlcl9mYTQzZDFjMzAwMmM0MTgxOGRlMDY3OTc2ZWFmOTk2OSk7XHJcblxyXG50ZW1wbGF0ZUluc3RhbmNlXzJlZjE2ZTBhMTJhMTQ5Y2M5ZjI1OTIzMjUwNDgwNTA4LlRlbXBsYXRlQ29udGVudCA9IEJvcmRlcl9iYmNiYmY1NGMxOTM0NzJkYTgyNDEyYzYzZTRmMzZiYTtcclxucmV0dXJuIHRlbXBsYXRlSW5zdGFuY2VfMmVmMTZlMGExMmExNDljYzlmMjU5MjMyNTA0ODA1MDg7XHJcbn0pKTtcclxuXHJcblNldHRlcl84ZTYwMTE0MzE4MzE0ZmU4OGUxYTBlMzRiMzFjYWQ4Ny5WYWx1ZSA9IENvbnRyb2xUZW1wbGF0ZV9iNTIxODc5MmUwZTY0N2UzOWZjOTEyN2RlNTdkYjJlODtcclxuXHJcblxyXG5TdHlsZV9mYTBlNTE3ZDM3ODA0ZDUxOTA5NTNlNTM4MGMyN2UyZi5TZXR0ZXJzLkFkZChTZXR0ZXJfMmRkZjUxMDBjZGFjNDhmYTllMGMzMDY1MDA3Mzk4Y2EpO1xyXG5TdHlsZV9mYTBlNTE3ZDM3ODA0ZDUxOTA5NTNlNTM4MGMyN2UyZi5TZXR0ZXJzLkFkZChTZXR0ZXJfYWVhOWU0OWEwMjE0NDQ3NGI0NjYyZWQ4ODQ4NDNjNjEpO1xyXG5TdHlsZV9mYTBlNTE3ZDM3ODA0ZDUxOTA5NTNlNTM4MGMyN2UyZi5TZXR0ZXJzLkFkZChTZXR0ZXJfZDZiZjg4OGZlYTA3NDNjYTk2NTQxOWZiMWQ4ZTMyYmQpO1xyXG5TdHlsZV9mYTBlNTE3ZDM3ODA0ZDUxOTA5NTNlNTM4MGMyN2UyZi5TZXR0ZXJzLkFkZChTZXR0ZXJfZDc5NGE3YWMyYmQzNGQ5MGEzNGM4N2VhNDYzNTlmYjUpO1xyXG5TdHlsZV9mYTBlNTE3ZDM3ODA0ZDUxOTA5NTNlNTM4MGMyN2UyZi5TZXR0ZXJzLkFkZChTZXR0ZXJfMWE1NzlhMmRkYTI4NGIzYjk0Y2YyYTNlMjI5YWRmODcpO1xyXG5TdHlsZV9mYTBlNTE3ZDM3ODA0ZDUxOTA5NTNlNTM4MGMyN2UyZi5TZXR0ZXJzLkFkZChTZXR0ZXJfMmIwZDI1YWRiZTA1NDA1N2JjYmYyNWUzOGY4ODAzY2QpO1xyXG5TdHlsZV9mYTBlNTE3ZDM3ODA0ZDUxOTA5NTNlNTM4MGMyN2UyZi5TZXR0ZXJzLkFkZChTZXR0ZXJfYjVmNTRiMjlhNDFkNGQ4Y2JjYmRiOTJkMmZlZDNkY2MpO1xyXG5TdHlsZV9mYTBlNTE3ZDM3ODA0ZDUxOTA5NTNlNTM4MGMyN2UyZi5TZXR0ZXJzLkFkZChTZXR0ZXJfOGU2MDExNDMxODMxNGZlODhlMWEwZTM0YjMxY2FkODcpO1xyXG5cclxuXHJcblJlc291cmNlRGljdGlvbmFyeV9mMGY2NDMxZjE3ZmU0NWNmYjE4OGI4YjIyNmI1NGNkNFtcIkludENvbnZlcnRlclwiXSA9IEludENvbnZlcnRlcl8wY2VkMTI1MzUwYzQ0ZTg3YTNhYmViMDBjOWNjN2U3MTtcclxuUmVzb3VyY2VEaWN0aW9uYXJ5X2YwZjY0MzFmMTdmZTQ1Y2ZiMTg4YjhiMjI2YjU0Y2Q0W1wiRGVjQ29udmVydGVyXCJdID0gRGVjQ29udmVydGVyX2NiZDI5NzRmZTM4OTQzNGNiMmFlMTViYjc1MDQ4NWFkO1xyXG5SZXNvdXJjZURpY3Rpb25hcnlfZjBmNjQzMWYxN2ZlNDVjZmIxODhiOGIyMjZiNTRjZDRbXCJUb1BvbHlMaW5lQ29udmVydGVyXCJdID0gVG9Qb2x5TGluZUNvbnZlcnRlcl8wMTBjNGVlMmU0YTE0MDFkYWE1YTI2NWJmZjI5MWRjYTtcclxuUmVzb3VyY2VEaWN0aW9uYXJ5X2YwZjY0MzFmMTdmZTQ1Y2ZiMTg4YjhiMjI2YjU0Y2Q0W1wiVG9Qb2ludHNDb252ZXJ0ZXJcIl0gPSBUb1BvaW50c0NvbnZlcnRlcl9jYjM5NDk3MjQ4ZTM0ZDIwYjJlMjhjNjgyZTcxOWNiZDtcclxuUmVzb3VyY2VEaWN0aW9uYXJ5X2YwZjY0MzFmMTdmZTQ1Y2ZiMTg4YjhiMjI2YjU0Y2Q0W1wiVG9MaW5lc0NvbnZlcnRlclwiXSA9IFRvTGluZXNDb252ZXJ0ZXJfNjQ5MjQxZTRhYzNhNDgwM2FkNjY0ZDVmMGM3MTg1NDg7XHJcblJlc291cmNlRGljdGlvbmFyeV9mMGY2NDMxZjE3ZmU0NWNmYjE4OGI4YjIyNmI1NGNkNFtcIkFQTENvbG9yQ29udmVydGVyXCJdID0gQVBMQ29sb3JDb252ZXJ0ZXJfMTdlNjFlMzY5YTRmNDZiZTlkNDgwODA1NjYyM2M4MmQ7XHJcblJlc291cmNlRGljdGlvbmFyeV9mMGY2NDMxZjE3ZmU0NWNmYjE4OGI4YjIyNmI1NGNkNFtcIkFQTENvbG9yQ1NTQ29udmVydGVyXCJdID0gQVBMQ29sb3JDU1NDb252ZXJ0ZXJfZjU0MjIwNTdjZTI2NDcxNzlmYmQ4ZmE0NDlhMTllZmY7XHJcblJlc291cmNlRGljdGlvbmFyeV9mMGY2NDMxZjE3ZmU0NWNmYjE4OGI4YjIyNmI1NGNkNFtcIkFQTE11bHRpQ29sb3JDb252ZXJ0ZXJcIl0gPSBBUExNdWx0aUNvbG9yQ29udmVydGVyXzY0MzM0NDVmYjcxZjRjNmJiMWM4ZTYzODlmMDk1ZjhmO1xyXG5SZXNvdXJjZURpY3Rpb25hcnlfZjBmNjQzMWYxN2ZlNDVjZmIxODhiOGIyMjZiNTRjZDRbXCJBUExNdWx0aUNvbG9yQ1NTQ29udmVydGVyXCJdID0gQVBMTXVsdGlDb2xvckNTU0NvbnZlcnRlcl9iMDhjMjU0MTZmYTg0Y2RlYjIxZTVkN2FlNTYzNjU1YztcclxuUmVzb3VyY2VEaWN0aW9uYXJ5X2YwZjY0MzFmMTdmZTQ1Y2ZiMTg4YjhiMjI2YjU0Y2Q0W1wiSW5kZXhJbnQzMkNvbnZlcnRlclwiXSA9IEluZGV4SW50MzJDb252ZXJ0ZXJfYmEyZjRkMDY5YjA3NDBjYjliMzk2YzlmYjFkZDFlMWM7XHJcblJlc291cmNlRGljdGlvbmFyeV9mMGY2NDMxZjE3ZmU0NWNmYjE4OGI4YjIyNmI1NGNkNFtcIkluZGV4RG91YmxlQ29udmVydGVyXCJdID0gSW5kZXhEb3VibGVDb252ZXJ0ZXJfNTM5NTNjY2ZiZDI5NDBlNDhkMjI5ZDk3YmEwODc2NTk7XHJcblJlc291cmNlRGljdGlvbmFyeV9mMGY2NDMxZjE3ZmU0NWNmYjE4OGI4YjIyNmI1NGNkNFtcIkluZGV4U3RyaW5nQ29udmVydGVyXCJdID0gSW5kZXhTdHJpbmdDb252ZXJ0ZXJfNjI5YzFmMTg3ODVlNGZjODllMTcyNWFkZjdmNGVhYjk7XHJcblJlc291cmNlRGljdGlvbmFyeV9mMGY2NDMxZjE3ZmU0NWNmYjE4OGI4YjIyNmI1NGNkNFtcIkluZGV4QVBMQ29sb3JDb252ZXJ0ZXJcIl0gPSBJbmRleEFQTENvbG9yQ29udmVydGVyX2Y0MGM3YWRhY2Y4MDQ5YWZhYzk5YTY5ZGE3MTcwNzUwO1xyXG5SZXNvdXJjZURpY3Rpb25hcnlfZjBmNjQzMWYxN2ZlNDVjZmIxODhiOGIyMjZiNTRjZDRbXCJJbmRleEFQTENvbG91ckNvbnZlcnRlclwiXSA9IEluZGV4QVBMQ29sb3VyQ29udmVydGVyX2FjY2RlNDU3ODIzNzQ4NDQ5ODU0ZmUyZTMzODEyYmUwO1xyXG5SZXNvdXJjZURpY3Rpb25hcnlfZjBmNjQzMWYxN2ZlNDVjZmIxODhiOGIyMjZiNTRjZDRbXCJNYXRoc0lDb252ZXJ0ZXJcIl0gPSBNYXRoc0lDb252ZXJ0ZXJfMzhlMTk0NjYwNWZkNDRjMWJkMTFlMWFlZWMyNDIwMTg7XHJcblJlc291cmNlRGljdGlvbmFyeV9mMGY2NDMxZjE3ZmU0NWNmYjE4OGI4YjIyNmI1NGNkNFtcIk1hdGhzRENvbnZlcnRlclwiXSA9IE1hdGhzRENvbnZlcnRlcl8yNjAxNzA2ODRjNGE0M2JiYjNlODRjMWYwMGI3NGNkMztcclxuUmVzb3VyY2VEaWN0aW9uYXJ5X2YwZjY0MzFmMTdmZTQ1Y2ZiMTg4YjhiMjI2YjU0Y2Q0W1wiTWF0aElDb252ZXJ0ZXJcIl0gPSBNYXRoSUNvbnZlcnRlcl9jY2RjMzgzNTA2MmY0NTRkODRkYzc2MDU2MGY0NzJkYTtcclxuUmVzb3VyY2VEaWN0aW9uYXJ5X2YwZjY0MzFmMTdmZTQ1Y2ZiMTg4YjhiMjI2YjU0Y2Q0W1wiTWF0aERDb252ZXJ0ZXJcIl0gPSBNYXRoRENvbnZlcnRlcl83NTRmYmY4ZTFkNGI0YTY1YjM1OWQ3MjNlYzVmMTQwMjtcclxuUmVzb3VyY2VEaWN0aW9uYXJ5X2YwZjY0MzFmMTdmZTQ1Y2ZiMTg4YjhiMjI2YjU0Y2Q0W1wiQXBwbGljYXRpb25cIl0gPSBTdHJpbmdfMzExMjdhN2RlZmFmNDA2YzgwNTIxMjdlN2Q2MTY3ZmU7XHJcblJlc291cmNlRGljdGlvbmFyeV9mMGY2NDMxZjE3ZmU0NWNmYjE4OGI4YjIyNmI1NGNkNFtcIk93bmVyXCJdID0gU3RyaW5nX2M0MDFiYTFmZGEyNzQ2ZjFhMzI2ZTdmYTc4YjY4MjU1O1xyXG5SZXNvdXJjZURpY3Rpb25hcnlfZjBmNjQzMWYxN2ZlNDVjZmIxODhiOGIyMjZiNTRjZDRbXCJDb21wYW55XCJdID0gU3RyaW5nXzM1YzJlOWQ0YWY1NzQ2MjFiMzEyZGRhYjRlMzMzMmE2O1xyXG5SZXNvdXJjZURpY3Rpb25hcnlfZjBmNjQzMWYxN2ZlNDVjZmIxODhiOGIyMjZiNTRjZDRbXCJOYW1lXCJdID0gU3RyaW5nX2U1ZWFhOWIxZjQ5NTQ3NTY4ZWI4N2RkZGM0ZTg3Y2I2O1xyXG5SZXNvdXJjZURpY3Rpb25hcnlfZjBmNjQzMWYxN2ZlNDVjZmIxODhiOGIyMjZiNTRjZDRbXCJUaXRsZVwiXSA9IFN0cmluZ18wMWNlMGQzYTRmZjY0NDM2OGE4OWZkNjZhY2YxNjJmZjtcclxuUmVzb3VyY2VEaWN0aW9uYXJ5X2YwZjY0MzFmMTdmZTQ1Y2ZiMTg4YjhiMjI2YjU0Y2Q0W1wiRmF2SWNvblwiXSA9IFN0cmluZ183YzJkMzE0OWEzNzA0OTE1YjE2ZGRhYjA3YWRmMmY5NTtcclxuUmVzb3VyY2VEaWN0aW9uYXJ5X2YwZjY0MzFmMTdmZTQ1Y2ZiMTg4YjhiMjI2YjU0Y2Q0W1wiUG9ydFwiXSA9IFN0cmluZ19lNzk2N2EyMjQ0MTQ0NDEwYjMwOWM3Mzc3MjhlMjlhYjtcclxuUmVzb3VyY2VEaWN0aW9uYXJ5X2YwZjY0MzFmMTdmZTQ1Y2ZiMTg4YjhiMjI2YjU0Y2Q0W1wiTWFpblwiXSA9IFN0cmluZ183M2RlZGNiMzEwOTM0ZGFkOWEzNmM3ZWY5NDg2OTE4YztcclxuUmVzb3VyY2VEaWN0aW9uYXJ5X2YwZjY0MzFmMTdmZTQ1Y2ZiMTg4YjhiMjI2YjU0Y2Q0W1wiQmFzZVwiXSA9IFN0cmluZ18zZjY2NDk0ZDA4NzE0ODE3YmQxNWUzOGIzMDhhOWViNDtcclxuUmVzb3VyY2VEaWN0aW9uYXJ5X2YwZjY0MzFmMTdmZTQ1Y2ZiMTg4YjhiMjI2YjU0Y2Q0W1wiQ29ubmVjdGlvblR5cGVcIl0gPSBTdHJpbmdfZTAwZjIyYTMyNmJjNDU4MWI0OTdiODg0NDYyOTY0Zjg7XHJcblJlc291cmNlRGljdGlvbmFyeV9mMGY2NDMxZjE3ZmU0NWNmYjE4OGI4YjIyNmI1NGNkNFtcIk5hbWVzcGFjZVwiXSA9IFN0cmluZ181M2Q2MGRmY2YzZTE0MWQyYjczYjg4OTJiM2Q1YTFjMDtcclxuUmVzb3VyY2VEaWN0aW9uYXJ5X2YwZjY0MzFmMTdmZTQ1Y2ZiMTg4YjhiMjI2YjU0Y2Q0W1wiQVBMRm9ybVN0eWxlXCJdID0gU3R5bGVfMjJhMWJkZWQwMzFhNDc1YWExNTUzOTM0MmVjOTYwMjE7XHJcblJlc291cmNlRGljdGlvbmFyeV9mMGY2NDMxZjE3ZmU0NWNmYjE4OGI4YjIyNmI1NGNkNFtcIkJ1dHRvblN0eWxlMVwiXSA9IFN0eWxlX2ZhMGU1MTdkMzc4MDRkNTE5MDk1M2U1MzgwYzI3ZTJmO1xyXG5cclxudGhpcy5SZXNvdXJjZXMgPSBSZXNvdXJjZURpY3Rpb25hcnlfZjBmNjQzMWYxN2ZlNDVjZmIxODhiOGIyMjZiNTRjZDQ7XHJcblxyXG5cclxuXHJcblxyXG5cclxuXHJcbiAgICBcclxuICAgICAgICB9XHJcblxyXG5cclxuXHJcbnB1YmxpYyBnbG9iYWw6OlN5c3RlbS5Db2xsZWN0aW9ucy5HZW5lcmljLklFbnVtZXJhYmxlPGdsb2JhbDo6U3lzdGVtLlR1cGxlPGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRlcGVuZGVuY3lPYmplY3QsIGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRlcGVuZGVuY3lQcm9wZXJ0eSwgaW50Pz4+IGFjY2Vzc1Zpc3VhbFN0YXRlUHJvcGVydHlfMTAyYjcwZDZmOTFiNDUwM2FjMjE4OWQyMjk2YmFhNjEgKGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRlcGVuZGVuY3lPYmplY3Qgcm9vdFRhcmdldE9iamVjdEluc3RhbmNlKVxyXG57XHJcbiAgXHJcbnlpZWxkIGJyZWFrO1xyXG59XHJcblxyXG5cclxucHVibGljIHZvaWQgc2V0VmlzdWFsU3RhdGVQcm9wZXJ0eV8xMDJiNzBkNmY5MWI0NTAzYWMyMTg5ZDIyOTZiYWE2MSAoZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGVwZW5kZW5jeU9iamVjdCBmaW5hbFRhcmdldEluc3RhbmNlLCBvYmplY3QgdmFsdWUpXHJcbntcclxuICBcclxuZ2xvYmFsOjpTeXN0ZW0uVHlwZSBmaW5hbFRhcmdldEluc3RhbmNlVHlwZSA9IGZpbmFsVGFyZ2V0SW5zdGFuY2UuR2V0VHlwZSgpO1xyXG5nbG9iYWw6OlN5c3RlbS5UeXBlIHByb3BlcnR5RGVjbGFyaW5nVHlwZSA9IGZpbmFsVGFyZ2V0SW5zdGFuY2VUeXBlLkdldFByb3BlcnR5KFwiQmFja2dyb3VuZFwiKS5EZWNsYXJpbmdUeXBlO1xyXG5nbG9iYWw6OlN5c3RlbS5SZWZsZWN0aW9uLkZpZWxkSW5mbyBwcm9wZXJ0eUZpZWxkID0gcHJvcGVydHlEZWNsYXJpbmdUeXBlLkdldEZpZWxkKFwiQmFja2dyb3VuZFByb3BlcnR5XCIpO1xyXG5nbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EZXBlbmRlbmN5UHJvcGVydHkgcHJvcGVydHkgPSAoZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGVwZW5kZW5jeVByb3BlcnR5KXByb3BlcnR5RmllbGQuR2V0VmFsdWUobnVsbCk7XHJcblxyXG4gIChmaW5hbFRhcmdldEluc3RhbmNlKS5TZXRWaXN1YWxTdGF0ZVZhbHVlKHByb3BlcnR5LCB2YWx1ZSk7XHJcbn1cclxuXHJcblxyXG5wdWJsaWMgdm9pZCBzZXRBbmltYXRpb25WaXN1YWxTdGF0ZVByb3BlcnR5XzEwMmI3MGQ2ZjkxYjQ1MDNhYzIxODlkMjI5NmJhYTYxIChnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EZXBlbmRlbmN5T2JqZWN0IGZpbmFsVGFyZ2V0SW5zdGFuY2UsIG9iamVjdCB2YWx1ZSlcclxue1xyXG4gIFxyXG5nbG9iYWw6OlN5c3RlbS5UeXBlIGZpbmFsVGFyZ2V0SW5zdGFuY2VUeXBlID0gZmluYWxUYXJnZXRJbnN0YW5jZS5HZXRUeXBlKCk7XHJcbmdsb2JhbDo6U3lzdGVtLlR5cGUgcHJvcGVydHlEZWNsYXJpbmdUeXBlID0gZmluYWxUYXJnZXRJbnN0YW5jZVR5cGUuR2V0UHJvcGVydHkoXCJCYWNrZ3JvdW5kXCIpLkRlY2xhcmluZ1R5cGU7XHJcbmdsb2JhbDo6U3lzdGVtLlJlZmxlY3Rpb24uRmllbGRJbmZvIHByb3BlcnR5RmllbGQgPSBwcm9wZXJ0eURlY2xhcmluZ1R5cGUuR2V0RmllbGQoXCJCYWNrZ3JvdW5kUHJvcGVydHlcIik7XHJcbmdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRlcGVuZGVuY3lQcm9wZXJ0eSBwcm9wZXJ0eSA9IChnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EZXBlbmRlbmN5UHJvcGVydHkpcHJvcGVydHlGaWVsZC5HZXRWYWx1ZShudWxsKTtcclxuXHJcbiAgKGZpbmFsVGFyZ2V0SW5zdGFuY2UpLlNldEFuaW1hdGlvblZhbHVlKHByb3BlcnR5LCB2YWx1ZSk7XHJcbn1cclxuXHJcblxyXG5wdWJsaWMgdm9pZCBzZXRMb2NhbFZpc3VhbFN0YXRlUHJvcGVydHlfMTAyYjcwZDZmOTFiNDUwM2FjMjE4OWQyMjk2YmFhNjEgKGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRlcGVuZGVuY3lPYmplY3QgZmluYWxUYXJnZXRJbnN0YW5jZSwgb2JqZWN0IHZhbHVlKVxyXG57XHJcbiAgXHJcbmdsb2JhbDo6U3lzdGVtLlR5cGUgZmluYWxUYXJnZXRJbnN0YW5jZVR5cGUgPSBmaW5hbFRhcmdldEluc3RhbmNlLkdldFR5cGUoKTtcclxuZ2xvYmFsOjpTeXN0ZW0uVHlwZSBwcm9wZXJ0eURlY2xhcmluZ1R5cGUgPSBmaW5hbFRhcmdldEluc3RhbmNlVHlwZS5HZXRQcm9wZXJ0eShcIkJhY2tncm91bmRcIikuRGVjbGFyaW5nVHlwZTtcclxuZ2xvYmFsOjpTeXN0ZW0uUmVmbGVjdGlvbi5GaWVsZEluZm8gcHJvcGVydHlGaWVsZCA9IHByb3BlcnR5RGVjbGFyaW5nVHlwZS5HZXRGaWVsZChcIkJhY2tncm91bmRQcm9wZXJ0eVwiKTtcclxuZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGVwZW5kZW5jeVByb3BlcnR5IHByb3BlcnR5ID0gKGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRlcGVuZGVuY3lQcm9wZXJ0eSlwcm9wZXJ0eUZpZWxkLkdldFZhbHVlKG51bGwpO1xyXG5cclxuICAoZmluYWxUYXJnZXRJbnN0YW5jZSkuU2V0Q3VycmVudFZhbHVlKHByb3BlcnR5LCB2YWx1ZSk7XHJcbn1cclxuXHJcblxyXG5wdWJsaWMgZ2xvYmFsOjpTeXN0ZW0uT2JqZWN0IGdldFZpc3VhbFN0YXRlUHJvcGVydHlfMTAyYjcwZDZmOTFiNDUwM2FjMjE4OWQyMjk2YmFhNjEgKGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRlcGVuZGVuY3lPYmplY3QgZmluYWxUYXJnZXRJbnN0YW5jZSlcclxue1xyXG4gIFxyXG5nbG9iYWw6OlN5c3RlbS5UeXBlIGZpbmFsVGFyZ2V0SW5zdGFuY2VUeXBlID0gZmluYWxUYXJnZXRJbnN0YW5jZS5HZXRUeXBlKCk7XHJcbmdsb2JhbDo6U3lzdGVtLlR5cGUgcHJvcGVydHlEZWNsYXJpbmdUeXBlID0gZmluYWxUYXJnZXRJbnN0YW5jZVR5cGUuR2V0UHJvcGVydHkoXCJCYWNrZ3JvdW5kXCIpLkRlY2xhcmluZ1R5cGU7XHJcbmdsb2JhbDo6U3lzdGVtLlJlZmxlY3Rpb24uRmllbGRJbmZvIHByb3BlcnR5RmllbGQgPSBwcm9wZXJ0eURlY2xhcmluZ1R5cGUuR2V0RmllbGQoXCJCYWNrZ3JvdW5kUHJvcGVydHlcIik7XHJcbmdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRlcGVuZGVuY3lQcm9wZXJ0eSBwcm9wZXJ0eSA9IChnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EZXBlbmRlbmN5UHJvcGVydHkpcHJvcGVydHlGaWVsZC5HZXRWYWx1ZShudWxsKTtcclxuXHJcbiAgcmV0dXJuIGZpbmFsVGFyZ2V0SW5zdGFuY2UuR2V0VmlzdWFsU3RhdGVWYWx1ZShwcm9wZXJ0eSk7XHJcbn1cclxuXHJcblxyXG5wdWJsaWMgZ2xvYmFsOjpTeXN0ZW0uQ29sbGVjdGlvbnMuR2VuZXJpYy5JRW51bWVyYWJsZTxnbG9iYWw6OlN5c3RlbS5UdXBsZTxnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EZXBlbmRlbmN5T2JqZWN0LCBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EZXBlbmRlbmN5UHJvcGVydHksIGludD8+PiBhY2Nlc3NWaXN1YWxTdGF0ZVByb3BlcnR5X2FlZGNiOGY1ZTc5MjQzMWM4ZjM0NjkxYWZjYzRiNjJjIChnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EZXBlbmRlbmN5T2JqZWN0IHJvb3RUYXJnZXRPYmplY3RJbnN0YW5jZSlcclxue1xyXG4gIFxyXG55aWVsZCBicmVhaztcclxufVxyXG5cclxuXHJcbnB1YmxpYyB2b2lkIHNldFZpc3VhbFN0YXRlUHJvcGVydHlfYWVkY2I4ZjVlNzkyNDMxYzhmMzQ2OTFhZmNjNGI2MmMgKGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRlcGVuZGVuY3lPYmplY3QgZmluYWxUYXJnZXRJbnN0YW5jZSwgb2JqZWN0IHZhbHVlKVxyXG57XHJcbiAgXHJcbmdsb2JhbDo6U3lzdGVtLlR5cGUgZmluYWxUYXJnZXRJbnN0YW5jZVR5cGUgPSBmaW5hbFRhcmdldEluc3RhbmNlLkdldFR5cGUoKTtcclxuZ2xvYmFsOjpTeXN0ZW0uVHlwZSBwcm9wZXJ0eURlY2xhcmluZ1R5cGUgPSBmaW5hbFRhcmdldEluc3RhbmNlVHlwZS5HZXRQcm9wZXJ0eShcIklzSGl0VGVzdFZpc2libGVcIikuRGVjbGFyaW5nVHlwZTtcclxuZ2xvYmFsOjpTeXN0ZW0uUmVmbGVjdGlvbi5GaWVsZEluZm8gcHJvcGVydHlGaWVsZCA9IHByb3BlcnR5RGVjbGFyaW5nVHlwZS5HZXRGaWVsZChcIklzSGl0VGVzdFZpc2libGVQcm9wZXJ0eVwiKTtcclxuZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGVwZW5kZW5jeVByb3BlcnR5IHByb3BlcnR5ID0gKGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRlcGVuZGVuY3lQcm9wZXJ0eSlwcm9wZXJ0eUZpZWxkLkdldFZhbHVlKG51bGwpO1xyXG5cclxuICAoZmluYWxUYXJnZXRJbnN0YW5jZSkuU2V0VmlzdWFsU3RhdGVWYWx1ZShwcm9wZXJ0eSwgdmFsdWUpO1xyXG59XHJcblxyXG5cclxucHVibGljIHZvaWQgc2V0QW5pbWF0aW9uVmlzdWFsU3RhdGVQcm9wZXJ0eV9hZWRjYjhmNWU3OTI0MzFjOGYzNDY5MWFmY2M0YjYyYyAoZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGVwZW5kZW5jeU9iamVjdCBmaW5hbFRhcmdldEluc3RhbmNlLCBvYmplY3QgdmFsdWUpXHJcbntcclxuICBcclxuZ2xvYmFsOjpTeXN0ZW0uVHlwZSBmaW5hbFRhcmdldEluc3RhbmNlVHlwZSA9IGZpbmFsVGFyZ2V0SW5zdGFuY2UuR2V0VHlwZSgpO1xyXG5nbG9iYWw6OlN5c3RlbS5UeXBlIHByb3BlcnR5RGVjbGFyaW5nVHlwZSA9IGZpbmFsVGFyZ2V0SW5zdGFuY2VUeXBlLkdldFByb3BlcnR5KFwiSXNIaXRUZXN0VmlzaWJsZVwiKS5EZWNsYXJpbmdUeXBlO1xyXG5nbG9iYWw6OlN5c3RlbS5SZWZsZWN0aW9uLkZpZWxkSW5mbyBwcm9wZXJ0eUZpZWxkID0gcHJvcGVydHlEZWNsYXJpbmdUeXBlLkdldEZpZWxkKFwiSXNIaXRUZXN0VmlzaWJsZVByb3BlcnR5XCIpO1xyXG5nbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EZXBlbmRlbmN5UHJvcGVydHkgcHJvcGVydHkgPSAoZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGVwZW5kZW5jeVByb3BlcnR5KXByb3BlcnR5RmllbGQuR2V0VmFsdWUobnVsbCk7XHJcblxyXG4gIChmaW5hbFRhcmdldEluc3RhbmNlKS5TZXRBbmltYXRpb25WYWx1ZShwcm9wZXJ0eSwgdmFsdWUpO1xyXG59XHJcblxyXG5cclxucHVibGljIHZvaWQgc2V0TG9jYWxWaXN1YWxTdGF0ZVByb3BlcnR5X2FlZGNiOGY1ZTc5MjQzMWM4ZjM0NjkxYWZjYzRiNjJjIChnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EZXBlbmRlbmN5T2JqZWN0IGZpbmFsVGFyZ2V0SW5zdGFuY2UsIG9iamVjdCB2YWx1ZSlcclxue1xyXG4gIFxyXG5nbG9iYWw6OlN5c3RlbS5UeXBlIGZpbmFsVGFyZ2V0SW5zdGFuY2VUeXBlID0gZmluYWxUYXJnZXRJbnN0YW5jZS5HZXRUeXBlKCk7XHJcbmdsb2JhbDo6U3lzdGVtLlR5cGUgcHJvcGVydHlEZWNsYXJpbmdUeXBlID0gZmluYWxUYXJnZXRJbnN0YW5jZVR5cGUuR2V0UHJvcGVydHkoXCJJc0hpdFRlc3RWaXNpYmxlXCIpLkRlY2xhcmluZ1R5cGU7XHJcbmdsb2JhbDo6U3lzdGVtLlJlZmxlY3Rpb24uRmllbGRJbmZvIHByb3BlcnR5RmllbGQgPSBwcm9wZXJ0eURlY2xhcmluZ1R5cGUuR2V0RmllbGQoXCJJc0hpdFRlc3RWaXNpYmxlUHJvcGVydHlcIik7XHJcbmdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRlcGVuZGVuY3lQcm9wZXJ0eSBwcm9wZXJ0eSA9IChnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EZXBlbmRlbmN5UHJvcGVydHkpcHJvcGVydHlGaWVsZC5HZXRWYWx1ZShudWxsKTtcclxuXHJcbiAgKGZpbmFsVGFyZ2V0SW5zdGFuY2UpLlNldEN1cnJlbnRWYWx1ZShwcm9wZXJ0eSwgdmFsdWUpO1xyXG59XHJcblxyXG5cclxucHVibGljIGdsb2JhbDo6U3lzdGVtLk9iamVjdCBnZXRWaXN1YWxTdGF0ZVByb3BlcnR5X2FlZGNiOGY1ZTc5MjQzMWM4ZjM0NjkxYWZjYzRiNjJjIChnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EZXBlbmRlbmN5T2JqZWN0IGZpbmFsVGFyZ2V0SW5zdGFuY2UpXHJcbntcclxuICBcclxuZ2xvYmFsOjpTeXN0ZW0uVHlwZSBmaW5hbFRhcmdldEluc3RhbmNlVHlwZSA9IGZpbmFsVGFyZ2V0SW5zdGFuY2UuR2V0VHlwZSgpO1xyXG5nbG9iYWw6OlN5c3RlbS5UeXBlIHByb3BlcnR5RGVjbGFyaW5nVHlwZSA9IGZpbmFsVGFyZ2V0SW5zdGFuY2VUeXBlLkdldFByb3BlcnR5KFwiSXNIaXRUZXN0VmlzaWJsZVwiKS5EZWNsYXJpbmdUeXBlO1xyXG5nbG9iYWw6OlN5c3RlbS5SZWZsZWN0aW9uLkZpZWxkSW5mbyBwcm9wZXJ0eUZpZWxkID0gcHJvcGVydHlEZWNsYXJpbmdUeXBlLkdldEZpZWxkKFwiSXNIaXRUZXN0VmlzaWJsZVByb3BlcnR5XCIpO1xyXG5nbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EZXBlbmRlbmN5UHJvcGVydHkgcHJvcGVydHkgPSAoZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGVwZW5kZW5jeVByb3BlcnR5KXByb3BlcnR5RmllbGQuR2V0VmFsdWUobnVsbCk7XHJcblxyXG4gIHJldHVybiBmaW5hbFRhcmdldEluc3RhbmNlLkdldFZpc3VhbFN0YXRlVmFsdWUocHJvcGVydHkpO1xyXG59XHJcblxyXG5cclxucHVibGljIGdsb2JhbDo6U3lzdGVtLkNvbGxlY3Rpb25zLkdlbmVyaWMuSUVudW1lcmFibGU8Z2xvYmFsOjpTeXN0ZW0uVHVwbGU8Z2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGVwZW5kZW5jeU9iamVjdCwgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGVwZW5kZW5jeVByb3BlcnR5LCBpbnQ/Pj4gYWNjZXNzVmlzdWFsU3RhdGVQcm9wZXJ0eV85OTRlMmNjZTU4YmQ0NDkzOGU3ZTMxM2Y5YTllMWZjNyAoZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGVwZW5kZW5jeU9iamVjdCByb290VGFyZ2V0T2JqZWN0SW5zdGFuY2UpXHJcbntcclxuICBcclxueWllbGQgYnJlYWs7XHJcbn1cclxuXHJcblxyXG5wdWJsaWMgdm9pZCBzZXRWaXN1YWxTdGF0ZVByb3BlcnR5Xzk5NGUyY2NlNThiZDQ0OTM4ZTdlMzEzZjlhOWUxZmM3IChnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EZXBlbmRlbmN5T2JqZWN0IGZpbmFsVGFyZ2V0SW5zdGFuY2UsIG9iamVjdCB2YWx1ZSlcclxue1xyXG4gIFxyXG5nbG9iYWw6OlN5c3RlbS5UeXBlIGZpbmFsVGFyZ2V0SW5zdGFuY2VUeXBlID0gZmluYWxUYXJnZXRJbnN0YW5jZS5HZXRUeXBlKCk7XHJcbmdsb2JhbDo6U3lzdGVtLlR5cGUgcHJvcGVydHlEZWNsYXJpbmdUeXBlID0gZmluYWxUYXJnZXRJbnN0YW5jZVR5cGUuR2V0UHJvcGVydHkoXCJCYWNrZ3JvdW5kXCIpLkRlY2xhcmluZ1R5cGU7XHJcbmdsb2JhbDo6U3lzdGVtLlJlZmxlY3Rpb24uRmllbGRJbmZvIHByb3BlcnR5RmllbGQgPSBwcm9wZXJ0eURlY2xhcmluZ1R5cGUuR2V0RmllbGQoXCJCYWNrZ3JvdW5kUHJvcGVydHlcIik7XHJcbmdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRlcGVuZGVuY3lQcm9wZXJ0eSBwcm9wZXJ0eSA9IChnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EZXBlbmRlbmN5UHJvcGVydHkpcHJvcGVydHlGaWVsZC5HZXRWYWx1ZShudWxsKTtcclxuXHJcbiAgKGZpbmFsVGFyZ2V0SW5zdGFuY2UpLlNldFZpc3VhbFN0YXRlVmFsdWUocHJvcGVydHksIHZhbHVlKTtcclxufVxyXG5cclxuXHJcbnB1YmxpYyB2b2lkIHNldEFuaW1hdGlvblZpc3VhbFN0YXRlUHJvcGVydHlfOTk0ZTJjY2U1OGJkNDQ5MzhlN2UzMTNmOWE5ZTFmYzcgKGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRlcGVuZGVuY3lPYmplY3QgZmluYWxUYXJnZXRJbnN0YW5jZSwgb2JqZWN0IHZhbHVlKVxyXG57XHJcbiAgXHJcbmdsb2JhbDo6U3lzdGVtLlR5cGUgZmluYWxUYXJnZXRJbnN0YW5jZVR5cGUgPSBmaW5hbFRhcmdldEluc3RhbmNlLkdldFR5cGUoKTtcclxuZ2xvYmFsOjpTeXN0ZW0uVHlwZSBwcm9wZXJ0eURlY2xhcmluZ1R5cGUgPSBmaW5hbFRhcmdldEluc3RhbmNlVHlwZS5HZXRQcm9wZXJ0eShcIkJhY2tncm91bmRcIikuRGVjbGFyaW5nVHlwZTtcclxuZ2xvYmFsOjpTeXN0ZW0uUmVmbGVjdGlvbi5GaWVsZEluZm8gcHJvcGVydHlGaWVsZCA9IHByb3BlcnR5RGVjbGFyaW5nVHlwZS5HZXRGaWVsZChcIkJhY2tncm91bmRQcm9wZXJ0eVwiKTtcclxuZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGVwZW5kZW5jeVByb3BlcnR5IHByb3BlcnR5ID0gKGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRlcGVuZGVuY3lQcm9wZXJ0eSlwcm9wZXJ0eUZpZWxkLkdldFZhbHVlKG51bGwpO1xyXG5cclxuICAoZmluYWxUYXJnZXRJbnN0YW5jZSkuU2V0QW5pbWF0aW9uVmFsdWUocHJvcGVydHksIHZhbHVlKTtcclxufVxyXG5cclxuXHJcbnB1YmxpYyB2b2lkIHNldExvY2FsVmlzdWFsU3RhdGVQcm9wZXJ0eV85OTRlMmNjZTU4YmQ0NDkzOGU3ZTMxM2Y5YTllMWZjNyAoZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGVwZW5kZW5jeU9iamVjdCBmaW5hbFRhcmdldEluc3RhbmNlLCBvYmplY3QgdmFsdWUpXHJcbntcclxuICBcclxuZ2xvYmFsOjpTeXN0ZW0uVHlwZSBmaW5hbFRhcmdldEluc3RhbmNlVHlwZSA9IGZpbmFsVGFyZ2V0SW5zdGFuY2UuR2V0VHlwZSgpO1xyXG5nbG9iYWw6OlN5c3RlbS5UeXBlIHByb3BlcnR5RGVjbGFyaW5nVHlwZSA9IGZpbmFsVGFyZ2V0SW5zdGFuY2VUeXBlLkdldFByb3BlcnR5KFwiQmFja2dyb3VuZFwiKS5EZWNsYXJpbmdUeXBlO1xyXG5nbG9iYWw6OlN5c3RlbS5SZWZsZWN0aW9uLkZpZWxkSW5mbyBwcm9wZXJ0eUZpZWxkID0gcHJvcGVydHlEZWNsYXJpbmdUeXBlLkdldEZpZWxkKFwiQmFja2dyb3VuZFByb3BlcnR5XCIpO1xyXG5nbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EZXBlbmRlbmN5UHJvcGVydHkgcHJvcGVydHkgPSAoZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGVwZW5kZW5jeVByb3BlcnR5KXByb3BlcnR5RmllbGQuR2V0VmFsdWUobnVsbCk7XHJcblxyXG4gIChmaW5hbFRhcmdldEluc3RhbmNlKS5TZXRDdXJyZW50VmFsdWUocHJvcGVydHksIHZhbHVlKTtcclxufVxyXG5cclxuXHJcbnB1YmxpYyBnbG9iYWw6OlN5c3RlbS5PYmplY3QgZ2V0VmlzdWFsU3RhdGVQcm9wZXJ0eV85OTRlMmNjZTU4YmQ0NDkzOGU3ZTMxM2Y5YTllMWZjNyAoZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGVwZW5kZW5jeU9iamVjdCBmaW5hbFRhcmdldEluc3RhbmNlKVxyXG57XHJcbiAgXHJcbmdsb2JhbDo6U3lzdGVtLlR5cGUgZmluYWxUYXJnZXRJbnN0YW5jZVR5cGUgPSBmaW5hbFRhcmdldEluc3RhbmNlLkdldFR5cGUoKTtcclxuZ2xvYmFsOjpTeXN0ZW0uVHlwZSBwcm9wZXJ0eURlY2xhcmluZ1R5cGUgPSBmaW5hbFRhcmdldEluc3RhbmNlVHlwZS5HZXRQcm9wZXJ0eShcIkJhY2tncm91bmRcIikuRGVjbGFyaW5nVHlwZTtcclxuZ2xvYmFsOjpTeXN0ZW0uUmVmbGVjdGlvbi5GaWVsZEluZm8gcHJvcGVydHlGaWVsZCA9IHByb3BlcnR5RGVjbGFyaW5nVHlwZS5HZXRGaWVsZChcIkJhY2tncm91bmRQcm9wZXJ0eVwiKTtcclxuZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGVwZW5kZW5jeVByb3BlcnR5IHByb3BlcnR5ID0gKGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRlcGVuZGVuY3lQcm9wZXJ0eSlwcm9wZXJ0eUZpZWxkLkdldFZhbHVlKG51bGwpO1xyXG5cclxuICByZXR1cm4gZmluYWxUYXJnZXRJbnN0YW5jZS5HZXRWaXN1YWxTdGF0ZVZhbHVlKHByb3BlcnR5KTtcclxufVxyXG5cclxuXHJcbnB1YmxpYyBnbG9iYWw6OlN5c3RlbS5Db2xsZWN0aW9ucy5HZW5lcmljLklFbnVtZXJhYmxlPGdsb2JhbDo6U3lzdGVtLlR1cGxlPGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRlcGVuZGVuY3lPYmplY3QsIGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRlcGVuZGVuY3lQcm9wZXJ0eSwgaW50Pz4+IGFjY2Vzc1Zpc3VhbFN0YXRlUHJvcGVydHlfYzYxNDYxMTdmODI3NDUxMjllMWFhMzgxZDgwZjVhNTkgKGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRlcGVuZGVuY3lPYmplY3Qgcm9vdFRhcmdldE9iamVjdEluc3RhbmNlKVxyXG57XHJcbiAgXHJcbnlpZWxkIGJyZWFrO1xyXG59XHJcblxyXG5cclxucHVibGljIHZvaWQgc2V0VmlzdWFsU3RhdGVQcm9wZXJ0eV9jNjE0NjExN2Y4Mjc0NTEyOWUxYWEzODFkODBmNWE1OSAoZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGVwZW5kZW5jeU9iamVjdCBmaW5hbFRhcmdldEluc3RhbmNlLCBvYmplY3QgdmFsdWUpXHJcbntcclxuICBcclxuZ2xvYmFsOjpTeXN0ZW0uVHlwZSBmaW5hbFRhcmdldEluc3RhbmNlVHlwZSA9IGZpbmFsVGFyZ2V0SW5zdGFuY2UuR2V0VHlwZSgpO1xyXG5nbG9iYWw6OlN5c3RlbS5UeXBlIHByb3BlcnR5RGVjbGFyaW5nVHlwZSA9IGZpbmFsVGFyZ2V0SW5zdGFuY2VUeXBlLkdldFByb3BlcnR5KFwiQmFja2dyb3VuZFwiKS5EZWNsYXJpbmdUeXBlO1xyXG5nbG9iYWw6OlN5c3RlbS5SZWZsZWN0aW9uLkZpZWxkSW5mbyBwcm9wZXJ0eUZpZWxkID0gcHJvcGVydHlEZWNsYXJpbmdUeXBlLkdldEZpZWxkKFwiQmFja2dyb3VuZFByb3BlcnR5XCIpO1xyXG5nbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EZXBlbmRlbmN5UHJvcGVydHkgcHJvcGVydHkgPSAoZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGVwZW5kZW5jeVByb3BlcnR5KXByb3BlcnR5RmllbGQuR2V0VmFsdWUobnVsbCk7XHJcblxyXG4gIChmaW5hbFRhcmdldEluc3RhbmNlKS5TZXRWaXN1YWxTdGF0ZVZhbHVlKHByb3BlcnR5LCB2YWx1ZSk7XHJcbn1cclxuXHJcblxyXG5wdWJsaWMgdm9pZCBzZXRBbmltYXRpb25WaXN1YWxTdGF0ZVByb3BlcnR5X2M2MTQ2MTE3ZjgyNzQ1MTI5ZTFhYTM4MWQ4MGY1YTU5IChnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EZXBlbmRlbmN5T2JqZWN0IGZpbmFsVGFyZ2V0SW5zdGFuY2UsIG9iamVjdCB2YWx1ZSlcclxue1xyXG4gIFxyXG5nbG9iYWw6OlN5c3RlbS5UeXBlIGZpbmFsVGFyZ2V0SW5zdGFuY2VUeXBlID0gZmluYWxUYXJnZXRJbnN0YW5jZS5HZXRUeXBlKCk7XHJcbmdsb2JhbDo6U3lzdGVtLlR5cGUgcHJvcGVydHlEZWNsYXJpbmdUeXBlID0gZmluYWxUYXJnZXRJbnN0YW5jZVR5cGUuR2V0UHJvcGVydHkoXCJCYWNrZ3JvdW5kXCIpLkRlY2xhcmluZ1R5cGU7XHJcbmdsb2JhbDo6U3lzdGVtLlJlZmxlY3Rpb24uRmllbGRJbmZvIHByb3BlcnR5RmllbGQgPSBwcm9wZXJ0eURlY2xhcmluZ1R5cGUuR2V0RmllbGQoXCJCYWNrZ3JvdW5kUHJvcGVydHlcIik7XHJcbmdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRlcGVuZGVuY3lQcm9wZXJ0eSBwcm9wZXJ0eSA9IChnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EZXBlbmRlbmN5UHJvcGVydHkpcHJvcGVydHlGaWVsZC5HZXRWYWx1ZShudWxsKTtcclxuXHJcbiAgKGZpbmFsVGFyZ2V0SW5zdGFuY2UpLlNldEFuaW1hdGlvblZhbHVlKHByb3BlcnR5LCB2YWx1ZSk7XHJcbn1cclxuXHJcblxyXG5wdWJsaWMgdm9pZCBzZXRMb2NhbFZpc3VhbFN0YXRlUHJvcGVydHlfYzYxNDYxMTdmODI3NDUxMjllMWFhMzgxZDgwZjVhNTkgKGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRlcGVuZGVuY3lPYmplY3QgZmluYWxUYXJnZXRJbnN0YW5jZSwgb2JqZWN0IHZhbHVlKVxyXG57XHJcbiAgXHJcbmdsb2JhbDo6U3lzdGVtLlR5cGUgZmluYWxUYXJnZXRJbnN0YW5jZVR5cGUgPSBmaW5hbFRhcmdldEluc3RhbmNlLkdldFR5cGUoKTtcclxuZ2xvYmFsOjpTeXN0ZW0uVHlwZSBwcm9wZXJ0eURlY2xhcmluZ1R5cGUgPSBmaW5hbFRhcmdldEluc3RhbmNlVHlwZS5HZXRQcm9wZXJ0eShcIkJhY2tncm91bmRcIikuRGVjbGFyaW5nVHlwZTtcclxuZ2xvYmFsOjpTeXN0ZW0uUmVmbGVjdGlvbi5GaWVsZEluZm8gcHJvcGVydHlGaWVsZCA9IHByb3BlcnR5RGVjbGFyaW5nVHlwZS5HZXRGaWVsZChcIkJhY2tncm91bmRQcm9wZXJ0eVwiKTtcclxuZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGVwZW5kZW5jeVByb3BlcnR5IHByb3BlcnR5ID0gKGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRlcGVuZGVuY3lQcm9wZXJ0eSlwcm9wZXJ0eUZpZWxkLkdldFZhbHVlKG51bGwpO1xyXG5cclxuICAoZmluYWxUYXJnZXRJbnN0YW5jZSkuU2V0Q3VycmVudFZhbHVlKHByb3BlcnR5LCB2YWx1ZSk7XHJcbn1cclxuXHJcblxyXG5wdWJsaWMgZ2xvYmFsOjpTeXN0ZW0uT2JqZWN0IGdldFZpc3VhbFN0YXRlUHJvcGVydHlfYzYxNDYxMTdmODI3NDUxMjllMWFhMzgxZDgwZjVhNTkgKGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRlcGVuZGVuY3lPYmplY3QgZmluYWxUYXJnZXRJbnN0YW5jZSlcclxue1xyXG4gIFxyXG5nbG9iYWw6OlN5c3RlbS5UeXBlIGZpbmFsVGFyZ2V0SW5zdGFuY2VUeXBlID0gZmluYWxUYXJnZXRJbnN0YW5jZS5HZXRUeXBlKCk7XHJcbmdsb2JhbDo6U3lzdGVtLlR5cGUgcHJvcGVydHlEZWNsYXJpbmdUeXBlID0gZmluYWxUYXJnZXRJbnN0YW5jZVR5cGUuR2V0UHJvcGVydHkoXCJCYWNrZ3JvdW5kXCIpLkRlY2xhcmluZ1R5cGU7XHJcbmdsb2JhbDo6U3lzdGVtLlJlZmxlY3Rpb24uRmllbGRJbmZvIHByb3BlcnR5RmllbGQgPSBwcm9wZXJ0eURlY2xhcmluZ1R5cGUuR2V0RmllbGQoXCJCYWNrZ3JvdW5kUHJvcGVydHlcIik7XHJcbmdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRlcGVuZGVuY3lQcm9wZXJ0eSBwcm9wZXJ0eSA9IChnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EZXBlbmRlbmN5UHJvcGVydHkpcHJvcGVydHlGaWVsZC5HZXRWYWx1ZShudWxsKTtcclxuXHJcbiAgcmV0dXJuIGZpbmFsVGFyZ2V0SW5zdGFuY2UuR2V0VmlzdWFsU3RhdGVWYWx1ZShwcm9wZXJ0eSk7XHJcbn1cclxuXHJcblxyXG5wdWJsaWMgZ2xvYmFsOjpTeXN0ZW0uQ29sbGVjdGlvbnMuR2VuZXJpYy5JRW51bWVyYWJsZTxnbG9iYWw6OlN5c3RlbS5UdXBsZTxnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EZXBlbmRlbmN5T2JqZWN0LCBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EZXBlbmRlbmN5UHJvcGVydHksIGludD8+PiBhY2Nlc3NWaXN1YWxTdGF0ZVByb3BlcnR5X2MzNzI5NDgxODJiYjQwYmQ4M2M1NDMwYjU3YTc3ZTc1IChnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EZXBlbmRlbmN5T2JqZWN0IHJvb3RUYXJnZXRPYmplY3RJbnN0YW5jZSlcclxue1xyXG4gIFxyXG55aWVsZCBicmVhaztcclxufVxyXG5cclxuXHJcbnB1YmxpYyB2b2lkIHNldFZpc3VhbFN0YXRlUHJvcGVydHlfYzM3Mjk0ODE4MmJiNDBiZDgzYzU0MzBiNTdhNzdlNzUgKGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRlcGVuZGVuY3lPYmplY3QgZmluYWxUYXJnZXRJbnN0YW5jZSwgb2JqZWN0IHZhbHVlKVxyXG57XHJcbiAgXHJcbmdsb2JhbDo6U3lzdGVtLlR5cGUgZmluYWxUYXJnZXRJbnN0YW5jZVR5cGUgPSBmaW5hbFRhcmdldEluc3RhbmNlLkdldFR5cGUoKTtcclxuZ2xvYmFsOjpTeXN0ZW0uVHlwZSBwcm9wZXJ0eURlY2xhcmluZ1R5cGUgPSBmaW5hbFRhcmdldEluc3RhbmNlVHlwZS5HZXRQcm9wZXJ0eShcIkJhY2tncm91bmRcIikuRGVjbGFyaW5nVHlwZTtcclxuZ2xvYmFsOjpTeXN0ZW0uUmVmbGVjdGlvbi5GaWVsZEluZm8gcHJvcGVydHlGaWVsZCA9IHByb3BlcnR5RGVjbGFyaW5nVHlwZS5HZXRGaWVsZChcIkJhY2tncm91bmRQcm9wZXJ0eVwiKTtcclxuZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGVwZW5kZW5jeVByb3BlcnR5IHByb3BlcnR5ID0gKGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRlcGVuZGVuY3lQcm9wZXJ0eSlwcm9wZXJ0eUZpZWxkLkdldFZhbHVlKG51bGwpO1xyXG5cclxuICAoZmluYWxUYXJnZXRJbnN0YW5jZSkuU2V0VmlzdWFsU3RhdGVWYWx1ZShwcm9wZXJ0eSwgdmFsdWUpO1xyXG59XHJcblxyXG5cclxucHVibGljIHZvaWQgc2V0QW5pbWF0aW9uVmlzdWFsU3RhdGVQcm9wZXJ0eV9jMzcyOTQ4MTgyYmI0MGJkODNjNTQzMGI1N2E3N2U3NSAoZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGVwZW5kZW5jeU9iamVjdCBmaW5hbFRhcmdldEluc3RhbmNlLCBvYmplY3QgdmFsdWUpXHJcbntcclxuICBcclxuZ2xvYmFsOjpTeXN0ZW0uVHlwZSBmaW5hbFRhcmdldEluc3RhbmNlVHlwZSA9IGZpbmFsVGFyZ2V0SW5zdGFuY2UuR2V0VHlwZSgpO1xyXG5nbG9iYWw6OlN5c3RlbS5UeXBlIHByb3BlcnR5RGVjbGFyaW5nVHlwZSA9IGZpbmFsVGFyZ2V0SW5zdGFuY2VUeXBlLkdldFByb3BlcnR5KFwiQmFja2dyb3VuZFwiKS5EZWNsYXJpbmdUeXBlO1xyXG5nbG9iYWw6OlN5c3RlbS5SZWZsZWN0aW9uLkZpZWxkSW5mbyBwcm9wZXJ0eUZpZWxkID0gcHJvcGVydHlEZWNsYXJpbmdUeXBlLkdldEZpZWxkKFwiQmFja2dyb3VuZFByb3BlcnR5XCIpO1xyXG5nbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EZXBlbmRlbmN5UHJvcGVydHkgcHJvcGVydHkgPSAoZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGVwZW5kZW5jeVByb3BlcnR5KXByb3BlcnR5RmllbGQuR2V0VmFsdWUobnVsbCk7XHJcblxyXG4gIChmaW5hbFRhcmdldEluc3RhbmNlKS5TZXRBbmltYXRpb25WYWx1ZShwcm9wZXJ0eSwgdmFsdWUpO1xyXG59XHJcblxyXG5cclxucHVibGljIHZvaWQgc2V0TG9jYWxWaXN1YWxTdGF0ZVByb3BlcnR5X2MzNzI5NDgxODJiYjQwYmQ4M2M1NDMwYjU3YTc3ZTc1IChnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EZXBlbmRlbmN5T2JqZWN0IGZpbmFsVGFyZ2V0SW5zdGFuY2UsIG9iamVjdCB2YWx1ZSlcclxue1xyXG4gIFxyXG5nbG9iYWw6OlN5c3RlbS5UeXBlIGZpbmFsVGFyZ2V0SW5zdGFuY2VUeXBlID0gZmluYWxUYXJnZXRJbnN0YW5jZS5HZXRUeXBlKCk7XHJcbmdsb2JhbDo6U3lzdGVtLlR5cGUgcHJvcGVydHlEZWNsYXJpbmdUeXBlID0gZmluYWxUYXJnZXRJbnN0YW5jZVR5cGUuR2V0UHJvcGVydHkoXCJCYWNrZ3JvdW5kXCIpLkRlY2xhcmluZ1R5cGU7XHJcbmdsb2JhbDo6U3lzdGVtLlJlZmxlY3Rpb24uRmllbGRJbmZvIHByb3BlcnR5RmllbGQgPSBwcm9wZXJ0eURlY2xhcmluZ1R5cGUuR2V0RmllbGQoXCJCYWNrZ3JvdW5kUHJvcGVydHlcIik7XHJcbmdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkRlcGVuZGVuY3lQcm9wZXJ0eSBwcm9wZXJ0eSA9IChnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EZXBlbmRlbmN5UHJvcGVydHkpcHJvcGVydHlGaWVsZC5HZXRWYWx1ZShudWxsKTtcclxuXHJcbiAgKGZpbmFsVGFyZ2V0SW5zdGFuY2UpLlNldEN1cnJlbnRWYWx1ZShwcm9wZXJ0eSwgdmFsdWUpO1xyXG59XHJcblxyXG5cclxucHVibGljIGdsb2JhbDo6U3lzdGVtLk9iamVjdCBnZXRWaXN1YWxTdGF0ZVByb3BlcnR5X2MzNzI5NDgxODJiYjQwYmQ4M2M1NDMwYjU3YTc3ZTc1IChnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EZXBlbmRlbmN5T2JqZWN0IGZpbmFsVGFyZ2V0SW5zdGFuY2UpXHJcbntcclxuICBcclxuZ2xvYmFsOjpTeXN0ZW0uVHlwZSBmaW5hbFRhcmdldEluc3RhbmNlVHlwZSA9IGZpbmFsVGFyZ2V0SW5zdGFuY2UuR2V0VHlwZSgpO1xyXG5nbG9iYWw6OlN5c3RlbS5UeXBlIHByb3BlcnR5RGVjbGFyaW5nVHlwZSA9IGZpbmFsVGFyZ2V0SW5zdGFuY2VUeXBlLkdldFByb3BlcnR5KFwiQmFja2dyb3VuZFwiKS5EZWNsYXJpbmdUeXBlO1xyXG5nbG9iYWw6OlN5c3RlbS5SZWZsZWN0aW9uLkZpZWxkSW5mbyBwcm9wZXJ0eUZpZWxkID0gcHJvcGVydHlEZWNsYXJpbmdUeXBlLkdldEZpZWxkKFwiQmFja2dyb3VuZFByb3BlcnR5XCIpO1xyXG5nbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5EZXBlbmRlbmN5UHJvcGVydHkgcHJvcGVydHkgPSAoZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGVwZW5kZW5jeVByb3BlcnR5KXByb3BlcnR5RmllbGQuR2V0VmFsdWUobnVsbCk7XHJcblxyXG4gIHJldHVybiBmaW5hbFRhcmdldEluc3RhbmNlLkdldFZpc3VhbFN0YXRlVmFsdWUocHJvcGVydHkpO1xyXG59XHJcblxyXG5cclxucHVibGljIHN0YXRpYyB2b2lkIE1haW4oKVxyXG57XHJcbiAgICBuZXcgQXBwKCk7XHJcbn1cclxuXHJcbn1cclxuXHJcblxyXG59XHJcbiIsIi8vIDxDU0hUTUw1PjxYYW1sSGFzaD4wNkE2NDE2NEY5NEIyNjg0MkI2RkY3MTUwMEJGQjY5RjwvWGFtbEhhc2g+PFBhc3NOdW1iZXI+MjwvUGFzc051bWJlcj48Q29tcGlsYXRpb25EYXRlPjE1LzA5LzIwMjQgMjI6Mjc6MDY8L0NvbXBpbGF0aW9uRGF0ZT48L0NTSFRNTDU+XHJcblxyXG5cclxuXHJcbnB1YmxpYyBzdGF0aWMgY2xhc3Mgx4DHgFF3Y8eAx4BDb21wb25lbnTHgMeATWFpbnBhZ2XHgMeAWGFtbMeAx4BGYWN0b3J5XHJcbntcclxuICAgIHB1YmxpYyBzdGF0aWMgb2JqZWN0IEluc3RhbnRpYXRlKClcclxuICAgIHtcclxuICAgICAgICBnbG9iYWw6OlN5c3RlbS5UeXBlIHR5cGUgPSB0eXBlb2YoUVdDLk1haW5QYWdlKTtcclxuICAgICAgICByZXR1cm4gZ2xvYmFsOjpDU0hUTUw1LkludGVybmFsLlR5cGVJbnN0YW50aWF0aW9uSGVscGVyLkluc3RhbnRpYXRlKHR5cGUpO1xyXG4gICAgfVxyXG59XHJcblxyXG5uYW1lc3BhY2UgUVdDXHJcbntcclxuXHJcblxyXG4vLy0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG4vLyA8YXV0by1nZW5lcmF0ZWQ+XHJcbi8vICAgICBUaGlzIGNvZGUgd2FzIGF1dG8tZ2VuZXJhdGVkIGJ5IFwiQyMvWEFNTCBmb3IgSFRNTDVcIlxyXG4vL1xyXG4vLyAgICAgQ2hhbmdlcyB0byB0aGlzIGZpbGUgbWF5IGNhdXNlIGluY29ycmVjdCBiZWhhdmlvciBhbmQgd2lsbCBiZSBsb3N0IGlmXHJcbi8vICAgICB0aGUgY29kZSBpcyByZWdlbmVyYXRlZC5cclxuLy8gPC9hdXRvLWdlbmVyYXRlZD5cclxuLy8tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuXHJcblxyXG5cclxucGFydGlhbCBjbGFzcyBNYWluUGFnZSA6IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkNvbnRyb2xzLlBhZ2Vcclxue1xyXG5cclxuI3ByYWdtYSB3YXJuaW5nIGRpc2FibGUgMTY5LCA2NDksIDA2MjggLy8gUHJldmVudHMgd2FybmluZyBDUzAxNjkgKCdmaWVsZCAuLi4gaXMgbmV2ZXIgdXNlZCcpLCBDUzA2NDkgKCdmaWVsZCAuLi4gaXMgbmV2ZXIgYXNzaWduZWQgdG8sIGFuZCB3aWxsIGFsd2F5cyBoYXZlIGl0cyBkZWZhdWx0IHZhbHVlIG51bGwnKSwgYW5kIENTMDYyOCAoJ21lbWJlciA6IG5ldyBwcm90ZWN0ZWQgbWVtYmVyIGRlY2xhcmVkIGluIHNlYWxlZCBjbGFzcycpXHJcbnByb3RlY3RlZCBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Db250cm9scy5HcmlkIFFXQ0dyaWQ7XHJcbnByb3RlY3RlZCBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Db250cm9scy5XcmFwUGFuZWwgUVdDSWNvbnM7XHJcbnByb3RlY3RlZCBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Db250cm9scy5HcmlkIFFXQ0hpZGRlbjtcclxucHJvdGVjdGVkIGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkNvbnRyb2xzLkdyaWQgUVdDU2lkZUJhcnM7XHJcbnByb3RlY3RlZCBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Db250cm9scy5QYWdlIFRvcDtcclxuXHJcblxyXG4jcHJhZ21hIHdhcm5pbmcgcmVzdG9yZSAxNjksIDY0OSwgMDYyOFxyXG5cclxuXHJcbiAgICAgICAgcHJpdmF0ZSBib29sIF9jb250ZW50TG9hZGVkO1xyXG4gICAgICAgIHB1YmxpYyB2b2lkIEluaXRpYWxpemVDb21wb25lbnQoKVxyXG4gICAgICAgIHtcclxuICAgICAgICAgICAgaWYgKF9jb250ZW50TG9hZGVkKVxyXG4gICAgICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgICAgICBfY29udGVudExvYWRlZCA9IHRydWU7XHJcblxyXG4jcHJhZ21hIHdhcm5pbmcgZGlzYWJsZSAwMTg0IC8vIFByZXZlbnRzIHdhcm5pbmcgQ1MwMTg0ICgnVGhlIGdpdmVuIGV4cHJlc3Npb24gaXMgbmV2ZXIgb2YgdGhlIHByb3ZpZGVkICgndHlwZScpIHR5cGUnKVxyXG4gICAgICAgICAgICBpZiAodGhpcyBpcyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5VSUVsZW1lbnQpXHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICgoZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuVUlFbGVtZW50KShvYmplY3QpdGhpcykuWGFtbFNvdXJjZVBhdGggPSBAXCJRV0NcXE1haW5QYWdlLnhhbWxcIjtcclxuICAgICAgICAgICAgfVxyXG4jcHJhZ21hIHdhcm5pbmcgcmVzdG9yZSAwMTg0XHJcblxyXG52YXIgR3JpZF8xMDhmYTJkYzQ2YjM0ZGNhOTljZDQzZTJjZjhkZjdlMSA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Db250cm9scy5HcmlkKCk7XHJcbnZhciBXcmFwUGFuZWxfY2ZhMGExMzg4MTYxNGIwYjkxZDA1ZGRhYmMzOTkzYzMgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuQ29udHJvbHMuV3JhcFBhbmVsKCk7XHJcbnZhciBHcmlkXzY5YTkxODUzM2E3ZjQ2MjE5ZGQ2MTgzNGNiZGY4ZTk2ID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkNvbnRyb2xzLkdyaWQoKTtcclxudmFyIEdyaWRfMTVmZDJiOTE0NzhmNDc3N2JjOTM3NGM1MmY3N2RiNTkgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuQ29udHJvbHMuR3JpZCgpO1xyXG5cclxudGhpcy5SZWdpc3Rlck5hbWUoXCJUb3BcIiwgdGhpcyk7XHJcbnRoaXMuTmFtZSA9IFwiVG9wXCI7XHJcbnZhciBJbnRDb252ZXJ0ZXJfNjcxYmQyMTFkYjY1NGRjZjkxNTY0MzY3OGNmNTMyOGEgPSBuZXcgZ2xvYmFsOjpBUExFeHRlbnNpb24uSW50Q29udmVydGVyKCk7XHJcblxyXG52YXIgRGVjQ29udmVydGVyX2JmMjhlNjM4N2I1MDQ5M2ViNDVjYWE4YWQyMmEyMmUzID0gbmV3IGdsb2JhbDo6QVBMRXh0ZW5zaW9uLkRlY0NvbnZlcnRlcigpO1xyXG5cclxudGhpcy5SZXNvdXJjZXNbXCJJbnRDb252ZXJ0ZXJcIl0gPSBJbnRDb252ZXJ0ZXJfNjcxYmQyMTFkYjY1NGRjZjkxNTY0MzY3OGNmNTMyOGE7XHJcbnRoaXMuUmVzb3VyY2VzW1wiRGVjQ29udmVydGVyXCJdID0gRGVjQ29udmVydGVyX2JmMjhlNjM4N2I1MDQ5M2ViNDVjYWE4YWQyMmEyMmUzO1xyXG5cclxudmFyIEdyaWRfZjJmMGE4MjZhMTQyNDVhOGI3YmE5M2E0NDVmMDlmMWUgPSBuZXcgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuQ29udHJvbHMuR3JpZCgpO1xyXG52YXIgUm93RGVmaW5pdGlvbl83OGEzMDI1NjA4NTc0MDZhOTg0YTM0OTg3N2JmMzllMSA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Db250cm9scy5Sb3dEZWZpbml0aW9uKCk7XHJcblJvd0RlZmluaXRpb25fNzhhMzAyNTYwODU3NDA2YTk4NGEzNDk4NzdiZjM5ZTEuSGVpZ2h0ID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkdyaWRMZW5ndGgoMS4wLCBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5HcmlkVW5pdFR5cGUuU3Rhcik7XHJcblxyXG52YXIgUm93RGVmaW5pdGlvbl84NjliN2IzMjljMDI0ZjU1ODg3YjMwMzZmZmRkODdlOSA9IG5ldyBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Db250cm9scy5Sb3dEZWZpbml0aW9uKCk7XHJcblJvd0RlZmluaXRpb25fODY5YjdiMzI5YzAyNGY1NTg4N2IzMDM2ZmZkZDg3ZTkuSGVpZ2h0ID0gbmV3IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkdyaWRMZW5ndGgoMS4wLCBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5HcmlkVW5pdFR5cGUuQXV0byk7XHJcblxyXG5HcmlkX2YyZjBhODI2YTE0MjQ1YThiN2JhOTNhNDQ1ZjA5ZjFlLlJvd0RlZmluaXRpb25zLkFkZChSb3dEZWZpbml0aW9uXzc4YTMwMjU2MDg1NzQwNmE5ODRhMzQ5ODc3YmYzOWUxKTtcclxuR3JpZF9mMmYwYTgyNmExNDI0NWE4YjdiYTkzYTQ0NWYwOWYxZS5Sb3dEZWZpbml0aW9ucy5BZGQoUm93RGVmaW5pdGlvbl84NjliN2IzMjljMDI0ZjU1ODg3YjMwMzZmZmRkODdlOSk7XHJcblxyXG50aGlzLlJlZ2lzdGVyTmFtZShcIlFXQ0dyaWRcIiwgR3JpZF8xMDhmYTJkYzQ2YjM0ZGNhOTljZDQzZTJjZjhkZjdlMSk7XHJcbkdyaWRfMTA4ZmEyZGM0NmIzNGRjYTk5Y2Q0M2UyY2Y4ZGY3ZTEuTmFtZSA9IFwiUVdDR3JpZFwiO1xyXG5cclxudGhpcy5SZWdpc3Rlck5hbWUoXCJRV0NJY29uc1wiLCBXcmFwUGFuZWxfY2ZhMGExMzg4MTYxNGIwYjkxZDA1ZGRhYmMzOTkzYzMpO1xyXG5XcmFwUGFuZWxfY2ZhMGExMzg4MTYxNGIwYjkxZDA1ZGRhYmMzOTkzYzMuTmFtZSA9IFwiUVdDSWNvbnNcIjtcclxuZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuQ29udHJvbHMuR3JpZC5TZXRSb3coV3JhcFBhbmVsX2NmYTBhMTM4ODE2MTRiMGI5MWQwNWRkYWJjMzk5M2MzLDEpO1xyXG5cclxudGhpcy5SZWdpc3Rlck5hbWUoXCJRV0NIaWRkZW5cIiwgR3JpZF82OWE5MTg1MzNhN2Y0NjIxOWRkNjE4MzRjYmRmOGU5Nik7XHJcbkdyaWRfNjlhOTE4NTMzYTdmNDYyMTlkZDYxODM0Y2JkZjhlOTYuTmFtZSA9IFwiUVdDSGlkZGVuXCI7XHJcbmdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkNvbnRyb2xzLkdyaWQuU2V0Um93KEdyaWRfNjlhOTE4NTMzYTdmNDYyMTlkZDYxODM0Y2JkZjhlOTYsMSk7XHJcbkdyaWRfNjlhOTE4NTMzYTdmNDYyMTlkZDYxODM0Y2JkZjhlOTYuVmlzaWJpbGl0eSA9IGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLlZpc2liaWxpdHkuQ29sbGFwc2VkO1xyXG5cclxudGhpcy5SZWdpc3Rlck5hbWUoXCJRV0NTaWRlQmFyc1wiLCBHcmlkXzE1ZmQyYjkxNDc4ZjQ3NzdiYzkzNzRjNTJmNzdkYjU5KTtcclxuR3JpZF8xNWZkMmI5MTQ3OGY0Nzc3YmM5Mzc0YzUyZjc3ZGI1OS5OYW1lID0gXCJRV0NTaWRlQmFyc1wiO1xyXG5nbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5Db250cm9scy5HcmlkLlNldFJvdyhHcmlkXzE1ZmQyYjkxNDc4ZjQ3NzdiYzkzNzRjNTJmNzdkYjU5LDEpO1xyXG5HcmlkXzE1ZmQyYjkxNDc4ZjQ3NzdiYzkzNzRjNTJmNzdkYjU5LlZpc2liaWxpdHkgPSBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5WaXNpYmlsaXR5LkNvbGxhcHNlZDtcclxuXHJcbkdyaWRfZjJmMGE4MjZhMTQyNDVhOGI3YmE5M2E0NDVmMDlmMWUuQ2hpbGRyZW4uQWRkKEdyaWRfMTA4ZmEyZGM0NmIzNGRjYTk5Y2Q0M2UyY2Y4ZGY3ZTEpO1xyXG5HcmlkX2YyZjBhODI2YTE0MjQ1YThiN2JhOTNhNDQ1ZjA5ZjFlLkNoaWxkcmVuLkFkZChXcmFwUGFuZWxfY2ZhMGExMzg4MTYxNGIwYjkxZDA1ZGRhYmMzOTkzYzMpO1xyXG5HcmlkX2YyZjBhODI2YTE0MjQ1YThiN2JhOTNhNDQ1ZjA5ZjFlLkNoaWxkcmVuLkFkZChHcmlkXzY5YTkxODUzM2E3ZjQ2MjE5ZGQ2MTgzNGNiZGY4ZTk2KTtcclxuR3JpZF9mMmYwYTgyNmExNDI0NWE4YjdiYTkzYTQ0NWYwOWYxZS5DaGlsZHJlbi5BZGQoR3JpZF8xNWZkMmI5MTQ3OGY0Nzc3YmM5Mzc0YzUyZjc3ZGI1OSk7XHJcblxyXG5cclxudGhpcy5Db250ZW50ID0gR3JpZF9mMmYwYTgyNmExNDI0NWE4YjdiYTkzYTQ0NWYwOWYxZTtcclxuXHJcbnZhciBEYXRhQ29udGV4dEV4dGVuc2lvbl9hYmVlNjI4MGYxNzI0ZDg3OWRmYmIyNDI5MzhiODA2NiA9IG5ldyBnbG9iYWw6OkFQTEV4dGVuc2lvbi5EYXRhQ29udGV4dEV4dGVuc2lvbigpO1xyXG5EYXRhQ29udGV4dEV4dGVuc2lvbl9hYmVlNjI4MGYxNzI0ZDg3OWRmYmIyNDI5MzhiODA2Ni5JbnN0YW5jZSA9IEBcInF3Y19Sb290XCI7XHJcbkRhdGFDb250ZXh0RXh0ZW5zaW9uX2FiZWU2MjgwZjE3MjRkODc5ZGZiYjI0MjkzOGI4MDY2LkNsYXNzID0gQFwicXdjX1Jvb3RcIjtcclxuRGF0YUNvbnRleHRFeHRlbnNpb25fYWJlZTYyODBmMTcyNGQ4NzlkZmJiMjQyOTM4YjgwNjYuTlMgPSBAXCJEYXRhQmluZGluZ1wiO1xyXG5cclxuXHJcblxyXG5cclxuUVdDR3JpZCA9IEdyaWRfMTA4ZmEyZGM0NmIzNGRjYTk5Y2Q0M2UyY2Y4ZGY3ZTE7XHJcblFXQ0ljb25zID0gV3JhcFBhbmVsX2NmYTBhMTM4ODE2MTRiMGI5MWQwNWRkYWJjMzk5M2MzO1xyXG5RV0NIaWRkZW4gPSBHcmlkXzY5YTkxODUzM2E3ZjQ2MjE5ZGQ2MTgzNGNiZGY4ZTk2O1xyXG5RV0NTaWRlQmFycyA9IEdyaWRfMTVmZDJiOTE0NzhmNDc3N2JjOTM3NGM1MmY3N2RiNTk7XHJcblRvcCA9IHRoaXM7XHJcblxyXG52YXIgY3VzdG9tTWFya3VwVmFsdWVfZWRlNzA2MmIzZmNkNGY4NGFmMDgyYTE2MGEwM2ZhN2MgPSBEYXRhQ29udGV4dEV4dGVuc2lvbl9hYmVlNjI4MGYxNzI0ZDg3OWRmYmIyNDI5MzhiODA2Ni5Qcm92aWRlVmFsdWUobmV3IGdsb2JhbDo6U3lzdGVtLlNlcnZpY2VQcm92aWRlcih0aGlzLCBnbG9iYWw6OldpbmRvd3MuVUkuWGFtbC5GcmFtZXdvcmtFbGVtZW50LkRhdGFDb250ZXh0UHJvcGVydHkpKTtcclxuaWYoY3VzdG9tTWFya3VwVmFsdWVfZWRlNzA2MmIzZmNkNGY4NGFmMDgyYTE2MGEwM2ZhN2MgaXMgV2luZG93cy5VSS5YYW1sLkRhdGEuQmluZGluZylcclxue1xyXG4gICAgZ2xvYmFsOjpXaW5kb3dzLlVJLlhhbWwuRGF0YS5CaW5kaW5nT3BlcmF0aW9ucy5TZXRCaW5kaW5nKHRoaXMsIGdsb2JhbDo6V2luZG93cy5VSS5YYW1sLkZyYW1ld29ya0VsZW1lbnQuRGF0YUNvbnRleHRQcm9wZXJ0eSwgKFdpbmRvd3MuVUkuWGFtbC5EYXRhLkJpbmRpbmcpY3VzdG9tTWFya3VwVmFsdWVfZWRlNzA2MmIzZmNkNGY4NGFmMDgyYTE2MGEwM2ZhN2MpO1xyXG59XHJcbmVsc2Vcclxue1xyXG4gICAgdGhpcy5EYXRhQ29udGV4dCA9IChnbG9iYWw6OlN5c3RlbS5PYmplY3QpY3VzdG9tTWFya3VwVmFsdWVfZWRlNzA2MmIzZmNkNGY4NGFmMDgyYTE2MGEwM2ZhN2M7XHJcbn1cclxuICAgIFxyXG4gICAgICAgIH1cclxuXHJcblxyXG5cclxuXHJcbn1cclxuXHJcblxyXG59XHJcbiIsInVzaW5nIEFQTENvbnRyb2xzO1xyXG51c2luZyBBUExDb250cm9scztcclxudXNpbmcgQVBMRXh0ZW5zaW9uO1xyXG51c2luZyBEYXRhQmluZGluZztcclxudXNpbmcgU3lzdGVtO1xyXG51c2luZyBDU0hUTUw1O1xyXG51c2luZyBTeXN0ZW0uQ29sbGVjdGlvbnMuR2VuZXJpYztcclxudXNpbmcgU3lzdGVtLklPO1xyXG51c2luZyBTeXN0ZW0uTGlucTtcclxudXNpbmcgV2luZG93cy5VSS5YYW1sO1xyXG51c2luZyBXaW5kb3dzLlVJLlhhbWwuQ29udHJvbHM7XHJcbnVzaW5nIFdpbmRvd3MuRm91bmRhdGlvbjtcclxubmFtZXNwYWNlIFFXQ1xyXG57XHJcbiAgICBwdWJsaWMgc2VhbGVkIHBhcnRpYWwgY2xhc3MgQXBwIDogQXBwbGljYXRpb25cclxuICAgIHtcclxuICAgICAgICBBUExFeHRlbnNpb24uRGF0YUNvbnRleHRFeHRlbnNpb24gZDtcclxuICAgICAgICBwdWJsaWMgQXBwKClcclxuICAgICAgICB7XHJcbiAgICAgICAgICAgIHRoaXMuSW5pdGlhbGl6ZUNvbXBvbmVudCgpO1xyXG4gICAgICAgICAgICAvLyBFbnRlciBjb25zdHJ1Y3Rpb24gbG9naWMgaGVyZS4uLlxyXG4gICAgICAgICAgICB0cnlcclxuICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgRGF0YUJpbmRpbmcuU2VuZGVyQ2xhc3MgYSA9IG5ldyBEYXRhQmluZGluZy5TZW5kZXJDbGFzcygpO1xyXG4gICAgICAgICAgICAgICAgQXBwbGljYXRpb24uQ3VycmVudC5SZXNvdXJjZXNbXCJTZW5kZXJDbGFzc1wiXSA9IGE7XHJcbiAgICAgICAgICAgICAgICBBcHBsaWNhdGlvbi5DdXJyZW50LlJlc291cmNlc1tcIlFXQ1wiXSA9IHRoaXM7XHJcbiAgICAgICAgICAgIH0gY2F0Y2ggeyB9XHJcbiAgICAgICAgICAgIHZhciBtYWluUGFnZSA9IG5ldyBNYWluUGFnZSgpO1xyXG4gICBJbnRlcm9wLkV4ZWN1dGVKYXZhU2NyaXB0KFwiaWYgKG1qaF9maWxlc2xvYWRlZCkgbWpoX2ZpbGVzbG9hZGVkWydwYWdlJ10gPSAkMFwiLCBtYWluUGFnZSk7XHJcbiAgICAgICAgICAgIFdpbmRvdy5DdXJyZW50LkNvbnRlbnQgPSBtYWluUGFnZTtcclxuICAgICAgICB9XHJcbnZvaWQgUnVuQ2xpY2tNaW4oT2JqZWN0IHMsIFJvdXRlZEV2ZW50QXJncyBhcmdzKSB7XHJcbnF3Y0Zvcm1fRGF0YSBkYyA9IChxd2NGb3JtX0RhdGEpICgoQnV0dG9uKSBzKS5EYXRhQ29udGV4dDtcclxuZGMuU2VuZE1hcmdpbiA9IGZhbHNlO1xyXG5kYy5TdGF0ZSA9IDE7XHJcbnF3Y19Sb290IHJvb3QgPSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBcInF3Y19Sb290XCIsIFwicXdjX1Jvb3RcIiwgdGhpcykgYXMgcXdjX1Jvb3Q7XHJcbnJvb3QuRnVsbFNjcmVlbklkID0gXCJcIjtcclxufSBcclxudm9pZCBSdW5DbGlja01heChPYmplY3QgcywgUm91dGVkRXZlbnRBcmdzIGFyZ3MpIHtcclxucXdjRm9ybV9EYXRhIGRjID0gKHF3Y0Zvcm1fRGF0YSkoKEJ1dHRvbilzKS5EYXRhQ29udGV4dDtcclxuZGMuU2VuZE1hcmdpbiA9IGZhbHNlO1xyXG5pZiAoMiA9PSBkYy5TdGF0ZSkgZGMuU3RhdGUgID0gMDtcclxuZWxzZSBkYy5TdGF0ZSA9IDI7XHJcbnF3Y19Sb290IHJvb3QgPSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBcInF3Y19Sb290XCIsIFwicXdjX1Jvb3RcIiwgdGhpcykgYXMgcXdjX1Jvb3Q7XHJcbnJvb3QuRnVsbFNjcmVlbklkID0gXCJcIjtcclxufSBcclxudm9pZCBSdW5DbGlja0Z1bGxTY3JlZW4oT2JqZWN0IHMsIFJvdXRlZEV2ZW50QXJncyBhcmdzKSB7XHJcbnF3Y0Zvcm1fRGF0YSBkYyA9IChxd2NGb3JtX0RhdGEpKChCdXR0b24pcykuRGF0YUNvbnRleHQ7XHJcbkFQTEZvcm0gb2JqID0gZGMuTUpIX1NlbGYgYXMgQVBMRm9ybTtcclxuZGMuU2VuZE1hcmdpbiA9IGZhbHNlO1xyXG5JbnRlcm9wLkV4ZWN1dGVKYXZhU2NyaXB0KFwidmFyIGVsZW0gPSAkMFwiLCBJbnRlcm9wLkdldERpdihvYmopKTtcclxuSW50ZXJvcC5FeGVjdXRlSmF2YVNjcmlwdChcIm9wZW5GdWxsc2NyZWVuKGVsZW0pXCIpO1xyXG5kYy5TdGF0ZSA9IDQ7XHJcbnF3Y19Sb290IHJvb3QgPSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBcInF3Y19Sb290XCIsIFwicXdjX1Jvb3RcIiwgdGhpcykgYXMgcXdjX1Jvb3Q7XHJcbnJvb3QuRnVsbFNjcmVlbklkID0gZGMuTmFtZTtcclxufSBcclxudm9pZCBSdW5DbGlja0Nsb3NlKE9iamVjdCBzLCBSb3V0ZWRFdmVudEFyZ3MgYXJncykge1xyXG5xd2NGb3JtX0RhdGEgZGMgPSAocXdjRm9ybV9EYXRhKSgoQnV0dG9uKXMpLkRhdGFDb250ZXh0O1xyXG5kYy5TZW5kTWFyZ2luID0gZmFsc2U7XHJcblN0cmluZyBldmVudG5hbWUgPSBcIkNsaWNrQ2xvc2VcIjtcclxuQVBMRm9ybSBvYmogPSBkYy5NSkhfU2VsZiBhcyBBUExGb3JtO1xyXG5vYmouQ2xvc2UoKTtcclxufSBcclxufX1cclxuIiwidXNpbmcgU3lzdGVtO1xyXG51c2luZyBTeXN0ZW0uQ29sbGVjdGlvbnMuR2VuZXJpYztcclxudXNpbmcgU3lzdGVtLklPO1xyXG51c2luZyBTeXN0ZW0uTGlucTtcclxudXNpbmcgV2luZG93cy5TeXN0ZW07XHJcbnVzaW5nIFdpbmRvd3MuVUkuWGFtbDtcclxudXNpbmcgV2luZG93cy5VSS5YYW1sLkNvbnRyb2xzO1xyXG51c2luZyBTeXN0ZW0uV2luZG93cy5JbnB1dDtcclxudXNpbmcgV2luZG93cy5VSS5YYW1sLklucHV0O1xyXG51c2luZyBXaW5kb3dzLlVJLlhhbWwuRGF0YTtcclxudXNpbmcgV2luZG93cy5Gb3VuZGF0aW9uO1xyXG51c2luZyBTeXN0ZW0uQ29sbGVjdGlvbnMuT2JqZWN0TW9kZWw7XHJcbnVzaW5nIFN5c3RlbS5XaW5kb3dzLkJyb3dzZXI7XHJcbnVzaW5nIFN5c3RlbS5SZWZsZWN0aW9uO1xyXG51c2luZyBBUExFeHRlbnNpb247XHJcbnVzaW5nIERhdGFCaW5kaW5nO1xyXG51c2luZyBDU0hUTUw1O1xyXG51c2luZyBTeXN0ZW0uVGhyZWFkaW5nLlRhc2tzO1xyXG51c2luZyBNSkhTb2Z0d2FyZS5Db21tb247XHJcbnVzaW5nIEFQTENvbnRyb2xzO1xyXG51c2luZyBTeXN0ZW0uVGhyZWFkaW5nO1xyXG5uYW1lc3BhY2UgUVdDXHJcbnsgXHJcbnB1YmxpYyBzZWFsZWQgcGFydGlhbCBjbGFzcyBNYWluUGFnZSA6IFBhZ2VcclxueyBcclxucHVibGljIHJlYWRvbmx5IFRhc2tDb21wbGV0aW9uU291cmNlPGJvb2w+IGZpbGVzUmVhZHkgPSBuZXcgVGFza0NvbXBsZXRpb25Tb3VyY2U8Ym9vbD4oKTtcclxucHVibGljIFRhc2s8Ym9vbD4gRmlsZXNSZWFkeSB7IGdldCB7IHJldHVybiBmaWxlc1JlYWR5LlRhc2s7IH0gfVxyXG5yZWFkb25seSBUYXNrQ29tcGxldGlvblNvdXJjZTxib29sPiB3ZWJTb2NrZXRSZWFkeSA9IG5ldyBUYXNrQ29tcGxldGlvblNvdXJjZTxib29sPigpO1xyXG5wdWJsaWMgVGFzazxib29sPiBXZWJTb2NrZXRSZWFkeSB7IGdldCB7IHJldHVybiB3ZWJTb2NrZXRSZWFkeS5UYXNrOyB9IH1cclxuQ1NIVE1MNS5FeHRlbnNpb25zLldlYlNvY2tldHMuV2ViU29ja2V0IHdlYlNvY2tldDtcclxuQ1NIVE1MNS5FeHRlbnNpb25zLldlYlNvY2tldHMuV2ViU29ja2V0IGRpcmVjdHdlYlNvY2tldDtcclxuU3RyaW5nIGNvbm5lY3Rpb24gPSBcIlwiO1xyXG5TdHJpbmcgY29ubmVjdGlvbnBvcnQgPSBcIlwiO1xyXG5Cb29sZWFuIEFsbFJlYWR5ID0gZmFsc2U7XHJcbkJvb2xlYW4gU2V0dXBDb21wbGV0ZVJ1biA9IGZhbHNlO1xyXG5wdWJsaWMgTWFpblBhZ2UoKSB7XHJcblJ1blJlc3RNYWluKCk7XHJcbn0gXHJcbnZvaWQgQWRkRmlsZUxvYWRpbmcoKSB7XHJcbkludGVyb3AuRXhlY3V0ZUphdmFTY3JpcHQoXCJtamhfZmlsZXNsb2FkZWQudmFsdWUgKz0gMVwiKTtcclxuaW50IEZpbGVzTG9hZGVkID0gKGludCkgSW50ZXJvcC5FeGVjdXRlSmF2YVNjcmlwdChcIm1qaF9maWxlc2xvYWRlZC52YWx1ZVwiKTtcclxuaW50IFRvdGFsRmlsZXNUb0JlTG9hZGVkID0gKGludCkgSW50ZXJvcC5FeGVjdXRlSmF2YVNjcmlwdChcIm1qaF9maWxlc2xvYWRlZC50b3RhbFwiKTtcclxuaWYgKEZpbGVzTG9hZGVkID09IFRvdGFsRmlsZXNUb0JlTG9hZGVkKSB7Ym9vbCB4ID0gZmlsZXNSZWFkeS5UcnlTZXRSZXN1bHQodHJ1ZSk7fTtcclxufSBcclxudm9pZCBDaGVja0ZpbGVMb2FkaW5nKCkge1xyXG5pbnQgRmlsZXNMb2FkZWQgPSAoaW50KSBJbnRlcm9wLkV4ZWN1dGVKYXZhU2NyaXB0KFwibWpoX2ZpbGVzbG9hZGVkLnZhbHVlXCIpO1xyXG5pbnQgVG90YWxGaWxlc1RvQmVMb2FkZWQgPSAoaW50KSBJbnRlcm9wLkV4ZWN1dGVKYXZhU2NyaXB0KFwibWpoX2ZpbGVzbG9hZGVkLnRvdGFsXCIpO1xyXG5pZiAoRmlsZXNMb2FkZWQgPT0gVG90YWxGaWxlc1RvQmVMb2FkZWQpIHtib29sIHggPSBmaWxlc1JlYWR5LlRyeVNldFJlc3VsdCh0cnVlKTt9O1xyXG59IFxyXG52b2lkIEVuZEN1c3RvbUNTUygpIHtcclxuYm9vbCBydW5mbGcgPSAoYm9vbCkgSW50ZXJvcC5FeGVjdXRlSmF2YVNjcmlwdChcIigndW5kZWZpbmVkJyAhPXR5cGVvZiBlaiAmJiAgJ3VuZGVmaW5lZCcgIT0gdHlwZW9mIGVqLmJhc2UpXCIpO1xyXG5pZiAocnVuZmxnKSB7XHJcbkludGVyb3AuRXhlY3V0ZUphdmFTY3JpcHQoXCJlai5iYXNlLmVuYWJsZVJpcHBsZShmYWxzZSlcIik7XHJcbn0gXHJcbn0gXHJcbnZvaWQgUnVuUmVzdE1haW4oKSB7XHJcbkludGVyb3AuRXhlY3V0ZUphdmFTY3JpcHQoXCJ3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcignYmVmb3JldW5sb2FkJywgJDApXCIsIChGdW5jPG9iamVjdCxzdHJpbmc+KU9uQmVmb3JlVW5sb2FkKTtcclxuQXBwbGljYXRpb24uQ3VycmVudC5SZXNvdXJjZXNbXCJNYXhTZXJpYWxOb1wiXSA9IDA7XHJcbkFwcGxpY2F0aW9uLkN1cnJlbnQuUmVzb3VyY2VzW1wiRnJhbWV3b3JrRWxlbWVudFwiXSA9IHRoaXM7XHJcbkFwcGxpY2F0aW9uLkN1cnJlbnQuUmVzb3VyY2VzW1wiQWxsUmVhZHlcIl0gPSBBbGxSZWFkeTtcclxuU3RyaW5nIG9yaWdpbmFsID0gSHRtbFBhZ2UuRG9jdW1lbnQuRG9jdW1lbnRVcmkuT3JpZ2luYWxTdHJpbmc7XHJcbkFwcGxpY2F0aW9uLkN1cnJlbnQuUmVzb3VyY2VzW1wiT3JpZ2luYWxVUkxcIl0gPSBvcmlnaW5hbDtcclxuU3RyaW5nIGNvbm5lY3Rpb247XHJcbkRpY3Rpb25hcnk8c3RyaW5nLHN0cmluZz4gYXBwcyA9IFV0aWxzLkdldEFwcHNSZXNvdXJjZShcIlFXQ1wiLFwid2ViZGV0YWlscy5odG1sXCIpO1xyXG5jb25uZWN0aW9uID0gVXRpbHMuR2V0QXBwUmVzb3VyY2UoYXBwcywgXCJDb25uZWN0aW9uXCIpO1xyXG5pZiAoMCA9PSBjb25uZWN0aW9uLkxlbmd0aCkge1xyXG5jb25uZWN0aW9uID0gKFN0cmluZylBcHBsaWNhdGlvbi5DdXJyZW50LlRyeUZpbmRSZXNvdXJjZShcIkNvbm5lY3Rpb25cIik7XHJcbn0gXHJcblN0cmluZyBjb25uZWN0aW9udHlwZSA9IFV0aWxzLkdldEFwcFJlc291cmNlKGFwcHMsIFwiQ29ubmVjdGlvblR5cGVcIik7XHJcbmlmICgwID09IGNvbm5lY3Rpb250eXBlLkxlbmd0aCkgeyBcclxuY29ubmVjdGlvbnR5cGUgPSAoU3RyaW5nKUFwcGxpY2F0aW9uLkN1cnJlbnQuVHJ5RmluZFJlc291cmNlKFwiQ29ubmVjdGlvblR5cGVcIik7XHJcbn0gXHJcbnN0cmluZyB1cGxvYWRob3N0ID0gVXRpbHMuR2V0QXBwUmVzb3VyY2UoYXBwcywgXCJVcGxvYWRIb3N0XCIpO1xyXG5pZiAobnVsbCA9PSB1cGxvYWRob3N0IHx8IDAgPT0gdXBsb2FkaG9zdC5MZW5ndGgpIHtcclxudXBsb2FkaG9zdCA9IChTdHJpbmcpQXBwbGljYXRpb24uQ3VycmVudC5UcnlGaW5kUmVzb3VyY2UoXCJVcGxvYWRIb3N0XCIpO1xyXG5pZiAobnVsbCA9PSB1cGxvYWRob3N0IHx8IDAgPT0gdXBsb2FkaG9zdC5MZW5ndGgpIHVwbG9hZGhvc3QgPSBcImxvY2FsaG9zdFwiO1xyXG59IFxyXG5BcHBsaWNhdGlvbi5DdXJyZW50LlJlc291cmNlc1tcIlVwbG9hZEhvc3RcIl0gPSB1cGxvYWRob3N0O1xyXG5zdHJpbmcgdXBsb2FkcG9ydCA9IFV0aWxzLkdldEFwcFJlc291cmNlKGFwcHMsIFwiVXBsb2FkUG9ydFwiKTtcclxuaWYgKG51bGwgPT0gdXBsb2FkcG9ydCB8fCAwID09IHVwbG9hZHBvcnQuTGVuZ3RoKSB7XHJcbnVwbG9hZHBvcnQgPSAoU3RyaW5nKUFwcGxpY2F0aW9uLkN1cnJlbnQuVHJ5RmluZFJlc291cmNlKFwiVXBsb2FkUG9ydFwiKTtcclxuaWYgKG51bGwgPT0gdXBsb2FkcG9ydCB8fCAwID09IHVwbG9hZHBvcnQuTGVuZ3RoKSB1cGxvYWRwb3J0ID0gXCIxMjM0XCI7XHJcbn0gXHJcbkFwcGxpY2F0aW9uLkN1cnJlbnQuUmVzb3VyY2VzW1wiVXBsb2FkUG9ydFwiXSA9IHVwbG9hZHBvcnQ7XHJcbnN0cmluZyB1cGxvYWRzZWN1cmUgPSBVdGlscy5HZXRBcHBSZXNvdXJjZShhcHBzLCBcIlVwbG9hZFNlY3VyZVwiKTtcclxuaWYgKG51bGwgPT0gdXBsb2Fkc2VjdXJlIHx8IDAgPT0gdXBsb2Fkc2VjdXJlLkxlbmd0aCkge1xyXG51cGxvYWRzZWN1cmUgPSAoU3RyaW5nKUFwcGxpY2F0aW9uLkN1cnJlbnQuVHJ5RmluZFJlc291cmNlKFwiVXBsb2FkU2VjdXJlXCIpO1xyXG5pZiAobnVsbCA9PSB1cGxvYWRzZWN1cmUgfHwgMCA9PSB1cGxvYWRzZWN1cmUuTGVuZ3RoKSB1cGxvYWRzZWN1cmUgPSBcIjBcIjtcclxufSBcclxuQXBwbGljYXRpb24uQ3VycmVudC5SZXNvdXJjZXNbXCJVcGxvYWRTZWN1cmVcIl0gPSB1cGxvYWRzZWN1cmU7XHJcbnN0cmluZyBuYW1lID0gVXRpbHMuR2V0QXBwUmVzb3VyY2UoYXBwcywgXCJOYW1lXCIpO1xyXG5pZiAoMCA9PSBuYW1lLkxlbmd0aCkge1xyXG5uYW1lID0gKFN0cmluZylBcHBsaWNhdGlvbi5DdXJyZW50LlJlc291cmNlc1tcIk5hbWVcIl07XHJcbn0gXHJcbnN0cmluZyBXU25hbWUgPSBVdGlscy5HZXRBcHBSZXNvdXJjZShhcHBzLCBcIldTTmFtZVwiKTtcclxuaWYgKDAgPT0gV1NuYW1lLkxlbmd0aCkge1xyXG5XU25hbWUgPSAoU3RyaW5nKUFwcGxpY2F0aW9uLkN1cnJlbnQuVHJ5RmluZFJlc291cmNlKFwiV1NOYW1lXCIpO1xyXG59IFxyXG5zdHJpbmcgcG9ydCA9IFV0aWxzLkdldEFwcFJlc291cmNlKGFwcHMsIFwiUG9ydFwiKTtcclxuaWYgKDAgPT0gcG9ydC5MZW5ndGgpIHtcclxucG9ydCA9IChTdHJpbmcpQXBwbGljYXRpb24uQ3VycmVudC5UcnlGaW5kUmVzb3VyY2UoXCJQb3J0XCIpO1xyXG59IFxyXG5pZiAobnVsbCA9PSBXU25hbWUgKSB7IFdTbmFtZSA9IFwiV1NcIjsgfVxyXG5XU25hbWUgPSBXU25hbWUuVHJpbSgpO1xyXG5pZiAoXCJcIiA9PSBXU25hbWUpIHsgV1NuYW1lID0gXCJXU1wiOyB9XHJcbmlmIChXU25hbWUuVG9VcHBlcigpID09IFwiTk9ORVwiKSBXU25hbWUgPSBcIlwiO1xyXG5pZiAobnVsbCA9PSBjb25uZWN0aW9uKSB7IGNvbm5lY3Rpb24gPSBcIlwiOyB9XHJcbmNvbm5lY3Rpb24gPSBjb25uZWN0aW9uLlRyaW0oKTtcclxuaWYgKG51bGwgPT0gY29ubmVjdGlvbnR5cGUpIHsgY29ubmVjdGlvbnR5cGUgPSBcIlwiOyB9XHJcbmNvbm5lY3Rpb250eXBlID0gY29ubmVjdGlvbnR5cGUuVHJpbSgpO1xyXG5pZiAoXCJcIiA9PSBjb25uZWN0aW9udHlwZSkgeyBjb25uZWN0aW9udHlwZSA9IFwiRGlyZWN0XCI7IH1cclxuaWYgKFwiXCIgPT0gY29ubmVjdGlvbikge1xyXG5pZiAoXCJodHRwXCIgPT0gSHRtbFBhZ2UuRG9jdW1lbnQuRG9jdW1lbnRVcmkuU2NoZW1lKSBjb25uZWN0aW9uID0gSHRtbFBhZ2UuRG9jdW1lbnQuRG9jdW1lbnRVcmkuSG9zdDtcclxuZWxzZSBjb25uZWN0aW9uID0gXCJsb2NhbGhvc3RcIjtcclxuIH1cclxuc3RyaW5nIGFwcG5hbWUgPSBVdGlscy5HZXRBcHBSZXNvdXJjZShhcHBzLCBcIkFwcE5hbWVcIik7XHJcbmlmICgwID09IGFwcG5hbWUuTGVuZ3RoKSBhcHBuYW1lID0gKFN0cmluZylBcHBsaWNhdGlvbi5DdXJyZW50LlRyeUZpbmRSZXNvdXJjZShcIkFwcE5hbWVcIik7XHJcbmlmIChudWxsID09IGFwcG5hbWUpIGFwcG5hbWUgPSBuYW1lO1xyXG5pZiAoXCJcIiA9PSBhcHBuYW1lKSBhcHBuYW1lID0gbmFtZTtcclxuQXBwbGljYXRpb24uQ3VycmVudC5SZXNvdXJjZXNbXCJBcHBOYW1lXCJdID0gYXBwbmFtZTtcclxuaWYgKFwiRGlyZWN0XCIgPT0gY29ubmVjdGlvbnR5cGUpIHtcclxuaWYgKG51bGwgPT0gcG9ydCkgeyBwb3J0ID0gXCJcIjsgfVxyXG5zdHJpbmcgdXJpID0gKHN0cmluZykgSW50ZXJvcC5FeGVjdXRlSmF2YVNjcmlwdChcImRvY3VtZW50LmxvY2F0aW9uLnNlYXJjaFwiKTtcclxuaWYgKDAgIT0gdXJpLkxlbmd0aCkge1xyXG5zdHJpbmcgcCA9IFwiXCI7XHJcbmZvcihpbnQgaT0wOyBpIDwgdXJpLkxlbmd0aDsgaSsrKSB7XHJcbmlmICgnPycgIT0gdXJpW2ldKSB7XHJcbmlmICgnMCcgPT0gdXJpW2ldIHx8ICcxJyA9PSB1cmlbaV0gfHwgJzInID09IHVyaVtpXSB8fCAnMycgPT0gdXJpW2ldIHx8ICc0JyA9PSB1cmlbaV0gfHwgJzUnID09IHVyaVtpXSB8fCAnNicgPT0gdXJpW2ldIHx8ICc3JyA9PSB1cmlbaV0gfHwgJzgnID09IHVyaVtpXSB8fCAnOScgPT0gdXJpW2ldKSB7XHJcbnAgKz0gdXJpW2ldO1xyXG59IFxyXG5lbHNlIGJyZWFrO1xyXG59IFxyXG59IFxyXG5pZiAoMCAhPSBwLkxlbmd0aCkgcG9ydCA9IHA7XHJcbn0gXHJcbmlmIChcIlwiID09IHBvcnQpIHsgcG9ydCA9IEh0bWxQYWdlLkRvY3VtZW50LkRvY3VtZW50VXJpLlBvcnQuVG9TdHJpbmcoKTsgfVxyXG5jb25uZWN0aW9uICs9IFwiOlwiICsgcG9ydCArIFwiL1wiICsgbmFtZSArXCIvXCI7XHJcbn0gZWxzZSB7XHJcbmlmICgwICE9IGNvbm5lY3Rpb24uTGVuZ3RoKSB7XHJcbmNvbm5lY3Rpb25wb3J0ID0gVXRpbHMuR2V0QXBwUmVzb3VyY2UoYXBwcywgXCJDb25uZWN0aW9uUG9ydFwiKTtcclxuaWYgKGNvbm5lY3Rpb25wb3J0ID09IG51bGwgfHwgMCA9PSBjb25uZWN0aW9ucG9ydC5MZW5ndGgpIGNvbm5lY3Rpb25wb3J0ID0gKFN0cmluZylBcHBsaWNhdGlvbi5DdXJyZW50LlRyeUZpbmRSZXNvdXJjZShcIkNvbm5lY3Rpb25Qb3J0XCIpO1xyXG5pZiAoY29ubmVjdGlvbnBvcnQgIT0gbnVsbCAmJiAwICE9IGNvbm5lY3Rpb25wb3J0Lkxlbmd0aCkgY29ubmVjdGlvbiArPSBcIjpcIiArIGNvbm5lY3Rpb25wb3J0O1xyXG59IFxyXG5jb25uZWN0aW9uICs9IFwiL1wiICsgV1NuYW1lO1xyXG5pZiAoMCAhPSBXU25hbWUuTGVuZ3RoKSBjb25uZWN0aW9uICs9IFwiL1wiO1xyXG59IFxyXG5zdHJpbmcgc2VjdXJlY29ubmVjdGlvbiA9IFV0aWxzLkdldEFwcFJlc291cmNlKGFwcHMsIFwiU2VjdXJlQ29ubmVjdGlvblwiKTtcclxuaWYgKG51bGwgPT0gc2VjdXJlY29ubmVjdGlvbiB8fCAwID09IHNlY3VyZWNvbm5lY3Rpb24uTGVuZ3RoKSB7XHJcbnNlY3VyZWNvbm5lY3Rpb24gPSAoU3RyaW5nKUFwcGxpY2F0aW9uLkN1cnJlbnQuVHJ5RmluZFJlc291cmNlKFwiU2VjdXJlQ29ubmVjdGlvblwiKTtcclxuaWYgKG51bGwgPT0gc2VjdXJlY29ubmVjdGlvbiB8fCAwID09IHNlY3VyZWNvbm5lY3Rpb24uTGVuZ3RoKSBzZWN1cmVjb25uZWN0aW9uID0gXCIwXCI7XHJcbn0gXHJcbkFwcGxpY2F0aW9uLkN1cnJlbnQuUmVzb3VyY2VzW1wiU2VjdXJlQ29ubmVjdGlvblwiXSA9IHNlY3VyZWNvbm5lY3Rpb247XHJcbmlmIChzZWN1cmVjb25uZWN0aW9uID09IFwiMVwiKSBjb25uZWN0aW9uID0gXCJ3c3M6Ly9cIiArIGNvbm5lY3Rpb247XHJcbmVsc2UgY29ubmVjdGlvbiA9IFwid3M6Ly9cIiArIGNvbm5lY3Rpb247XHJcbldTSW50ZXJuYWxzIF9XU0ludGVybmFscyA9IEFQTC5NYWtlSW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLFwiV1NJbnRlcm5hbHNcIixcIldTSW50ZXJuYWxzXCIsdGhpcykgYXMgV1NJbnRlcm5hbHM7XHJcbnF3Y19Sb290IF9xd2NfUm9vdCA9IEFQTC5NYWtlSW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLFwicXdjX1Jvb3RcIixcInF3Y19Sb290XCIsdGhpcykgYXMgcXdjX1Jvb3Q7XHJcbi8vIFJhbmRvbSBybmQgPSBuZXcgUmFuZG9tKEd1aWQuTmV3R3VpZCgpLkdldEhhc2hDb2RlKCkpO1xyXG5SYW5kb20gcm5kID0gbmV3IFJhbmRvbSgpO1xyXG5zdHJpbmcgcm5kcyA9IHJuZC5OZXh0KCkuVG9TdHJpbmcoKTtcclxud2ViU29ja2V0ID0gbmV3IENTSFRNTDUuRXh0ZW5zaW9ucy5XZWJTb2NrZXRzLldlYlNvY2tldChjb25uZWN0aW9uICsgXCI/aGFzaD1cIiArIHJuZHMpO1xyXG5kaXJlY3R3ZWJTb2NrZXQgPSBuZXcgQ1NIVE1MNS5FeHRlbnNpb25zLldlYlNvY2tldHMuV2ViU29ja2V0KGNvbm5lY3Rpb24gKyBcIj9oYXNoPVwiICsgcm5kcyk7XHJcbkFwcGxpY2F0aW9uLkN1cnJlbnQuUmVzb3VyY2VzW1wiV2ViU29ja2V0XCJdID0gd2ViU29ja2V0O1xyXG5BcHBsaWNhdGlvbi5DdXJyZW50LlJlc291cmNlc1tcIkRpcmVjdFdlYlNvY2tldFwiXSA9IGRpcmVjdHdlYlNvY2tldDtcclxuVHJhbnNmZXJTdHJpbmcgeHN0cmluZztcclxuc3RyaW5nIGQgPSBcIlwiO1xyXG53ZWJTb2NrZXQuT25NZXNzYWdlKz0gYXN5bmMgKHMsIGUpID0+e1xyXG5pZiAoU2V0dXBDb21wbGV0ZVJ1bikge1xyXG5TZXR1cENvbXBsZXRlUnVuID0gZmFsc2U7XHJcbkNoZWNrRmlsZUxvYWRpbmcoKTtcclxuYXdhaXQgRmlsZXNSZWFkeTtcclxuRW5kQ3VzdG9tQ1NTKCk7XHJcbn0gXHJcbnN0cmluZ1tdIGRhdGEgPSAoc3RyaW5nW10pVEQuU3BsaXQoZS5EYXRhLCBURC5kZWxpbXM1KTtcclxuZm9yIChpbnQgaSA9IDA7IGkgPCBkYXRhLkxlbmd0aDsgaSsrKSB7XHJcblRyYW5zZmVyU3RyaW5nIGRzPVRELlRvVHJhbnNmZXJTdHJpbmcoZGF0YVtpXSk7XHJcbnN0cmluZyB0cmFucyA9IGRzLlRyYW5zO1xyXG5pZiAoZHMuQWN0aW9uID09IFwiV2FpdEZvclF1ZXVlXCIpIHtcclxud2ViU29ja2V0LlNlbmQoZGF0YVtpXSk7XHJcbn0gZWxzZSBpZiAoZHMuQWN0aW9uID09IFwiTUpIX0Nsb3NlU2VydmVyXCIpIHtcclxud2ViU29ja2V0LlNlbmQoZGF0YVtpXSk7XHJcbn0gZWxzZSBpZiAoZHMuQWN0aW9uID09IFwiUGluZ1wiKSB7XHJcbndlYlNvY2tldC5TZW5kKGRhdGFbaV0pO1xyXG59IGVsc2UgaWYgKGRzLkFjdGlvbiA9PSBcIkxvYWRlZFwiKSB7XHJcbkFwcGxpY2F0aW9uLkN1cnJlbnQuUmVzb3VyY2VzW1wiSW5kZXhcIl0gPSBkcy5EYXRhO1xyXG53ZWJTb2NrZXRSZWFkeS5TZXRSZXN1bHQodHJ1ZSk7XHJcbl9XU0ludGVybmFscy5TdGF0dXMgPSBcIldlYlNvY2tldCBPcGVuZWQgXCI7XHJcbkFsbFJlYWR5ID0gdHJ1ZTtcclxuQXBwbGljYXRpb24uQ3VycmVudC5SZXNvdXJjZXNbXCJBbGxSZWFkeVwiXSA9IEFsbFJlYWR5O1xyXG50aGlzLkluaXRpYWxpemVDb21wb25lbnQoKTtcclxuTWFrZVdpblNpemUoX3F3Y19Sb290LF9XU0ludGVybmFscyk7XHJcbl9xd2NfUm9vdC5Ob3RpZnlQcm9wZXJ0eUNoYW5nZWQoXCJGb250TGlzdFwiKTtcclxuX3F3Y19Sb290Lk5vdGlmeVByb3BlcnR5Q2hhbmdlZChcIkZvbnRGYW1pbHlcIik7XHJcbl9xd2NfUm9vdC5Ob3RpZnlQcm9wZXJ0eUNoYW5nZWQoXCJDYXB0aW9uXCIpO1xyXG5fcXdjX1Jvb3QuTm90aWZ5UHJvcGVydHlDaGFuZ2VkKFwiVVJMXCIpO1xyXG5fcXdjX1Jvb3QuTm90aWZ5UHJvcGVydHlDaGFuZ2VkKFwiVVJMU1wiKTtcclxuX3F3Y19Sb290Lk5vdGlmeVByb3BlcnR5Q2hhbmdlZChcIkNhcHRpb25zXCIpO1xyXG5JbnRlcm9wLkV4ZWN1dGVKYXZhU2NyaXB0KFwibG9hZEZvbnQoJDAsJDEpXCIsXCJBUEwzODVcIixcImFwcC1jc2h0bWw1L3Jlcy9RV0MvZm9udHMvYXBsMzg1LXdlYmZvbnQud29mZlwiKTtcclxuTGlzdDxzdHJpbmc+IGZ1bGxmb250ID0gZ2xvYmFsOjpCcmlkZ2UuU2NyaXB0LkNhbGxGb3IobmV3IExpc3Q8c3RyaW5nPigpLChfbzEpPT57X28xLkFkZChcIkFQTDM4NVwiKTtfbzEuQWRkKFwiQW5kYWzDqSBNb25vXCIpO19vMS5BZGQoXCJBcmlhbFwiKTtfbzEuQWRkKFwiQXJpYWwgQmxhY2tcIik7X28xLkFkZChcIkFyaWFsIE5hcnJvd1wiKTtfbzEuQWRkKFwiQXJpYWwgUm91bmRlZCBNVCBCb2xkXCIpO19vMS5BZGQoXCJCYXNrZXJ2aWxsZVwiKTtfbzEuQWRkKFwiQm9kb25pIDcyXCIpO19vMS5BZGQoXCJCb2RvbmkgTVRcIik7X28xLkFkZChcIkJyYWRsZXkgSGFuZFwiKTtfbzEuQWRkKFwiQnJ1c2ggU2NyaXB0IE1UXCIpO19vMS5BZGQoXCJDYWxpYnJpXCIpO19vMS5BZGQoXCJDYWxpc3RvIE1UXCIpO19vMS5BZGQoXCJDYW1icmlhXCIpO19vMS5BZGQoXCJDYW5kYXJhXCIpO19vMS5BZGQoXCJDZW50dXJ5IEdvdGhpY1wiKTtfbzEuQWRkKFwiQ29taWMgU2FucyBNU1wiKTtfbzEuQWRkKFwiQ29uc29sYXNcIik7X28xLkFkZChcIkNvcHBlcnBsYXRlIEdvdGhpY1wiKTtfbzEuQWRkKFwiQ291cmllclwiKTtfbzEuQWRkKFwiQ291cmllciBOZXdcIik7X28xLkFkZChcIkRlamF2dSBTYW5zXCIpO19vMS5BZGQoXCJEaWRvdFwiKTtfbzEuQWRkKFwiRnJhbmtsaW4gR290aGljXCIpO19vMS5BZGQoXCJHYXJhbW9uZFwiKTtfbzEuQWRkKFwiR2VvcmdpYVwiKTtfbzEuQWRkKFwiR2lsbCBTYW5zXCIpO19vMS5BZGQoXCJHb3VkeSBPbGQgU3R5bGVcIik7X28xLkFkZChcIkhlbHZldGljYVwiKTtfbzEuQWRkKFwiSGVsdmV0aWNhIE5ldVwiKTtfbzEuQWRkKFwiSW1wYWN0XCIpO19vMS5BZGQoXCJMdWNpZGFcIik7X28xLkFkZChcIkx1Y2lkYSBCcmlnaHRcIik7X28xLkFkZChcIkx1Y2lkYSBIYW5kd3JpdGluZ1wiKTtfbzEuQWRkKFwiTHVjaWRhIFNhbnNcIik7X28xLkFkZChcIkx1bWluYXJpXCIpO19vMS5BZGQoXCJNaWNyb3NvZnQgU2FucyBTZXJpZlwiKTtfbzEuQWRkKFwiTW9uYWNvXCIpO19vMS5BZGQoXCJPcHRpbWFcIik7X28xLkFkZChcIlBhbGF0aW5vXCIpO19vMS5BZGQoXCJQZXJwZXR1YVwiKTtfbzEuQWRkKFwiUmFnZVwiKTtfbzEuQWRkKFwiUm9ja3dlbGxcIik7X28xLkFkZChcIlNjcmlwdCBNVFwiKTtfbzEuQWRkKFwiU2Vnb2UgVUlcIik7X28xLkFkZChcIlNlZ29lIHNjcmlwdFwiKTtfbzEuQWRkKFwiU25lbGwgUm91bmRoYW5kXCIpO19vMS5BZGQoXCJUYWhvbWFcIik7X28xLkFkZChcIlRpbWVzIE5ldyBSb21hblwiKTtfbzEuQWRkKFwiVHJlYnVjaGV0IE1TXCIpO19vMS5BZGQoXCJWZXJkYW5hXCIpO3JldHVybiBfbzE7fSk7XHJcbl9xd2NfUm9vdC5NSkhfRm9udExpc3RfU2hhcGVbMF0gPSA1MTtcclxuX3F3Y19Sb290Lk1KSF9Gb250TGlzdF9TaGFwZVsxXSA9IDg7XHJcbl9xd2NfUm9vdC5NSkhfRm9udEZhbWlseV9TaGFwZSA9IDUxO1xyXG5MaXN0PExpc3Q8QVBMSXRlbT4+IGYgPSBuZXcgTGlzdDxMaXN0PEFQTEl0ZW0+PigpO1xyXG5mb3IgKGludCByID0gMDtyPDUxOyByKyspIHtcclxuZi5BZGQobmV3IExpc3Q8QVBMSXRlbT4oKSk7XHJcbmZbcl0uQWRkKG5ldyBBUExJdGVtKGZ1bGxmb250W3JdKSk7XHJcbmZbcl0uQWRkKG5ldyBBUExJdGVtKDApKTtcclxuZltyXS5BZGQobmV3IEFQTEl0ZW0oMCkpO1xyXG5mW3JdLkFkZChuZXcgQVBMSXRlbSgwKSk7XHJcbmZbcl0uQWRkKG5ldyBBUExJdGVtKDApKTtcclxuZltyXS5BZGQobmV3IEFQTEl0ZW0oMCkpO1xyXG5mW3JdLkFkZChuZXcgQVBMSXRlbSgwKSk7XHJcbmZbcl0uQWRkKG5ldyBBUExJdGVtKDApKTtcclxufSBcclxuX3F3Y19Sb290LkZvbnRMaXN0ID0gZjtcclxuX3F3Y19Sb290LkZvbnRGYW1pbHkgPSAgZ2xvYmFsOjpCcmlkZ2UuU2NyaXB0LkNhbGxGb3IobmV3IExpc3Q8c3RyaW5nPigpLChfbzIpPT57X28yLkFkZChcIkFQTDM4NVwiKTtfbzIuQWRkKFwiQW5kYWzDqSBNb25vLCBtb25vc3BhY2VcIik7X28yLkFkZChcIkFyaWFsLCBIZWx2ZXRpY2EgTmV1ZSwgSGVsdmV0aWNhLCBzYW5zLXNlcmlmXCIpO19vMi5BZGQoXCJBcmlhbCBCbGFjaywgQXJpYWwgQm9sZCwgR2FkZ2V0LCBzYW5zLXNlcmlmXCIpO19vMi5BZGQoXCJBcmlhbCBOYXJyb3csIEFyaWFsLCBzYW5zLXNlcmlmXCIpO19vMi5BZGQoXCJBcmlhbCBSb3VuZGVkIE1UIEJvbGQsIEhlbHZldGljYSBSb3VuZGVkLCBBcmlhbCwgc2Fucy1zZXJpZlwiKTtfbzIuQWRkKFwiQmFza2VydmlsbGUsIEJhc2tlcnZpbGxlIE9sZCBGYWNlLCBHYXJhbW9uZCwgVGltZXMgTmV3IFJvbWFuLCBzZXJpZlwiKTtfbzIuQWRkKFwiQm9kb25pIDcyLCBCb2RvbmkgTVQsIERpZG90LCBEaWRvdCBMVCBTVEQsIEhvZWZsZXIgVGV4dCwgR2FyYW1vbmQsIFRpbWVzIE5ldyBSb21hbiwgc2VyaWZcIik7X28yLkFkZChcIkJvZG9uaSBNVCwgQm9kb25pIDcyLCBEaWRvdCwgRGlkb3QgTFQgU1RELCBIb2VmbGVyIFRleHQsIEdhcmFtb25kLCBUaW1lcyBOZXcgUm9tYW4sIHNlcmlmXCIpO19vMi5BZGQoXCJCcmFkbGV5IEhhbmQsIGN1cnNpdmVcIik7X28yLkFkZChcIkJydXNoIFNjcmlwdCBNVCwgY3Vyc2l2ZVwiKTtfbzIuQWRkKFwiQ2FsaWJyaSwgQ2FuZGFyYSwgU2Vnb2UsIFNlZ29lIFVJLCBPcHRpbWEsIEFyaWFsLCBzYW5zLXNlcmlmXCIpO19vMi5BZGQoXCJDYWxpc3RvIE1ULCBCb29rbWFuIE9sZCBTdHlsZSwgQm9va21hbiwgR291ZHkgT2xkIFN0eWxlLCBHYXJhbW9uZCwgSG9lZmxlciBUZXh0LCBCaXRzdHJlYW0gQ2hhcnRlciwgR2VvcmdpYSwgc2VyaWZcIik7X28yLkFkZChcIkNhbWJyaWEsIEdlb3JnaWEsIHNlcmlmXCIpO19vMi5BZGQoXCJDYW5kYXJhLCBDYWxpYnJpLCBTZWdvZSwgU2Vnb2UgVUksIE9wdGltYSwgQXJpYWwsIHNhbnMtc2VyaWZcIik7X28yLkFkZChcIkNlbnR1cnkgR290aGljLCBDZW50dXJ5R290aGljLCBBcHBsZUdvdGhpYywgc2Fucy1zZXJpZlwiKTtfbzIuQWRkKFwiQ29taWMgU2FucyBNUywgY3Vyc2l2ZVwiKTtfbzIuQWRkKFwiQ29uc29sYXMsIG1vbmFjbywgbW9ub3NwYWNlXCIpO19vMi5BZGQoXCJDb3BwZXJwbGF0ZSBHb3RoaWMsIENvcHBlcnBsYXRlIEdvdGhpYyBMaWdodCwgZmFudGFzeVwiKTtfbzIuQWRkKFwiQ291cmllciwgbW9ub3NwYWNlXCIpO19vMi5BZGQoXCJDb3VyaWVyIE5ldywgQ291cmllciwgTHVjaWRhIFNhbnMgVHlwZXdyaXRlciwgTHVjaWRhIFR5cGV3cml0ZXIsIG1vbm9zcGFjZVwiKTtfbzIuQWRkKFwiRGVqYXZ1IFNhbnMsIEFyaWFsLCBWZXJkYW5hLCBzYW5zLXNlcmlmXCIpO19vMi5BZGQoXCJEaWRvdCwgRGlkb3QgTFQgU1RELCBIb2VmbGVyIFRleHQsIEdhcmFtb25kLCBDYWxpc3RvIE1ULCBUaW1lcyBOZXcgUm9tYW4sIHNlcmlmXCIpO19vMi5BZGQoXCJGcmFua2xpbiBHb3RoaWMsIEFyaWFsIEJvbGQsIEFyaWFsLCBzYW5zLXNlcmlmXCIpO19vMi5BZGQoXCJHYXJhbW9uZCwgQmFza2VydmlsbGUsIEJhc2tlcnZpbGxlIE9sZCBGYWNlLCBIb2VmbGVyIFRleHQsIFRpbWVzIE5ldyBSb21hbiwgc2VyaWZcIik7X28yLkFkZChcIkdlb3JnaWEsIFRpbWVzLCBUaW1lcyBOZXcgUm9tYW4sIHNlcmlmXCIpO19vMi5BZGQoXCJHaWxsIFNhbnMsIEdpbGwgU2FucyBNVCwgQ2FsaWJyaSwgc2Fucy1zZXJpZlwiKTtfbzIuQWRkKFwiR291ZHkgT2xkIFN0eWxlLCBHYXJhbW9uZCwgQmlnIENhc2xvbiwgVGltZXMgTmV3IFJvbWFuLCBzZXJpZlwiKTtfbzIuQWRkKFwiSGVsdmV0aWNhLCBIZWx2ZXRpY2EgTmV1LCBBcmlhbCwgc2Fucy1zZXJpZi5cIik7X28yLkFkZChcIkhlbHZldGljYSBOZXUsIEhlbHZldGljYSwgQXJpYWwsIHNhbnMtc2VyaWYuXCIpO19vMi5BZGQoXCJJbXBhY3QsIENoYXJjb2FsLCBIZWx2ZXRpY2EgSW5zZXJhdCwgQml0c3RyZWFtIFZlcmEgU2FucyBCb2xkLCBBcmlhbCBCbGFjaywgc2Fucy1zZXJpZi5cIik7X28yLkFkZChcIkx1Y2lkYSwgbW9ub3NwYWNlXCIpO19vMi5BZGQoXCJMdWNpZGEgQnJpZ2h0LCBHZW9yZ2lhLCBzZXJpZi5cIik7X28yLkFkZChcIkx1Y2lkYSBIYW5kd3JpdGluZywgY3Vyc2l2ZVwiKTtfbzIuQWRkKFwiTHVjaWRhIFNhbnMsIEhlbHZldGljYSwgQXJpYWwsIHNhbnMtc2VyaWYuXCIpO19vMi5BZGQoXCJMdW1pbmFyaSwgZmFudGFzeVwiKTtfbzIuQWRkKFwiTWljcm9zb2Z0IFNhbnMgU2VyaWYsIHNhbnMtc2VyaWYuXCIpO19vMi5BZGQoXCJNb25hY28sIG1vbm9zcGFjZVwiKTtfbzIuQWRkKFwiT3B0aW1hLCBTZWdvZSwgU2Vnb2UgVUksIENhbmRhcmEsIENhbGlicmksIEFyaWFsLCBzYW5zLXNlcmlmLlwiKTtfbzIuQWRkKFwiUGFsYXRpbm8sIFBhbGF0aW5vIExpbm90eXBlLCBQYWxhdGlubyBMVCBTVEQsIEJvb2sgQW50aXF1YSwgR2VvcmdpYSwgc2VyaWYuXCIpO19vMi5BZGQoXCJQZXJwZXR1YSwgQmFza2VydmlsbGUsIEJpZyBDYXNsb24sIFBhbGF0aW5vIExpbm90eXBlLCBQYWxhdGlubywgc2VyaWYuXCIpO19vMi5BZGQoXCJSYWdlLCBjdXJzaXZlXCIpO19vMi5BZGQoXCJSb2Nrd2VsbCwgQ291cmllciBCb2xkLCBDb3VyaWVyLCBHZW9yZ2lhLCBUaW1lcywgVGltZXMgTmV3IFJvbWFuLCBzZXJpZi5cIik7X28yLkFkZChcIlNjcmlwdCBNVCwgY3Vyc2l2ZVwiKTtfbzIuQWRkKFwiU2Vnb2UgVUksIEZydXRpZ2VyLCBEZWphdnUgU2FucywgSGVsdmV0aWNhIE5ldWUsIEFyaWFsLCBzYW5zLXNlcmlmLlwiKTtfbzIuQWRkKFwiU2Vnb2Ugc2NyaXB0LCBjdXJzaXZlXCIpO19vMi5BZGQoXCJTbmVsbCBSb3VuZGhhbmQsIGN1cnNpdmVcIik7X28yLkFkZChcIlRhaG9tYSwgVmVyZGFuYSwgU2Vnb2UsIHNhbnMtc2VyaWYuXCIpO19vMi5BZGQoXCJUaW1lcyBOZXcgUm9tYW4sIEdlb3JnaWEsIHNlcmlmO1wiKTtfbzIuQWRkKFwiVHJlYnVjaGV0IE1TLCBMdWNpZGEgR3JhbmRlLCBMdWNpZGEgU2FucyBVbmljb2RlLCBMdWNpZGEgU2Fucywgc2Fucy1zZXJpZi5cIik7X28yLkFkZChcIlZlcmRhbmEsIEdlbmV2YSwgc2Fucy1zZXJpZi5cIik7cmV0dXJuIF9vMjt9KTtcclxuX3F3Y19Sb290Lk5vdGlmeVByb3BlcnR5Q2hhbmdlZChcIkZvbnRMaXN0XCIpO1xyXG5fcXdjX1Jvb3QuTm90aWZ5UHJvcGVydHlDaGFuZ2VkKFwiRm9udEZhbWlseVwiKTtcclxueHN0cmluZyA9IG5ldyBUcmFuc2ZlclN0cmluZygpO1xyXG54c3RyaW5nLlR5cGUgPSBcIlNldHVwQ29tcGxldGVcIjtcclxuU2V0dXBDb21wbGV0ZVJ1biA9IHRydWU7XHJcbmQgPSBURC5Gcm9tVHJhbnNmZXJTdHJpbmcoeHN0cmluZyk7XHJcbndlYlNvY2tldC5TZW5kKGQpO1xyXG52YXIgZWxlbSA9IEludGVyb3AuRXhlY3V0ZUphdmFTY3JpcHQoXCJkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgkMCk7XCIsXCJtamhzcGxhc2hzY3JlZW5cIik7XHJcbkludGVyb3AuRXhlY3V0ZUphdmFTY3JpcHQoXCIkMC5zdHlsZSA9ICQxO1wiLCBlbGVtLCBcImRpc3BsYXk6IG5vbmU7XCIpO1xyXG59IGVsc2UgaWYgKGRzLkFjdGlvbiA9PSBcIkNyZWF0ZVwiKSB7ICAvLyBxV0NcclxuRW5kQ3VzdG9tQ1NTKCk7XHJcbmRzLk5hbWUgPSBcIlR5cGVcIjtcclxuZHMuRGF0YSA9IGRzLkNsYXNzLlN1YnN0cmluZygzKTtcclxuaWYgKGRzLkNsYXNzID09IFwicXdjQnV0dG9uXCIgfHxkcy5DbGFzcyA9PSBcInF3Y0NvbWJvXCIgfHxkcy5DbGFzcyA9PSBcInF3Y0RhdGVUaW1lUGlja2VyXCIgfHxkcy5DbGFzcyA9PSBcInF3Y01zZ0JveFwiIHx8ZHMuQ2xhc3MgPT0gXCJxd2NFZGl0XCIgfHxkcy5DbGFzcyA9PSBcInF3Y0xpc3RcIiB8fGRzLkNsYXNzID09IFwicXdjTGlzdFZpZXdTaW5nbGVcIiB8fGRzLkNsYXNzID09IFwicXdjTGlzdFZpZXdNdWx0aVwiIHx8ZHMuQ2xhc3MgPT0gXCJxd2NNZW51SXRlbVwiIHx8ZHMuQ2xhc3MgPT0gXCJxd2NUYWJDb250cm9sXCIgKSB7XHJcbmRzLkNsYXNzICs9IGRzLkV4dHJhcztcclxufVxyXG5zdHJpbmcgY2wgPSBkcy5DbGFzcyArIFwiX0RhdGFcIjtcclxub2JqZWN0IG8gPSBBUEwuTWFrZUluc3RhbmNlKFwiRGF0YUJpbmRpbmdcIiwgY2wsIGRzLkluc3RhbmNlLCB0aGlzKTtcclxueHN0cmluZyA9IG5ldyBUcmFuc2ZlclN0cmluZygpO1xyXG54c3RyaW5nLlRyYW5zID0gdHJhbnM7XHJcbmQgPSBURC5Gcm9tVHJhbnNmZXJTdHJpbmcoeHN0cmluZyk7XHJcbndlYlNvY2tldC5TZW5kKGQpO1xyXG59IGVsc2UgaWYgKGRzLkFjdGlvbiA9PSBcIkVuZFJ1bkxvYWRlZFwiKSB7XHJcbkNyZWF0ZUNvbnRyb2woZHMpO1xyXG59IGVsc2UgaWYgKGRzLkFjdGlvbiA9PSBcIk9sZENyZWF0ZVwiKSB7ICAvLyBxV0NcclxuZHMuTmFtZSA9IFwiVHlwZVwiO1xyXG5kcy5EYXRhID0gZHMuQ2xhc3MuU3Vic3RyaW5nKDMpO1xyXG5pZiAoZHMuQ2xhc3MgPT0gXCJxd2NCdXR0b25cIiB8fGRzLkNsYXNzID09IFwicXdjQ29tYm9cIiB8fGRzLkNsYXNzID09IFwicXdjRGF0ZVRpbWVQaWNrZXJcIiB8fGRzLkNsYXNzID09IFwicXdjTXNnQm94XCIgfHxkcy5DbGFzcyA9PSBcInF3Y0VkaXRcIiB8fGRzLkNsYXNzID09IFwicXdjTGlzdFwiIHx8ZHMuQ2xhc3MgPT0gXCJxd2NMaXN0Vmlld1NpbmdsZVwiIHx8ZHMuQ2xhc3MgPT0gXCJxd2NMaXN0Vmlld011bHRpXCIgfHxkcy5DbGFzcyA9PSBcInF3Y01lbnVJdGVtXCIgfHxkcy5DbGFzcyA9PSBcInF3Y1RhYkNvbnRyb2xcIiApIHtcclxuZHMuQ2xhc3MgKz0gZHMuRXh0cmFzO1xyXG59XHJcbkFzc2VtYmx5IGFzc2VtYmx5ID0gQVBMLkdldEFzc2VtYmx5KFwiRGF0YUJpbmRpbmdcIiwgdGhpcyk7XHJcblR5cGUgdHlwZSA9IGFzc2VtYmx5LkdldFR5cGUoXCJEYXRhQmluZGluZ1wiICsgXCIuXCIgKyBkcy5DbGFzcyk7XHJcbnZhciBvYiA9IEFjdGl2YXRvci5DcmVhdGVJbnN0YW5jZSh0eXBlLGRzKTtcclxuU3RyaW5nIGNsID0gQVBMLkdldENsYXNzQnlOYW1lKGRzLkluc3RhbmNlKTtcclxudmFyIG9iaiA9IEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGNsLCBkcy5JbnN0YW5jZSwgIG9iKTtcclxueHN0cmluZyA9IG5ldyBUcmFuc2ZlclN0cmluZygpO1xyXG54c3RyaW5nLlRyYW5zID0gdHJhbnM7XHJcbmQ9VEQuRnJvbVRyYW5zZmVyU3RyaW5nKHhzdHJpbmcpO1xyXG53ZWJTb2NrZXQuU2VuZChkKTtcclxuZGlyZWN0d2ViU29ja2V0LlNlbmQoZCk7XHJcbn0gZWxzZSBpZiAoZHMuQWN0aW9uID09IFwiQ3JlYXRlQ29udGludWUxXCIpIHtcclxuaWYgKGRzLkNsYXNzID09IFwicXdjQnV0dG9uXCIgfHxkcy5DbGFzcyA9PSBcInF3Y0NvbWJvXCIgfHxkcy5DbGFzcyA9PSBcInF3Y0RhdGVUaW1lUGlja2VyXCIgfHxkcy5DbGFzcyA9PSBcInF3Y01zZ0JveFwiIHx8ZHMuQ2xhc3MgPT0gXCJxd2NFZGl0XCIgfHxkcy5DbGFzcyA9PSBcInF3Y0xpc3RcIiB8fGRzLkNsYXNzID09IFwicXdjTGlzdFZpZXdTaW5nbGVcIiB8fGRzLkNsYXNzID09IFwicXdjTGlzdFZpZXdNdWx0aVwiIHx8ZHMuQ2xhc3MgPT0gXCJxd2NNZW51SXRlbVwiIHx8ZHMuQ2xhc3MgPT0gXCJxd2NUYWJDb250cm9sXCIgKSB7XHJcbmRzLkNsYXNzICs9IGRzLkV4dHJhczsgfVxyXG5Bc3NlbWJseSBhc3NlbWJseSA9IEFQTC5HZXRBc3NlbWJseShcIkRhdGFCaW5kaW5nXCIsIHRoaXMpO1xyXG5TdHJpbmcgY2wgPSBBUEwuR2V0Q2xhc3NCeU5hbWUoZHMuSW5zdGFuY2UpO1xyXG52YXIgb2JqID0gQVBMLkdldEluc3RhbmNlKFwiRGF0YUJpbmRpbmdcIiwgY2wsIGRzLkluc3RhbmNlLCBudWxsKTtcclxuVHlwZSBjbGEgPSBhc3NlbWJseS5HZXRUeXBlKFwiRGF0YUJpbmRpbmdcIiArIFwiLlwiICsgZHMuQ2xhc3MpO1xyXG5NZXRob2RJbmZvIG1ldGhvZCA9IGNsYS5HZXRNZXRob2QoXCJDcmVhdGVDb250aW51ZTFcIik7XHJcbmlmIChtZXRob2QgIT0gbnVsbCkge1xyXG52YXIgYXJndW1lbnRzID0gbmV3IG9iamVjdFtdIHsgZHMgfTtcclxubWV0aG9kLkludm9rZSgoKE1KSF9Db21tb25EYXRhKW9iaikuTUpIX0NsYXNzLCBhcmd1bWVudHMpOyB9XHJcbnhzdHJpbmcgPSBuZXcgVHJhbnNmZXJTdHJpbmcoKTtcclxueHN0cmluZy5UcmFucyA9IHRyYW5zO1xyXG5kID0gVEQuRnJvbVRyYW5zZmVyU3RyaW5nKHhzdHJpbmcpO1xyXG53ZWJTb2NrZXQuU2VuZChkKTtcclxuZGlyZWN0d2ViU29ja2V0LlNlbmQoZCk7XHJcbn0gZWxzZSBpZiAoZHMuQWN0aW9uID09IFwiQ3JlYXRlQ29udGludWUyXCIpIHsgIC8vIFxyXG5pZiAoZHMuQ2xhc3MgPT0gXCJxd2NCdXR0b25cIiB8fGRzLkNsYXNzID09IFwicXdjQ29tYm9cIiB8fGRzLkNsYXNzID09IFwicXdjRGF0ZVRpbWVQaWNrZXJcIiB8fGRzLkNsYXNzID09IFwicXdjTXNnQm94XCIgfHxkcy5DbGFzcyA9PSBcInF3Y0VkaXRcIiB8fGRzLkNsYXNzID09IFwicXdjTGlzdFwiIHx8ZHMuQ2xhc3MgPT0gXCJxd2NMaXN0Vmlld1NpbmdsZVwiIHx8ZHMuQ2xhc3MgPT0gXCJxd2NMaXN0Vmlld011bHRpXCIgfHxkcy5DbGFzcyA9PSBcInF3Y01lbnVJdGVtXCIgfHxkcy5DbGFzcyA9PSBcInF3Y1RhYkNvbnRyb2xcIiApIHtcclxuZHMuQ2xhc3MgKz0gZHMuRXh0cmFzO1xyXG59XHJcbkFzc2VtYmx5IGFzc2VtYmx5ID0gQVBMLkdldEFzc2VtYmx5KFwiRGF0YUJpbmRpbmdcIix0aGlzKTtcclxuU3RyaW5nIGNsID0gQVBMLkdldENsYXNzQnlOYW1lKGRzLkluc3RhbmNlKTtcclxudmFyIG9iaiA9IEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGNsLCBkcy5JbnN0YW5jZSxudWxsKTtcclxuVHlwZSBjbGEgPSBhc3NlbWJseS5HZXRUeXBlKFwiRGF0YUJpbmRpbmdcIiArIFwiLlwiICsgZHMuQ2xhc3MpO1xyXG5NZXRob2RJbmZvIG1ldGhvZCA9IGNsYS5HZXRNZXRob2QoXCJDcmVhdGVDb250aW51ZTJcIik7XHJcbmlmIChtZXRob2QgIT0gbnVsbCkge1xyXG52YXIgYXJndW1lbnRzID0gbmV3IG9iamVjdFtdIHsgZHMgfTtcclxubWV0aG9kLkludm9rZSgoKE1KSF9Db21tb25EYXRhKSBvYmopLk1KSF9DbGFzcywgYXJndW1lbnRzKTtcclxufSBcclxuaWYgKDAhPWRzLkV4dHJhcy5MZW5ndGgpIHtcclxuZHMuTmFtZSA9IFwiU3R5bGVcIjtcclxuZHMuRGF0YSA9IGRzLkV4dHJhcztcclxuVHlwZSB0eXBlY2wgPSBhc3NlbWJseS5HZXRUeXBlKFwiRGF0YUJpbmRpbmdcIiArIFwiLlwiICsgY2wpO1xyXG5NZXRob2RJbmZvIG1ldGhvZDEgPSB0eXBlY2wuR2V0TWV0aG9kKFwiUnVuUHJvcGVydHlDaGFuZ2VkSW5cIik7XHJcbnZhciBhcmd1bWVudHMgPSBuZXcgb2JqZWN0W10geyBkcywgZmFsc2UgfTtcclxubWV0aG9kMS5JbnZva2Uob2JqLCBhcmd1bWVudHMpO1xyXG59IFxyXG54c3RyaW5nID0gbmV3IFRyYW5zZmVyU3RyaW5nKCk7XHJcbnhzdHJpbmcuVHJhbnMgPSB0cmFucztcclxuZD1URC5Gcm9tVHJhbnNmZXJTdHJpbmcoeHN0cmluZyk7XHJcbndlYlNvY2tldC5TZW5kKGQpO1xyXG5kaXJlY3R3ZWJTb2NrZXQuU2VuZChkKTtcclxufSBlbHNlIGlmIChkcy5BY3Rpb24gPT0gXCJFblF1ZXVlXCIpIHsgIC8vIHFOUVxyXG5TdHJpbmcgTlFyZXN1bHQ7XHJcbmRzLkNsYXNzID0gQVBMLkdldENsYXNzQnlOYW1lKGRzLkluc3RhbmNlKTtcclxuaWYgKG51bGwgIT0gZHMuQ2xhc3MpIHtcclxub2JqZWN0IG9iaiA9IEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgdGhpcyk7XHJcbnZhciBhcmd1bWVudHMgPSBuZXcgb2JqZWN0W10geyBkcywgdGhpcyB9O1xyXG5Bc3NlbWJseSBhc3NlbWJseSA9IEFQTC5HZXRBc3NlbWJseShcIlFXQ1wiLCB0aGlzKTtcclxuVHlwZSB0eXBlID0gYXNzZW1ibHkuR2V0VHlwZShcIlFXQ1wiICsgXCIuTlFcIik7XHJcbk1ldGhvZEluZm8gbWV0aG9kID0gdHlwZS5HZXRNZXRob2QoXCJEb1wiICsgZHMuTmFtZSk7XHJcbmlmIChVdGlscy5Jc1N0YXRpYyhtZXRob2QpKSB7XHJcbk5RcmVzdWx0ID0gKFN0cmluZyltZXRob2QuSW52b2tlKG51bGwsIGFyZ3VtZW50cyk7XHJcbn0gZWxzZSB7XHJcbk5RcmVzdWx0ID0gKFN0cmluZyltZXRob2QuSW52b2tlKG9iaiwgYXJndW1lbnRzKTtcclxufSBcclxufSBlbHNlIHtcclxuTlFyZXN1bHQ9XCJGYWxzZVwiO1xyXG59IFxyXG54c3RyaW5nID0gbmV3IFRyYW5zZmVyU3RyaW5nKCk7XHJcbnhzdHJpbmcuVHlwZSA9IFwiRW5RdWV1ZVwiO1xyXG54c3RyaW5nLkRhdGEgPSBOUXJlc3VsdDtcclxueHN0cmluZy5UcmFucyA9IHRyYW5zO1xyXG5kID0gVEQuRnJvbVRyYW5zZmVyU3RyaW5nKHhzdHJpbmcpO1xyXG5kaXJlY3R3ZWJTb2NrZXQuU2VuZChkKTsgICAvLyBQcm9jZXNzIHFOUSBcclxufSBlbHNlIFJ1bkRhdGFCaW5kaW5nKGRzKTtcclxufX07XHJcbndlYlNvY2tldC5PbkVycm9yKz0ocyxlKT0+X1dTSW50ZXJuYWxzLlN0YXR1cz1cIkVSUk9SIDogXCIgKyBlLkRhdGE7XHJcbndlYlNvY2tldC5PbkNsb3NlKz0ocyxlKT0+X1dTSW50ZXJuYWxzLlN0YXR1cz1cIldlYlNvY2tldCBDbG9zZWQgXCI7XHJcbndlYlNvY2tldC5Pbk9wZW4rPShzLGUpPT4ge1xyXG54c3RyaW5nID0gbmV3IFRyYW5zZmVyU3RyaW5nKCk7XHJcbnhzdHJpbmcuVHlwZSA9IFwiU2Vzc2lvblN0YXJ0XCI7XHJcbnhzdHJpbmcuRGF0YSA9IChzdHJpbmcpIEFwcGxpY2F0aW9uLkN1cnJlbnQuUmVzb3VyY2VzW1wiT3JpZ2luYWxVUkxcIl07XHJcbmQgPSBURC5Gcm9tVHJhbnNmZXJTdHJpbmcoeHN0cmluZyk7XHJcbndlYlNvY2tldC5TZW5kKGQpO1xyXG59O1xyXG5kaXJlY3R3ZWJTb2NrZXQuT25PcGVuICs9IGFzeW5jIChzLCBlKSA9PlxyXG57IFxyXG54c3RyaW5nID0gbmV3IFRyYW5zZmVyU3RyaW5nKCk7XHJcbmF3YWl0IFdlYlNvY2tldFJlYWR5O1xyXG54c3RyaW5nLkRhdGEgPSAoc3RyaW5nKSBBcHBsaWNhdGlvbi5DdXJyZW50LlJlc291cmNlc1tcIkluZGV4XCJdOyAgLy8gSW5kZXhcclxueHN0cmluZy5UeXBlID0gXCJJbmRleFwiO1xyXG5zdHJpbmcgZHggPSBURC5Gcm9tVHJhbnNmZXJTdHJpbmcoeHN0cmluZyk7XHJcbmRpcmVjdHdlYlNvY2tldC5TZW5kKGR4KTtcclxufTtcclxuZGlyZWN0d2ViU29ja2V0Lk9uTWVzc2FnZSArPSAocywgZSkgPT4ge1xyXG5UcmFuc2ZlclN0cmluZyBkcyA9IFRELlRvVHJhbnNmZXJTdHJpbmcoZS5EYXRhKTtcclxuc3RyaW5nIHRyYW5zID0gZHMuVHJhbnM7XHJcbmlmIChkcy5BY3Rpb24gPT0gXCJNSkhfQ2xvc2VTZXJ2ZXJcIikge1xyXG5kaXJlY3R3ZWJTb2NrZXQuU2VuZChlLkRhdGEpOyAgIC8vIFByb2Nlc3MgTUpIX0Nsb3NlU2VydmVyXHJcbn0gZWxzZSBpZiAoZHMuQWN0aW9uID09IFwiRW5RdWV1ZVwiKXsgIC8vIHFOUVxyXG5TdHJpbmcgTlFyZXN1bHQ7XHJcbmRzLkNsYXNzID0gQVBMLkdldENsYXNzQnlOYW1lKGRzLkluc3RhbmNlKTtcclxuaWYgKG51bGwgIT0gZHMuQ2xhc3MpIHtcclxub2JqZWN0IG9iaiA9IEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgdGhpcyk7XHJcbnZhciBhcmd1bWVudHMgPSBuZXcgb2JqZWN0W10geyBkcywgdGhpcyB9O1xyXG5Bc3NlbWJseSBhc3NlbWJseSA9IEFQTC5HZXRBc3NlbWJseShcIlFXQ1wiLCB0aGlzKTtcclxuVHlwZSB0eXBlID0gYXNzZW1ibHkuR2V0VHlwZShcIlFXQ1wiICsgXCIuTlFcIik7XHJcbk1ldGhvZEluZm8gbWV0aG9kID0gdHlwZS5HZXRNZXRob2QoXCJEb1wiICsgZHMuTmFtZSk7XHJcbmlmIChVdGlscy5Jc1N0YXRpYyhtZXRob2QpKSB7XHJcbk5RcmVzdWx0ID0gKFN0cmluZyltZXRob2QuSW52b2tlKG51bGwsIGFyZ3VtZW50cyk7XHJcbn0gZWxzZSB7XHJcbk5RcmVzdWx0ID0gKFN0cmluZyltZXRob2QuSW52b2tlKG9iaiwgYXJndW1lbnRzKTtcclxufSBcclxufSBlbHNlIHtcclxuTlFyZXN1bHQgPSBcIkZhbHNlXCI7XHJcbn0gXHJcbnhzdHJpbmcgPSBuZXcgVHJhbnNmZXJTdHJpbmcoKTtcclxueHN0cmluZy5UeXBlID0gXCJFblF1ZXVlXCI7XHJcbnhzdHJpbmcuRGF0YSA9IE5RcmVzdWx0O1xyXG54c3RyaW5nLlRyYW5zID0gdHJhbnM7XHJcbmQgPSBURC5Gcm9tVHJhbnNmZXJTdHJpbmcoeHN0cmluZyk7XHJcbmRpcmVjdHdlYlNvY2tldC5TZW5kKGQpOyAgIC8vIFByb2Nlc3MgcU5RXHJcbn0gZWxzZSBpZiAoZHMuQWN0aW9uID09IFwiUmV0dXJuRXZlbnRcIil7XHJcbkFQTC5SYWlzZUV2ZW50UmV0dXJuZWQoZS5EYXRhKTtcclxufSBcclxufTtcclxufSBcclxuYm9vbCBJc0VKMShzdHJpbmcgaW5wKSB7XHJcbnJldHVybiBmYWxzZTtcclxufSBcclxuYm9vbCBJc0VKMihzdHJpbmcgaW5wKSB7XHJcbmlmIChpbnAgPT0gXCJxd2NBcHBCYXJfRGF0YVwiKSByZXR1cm4gdHJ1ZTtcclxuaWYgKGlucCA9PSBcInF3Y0F2YXRhcl9EYXRhXCIpIHJldHVybiB0cnVlO1xyXG5pZiAoaW5wID09IFwicXdjQmFkZ2VfRGF0YVwiKSByZXR1cm4gdHJ1ZTtcclxuaWYgKGlucCA9PSBcInF3Y0JhckNvZGVfRGF0YVwiKSByZXR1cm4gdHJ1ZTtcclxuaWYgKGlucCA9PSBcInF3Y0JyZWFkQ3J1bWJfRGF0YVwiKSByZXR1cm4gdHJ1ZTtcclxuaWYgKGlucCA9PSBcInF3Y0NhbGVuZGFyX0RhdGFcIikgcmV0dXJuIHRydWU7XHJcbmlmIChpbnAgPT0gXCJxd2NDYXJkX0RhdGFcIikgcmV0dXJuIHRydWU7XHJcbmlmIChpbnAgPT0gXCJxd2NDYXJvdXNlbF9EYXRhXCIpIHJldHVybiB0cnVlO1xyXG5pZiAoaW5wID09IFwicXdjQ2hhcnRfRGF0YVwiKSByZXR1cm4gdHJ1ZTtcclxuaWYgKGlucCA9PSBcInF3Y0NoaXBzX0RhdGFcIikgcmV0dXJuIHRydWU7XHJcbmlmIChpbnAgPT0gXCJxd2NDaXJjdWxhckdhdWdlX0RhdGFcIikgcmV0dXJuIHRydWU7XHJcbmlmIChpbnAgPT0gXCJxd2NDb2xvdXJQaWNrZXJfRGF0YVwiKSByZXR1cm4gdHJ1ZTtcclxuaWYgKGlucCA9PSBcInF3Y0NvbG9yUGlja2VyX0RhdGFcIikgcmV0dXJuIHRydWU7XHJcbmlmIChpbnAgPT0gXCJxd2NDb21ib0Ryb3BfRGF0YVwiKSByZXR1cm4gdHJ1ZTtcclxuaWYgKGlucCA9PSBcInF3Y0NvbWJvRHJvcEVkaXRfRGF0YVwiKSByZXR1cm4gdHJ1ZTtcclxuaWYgKGlucCA9PSBcInF3Y0NvbWJvU2ltcGxlX0RhdGFcIikgcmV0dXJuIHRydWU7XHJcbmlmIChpbnAgPT0gXCJxd2NDb250ZXh0TWVudV9EYXRhXCIpIHJldHVybiB0cnVlO1xyXG5pZiAoaW5wID09IFwicXdjRGFzaEJvYXJkX0RhdGFcIikgcmV0dXJuIHRydWU7XHJcbmlmIChpbnAgPT0gXCJxd2NEYXRhR3JpZF9EYXRhXCIpIHJldHVybiB0cnVlO1xyXG5pZiAoaW5wID09IFwicXdjRGF0YU1hbmFnZXJfRGF0YVwiKSByZXR1cm4gdHJ1ZTtcclxuaWYgKGlucCA9PSBcInF3Y0RhdGVUaW1lUGlja2VyQ29tYm9fRGF0YVwiKSByZXR1cm4gdHJ1ZTtcclxuaWYgKGlucCA9PSBcInF3Y0RpYWdyYW1fRGF0YVwiKSByZXR1cm4gdHJ1ZTtcclxuaWYgKGlucCA9PSBcInF3Y01zZ0JveE1zZ19EYXRhXCIpIHJldHVybiB0cnVlO1xyXG5pZiAoaW5wID09IFwicXdjTXNnQm94SW5mb19EYXRhXCIpIHJldHVybiB0cnVlO1xyXG5pZiAoaW5wID09IFwicXdjTXNnQm94UXVlcnlfRGF0YVwiKSByZXR1cm4gdHJ1ZTtcclxuaWYgKGlucCA9PSBcInF3Y01zZ0JveFdhcm5fRGF0YVwiKSByZXR1cm4gdHJ1ZTtcclxuaWYgKGlucCA9PSBcInF3Y01zZ0JveEVycm9yX0RhdGFcIikgcmV0dXJuIHRydWU7XHJcbmlmIChpbnAgPT0gXCJxd2NEb2N1bWVudEVkaXRvcl9EYXRhXCIpIHJldHVybiB0cnVlO1xyXG5pZiAoaW5wID09IFwicXdjRmlsZU1hbmFnZXJfRGF0YVwiKSByZXR1cm4gdHJ1ZTtcclxuaWYgKGlucCA9PSBcInF3Y0dhbnR0X0RhdGFcIikgcmV0dXJuIHRydWU7XHJcbmlmIChpbnAgPT0gXCJxd2NHcmlkX0RhdGFcIikgcmV0dXJuIHRydWU7XHJcbmlmIChpbnAgPT0gXCJxd2NJbWFnZUVkaXRvcl9EYXRhXCIpIHJldHVybiB0cnVlO1xyXG5pZiAoaW5wID09IFwicXdjTGluZWFyR2F1Z2VfRGF0YVwiKSByZXR1cm4gdHJ1ZTtcclxuaWYgKGlucCA9PSBcInF3Y0ltYWdlX0RhdGFcIikgcmV0dXJuIHRydWU7XHJcbmlmIChpbnAgPT0gXCJxd2NLYW5iYW5fRGF0YVwiKSByZXR1cm4gdHJ1ZTtcclxuaWYgKGlucCA9PSBcInF3Y0xpc3RTaW5nbGVfRGF0YVwiKSByZXR1cm4gdHJ1ZTtcclxuaWYgKGlucCA9PSBcInF3Y0xpc3RNdWx0aV9EYXRhXCIpIHJldHVybiB0cnVlO1xyXG5pZiAoaW5wID09IFwicXdjTGlzdFZpZXdTaW5nbGVfRGF0YVwiKSByZXR1cm4gdHJ1ZTtcclxuaWYgKGlucCA9PSBcInF3Y0xpc3RWaWV3TXVsdGlfRGF0YVwiKSByZXR1cm4gdHJ1ZTtcclxuaWYgKGlucCA9PSBcInF3Y01hcHNfRGF0YVwiKSByZXR1cm4gdHJ1ZTtcclxuaWYgKGlucCA9PSBcInF3Y01lbnRpb25fRGF0YVwiKSByZXR1cm4gdHJ1ZTtcclxuaWYgKGlucCA9PSBcInF3Y01lbnVCYXJfRGF0YVwiKSByZXR1cm4gdHJ1ZTtcclxuaWYgKGlucCA9PSBcInF3Y01lc3NhZ2VfRGF0YVwiKSByZXR1cm4gdHJ1ZTtcclxuaWYgKGlucCA9PSBcInF3Y1BhZ2VyX0RhdGFcIikgcmV0dXJuIHRydWU7XHJcbmlmIChpbnAgPT0gXCJxd2NQREZWaWV3ZXJfRGF0YVwiKSByZXR1cm4gdHJ1ZTtcclxuaWYgKGlucCA9PSBcInF3Y1Bpdm90VGFibGVfRGF0YVwiKSByZXR1cm4gdHJ1ZTtcclxuaWYgKGlucCA9PSBcInF3Y1Byb2dyZXNzQmFyX0RhdGFcIikgcmV0dXJuIHRydWU7XHJcbmlmIChpbnAgPT0gXCJxd2NQcm9ncmVzc0J1dHRvbl9EYXRhXCIpIHJldHVybiB0cnVlO1xyXG5pZiAoaW5wID09IFwicXdjUXVlcnlCdWlsZGVyX0RhdGFcIikgcmV0dXJuIHRydWU7XHJcbmlmIChpbnAgPT0gXCJxd2NRUkNvZGVfRGF0YVwiKSByZXR1cm4gdHJ1ZTtcclxuaWYgKGlucCA9PSBcInF3Y1JhdGluZ19EYXRhXCIpIHJldHVybiB0cnVlO1xyXG5pZiAoaW5wID09IFwicXdjUmliYm9uX0RhdGFcIikgcmV0dXJuIHRydWU7XHJcbmlmIChpbnAgPT0gXCJxd2NSaWNoVGV4dEVkaXRvcl9EYXRhXCIpIHJldHVybiB0cnVlO1xyXG5pZiAoaW5wID09IFwicXdjU2NoZWR1bGVfRGF0YVwiKSByZXR1cm4gdHJ1ZTtcclxuaWYgKGlucCA9PSBcInF3Y1NpZGVCYXJfRGF0YVwiKSByZXR1cm4gdHJ1ZTtcclxuaWYgKGlucCA9PSBcInF3Y1NpZ25hdHVyZV9EYXRhXCIpIHJldHVybiB0cnVlO1xyXG5pZiAoaW5wID09IFwicXdjU2tlbGV0b25fRGF0YVwiKSByZXR1cm4gdHJ1ZTtcclxuaWYgKGlucCA9PSBcInF3Y1NwbGl0dGVyX0RhdGFcIikgcmV0dXJuIHRydWU7XHJcbmlmIChpbnAgPT0gXCJxd2NUYWJDb250cm9sX0RhdGFcIikgcmV0dXJuIHRydWU7XHJcbmlmIChpbnAgPT0gXCJxd2NUZXh0X0RhdGFcIikgcmV0dXJuIHRydWU7XHJcbmlmIChpbnAgPT0gXCJxd2NUcmVlVmlld19EYXRhXCIpIHJldHVybiB0cnVlO1xyXG5pZiAoaW5wID09IFwicXdjVXBsb2FkZXJfRGF0YVwiKSByZXR1cm4gdHJ1ZTtcclxucmV0dXJuIGZhbHNlO1xyXG59IFxyXG5wcml2YXRlIHZvaWQgQ3JlYXRlQ29udHJvbChUcmFuc2ZlclN0cmluZyBkcykge1xyXG5Bc3NlbWJseSBhc3NlbWJseSA9IEFQTC5HZXRBc3NlbWJseShcIkRhdGFCaW5kaW5nXCIsIHRoaXMpO1xyXG5UeXBlIHR5cGUgPSBhc3NlbWJseS5HZXRUeXBlKFwiRGF0YUJpbmRpbmdcIiArIFwiLlwiICsgZHMuQ2xhc3MpO1xyXG5zdHJpbmcgY2wgPSBkcy5DbGFzcyArIFwiX0RhdGFcIjtcclxuYm9vbCBpc0VKMSA9IElzRUoxKGNsKTtcclxuYm9vbCBpc0VKMiA9IElzRUoyKGNsKTtcclxudmFyIG9iID0gQWN0aXZhdG9yLkNyZWF0ZUluc3RhbmNlKHR5cGUsIGRzKTtcclxuTWV0aG9kSW5mbyBtZXRob2QgPSB0eXBlLkdldE1ldGhvZChcIkNyZWF0ZUNvbnRpbnVlMVwiKTtcclxudmFyIG9iaiA9IEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGNsLCBkcy5JbnN0YW5jZSwgbnVsbCk7XHJcbmlmIChtZXRob2QgIT0gbnVsbCkge1xyXG52YXIgYXJndW1lbnRzID0gbmV3IG9iamVjdFtdIHsgZHMgfTtcclxubWV0aG9kLkludm9rZSgoKE1KSF9Db21tb25EYXRhKW9iaikuTUpIX0NsYXNzLCBhcmd1bWVudHMpO1xyXG59IFxyXG5tZXRob2QgPSB0eXBlLkdldE1ldGhvZChcIkNyZWF0ZUNvbnRpbnVlMlwiKTtcclxuaWYgKG1ldGhvZCAhPSBudWxsKSB7XHJcbnZhciBhcmd1bWVudHMgPSBuZXcgb2JqZWN0W10geyBkcyB9O1xyXG5tZXRob2QuSW52b2tlKCgoTUpIX0NvbW1vbkRhdGEpb2JqKS5NSkhfQ2xhc3MsIGFyZ3VtZW50cyk7XHJcbn0gXHJcbmlmICgwICE9IGRzLkV4dHJhcy5MZW5ndGgpIHsgICAvLyBQcm9jZXNzIFN0eWxlIHByb3BlcnR5XHJcbmRzLk5hbWUgPSBcIlN0eWxlXCI7XHJcbmRzLkRhdGEgPSBkcy5FeHRyYXM7XHJcblR5cGUgdHlwZWNsID0gYXNzZW1ibHkuR2V0VHlwZShcIkRhdGFCaW5kaW5nXCIgKyBcIi5cIiArIGNsKTtcclxubWV0aG9kID0gdHlwZWNsLkdldE1ldGhvZChcIlJ1blByb3BlcnR5Q2hhbmdlZEluXCIpO1xyXG52YXIgYXJndW1lbnRzID0gbmV3IG9iamVjdFtdIHsgZHMsIGZhbHNlIH07XHJcbm1ldGhvZC5JbnZva2Uob2JqLCBhcmd1bWVudHMpO1xyXG59fVxyXG5wcml2YXRlIHZvaWQgUnVuRGF0YUJpbmRpbmcoVHJhbnNmZXJTdHJpbmcgZHMpIHtcclxuaWYoZHMuQ2xhc3MgPT0gXCJxd2NfUm9vdFwiKSB7XHJcbnF3Y19Sb290IGRib2JqMSA9IChxd2NfUm9vdCkgQVBMLkdldEluc3RhbmNlKFwiRGF0YUJpbmRpbmdcIiwgZHMuQ2xhc3MsIGRzLkluc3RhbmNlLCB0aGlzKTtcclxuaWYgKG51bGwgIT0gZGJvYmoxKSBkYm9iajEuUnVuUHJvcGVydHlDaGFuZ2VkSW4oZHMsZmFsc2UpO1xyXG59XHJcbiBcclxuZWxzZSBpZihkcy5DbGFzcyA9PSBcIk1KSF9EUV9EYXRhXCIpIHtcclxuTUpIX0RRX0RhdGEgZGJvYmoyID0gKE1KSF9EUV9EYXRhKSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBkcy5DbGFzcywgZHMuSW5zdGFuY2UsIHRoaXMpO1xyXG5pZiAobnVsbCAhPSBkYm9iajIpIGRib2JqMi5SdW5Qcm9wZXJ0eUNoYW5nZWRJbihkcyxmYWxzZSk7XHJcbn1cclxuIFxyXG5lbHNlIGlmKGRzLkNsYXNzID09IFwiTUpIX01pbkZvcm1fRGF0YVwiKSB7XHJcbk1KSF9NaW5Gb3JtX0RhdGEgZGJvYmozID0gKE1KSF9NaW5Gb3JtX0RhdGEpIEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgdGhpcyk7XHJcbmlmIChudWxsICE9IGRib2JqMykgZGJvYmozLlJ1blByb3BlcnR5Q2hhbmdlZEluKGRzLGZhbHNlKTtcclxufVxyXG4gXHJcbmVsc2UgaWYoZHMuQ2xhc3MgPT0gXCJxd2NBcHBCYXJfRGF0YVwiKSB7XHJcbnF3Y0FwcEJhcl9EYXRhIGRib2JqNCA9IChxd2NBcHBCYXJfRGF0YSkgQVBMLkdldEluc3RhbmNlKFwiRGF0YUJpbmRpbmdcIiwgZHMuQ2xhc3MsIGRzLkluc3RhbmNlLCB0aGlzKTtcclxuaWYgKG51bGwgIT0gZGJvYmo0KSBkYm9iajQuUnVuUHJvcGVydHlDaGFuZ2VkSW4oZHMsZmFsc2UpO1xyXG59XHJcbiBcclxuZWxzZSBpZihkcy5DbGFzcyA9PSBcInF3Y0F2YXRhcl9EYXRhXCIpIHtcclxucXdjQXZhdGFyX0RhdGEgZGJvYmo1ID0gKHF3Y0F2YXRhcl9EYXRhKSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBkcy5DbGFzcywgZHMuSW5zdGFuY2UsIHRoaXMpO1xyXG5pZiAobnVsbCAhPSBkYm9iajUpIGRib2JqNS5SdW5Qcm9wZXJ0eUNoYW5nZWRJbihkcyxmYWxzZSk7XHJcbn1cclxuIFxyXG5lbHNlIGlmKGRzLkNsYXNzID09IFwicXdjQmFkZ2VfRGF0YVwiKSB7XHJcbnF3Y0JhZGdlX0RhdGEgZGJvYmo2ID0gKHF3Y0JhZGdlX0RhdGEpIEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgdGhpcyk7XHJcbmlmIChudWxsICE9IGRib2JqNikgZGJvYmo2LlJ1blByb3BlcnR5Q2hhbmdlZEluKGRzLGZhbHNlKTtcclxufVxyXG4gXHJcbmVsc2UgaWYoZHMuQ2xhc3MgPT0gXCJxd2NCYXJDb2RlX0RhdGFcIikge1xyXG5xd2NCYXJDb2RlX0RhdGEgZGJvYmo3ID0gKHF3Y0JhckNvZGVfRGF0YSkgQVBMLkdldEluc3RhbmNlKFwiRGF0YUJpbmRpbmdcIiwgZHMuQ2xhc3MsIGRzLkluc3RhbmNlLCB0aGlzKTtcclxuaWYgKG51bGwgIT0gZGJvYmo3KSBkYm9iajcuUnVuUHJvcGVydHlDaGFuZ2VkSW4oZHMsZmFsc2UpO1xyXG59XHJcbiBcclxuZWxzZSBpZihkcy5DbGFzcyA9PSBcInF3Y0JyZWFkQ3J1bWJfRGF0YVwiKSB7XHJcbnF3Y0JyZWFkQ3J1bWJfRGF0YSBkYm9iajggPSAocXdjQnJlYWRDcnVtYl9EYXRhKSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBkcy5DbGFzcywgZHMuSW5zdGFuY2UsIHRoaXMpO1xyXG5pZiAobnVsbCAhPSBkYm9iajgpIGRib2JqOC5SdW5Qcm9wZXJ0eUNoYW5nZWRJbihkcyxmYWxzZSk7XHJcbn1cclxuIFxyXG5lbHNlIGlmKGRzLkNsYXNzID09IFwicXdjQnJpZGdlU2NvcmVfRGF0YVwiKSB7XHJcbnF3Y0JyaWRnZVNjb3JlX0RhdGEgZGJvYmo5ID0gKHF3Y0JyaWRnZVNjb3JlX0RhdGEpIEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgdGhpcyk7XHJcbmlmIChudWxsICE9IGRib2JqOSkgZGJvYmo5LlJ1blByb3BlcnR5Q2hhbmdlZEluKGRzLGZhbHNlKTtcclxufVxyXG4gXHJcbmVsc2UgaWYoZHMuQ2xhc3MgPT0gXCJxd2NCdXR0b25DaGVja19EYXRhXCIpIHtcclxucXdjQnV0dG9uQ2hlY2tfRGF0YSBkYm9iajEwID0gKHF3Y0J1dHRvbkNoZWNrX0RhdGEpIEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgdGhpcyk7XHJcbmlmIChudWxsICE9IGRib2JqMTApIGRib2JqMTAuUnVuUHJvcGVydHlDaGFuZ2VkSW4oZHMsZmFsc2UpO1xyXG59XHJcbiBcclxuZWxzZSBpZihkcy5DbGFzcyA9PSBcInF3Y0J1dHRvbkNvbW1hbmRMaW5rX0RhdGFcIikge1xyXG5xd2NCdXR0b25Db21tYW5kTGlua19EYXRhIGRib2JqMTEgPSAocXdjQnV0dG9uQ29tbWFuZExpbmtfRGF0YSkgQVBMLkdldEluc3RhbmNlKFwiRGF0YUJpbmRpbmdcIiwgZHMuQ2xhc3MsIGRzLkluc3RhbmNlLCB0aGlzKTtcclxuaWYgKG51bGwgIT0gZGJvYmoxMSkgZGJvYmoxMS5SdW5Qcm9wZXJ0eUNoYW5nZWRJbihkcyxmYWxzZSk7XHJcbn1cclxuIFxyXG5lbHNlIGlmKGRzLkNsYXNzID09IFwicXdjQnV0dG9uUHVzaF9EYXRhXCIpIHtcclxucXdjQnV0dG9uUHVzaF9EYXRhIGRib2JqMTIgPSAocXdjQnV0dG9uUHVzaF9EYXRhKSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBkcy5DbGFzcywgZHMuSW5zdGFuY2UsIHRoaXMpO1xyXG5pZiAobnVsbCAhPSBkYm9iajEyKSBkYm9iajEyLlJ1blByb3BlcnR5Q2hhbmdlZEluKGRzLGZhbHNlKTtcclxufVxyXG4gXHJcbmVsc2UgaWYoZHMuQ2xhc3MgPT0gXCJxd2NCdXR0b25SYWRpb19EYXRhXCIpIHtcclxucXdjQnV0dG9uUmFkaW9fRGF0YSBkYm9iajEzID0gKHF3Y0J1dHRvblJhZGlvX0RhdGEpIEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgdGhpcyk7XHJcbmlmIChudWxsICE9IGRib2JqMTMpIGRib2JqMTMuUnVuUHJvcGVydHlDaGFuZ2VkSW4oZHMsZmFsc2UpO1xyXG59XHJcbiBcclxuZWxzZSBpZihkcy5DbGFzcyA9PSBcInF3Y0J1dHRvblNwbGl0X0RhdGFcIikge1xyXG5xd2NCdXR0b25TcGxpdF9EYXRhIGRib2JqMTQgPSAocXdjQnV0dG9uU3BsaXRfRGF0YSkgQVBMLkdldEluc3RhbmNlKFwiRGF0YUJpbmRpbmdcIiwgZHMuQ2xhc3MsIGRzLkluc3RhbmNlLCB0aGlzKTtcclxuaWYgKG51bGwgIT0gZGJvYmoxNCkgZGJvYmoxNC5SdW5Qcm9wZXJ0eUNoYW5nZWRJbihkcyxmYWxzZSk7XHJcbn1cclxuIFxyXG5lbHNlIGlmKGRzLkNsYXNzID09IFwicXdjQnV0dG9uVG9nZ2xlX0RhdGFcIikge1xyXG5xd2NCdXR0b25Ub2dnbGVfRGF0YSBkYm9iajE1ID0gKHF3Y0J1dHRvblRvZ2dsZV9EYXRhKSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBkcy5DbGFzcywgZHMuSW5zdGFuY2UsIHRoaXMpO1xyXG5pZiAobnVsbCAhPSBkYm9iajE1KSBkYm9iajE1LlJ1blByb3BlcnR5Q2hhbmdlZEluKGRzLGZhbHNlKTtcclxufVxyXG4gXHJcbmVsc2UgaWYoZHMuQ2xhc3MgPT0gXCJxd2NDYWxlbmRhcl9EYXRhXCIpIHtcclxucXdjQ2FsZW5kYXJfRGF0YSBkYm9iajE2ID0gKHF3Y0NhbGVuZGFyX0RhdGEpIEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgdGhpcyk7XHJcbmlmIChudWxsICE9IGRib2JqMTYpIGRib2JqMTYuUnVuUHJvcGVydHlDaGFuZ2VkSW4oZHMsZmFsc2UpO1xyXG59XHJcbiBcclxuZWxzZSBpZihkcy5DbGFzcyA9PSBcInF3Y0NhcmRfRGF0YVwiKSB7XHJcbnF3Y0NhcmRfRGF0YSBkYm9iajE3ID0gKHF3Y0NhcmRfRGF0YSkgQVBMLkdldEluc3RhbmNlKFwiRGF0YUJpbmRpbmdcIiwgZHMuQ2xhc3MsIGRzLkluc3RhbmNlLCB0aGlzKTtcclxuaWYgKG51bGwgIT0gZGJvYmoxNykgZGJvYmoxNy5SdW5Qcm9wZXJ0eUNoYW5nZWRJbihkcyxmYWxzZSk7XHJcbn1cclxuIFxyXG5lbHNlIGlmKGRzLkNsYXNzID09IFwicXdjQ2Fyb3VzZWxfRGF0YVwiKSB7XHJcbnF3Y0Nhcm91c2VsX0RhdGEgZGJvYmoxOCA9IChxd2NDYXJvdXNlbF9EYXRhKSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBkcy5DbGFzcywgZHMuSW5zdGFuY2UsIHRoaXMpO1xyXG5pZiAobnVsbCAhPSBkYm9iajE4KSBkYm9iajE4LlJ1blByb3BlcnR5Q2hhbmdlZEluKGRzLGZhbHNlKTtcclxufVxyXG4gXHJcbmVsc2UgaWYoZHMuQ2xhc3MgPT0gXCJxd2NDaGFydF9EYXRhXCIpIHtcclxucXdjQ2hhcnRfRGF0YSBkYm9iajE5ID0gKHF3Y0NoYXJ0X0RhdGEpIEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgdGhpcyk7XHJcbmlmIChudWxsICE9IGRib2JqMTkpIGRib2JqMTkuUnVuUHJvcGVydHlDaGFuZ2VkSW4oZHMsZmFsc2UpO1xyXG59XHJcbiBcclxuZWxzZSBpZihkcy5DbGFzcyA9PSBcInF3Y0NoaXBzX0RhdGFcIikge1xyXG5xd2NDaGlwc19EYXRhIGRib2JqMjAgPSAocXdjQ2hpcHNfRGF0YSkgQVBMLkdldEluc3RhbmNlKFwiRGF0YUJpbmRpbmdcIiwgZHMuQ2xhc3MsIGRzLkluc3RhbmNlLCB0aGlzKTtcclxuaWYgKG51bGwgIT0gZGJvYmoyMCkgZGJvYmoyMC5SdW5Qcm9wZXJ0eUNoYW5nZWRJbihkcyxmYWxzZSk7XHJcbn1cclxuIFxyXG5lbHNlIGlmKGRzLkNsYXNzID09IFwicXdjQ2lyY3VsYXJHYXVnZV9EYXRhXCIpIHtcclxucXdjQ2lyY3VsYXJHYXVnZV9EYXRhIGRib2JqMjEgPSAocXdjQ2lyY3VsYXJHYXVnZV9EYXRhKSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBkcy5DbGFzcywgZHMuSW5zdGFuY2UsIHRoaXMpO1xyXG5pZiAobnVsbCAhPSBkYm9iajIxKSBkYm9iajIxLlJ1blByb3BlcnR5Q2hhbmdlZEluKGRzLGZhbHNlKTtcclxufVxyXG4gXHJcbmVsc2UgaWYoZHMuQ2xhc3MgPT0gXCJxd2NDb2xvdXJQaWNrZXJfRGF0YVwiKSB7XHJcbnF3Y0NvbG91clBpY2tlcl9EYXRhIGRib2JqMjIgPSAocXdjQ29sb3VyUGlja2VyX0RhdGEpIEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgdGhpcyk7XHJcbmlmIChudWxsICE9IGRib2JqMjIpIGRib2JqMjIuUnVuUHJvcGVydHlDaGFuZ2VkSW4oZHMsZmFsc2UpO1xyXG59XHJcbiBcclxuZWxzZSBpZihkcy5DbGFzcyA9PSBcInF3Y0NvbG9yUGlja2VyX0RhdGFcIikge1xyXG5xd2NDb2xvclBpY2tlcl9EYXRhIGRib2JqMjMgPSAocXdjQ29sb3JQaWNrZXJfRGF0YSkgQVBMLkdldEluc3RhbmNlKFwiRGF0YUJpbmRpbmdcIiwgZHMuQ2xhc3MsIGRzLkluc3RhbmNlLCB0aGlzKTtcclxuaWYgKG51bGwgIT0gZGJvYmoyMykgZGJvYmoyMy5SdW5Qcm9wZXJ0eUNoYW5nZWRJbihkcyxmYWxzZSk7XHJcbn1cclxuIFxyXG5lbHNlIGlmKGRzLkNsYXNzID09IFwicXdjQ29tYm9Ecm9wX0RhdGFcIikge1xyXG5xd2NDb21ib0Ryb3BfRGF0YSBkYm9iajI0ID0gKHF3Y0NvbWJvRHJvcF9EYXRhKSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBkcy5DbGFzcywgZHMuSW5zdGFuY2UsIHRoaXMpO1xyXG5pZiAobnVsbCAhPSBkYm9iajI0KSBkYm9iajI0LlJ1blByb3BlcnR5Q2hhbmdlZEluKGRzLGZhbHNlKTtcclxufVxyXG4gXHJcbmVsc2UgaWYoZHMuQ2xhc3MgPT0gXCJxd2NDb21ib0Ryb3BFZGl0X0RhdGFcIikge1xyXG5xd2NDb21ib0Ryb3BFZGl0X0RhdGEgZGJvYmoyNSA9IChxd2NDb21ib0Ryb3BFZGl0X0RhdGEpIEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgdGhpcyk7XHJcbmlmIChudWxsICE9IGRib2JqMjUpIGRib2JqMjUuUnVuUHJvcGVydHlDaGFuZ2VkSW4oZHMsZmFsc2UpO1xyXG59XHJcbiBcclxuZWxzZSBpZihkcy5DbGFzcyA9PSBcInF3Y0NvbWJvU2ltcGxlX0RhdGFcIikge1xyXG5xd2NDb21ib1NpbXBsZV9EYXRhIGRib2JqMjYgPSAocXdjQ29tYm9TaW1wbGVfRGF0YSkgQVBMLkdldEluc3RhbmNlKFwiRGF0YUJpbmRpbmdcIiwgZHMuQ2xhc3MsIGRzLkluc3RhbmNlLCB0aGlzKTtcclxuaWYgKG51bGwgIT0gZGJvYmoyNikgZGJvYmoyNi5SdW5Qcm9wZXJ0eUNoYW5nZWRJbihkcyxmYWxzZSk7XHJcbn1cclxuIFxyXG5lbHNlIGlmKGRzLkNsYXNzID09IFwicXdjQ29udGV4dE1lbnVfRGF0YVwiKSB7XHJcbnF3Y0NvbnRleHRNZW51X0RhdGEgZGJvYmoyNyA9IChxd2NDb250ZXh0TWVudV9EYXRhKSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBkcy5DbGFzcywgZHMuSW5zdGFuY2UsIHRoaXMpO1xyXG5pZiAobnVsbCAhPSBkYm9iajI3KSBkYm9iajI3LlJ1blByb3BlcnR5Q2hhbmdlZEluKGRzLGZhbHNlKTtcclxufVxyXG4gXHJcbmVsc2UgaWYoZHMuQ2xhc3MgPT0gXCJxd2NEYXNoQm9hcmRfRGF0YVwiKSB7XHJcbnF3Y0Rhc2hCb2FyZF9EYXRhIGRib2JqMjggPSAocXdjRGFzaEJvYXJkX0RhdGEpIEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgdGhpcyk7XHJcbmlmIChudWxsICE9IGRib2JqMjgpIGRib2JqMjguUnVuUHJvcGVydHlDaGFuZ2VkSW4oZHMsZmFsc2UpO1xyXG59XHJcbiBcclxuZWxzZSBpZihkcy5DbGFzcyA9PSBcInF3Y0RhdGFHcmlkX0RhdGFcIikge1xyXG5xd2NEYXRhR3JpZF9EYXRhIGRib2JqMjkgPSAocXdjRGF0YUdyaWRfRGF0YSkgQVBMLkdldEluc3RhbmNlKFwiRGF0YUJpbmRpbmdcIiwgZHMuQ2xhc3MsIGRzLkluc3RhbmNlLCB0aGlzKTtcclxuaWYgKG51bGwgIT0gZGJvYmoyOSkgZGJvYmoyOS5SdW5Qcm9wZXJ0eUNoYW5nZWRJbihkcyxmYWxzZSk7XHJcbn1cclxuIFxyXG5lbHNlIGlmKGRzLkNsYXNzID09IFwicXdjRGF0YU1hbmFnZXJfRGF0YVwiKSB7XHJcbnF3Y0RhdGFNYW5hZ2VyX0RhdGEgZGJvYmozMCA9IChxd2NEYXRhTWFuYWdlcl9EYXRhKSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBkcy5DbGFzcywgZHMuSW5zdGFuY2UsIHRoaXMpO1xyXG5pZiAobnVsbCAhPSBkYm9iajMwKSBkYm9iajMwLlJ1blByb3BlcnR5Q2hhbmdlZEluKGRzLGZhbHNlKTtcclxufVxyXG4gXHJcbmVsc2UgaWYoZHMuQ2xhc3MgPT0gXCJxd2NEYXRlUGlja2VyX0RhdGFcIikge1xyXG5xd2NEYXRlUGlja2VyX0RhdGEgZGJvYmozMSA9IChxd2NEYXRlUGlja2VyX0RhdGEpIEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgdGhpcyk7XHJcbmlmIChudWxsICE9IGRib2JqMzEpIGRib2JqMzEuUnVuUHJvcGVydHlDaGFuZ2VkSW4oZHMsZmFsc2UpO1xyXG59XHJcbiBcclxuZWxzZSBpZihkcy5DbGFzcyA9PSBcInF3Y0RhdGVUaW1lUGlja2VyQ29tYm9fRGF0YVwiKSB7XHJcbnF3Y0RhdGVUaW1lUGlja2VyQ29tYm9fRGF0YSBkYm9iajMyID0gKHF3Y0RhdGVUaW1lUGlja2VyQ29tYm9fRGF0YSkgQVBMLkdldEluc3RhbmNlKFwiRGF0YUJpbmRpbmdcIiwgZHMuQ2xhc3MsIGRzLkluc3RhbmNlLCB0aGlzKTtcclxuaWYgKG51bGwgIT0gZGJvYmozMikgZGJvYmozMi5SdW5Qcm9wZXJ0eUNoYW5nZWRJbihkcyxmYWxzZSk7XHJcbn1cclxuIFxyXG5lbHNlIGlmKGRzLkNsYXNzID09IFwicXdjRGlhZ3JhbV9EYXRhXCIpIHtcclxucXdjRGlhZ3JhbV9EYXRhIGRib2JqMzMgPSAocXdjRGlhZ3JhbV9EYXRhKSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBkcy5DbGFzcywgZHMuSW5zdGFuY2UsIHRoaXMpO1xyXG5pZiAobnVsbCAhPSBkYm9iajMzKSBkYm9iajMzLlJ1blByb3BlcnR5Q2hhbmdlZEluKGRzLGZhbHNlKTtcclxufVxyXG4gXHJcbmVsc2UgaWYoZHMuQ2xhc3MgPT0gXCJxd2NNc2dCb3hNc2dfRGF0YVwiKSB7XHJcbnF3Y01zZ0JveE1zZ19EYXRhIGRib2JqMzQgPSAocXdjTXNnQm94TXNnX0RhdGEpIEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgdGhpcyk7XHJcbmlmIChudWxsICE9IGRib2JqMzQpIGRib2JqMzQuUnVuUHJvcGVydHlDaGFuZ2VkSW4oZHMsZmFsc2UpO1xyXG59XHJcbiBcclxuZWxzZSBpZihkcy5DbGFzcyA9PSBcInF3Y01zZ0JveEluZm9fRGF0YVwiKSB7XHJcbnF3Y01zZ0JveEluZm9fRGF0YSBkYm9iajM1ID0gKHF3Y01zZ0JveEluZm9fRGF0YSkgQVBMLkdldEluc3RhbmNlKFwiRGF0YUJpbmRpbmdcIiwgZHMuQ2xhc3MsIGRzLkluc3RhbmNlLCB0aGlzKTtcclxuaWYgKG51bGwgIT0gZGJvYmozNSkgZGJvYmozNS5SdW5Qcm9wZXJ0eUNoYW5nZWRJbihkcyxmYWxzZSk7XHJcbn1cclxuIFxyXG5lbHNlIGlmKGRzLkNsYXNzID09IFwicXdjTXNnQm94UXVlcnlfRGF0YVwiKSB7XHJcbnF3Y01zZ0JveFF1ZXJ5X0RhdGEgZGJvYmozNiA9IChxd2NNc2dCb3hRdWVyeV9EYXRhKSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBkcy5DbGFzcywgZHMuSW5zdGFuY2UsIHRoaXMpO1xyXG5pZiAobnVsbCAhPSBkYm9iajM2KSBkYm9iajM2LlJ1blByb3BlcnR5Q2hhbmdlZEluKGRzLGZhbHNlKTtcclxufVxyXG4gXHJcbmVsc2UgaWYoZHMuQ2xhc3MgPT0gXCJxd2NNc2dCb3hXYXJuX0RhdGFcIikge1xyXG5xd2NNc2dCb3hXYXJuX0RhdGEgZGJvYmozNyA9IChxd2NNc2dCb3hXYXJuX0RhdGEpIEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgdGhpcyk7XHJcbmlmIChudWxsICE9IGRib2JqMzcpIGRib2JqMzcuUnVuUHJvcGVydHlDaGFuZ2VkSW4oZHMsZmFsc2UpO1xyXG59XHJcbiBcclxuZWxzZSBpZihkcy5DbGFzcyA9PSBcInF3Y01zZ0JveEVycm9yX0RhdGFcIikge1xyXG5xd2NNc2dCb3hFcnJvcl9EYXRhIGRib2JqMzggPSAocXdjTXNnQm94RXJyb3JfRGF0YSkgQVBMLkdldEluc3RhbmNlKFwiRGF0YUJpbmRpbmdcIiwgZHMuQ2xhc3MsIGRzLkluc3RhbmNlLCB0aGlzKTtcclxuaWYgKG51bGwgIT0gZGJvYmozOCkgZGJvYmozOC5SdW5Qcm9wZXJ0eUNoYW5nZWRJbihkcyxmYWxzZSk7XHJcbn1cclxuIFxyXG5lbHNlIGlmKGRzLkNsYXNzID09IFwicXdjRG9jdW1lbnRFZGl0b3JfRGF0YVwiKSB7XHJcbnF3Y0RvY3VtZW50RWRpdG9yX0RhdGEgZGJvYmozOSA9IChxd2NEb2N1bWVudEVkaXRvcl9EYXRhKSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBkcy5DbGFzcywgZHMuSW5zdGFuY2UsIHRoaXMpO1xyXG5pZiAobnVsbCAhPSBkYm9iajM5KSBkYm9iajM5LlJ1blByb3BlcnR5Q2hhbmdlZEluKGRzLGZhbHNlKTtcclxufVxyXG4gXHJcbmVsc2UgaWYoZHMuQ2xhc3MgPT0gXCJxd2NFZGl0U2luZ2xlX0RhdGFcIikge1xyXG5xd2NFZGl0U2luZ2xlX0RhdGEgZGJvYmo0MCA9IChxd2NFZGl0U2luZ2xlX0RhdGEpIEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgdGhpcyk7XHJcbmlmIChudWxsICE9IGRib2JqNDApIGRib2JqNDAuUnVuUHJvcGVydHlDaGFuZ2VkSW4oZHMsZmFsc2UpO1xyXG59XHJcbiBcclxuZWxzZSBpZihkcy5DbGFzcyA9PSBcInF3Y0VkaXRNdWx0aV9EYXRhXCIpIHtcclxucXdjRWRpdE11bHRpX0RhdGEgZGJvYmo0MSA9IChxd2NFZGl0TXVsdGlfRGF0YSkgQVBMLkdldEluc3RhbmNlKFwiRGF0YUJpbmRpbmdcIiwgZHMuQ2xhc3MsIGRzLkluc3RhbmNlLCB0aGlzKTtcclxuaWYgKG51bGwgIT0gZGJvYmo0MSkgZGJvYmo0MS5SdW5Qcm9wZXJ0eUNoYW5nZWRJbihkcyxmYWxzZSk7XHJcbn1cclxuIFxyXG5lbHNlIGlmKGRzLkNsYXNzID09IFwicXdjRXhwYW5kZXJfRGF0YVwiKSB7XHJcbnF3Y0V4cGFuZGVyX0RhdGEgZGJvYmo0MiA9IChxd2NFeHBhbmRlcl9EYXRhKSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBkcy5DbGFzcywgZHMuSW5zdGFuY2UsIHRoaXMpO1xyXG5pZiAobnVsbCAhPSBkYm9iajQyKSBkYm9iajQyLlJ1blByb3BlcnR5Q2hhbmdlZEluKGRzLGZhbHNlKTtcclxufVxyXG4gXHJcbmVsc2UgaWYoZHMuQ2xhc3MgPT0gXCJxd2NGaWxlTWFuYWdlcl9EYXRhXCIpIHtcclxucXdjRmlsZU1hbmFnZXJfRGF0YSBkYm9iajQzID0gKHF3Y0ZpbGVNYW5hZ2VyX0RhdGEpIEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgdGhpcyk7XHJcbmlmIChudWxsICE9IGRib2JqNDMpIGRib2JqNDMuUnVuUHJvcGVydHlDaGFuZ2VkSW4oZHMsZmFsc2UpO1xyXG59XHJcbiBcclxuZWxzZSBpZihkcy5DbGFzcyA9PSBcInF3Y0ZvbnRfRGF0YVwiKSB7XHJcbnF3Y0ZvbnRfRGF0YSBkYm9iajQ0ID0gKHF3Y0ZvbnRfRGF0YSkgQVBMLkdldEluc3RhbmNlKFwiRGF0YUJpbmRpbmdcIiwgZHMuQ2xhc3MsIGRzLkluc3RhbmNlLCB0aGlzKTtcclxuaWYgKG51bGwgIT0gZGJvYmo0NCkgZGJvYmo0NC5SdW5Qcm9wZXJ0eUNoYW5nZWRJbihkcyxmYWxzZSk7XHJcbn1cclxuIFxyXG5lbHNlIGlmKGRzLkNsYXNzID09IFwicXdjRm9ybV9EYXRhXCIpIHtcclxucXdjRm9ybV9EYXRhIGRib2JqNDUgPSAocXdjRm9ybV9EYXRhKSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBkcy5DbGFzcywgZHMuSW5zdGFuY2UsIHRoaXMpO1xyXG5pZiAobnVsbCAhPSBkYm9iajQ1KSBkYm9iajQ1LlJ1blByb3BlcnR5Q2hhbmdlZEluKGRzLGZhbHNlKTtcclxufVxyXG4gXHJcbmVsc2UgaWYoZHMuQ2xhc3MgPT0gXCJxd2NHYW50dF9EYXRhXCIpIHtcclxucXdjR2FudHRfRGF0YSBkYm9iajQ2ID0gKHF3Y0dhbnR0X0RhdGEpIEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgdGhpcyk7XHJcbmlmIChudWxsICE9IGRib2JqNDYpIGRib2JqNDYuUnVuUHJvcGVydHlDaGFuZ2VkSW4oZHMsZmFsc2UpO1xyXG59XHJcbiBcclxuZWxzZSBpZihkcy5DbGFzcyA9PSBcInF3Y0dyaWRfRGF0YVwiKSB7XHJcbnF3Y0dyaWRfRGF0YSBkYm9iajQ3ID0gKHF3Y0dyaWRfRGF0YSkgQVBMLkdldEluc3RhbmNlKFwiRGF0YUJpbmRpbmdcIiwgZHMuQ2xhc3MsIGRzLkluc3RhbmNlLCB0aGlzKTtcclxuaWYgKG51bGwgIT0gZGJvYmo0NykgZGJvYmo0Ny5SdW5Qcm9wZXJ0eUNoYW5nZWRJbihkcyxmYWxzZSk7XHJcbn1cclxuIFxyXG5lbHNlIGlmKGRzLkNsYXNzID09IFwicXdjR3JvdXBfRGF0YVwiKSB7XHJcbnF3Y0dyb3VwX0RhdGEgZGJvYmo0OCA9IChxd2NHcm91cF9EYXRhKSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBkcy5DbGFzcywgZHMuSW5zdGFuY2UsIHRoaXMpO1xyXG5pZiAobnVsbCAhPSBkYm9iajQ4KSBkYm9iajQ4LlJ1blByb3BlcnR5Q2hhbmdlZEluKGRzLGZhbHNlKTtcclxufVxyXG4gXHJcbmVsc2UgaWYoZHMuQ2xhc3MgPT0gXCJxd2NJbWFnZUVkaXRvcl9EYXRhXCIpIHtcclxucXdjSW1hZ2VFZGl0b3JfRGF0YSBkYm9iajQ5ID0gKHF3Y0ltYWdlRWRpdG9yX0RhdGEpIEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgdGhpcyk7XHJcbmlmIChudWxsICE9IGRib2JqNDkpIGRib2JqNDkuUnVuUHJvcGVydHlDaGFuZ2VkSW4oZHMsZmFsc2UpO1xyXG59XHJcbiBcclxuZWxzZSBpZihkcy5DbGFzcyA9PSBcInF3Y0thbmJhbl9EYXRhXCIpIHtcclxucXdjS2FuYmFuX0RhdGEgZGJvYmo1MCA9IChxd2NLYW5iYW5fRGF0YSkgQVBMLkdldEluc3RhbmNlKFwiRGF0YUJpbmRpbmdcIiwgZHMuQ2xhc3MsIGRzLkluc3RhbmNlLCB0aGlzKTtcclxuaWYgKG51bGwgIT0gZGJvYmo1MCkgZGJvYmo1MC5SdW5Qcm9wZXJ0eUNoYW5nZWRJbihkcyxmYWxzZSk7XHJcbn1cclxuIFxyXG5lbHNlIGlmKGRzLkNsYXNzID09IFwicXdjTGFiZWxfRGF0YVwiKSB7XHJcbnF3Y0xhYmVsX0RhdGEgZGJvYmo1MSA9IChxd2NMYWJlbF9EYXRhKSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBkcy5DbGFzcywgZHMuSW5zdGFuY2UsIHRoaXMpO1xyXG5pZiAobnVsbCAhPSBkYm9iajUxKSBkYm9iajUxLlJ1blByb3BlcnR5Q2hhbmdlZEluKGRzLGZhbHNlKTtcclxufVxyXG4gXHJcbmVsc2UgaWYoZHMuQ2xhc3MgPT0gXCJxd2NMaW5lYXJHYXVnZV9EYXRhXCIpIHtcclxucXdjTGluZWFyR2F1Z2VfRGF0YSBkYm9iajUyID0gKHF3Y0xpbmVhckdhdWdlX0RhdGEpIEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgdGhpcyk7XHJcbmlmIChudWxsICE9IGRib2JqNTIpIGRib2JqNTIuUnVuUHJvcGVydHlDaGFuZ2VkSW4oZHMsZmFsc2UpO1xyXG59XHJcbiBcclxuZWxzZSBpZihkcy5DbGFzcyA9PSBcInF3Y0ltYWdlX0RhdGFcIikge1xyXG5xd2NJbWFnZV9EYXRhIGRib2JqNTMgPSAocXdjSW1hZ2VfRGF0YSkgQVBMLkdldEluc3RhbmNlKFwiRGF0YUJpbmRpbmdcIiwgZHMuQ2xhc3MsIGRzLkluc3RhbmNlLCB0aGlzKTtcclxuaWYgKG51bGwgIT0gZGJvYmo1MykgZGJvYmo1My5SdW5Qcm9wZXJ0eUNoYW5nZWRJbihkcyxmYWxzZSk7XHJcbn1cclxuIFxyXG5lbHNlIGlmKGRzLkNsYXNzID09IFwicXdjSW1hZ2VMaXN0X0RhdGFcIikge1xyXG5xd2NJbWFnZUxpc3RfRGF0YSBkYm9iajU0ID0gKHF3Y0ltYWdlTGlzdF9EYXRhKSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBkcy5DbGFzcywgZHMuSW5zdGFuY2UsIHRoaXMpO1xyXG5pZiAobnVsbCAhPSBkYm9iajU0KSBkYm9iajU0LlJ1blByb3BlcnR5Q2hhbmdlZEluKGRzLGZhbHNlKTtcclxufVxyXG4gXHJcbmVsc2UgaWYoZHMuQ2xhc3MgPT0gXCJxd2NLYW5iYW5fRGF0YVwiKSB7XHJcbnF3Y0thbmJhbl9EYXRhIGRib2JqNTUgPSAocXdjS2FuYmFuX0RhdGEpIEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgdGhpcyk7XHJcbmlmIChudWxsICE9IGRib2JqNTUpIGRib2JqNTUuUnVuUHJvcGVydHlDaGFuZ2VkSW4oZHMsZmFsc2UpO1xyXG59XHJcbiBcclxuZWxzZSBpZihkcy5DbGFzcyA9PSBcInF3Y0xpc3RTaW5nbGVfRGF0YVwiKSB7XHJcbnF3Y0xpc3RTaW5nbGVfRGF0YSBkYm9iajU2ID0gKHF3Y0xpc3RTaW5nbGVfRGF0YSkgQVBMLkdldEluc3RhbmNlKFwiRGF0YUJpbmRpbmdcIiwgZHMuQ2xhc3MsIGRzLkluc3RhbmNlLCB0aGlzKTtcclxuaWYgKG51bGwgIT0gZGJvYmo1NikgZGJvYmo1Ni5SdW5Qcm9wZXJ0eUNoYW5nZWRJbihkcyxmYWxzZSk7XHJcbn1cclxuIFxyXG5lbHNlIGlmKGRzLkNsYXNzID09IFwicXdjTGlzdE11bHRpX0RhdGFcIikge1xyXG5xd2NMaXN0TXVsdGlfRGF0YSBkYm9iajU3ID0gKHF3Y0xpc3RNdWx0aV9EYXRhKSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBkcy5DbGFzcywgZHMuSW5zdGFuY2UsIHRoaXMpO1xyXG5pZiAobnVsbCAhPSBkYm9iajU3KSBkYm9iajU3LlJ1blByb3BlcnR5Q2hhbmdlZEluKGRzLGZhbHNlKTtcclxufVxyXG4gXHJcbmVsc2UgaWYoZHMuQ2xhc3MgPT0gXCJxd2NMaXN0Vmlld1NpbmdsZV9EYXRhXCIpIHtcclxucXdjTGlzdFZpZXdTaW5nbGVfRGF0YSBkYm9iajU4ID0gKHF3Y0xpc3RWaWV3U2luZ2xlX0RhdGEpIEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgdGhpcyk7XHJcbmlmIChudWxsICE9IGRib2JqNTgpIGRib2JqNTguUnVuUHJvcGVydHlDaGFuZ2VkSW4oZHMsZmFsc2UpO1xyXG59XHJcbiBcclxuZWxzZSBpZihkcy5DbGFzcyA9PSBcInF3Y0xpc3RWaWV3TXVsdGlfRGF0YVwiKSB7XHJcbnF3Y0xpc3RWaWV3TXVsdGlfRGF0YSBkYm9iajU5ID0gKHF3Y0xpc3RWaWV3TXVsdGlfRGF0YSkgQVBMLkdldEluc3RhbmNlKFwiRGF0YUJpbmRpbmdcIiwgZHMuQ2xhc3MsIGRzLkluc3RhbmNlLCB0aGlzKTtcclxuaWYgKG51bGwgIT0gZGJvYmo1OSkgZGJvYmo1OS5SdW5Qcm9wZXJ0eUNoYW5nZWRJbihkcyxmYWxzZSk7XHJcbn1cclxuIFxyXG5lbHNlIGlmKGRzLkNsYXNzID09IFwicXdjTWFwc19EYXRhXCIpIHtcclxucXdjTWFwc19EYXRhIGRib2JqNjAgPSAocXdjTWFwc19EYXRhKSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBkcy5DbGFzcywgZHMuSW5zdGFuY2UsIHRoaXMpO1xyXG5pZiAobnVsbCAhPSBkYm9iajYwKSBkYm9iajYwLlJ1blByb3BlcnR5Q2hhbmdlZEluKGRzLGZhbHNlKTtcclxufVxyXG4gXHJcbmVsc2UgaWYoZHMuQ2xhc3MgPT0gXCJxd2NNZW50aW9uX0RhdGFcIikge1xyXG5xd2NNZW50aW9uX0RhdGEgZGJvYmo2MSA9IChxd2NNZW50aW9uX0RhdGEpIEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgdGhpcyk7XHJcbmlmIChudWxsICE9IGRib2JqNjEpIGRib2JqNjEuUnVuUHJvcGVydHlDaGFuZ2VkSW4oZHMsZmFsc2UpO1xyXG59XHJcbiBcclxuZWxzZSBpZihkcy5DbGFzcyA9PSBcInF3Y01lbnVfRGF0YVwiKSB7XHJcbnF3Y01lbnVfRGF0YSBkYm9iajYyID0gKHF3Y01lbnVfRGF0YSkgQVBMLkdldEluc3RhbmNlKFwiRGF0YUJpbmRpbmdcIiwgZHMuQ2xhc3MsIGRzLkluc3RhbmNlLCB0aGlzKTtcclxuaWYgKG51bGwgIT0gZGJvYmo2MikgZGJvYmo2Mi5SdW5Qcm9wZXJ0eUNoYW5nZWRJbihkcyxmYWxzZSk7XHJcbn1cclxuIFxyXG5lbHNlIGlmKGRzLkNsYXNzID09IFwicXdjTWVudUJhcl9EYXRhXCIpIHtcclxucXdjTWVudUJhcl9EYXRhIGRib2JqNjMgPSAocXdjTWVudUJhcl9EYXRhKSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBkcy5DbGFzcywgZHMuSW5zdGFuY2UsIHRoaXMpO1xyXG5pZiAobnVsbCAhPSBkYm9iajYzKSBkYm9iajYzLlJ1blByb3BlcnR5Q2hhbmdlZEluKGRzLGZhbHNlKTtcclxufVxyXG4gXHJcbmVsc2UgaWYoZHMuQ2xhc3MgPT0gXCJxd2NNZW51SXRlbUNoZWNrX0RhdGFcIikge1xyXG5xd2NNZW51SXRlbUNoZWNrX0RhdGEgZGJvYmo2NCA9IChxd2NNZW51SXRlbUNoZWNrX0RhdGEpIEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgdGhpcyk7XHJcbmlmIChudWxsICE9IGRib2JqNjQpIGRib2JqNjQuUnVuUHJvcGVydHlDaGFuZ2VkSW4oZHMsZmFsc2UpO1xyXG59XHJcbiBcclxuZWxzZSBpZihkcy5DbGFzcyA9PSBcInF3Y01lbnVJdGVtUmFkaW9fRGF0YVwiKSB7XHJcbnF3Y01lbnVJdGVtUmFkaW9fRGF0YSBkYm9iajY1ID0gKHF3Y01lbnVJdGVtUmFkaW9fRGF0YSkgQVBMLkdldEluc3RhbmNlKFwiRGF0YUJpbmRpbmdcIiwgZHMuQ2xhc3MsIGRzLkluc3RhbmNlLCB0aGlzKTtcclxuaWYgKG51bGwgIT0gZGJvYmo2NSkgZGJvYmo2NS5SdW5Qcm9wZXJ0eUNoYW5nZWRJbihkcyxmYWxzZSk7XHJcbn1cclxuIFxyXG5lbHNlIGlmKGRzLkNsYXNzID09IFwicXdjTWVzc2FnZV9EYXRhXCIpIHtcclxucXdjTWVzc2FnZV9EYXRhIGRib2JqNjYgPSAocXdjTWVzc2FnZV9EYXRhKSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBkcy5DbGFzcywgZHMuSW5zdGFuY2UsIHRoaXMpO1xyXG5pZiAobnVsbCAhPSBkYm9iajY2KSBkYm9iajY2LlJ1blByb3BlcnR5Q2hhbmdlZEluKGRzLGZhbHNlKTtcclxufVxyXG4gXHJcbmVsc2UgaWYoZHMuQ2xhc3MgPT0gXCJxd2NQYWdlcl9EYXRhXCIpIHtcclxucXdjUGFnZXJfRGF0YSBkYm9iajY3ID0gKHF3Y1BhZ2VyX0RhdGEpIEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgdGhpcyk7XHJcbmlmIChudWxsICE9IGRib2JqNjcpIGRib2JqNjcuUnVuUHJvcGVydHlDaGFuZ2VkSW4oZHMsZmFsc2UpO1xyXG59XHJcbiBcclxuZWxzZSBpZihkcy5DbGFzcyA9PSBcInF3Y1BERlZpZXdlcl9EYXRhXCIpIHtcclxucXdjUERGVmlld2VyX0RhdGEgZGJvYmo2OCA9IChxd2NQREZWaWV3ZXJfRGF0YSkgQVBMLkdldEluc3RhbmNlKFwiRGF0YUJpbmRpbmdcIiwgZHMuQ2xhc3MsIGRzLkluc3RhbmNlLCB0aGlzKTtcclxuaWYgKG51bGwgIT0gZGJvYmo2OCkgZGJvYmo2OC5SdW5Qcm9wZXJ0eUNoYW5nZWRJbihkcyxmYWxzZSk7XHJcbn1cclxuIFxyXG5lbHNlIGlmKGRzLkNsYXNzID09IFwicXdjUGl2b3RUYWJsZV9EYXRhXCIpIHtcclxucXdjUGl2b3RUYWJsZV9EYXRhIGRib2JqNjkgPSAocXdjUGl2b3RUYWJsZV9EYXRhKSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBkcy5DbGFzcywgZHMuSW5zdGFuY2UsIHRoaXMpO1xyXG5pZiAobnVsbCAhPSBkYm9iajY5KSBkYm9iajY5LlJ1blByb3BlcnR5Q2hhbmdlZEluKGRzLGZhbHNlKTtcclxufVxyXG4gXHJcbmVsc2UgaWYoZHMuQ2xhc3MgPT0gXCJxd2NQcm9ncmVzc0Jhcl9EYXRhXCIpIHtcclxucXdjUHJvZ3Jlc3NCYXJfRGF0YSBkYm9iajcwID0gKHF3Y1Byb2dyZXNzQmFyX0RhdGEpIEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgdGhpcyk7XHJcbmlmIChudWxsICE9IGRib2JqNzApIGRib2JqNzAuUnVuUHJvcGVydHlDaGFuZ2VkSW4oZHMsZmFsc2UpO1xyXG59XHJcbiBcclxuZWxzZSBpZihkcy5DbGFzcyA9PSBcInF3Y1Byb2dyZXNzQnV0dG9uX0RhdGFcIikge1xyXG5xd2NQcm9ncmVzc0J1dHRvbl9EYXRhIGRib2JqNzEgPSAocXdjUHJvZ3Jlc3NCdXR0b25fRGF0YSkgQVBMLkdldEluc3RhbmNlKFwiRGF0YUJpbmRpbmdcIiwgZHMuQ2xhc3MsIGRzLkluc3RhbmNlLCB0aGlzKTtcclxuaWYgKG51bGwgIT0gZGJvYmo3MSkgZGJvYmo3MS5SdW5Qcm9wZXJ0eUNoYW5nZWRJbihkcyxmYWxzZSk7XHJcbn1cclxuIFxyXG5lbHNlIGlmKGRzLkNsYXNzID09IFwicXdjUXVlcnlCdWlsZGVyX0RhdGFcIikge1xyXG5xd2NRdWVyeUJ1aWxkZXJfRGF0YSBkYm9iajcyID0gKHF3Y1F1ZXJ5QnVpbGRlcl9EYXRhKSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBkcy5DbGFzcywgZHMuSW5zdGFuY2UsIHRoaXMpO1xyXG5pZiAobnVsbCAhPSBkYm9iajcyKSBkYm9iajcyLlJ1blByb3BlcnR5Q2hhbmdlZEluKGRzLGZhbHNlKTtcclxufVxyXG4gXHJcbmVsc2UgaWYoZHMuQ2xhc3MgPT0gXCJxd2NRUkNvZGVfRGF0YVwiKSB7XHJcbnF3Y1FSQ29kZV9EYXRhIGRib2JqNzMgPSAocXdjUVJDb2RlX0RhdGEpIEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgdGhpcyk7XHJcbmlmIChudWxsICE9IGRib2JqNzMpIGRib2JqNzMuUnVuUHJvcGVydHlDaGFuZ2VkSW4oZHMsZmFsc2UpO1xyXG59XHJcbiBcclxuZWxzZSBpZihkcy5DbGFzcyA9PSBcInF3Y1JhdGluZ19EYXRhXCIpIHtcclxucXdjUmF0aW5nX0RhdGEgZGJvYmo3NCA9IChxd2NSYXRpbmdfRGF0YSkgQVBMLkdldEluc3RhbmNlKFwiRGF0YUJpbmRpbmdcIiwgZHMuQ2xhc3MsIGRzLkluc3RhbmNlLCB0aGlzKTtcclxuaWYgKG51bGwgIT0gZGJvYmo3NCkgZGJvYmo3NC5SdW5Qcm9wZXJ0eUNoYW5nZWRJbihkcyxmYWxzZSk7XHJcbn1cclxuIFxyXG5lbHNlIGlmKGRzLkNsYXNzID09IFwicXdjUmliYm9uX0RhdGFcIikge1xyXG5xd2NSaWJib25fRGF0YSBkYm9iajc1ID0gKHF3Y1JpYmJvbl9EYXRhKSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBkcy5DbGFzcywgZHMuSW5zdGFuY2UsIHRoaXMpO1xyXG5pZiAobnVsbCAhPSBkYm9iajc1KSBkYm9iajc1LlJ1blByb3BlcnR5Q2hhbmdlZEluKGRzLGZhbHNlKTtcclxufVxyXG4gXHJcbmVsc2UgaWYoZHMuQ2xhc3MgPT0gXCJxd2NSaWNoVGV4dEVkaXRvcl9EYXRhXCIpIHtcclxucXdjUmljaFRleHRFZGl0b3JfRGF0YSBkYm9iajc2ID0gKHF3Y1JpY2hUZXh0RWRpdG9yX0RhdGEpIEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgdGhpcyk7XHJcbmlmIChudWxsICE9IGRib2JqNzYpIGRib2JqNzYuUnVuUHJvcGVydHlDaGFuZ2VkSW4oZHMsZmFsc2UpO1xyXG59XHJcbiBcclxuZWxzZSBpZihkcy5DbGFzcyA9PSBcInF3Y1NjaGVkdWxlX0RhdGFcIikge1xyXG5xd2NTY2hlZHVsZV9EYXRhIGRib2JqNzcgPSAocXdjU2NoZWR1bGVfRGF0YSkgQVBMLkdldEluc3RhbmNlKFwiRGF0YUJpbmRpbmdcIiwgZHMuQ2xhc3MsIGRzLkluc3RhbmNlLCB0aGlzKTtcclxuaWYgKG51bGwgIT0gZGJvYmo3NykgZGJvYmo3Ny5SdW5Qcm9wZXJ0eUNoYW5nZWRJbihkcyxmYWxzZSk7XHJcbn1cclxuIFxyXG5lbHNlIGlmKGRzLkNsYXNzID09IFwicXdjU2VwYXJhdG9yX0RhdGFcIikge1xyXG5xd2NTZXBhcmF0b3JfRGF0YSBkYm9iajc4ID0gKHF3Y1NlcGFyYXRvcl9EYXRhKSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBkcy5DbGFzcywgZHMuSW5zdGFuY2UsIHRoaXMpO1xyXG5pZiAobnVsbCAhPSBkYm9iajc4KSBkYm9iajc4LlJ1blByb3BlcnR5Q2hhbmdlZEluKGRzLGZhbHNlKTtcclxufVxyXG4gXHJcbmVsc2UgaWYoZHMuQ2xhc3MgPT0gXCJxd2NTaWRlQmFyX0RhdGFcIikge1xyXG5xd2NTaWRlQmFyX0RhdGEgZGJvYmo3OSA9IChxd2NTaWRlQmFyX0RhdGEpIEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgdGhpcyk7XHJcbmlmIChudWxsICE9IGRib2JqNzkpIGRib2JqNzkuUnVuUHJvcGVydHlDaGFuZ2VkSW4oZHMsZmFsc2UpO1xyXG59XHJcbiBcclxuZWxzZSBpZihkcy5DbGFzcyA9PSBcInF3Y1NpZ25hdHVyZV9EYXRhXCIpIHtcclxucXdjU2lnbmF0dXJlX0RhdGEgZGJvYmo4MCA9IChxd2NTaWduYXR1cmVfRGF0YSkgQVBMLkdldEluc3RhbmNlKFwiRGF0YUJpbmRpbmdcIiwgZHMuQ2xhc3MsIGRzLkluc3RhbmNlLCB0aGlzKTtcclxuaWYgKG51bGwgIT0gZGJvYmo4MCkgZGJvYmo4MC5SdW5Qcm9wZXJ0eUNoYW5nZWRJbihkcyxmYWxzZSk7XHJcbn1cclxuIFxyXG5lbHNlIGlmKGRzLkNsYXNzID09IFwicXdjU2tlbGV0b25fRGF0YVwiKSB7XHJcbnF3Y1NrZWxldG9uX0RhdGEgZGJvYmo4MSA9IChxd2NTa2VsZXRvbl9EYXRhKSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBkcy5DbGFzcywgZHMuSW5zdGFuY2UsIHRoaXMpO1xyXG5pZiAobnVsbCAhPSBkYm9iajgxKSBkYm9iajgxLlJ1blByb3BlcnR5Q2hhbmdlZEluKGRzLGZhbHNlKTtcclxufVxyXG4gXHJcbmVsc2UgaWYoZHMuQ2xhc3MgPT0gXCJxd2NTcGxpdHRlcl9EYXRhXCIpIHtcclxucXdjU3BsaXR0ZXJfRGF0YSBkYm9iajgyID0gKHF3Y1NwbGl0dGVyX0RhdGEpIEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgdGhpcyk7XHJcbmlmIChudWxsICE9IGRib2JqODIpIGRib2JqODIuUnVuUHJvcGVydHlDaGFuZ2VkSW4oZHMsZmFsc2UpO1xyXG59XHJcbiBcclxuZWxzZSBpZihkcy5DbGFzcyA9PSBcInF3Y1N1YkZvcm1fRGF0YVwiKSB7XHJcbnF3Y1N1YkZvcm1fRGF0YSBkYm9iajgzID0gKHF3Y1N1YkZvcm1fRGF0YSkgQVBMLkdldEluc3RhbmNlKFwiRGF0YUJpbmRpbmdcIiwgZHMuQ2xhc3MsIGRzLkluc3RhbmNlLCB0aGlzKTtcclxuaWYgKG51bGwgIT0gZGJvYmo4MykgZGJvYmo4My5SdW5Qcm9wZXJ0eUNoYW5nZWRJbihkcyxmYWxzZSk7XHJcbn1cclxuIFxyXG5lbHNlIGlmKGRzLkNsYXNzID09IFwicXdjVGFiQnV0dG9uX0RhdGFcIikge1xyXG5xd2NUYWJCdXR0b25fRGF0YSBkYm9iajg0ID0gKHF3Y1RhYkJ1dHRvbl9EYXRhKSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBkcy5DbGFzcywgZHMuSW5zdGFuY2UsIHRoaXMpO1xyXG5pZiAobnVsbCAhPSBkYm9iajg0KSBkYm9iajg0LlJ1blByb3BlcnR5Q2hhbmdlZEluKGRzLGZhbHNlKTtcclxufVxyXG4gXHJcbmVsc2UgaWYoZHMuQ2xhc3MgPT0gXCJxd2NUYWJCdXR0b24xX0RhdGFcIikge1xyXG5xd2NUYWJCdXR0b24xX0RhdGEgZGJvYmo4NSA9IChxd2NUYWJCdXR0b24xX0RhdGEpIEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgdGhpcyk7XHJcbmlmIChudWxsICE9IGRib2JqODUpIGRib2JqODUuUnVuUHJvcGVydHlDaGFuZ2VkSW4oZHMsZmFsc2UpO1xyXG59XHJcbiBcclxuZWxzZSBpZihkcy5DbGFzcyA9PSBcInF3Y1RhYkNvbnRyb2xfRGF0YVwiKSB7XHJcbnF3Y1RhYkNvbnRyb2xfRGF0YSBkYm9iajg2ID0gKHF3Y1RhYkNvbnRyb2xfRGF0YSkgQVBMLkdldEluc3RhbmNlKFwiRGF0YUJpbmRpbmdcIiwgZHMuQ2xhc3MsIGRzLkluc3RhbmNlLCB0aGlzKTtcclxuaWYgKG51bGwgIT0gZGJvYmo4NikgZGJvYmo4Ni5SdW5Qcm9wZXJ0eUNoYW5nZWRJbihkcyxmYWxzZSk7XHJcbn1cclxuIFxyXG5lbHNlIGlmKGRzLkNsYXNzID09IFwicXdjVGFiQ29udHJvbEJ1dHRvbnNfRGF0YVwiKSB7XHJcbnF3Y1RhYkNvbnRyb2xCdXR0b25zX0RhdGEgZGJvYmo4NyA9IChxd2NUYWJDb250cm9sQnV0dG9uc19EYXRhKSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBkcy5DbGFzcywgZHMuSW5zdGFuY2UsIHRoaXMpO1xyXG5pZiAobnVsbCAhPSBkYm9iajg3KSBkYm9iajg3LlJ1blByb3BlcnR5Q2hhbmdlZEluKGRzLGZhbHNlKTtcclxufVxyXG4gXHJcbmVsc2UgaWYoZHMuQ2xhc3MgPT0gXCJxd2NUYWJDb250cm9sRmxhdEJ1dHRvbnNfRGF0YVwiKSB7XHJcbnF3Y1RhYkNvbnRyb2xGbGF0QnV0dG9uc19EYXRhIGRib2JqODggPSAocXdjVGFiQ29udHJvbEZsYXRCdXR0b25zX0RhdGEpIEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgdGhpcyk7XHJcbmlmIChudWxsICE9IGRib2JqODgpIGRib2JqODguUnVuUHJvcGVydHlDaGFuZ2VkSW4oZHMsZmFsc2UpO1xyXG59XHJcbiBcclxuZWxzZSBpZihkcy5DbGFzcyA9PSBcInF3Y1RhYkNvbnRyb2xUYWJzX0RhdGFcIikge1xyXG5xd2NUYWJDb250cm9sVGFic19EYXRhIGRib2JqODkgPSAocXdjVGFiQ29udHJvbFRhYnNfRGF0YSkgQVBMLkdldEluc3RhbmNlKFwiRGF0YUJpbmRpbmdcIiwgZHMuQ2xhc3MsIGRzLkluc3RhbmNlLCB0aGlzKTtcclxuaWYgKG51bGwgIT0gZGJvYmo4OSkgZGJvYmo4OS5SdW5Qcm9wZXJ0eUNoYW5nZWRJbihkcyxmYWxzZSk7XHJcbn1cclxuIFxyXG5lbHNlIGlmKGRzLkNsYXNzID09IFwicXdjVGV4dF9EYXRhXCIpIHtcclxucXdjVGV4dF9EYXRhIGRib2JqOTAgPSAocXdjVGV4dF9EYXRhKSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBkcy5DbGFzcywgZHMuSW5zdGFuY2UsIHRoaXMpO1xyXG5pZiAobnVsbCAhPSBkYm9iajkwKSBkYm9iajkwLlJ1blByb3BlcnR5Q2hhbmdlZEluKGRzLGZhbHNlKTtcclxufVxyXG4gXHJcbmVsc2UgaWYoZHMuQ2xhc3MgPT0gXCJxd2NUcmVlVmlld19EYXRhXCIpIHtcclxucXdjVHJlZVZpZXdfRGF0YSBkYm9iajkxID0gKHF3Y1RyZWVWaWV3X0RhdGEpIEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgdGhpcyk7XHJcbmlmIChudWxsICE9IGRib2JqOTEpIGRib2JqOTEuUnVuUHJvcGVydHlDaGFuZ2VkSW4oZHMsZmFsc2UpO1xyXG59XHJcbiBcclxuZWxzZSBpZihkcy5DbGFzcyA9PSBcInF3Y1VwbG9hZGVyX0RhdGFcIikge1xyXG5xd2NVcGxvYWRlcl9EYXRhIGRib2JqOTIgPSAocXdjVXBsb2FkZXJfRGF0YSkgQVBMLkdldEluc3RhbmNlKFwiRGF0YUJpbmRpbmdcIiwgZHMuQ2xhc3MsIGRzLkluc3RhbmNlLCB0aGlzKTtcclxuaWYgKG51bGwgIT0gZGJvYmo5MikgZGJvYmo5Mi5SdW5Qcm9wZXJ0eUNoYW5nZWRJbihkcyxmYWxzZSk7XHJcbn1cclxuIFxyXG5lbHNlIGlmKGRzLkNsYXNzID09IFwiV1NJbnRlcm5hbHNcIikge1xyXG5XU0ludGVybmFscyBkYm9iajkzID0gKFdTSW50ZXJuYWxzKSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBkcy5DbGFzcywgZHMuSW5zdGFuY2UsIHRoaXMpO1xyXG5pZiAobnVsbCAhPSBkYm9iajkzKSBkYm9iajkzLlJ1blByb3BlcnR5Q2hhbmdlZEluKGRzLGZhbHNlKTtcclxufVxyXG4gXHJcbn1cclxuc3RyaW5nIE9uQmVmb3JlVW5sb2FkKG9iamVjdCBlKSB7XHJcbnN0cmluZyBtc2cgPSBcIkRvIHlvdSB3YW50IHRvIGxlYXZlIFFXQz9cIjtcclxuSW50ZXJvcC5FeGVjdXRlSmF2YVNjcmlwdChcIiQwLnByZXZlbnREZWZhdWx0KClcIiwgZSk7XHJcbkludGVyb3AuRXhlY3V0ZUphdmFTY3JpcHQoXCIkMC5yZXR1cm5WYWx1ZSA9ICQxXCIsZSxtc2cpO1xyXG5yZXR1cm4gbXNnO1xyXG59IFxyXG5wcml2YXRlIHZvaWQgTWFrZVdpblNpemUocXdjX1Jvb3QgcnQsIFdTSW50ZXJuYWxzIHdpKXtcclxud2kuU2V0VmFsdWUoXCJTdGF0dXNcIiwgXCJXZWJTb2NrZXQgT3BlbmVkXCIpO1xyXG5TaXplIGZzeiA9IG5ldyBTaXplKCk7XHJcbmZzei5XaWR0aCA9IChkb3VibGUpIEludGVyb3AuRXhlY3V0ZUphdmFTY3JpcHQoXCJzY3JlZW4ud2lkdGhcIik7XHJcbmZzei5IZWlnaHQgPSAoZG91YmxlKSBJbnRlcm9wLkV4ZWN1dGVKYXZhU2NyaXB0KFwic2NyZWVuLmhlaWdodFwiKTtcclxuQXBwbGljYXRpb24uQ3VycmVudC5SZXNvdXJjZXNbXCJGdWxsU2NyZWVuSGVpZ2h0XCJdID0gZnN6LkhlaWdodDtcclxuQXBwbGljYXRpb24uQ3VycmVudC5SZXNvdXJjZXNbXCJGdWxsU2NyZWVuV2lkdGhcIl0gPSBmc3ouV2lkdGg7XHJcbnJ0LlNldFZhbHVlKFwiRnVsbFNjcmVlblNpemVcIixmc3opO1xyXG5XaW5kb3cgd2luID0gV2luZG93LkN1cnJlbnQ7XHJcbkFwcGxpY2F0aW9uLkN1cnJlbnQuUmVzb3VyY2VzW1wiU2NyZWVuXCJdID0gd2luO1xyXG5SZWN0IHJlY3QgPSB3aW4uQm91bmRzO1xyXG5BcHBsaWNhdGlvbi5DdXJyZW50LlJlc291cmNlc1tcIlNjcmVlbkhlaWdodFwiXSA9IHJlY3QuSGVpZ2h0O1xyXG5BcHBsaWNhdGlvbi5DdXJyZW50LlJlc291cmNlc1tcIlNjcmVlbldpZHRoXCJdID0gcmVjdC5XaWR0aDtcclxucnQuU2V0VmFsdWUoXCJTY3JlZW5TaXplXCIscmVjdC5TaXplKTtcclxucnQuU2V0VmFsdWUoXCJCcm93c2VyU2NyZWVuU2l6ZVwiLHJlY3QuU2l6ZSk7XHJcbmRvdWJsZSByYXRpbz0oZG91YmxlKSBJbnRlcm9wLkV4ZWN1dGVKYXZhU2NyaXB0KFwid2luZG93LmRldmljZVBpeGVsUmF0aW9cIik7XHJcbmlmIChyYXRpbzwxKSByYXRpbz0xL3JhdGlvO1xyXG5TaXplIGZTaXplPW5ldyBTaXplKChpbnQpIGZzei5XaWR0aCpyYXRpbywgKGludCkgZnN6LkhlaWdodCpyYXRpbyk7XHJcbkFwcGxpY2F0aW9uLkN1cnJlbnQuUmVzb3VyY2VzW1wiRnVsbFNjcmVlbkhlaWdodFwiXSA9IGZTaXplLkhlaWdodDtcclxuQXBwbGljYXRpb24uQ3VycmVudC5SZXNvdXJjZXNbXCJGdWxsU2NyZWVuV2lkdGhcIl0gPSBmU2l6ZS5XaWR0aDtcclxucnQuU2V0VmFsdWUoXCJGdWxsU2NyZWVuU2l6ZVwiLGZTaXplKTtcclxud2luLlNpemVDaGFuZ2VkICs9IChzMSwgZTEpID0+IHtcclxuU2l6ZSBuZXdzeiA9IGUxLlNpemU7XHJcbnF3Y19Sb290IHJvb3QgPSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBcInF3Y19Sb290XCIsIFwicXdjX1Jvb3RcIiwgdGhpcykgYXMgcXdjX1Jvb3Q7XHJcbnJvb3QuU2V0VmFsdWUoXCJTY3JlZW5TaXplXCIsIG5ld3N6KTtcclxucm9vdC5TZXRWYWx1ZShcIkJyb3dzZXJTY3JlZW5TaXplXCIsIG5ld3N6KTtcclxuZG91YmxlIHJhdGlvMT0oZG91YmxlKSBJbnRlcm9wLkV4ZWN1dGVKYXZhU2NyaXB0KFwid2luZG93LmRldmljZVBpeGVsUmF0aW9cIik7XHJcbmlmIChyYXRpbzE8MSkgcmF0aW8xPTEvcmF0aW8xKzAuNTtcclxuU2l6ZSBmU2l6ZTE9bmV3IFNpemUoKGludCkgZnN6LldpZHRoKnJhdGlvMSwgKGludCkgZnN6LkhlaWdodCpyYXRpbzEpO1xyXG5BcHBsaWNhdGlvbi5DdXJyZW50LlJlc291cmNlc1tcIkZ1bGxTY3JlZW5IZWlnaHRcIl0gPSBmU2l6ZTEuSGVpZ2h0O1xyXG5BcHBsaWNhdGlvbi5DdXJyZW50LlJlc291cmNlc1tcIkZ1bGxTY3JlZW5XaWR0aFwiXSA9IGZTaXplMS5XaWR0aDtcclxucm9vdC5TZXRWYWx1ZShcIkZ1bGxTY3JlZW5TaXplXCIsZlNpemUxKTtcclxuQXBwbGljYXRpb24uQ3VycmVudC5SZXNvdXJjZXNbXCJTY3JlZW5IZWlnaHRcIl0gPSBuZXdzei5IZWlnaHQ7XHJcbkFwcGxpY2F0aW9uLkN1cnJlbnQuUmVzb3VyY2VzW1wiU2NyZWVuV2lkdGhcIl0gPSBuZXdzei5XaWR0aDtcclxuQXBwbGljYXRpb24uQ3VycmVudC5SZXNvdXJjZXNbXCJCcm93c2VyU2NyZWVuSGVpZ2h0XCJdID0gbmV3c3ouSGVpZ2h0O1xyXG5BcHBsaWNhdGlvbi5DdXJyZW50LlJlc291cmNlc1tcIkJyb3dzZXJTY3JlZW5XaWR0aFwiXSA9IG5ld3N6LldpZHRoO1xyXG5TdHJpbmcgZm0gPSAoU3RyaW5nKXJvb3QuR2V0VmFsdWUoXCJGdWxsU2NyZWVuSWRcIik7XHJcbmlmICgwICE9IGZtLkxlbmd0aCkge1xyXG5xd2NGb3JtX0RhdGEgZHMgPSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBcInF3Y0Zvcm1fRGF0YVwiLCBmbSwgdGhpcykgYXMgcXdjRm9ybV9EYXRhO1xyXG5pZiAoZm0gIT0gbnVsbCAmJiA0ID09IChpbnQpZHMuR2V0VmFsdWUoXCJTdGF0ZVwiKSkge1xyXG5kcy5Ob3RpZnlQcm9wZXJ0eUNoYW5nZWQoXCJTaXplXCIpO1xyXG59fVxyXG59O31cclxucHJpdmF0ZSB2b2lkIFVwZGF0ZUJpbmRpbmdMb3N0Rm9jdXMob2JqZWN0IHNlbmRlciwgUm91dGVkRXZlbnRBcmdzIGUpXHJcbnsgXHJcblRleHRCb3ggdHggPSAoVGV4dEJveClzZW5kZXI7XHJcbmlmICgwICE9IHR4LlRleHQuTGVuZ3RoKSB7XHJcbkJpbmRpbmdFeHByZXNzaW9uIGV4cCA9IHR4LkdldEJpbmRpbmdFeHByZXNzaW9uKFRleHRCb3guVGV4dFByb3BlcnR5KTtcclxuTUpIX0NvbW1vbkRhdGEgZG9iaiA9IGV4cC5EYXRhSXRlbSBhcyBNSkhfQ29tbW9uRGF0YTtcclxuc3RyaW5nIGluc3RhbmNlID0gZG9iai5NSkhfSW5zdGFuY2U7XHJcblRyYW5zZmVyU3RyaW5nIGRzID0gVEQuVG9UcmFuc2ZlclN0cmluZyhcIlwiKTtcclxuZHMuTmFtZSA9IGV4cC5QYXJlbnRCaW5kaW5nLlBhdGguUGF0aDtcclxuZHMuRGF0YSA9IHR4LlRleHQ7XHJcbmRzLkluc3RhbmNlID0gaW5zdGFuY2U7XHJcbmRzLkNsYXNzID0gQVBMLkdldENsYXNzQnlOYW1lKGRzLkluc3RhbmNlKTtcclxub2JqZWN0IG9iaiA9IEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgdGhpcyk7XHJcbnZhciBhcmd1bWVudHMgPSBuZXcgb2JqZWN0W10ge2RzLCB0cnVlfTsgIC8vIEFzIGlmIGVudGVyZWQgZnJvbSBzY3JlZW5cclxuQXNzZW1ibHkgYXNzZW1ibHkgPSBBUEwuR2V0QXNzZW1ibHkoXCJEYXRhQmluZGluZ1wiLCB0aGlzKTtcclxuVHlwZSB0eXBlID0gYXNzZW1ibHkuR2V0VHlwZShcIkRhdGFCaW5kaW5nXCIgKyBcIi5cIiArIGRzLkNsYXNzKTtcclxuTWV0aG9kSW5mbyBtZXRob2QgPSB0eXBlLkdldE1ldGhvZChcIlJ1blByb3BlcnR5Q2hhbmdlZEluXCIpO1xyXG5tZXRob2QuSW52b2tlKG9iaiwgYXJndW1lbnRzKTtcclxufX1cclxucHJpdmF0ZSB2b2lkIFVwZGF0ZUJpbmRpbmdLZXlEb3duKG9iamVjdCBzZW5kZXIsIEtleVJvdXRlZEV2ZW50QXJncyBlKVxyXG57IFxyXG5pZiAoZS5LZXkgPT0gVmlydHVhbEtleS5FbnRlcilcclxueyBcclxuVGV4dEJveCB0eCA9IChUZXh0Qm94KXNlbmRlcjtcclxuaWYoMCE9dHguVGV4dC5MZW5ndGgpe1xyXG5CaW5kaW5nRXhwcmVzc2lvbiBleHAgPSB0eC5HZXRCaW5kaW5nRXhwcmVzc2lvbihUZXh0Qm94LlRleHRQcm9wZXJ0eSk7XHJcbk1KSF9Db21tb25EYXRhIGRvYmogPSBleHAuRGF0YUl0ZW0gYXMgTUpIX0NvbW1vbkRhdGE7XHJcbnN0cmluZyBpbnN0YW5jZSA9IGRvYmouTUpIX0luc3RhbmNlO1xyXG5UcmFuc2ZlclN0cmluZyBkcyA9IFRELlRvVHJhbnNmZXJTdHJpbmcoXCJcIik7XHJcbmRzLk5hbWUgPSBleHAuUGFyZW50QmluZGluZy5QYXRoLlBhdGg7XHJcbmRzLkRhdGEgPSB0eC5UZXh0O1xyXG5kcy5JbnN0YW5jZSA9IGluc3RhbmNlO1xyXG5kcy5DbGFzcyA9IEFQTC5HZXRDbGFzc0J5TmFtZShkcy5JbnN0YW5jZSk7XHJcbm9iamVjdCBvYmogPSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBkcy5DbGFzcywgZHMuSW5zdGFuY2UsIHRoaXMpO1xyXG52YXIgYXJndW1lbnRzID0gbmV3IG9iamVjdFtdIHtkcywgdHJ1ZX07ICAgIC8vIEFzIGlmIGVudGVyZWQgZnJvbSBzY3JlZW5cclxuQXNzZW1ibHkgYXNzZW1ibHkgPSBBUEwuR2V0QXNzZW1ibHkoXCJEYXRhQmluZGluZ1wiLCB0aGlzKTtcclxuVHlwZSB0eXBlID0gYXNzZW1ibHkuR2V0VHlwZShcIkRhdGFCaW5kaW5nXCIgKyBcIi5cIiArIGRzLkNsYXNzKTtcclxuTWV0aG9kSW5mbyBtZXRob2QgPSB0eXBlLkdldE1ldGhvZChcIlJ1blByb3BlcnR5Q2hhbmdlZEluXCIpO1xyXG5tZXRob2QuSW52b2tlKG9iaiwgYXJndW1lbnRzKTtcclxufX19XHJcbn19XHJcbiIsInVzaW5nIFN5c3RlbTtcclxudXNpbmcgQVBMRXh0ZW5zaW9uO1xyXG51c2luZyBTeXN0ZW0uUmVmbGVjdGlvbjtcclxudXNpbmcgQVBMQ29udHJvbHM7XHJcbnVzaW5nIFN5c3RlbS5Db2xsZWN0aW9ucy5HZW5lcmljO1xyXG51c2luZyBXaW5kb3dzLlVJLlhhbWw7XHJcbnVzaW5nIERhdGFCaW5kaW5nO1xyXG51c2luZyBDU0hUTUw1O1xyXG5cclxubmFtZXNwYWNlIFFXQ1xyXG57XHJcbiAgICBwdWJsaWMgc3RhdGljIGNsYXNzIE5RXHJcbiAgICB7XHJcbiAgICAgICAgcHVibGljIHN0YXRpYyBTdHJpbmcgRG9BZGRWaXN1YWwoVHJhbnNmZXJTdHJpbmcgZHMsIG9iamVjdCBhY3R0aGlzKVxyXG4gICAgICAgIHtcclxuICAgICAgICAgICAgb2JqZWN0IG9iaiA9IEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgYWN0dGhpcyk7XHJcbiAgICAgICAgICAgIHZhciBhcmd1bWVudHMgPSBuZXcgb2JqZWN0W10geyBkcyB9O1xyXG4gICAgICAgICAgICBBc3NlbWJseSBhc3NlbWJseSA9IEFQTC5HZXRBc3NlbWJseShcIkRhdGFCaW5kaW5nXCIsIGFjdHRoaXMpO1xyXG5cclxuICAgICAgICAgICAgc3RyaW5nIGNsID0gQVBMLkdldENsYXNzQnlOYW1lKGRzLkluc3RhbmNlKTtcclxuICAgICAgICAgICAgaWYgKGNsLkNvbnRhaW5zKFwiX0RhdGFcIikpIGNsID0gY2wuU3Vic3RyaW5nKDAsIGNsLkxlbmd0aCAtIDUpO1xyXG4gICAgICAgICAgICBUeXBlIHR5cGUgPSBhc3NlbWJseS5HZXRUeXBlKFwiRGF0YUJpbmRpbmdcIiArIFwiLlwiICsgY2wpO1xyXG5cclxuICAgICAgICAgICAgTWV0aG9kSW5mbyBtZXRob2QgPSB0eXBlLkdldE1ldGhvZChcIkRvQWRkVmlzdWFsXCIpO1xyXG5cclxuICAgICAgICAgICAgaWYgKFV0aWxzLklzU3RhdGljKG1ldGhvZCkpXHJcbiAgICAgICAgICAgICAgICByZXR1cm4gKFN0cmluZyltZXRob2QuSW52b2tlKG51bGwsIGFyZ3VtZW50cyk7XHJcbiAgICAgICAgICAgIGVsc2VcclxuICAgICAgICAgICAgICAgIHJldHVybiAoU3RyaW5nKW1ldGhvZC5JbnZva2UoKChNSkhfQ29tbW9uRGF0YSlvYmopLk1KSF9DbGFzcywgYXJndW1lbnRzKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHB1YmxpYyBzdGF0aWMgU3RyaW5nIERvUnVuRXZlbnQoVHJhbnNmZXJTdHJpbmcgZHMsIG9iamVjdCBhY3R0aGlzKVxyXG4gICAgICAgIHtcclxuICAgICAgICAgICAgb2JqZWN0IG9iaiA9IEFQTC5HZXRJbnN0YW5jZShcIkRhdGFCaW5kaW5nXCIsIGRzLkNsYXNzLCBkcy5JbnN0YW5jZSwgYWN0dGhpcyk7XHJcbiAgICAgICAgICAgIHZhciBhcmd1bWVudHMgPSBuZXcgb2JqZWN0W10geyBkcyB9O1xyXG4gICAgICAgICAgICBBc3NlbWJseSBhc3NlbWJseSA9IEFQTC5HZXRBc3NlbWJseShcIkRhdGFCaW5kaW5nXCIsIGFjdHRoaXMpO1xyXG5cclxuICAgICAgICAgICAgc3RyaW5nIGNsID0gQVBMLkdldENsYXNzQnlOYW1lKGRzLkluc3RhbmNlKTtcclxuICAgICAgICAgICAgaWYgKGNsLkNvbnRhaW5zKFwiX0RhdGFcIikpIGNsID0gY2wuU3Vic3RyaW5nKDAsIGNsLkxlbmd0aCAtIDUpO1xyXG4gICAgICAgICAgICBUeXBlIHR5cGUgPSBhc3NlbWJseS5HZXRUeXBlKFwiRGF0YUJpbmRpbmdcIiArIFwiLlwiICsgY2wpO1xyXG5cclxuICAgICAgICAgICAgTWV0aG9kSW5mbyBtZXRob2QgPSB0eXBlLkdldE1ldGhvZChcIkRvUnVuRXZlbnRcIik7XHJcblxyXG4gICAgICAgICAgICBzdHJpbmcgcmVzdWx0ID0gXCJcIjtcclxuICAgICAgICAgICAgaWYgKG1ldGhvZCAhPSBudWxsKVxyXG4gICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICBpZiAoVXRpbHMuSXNTdGF0aWMobWV0aG9kKSlcclxuICAgICAgICAgICAgICAgICAgICByZXN1bHQgPSAoU3RyaW5nKW1ldGhvZC5JbnZva2UobnVsbCwgYXJndW1lbnRzKTtcclxuICAgICAgICAgICAgICAgIGVsc2VcclxuICAgICAgICAgICAgICAgICAgICByZXN1bHQgPSAoU3RyaW5nKW1ldGhvZC5JbnZva2UoKChNSkhfQ29tbW9uRGF0YSlvYmopLk1KSF9DbGFzcywgYXJndW1lbnRzKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICByZXR1cm4gcmVzdWx0O1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcHVibGljIHN0YXRpYyBTdHJpbmcgRG9SdW5NZXRob2QoVHJhbnNmZXJTdHJpbmcgZHMsIG9iamVjdCBhY3R0aGlzKVxyXG4gICAgICAgIHtcclxuICAgICAgICAgICAgc3RyaW5nIHJlc3VsdCA9IFwiXCI7XHJcbiAgICAgICAgICAgIG9iamVjdCBvYmogPSBBUEwuR2V0SW5zdGFuY2UoXCJEYXRhQmluZGluZ1wiLCBkcy5DbGFzcywgZHMuSW5zdGFuY2UsIGFjdHRoaXMpO1xyXG4gICAgICAgICAgICB2YXIgYXJndW1lbnRzID0gbmV3IG9iamVjdFtdIHsgZHMgfTtcclxuICAgICAgICAgICAgQXNzZW1ibHkgYXNzZW1ibHkgPSBBUEwuR2V0QXNzZW1ibHkoXCJEYXRhQmluZGluZ1wiLCBhY3R0aGlzKTtcclxuICAgICAgICAgICAgc3RyaW5nIGNsID0gQVBMLkdldENsYXNzQnlOYW1lKGRzLkluc3RhbmNlKTtcclxuXHJcbiAgICAgICAgICAgIGlmIChjbC5Db250YWlucyhcIl9EYXRhXCIpKSBjbCA9IGNsLlN1YnN0cmluZygwLCBjbC5MZW5ndGggLSA1KTtcclxuICAgICAgICAgICAgVHlwZSB0eXBlID0gYXNzZW1ibHkuR2V0VHlwZShcIkRhdGFCaW5kaW5nXCIgKyBcIi5cIiArIGNsKTtcclxuICAgICAgICAgICAgTWV0aG9kSW5mbyBtZXRob2QgPSB0eXBlLkdldE1ldGhvZChcIkRvXCIgKyBkcy5EYXRhKTtcclxuXHJcbiAgICAgICAgICAgIGlmIChtZXRob2QgIT0gbnVsbClcclxuICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgaWYgKFV0aWxzLklzU3RhdGljKG1ldGhvZCkpIHJlc3VsdCA9IChTdHJpbmcpbWV0aG9kLkludm9rZShudWxsLCBhcmd1bWVudHMpO1xyXG4gICAgICAgICAgICAgICAgZWxzZSByZXN1bHQgPSAoU3RyaW5nKW1ldGhvZC5JbnZva2UoKChNSkhfQ29tbW9uRGF0YSlvYmopLk1KSF9DbGFzcywgYXJndW1lbnRzKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICByZXR1cm4gcmVzdWx0O1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcHVibGljIHN0YXRpYyBzdHJpbmcgRG9HZXRTZXJpYWxObyhUcmFuc2ZlclN0cmluZyBkcywgb2JqZWN0IGFjdHRoaXMpXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgICBNSkhfQ29tbW9uRGF0YSBvYmogPSAoTUpIX0NvbW1vbkRhdGEpQVBMLkdldEluc3RhbmNlKFwiRGF0YUJpbmRpbmdcIiwgZHMuQ2xhc3MsIGRzLkluc3RhbmNlLCBhY3R0aGlzKTtcclxuICAgICAgICAgICAgc3RyaW5nIHJlc3VsdCA9IG9iai5NSkhfU2VyaWFsTm87XHJcbiAgICAgICAgICAgIHJldHVybiByZXN1bHQ7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBwcml2YXRlIHN0YXRpYyBvYmplY3QgTG9ja0luc3RhbmNlcyA9IG5ldyBPYmplY3QoKTtcclxuXHJcbiAgICAgICAgcHVibGljIHN0YXRpYyBzdHJpbmcgRG9EZWxldGUoVHJhbnNmZXJTdHJpbmcgZHMsIG9iamVjdCBhY3R0aGlzKVxyXG4gICAgICAgIHtcclxuICAgICAgICAgICAgaWYgKGRzLkNsYXNzID09IFwicXdjX1Jvb3RcIikgcmV0dXJuIChcIlwiKTtcclxuICAgICAgICAgICAgc3RyaW5nIHJlc3VsdCA9IFwiXCI7XHJcblxyXG4gICAgICAgICAgICBvYmplY3Qgb2JqID0gQVBMLkdldEluc3RhbmNlKGRzLlNlcmlhbE5vKTtcclxuICAgICAgICAgICAgdmFyIGFyZ3VtZW50cyA9IG5ldyBvYmplY3RbXSB7IGRzIH07XHJcbiAgICAgICAgICAgIEFzc2VtYmx5IGFzc2VtYmx5ID0gQVBMLkdldEFzc2VtYmx5KFwiRGF0YUJpbmRpbmdcIiwgYWN0dGhpcyk7XHJcbiAgICAgICAgICAgIGlmICgwICE9IGRzLlNlcmlhbE5vLkxlbmd0aClcclxuICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgc3RyaW5nIGNsID0gQVBMLkdldENsYXNzQnlTZXJpYWxObyhkcy5TZXJpYWxObyk7XHJcblx0XHRcdFx0aWYgKDAgIT0gY2wuTGVuZ3RoKSB7XHJcblx0XHRcdFx0XHRpZiAoY2wuQ29udGFpbnMoXCJfRGF0YVwiKSkgY2wgPSBjbC5TdWJzdHJpbmcoMCwgY2wuTGVuZ3RoIC0gNSk7XHJcblx0XHRcdFx0XHRUeXBlIHR5cGUgPSBhc3NlbWJseS5HZXRUeXBlKFwiRGF0YUJpbmRpbmdcIiArIFwiLlwiICsgY2wpO1xyXG5cclxuXHRcdFx0XHRcdE1ldGhvZEluZm8gbWV0aG9kID0gdHlwZS5HZXRNZXRob2QoXCJEb0RlbGV0ZVwiKTtcclxuXHJcblx0XHRcdFx0XHRpZiAobWV0aG9kICE9IG51bGwpXHJcblx0XHRcdFx0XHR7XHJcblx0XHRcdFx0XHRcdGlmIChVdGlscy5Jc1N0YXRpYyhtZXRob2QpKVxyXG5cdFx0XHRcdFx0XHRcdHJlc3VsdCA9IChTdHJpbmcpbWV0aG9kLkludm9rZShudWxsLCBhcmd1bWVudHMpO1xyXG5cdFx0XHRcdFx0XHRlbHNlXHJcblx0XHRcdFx0XHRcdHtcclxuXHRcdFx0XHRcdFx0XHRNSkhfQ29tbW9uRGF0YSBzZWxmID0gKE1KSF9Db21tb25EYXRhKW9iajtcclxuXHRcdFx0XHRcdFx0XHRyZXN1bHQgPSAoU3RyaW5nKW1ldGhvZC5JbnZva2Uoc2VsZi5NSkhfQ2xhc3MsIGFyZ3VtZW50cyk7XHJcblx0XHRcdFx0XHRcdH1cclxuXHRcdFx0XHRcdH1cclxuXHRcdFx0ICAgfVxyXG4gICAgICAgICAgICAgICAgcmV0dXJuIHJlc3VsdDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIHJldHVybiBcIlwiO1xyXG4gICAgICAgIH1cclxuXHRcdHB1YmxpYyBzdGF0aWMgc3RyaW5nIERvU2V0QWNjZWxlcmF0b3IoVHJhbnNmZXJTdHJpbmcgZHMsIG9iamVjdCBhY3R0aGlzKVxyXG4gICAgICAgIHtcclxuICAgICAgICAgICAgaW50IGtleSA9IENvbnZlcnQuVG9JbnQzMihkcy5BcmdzKTtcclxuICAgICAgICAgICAgaWYgKGtleSAhPSAwKVxyXG4gICAgICAgICAgICB7IC8vIEFkZFxyXG4gICAgICAgICAgICAgICAgQWNjZWxlcmF0b3IuQWRkKGtleSwgZHMuSW5zdGFuY2UpO1xyXG4gICAgICAgICAgICB9IGVsc2UgXHJcbiAgICAgICAgICAgIHsgLy8gUmVtb3ZlXHJcbiAgICAgICAgICAgICAgICBBY2NlbGVyYXRvci5SZW1vdmUoa2V5LCBkcy5JbnN0YW5jZSk7XHJcblxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHJldHVybiBcIlwiO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG4iXQp9Cg==

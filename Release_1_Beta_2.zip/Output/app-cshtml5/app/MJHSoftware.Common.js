/**
 * @version 1.0.0.0
 * @copyright Copyright ©  2018
 * @compiler Bridge.NET 17.9.0
 */
Bridge.assembly("MJHSoftware.Common", function ($asm, globals) {
    "use strict";

    /** @namespace MJHSoftware.Common */

    /**
     * Base class providing a standard way to expose a JS component as a C#/XAML component.
     *
     * @abstract
     * @public
     * @class MJHSoftware.Common.JSComponent
     * @augments CSHTML5.Native.Html.Controls.HtmlPresenter
     */
    Bridge.define("MJHSoftware.Common.JSComponent", {
        inherits: [CSHTML5.Native.Html.Controls.HtmlPresenter],
        statics: {
            fields: {
                JSId_Max: 0,
                LockInstances: null
            },
            ctors: {
                init: function () {
                    this.JSId_Max = 0;
                    this.LockInstances = { };
                }
            },
            methods: {
                GetJSId: function () {
                    MJHSoftware.Common.JSComponent.LockInstances;
                    {
                        MJHSoftware.Common.JSComponent.JSId_Max = (MJHSoftware.Common.JSComponent.JSId_Max + 1) | 0;
                        return "mjhej" + (Bridge.toString(MJHSoftware.Common.JSComponent.JSId_Max) || "");
                    }
                }
            }
        },
        fields: {
            initJSInstance: false,
            SerialNo: null,
            MJH_model: null,
            _JSId: null,
            jsInstanceLoaded: null
        },
        props: {
            JSId: {
                get: function () {
                    return this._JSId;
                }
            },
            /**
             * @instance
             * @public
             * @readonly
             * @memberof MJHSoftware.Common.JSComponent
             * @function JSInstanceLoaded
             * @type System.Threading.Tasks.Task$1
             */
            JSInstanceLoaded: {
                get: function () {
                    return this.jsInstanceLoaded.task;
                }
            }
        },
        ctors: {
            init: function () {
                this.initJSInstance = false;
                this._JSId = MJHSoftware.Common.JSComponent.GetJSId();
                this.jsInstanceLoaded = new System.Threading.Tasks.TaskCompletionSource();
            }
        },
        methods: {
            InitializeId: function () { },
            /**
             * Initializes the HTML content of this component, as well as its underlying JS instance
             as soon as the component has finished loading in the Visual Tree.
             *
             * @instance
             * @protected
             * @this MJHSoftware.Common.JSComponent
             * @memberof MJHSoftware.Common.JSComponent
             * @param   {boolean}    initJSInstance    Whether the InitializeJSInstance method should be used to initialize the underlying JS instance.
             * @return  {void}
             */
            Initialize: function (initJSInstance) {
                if (initJSInstance === void 0) { initJSInstance = false; }
                this.initJSInstance = initJSInstance;

                this.Html = this.InitializeHtml();
                this.addLoaded(Bridge.fn.cacheBind(this, this.JSComponent_Loaded));
            },
            /**
             * Generates the initial HTML content of this component.
             *
             * @instance
             * @protected
             * @this MJHSoftware.Common.JSComponent
             * @memberof MJHSoftware.Common.JSComponent
             * @return  {string}        A string holding the initial HTML.
             */
            InitializeHtml: function () {
                return "<div style='width: 100%; height: 100%;'>";
            },
            /**
             * Custom code to execute to initialize this component's underlying JS instance.
             *
             * @instance
             * @protected
             * @this MJHSoftware.Common.JSComponent
             * @memberof MJHSoftware.Common.JSComponent
             * @return  {void}
             */
            InitializeJSInstance: function () {
                throw new System.NotImplementedException.ctor();
            },
            /**
             * Custom code to execute after the underlying JS instance has finished loading.
             *
             * @instance
             * @protected
             * @this MJHSoftware.Common.JSComponent
             * @memberof MJHSoftware.Common.JSComponent
             * @return  {void}
             */
            OnJSInstanceLoaded: function () { },
            JSComponent_Loaded: function (sender, e) {
                var $step = 0,
                    $task1, 
                    $jumpFromFinally, 
                    $asyncBody = Bridge.fn.bind(this, function () {
                        for (;;) {
                            $step = System.Array.min([0,1], $step);
                            switch ($step) {
                                case 0: {
                                    $task1 = this.JSLibrary.Load();
                                    $step = 1;
                                    if ($task1.isCompleted()) {
                                        continue;
                                    }
                                    $task1.continue($asyncBody);
                                    return;
                                }
                                case 1: {
                                    $task1.getAwaitedResult();
                                    if (this.initJSInstance) {
                                        this.InitializeJSInstance();
                                    }
                                    this.jsInstanceLoaded.setResult(true);
                                    this.OnJSInstanceLoaded();
                                    return;
                                }
                                default: {
                                    return;
                                }
                            }
                        }
                    }, arguments);

                $asyncBody();
            }
        }
    });

    /** @namespace System */

    /**
     * @memberof System
     * @callback System.Action
     * @return  {void}
     */

    /**
     * Class used to represent a set of JS and CSS files that should be loaded only once.
     *
     * @public
     * @class MJHSoftware.Common.JSLibrary
     */
    Bridge.define("MJHSoftware.Common.JSLibrary", {
        fields: {
            /**
             * @instance
             * @public
             * @memberof MJHSoftware.Common.JSLibrary
             * @function IsLoaded
             * @type boolean
             */
            IsLoaded: false,
            /**
             * @instance
             * @public
             * @memberof MJHSoftware.Common.JSLibrary
             * @function CSS
             * @type Array.<string>
             */
            CSS: null,
            /**
             * @instance
             * @public
             * @memberof MJHSoftware.Common.JSLibrary
             * @function JS
             * @type Array.<string>
             */
            JS: null
        },
        ctors: {
            ctor: function (css, js) {
                this.$initialize();
                this.IsLoaded = false;
                this.CSS = css;
                this.JS = js;
            }
        },
        methods: {
            ResetLoaded: function () {
                this.IsLoaded = false;
            },
            /**
             * Loads the library if it is not already loaded.
             *
             * @instance
             * @public
             * @this MJHSoftware.Common.JSLibrary
             * @memberof MJHSoftware.Common.JSLibrary
             * @return  {System.Threading.Tasks.Task}        A Task that should be awaited to wait until the library has finished loading.
             */
            Load: function () {
                var $step = 0,
                    $task1, 
                    $taskResult1, 
                    $task2, 
                    $taskResult2, 
                    $jumpFromFinally, 
                    $tcs = new System.Threading.Tasks.TaskCompletionSource(), 
                    $returnValue, 
                    $t, 
                    url, 
                    $t1, 
                    url1, 
                    $async_e, 
                    $asyncBody = Bridge.fn.bind(this, function () {
                        try {
                            for (;;) {
                                $step = System.Array.min([0,1,2,3,4,5,6,7,8,9,10], $step);
                                switch ($step) {
                                    case 0: {
                                        if (!this.IsLoaded) {
                                            $step = 1;
                                            continue;
                                        } 
                                        $step = 10;
                                        continue;
                                    }
                                    case 1: {
                                        $t = Bridge.getEnumerator(this.CSS);
                                        $step = 2;
                                        continue;
                                    }
                                    case 2: {
                                        if ($t.moveNext()) {
                                            url = $t.Current;
                                            $step = 3;
                                            continue;
                                        }
                                        $step = 5;
                                        continue;
                                    }
                                    case 3: {
                                        $task1 = CSHTML5.Interop.LoadCssFile$1(url);
                                        $step = 4;
                                        if ($task1.isCompleted()) {
                                            continue;
                                        }
                                        $task1.continue($asyncBody);
                                        return;
                                    }
                                    case 4: {
                                        $taskResult1 = $task1.getAwaitedResult();
                                        $step = 2;
                                        continue;
                                    }
                                    case 5: {
                                        $t1 = Bridge.getEnumerator(this.JS);
                                        $step = 6;
                                        continue;
                                    }
                                    case 6: {
                                        if ($t1.moveNext()) {
                                            url1 = $t1.Current;
                                            $step = 7;
                                            continue;
                                        }
                                        $step = 9;
                                        continue;
                                    }
                                    case 7: {
                                        $task2 = CSHTML5.Interop.LoadJavaScriptFile$1(url1);
                                        $step = 8;
                                        if ($task2.isCompleted()) {
                                            continue;
                                        }
                                        $task2.continue($asyncBody);
                                        return;
                                    }
                                    case 8: {
                                        $taskResult2 = $task2.getAwaitedResult();
                                        $step = 6;
                                        continue;
                                    }
                                    case 9: {
                                        this.IsLoaded = true;
                                        $step = 10;
                                        continue;
                                    }
                                    case 10: {
                                        $tcs.setResult(null);
                                        return;
                                    }
                                    default: {
                                        $tcs.setResult(null);
                                        return;
                                    }
                                }
                            }
                        } catch($async_e1) {
                            $async_e = System.Exception.create($async_e1);
                            $tcs.setException($async_e);
                        }
                    }, arguments);

                $asyncBody();
                return $tcs.task;
            },
            /**
             * Loads this library if it is not already loaded, and then executes a given callback.
             *
             * @instance
             * @public
             * @this MJHSoftware.Common.JSLibrary
             * @memberof MJHSoftware.Common.JSLibrary
             * @param   {System.Action}    callback    The callback to execute when the library has finished loading.
             * @return  {void}
             */
            LoadAsync: function (callback) {
                if (!this.IsLoaded) {
                    CSHTML5.Interop.LoadCssFilesAsync$1(this.CSS, Bridge.fn.bind(this, function () {
                        CSHTML5.Interop.LoadJavaScriptFilesAsync$1(this.JS, Bridge.fn.bind(this, function () {
                            this.IsLoaded = true;
                            callback();
                        }));
                    }));
                }
            }
        }
    });

    Bridge.define("MJHSoftware.Common.ejComponent", {
        inherits: [MJHSoftware.Common.JSComponent,TypeScriptDefinitionsSupport.IJSObject],
        statics: {
            fields: {
                _jsLibrary: null
            },
            ctors: {
                init: function () {
                    this._jsLibrary = new MJHSoftware.Common.JSLibrary(System.Array.init([], System.String), System.Array.init([], System.String));
                }
            }
        },
        fields: {
            UnderlyingJSInstance: null
        },
        props: {
            JSLibrary: {
                get: function () {
                    return MJHSoftware.Common.ejComponent._jsLibrary;
                }
            }
        },
        alias: ["UnderlyingJSInstance", "TypeScriptDefinitionsSupport$IJSObject$UnderlyingJSInstance"],
        ctors: {
            ctor: function () {
                this.$initialize();
                MJHSoftware.Common.JSComponent.ctor.call(this);
                this.UnderlyingJSInstance = new Object();
                this.Initialize$1();
            }
        },
        methods: {
            Initialize$1: function () {
                this.Initialize(false);
            },
            InitializeJSInstance: function () {


            }
        }
    });
});

//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAiZmlsZSI6ICJNSkhTb2Z0d2FyZS5Db21tb24uanMiLAogICJzb3VyY2VSb290IjogIiIsCiAgInNvdXJjZXMiOiBbIkpTQ29tcG9uZW50LmNzIiwiSlNMaWJyYXJ5LmNzIiwiZWpDb21wb25lbnQxLmNzIiwiZWpDb21wb25lbnQyLmNzIl0sCiAgIm5hbWVzIjogWyIiXSwKICAibWFwcGluZ3MiOiAiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O3lDQW9DOENBOzs7OztvQkFHNUJBOzt3QkFFRkE7d0JBQ0FBLE9BQU9BLFdBQVVBOzs7Ozs7Ozs7Ozs7Ozs7b0JBU0VBLE9BQU9BOzs7Ozs7Ozs7Ozs7O29CQXNCU0EsT0FBT0E7Ozs7Ozs7NkJBNEVaQTt3Q0ExRmlCQSxJQUFJQTs7Ozs7Ozs7Ozs7Ozs7OztrQ0E4QmpDQTs7Z0JBRXZCQSxzQkFBc0JBOztnQkFFckJBLFlBQVlBO2dCQUNaQSxlQUFlQTs7Ozs7Ozs7Ozs7O2dCQVloQkE7Ozs7Ozs7Ozs7OztnQkFhQ0EsTUFBTUEsSUFBSUE7Ozs7Ozs7Ozs7OzswQ0FjaUJBLFFBQWVBOzs7Ozs7Ozs7b0NBRTFDQSxTQUFNQTs7Ozs7Ozs7OztvQ0FDVEEsSUFBSUE7d0NBQ0dBOztvQ0FHWkE7b0NBQ1lBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7NEJDaEhTQSxLQUFjQTs7Z0JBRTNCQTtnQkFDQUEsV0FBV0E7Z0JBQ1hBLFVBQVVBOzs7OztnQkFLVkE7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7d0NBV0FBLElBQUlBLENBQUNBOzs7Ozs7Ozt3Q0FFREEsMEJBQW9CQTs7Ozs7Ozs7Ozs7Ozs7d0NBQ2hCQSxTQUFNQSw4QkFBb0JBOzs7Ozs7Ozs7Ozs7Ozt3Q0FFOUJBLDJCQUFvQkE7Ozs7Ozs7Ozs7Ozs7O3dDQUNoQkEsU0FBTUEscUNBQTJCQTs7Ozs7Ozs7Ozs7Ozs7d0NBRXJDQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O2lDQVVjQTtnQkFFbEJBLElBQUlBLENBQUNBO29CQUVEQSxvQ0FBMEJBLFVBQVVBLEFBQVNBO3dCQUV6Q0EsMkNBQWlDQSxTQUFTQSxBQUFTQTs0QkFFL0NBOzRCQUNBQTs7Ozs7Ozs7Ozs7Ozs7OztzQ0M3RHVCQSxJQUFJQSw2QkFDbENBLHNDQUdEQTs7Ozs7Ozs7OztvQkFNb0NBLE9BQU9BOzs7Ozs7Ozs7Z0JDUi9DQSw0QkFBNEJBO2dCQUM1QkE7Ozs7O2dCRFdBQSIsCiAgInNvdXJjZXNDb250ZW50IjogWyJ1c2luZyBDU0hUTUw1Lk5hdGl2ZS5IdG1sLkNvbnRyb2xzO1xyXG51c2luZyBTeXN0ZW07XHJcbnVzaW5nIFN5c3RlbS5Db2xsZWN0aW9ucy5HZW5lcmljO1xyXG51c2luZyBTeXN0ZW0uTGlucTtcclxudXNpbmcgU3lzdGVtLlRleHQ7XHJcbnVzaW5nIFN5c3RlbS5UaHJlYWRpbmcuVGFza3M7XHJcbnVzaW5nIFR5cGVTY3JpcHREZWZpbml0aW9uc1N1cHBvcnQ7XHJcbnVzaW5nIFdpbmRvd3MuVUkuWGFtbDtcclxudXNpbmcgQVBMRXh0ZW5zaW9uO1xyXG5cclxubmFtZXNwYWNlIE1KSFNvZnR3YXJlLkNvbW1vblxyXG57XHJcbiAgICAvLy8gPHN1bW1hcnk+XHJcbiAgICAvLy8gQmFzZSBjbGFzcyBwcm92aWRpbmcgYSBzdGFuZGFyZCB3YXkgdG8gZXhwb3NlIGEgSlMgY29tcG9uZW50IGFzIGEgQyMvWEFNTCBjb21wb25lbnQuXHJcbiAgICAvLy8gPC9zdW1tYXJ5PlxyXG4gICAgLy8vIDxyZW1hcmtzPlxyXG4gICAgLy8vIFRoaXMgY2xhc3Mgc2hvdWxkIGJlIGRlcml2ZWQgd2hlbmV2ZXIgcG9zc2libGUgd2hlbiBkZXNpZ25pbmcgYSBsaWJyYXJ5IGV4cG9zaW5nIGEgSlMgY29tcG9uZW50LCBiZWNhdXNlOlxyXG4gICAgLy8vIDxsaXN0IHR5cGU9XCJudW1iZXJcIj5cclxuICAgIC8vLyA8aXRlbT5cclxuICAgIC8vLyBJdCBlbnN1cmVzIHRoYXQgdGhlIGNsYXNzIGV4cG9zaW5nIHRoZSBjb21wb25lbnQgaW1wbGVtZW50cyB0aGUgY29ycmVjdCBpbml0aWFsaXphdGlvbiBsb2dpY1xyXG4gICAgLy8vIGZvciB0aGUgdW5kZXJseWluZyBKUyBpbnN0YW5jZS5cclxuICAgIC8vLyA8L2l0ZW0+XHJcbiAgICAvLy8gPGl0ZW0+XHJcbiAgICAvLy8gSXQgaXMgZGVzaWduZWQgdG8gaW50ZWdyYXRlIHdlbGwgd2l0aCBDIyBjb2RlIGdlbmVyYXRlZCBieSB0aGUgY29tcGlsZXIgZnJvbSBUeXBlU2NyaXB0IGRlZmluaXRpb25zLlxyXG4gICAgLy8vIDwvaXRlbT5cclxuICAgIC8vLyA8aXRlbT5cclxuICAgIC8vLyBJdCBtYWtlcyBpdCBlYXNpZXIgdG8gcHJvdmlkZSBhIGNvbnNpc3RlbnQgQVBJIGFjcm9zcyBhbGwgbGlicmFyaWVzIG9mIHRoaXMga2luZC5cclxuICAgIC8vLyA8L2l0ZW0+XHJcbiAgICAvLy8gPC9saXN0PlxyXG4gICAgLy8vIEhvd2V2ZXIsIG9uZSBtaWdodCBuZWVkIGl0cyBjb21wb25lbnQgdG8gZGVyaXZlIGZyb20gYSBkaWZmZXJlbnQgY2xhc3MgdGhhbiBIdG1sUHJlc2VudGVyLlxyXG4gICAgLy8vIEluIHRoaXMgY2FzZSwgaXQgaXMgYWR2aXNlZCB0byByZXByb2R1Y2UgbW9zdCBvZiB0aGUgZnVuY3Rpb25hbGl0eSBwcm92aWRlZCBieSBKU0NvbXBvbmVudFxyXG4gICAgLy8vIGluIHlvdXIgY2xhc3MgdG8ga2VlcCB0aGUgYWZvcmVtZW50aW9uZWQgYmVuZWZpdHMuXHJcbiAgICAvLy8gPC9yZW1hcmtzPlxyXG4gICAgcHVibGljIGFic3RyYWN0IGNsYXNzIEpTQ29tcG9uZW50IDogSHRtbFByZXNlbnRlclxyXG4gICAge1xyXG4gICAgICAgIHB1YmxpYyBzdGF0aWMgaW50IEpTSWRfTWF4ID0gMDtcclxuICAgICAgICBwcml2YXRlIHN0YXRpYyBvYmplY3QgTG9ja0luc3RhbmNlcyA9IG5ldyBPYmplY3QoKTtcclxuICAgICAgICBwcml2YXRlIHN0YXRpYyBzdHJpbmcgR2V0SlNJZCgpXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgICBsb2NrIChMb2NrSW5zdGFuY2VzKVxyXG4gICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICBKU0lkX01heCsrO1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIFwibWpoZWpcIiArIEpTSWRfTWF4LlRvU3RyaW5nKCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGJvb2wgaW5pdEpTSW5zdGFuY2UgPSBmYWxzZTtcclxuXHRcdFxyXG5cdFx0cHVibGljIHN0cmluZyBTZXJpYWxObyB7IGdldDsgc2V0OyB9XHJcblx0XHRwdWJsaWMgSUpTT2JqZWN0IE1KSF9tb2RlbDsgXHJcblx0XHRcclxuICAgICAgICBwdWJsaWMgU3RyaW5nIEpTSWQgeyBnZXQgeyByZXR1cm4gX0pTSWQ7IH0gfVxyXG4gICAgICAgIHByaXZhdGUgU3RyaW5nIF9KU0lkIHsgZ2V0OyBzZXQ7IH1cclxuXHJcbiAgICAgICAgcHJvdGVjdGVkIHZpcnR1YWwgdm9pZCBJbml0aWFsaXplSWQoKVxyXG4gICAgICAgIHtcclxuICAgICAgICAgICAgLy8gb3ZlcnJpZGVuXHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICByZWFkb25seSBUYXNrQ29tcGxldGlvblNvdXJjZTxib29sPiBqc0luc3RhbmNlTG9hZGVkID0gbmV3IFRhc2tDb21wbGV0aW9uU291cmNlPGJvb2w+KCk7XHJcblxyXG4gICAgICAgIC8vLyA8dmFsdWU+XHJcbiAgICAgICAgLy8vIEpTIExpYnJhcnkgdGhhdCBtdXN0IGJlIGxvYWRlZCBiZWZvcmUgdGhpcyBjb21wb25lbnQuXHJcbiAgICAgICAgLy8vIDwvdmFsdWU+XHJcbiAgICAgICAgLy8vIDxyZW1hcmtzPlxyXG4gICAgICAgIC8vLyBUaGlzIHNob3VsZCBiZSBpbXBsZW1lbnRlZCBhcyBhIHJlZmVyZW5jZSB0byBhIHN0YXRpYyBmaWVsZFxyXG4gICAgICAgIC8vLyB0byBhdm9pZCBsb2FkaW5nIHRoZSBzYW1lIGZpbGVzIG11bHRpcGxlIHRpbWVzLlxyXG4gICAgICAgIC8vLyA8L3JlbWFya3M+XHJcbiAgICAgICAgcHVibGljIGFic3RyYWN0IEpTTGlicmFyeSBKU0xpYnJhcnkgeyBnZXQ7IH1cclxuXHJcbiAgICAgICAgLy8vIDx2YWx1ZT5cclxuICAgICAgICAvLy8gVGFzayBwcm92aWRpbmcgYSB3YXkgZm9yIHVzZXJzIHRvIHdhaXQgZm9yIHRoZSBpbml0aWFsaXphdGlvbiBvZiB0aGlzIGNvbXBvbmVudCdzIHVuZGVybHlpbmcgSlMgaW5zdGFuY2UuXHJcbiAgICAgICAgLy8vIDwvdmFsdWU+XHJcbiAgICAgICAgcHVibGljIFRhc2s8Ym9vbD4gSlNJbnN0YW5jZUxvYWRlZCB7IGdldCB7IHJldHVybiBqc0luc3RhbmNlTG9hZGVkLlRhc2s7IH0gfVxyXG5cclxuICAgICAgICAvLy8gPHN1bW1hcnk+XHJcbiAgICAgICAgLy8vIEluaXRpYWxpemVzIHRoZSBIVE1MIGNvbnRlbnQgb2YgdGhpcyBjb21wb25lbnQsIGFzIHdlbGwgYXMgaXRzIHVuZGVybHlpbmcgSlMgaW5zdGFuY2VcclxuICAgICAgICAvLy8gYXMgc29vbiBhcyB0aGUgY29tcG9uZW50IGhhcyBmaW5pc2hlZCBsb2FkaW5nIGluIHRoZSBWaXN1YWwgVHJlZS5cclxuICAgICAgICAvLy8gPC9zdW1tYXJ5PlxyXG4gICAgICAgIC8vLyA8cGFyYW0gbmFtZT1cImluaXRKU0luc3RhbmNlXCI+XHJcbiAgICAgICAgLy8vIFdoZXRoZXIgdGhlIEluaXRpYWxpemVKU0luc3RhbmNlIG1ldGhvZCBzaG91bGQgYmUgdXNlZCB0byBpbml0aWFsaXplIHRoZSB1bmRlcmx5aW5nIEpTIGluc3RhbmNlLlxyXG4gICAgICAgIC8vLyA8L3BhcmFtPlxyXG4gICAgICAgIC8vLyA8cmVtYXJrcz5cclxuICAgICAgICAvLy8gV2hlbiB3b3JraW5nIHdpdGggQyMgY29kZSBnZW5lcmF0ZWQgYnkgdGhlIGNvbXBpbGVyIGZyb20gVHlwZVNjcmlwdCBkZWZpbml0aW9ucywgdGhpcyBtZXRob2RcclxuICAgICAgICAvLy8gc2hvdWxkIGJlIGNhbGxlZCBpbiBldmVyeSBvdmVybG9hZCBvZiB0aGUgcGFydGlhbCBJbml0aWFsaXplIG1ldGhvZCBzbyB0aGF0IGl0IHdpbGwgYmUgY2FsbGVkXHJcbiAgICAgICAgLy8vIGluIGV2ZXJ5IGNvbnN0dWN0b3IuXHJcbiAgICAgICAgLy8vIFRoZSBpbml0SlNJbnN0YW5jZSBwYXJhbWV0ZXIgaXMgdXNlZnVsIHdoZW4gc3RyYXlpbmcgYXBhcnQgZnJvbSB0aGUgaW5zdGFuY2lhdGlvbiBzY2VuYXJpb3NcclxuICAgICAgICAvLy8gcHJvdmlkZWQgYnkgdGhlIEpTIGxpYnJhcnkgb2YgdGhlIGNvbXBvbmVudC5cclxuICAgICAgICAvLy8gPC9yZW1hcmtzPlxyXG4gICAgICAgIHByb3RlY3RlZCB2b2lkIEluaXRpYWxpemUoYm9vbCBpbml0SlNJbnN0YW5jZSA9IGZhbHNlKVxyXG4gICAgICAgIHtcclxuICAgICAgICAgICB0aGlzLmluaXRKU0luc3RhbmNlID0gaW5pdEpTSW5zdGFuY2U7XHJcblxyXG4gICAgICAgICAgICB0aGlzLkh0bWwgPSB0aGlzLkluaXRpYWxpemVIdG1sKCk7XHJcbiAgICAgICAgICAgIHRoaXMuTG9hZGVkICs9IHRoaXMuSlNDb21wb25lbnRfTG9hZGVkO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLy8vIDxzdW1tYXJ5PlxyXG4gICAgICAgIC8vLyBHZW5lcmF0ZXMgdGhlIGluaXRpYWwgSFRNTCBjb250ZW50IG9mIHRoaXMgY29tcG9uZW50LlxyXG4gICAgICAgIC8vLyA8L3N1bW1hcnk+XHJcbiAgICAgICAgLy8vIDxyZXR1cm5zPlxyXG4gICAgICAgIC8vLyBBIHN0cmluZyBob2xkaW5nIHRoZSBpbml0aWFsIEhUTUwuXHJcbiAgICAgICAgLy8vIDwvcmV0dXJucz5cclxuICAgICAgICBwcm90ZWN0ZWQgdmlydHVhbCBzdHJpbmcgSW5pdGlhbGl6ZUh0bWwoKVxyXG4gICAgICAgIHtcclxuICAgICAgICAgICAvLyBPdmVycmlkZGVuIHNvIHNvIG5vdCB1c2VkXHJcbiAgICAgICAgICAgcmV0dXJuIEBcIjxkaXYgc3R5bGU9J3dpZHRoOiAxMDAlOyBoZWlnaHQ6IDEwMCU7Jz5cIjtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC8vLyA8c3VtbWFyeT5cclxuICAgICAgICAvLy8gQ3VzdG9tIGNvZGUgdG8gZXhlY3V0ZSB0byBpbml0aWFsaXplIHRoaXMgY29tcG9uZW50J3MgdW5kZXJseWluZyBKUyBpbnN0YW5jZS5cclxuICAgICAgICAvLy8gPC9zdW1tYXJ5PlxyXG4gICAgICAgIC8vLyA8cmVtYXJrcz5cclxuICAgICAgICAvLy8gVGhpcyBtZXRob2Qgd2lsbCBiZSBleGVjdXRlZCBieSB0aGUgSW5pdGlhbGl6ZSBtZXRob2QgaWYgaXRzIGluaXRKU0luc3RhbmNlIHBhcmFtZXRlciBpcyBzZXQgdG8gdHJ1ZS5cclxuICAgICAgICAvLy8gVGhlIGxhdHRlciBkZWZhdWx0cyB0byBmYWxzZSBiZWNhdXNlIG1vc3Qgb2YgdGhlIHRpbWUsIGluc3RhbnRpYXRpb24gd2lsbCBiZSBoYW5kbGVkIGJ5IHRoZSBjb25zdHJ1Y3RvclxyXG4gICAgICAgIC8vLyBhdXRvLWdlbmVyYXRlZCBieSB0aGUgY29tcGlsZXIgZnJvbSB0aGUgVHlwZVNjcmlwdCBkZWZpbml0aW9uIG9mIHRoZSBjb21wb25lbnQuXHJcbiAgICAgICAgLy8vIDwvcmVtYXJrcz5cclxuICAgICAgICBwcm90ZWN0ZWQgdmlydHVhbCB2b2lkIEluaXRpYWxpemVKU0luc3RhbmNlKClcclxuICAgICAgICB7XHJcbiAgICAgICAgICAgIHRocm93IG5ldyBOb3RJbXBsZW1lbnRlZEV4Y2VwdGlvbigpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLy8vIDxzdW1tYXJ5PlxyXG4gICAgICAgIC8vLyBDdXN0b20gY29kZSB0byBleGVjdXRlIGFmdGVyIHRoZSB1bmRlcmx5aW5nIEpTIGluc3RhbmNlIGhhcyBmaW5pc2hlZCBsb2FkaW5nLlxyXG4gICAgICAgIC8vLyA8L3N1bW1hcnk+XHJcbiAgICAgICAgLy8vIFRoaXMgbWV0aG9kIGlzIHJlcXVpcmVkIGJlY2F1c2UgaXQgaXMgbm90IHBvc3NpYmxlIGluIENTSFRNTDUgdG8gd2FpdCBmb3IgYSB0YXNrXHJcbiAgICAgICAgLy8vIGluc2lkZSBvZiBhIHN5bmNocm9ub3VzIG1ldGhvZCwgYW5kIHRodXMgd2UgY2Fubm90IGF3YWl0IEpTSW5zdGFuY2VMb2FkZWQgaW4gdGhlXHJcbiAgICAgICAgLy8vIHBhcnRpYWwgSW5pdGlhbGl6ZSBtZXRob2QgYXV0by1nZW5lcmF0ZWQgYnkgdGhlIGNvbXBpbGVyLlxyXG4gICAgICAgIHByb3RlY3RlZCB2aXJ0dWFsIHZvaWQgT25KU0luc3RhbmNlTG9hZGVkKClcclxuICAgICAgICB7XHJcbiAgICAgICAgICAgIC8vIERvIG5vdGhpbmcgYnkgZGVmYXVsdC5cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgICBhc3luYyB2b2lkIEpTQ29tcG9uZW50X0xvYWRlZChvYmplY3Qgc2VuZGVyLCBXaW5kb3dzLlVJLlhhbWwuUm91dGVkRXZlbnRBcmdzIGUpXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgICBhd2FpdCB0aGlzLkpTTGlicmFyeS5Mb2FkKCk7XHJcblx0ICAgICAgICBpZiAodGhpcy5pbml0SlNJbnN0YW5jZSkgXHJcbiAgICAgICAgICAgICAgICB0aGlzLkluaXRpYWxpemVKU0luc3RhbmNlKCk7XHJcbiAgICAgICAgLy8gICAgRGlzcGF0Y2hlci5CZWdpbkludm9rZSgoKSA9PlxyXG4gICAgICAgIC8vICAge1xyXG5cdFx0XHRcdHRoaXMuanNJbnN0YW5jZUxvYWRlZC5TZXRSZXN1bHQodHJ1ZSk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLk9uSlNJbnN0YW5jZUxvYWRlZCgpO1xyXG4gICAgICAgIC8vICAgIH0pO1xyXG5cdFx0XHRcclxuXHRcdFx0Ly8gIHRoaXMuanNJbnN0YW5jZUxvYWRlZC5TZXRSZXN1bHQodHJ1ZSk7XHJcbiAgICAgICAgICAgIC8vICB0aGlzLk9uSlNJbnN0YW5jZUxvYWRlZCgpO1xyXG4gICAgICAgIH1cclxuXG4gICAgXG5wcml2YXRlIFN0cmluZyBfX1Byb3BlcnR5X19Jbml0aWFsaXplcl9fX0pTSWQ9R2V0SlNJZCgpO31cclxufVxyXG4iLCJ1c2luZyBDU0hUTUw1O1xyXG51c2luZyBTeXN0ZW07XHJcbnVzaW5nIFN5c3RlbS5Db2xsZWN0aW9ucy5HZW5lcmljO1xyXG51c2luZyBTeXN0ZW0uTGlucTtcclxudXNpbmcgU3lzdGVtLlRleHQ7XHJcbnVzaW5nIFN5c3RlbS5UaHJlYWRpbmcuVGFza3M7XHJcblxyXG5uYW1lc3BhY2UgTUpIU29mdHdhcmUuQ29tbW9uXHJcbntcclxuICAgIC8vLyA8c3VtbWFyeT4gIFxyXG4gICAgLy8vIENsYXNzIHVzZWQgdG8gcmVwcmVzZW50IGEgc2V0IG9mIEpTIGFuZCBDU1MgZmlsZXMgdGhhdCBzaG91bGQgYmUgbG9hZGVkIG9ubHkgb25jZS5cclxuICAgIC8vLyA8L3N1bW1hcnk+XHJcbiAgICBwdWJsaWMgY2xhc3MgSlNMaWJyYXJ5XHJcbiAgICB7XHJcbiAgICAgICAgLy8vIDx2YWx1ZT5cclxuICAgICAgICAvLy8gV2hldGhlciB0aGUgbGlicmFyeSBpcyBhbHJlYWR5IGxvYWRlZC5cclxuICAgICAgICAvLy8gPC92YWx1ZT5cclxuICAgICAgICBwdWJsaWMgYm9vbCBJc0xvYWRlZCB7IGdldDsgcHJpdmF0ZSBzZXQ7IH1cclxuXHJcbiAgICAgICAgLy8vIDx2YWx1ZT5cclxuICAgICAgICAvLy8gVVJMcyBwb2ludGluZyB0byB0aGUgbGlicmFyeSdzIENTUyBmaWxlcy5cclxuICAgICAgICAvLy8gPC92YWx1ZT5cclxuICAgICAgICBwdWJsaWMgc3RyaW5nW10gQ1NTIHsgZ2V0OyBwcml2YXRlIHNldDsgfVxyXG5cclxuICAgICAgICAvLy8gPHZhbHVlPlxyXG4gICAgICAgIC8vLyBVUkxzIHBvaW50aW5nIHRvIHRoZSBsaWJyYXJ5J3MgSlMgZmlsZXMuXHJcbiAgICAgICAgLy8vIDwvdmFsdWU+XHJcbiAgICAgICAgcHVibGljIHN0cmluZ1tdIEpTIHsgZ2V0OyBwcml2YXRlIHNldDsgfVxyXG5cclxuICAgICAgICBwdWJsaWMgSlNMaWJyYXJ5KHN0cmluZ1tdIGNzcywgc3RyaW5nW10ganMpXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgICB0aGlzLklzTG9hZGVkID0gZmFsc2U7XHJcbiAgICAgICAgICAgIHRoaXMuQ1NTID0gY3NzO1xyXG4gICAgICAgICAgICB0aGlzLkpTID0ganM7XHJcbiAgICAgICAgfVxyXG5cdFx0XHJcblx0XHRwdWJsaWMgdm9pZCBSZXNldExvYWRlZCgpXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgICB0aGlzLklzTG9hZGVkID0gZmFsc2U7XHJcbiAgICAgICAgfVxyXG5cdFx0XHJcblx0ICAgIC8vLyA8c3VtbWFyeT5cclxuICAgICAgICAvLy8gTG9hZHMgdGhlIGxpYnJhcnkgaWYgaXQgaXMgbm90IGFscmVhZHkgbG9hZGVkLlxyXG4gICAgICAgIC8vLyA8L3N1bW1hcnk+XHJcbiAgICAgICAgLy8vIDxyZXR1cm5zPlxyXG4gICAgICAgIC8vLyBBIFRhc2sgdGhhdCBzaG91bGQgYmUgYXdhaXRlZCB0byB3YWl0IHVudGlsIHRoZSBsaWJyYXJ5IGhhcyBmaW5pc2hlZCBsb2FkaW5nLlxyXG4gICAgICAgIC8vLyA8L3JldHVybnM+XHJcbiAgICAgICAgcHVibGljIGFzeW5jIFRhc2sgTG9hZCgpXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgICBpZiAoIXRoaXMuSXNMb2FkZWQpXHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgIGZvcmVhY2ggKHZhciB1cmwgaW4gdGhpcy5DU1MpXHJcbiAgICAgICAgICAgICAgICAgICAgYXdhaXQgSW50ZXJvcC5Mb2FkQ3NzRmlsZSh1cmwpO1xyXG5cclxuICAgICAgICAgICAgICAgIGZvcmVhY2ggKHZhciB1cmwgaW4gdGhpcy5KUylcclxuICAgICAgICAgICAgICAgICAgICBhd2FpdCBJbnRlcm9wLkxvYWRKYXZhU2NyaXB0RmlsZSh1cmwpO1xyXG5cclxuICAgICAgICAgICAgICAgIHRoaXMuSXNMb2FkZWQgPSB0cnVlO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAvLy8gPHN1bW1hcnk+XHJcbiAgICAgICAgLy8vIExvYWRzIHRoaXMgbGlicmFyeSBpZiBpdCBpcyBub3QgYWxyZWFkeSBsb2FkZWQsIGFuZCB0aGVuIGV4ZWN1dGVzIGEgZ2l2ZW4gY2FsbGJhY2suXHJcbiAgICAgICAgLy8vIDwvc3VtbWFyeT5cclxuICAgICAgICAvLy8gPHBhcmFtIG5hbWU9XCJjYWxsYmFja1wiPlxyXG4gICAgICAgIC8vLyBUaGUgY2FsbGJhY2sgdG8gZXhlY3V0ZSB3aGVuIHRoZSBsaWJyYXJ5IGhhcyBmaW5pc2hlZCBsb2FkaW5nLlxyXG4gICAgICAgIC8vLyA8L3BhcmFtPlxyXG4gICAgICAgIHB1YmxpYyB2b2lkIExvYWRBc3luYyhBY3Rpb24gY2FsbGJhY2spXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgICBpZiAoIXRoaXMuSXNMb2FkZWQpXHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgIEludGVyb3AuTG9hZENzc0ZpbGVzQXN5bmModGhpcy5DU1MsIChBY3Rpb24pKCgpID0+XHJcbiAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgSW50ZXJvcC5Mb2FkSmF2YVNjcmlwdEZpbGVzQXN5bmModGhpcy5KUywgKEFjdGlvbikoKCkgPT5cclxuICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuSXNMb2FkZWQgPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjYWxsYmFjaygpO1xyXG4gICAgICAgICAgICAgICAgICAgIH0pKTtcclxuICAgICAgICAgICAgICAgIH0pKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG4iLCJ1c2luZyBDU0hUTUw1O1xyXG51c2luZyBTeXN0ZW07XHJcbnVzaW5nIFN5c3RlbS5Db2xsZWN0aW9ucztcclxudXNpbmcgU3lzdGVtLkNvbGxlY3Rpb25zLkdlbmVyaWM7XHJcbnVzaW5nIFN5c3RlbS5MaW5xO1xyXG51c2luZyBTeXN0ZW0uVGhyZWFkaW5nLlRhc2tzO1xyXG51c2luZyBUeXBlU2NyaXB0RGVmaW5pdGlvbnNTdXBwb3J0O1xyXG51c2luZyBXaW5kb3dzLlVJLlhhbWw7XHJcbnVzaW5nIFdpbmRvd3MuVUkuWGFtbC5Db250cm9scztcclxudXNpbmcgV2luZG93cy5VSS5YYW1sLkRhdGE7XHJcblxyXG5uYW1lc3BhY2UgTUpIU29mdHdhcmUuQ29tbW9uXHJcbntcclxuICAgIHB1YmxpYyBwYXJ0aWFsIGNsYXNzIGVqQ29tcG9uZW50IDogSlNDb21wb25lbnRcclxuICAgIHtcclxuICAgICAgICBzdGF0aWMgcmVhZG9ubHkgSlNMaWJyYXJ5IF9qc0xpYnJhcnkgPSBuZXcgSlNMaWJyYXJ5KFxyXG4gICAgICAgICAgICBjc3M6IG5ldyBzdHJpbmdbXVxyXG4gICAgICAgICAgICB7XHJcblx0XHRcdH0sXHJcbiAgICAgICAgICAgIGpzOiBuZXcgc3RyaW5nW11cclxuICAgICAgICAgICAge1xyXG4gICAgLy8gICAgICAgICAgIFwibXMtYXBweDovLy9RV0Mvc2NyaXB0cy9lai5zcHJlYWRzaGVldC5qc1wiXHJcblx0ICAgICAgICB9XHJcbiAgICAgICAgKTtcclxuXHRcdFxyXG4gICAgICAgIHB1YmxpYyBvdmVycmlkZSBKU0xpYnJhcnkgSlNMaWJyYXJ5IHsgZ2V0IHsgcmV0dXJuIF9qc0xpYnJhcnk7IH0gfVxyXG5cclxuXHQgICAgcGFydGlhbCB2b2lkIEluaXRpYWxpemUoKVxyXG4gICAgICAgIHtcclxuICAgICAgICAgICAgYmFzZS5Jbml0aWFsaXplKGluaXRKU0luc3RhbmNlOiBmYWxzZSk7XHJcblx0XHR9XHJcblxyXG4gICAgICAgIHByb3RlY3RlZCBvdmVycmlkZSB2b2lkIEluaXRpYWxpemVKU0luc3RhbmNlKClcclxuICAgICAgICB7XHJcblx0XHQgICAvLyBHZXQgYSByZWZlcmVuY2UgdG8gdGhlIEhUTUwgRE9NIHJlcHJlc2VudGF0aW9uIG9mIHRoZSBjb250cm9sXHJcbiAgICAgICAgICAgLy8gb2JqZWN0IGRpdiA9IHRoaXMuRG9tRWxlbWVudDtcclxuXHJcbiAgICAgICAgICAgLy8gTWFrZSBzdXJlIHRoYXQgdGhlIGRpdiBoYXMgYSB1bmlxdWUgSUQgIChKU0lkIGZyb20gbmV3R1VJRClcclxuICAgICAgICAgICAvLyBJbnRlcm9wLkV4ZWN1dGVKYXZhU2NyaXB0KFwiJDAuaWQgPSAkMVwiLCBkaXYsIEpTSWQpO1xyXG5cdFx0XHRcclxuXHRcdCAgIC8vIFJlbmRlciB0aGUgY29udHJvbFxyXG5cdFx0ICAgLy8gTW9kZWwgbW9kZWwgPSB0aGlzLm1vZGVsOyAgIFx0Ly8gd2hlbiB1c2luZyBuZXcgTW9kZWwoKXt9XHJcblx0ICAgICAgIC8vIGlmIChtb2RlbCAhPSBudWxsKVx0XHRcdC8vIHdoZW4gdXNpbmcgbmV3IE1vZGVsKCl7fVxyXG5cdFx0ICAgLy8ge1xyXG5cdFx0ICAgLy9cdFx0ICAgIEludGVyb3AuRXhlY3V0ZUphdmFTY3JpcHQoQFwialF1ZXJ5KCcjJyArICQwKS5lalNwcmVhZHNoZWV0KCQxKTtcIiwgSlNJZCwgbW9kZWwuVW5kZXJseWluZ0pTSW5zdGFuY2UpO1xyXG5cdFx0ICAgLy9cdFx0fSBlbHNlIHtcclxuXHRcdCAgIC8vXHRcdFx0SW50ZXJvcC5FeGVjdXRlSmF2YVNjcmlwdChAXCJqUXVlcnkoJyMnICsgJDApLmVqU3ByZWFkc2hlZXQoKTtcIiwgSlNJZCk7XHJcblx0XHQgICAvL1x0XHR9XHJcblx0XHQgICAvL1x0XHJcblx0ICAgICAgIC8vIEluaXRpYWxpemUgdGhlIHVuZGVybHlpbmcgSlMgaW5zdGFuY2VcclxuICAgICAgICAgICAvLyB0aGlzLlVuZGVybHlpbmdKU0luc3RhbmNlID0gSW50ZXJvcC5FeGVjdXRlSmF2YVNjcmlwdChAXCJqUXVlcnkoJyMnICsgJDApLmRhdGEoJ2VqU3ByZWFkc2hlZXQnKVwiLCBKU0lkKTtcclxuXHQgICAgfVxyXG4gICAgfVxyXG59XHJcbiIsInVzaW5nIENTSFRNTDU7XHJcbnVzaW5nIFN5c3RlbTtcclxudXNpbmcgU3lzdGVtLkNvbGxlY3Rpb25zLkdlbmVyaWM7XHJcbnVzaW5nIEFub255bW91c1R5cGVzO1xyXG51c2luZyBUb0phdmFTY3JpcHRPYmplY3RFeHRlbmRlcjtcclxudXNpbmcgVHlwZVNjcmlwdERlZmluaXRpb25zU3VwcG9ydDtcclxuXHJcbm5hbWVzcGFjZSBNSkhTb2Z0d2FyZS5Db21tb25cclxue1xyXG4gICAgcHVibGljIHBhcnRpYWwgY2xhc3MgZWpDb21wb25lbnQgOiBJSlNPYmplY3RcclxuICAgIHtcclxuICAgICAgICBwdWJsaWMgb2JqZWN0IFVuZGVybHlpbmdKU0luc3RhbmNlIHsgZ2V0OyBzZXQ7IH1cclxuXHJcblx0ICAgIHBhcnRpYWwgdm9pZCBJbml0aWFsaXplKCk7XHJcblxyXG4gICAgICAgIHB1YmxpYyBlakNvbXBvbmVudCgpXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgICB0aGlzLlVuZGVybHlpbmdKU0luc3RhbmNlID0gSW50ZXJvcC5FeGVjdXRlSmF2YVNjcmlwdChcIm5ldyBPYmplY3QoKVwiKTtcclxuICAgICAgICAgICAgdGhpcy5Jbml0aWFsaXplKCk7XHJcbiAgICAgICAgfVxyXG5cdH1cclxufVxyXG4iXQp9Cg==

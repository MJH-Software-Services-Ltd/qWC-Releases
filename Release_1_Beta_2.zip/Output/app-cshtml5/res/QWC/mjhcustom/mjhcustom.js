function validateDate(testdate) {
        var date_regex = /^(0?[1-9]|1[0-2])\/(0?[1-9]|1\d|2\d|3[01])\/(19|20)\d{2}$/ ;
        return date_regex.test(testdate);
}

function init_text_width() {
    var element = document.createElement('canvas');
    element.className = "textDimensionCalculation";
	element.Id = "textDimensionCalculation"
}

function get_text_size(txt, font) {
    var element = document.getElementById('textDimensionCalculation');
    var context = element.getContext("2d");
    context.style="height: auto; width: auto;white-space: nowrap;";
    context.font = font;
    var sz = context.measureText(txt);
	return [sz.height, sz.width];
}

function mjhAddClass(elem, classname) {
   	if (!elem.classList.contains(classname)){
		elem.classList.add(classname);
	}
}
/**
 * Inserts newnode AFTER referencenode.
*/
function mjhinsertBeforeFirst(newNode, eElement) {
    eElement.insertBefore(newNode, eElement.firstElementChild);
}

function mjhinsertBefore(newNode, eElement) {
    eElement.insertBefore(newNode, eElement);
}

function mjhinsertAfter(newNode, referenceNode) {
    referenceNode.parentNode.insertBefore(newNode, referenceNode.nextSibling);
	
}
function mjhinsertAfterLast(newNode, referenceNode) {
    referenceNode.parentNode.insertBefore(newNode, referenceNode.lastElementChild);
}

/**
 * Uses canvas.measureText to compute and return the width of the given text of given font in pixels.
 * 
 * @param {String} text The text to be rendered.
 * @param {String} font The css font descriptor that text is to be rendered with (e.g. "bold 14px verdana").
 * 
 * @see https://stackoverflow.com/questions/118241/calculate-text-width-with-javascript/21015393#21015393
 *
 * usage:
 * console.log(mjhgetTextWidth("hello there!", "bold 12pt arial"));  // close to 86   
 */
function css( element, property ) {  
return window.getComputedStyle( element, null ).getPropertyValue( property );
}

/*there are other height metrics - tm is one that matches Win32  
* re-use canvas object for better performance */

function mjhgetTextWidth(font, text) {
    var canvas = mjhgetTextWidth.canvas || (mjhgetTextWidth.canvas = document.createElement("canvas"));
    var context = canvas.getContext("2d");
    context.font = font;
    var metrics = context.measureText(text);
    return metrics.width;
}

/*there are other height metrics - tm is one that matches Win32  
* re-use canvas object for better performance */

function mjhgetTextHeight(font, text) {
    var canvas = mjhgetTextHeight.canvas || (mjhgetTextHeight.canvas = document.createElement("canvas"));
    var context = canvas.getContext("2d");
    context.font = font;
    var metrics = context.measureText(text);
    return (metrics.actualBoundingBoxAscent + metrics.actualBoundingBoxDescent);
}


/* Fullscreen Document
 * To open the whole page in fullscreen, use the document.documentElement instead of document.getElementById("element"). In this example, we also use a close function to close the fullscreen:

 * Example   
 * <script>
/* Get the documentElement (<html>) to display the page in fullscreen 
 * var elem = document.documentElement; 
 * To open the whole page in fullscreen
 * Get the documentElement (<html>) to display the page in fullscreen, 
 *  use the document.documentElement instead of document.getElementById("element"). 
 *  In this example, we also use a close function to close the fullscreen:   
 * var elem = document.documentElement; 
 * var elem = document.getElementById("element") 
 * View in fullscreen */

//function AddFullScreenEvent(fn){
//  if (document.exitFullscreen) {
//    document.addEventListener("fullscreenchange", fn); 
//  } else if (document.mozCancelFullScreen) { /* Firefox */
//    document.addEventListener("mozfullscreenchange", fn);
//  } else if (document.webkitExitFullscreen) { /* Chrome, Safari and Opera */
//    document.addEventListener("webkitfullscreenchange", fn);
//  } else if (document.msExitFullscreen) { /* IE/Edge */
//    document.addEventListener("msfullscreenchange", fn); 
 // }
//}	

function openFullscreen(elem) {
  if (elem.requestFullscreen) {
    elem.requestFullscreen();
  } else if (elem.mozRequestFullScreen) { /* Firefox */
    elem.mozRequestFullScreen();
  } else if (elem.webkitRequestFullscreen) { /* Chrome, Safari and Opera */
    elem.webkitRequestFullscreen();
  } else if (elem.msRequestFullscreen) { /* IE/Edge */
    elem.msRequestFullscreen();
  }
}

/* Close fullscreen */
function closeFullscreen() {
	if (document.fullscreenElement || 
		document.webkitFullscreenElement || 
		document.mozFullScreenElement) {
 
		if (document.exitFullscreen) {
			document.exitFullscreen();
		} else if (document.mozCancelFullScreen) { /* Firefox */
			document.mozCancelFullScreen();
		} else if (document.webkitExitFullscreen) { /* Chrome, Safari and Opera */
			document.webkitExitFullscreen();
		} else if (document.msExitFullscreen) { /* IE/Edge */
			document.msExitFullscreen();
		}
	}
}	
/* </script>  */
// To manipulate CSS Style sheets 
function getCSSRule(ruleName, deleteFlag) {               // Return requested style obejct
   ruleName=ruleName.toLowerCase();                       // Convert test string to lower case.
   if (document.styleSheets) {                            // If browser can play with stylesheets
      for (var i=0; i<document.styleSheets.length; i++) { // For each stylesheet
        var styleSheet=document.styleSheets[i];          // Get the current Stylesheet
		var ii=0;                                        // Initialize subCounter.
        var cssRule=false;                               // Initialize cssRule. 
        do {                                             // For each rule in stylesheet
           if (styleSheet.cssRules) {                    // Browser uses cssRules?
              cssRule = styleSheet.cssRules[ii];         // Yes --Mozilla Style
           } else {                                      // Browser usses rules?
              cssRule = styleSheet.rules[ii];            // Yes IE style. 
           }                                             // End IE check.
           if (cssRule)  {                               // If we found a rule...
				if (cssRule.selectorText) {	
					if (cssRule.selectorText.toLowerCase()==ruleName) { 		//  match ruleName?
						if (deleteFlag=='delete') {             				// Yes.  Are we deleteing?
							if (styleSheet.cssRules) {          				// Yes, deleting...
								styleSheet.deleteRule(ii);        		// Delete rule, Moz Style
							} else {                             // Still deleting.
								styleSheet.removeRule(ii);        // Delete rule IE style.
							}                                    // End IE check.
							return true;                         // return true, class deleted.
						} else {                                // found and not deleting.
							return cssRule;                      // return the style object.
						}                                       // End delete Check
					}
				} else {                               // TODO Check for media rules (cssRule.cssRules)
				}	
			}                                             // end found cssRule
            ii++;                                         // Increment sub-counter
         } while (cssRule)                                // end While loop
      }                                                   // end For loop
   }                                                      // end styleSheet ability check
   return false;                                          // we found NOTHING!
}                                                         // end getCSSRule 

function killCSSRule(ruleName) {                          // Delete a CSS rule   
   return getCSSRule(ruleName,'delete');                  // just call getCSSRule w/delete flag.
}                                                         // end killCSSRule

function addCSSRule(ruleName) {                           // Create a new css rule
   if (document.styleSheets) {                            // Can browser do styleSheets?
      if (!getCSSRule(ruleName)) {                        // if rule doesn't exist...
         if (document.styleSheets[0].addRule) {           // Browser is IE?
            document.styleSheets[0].addRule(ruleName, null,0);      // Yes, add IE style
         } else {                                         // Browser is IE?
            document.styleSheets[0].insertRule(ruleName+' { }', 0); // Yes, add Moz style.
         }                                                // End browser check
      }                                                   // End already exist check.
   }                                                      // End browser ability check.
   return getCSSRule(ruleName);                           // return rule we just created.
} 
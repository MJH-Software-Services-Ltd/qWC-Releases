function mjhenableNoItems(elem) 
{
   	if (elem.element !=null && elem.element.parentElement != null)
	{
		if (!elem.element.parentElement.parentElement.classList.contains("no-item-class")) 
		{
			elem.element.parentElement.parentElement.classList.add("no-item-class");
		}
	}
}

function mjhdisableNoItems(elem) 
{
	if (elem.element !=null && elem.element.parentElement != null)
	{
		if (elem.element.parentElement.parentElement.classList.contains("no-item-class")) 
		{
			elem.element.parentElement.parentElement.classList.remove("no-item-class");
		}
	}
}

function mjhMenuExtend(elem)
{
	if (elem.element !=null && elem.element.parentElement != null)
	{   
		if (document.getElementById(elem).parentElement.classList.contains("e-menu-noextend")) 
		{
			document.getElementById(elem).parentElement.classList.remove("e-menu-noextend");
		}
		if (!document.getElementById(elem).parentElement.classList.contains("e-menu-extend")) 
		{
			document.getElementById(elem).parentElement.classList.add("e-menu-extend");
		}
	}
}

function mjhMenuNoExtend(elem) 
{
   	if (elem.element !=null && elem.element.parentElement != null)
	{
		if (document.getElementById(elem).parentElement.classList.contains("e-menu-extend")) 
		{
			document.getElementById(elem).parentElement.classList.remove("e-menu-extend");
		}
		if (!document.getElementById(elem).parentElement.classList.contains("e-menu-noextend")) 
		{
			document.getElementById(elem).parentElement.classList.add("e-menu-noextend");
		}
	}
}

function menufindid(stringId, myArray){
	for (var i=0; i < myArray.length; i++) {
        if (myArray[i].id === stringId) {
            return i;
        }
    }
	return -1;
}

function menufindlastid(stringId, myArray){
	if (0 === myArray.length) 
	{	
		return -1;
	} else
	{	
		var pos = menufindid(stringId, myArray);
		if (-1 === pos) {
			return -1;
		} else 
		{
			for (var i = mjhmax(0,pos); i < myArray.length; i++) {
				if (myArray[i].id !== stringId) {
					return i - 1;
				}
			}
			return i - 1;
		}	
	}
}
function mjhmax(first,second){
	if (first > second) 
	{
		return first;
	} else {
		return second;
	}
}	
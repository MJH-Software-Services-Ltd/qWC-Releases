/* List Multicolumn   */
function mjhenableList(elem) {
   	if (elem.classList.contains("e-popup-open")){
		elem.ulElement.parentNode.classList.remove("e-popup-open");
	}
	if (!elem.classList.contains("e-popup-close")){
		elem.ulElement.parentNode.classList.add("e-popup-close");
	}
}

function mjhdisableList(elem) {
   	if (!elem.classList.contains("e-popup-open")){
		elem.ulElement.parentNode.classList.add("e-popup-open");
	}
	if (elem.classList.contains("e-popup-close")){
		elem.ulElement.parentNode.classList.remove("e-popup-close");
	}
}
/* End List Multicolumn */


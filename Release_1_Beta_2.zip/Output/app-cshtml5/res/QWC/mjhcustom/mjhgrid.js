/* Grid ReadOnly active cell   */
function mjhAddReadOnly(elem) {
   	if (!elem.classList.contains("e-mjhreadonlycell")){
		elem.classList.add("e-mjhreadonlycell");
	}
}

function mjhRemoveReadOnly(elem) {
   	if (elem.classList.contains("e-mjhreadonlycell")) {
		elem.classList.remove("e-mjhreadonlycell");
	}	
}
/* End Grid ReadOnly active cell */
/* Grid active cell   */
function mjhAddCurCell(elem) {
   	if (!elem.classList.contains("e-mjhhighlightcurcell")){
		elem.classList.add("e-mjhhighlightcurcell");
	}
}

function mjhRemoveCurCell(elem) {
   	if (elem.classList.contains("e-mjhhighlightcurcell")) {
		elem.classList.remove("e-mjhhighlightcurcell");
	}	
}

function mjhAddHideActiveCell(elem) 
{
   	if (typeof elem != "undefined")
	{	
		if (typeof elem.children != "undefined")
		{
			if (1 < elem.children.length) 
			{	
				if (!elem.children[2].classList.contains("mjh-hide-active"))
				{
					elem.children[2].classList.add("mjh-hide-active");
				}
			}	
		}
	}
}	

function mjhRemoveHideActiveCell(elem) 
{
   	if (typeof elem != "undefined")
	{
		if (typeof elem.children != "undefined")
		{
			if (1 < elem.children.length) 
			{	
				if (elem.children[2].classList.contains("mjh-hide")) 
				{
					elem.children[2].classList.remove("mjh-hide");
				}
			}	
		}
	}
}

/* End Grid active cell */

/* Active cell for current row and column are ⎕io 1 so -1 in both cases     */
function mjhActiveCellElement(name) {
   	return document.getElementById(name.concat('_main_content')).children[2]
}
/* Cell for current row and column are ⎕io 1 so -1 in both cases     */
function mjhCellElement(name, row, col) {
   	try {
		return document.getElementById(name.concat('_main_content')).children[0].children[1].children[row-1].children[col-1];
	} catch {
		return null;	
	}
}

/* Cell for current row and column are ⎕io 1 so -1 in both cases     */
function mjhShowInput(name, row, col) {
   	try {
		let cell = document.getElementById(name.concat('_main_content')).children[0].children[1].children[row-1].children[col-1];
	    if (cell !== null)
		{
			if (cell.children[0].classList.contains("e-mjhvisible"))
			{ 
				cell.children[0].classList.remove("e-mjhinvisible");
			}
		}
	} catch {
		return null;	
	}
}

function mjhHideInput(name, row, col) {
   	try {
		let cell = document.getElementById(name.concat('_main_content')).children[0].children[1].children[row-1].children[col-1];
	    if (cell !== null)
		{
			if (!cell.children[0].classList.contains("e-mjhinvisible"))
			{ 
				cell.children[0].classList.add("e-mjhinvisible");
			}
		}	
	} catch {
		return null;	
	}
}

function mjhShowInputElem(elem) {
    if (elem !== null)
	{
		if (elem.classList.contains("e-mjhvisible"))
		{ 
			elem.classList.remove("e-mjhinvisible");
		}
	}
}

function mjhHideInputElem(elem) {
    if (elem !== null)
    {
		if (!elem.classList.contains("e-mjhinvisible"))
		{ 
			elem.classList.add("e-mjhinvisible");
		}
	}	
}
/* Cell for current row are ⎕io 1 so -1 in both cases     */
function mjhRowCellElement(name, row) {
	try {
		return document.getElementById(name.concat('_row_header')).children[0].children[1].children[row-1].children[1];
    } catch {
		return null;
	}		
}

/* Cell for current col are ⎕io 1 so -1 in both cases     */
function mjhColCellElement(name, col) {
   	try {
		return document.getElementById(name.concat('_col_header')).children[0].children[2].children[0].children[col-1];
	} catch {
		return null;
	}
}

/* Cell for current col are ⎕io 1 so -1 in both cases     */
function mjhRowColCellElement(name, row, col) {
   	try {
		return document.getElementById(name.concat('_col_header')).children[0].children[2].children[0].children[col-1];
	} catch {
		return null;
	}
}
/* Grid Highlight active cell   */
function mjhAddHighlight(elem) {
   	if (!elem.classList.contains("e-mjhhighlightcell")){
		elem.classList.add("e-mjhhighlightcell");
	}
}

function mjhRemoveHighlight(elem) {
   	if (elem.classList.contains("e-mjhhighlightcell")) {
		elem.classList.remove("e-mjhhighlightcell");
	}	
}
/* End Grid Highlight active cell */
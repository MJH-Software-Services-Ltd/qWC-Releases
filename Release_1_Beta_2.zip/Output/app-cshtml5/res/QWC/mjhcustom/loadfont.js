//function loadLocalFont(myfont){
// Define a FontFace
//	const font = new FontFace(myfont);
// Add to the document.fonts (FontFaceSet)
//	document.fonts.add(font);
// Load the font
//	font.load();
//} 
 
function loadFont(myfont, url){
// Define a FontFace
//  console.log("url(" + document.baseURI + url + ")");
	const font = new FontFace(myfont, "url(" + document.baseURI.substring(0, document.baseURI.indexOf("?")) + url + ")");
// Add to the document.fonts (FontFaceSet)
	document.fonts.add(font);
// Load the font
	font.load();
}
 
// document.fonts.ready.then(() => {
//		console.log("font ready");
//	});
  
//  window.onload = initFonts;
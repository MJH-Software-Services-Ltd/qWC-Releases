/* List Multicolumn   */
function mjhenableMultiColumn(elem) {
   	if (!elem.ulElement.parentNode.classList.contains("e-mjhlistmulticolumn")){
		elem.ulElement.parentNode.classList.add("e-mjhlistmulticolumn");
	}
}

function mjhdisableMultiColumn(elem) {
   	if (elem.ulElement.parentNode.classList.contains("e-mjhlistmulticolumn")) {
		elem.ulElement.parentNode.classList.remove("e-mjhlistmulticolumn");
	}	
}
/* End List Multicolumn */


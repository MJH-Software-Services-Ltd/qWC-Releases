function InsertDivParent(obj, classname, divclass) {
/* obj       = object UderlyingJSInstance
   classname = class closest to obj	
   divclass  = class to set to the new div element
*/ 
	var elem = closest(obj.element, classname);
/* 'elem` is the element you want to wrap  				*/
    var parent = elem.parentNode;
	var wrapper = document.createElement('div');
	wrapper.classList.add(divclass);
/* set the wrapper as child (instead of the element)  	*/
	parent.replaceChild(wrapper, elem);
/* set element as child of wrapper     					*/
	wrapper.appendChild(elem);
}
 // Sets e-fullrow to be the same as e-text-content
    function mjhTreeViewSetHeight(element,tree1) {
      if(tree1.fullRowSelect) {
        if(element.classList.contains("e-treeview")) {
          element = element.querySelector(".e-node-focus").querySelector(".e-fullrow");
        }
        else if(element.classList.contains("e-list-parent")) {
          element = element.querySelector(".e-fullrow");
        }
        else if(element.classList.value != ("e-fullrow") && element.closest(".e-list-item")) {        
          element = element.closest(".e-list-item").querySelector(".e-fullrow");   
        }
        if(element.nextElementSibling)
          element.style.height = element.nextElementSibling.offsetHeight +"px";        
      }
    }
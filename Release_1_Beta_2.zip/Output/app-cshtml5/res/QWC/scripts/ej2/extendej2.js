//Extend ej namespace with Syncfusion
$.extend(ej, Syncfusion);
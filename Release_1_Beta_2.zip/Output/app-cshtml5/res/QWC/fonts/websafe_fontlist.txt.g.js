window.FileContent = "Arial    				: Helvetica Neue, Helvetica, sans-serif\\
Arial Black				: Arial Bold, Gadget, sans-serif\\
Arial Narrow			: Arial, sans-serif\\
Arial Rounded MT Bold	: Helvetica Rounded, Arial, sans-serif\\
Baskerville     		: Baskerville Old Face, Garamond, Times New Roman, serif\\
Bodoni MT				: Bodoni 72, Didot, Didot LT STD, Hoefler Text, Garamond, Times New Roman, serif\\
Bodoni 72				: Bodoni MT, Didot, Didot LT STD, Hoefler Text, Garamond, Times New Roman, serif\\
Calibri					: Candara, Segoe, Segoe UI, Optima, Arial, sans-serif\\
Calisto MT				: Bookman Old Style, Bookman, Goudy Old Style, Garamond, Hoefler Text, Bitstream Charter, Georgia, serif\\
Cambria					: Georgia, serif\\
Candara					: Calibri, Segoe, Segoe UI, Optima, Arial, sans-serif\\
Century Gothic			: CenturyGothic, AppleGothic, sans-serif\\
Consolas				: monaco, monospace\\
Copperplate Gothic		: Copperplate Gothic Light, fantasy\\
Courier New				: Courier, Lucida Sans Typewriter, Lucida Typewriter, monospace\\
Dejavu Sans				: Arial, Verdana, sans-serif\\
Didot					: Didot LT STD, Hoefler Text, Garamond, Calisto MT, Times New Roman, serif\\
Franklin Gothic			: Arial Bold, Arial, sans-serif\\
Garamond				: Baskerville, Baskerville Old Face, Hoefler Text, Times New Roman, serif\\
Georgia					: Times, Times New Roman, serif\\
Gill Sans				: Gill Sans MT, Calibri, sans-serif\\
Goudy Old Style			: Garamond, Big Caslon, Times New Roman, serif\\
Helvetica Neu			: Helvetica, Arial, sans-serif.\\
Helvetica				: Helvetica Neu, Arial, sans-serif.\\
Impact 					: Charcoal, Helvetica Inserat, Bitstream Vera Sans Bold, Arial Black, sans-serif.\\
Lucida Bright			: Georgia, serif.\\
Lucida Sans				: Helvetica, Arial, sans-serif.\\
Microsoft Sans Serif	: sans-serif.\\
Optima					: Segoe, Segoe UI, Candara, Calibri, Arial, sans-serif.\\
Palatino				: Palatino Linotype, Palatino LT STD, Book Antiqua, Georgia, serif.\\
Perpetua				: Baskerville, Big Caslon, Palatino Linotype, Palatino, serif.\\
Rockwell				: Courier Bold, Courier, Georgia, Times, Times New Roman, serif.\\
Segoe UI				: Frutiger, Dejavu Sans, Helvetica Neue, Arial, sans-serif.\\
Tahoma					: Verdana, Segoe, sans-serif.\\
Times New Roman     	: Georgia, serif;\\
Trebuchet MS			: Lucida Grande, Lucida Sans Unicode, Lucida Sans, sans-serif.\\
Verdana					: Geneva, sans-serif.\\
Segoe script			: cursive\\
Rage					: cursive\\
Script MT				: cursive\\
Snell Roundhand			: cursive\\
Lucida Handwriting		: cursive\\
Andalé Mono 			: monospace\\
Courier 				: monospace\\
Lucida 					: monospace\\
Monaco 					: monospace\\
Bradley Hand 			: cursive\\
Brush Script MT 		: cursive\\
Luminari 				: fantasy\\
Comic Sans MS 			: cursive";
document.ResXFiles = document.ResXFiles || {};
document.ResXFiles.Runtime = document.ResXFiles.Runtime || {};
document.ResXFiles.Runtime.CSHTML5 = document.ResXFiles.Runtime.CSHTML5 || {};
document.ResXFiles.Runtime.CSHTML5.PagedCollectionView = document.ResXFiles.Runtime.CSHTML5.PagedCollectionView || {};
document.ResXFiles.Runtime.CSHTML5.PagedCollectionView.PagedCollectionViewResources = document.ResXFiles.Runtime.CSHTML5.PagedCollectionView.PagedCollectionViewResources || {};

document.ResXFiles.Runtime.CSHTML5.PagedCollectionView.PagedCollectionViewResources = {
    "CancelEditNotSupported": "CancelEdit is not supported for the current edit item.",
    "CannotFilter": "The Filter property cannot be set when the CanFilter property returns false.",
    "EnumeratorVersionChanged": "Collection was modified; enumeration operation cannot execute.",
    "InvalidPageSize": "PageSize cannot have a negative value.",
    "NoCheckOrChangeWhenDeferred": "Cannot change or check the contents or current position of the PagedCollectionView while Refresh is being deferred.",
    "OperationNotAllowedDuringAddOrEdit": "'{0}' is not allowed during an AddNew or EditItem transaction.",
    "OperationNotAllowedDuringTransaction": "'{0}' is not allowed during a transaction started by '{1}'.",
    "OperationNotAllowedForView": "'{0}' is not allowed for this view.",
    "RemoveNotSupported": "Remove/RemoveAt is not supported.",
    "PropertyNotReadable": "The property named '{0}' on type '{1}' cannot be read.",
    "IndexOutOfRange": "Index was out of range. Must be non-negative and less than the size of the collection.",
    "ChangingPageSizeNotAllowedDuringAddOrEdit": "Changing the PageSize is not allowed during an AddNew or EditItem transaction.",
    "InvalidEnumArgument": "The value of argument '{0}' ({1}) is invalid for Enum type '{2}'."
}
;